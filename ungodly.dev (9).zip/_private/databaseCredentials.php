<?php
/**
 * ==============================================================================
 * NAMESPACE: 
 * CONTEXT: Sitting in my server. root/_private/databaseCredentials.php 
 * AUTHOR: 
 * DESCRIPTION: CREDS
 * ==============================================================================
 */
 $dbHost = '';
 $dbUser = '';
 $dbPass = '';
 $dbName = '';
?>
