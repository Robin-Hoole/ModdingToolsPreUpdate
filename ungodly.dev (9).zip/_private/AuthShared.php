<?php
/**
 * ==============================================================================
 * NAMESPACE: RobinHooleProduction
 * CONTEXT: Shared auth/session helper for the Ungodly/FSG web-app suite
 * DESCRIPTION: One login, every same-origin tool, 12-hour browser auth token.
 * ==============================================================================
 */

declare(strict_types=1);

function fsgAuth_tokenLifetimeSeconds(): int { return 43200; }

function fsgAuth_isHttpsRequest(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
}

function fsgAuth_cookieDomain(): string
{
    $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
    $host = preg_replace('/:\d+$/', '', $host) ?: '';
    if ($host === '' || $host === 'localhost' || filter_var($host, FILTER_VALIDATE_IP) !== false) return '';
    return $host === 'ungodly.dev' ? '.ungodly.dev' : $host;
}

function fsgAuth_startSharedSession(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;

    ini_set('session.gc_maxlifetime', (string)fsgAuth_tokenLifetimeSeconds());
    ini_set('session.cookie_lifetime', (string)fsgAuth_tokenLifetimeSeconds());
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_strict_mode', '1');

    $params = [
        'lifetime' => fsgAuth_tokenLifetimeSeconds(),
        'path' => '/',
        'secure' => fsgAuth_isHttpsRequest(),
        'httponly' => true,
        'samesite' => 'Lax',
    ];
    $domain = fsgAuth_cookieDomain();
    if ($domain !== '') $params['domain'] = $domain;

    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params($params);
    } else {
        session_set_cookie_params(fsgAuth_tokenLifetimeSeconds(), '/', $domain, fsgAuth_isHttpsRequest(), true);
    }

    session_start();
}

function fsgAuth_touchSharedSession(): void
{
    fsgAuth_startSharedSession();
    $_SESSION['fsg_last_seen_at'] = time();
}

function fsgAuth_setBearerCookie(string $token): void
{
    $params = [
        'expires' => time() + fsgAuth_tokenLifetimeSeconds(),
        'path' => '/',
        'secure' => fsgAuth_isHttpsRequest(),
        'httponly' => true,
        'samesite' => 'Lax',
    ];
    $domain = fsgAuth_cookieDomain();
    if ($domain !== '') $params['domain'] = $domain;

    if (PHP_VERSION_ID >= 70300) {
        setcookie('AUTH_TOKEN', $token, $params);
    } else {
        setcookie('AUTH_TOKEN', $token, time() + fsgAuth_tokenLifetimeSeconds(), '/', $domain, fsgAuth_isHttpsRequest(), true);
    }

    header('X-Auth-Token: ' . $token);
    header('X-Auth-Expires-At: ' . gmdate('c', time() + fsgAuth_tokenLifetimeSeconds()));
}

function fsgAuth_clearBearerCookie(): void
{
    $params = [
        'expires' => time() - 42000,
        'path' => '/',
        'secure' => fsgAuth_isHttpsRequest(),
        'httponly' => true,
        'samesite' => 'Lax',
    ];
    $domain = fsgAuth_cookieDomain();
    if ($domain !== '') $params['domain'] = $domain;

    if (PHP_VERSION_ID >= 70300) {
        setcookie('AUTH_TOKEN', '', $params);
    } else {
        setcookie('AUTH_TOKEN', '', time() - 42000, '/', $domain, fsgAuth_isHttpsRequest(), true);
    }
}

function fsgAuth_extractBearerToken(): string
{
    // Query/body fallback exists because some shared-hosting stacks do not pass
    // Authorization or custom X-* headers into PHP reliably. Same-origin tools
    // append this token only after login, so all seven web apps can recognize
    // the same browser for the 12-hour window.
    $queryToken = (string)($_GET['authToken'] ?? $_GET['token'] ?? '');
    if (trim($queryToken) !== '') return trim($queryToken);

    $postToken = (string)($_POST['authToken'] ?? $_POST['token'] ?? '');
    if (trim($postToken) !== '') return trim($postToken);

    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authHeader = '';
    foreach ($headers as $key => $value) {
        if (strtolower((string)$key) === 'authorization') {
            $authHeader = (string)$value;
            break;
        }
    }
    if ($authHeader === '') $authHeader = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
    if ($authHeader === '') $authHeader = (string)($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (preg_match('/Bearer\s+(.+)/i', $authHeader, $matches)) return trim($matches[1]);

    $xToken = (string)($_SERVER['HTTP_X_AUTH_TOKEN'] ?? '');
    if (trim($xToken) !== '') return trim($xToken);

    $cookieToken = (string)($_COOKIE['AUTH_TOKEN'] ?? '');
    return trim($cookieToken);
}

function fsgAuth_tokenHash(string $token): string { return hash('sha256', $token); }

function fsgAuth_respondJson(array $payload, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function fsgAuth_requireCredentials(): array
{
    $credentialsPath = __DIR__ . '/databaseCredentials.php';
    if (!is_file($credentialsPath)) fsgAuth_respondJson(['ok' => false, 'error' => 'Missing _private/databaseCredentials.php'], 500);
    require $credentialsPath;
    foreach (['dbHost', 'dbUser', 'dbPass', 'dbName'] as $varName) {
        if (!isset(${$varName})) fsgAuth_respondJson(['ok' => false, 'error' => "Missing database credential variable: {$varName}"], 500);
    }
    return [$dbHost, $dbUser, $dbPass, $dbName];
}

function fsgAuth_dbConnection(): PDO
{
    [$dbHost, $dbUser, $dbPass, $dbName] = fsgAuth_requireCredentials();
    $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
    return new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function fsgAuth_textValue(mixed $value): string
{
    if ($value === null) return '';
    if (is_bool($value)) return $value ? '1' : '0';
    if (is_scalar($value)) return (string)$value;
    return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '';
}

function fsgAuth_boolValue(mixed $value): int
{
    if (is_bool($value)) return $value ? 1 : 0;
    if (is_numeric($value)) return ((int)$value) !== 0 ? 1 : 0;
    if (is_string($value)) return in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true) ? 1 : 0;
    return 0;
}

function fsgAuth_requestBody(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') return [];
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) fsgAuth_respondJson(['ok' => false, 'error' => 'Invalid JSON body.'], 400);
    return $decoded;
}

function fsgAuth_sharedFsgUserIdSqlType(PDO $pdo): string
{
    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM FSG_users LIKE 'id'");
        $column = $stmt ? $stmt->fetch() : null;
        $type = strtolower((string)($column['Type'] ?? 'int'));
        $isUnsigned = strpos($type, 'unsigned') !== false;
        if (strpos($type, 'bigint') !== false) return $isUnsigned ? 'BIGINT UNSIGNED' : 'BIGINT';
        return $isUnsigned ? 'INT UNSIGNED' : 'INT';
    } catch (Throwable $e) {
        return 'INT';
    }
}

function fsgAuth_ensureAccountTables(PDO $pdo): void
{
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_users (
        id INT NOT NULL AUTO_INCREMENT,
        username VARCHAR(64) NOT NULL,
        email VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        is_over_18 TINYINT(1) NOT NULL DEFAULT 0,
        agreed_terms TINYINT(1) NOT NULL DEFAULT 0,
        agreed_privacy TINYINT(1) NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        is_admin TINYINT(1) NOT NULL DEFAULT 0,
        banned_until DATETIME NULL DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_FSG_users_active_username (is_active, username),
        KEY idx_FSG_users_active_email (is_active, email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $userColumns = [
        'is_over_18' => "ALTER TABLE FSG_users ADD COLUMN is_over_18 TINYINT(1) NOT NULL DEFAULT 0",
        'agreed_terms' => "ALTER TABLE FSG_users ADD COLUMN agreed_terms TINYINT(1) NOT NULL DEFAULT 0",
        'agreed_privacy' => "ALTER TABLE FSG_users ADD COLUMN agreed_privacy TINYINT(1) NOT NULL DEFAULT 0",
        'is_active' => "ALTER TABLE FSG_users ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1",
        'is_admin' => "ALTER TABLE FSG_users ADD COLUMN is_admin TINYINT(1) NOT NULL DEFAULT 0",
        'banned_until' => "ALTER TABLE FSG_users ADD COLUMN banned_until DATETIME NULL DEFAULT NULL",
        'created_at' => "ALTER TABLE FSG_users ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP",
        'updated_at' => "ALTER TABLE FSG_users ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
    ];
    foreach ($userColumns as $columnName => $alterSql) {
        try {
            $check = $pdo->query("SHOW COLUMNS FROM FSG_users LIKE " . $pdo->quote($columnName));
            if ($check && $check->rowCount() === 0) $pdo->exec($alterSql);
        } catch (Throwable $e) {}
    }

    $userType = fsgAuth_sharedFsgUserIdSqlType($pdo);

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_user_identity_history (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$userType} NOT NULL,
        field_name ENUM('username','email','password') NOT NULL,
        old_value VARCHAR(255) NOT NULL DEFAULT '',
        new_value VARCHAR(255) NOT NULL DEFAULT '',
        changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_FSG_user_identity_history_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_auth_sessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$userType} NOT NULL,
        token_hash CHAR(64) NOT NULL,
        browser_label VARCHAR(128) NOT NULL DEFAULT '',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME NOT NULL,
        last_seen_at DATETIME NULL DEFAULT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_auth_sessions_token_hash (token_hash),
        KEY idx_FSG_auth_sessions_user_seen (user_id, last_seen_at),
        KEY idx_FSG_auth_sessions_expires (expires_at),
        KEY idx_FSG_auth_sessions_active (user_id, is_active, expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    foreach ([
        'browser_label' => "ALTER TABLE FSG_auth_sessions ADD COLUMN browser_label VARCHAR(128) NOT NULL DEFAULT '' AFTER token_hash",
        'is_active' => "ALTER TABLE FSG_auth_sessions ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER last_seen_at"
    ] as $columnName => $alterSql) {
        try {
            $check = $pdo->query("SHOW COLUMNS FROM FSG_auth_sessions LIKE " . $pdo->quote($columnName));
            if ($check && $check->rowCount() === 0) $pdo->exec($alterSql);
        } catch (Throwable $e) {}
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Server_Sessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$userType} NOT NULL,
        app_key VARCHAR(64) NOT NULL DEFAULT 'DialogueDesigner',
        session_id VARCHAR(96) NOT NULL,
        first_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        first_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_viewed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        workspace_count INT UNSIGNED NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Server_Sessions_user_app_session (user_id, app_key, session_id),
        KEY idx_FSG_Server_Sessions_user_viewed (user_id, last_viewed_at),
        KEY idx_FSG_Server_Sessions_session (session_id),
        KEY idx_FSG_Server_Sessions_app_user (app_key, user_id, last_viewed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DD_UserSessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$userType} NOT NULL,
        session_id VARCHAR(96) NOT NULL,
        first_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_viewed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        workspace_count INT UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_DD_UserSessions_session (session_id),
        KEY idx_FSG_DD_UserSessions_user_viewed (user_id, last_viewed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    try { $pdo->prepare('DELETE FROM FSG_auth_sessions WHERE expires_at < UTC_TIMESTAMP() OR is_active = 0')->execute(); } catch (Throwable $e) {}
}

function fsgAuth_currentUserId(): int
{
    if (isset($_SESSION['fsg_user_id'])) return (int)$_SESSION['fsg_user_id'];
    if (isset($_SESSION['dd_user_id'])) return (int)$_SESSION['dd_user_id'];
    if (isset($_SESSION['user_id'])) return (int)$_SESSION['user_id'];
    return 0;
}

function fsgAuth_setCurrentUserSession(int $userId, string $username): void
{
    fsgAuth_startSharedSession();
    $_SESSION['fsg_user_id'] = $userId;
    $_SESSION['fsg_username'] = $username;
    $_SESSION['dd_user_id'] = $userId;
    $_SESSION['dd_username'] = $username;
    $_SESSION['user_id'] = $userId;
    $_SESSION['username'] = $username;
    $_SESSION['fsg_last_seen_at'] = time();
}

function fsgAuth_clearCurrentUserSession(): void
{
    unset($_SESSION['fsg_user_id'], $_SESSION['fsg_username'], $_SESSION['dd_user_id'], $_SESSION['dd_username'], $_SESSION['user_id'], $_SESSION['username'], $_SESSION['guest_name']);
}

function fsgAuth_issueAuthToken(PDO $pdo, int $userId, string $browserLabel = ''): string
{
    $token = bin2hex(random_bytes(32));
    $hash = fsgAuth_tokenHash($token);
    $expiresSql = gmdate('Y-m-d H:i:s', time() + fsgAuth_tokenLifetimeSeconds());
    $pdo->prepare('DELETE FROM FSG_auth_sessions WHERE expires_at < UTC_TIMESTAMP() OR is_active = 0')->execute();
    $stmt = $pdo->prepare('INSERT INTO FSG_auth_sessions (user_id, token_hash, browser_label, expires_at, last_seen_at, is_active) VALUES (?, ?, ?, ?, UTC_TIMESTAMP(), 1)');
    $stmt->execute([$userId, $hash, mb_substr($browserLabel, 0, 128), $expiresSql]);
    fsgAuth_setBearerCookie($token);
    return $token;
}

function fsgAuth_userIdFromBearerToken(PDO $pdo): int
{
    $token = fsgAuth_extractBearerToken();
    if ($token === '') return 0;
    $hash = fsgAuth_tokenHash($token);
    $stmt = $pdo->prepare('SELECT s.user_id, u.username FROM FSG_auth_sessions s JOIN FSG_users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > UTC_TIMESTAMP() AND s.is_active = 1 AND u.is_active = 1 LIMIT 1');
    $stmt->execute([$hash]);
    $row = $stmt->fetch();
    if (!$row) return 0;

    $userId = (int)$row['user_id'];
    $username = (string)$row['username'];
    $expiresSql = gmdate('Y-m-d H:i:s', time() + fsgAuth_tokenLifetimeSeconds());
    $upd = $pdo->prepare('UPDATE FSG_auth_sessions SET expires_at = ?, last_seen_at = UTC_TIMESTAMP(), is_active = 1 WHERE token_hash = ?');
    $upd->execute([$expiresSql, $hash]);
    fsgAuth_setBearerCookie($token);
    fsgAuth_setCurrentUserSession($userId, $username);
    return $userId;
}

function fsgAuth_currentUserIdFromRequest(PDO $pdo): int
{
    fsgAuth_startSharedSession();
    $sessionUserId = fsgAuth_currentUserId();
    if ($sessionUserId > 0 && fsgAuth_getUserById($pdo, $sessionUserId)) return $sessionUserId;
    return fsgAuth_userIdFromBearerToken($pdo);
}

function fsgAuth_passwordMeetsPolicy(string $password): bool
{
    return (bool)preg_match('/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z0-9]).{8,}/', $password);
}

function fsgAuth_normalizeUsername(string $username): string { return trim($username); }
function fsgAuth_normalizeEmail(string $email): string { return strtolower(trim($email)); }

function fsgAuth_activeIdentityExists(PDO $pdo, string $username, string $email, int $excludeUserId = 0): bool
{
    $sql = 'SELECT id FROM FSG_users WHERE is_active = 1 AND (LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?))';
    $params = [$username, $email];
    if ($excludeUserId > 0) { $sql .= ' AND id != ?'; $params[] = $excludeUserId; }
    $sql .= ' LIMIT 1';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (bool)$stmt->fetch();
}

function fsgAuth_getUserById(PDO $pdo, int $userId): ?array
{
    if ($userId <= 0) return null;
    $stmt = $pdo->prepare('SELECT id, username, email, created_at FROM FSG_users WHERE id = ? AND is_active = 1 LIMIT 1');
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    return $row ?: null;
}


function fsgAuth_identifierIsSafe(string $identifier): bool
{
    return $identifier !== '' && (bool)preg_match('/^[A-Za-z0-9_]+$/', $identifier);
}

function fsgAuth_quoteIdentifier(string $identifier): string
{
    if (!fsgAuth_identifierIsSafe($identifier)) {
        throw new RuntimeException('Unsafe SQL identifier: ' . $identifier);
    }
    return '`' . str_replace('`', '``', $identifier) . '`';
}

function fsgAuth_tableExists(PDO $pdo, string $tableName): bool
{
    $tableName = trim($tableName);
    if (!fsgAuth_identifierIsSafe($tableName)) return false;
    try {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?');
        $stmt->execute([$tableName]);
        if ((int)$stmt->fetchColumn() > 0) return true;
    } catch (Throwable $e) {}
    try {
        $stmt = $pdo->query('SHOW TABLES');
        foreach (($stmt ? $stmt->fetchAll(PDO::FETCH_NUM) : []) as $row) {
            if (strcasecmp((string)($row[0] ?? ''), $tableName) === 0) return true;
        }
    } catch (Throwable $e) {}
    try {
        $pdo->query('SHOW COLUMNS FROM ' . fsgAuth_quoteIdentifier($tableName));
        return true;
    } catch (Throwable $e) {}
    return false;
}

function fsgAuth_columnExists(PDO $pdo, string $tableName, string $columnName): bool
{
    $tableName = trim($tableName);
    $columnName = trim($columnName);
    if (!fsgAuth_identifierIsSafe($tableName) || !fsgAuth_identifierIsSafe($columnName)) return false;
    try {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?');
        $stmt->execute([$tableName, $columnName]);
        if ((int)$stmt->fetchColumn() > 0) return true;
    } catch (Throwable $e) {}
    try {
        $stmt = $pdo->query('SHOW COLUMNS FROM ' . fsgAuth_quoteIdentifier($tableName));
        foreach (($stmt ? $stmt->fetchAll() : []) as $row) {
            if (strcasecmp((string)($row['Field'] ?? ''), $columnName) === 0) return true;
        }
    } catch (Throwable $e) {}
    return false;
}

function fsgAuth_serverSessionColumns(PDO $pdo): array
{
    $cols = [
        'app' => '',
        'first' => '',
        'firstPushed' => '',
        'lastPushed' => '',
        'lastViewed' => '',
        'workspaceCount' => '',
        'isActive' => '',
    ];
    if (!fsgAuth_tableExists($pdo, 'FSG_Server_Sessions')) return $cols;
    $cols['app'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'app_key') ? 'app_key' : (fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'app_name') ? 'app_name' : '');
    $cols['first'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'first_seen_at') ? 'first_seen_at' : (fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'first_used_at') ? 'first_used_at' : '');
    $cols['firstPushed'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'first_pushed_at') ? 'first_pushed_at' : '';
    $cols['lastPushed'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'last_pushed_at') ? 'last_pushed_at' : '';
    $cols['lastViewed'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'last_viewed_at') ? 'last_viewed_at' : '';
    $cols['workspaceCount'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'workspace_count') ? 'workspace_count' : '';
    $cols['isActive'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'is_active') ? 'is_active' : '';
    return $cols;
}

function fsgAuth_serverSessionTimeExpr(array $cols): string
{
    $parts = [];
    if ($cols['lastViewed'] !== '') $parts[] = $cols['lastViewed'];
    if ($cols['lastPushed'] !== '') $parts[] = $cols['lastPushed'];
    if ($cols['firstPushed'] !== '') $parts[] = $cols['firstPushed'];
    if ($cols['first'] !== '') $parts[] = $cols['first'];
    return $parts ? 'COALESCE(' . implode(', ', $parts) . ')' : 'id';
}

function fsgAuth_touchServerSession(PDO $pdo, int $userId, string $appKey, string $sessionId, string $mode = 'view'): void
{
    $sessionId = trim($sessionId);
    $appKey = trim($appKey) ?: 'DialogueDesigner';
    if ($userId <= 0 || $sessionId === '') return;

    if (!$pdo->inTransaction()) {
        fsgAuth_ensureAccountTables($pdo);
    }

    $cols = fsgAuth_serverSessionColumns($pdo);
    if ($cols['app'] === '') return;

    $isPush = $mode === 'push';
    $insertCols = ['user_id', $cols['app'], 'session_id'];
    $valuesSql = ['?', '?', '?'];
    $params = [$userId, $appKey, $sessionId];

    if ($cols['firstPushed'] !== '') { $insertCols[] = $cols['firstPushed']; $valuesSql[] = $isPush ? 'CURRENT_TIMESTAMP' : 'NULL'; }
    if ($cols['lastPushed'] !== '') { $insertCols[] = $cols['lastPushed']; $valuesSql[] = $isPush ? 'CURRENT_TIMESTAMP' : 'NULL'; }
    if ($cols['lastViewed'] !== '') { $insertCols[] = $cols['lastViewed']; $valuesSql[] = 'CURRENT_TIMESTAMP'; }
    if ($cols['workspaceCount'] !== '') { $insertCols[] = $cols['workspaceCount']; $valuesSql[] = $isPush ? '1' : '0'; }
    if ($cols['isActive'] !== '') { $insertCols[] = $cols['isActive']; $valuesSql[] = '1'; }

    $updates = [];
    if ($cols['lastViewed'] !== '') $updates[] = "{$cols['lastViewed']} = CURRENT_TIMESTAMP";
    if ($cols['lastPushed'] !== '') $updates[] = "{$cols['lastPushed']} = IF(VALUES({$cols['lastPushed']}) IS NULL, {$cols['lastPushed']}, VALUES({$cols['lastPushed']}))";
    if ($cols['firstPushed'] !== '') $updates[] = "{$cols['firstPushed']} = IF({$cols['firstPushed']} IS NULL, VALUES({$cols['firstPushed']}), {$cols['firstPushed']})";
    if ($cols['workspaceCount'] !== '') $updates[] = "{$cols['workspaceCount']} = {$cols['workspaceCount']} + " . ($isPush ? '1' : '0');
    if ($cols['isActive'] !== '') $updates[] = "{$cols['isActive']} = 1";

    $sql = "INSERT INTO FSG_Server_Sessions (`" . implode('`,`', $insertCols) . "`) VALUES (" . implode(',', $valuesSql) . ")";
    if ($updates) $sql .= " ON DUPLICATE KEY UPDATE " . implode(', ', $updates);

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
}

function fsgAuth_listUserSessions(PDO $pdo, int $userId, string $appKey = 'DialogueDesigner'): array
{
    if ($userId <= 0) return [];
    if (!$pdo->inTransaction()) {
        fsgAuth_ensureAccountTables($pdo);
    }

    $sessionsById = [];
    $normalizedAppKey = strtolower(str_replace(' ', '', $appKey));

    try {
        $cols = fsgAuth_serverSessionColumns($pdo);
        if ($cols['app'] !== '') {
            $timeExpr = fsgAuth_serverSessionTimeExpr($cols);
            $whereActive = $cols['isActive'] !== '' ? " AND {$cols['isActive']} = 1" : '';
            $firstExpr = $cols['firstPushed'] !== '' ? $cols['firstPushed'] : ($cols['first'] !== '' ? $cols['first'] : 'NULL');
            $lastPushExpr = $cols['lastPushed'] !== '' ? $cols['lastPushed'] : 'NULL';
            $lastViewExpr = $cols['lastViewed'] !== '' ? $cols['lastViewed'] : ($cols['first'] !== '' ? $cols['first'] : 'NULL');
            $countExpr = $cols['workspaceCount'] !== '' ? $cols['workspaceCount'] : '0';
            $stmt = $pdo->prepare("SELECT session_id, {$cols['app']} AS app_key, {$firstExpr} AS first_pushed_at, {$lastPushExpr} AS last_pushed_at, {$lastViewExpr} AS last_viewed_at, {$countExpr} AS workspace_count FROM FSG_Server_Sessions WHERE user_id = ? AND REPLACE(LOWER({$cols['app']}), ' ', '') = ?{$whereActive} ORDER BY {$timeExpr} DESC, id DESC");
            $stmt->execute([$userId, $normalizedAppKey]);
            foreach ($stmt->fetchAll() as $row) {
                $sid = trim((string)($row['session_id'] ?? ''));
                if ($sid !== '') $sessionsById[$sid] = $row;
            }
        }
    } catch (Throwable $e) {}

    if ($normalizedAppKey === 'dialoguedesigner') {
        try {
            if (fsgAuth_tableExists($pdo, 'FSG_DD_UserSessions')) {
                $stmt = $pdo->prepare('SELECT session_id, first_pushed_at, last_pushed_at, last_viewed_at, workspace_count FROM FSG_DD_UserSessions WHERE user_id = ? ORDER BY last_viewed_at DESC, last_pushed_at DESC, id DESC');
                $stmt->execute([$userId]);
                foreach ($stmt->fetchAll() as $row) {
                    $sid = trim((string)($row['session_id'] ?? ''));
                    if ($sid === '') continue;
                    if (!isset($sessionsById[$sid])) $sessionsById[$sid] = ['app_key' => 'DialogueDesigner'] + $row;
                }
            }
        } catch (Throwable $e) {}

        try {
            if (fsgAuth_tableExists($pdo, 'FSG_DD_Workspaces')) {
                $createdCol = fsgAuth_columnExists($pdo, 'FSG_DD_Workspaces', 'created_at') ? 'created_at' : (fsgAuth_columnExists($pdo, 'FSG_DD_Workspaces', 'updated_at') ? 'updated_at' : 'id');
                $updatedCol = fsgAuth_columnExists($pdo, 'FSG_DD_Workspaces', 'updated_at') ? 'updated_at' : $createdCol;
                $stmt = $pdo->prepare("SELECT session_id, MIN({$createdCol}) AS first_pushed_at, MAX({$updatedCol}) AS last_pushed_at, MAX({$updatedCol}) AS last_viewed_at, COUNT(*) AS workspace_count FROM FSG_DD_Workspaces WHERE user_id = ? AND session_id <> '' GROUP BY session_id ORDER BY last_viewed_at DESC");
                $stmt->execute([$userId]);
                foreach ($stmt->fetchAll() as $row) {
                    $sid = trim((string)($row['session_id'] ?? ''));
                    if ($sid === '') continue;
                    if (!isset($sessionsById[$sid])) $sessionsById[$sid] = ['app_key' => 'DialogueDesigner'] + $row;
                }
            }
        } catch (Throwable $e) {}
    }

    if ($normalizedAppKey === 'taskmanager') {
        try {
            if (fsgAuth_tableExists($pdo, 'FSG_TASK_server_sessions')) {
                $stmt = $pdo->prepare("SELECT session_id, created_at AS first_pushed_at, updated_at AS last_pushed_at, updated_at AS last_viewed_at, 1 AS workspace_count FROM FSG_TASK_server_sessions WHERE user_id = ? ORDER BY updated_at DESC");
                $stmt->execute([$userId]);
                foreach ($stmt->fetchAll() as $row) {
                    $sid = trim((string)($row['session_id'] ?? ''));
                    if ($sid === '') continue;
                    if (!isset($sessionsById[$sid])) $sessionsById[$sid] = ['app_key' => 'TaskManager'] + $row;
                }
            }
        } catch (Throwable $e) {}
    }

    if ($normalizedAppKey === 'promptdesigner') {
        try {
            if (fsgAuth_tableExists($pdo, 'FSG_PD_server_sessions')) {
                $stmt = $pdo->prepare("SELECT session_id, created_at AS first_pushed_at, updated_at AS last_pushed_at, updated_at AS last_viewed_at, 1 AS workspace_count FROM FSG_PD_server_sessions WHERE user_id = ? ORDER BY updated_at DESC");
                $stmt->execute([$userId]);
                foreach ($stmt->fetchAll() as $row) {
                    $sid = trim((string)($row['session_id'] ?? ''));
                    if ($sid === '') continue;
                    if (!isset($sessionsById[$sid])) $sessionsById[$sid] = ['app_key' => 'PromptDesigner'] + $row;
                }
            }
        } catch (Throwable $e) {}
    }

    if ($normalizedAppKey === 'narrativeflow') {
        try {
            if (fsgAuth_tableExists($pdo, 'FSG_NF_server_sessions')) {
                $stmt = $pdo->prepare("SELECT session_id, created_at AS first_pushed_at, updated_at AS last_pushed_at, updated_at AS last_viewed_at, 1 AS workspace_count FROM FSG_NF_server_sessions WHERE user_id = ? ORDER BY updated_at DESC");
                $stmt->execute([$userId]);
                foreach ($stmt->fetchAll() as $row) {
                    $sid = trim((string)($row['session_id'] ?? ''));
                    if ($sid === '') continue;
                    if (!isset($sessionsById[$sid])) $sessionsById[$sid] = ['app_key' => 'NarrativeFlow'] + $row;
                }
            }
        } catch (Throwable $e) {}
    }

    $sessions = array_values($sessionsById);
    usort($sessions, function($a, $b) {
        $aTime = strtotime((string)($a['last_viewed_at'] ?? $a['last_pushed_at'] ?? $a['first_pushed_at'] ?? '')) ?: 0;
        $bTime = strtotime((string)($b['last_viewed_at'] ?? $b['last_pushed_at'] ?? $b['first_pushed_at'] ?? '')) ?: 0;
        return $bTime <=> $aTime;
    });
    return $sessions;
}

function fsgAuth_authPayload(PDO $pdo): array
{
    $userId = fsgAuth_currentUserIdFromRequest($pdo);
    $user = fsgAuth_getUserById($pdo, $userId);
    if (!$user) {
        fsgAuth_clearCurrentUserSession();
        return ['loggedIn' => false, 'user' => null, 'sessions' => [], 'authExpiresAt' => ''];
    }
    fsgAuth_setCurrentUserSession((int)$user['id'], (string)$user['username']);
    return [
        'loggedIn' => true,
        'user' => [
            'id' => (int)$user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'createdAt' => $user['created_at'],
        ],
        'sessions' => fsgAuth_listUserSessions($pdo, (int)$user['id'], 'DialogueDesigner'),
        'authExpiresAt' => gmdate('c', time() + fsgAuth_tokenLifetimeSeconds()),
    ];
}

function fsgAuth_registerAccount(PDO $pdo, array $body): array
{
    $username = fsgAuth_normalizeUsername(fsgAuth_textValue($body['username'] ?? ''));
    $email = fsgAuth_normalizeEmail(fsgAuth_textValue($body['email'] ?? ''));
    $password = fsgAuth_textValue($body['password'] ?? '');
    $passwordConfirm = fsgAuth_textValue($body['passwordConfirm'] ?? $body['passwordVerify'] ?? '');
    $over18 = fsgAuth_boolValue($body['over18'] ?? false);
    $terms = fsgAuth_boolValue($body['terms'] ?? false);
    $privacy = fsgAuth_boolValue($body['privacy'] ?? false);
    if ($username === '' || $email === '') fsgAuth_respondJson(['ok' => false, 'error' => 'Username and email are required.'], 400);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fsgAuth_respondJson(['ok' => false, 'error' => 'Enter a valid email address.'], 400);
    if (!$over18 || !$terms || !$privacy) fsgAuth_respondJson(['ok' => false, 'error' => 'You must confirm 18+ and agree to the Terms of Service and Privacy Policy.'], 400);
    if ($password !== $passwordConfirm) fsgAuth_respondJson(['ok' => false, 'error' => 'Passwords do not match.'], 400);
    if (!fsgAuth_passwordMeetsPolicy($password)) fsgAuth_respondJson(['ok' => false, 'error' => 'Password must be at least 8 characters with 1 uppercase, 1 lowercase, 1 number, and 1 special character.'], 400);
    if (fsgAuth_activeIdentityExists($pdo, $username, $email)) fsgAuth_respondJson(['ok' => false, 'error' => 'Username or email is already active.'], 409);
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO FSG_users (username, email, password, is_over_18, agreed_terms, agreed_privacy, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)');
    $stmt->execute([$username, $email, $hash, $over18, $terms, $privacy]);
    $userId = (int)$pdo->lastInsertId();
    fsgAuth_setCurrentUserSession($userId, $username);
    $payload = fsgAuth_authPayload($pdo);
    $payload['authToken'] = fsgAuth_issueAuthToken($pdo, $userId, fsgAuth_textValue($body['browserLabel'] ?? ''));
    return $payload;
}

function fsgAuth_loginAccount(PDO $pdo, array $body): array
{
    $identity = trim(fsgAuth_textValue($body['identity'] ?? ''));
    $password = fsgAuth_textValue($body['password'] ?? '');
    if ($identity === '' || $password === '') fsgAuth_respondJson(['ok' => false, 'error' => 'Username/email and password are required.'], 400);
    $stmt = $pdo->prepare('SELECT id, username, password FROM FSG_users WHERE is_active = 1 AND (LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)) LIMIT 1');
    $stmt->execute([$identity, $identity]);
    $row = $stmt->fetch();
    if (!$row || !password_verify($password, $row['password'])) fsgAuth_respondJson(['ok' => false, 'error' => 'Invalid credentials.'], 401);
    $userId = (int)$row['id'];
    fsgAuth_setCurrentUserSession($userId, (string)$row['username']);
    $payload = fsgAuth_authPayload($pdo);
    $payload['authToken'] = fsgAuth_issueAuthToken($pdo, $userId, fsgAuth_textValue($body['browserLabel'] ?? ''));
    return $payload;
}

function fsgAuth_updateProfile(PDO $pdo, array $body): array
{
    $userId = fsgAuth_currentUserIdFromRequest($pdo);
    $user = fsgAuth_getUserById($pdo, $userId);
    if (!$user) fsgAuth_respondJson(['ok' => false, 'error' => 'You are not logged in.'], 401);
    $username = fsgAuth_normalizeUsername(fsgAuth_textValue($body['username'] ?? ''));
    $email = fsgAuth_normalizeEmail(fsgAuth_textValue($body['email'] ?? ''));
    if ($username === '' || $email === '') fsgAuth_respondJson(['ok' => false, 'error' => 'Username and email are required.'], 400);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fsgAuth_respondJson(['ok' => false, 'error' => 'Enter a valid email address.'], 400);
    if (fsgAuth_activeIdentityExists($pdo, $username, $email, $userId)) fsgAuth_respondJson(['ok' => false, 'error' => 'Username or email is already active.'], 409);
    $pdo->beginTransaction();
    try {
        if ($username !== $user['username']) {
            $hist = $pdo->prepare("INSERT INTO FSG_user_identity_history (user_id, field_name, old_value, new_value) VALUES (?, 'username', ?, ?)");
            $hist->execute([$userId, $user['username'], $username]);
        }
        if ($email !== strtolower((string)$user['email'])) {
            $hist = $pdo->prepare("INSERT INTO FSG_user_identity_history (user_id, field_name, old_value, new_value) VALUES (?, 'email', ?, ?)");
            $hist->execute([$userId, $user['email'], $email]);
        }
        $stmt = $pdo->prepare('UPDATE FSG_users SET username = ?, email = ? WHERE id = ?');
        $stmt->execute([$username, $email, $userId]);
        fsgAuth_setCurrentUserSession($userId, $username);
        $pdo->commit();
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
    return fsgAuth_authPayload($pdo);
}

function fsgAuth_changePassword(PDO $pdo, array $body): array
{
    $userId = fsgAuth_currentUserIdFromRequest($pdo);
    if (!fsgAuth_getUserById($pdo, $userId)) fsgAuth_respondJson(['ok' => false, 'error' => 'You are not logged in.'], 401);
    $password = fsgAuth_textValue($body['password'] ?? '');
    $passwordConfirm = fsgAuth_textValue($body['passwordConfirm'] ?? $body['passwordVerify'] ?? '');
    if ($password !== $passwordConfirm) fsgAuth_respondJson(['ok' => false, 'error' => 'Passwords do not match.'], 400);
    if (!fsgAuth_passwordMeetsPolicy($password)) fsgAuth_respondJson(['ok' => false, 'error' => 'Password must be at least 8 characters with 1 uppercase, 1 lowercase, 1 number, and 1 special character.'], 400);
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('UPDATE FSG_users SET password = ? WHERE id = ?');
        $stmt->execute([$hash, $userId]);
        $hist = $pdo->prepare("INSERT INTO FSG_user_identity_history (user_id, field_name, old_value, new_value) VALUES (?, 'password', '[password changed]', '[password changed]')");
        $hist->execute([$userId]);
        $pdo->commit();
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
    return fsgAuth_authPayload($pdo);
}

function fsgAuth_generateUniqueSessionId(PDO $pdo): string
{
    for ($attempt = 0; $attempt < 25; $attempt++) {
        $bytes = strtoupper(bin2hex(random_bytes(8)));
        $sessionId = 'DD-' . substr($bytes, 0, 6) . '-' . substr($bytes, 6, 10);
        foreach (['FSG_DD_Workspaces', 'FSG_DD_UserSessions', 'FSG_Server_Sessions', 'FSG_PD_server_sessions', 'FSG_NF_server_sessions', 'FSG_NF_workspaces'] as $table) {
            try {
                $stmt = $pdo->prepare("SELECT session_id FROM {$table} WHERE session_id = ? LIMIT 1");
                $stmt->execute([$sessionId]);
                if ($stmt->fetch()) continue 2;
            } catch (Throwable $e) {}
        }
        return $sessionId;
    }
    return 'DD-' . strtoupper(bin2hex(random_bytes(4))) . '-' . strtoupper(bin2hex(random_bytes(5)));
}

function fsgAuth_logout(?PDO $pdo = null): void
{
    if ($pdo) {
        $token = fsgAuth_extractBearerToken();
        if ($token !== '') {
            $stmt = $pdo->prepare('UPDATE FSG_auth_sessions SET is_active = 0, expires_at = UTC_TIMESTAMP() WHERE token_hash = ?');
            $stmt->execute([fsgAuth_tokenHash($token)]);
        }
    }
    fsgAuth_clearCurrentUserSession();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'] ?? '/', $params['domain'] ?? '', (bool)($params['secure'] ?? false), (bool)($params['httponly'] ?? true));
    }
    fsgAuth_clearBearerCookie();
    if (session_status() === PHP_SESSION_ACTIVE) session_destroy();
}
?>
