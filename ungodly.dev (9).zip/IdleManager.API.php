<?php
/**
 * ==============================================================================
 * NAMESPACE: RobinHooleProduction.Idle.API
 * CONTEXT: Idle Manager Data Configurator - Database Serialization Pipeline
 * AUTHOR: BusinessTycoon Web to Engine Architect
 * DESCRIPTION: Armored Database Pipeline. Captures all fatal errors and PDO
 * exceptions. Upgraded to brute-force Linux case-sensitivity pathing.
 * ==============================================================================
 */

declare(strict_types=1);
ini_set('display_errors', '0');
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Auth-Token");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ------------------------------------------------------------------------------
// FATAL ERROR CATCHER: Prevents silent 500 Blank Pages
// ------------------------------------------------------------------------------
register_shutdown_function(function() {
    $err = error_get_last();
    if ($err !== null && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR])) {
        http_response_code(500);
        echo json_encode([
            "status" => "error",
            "message" => "Fatal PHP Execution Crash",
            "details" => "{$err['message']} in {$err['file']} on line {$err['line']}"
        ], JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
    }
});

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' && $_SERVER['REQUEST_METHOD'] !== 'GET') {
        throw new Exception("Strictly GET/POST requests allowed.");
    }

    // ------------------------------------------------------------------------------
    // SECURE CREDENTIAL LOADING (BRUTE-FORCE PATHING FOR LINUX CASE SENSITIVITY)
    // ------------------------------------------------------------------------------
    $possibleCredFiles = [
        __DIR__ . '/_private/databaseCredentials.php',
        __DIR__ . '/_private/databasecredentials.php',
        __DIR__ . '/_Private/databaseCredentials.php',
        __DIR__ . '/private/databaseCredentials.php',
        $_SERVER['DOCUMENT_ROOT'] . '/_private/databaseCredentials.php',
        __DIR__ . '/databaseCredentials.php',
        __DIR__ . '/databaseCredentials (1).php'
    ];
    
    $loaded = false;
    $checkedPaths = [];
    
    foreach ($possibleCredFiles as $f) {
        $checkedPaths[] = $f;
        if (file_exists($f)) {
            require_once $f;
            $loaded = true;
            break;
        }
    }
    
    if (!$loaded) {
        throw new Exception("File missing. Paths checked: " . implode(' | ', $checkedPaths));
    }

    $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    function idle_get_auth_token(): string {
        $headers = function_exists('getallheaders') ? getallheaders() : [];
        $authHeader = '';
        foreach ($headers as $k => $v) {
            if (strtolower((string)$k) === 'authorization') $authHeader = (string)$v;
            if (strtolower((string)$k) === 'x-auth-token' && trim((string)$v) !== '') return trim((string)$v);
        }
        if (preg_match('/Bearer\s+(.+)/i', $authHeader, $m)) return trim($m[1]);
        if (isset($_GET['authToken']) && trim((string)$_GET['authToken']) !== '') return trim((string)$_GET['authToken']);
        return '';
    }

    function idle_resolve_user_id(PDO $pdo): ?int {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            @session_set_cookie_params([
                'lifetime' => 43200,
                'path' => '/',
                'secure' => true,
                'httponly' => true,
                'samesite' => 'Lax'
            ]);
            @session_start();
        }

        foreach (['user_id', 'fsg_user_id', 'auth_user_id'] as $sessionKey) {
            if (isset($_SESSION[$sessionKey]) && intval($_SESSION[$sessionKey]) > 0) {
                return intval($_SESSION[$sessionKey]);
            }
        }

        $token = idle_get_auth_token();
        if ($token === '') return null;
        $hash = hash('sha256', $token);

        try {
            $stmt = $pdo->prepare("
                SELECT user_id
                FROM FSG_auth_sessions
                WHERE token_hash = ?
                  AND (expires_at IS NULL OR expires_at > NOW())
                  AND (revoked_at IS NULL)
                ORDER BY expires_at DESC
                LIMIT 1
            ");
            $stmt->execute([$hash]);
            $row = $stmt->fetch();
            if ($row && intval($row['user_id']) > 0) {
                $touch = $pdo->prepare("UPDATE FSG_auth_sessions SET expires_at = DATE_ADD(NOW(), INTERVAL 12 HOUR) WHERE token_hash = ?");
                $touch->execute([$hash]);
                return intval($row['user_id']);
            }
        } catch (Throwable $ignored) {
            try {
                $stmt = $pdo->prepare("SELECT user_id FROM FSG_auth_sessions WHERE token_hash = ? ORDER BY id DESC LIMIT 1");
                $stmt->execute([$hash]);
                $row = $stmt->fetch();
                if ($row && intval($row['user_id']) > 0) return intval($row['user_id']);
            } catch (Throwable $ignoredAgain) {}
        }

        return null;
    }

    function idle_ensure_aux_tables(PDO $pdo): void {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS FSG_IDLE_app_state (
                state_key VARCHAR(80) NOT NULL PRIMARY KEY,
                state_json LONGTEXT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $pdo->exec("
            CREATE TABLE IF NOT EXISTS FSG_IDLE_server_sessions (
                session_id VARCHAR(128) NOT NULL PRIMARY KEY,
                user_id INT NULL,
                payload_json LONGTEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_user_updated (user_id, updated_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $pdo->exec("
            CREATE TABLE IF NOT EXISTS FSG_Server_Sessions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NULL,
                app_name VARCHAR(80) NOT NULL,
                session_id VARCHAR(128) NOT NULL,
                first_used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_pushed_at TIMESTAMP NULL DEFAULT NULL,
                UNIQUE KEY uniq_user_app_session (user_id, app_name, session_id),
                INDEX idx_user_app_recent (user_id, app_name, last_viewed_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    function idle_default_values(): array {
        return [
            "serverSessionId" => "",
            "availableLanguages" => ["ENG"],
            "currentLanguage" => "ENG",
            "globalTokens" => [],
            "globalCast" => [],
            "globalStates" => [],
            "globalMoods" => [],
            "globalSettings" => [],
            "globalTimesOfDay" => [],
            "globalDaysOfWeek" => [],
            "globalMenuOptions" => [],
            "globalImageSequences" => []
        ];
    }

    function idle_load_values(PDO $pdo): array {
        try {
            $stmt = $pdo->prepare("SELECT state_json FROM FSG_IDLE_app_state WHERE state_key = 'values' LIMIT 1");
            $stmt->execute();
            $row = $stmt->fetch();
            if ($row && !empty($row['state_json'])) {
                $values = json_decode($row['state_json'], true);
                if (is_array($values)) return array_replace_recursive(idle_default_values(), $values);
            }
        } catch (Throwable $ignored) {}
        return idle_default_values();
    }

    function idle_save_values(PDO $pdo, array $values): void {
        $stmt = $pdo->prepare("
            INSERT INTO FSG_IDLE_app_state (state_key, state_json)
            VALUES ('values', ?)
            ON DUPLICATE KEY UPDATE state_json = VALUES(state_json), updated_at = CURRENT_TIMESTAMP
        ");
        $stmt->execute([json_encode(array_replace_recursive(idle_default_values(), $values), JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR)]);
    }

    function idle_record_shared_session(PDO $pdo, ?int $userId, string $sessionId, bool $pushed): void {
        if ($sessionId === '') return;
        try {
            $stmt = $pdo->prepare("
                INSERT INTO FSG_Server_Sessions (user_id, app_name, session_id, last_viewed_at, last_pushed_at)
                VALUES (?, 'IdleManager', ?, CURRENT_TIMESTAMP, " . ($pushed ? "CURRENT_TIMESTAMP" : "NULL") . ")
                ON DUPLICATE KEY UPDATE
                    last_viewed_at = CURRENT_TIMESTAMP,
                    last_pushed_at = " . ($pushed ? "CURRENT_TIMESTAMP" : "last_pushed_at") . "
            ");
            $stmt->execute([$userId, $sessionId]);
        } catch (Throwable $ignored) {}
    }


    function idle_normalize_language_code($value): string {
        $code = strtoupper(trim((string)$value));
        $code = preg_replace('/[^A-Z0-9_-]/', '', $code) ?? '';
        return substr($code, 0, 8);
    }

    function idle_normalize_language_list($list): array {
        $ordered = [];
        $seen = [];
        $add = function($value) use (&$ordered, &$seen) {
            $code = idle_normalize_language_code($value);
            if ($code === '' || isset($seen[$code])) return;
            $seen[$code] = true;
            $ordered[] = $code;
        };
        if (is_array($list)) {
            foreach ($list as $value) $add($value);
        }
        $add('ENG');
        usort($ordered, function($a, $b) {
            if ($a === 'ENG') return -1;
            if ($b === 'ENG') return 1;
            return strcmp($a, $b);
        });
        return $ordered;
    }

    function idle_require_user_id(PDO $pdo): int {
        $userId = idle_resolve_user_id($pdo);
        if (!$userId || $userId <= 0) {
            http_response_code(401);
            echo json_encode([
                'status' => 'error',
                'ok' => false,
                'message' => 'You must be logged in before saving Idle Manager data to the server.'
            ], JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
            exit();
        }
        return (int)$userId;
    }

    function idle_json_text(mixed $value): string {
        return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR) ?: 'null';
    }

    function idle_text_value(mixed $value): string {
        if ($value === null) return '';
        if (is_bool($value)) return $value ? '1' : '0';
        if (is_scalar($value)) return trim((string)$value);
        return idle_json_text($value);
    }

    function idle_normalize_shared_values(array $values): array {
        $defaults = idle_default_values();
        $merged = array_replace_recursive($defaults, $values);
        $merged['availableLanguages'] = idle_normalize_language_list($merged['availableLanguages'] ?? []);
        $merged['currentLanguage'] = idle_normalize_language_code($merged['currentLanguage'] ?? 'ENG') ?: 'ENG';
        if (!in_array($merged['currentLanguage'], $merged['availableLanguages'], true)) $merged['availableLanguages'][] = $merged['currentLanguage'];
        $merged['globalTokens'] = array_values(array_map(function($item) {
            $data = is_array($item) ? $item : ['key' => idle_text_value($item), 'value' => ''];
            return ['key' => idle_text_value($data['key'] ?? ''), 'value' => idle_text_value($data['value'] ?? '')];
        }, is_array($merged['globalTokens'] ?? null) ? $merged['globalTokens'] : []));

        $castSource = is_array($merged['globalCast'] ?? null) ? $merged['globalCast'] : (is_array($merged['cast'] ?? null) ? $merged['cast'] : []);
        $merged['globalCast'] = array_values(array_filter(array_map(function($item) {
            $data = is_array($item) ? $item : ['name' => idle_text_value($item), 'color' => '#00f2ff'];
            $name = idle_text_value($data['name'] ?? $data['character_name'] ?? $data['key'] ?? '');
            return ['name' => $name, 'color' => idle_text_value($data['color'] ?? '#00f2ff') ?: '#00f2ff'];
        }, $castSource), fn($item) => idle_text_value($item['name'] ?? '') !== ''));

        foreach (['globalStates','globalMoods','globalSettings','globalTimesOfDay','globalDaysOfWeek','globalMenuOptions'] as $collection) {
            $merged[$collection] = array_values(array_map(function($item) {
                $data = is_array($item) ? $item : ['name' => idle_text_value($item), 'color' => '#00f2ff'];
                return ['name' => idle_text_value($data['name'] ?? $data['key'] ?? ''), 'color' => idle_text_value($data['color'] ?? '#00f2ff') ?: '#00f2ff'];
            }, is_array($merged[$collection] ?? null) ? $merged[$collection] : []));
        }

        $merged['globalImageSequences'] = array_values(array_map(function($item) {
            $data = is_array($item) ? $item : ['name' => idle_text_value($item), 'images' => []];
            $images = is_array($data['images'] ?? null) ? array_values(array_map('idle_text_value', $data['images'])) : [];
            $path = idle_text_value($data['path'] ?? $data['rootPath'] ?? 'Assets/2D/Sequences/');
            if ($path === '') $path = 'Assets/2D/Sequences/';
            return [
                'name' => idle_text_value($data['name'] ?? ''),
                'color' => idle_text_value($data['color'] ?? '#00f2ff') ?: '#00f2ff',
                'path' => $path,
                'rootPath' => $path,
                'images' => $images,
            ];
        }, is_array($merged['globalImageSequences'] ?? null) ? $merged['globalImageSequences'] : []));

        $merged['serverSessionId'] = idle_text_value($merged['serverSessionId'] ?? '');
        return $merged;
    }

    function idle_fetch_latest_dd_workspace(PDO $pdo, ?int $userId, string $sessionId = ''): ?array {
        $sessionId = trim($sessionId);
        try {
            if ($sessionId !== '') {
                $stmt = $pdo->prepare('SELECT * FROM FSG_DD_Workspaces WHERE session_id = ? ORDER BY id DESC LIMIT 1');
                $stmt->execute([$sessionId]);
                $row = $stmt->fetch();
                if ($row) return $row;
            }
        } catch (Throwable $ignored) {}

        if ($userId && $userId > 0) {
            try {
                $stmt = $pdo->prepare("SELECT w.* FROM FSG_DD_Workspaces w JOIN FSG_DD_UserSessions s ON s.session_id = w.session_id WHERE s.user_id = ? ORDER BY s.last_viewed_at DESC, s.last_pushed_at DESC, w.id DESC LIMIT 1");
                $stmt->execute([$userId]);
                $row = $stmt->fetch();
                if ($row) return $row;
            } catch (Throwable $ignored) {}
            try {
                $stmt = $pdo->prepare('SELECT * FROM FSG_DD_Workspaces WHERE user_id = ? ORDER BY id DESC LIMIT 1');
                $stmt->execute([$userId]);
                $row = $stmt->fetch();
                if ($row) return $row;
            } catch (Throwable $ignored) {}
        }

        try {
            $stmt = $pdo->query('SELECT * FROM FSG_DD_Workspaces ORDER BY id DESC LIMIT 1');
            $row = $stmt ? $stmt->fetch() : null;
            return $row ?: null;
        } catch (Throwable $ignored) {}
        return null;
    }

    function idle_table_exists(PDO $pdo, string $tableName): bool {
        try {
            $stmt = $pdo->query('SHOW TABLES LIKE ' . $pdo->quote($tableName));
            return $stmt && $stmt->rowCount() > 0;
        } catch (Throwable $ignored) {
            return false;
        }
    }

    function idle_load_named_global_table(PDO $pdo, int $workspacePk, string $tableName): array {
        if (!idle_table_exists($pdo, $tableName)) return [];
        $stmt = $pdo->prepare("SELECT item_name, color, raw_json FROM {$tableName} WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC");
        $stmt->execute([$workspacePk]);
        $items = [];
        foreach ($stmt->fetchAll() as $row) {
            $raw = json_decode((string)($row['raw_json'] ?? ''), true);
            if (!is_array($raw)) $raw = [];
            $items[] = [
                'name' => idle_text_value($raw['name'] ?? $row['item_name'] ?? ''),
                'color' => idle_text_value($raw['color'] ?? $row['color'] ?? '#00f2ff') ?: '#00f2ff',
            ];
        }
        return $items;
    }

    function idle_load_dd_globals_from_tables(PDO $pdo, int $workspacePk): array {
        $values = idle_default_values();
        if (idle_table_exists($pdo, 'FSG_DD_Languages')) {
            $langStmt = $pdo->prepare('SELECT language_code FROM FSG_DD_Languages WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC');
            $langStmt->execute([$workspacePk]);
            $languages = array_map(fn($row) => idle_normalize_language_code($row['language_code'] ?? ''), $langStmt->fetchAll());
            $languages = array_values(array_filter($languages));
            if ($languages) $values['availableLanguages'] = idle_normalize_language_list($languages);
        }
        if (idle_table_exists($pdo, 'FSG_DD_GlobalTokens')) {
            $stmt = $pdo->prepare('SELECT token_key, token_value, raw_json FROM FSG_DD_GlobalTokens WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC');
            $stmt->execute([$workspacePk]);
            $values['globalTokens'] = array_map(function($row) {
                $raw = json_decode((string)($row['raw_json'] ?? ''), true);
                if (!is_array($raw)) $raw = [];
                return ['key' => idle_text_value($raw['key'] ?? $row['token_key'] ?? ''), 'value' => idle_text_value($raw['value'] ?? $row['token_value'] ?? '')];
            }, $stmt->fetchAll());
        }
        if (idle_table_exists($pdo, 'FSG_DD_Cast')) {
            $stmt = $pdo->prepare('SELECT character_name, color, raw_json FROM FSG_DD_Cast WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC');
            $stmt->execute([$workspacePk]);
            $values['globalCast'] = array_values(array_filter(array_map(function($row) {
                $raw = json_decode((string)($row['raw_json'] ?? ''), true);
                if (!is_array($raw)) $raw = [];
                $name = idle_text_value($raw['name'] ?? $raw['character_name'] ?? $row['character_name'] ?? '');
                return ['name' => $name, 'color' => idle_text_value($raw['color'] ?? $row['color'] ?? '#00f2ff') ?: '#00f2ff'];
            }, $stmt->fetchAll()), fn($item) => idle_text_value($item['name'] ?? '') !== ''));
        }
        $map = [
            'globalStates' => 'FSG_DD_GlobalStates',
            'globalMoods' => 'FSG_DD_GlobalMoods',
            'globalSettings' => 'FSG_DD_GlobalSettings',
            'globalTimesOfDay' => 'FSG_DD_GlobalTimesOfDay',
            'globalDaysOfWeek' => 'FSG_DD_GlobalDaysOfWeek',
            'globalMenuOptions' => 'FSG_DD_GlobalMenuOptions',
        ];
        foreach ($map as $collection => $tableName) {
            $values[$collection] = idle_load_named_global_table($pdo, $workspacePk, $tableName);
        }
        if (idle_table_exists($pdo, 'FSG_DD_GlobalImageSequences')) {
            $stmt = $pdo->prepare('SELECT id, sequence_name, color, path, raw_json FROM FSG_DD_GlobalImageSequences WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC');
            $stmt->execute([$workspacePk]);
            $seqs = [];
            foreach ($stmt->fetchAll() as $row) {
                $raw = json_decode((string)($row['raw_json'] ?? ''), true);
                if (!is_array($raw)) $raw = [];
                $images = [];
                if (idle_table_exists($pdo, 'FSG_DD_GlobalImageSequenceImages')) {
                    $imgStmt = $pdo->prepare('SELECT image_name FROM FSG_DD_GlobalImageSequenceImages WHERE image_sequence_id = ? ORDER BY sort_order ASC, id ASC');
                    $imgStmt->execute([(int)$row['id']]);
                    $images = array_map(fn($img) => idle_text_value($img['image_name'] ?? ''), $imgStmt->fetchAll());
                }
                if (!$images && is_array($raw['images'] ?? null)) $images = array_values(array_map('idle_text_value', $raw['images']));
                $path = idle_text_value($raw['path'] ?? $row['path'] ?? 'Assets/2D/Sequences/') ?: 'Assets/2D/Sequences/';
                $seqs[] = [
                    'name' => idle_text_value($raw['name'] ?? $row['sequence_name'] ?? ''),
                    'color' => idle_text_value($raw['color'] ?? $row['color'] ?? '#00f2ff') ?: '#00f2ff',
                    'path' => $path,
                    'rootPath' => $path,
                    'images' => $images,
                ];
            }
            $values['globalImageSequences'] = $seqs;
        }
        return idle_normalize_shared_values($values);
    }

    function idle_load_shared_dialogue_values(PDO $pdo, ?int $userId, string $sessionId = ''): array {
        $row = idle_fetch_latest_dd_workspace($pdo, $userId, $sessionId);
        $values = idle_default_values();
        $dialogueSessionId = '';
        $workspacePk = 0;
        if ($row) {
            $workspacePk = (int)($row['id'] ?? 0);
            $dialogueSessionId = idle_text_value($row['session_id'] ?? '');
            $raw = json_decode((string)($row['raw_json'] ?? ''), true);
            if (is_array($raw)) {
                foreach (['globalTokens','globalCast','globalStates','globalMoods','globalSettings','globalTimesOfDay','globalDaysOfWeek','globalMenuOptions','globalImageSequences'] as $key) {
                    if (array_key_exists($key, $raw) && is_array($raw[$key])) $values[$key] = $raw[$key];
                }
                if ((!isset($values['globalCast']) || count($values['globalCast']) === 0) && array_key_exists('cast', $raw) && is_array($raw['cast'])) $values['globalCast'] = $raw['cast'];
                if (array_key_exists('availableLanguages', $raw) && is_array($raw['availableLanguages'])) $values['availableLanguages'] = idle_normalize_language_list($raw['availableLanguages']);
                if (array_key_exists('currentLanguage', $raw)) $values['currentLanguage'] = idle_normalize_language_code($raw['currentLanguage']) ?: 'ENG';
            }
            $workspaceLanguages = [];
            $workspaceLangJson = json_decode((string)($row['available_languages_json'] ?? ''), true);
            if (is_array($workspaceLangJson)) $workspaceLanguages = $workspaceLangJson;
            if ($workspaceLanguages) $values['availableLanguages'] = idle_normalize_language_list($workspaceLanguages);
            if (!empty($row['current_language'])) $values['currentLanguage'] = idle_normalize_language_code($row['current_language']) ?: ($values['currentLanguage'] ?? 'ENG');
            $tableValues = idle_load_dd_globals_from_tables($pdo, $workspacePk);
            foreach ($tableValues as $key => $items) {
                if (!in_array($key, ['serverSessionId', 'currentLanguage'], true) && is_array($items) && count($items) > 0) $values[$key] = $items;
            }
            if (!empty($tableValues['currentLanguage'])) $values['currentLanguage'] = idle_normalize_language_code($tableValues['currentLanguage']) ?: ($values['currentLanguage'] ?? 'ENG');
        }
        $values['serverSessionId'] = $sessionId !== '' ? $sessionId : idle_text_value(idle_load_values($pdo)['serverSessionId'] ?? '');
        return [
            'Values' => idle_normalize_shared_values($values),
            'dialogueSessionId' => $dialogueSessionId,
            'workspaceDatabaseId' => $workspacePk,
        ];
    }

    function idle_replace_named_globals(PDO $pdo, int $workspacePk, string $tableName, array $items): void {
        if (!idle_table_exists($pdo, $tableName)) return;
        $pdo->prepare("DELETE FROM {$tableName} WHERE workspace_id = ?")->execute([$workspacePk]);
        $stmt = $pdo->prepare("INSERT INTO {$tableName} (workspace_id, sort_order, item_name, color, raw_json) VALUES (?, ?, ?, ?, ?)");
        foreach (array_values($items) as $index => $item) {
            $data = is_array($item) ? $item : ['name' => idle_text_value($item), 'color' => '#00f2ff'];
            $stmt->execute([$workspacePk, $index, idle_text_value($data['name'] ?? ''), idle_text_value($data['color'] ?? '#00f2ff'), idle_json_text($data)]);
        }
    }

    function idle_save_shared_dialogue_values(PDO $pdo, array $values, string $sessionId = '', ?int $userId = null): array {
        $values = idle_normalize_shared_values($values);
        $row = idle_fetch_latest_dd_workspace($pdo, $userId, $sessionId);
        if (!$row) {
            idle_save_values($pdo, $values);
            return ['savedToDialogueDesigner' => false, 'message' => 'No Dialogue Designer workspace exists yet. Values were kept in Idle Manager state only.', 'Values' => $values];
        }
        $workspacePk = (int)$row['id'];
        $raw = json_decode((string)($row['raw_json'] ?? ''), true);
        if (!is_array($raw)) $raw = [];
        foreach (['globalTokens','globalCast','globalStates','globalMoods','globalSettings','globalTimesOfDay','globalDaysOfWeek','globalMenuOptions','globalImageSequences'] as $key) {
            $raw[$key] = $values[$key] ?? [];
        }
        $raw['cast'] = $values['globalCast'] ?? [];
        $raw['availableLanguages'] = idle_normalize_language_list($values['availableLanguages'] ?? []);
        $raw['currentLanguage'] = idle_normalize_language_code($values['currentLanguage'] ?? 'ENG') ?: 'ENG';
        $pdo->prepare('UPDATE FSG_DD_Workspaces SET raw_json = ?, current_language = ?, available_languages_json = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([idle_json_text($raw), $raw['currentLanguage'], idle_json_text($raw['availableLanguages']), $workspacePk]);

        if (idle_table_exists($pdo, 'FSG_DD_Languages')) {
            $pdo->prepare('DELETE FROM FSG_DD_Languages WHERE workspace_id = ?')->execute([$workspacePk]);
            $langStmt = $pdo->prepare('INSERT INTO FSG_DD_Languages (workspace_id, language_code, sort_order) VALUES (?, ?, ?)');
            foreach (array_values($raw['availableLanguages']) as $index => $languageCode) {
                $code = idle_normalize_language_code($languageCode);
                if ($code !== '') $langStmt->execute([$workspacePk, $code, $index]);
            }
        }

        if (idle_table_exists($pdo, 'FSG_DD_GlobalTokens')) {
            $pdo->prepare('DELETE FROM FSG_DD_GlobalTokens WHERE workspace_id = ?')->execute([$workspacePk]);
            $stmt = $pdo->prepare('INSERT INTO FSG_DD_GlobalTokens (workspace_id, sort_order, token_key, token_value, raw_json) VALUES (?, ?, ?, ?, ?)');
            foreach (array_values($values['globalTokens'] ?? []) as $index => $item) {
                $stmt->execute([$workspacePk, $index, idle_text_value($item['key'] ?? ''), idle_text_value($item['value'] ?? ''), idle_json_text($item)]);
            }
        }

        if (idle_table_exists($pdo, 'FSG_DD_Cast')) {
            $pdo->prepare('DELETE FROM FSG_DD_Cast WHERE workspace_id = ?')->execute([$workspacePk]);
            $stmt = $pdo->prepare('INSERT INTO FSG_DD_Cast (workspace_id, sort_order, character_name, color, raw_json) VALUES (?, ?, ?, ?, ?)');
            foreach (array_values($values['globalCast'] ?? []) as $index => $item) {
                $data = is_array($item) ? $item : ['name' => idle_text_value($item), 'color' => '#00f2ff'];
                $name = idle_text_value($data['name'] ?? $data['character_name'] ?? $data['key'] ?? '');
                if ($name === '') continue;
                $normalizedCastItem = ['name' => $name, 'color' => idle_text_value($data['color'] ?? '#00f2ff') ?: '#00f2ff'];
                $stmt->execute([$workspacePk, $index, $normalizedCastItem['name'], $normalizedCastItem['color'], idle_json_text($normalizedCastItem)]);
            }
        }

        $namedMap = [
            'globalStates' => 'FSG_DD_GlobalStates',
            'globalMoods' => 'FSG_DD_GlobalMoods',
            'globalSettings' => 'FSG_DD_GlobalSettings',
            'globalTimesOfDay' => 'FSG_DD_GlobalTimesOfDay',
            'globalDaysOfWeek' => 'FSG_DD_GlobalDaysOfWeek',
            'globalMenuOptions' => 'FSG_DD_GlobalMenuOptions',
        ];
        foreach ($namedMap as $collection => $tableName) {
            idle_replace_named_globals($pdo, $workspacePk, $tableName, $values[$collection] ?? []);
        }

        if (idle_table_exists($pdo, 'FSG_DD_GlobalImageSequences')) {
            if (idle_table_exists($pdo, 'FSG_DD_GlobalImageSequenceImages')) {
                $idsStmt = $pdo->prepare('SELECT id FROM FSG_DD_GlobalImageSequences WHERE workspace_id = ?');
                $idsStmt->execute([$workspacePk]);
                $ids = array_map(fn($r) => (int)$r['id'], $idsStmt->fetchAll());
                if ($ids) {
                    $placeholders = implode(',', array_fill(0, count($ids), '?'));
                    $pdo->prepare("DELETE FROM FSG_DD_GlobalImageSequenceImages WHERE image_sequence_id IN ({$placeholders})")->execute($ids);
                }
            }
            $pdo->prepare('DELETE FROM FSG_DD_GlobalImageSequences WHERE workspace_id = ?')->execute([$workspacePk]);
            $seqStmt = $pdo->prepare('INSERT INTO FSG_DD_GlobalImageSequences (workspace_id, sort_order, sequence_name, color, path, raw_json) VALUES (?, ?, ?, ?, ?, ?)');
            $imgStmt = idle_table_exists($pdo, 'FSG_DD_GlobalImageSequenceImages') ? $pdo->prepare('INSERT INTO FSG_DD_GlobalImageSequenceImages (image_sequence_id, sort_order, image_name) VALUES (?, ?, ?)') : null;
            foreach (array_values($values['globalImageSequences'] ?? []) as $index => $seq) {
                $seqStmt->execute([$workspacePk, $index, idle_text_value($seq['name'] ?? ''), idle_text_value($seq['color'] ?? '#00f2ff'), idle_text_value($seq['path'] ?? $seq['rootPath'] ?? 'Assets/2D/Sequences/'), idle_json_text($seq)]);
                $seqId = (int)$pdo->lastInsertId();
                if ($imgStmt) {
                    foreach (array_values(is_array($seq['images'] ?? null) ? $seq['images'] : []) as $imgIndex => $imageName) {
                        $imgStmt->execute([$seqId, $imgIndex, idle_text_value($imageName)]);
                    }
                }
            }
        }

        idle_save_values($pdo, $values);
        return ['savedToDialogueDesigner' => true, 'workspaceDatabaseId' => $workspacePk, 'dialogueSessionId' => idle_text_value($row['session_id'] ?? ''), 'Values' => $values];
    }

    idle_ensure_aux_tables($pdo);

    $action = trim((string)($_GET['action'] ?? ''));
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'health') {
        echo json_encode(['status' => 'success', 'ok' => true, 'app' => 'IdleManager'], JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
        exit();
    }
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'loadSharedDialogueValues') {
        $userId = idle_resolve_user_id($pdo);
        $sessionId = trim((string)($_GET['sessionId'] ?? ''));
        $result = idle_load_shared_dialogue_values($pdo, $userId, $sessionId);
        echo json_encode(['status' => 'success', 'ok' => true] + $result, JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
        exit();
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'saveSharedDialogueValues') {
        $payload = json_decode(file_get_contents('php://input'), true);
        if (!is_array($payload)) $payload = [];
        $values = is_array($payload['Values'] ?? null) ? $payload['Values'] : idle_default_values();
        $sessionId = trim((string)($_GET['sessionId'] ?? ($values['serverSessionId'] ?? '')));
        $userId = idle_require_user_id($pdo);
        $result = idle_save_shared_dialogue_values($pdo, $values, $sessionId, $userId);
        echo json_encode(['status' => 'success', 'ok' => true] + $result, JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
        exit();
    }
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'loadSession') {
        $sessionId = trim((string)($_GET['sessionId'] ?? ''));
        if ($sessionId === '') throw new Exception('Session ID is required.');
        $stmt = $pdo->prepare('SELECT payload_json FROM FSG_IDLE_server_sessions WHERE session_id = ? ORDER BY updated_at DESC LIMIT 1');
        $stmt->execute([$sessionId]);
        $row = $stmt->fetch();
        if (!$row) throw new Exception('Idle Manager session was not found.');
        $data = json_decode((string)$row['payload_json'], true);
        if (!is_array($data)) throw new Exception('Saved Idle Manager session payload was not valid JSON.');
        echo json_encode($data, JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
        exit();
    }

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {

        
        $stmtBiz = $pdo->query("SELECT * FROM FSG_IDLE_business_configs");
        $businesses = $stmtBiz->fetchAll();

        $stmtMgr = $pdo->query("SELECT * FROM FSG_IDLE_managers");
        $managers = $stmtMgr->fetchAll();
        $mgrMap = [];
        foreach ($managers as $m) {
            $m['useAutomation'] = (bool)$m['useAutomation'];
            $m['enableCostDiscount'] = (bool)$m['enableCostDiscount'];
            $m['useClickModifier'] = (bool)$m['useClickModifier'];
            $m['useOfflineProfitModifier'] = (bool)$m['useOfflineProfitModifier'];
            $m['calledExternally'] = (bool)$m['calledExternally'];
            $m['makeExternalCall'] = (bool)$m['makeExternalCall'];
            
            $m['managerCost'] = (float)$m['managerCost'];
            $m['costDiscountMultiplier'] = (float)$m['costDiscountMultiplier'];
            $m['clickStrength'] = (float)$m['clickStrength'];
            $m['offlineProfitMultiplier'] = (float)$m['offlineProfitMultiplier'];
            
            $m['managerIcon'] = json_decode($m['managerIcon'] ?? '{}', true);
            $m['conditions'] = json_decode($m['conditions'] ?? '[]', true);
            $m['changeStates'] = json_decode($m['changeStates'] ?? '[]', true);

            $mgrMap[$m['business_id']][] = $m;
        }

        $stmtUpg = $pdo->query("SELECT * FROM FSG_IDLE_upgrades");
        $upgrades = $stmtUpg->fetchAll();
        $upgMap = [];
        foreach ($upgrades as $u) {
            $u['useProfitMultiplier'] = (bool)$u['useProfitMultiplier'];
            $u['modifiesTime'] = (bool)$u['modifiesTime'];
            $u['useClickStrengthModifier'] = (bool)$u['useClickStrengthModifier'];
            $u['modifyOfflineProfit'] = (bool)$u['modifyOfflineProfit'];
            $u['calledExternally'] = (bool)$u['calledExternally'];
            $u['makeExternalCall'] = (bool)$u['makeExternalCall'];
            
            $u['upgradeCost'] = (float)$u['upgradeCost'];
            $u['profitMultiplier'] = (float)$u['profitMultiplier'];
            $u['timeMultiplier'] = (float)$u['timeMultiplier'];
            $u['targetType'] = (int)$u['targetType'];
            $u['clickStrengthAmount'] = (float)$u['clickStrengthAmount'];
            $u['offlineModifier'] = (float)$u['offlineModifier'];

            $u['specificBusinessIds'] = json_decode($u['specificBusinessIds'] ?? '[]', true);
            $u['upgradeIcon'] = json_decode($u['upgradeIcon'] ?? '{}', true);
            $u['conditions'] = json_decode($u['conditions'] ?? '[]', true);
            $u['changeStates'] = json_decode($u['changeStates'] ?? '[]', true);

            $upgMap[$u['business_id']][] = $u;
        }

        $Configurations = [];
        foreach ($businesses as $b) {
            $b['contextParent'] = (int)$b['contextParent'];
            $b['Id'] = (int)$b['Id'];
            $b['TimerDivision'] = (int)$b['TimerDivision'];
            $b['calledExternally'] = (bool)$b['calledExternally'];
            $b['makeExternalCall'] = (bool)$b['makeExternalCall'];
            
            $b['BaseCost'] = (float)$b['BaseCost'];
            $b['BaseProfit'] = (float)$b['BaseProfit'];
            $b['TimerInSeconds'] = (float)$b['TimerInSeconds'];
            $b['CostMultiplier'] = (float)$b['CostMultiplier'];
            
            $b['identityColor'] = json_decode($b['identityColor'] ?? '{"r":0,"g":1,"b":1,"a":1}', true);
            $b['regularColor'] = json_decode($b['regularColor'] ?? '{"r":0,"g":0,"b":0,"a":1}', true);
            $b['highlightColor'] = json_decode($b['highlightColor'] ?? '{"r":1,"g":0.5,"b":0,"a":1}', true);
            $b['darkColor'] = json_decode($b['darkColor'] ?? '{"r":0,"g":0,"b":0,"a":1}', true);
            
            $b['conditions'] = json_decode($b['conditions'] ?? '[]', true);
            $b['changeStates'] = json_decode($b['changeStates'] ?? '[]', true);
            $b['spriteSettings'] = json_decode($b['spriteSettings'] ?? '[]', true);

            $b['Managers'] = $mgrMap[$b['nodeId']] ?? [];
            $b['Upgrades'] = $upgMap[$b['nodeId']] ?? [];

            $Configurations[] = $b;
        }

        $stmtDir = $pdo->query("SELECT * FROM FSG_IDLE_sprite_directories");
        $dirs = $stmtDir->fetchAll();
        
        $stmtSpr = $pdo->query("SELECT * FROM FSG_IDLE_sprites");
        $sprs = $stmtSpr->fetchAll();
        $sprMap = [];
        foreach ($sprs as $s) {
            $sprMap[$s['directory_id']][] = ["name" => $s['name'], "file" => $s['file']];
        }

        $Sprites = [];
        foreach ($dirs as $d) {
            $d['expanded'] = (bool)$d['expanded'];
            $d['isSprite'] = (bool)$d['isSprite'];
            $d['sprites'] = $sprMap[$d['id']] ?? [];
            $Sprites[] = $d;
        }

        $userId = idle_resolve_user_id($pdo);
        $sharedValuesResult = idle_load_shared_dialogue_values($pdo, $userId, trim((string)($_GET['sessionId'] ?? '')));
        $Values = $sharedValuesResult['Values'] ?? idle_load_values($pdo);

        echo json_encode(
            ["Configurations" => $Configurations, "Sprites" => $Sprites, "Values" => $Values, "sharedDialogueSessionId" => ($sharedValuesResult['dialogueSessionId'] ?? '')],
            JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR
        );
        exit();

    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        
        $userId = idle_require_user_id($pdo);
        $jsonPayload = file_get_contents('php://input');
        $payload = json_decode($jsonPayload, true);

        if (!$payload || !isset($payload['Configurations'])) {
            throw new Exception("Structural integrity check failed. Unreadable JSON Payload.");
        }

        $pdo->beginTransaction();

        $pdo->exec("DELETE FROM FSG_IDLE_business_configs");
        $pdo->exec("DELETE FROM FSG_IDLE_sprite_directories");

        $stmtBiz = $pdo->prepare("
            INSERT INTO FSG_IDLE_business_configs 
            (nodeId, contextParent, Id, Name, businessMode, flavorText, BaseCost, BaseProfit, TimerInSeconds, CostMultiplier, TimerDivision, identityColor, regularColor, highlightColor, darkColor, calledExternally, makeExternalCall, conditions, changeStates, spriteSettings) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmtMgr = $pdo->prepare("
            INSERT INTO FSG_IDLE_managers 
            (nodeId, business_id, managerName, managerCost, managerDesc, useAutomation, enableCostDiscount, costDiscountMultiplier, costDiscountDescription, useClickModifier, clickStrength, clickStrengthDescription, useOfflineProfitModifier, offlineProfitMultiplier, offlineProfitDescription, managerIcon, conditions, changeStates, calledExternally, makeExternalCall) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmtUpg = $pdo->prepare("
            INSERT INTO FSG_IDLE_upgrades 
            (nodeId, business_id, upgradeName, upgradeCost, upgradeDesc, profitDescription, useProfitMultiplier, profitMultiplier, modifiesTime, timeMultiplier, timeDescription, targetType, targetScope, specificTargetId, specificBusinessIds, useClickStrengthModifier, clickStrengthAmount, clickStrengthDescription, modifyOfflineProfit, offlineModifier, offlineDescription, upgradeIcon, conditions, changeStates, calledExternally, makeExternalCall) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        foreach ($payload['Configurations'] as $biz) {
            $stmtBiz->execute([
                $biz['nodeId'] ?? uniqid(),
                (int)($biz['contextParent'] ?? 0),
                (int)($biz['Id'] ?? 1),
                $biz['Name'] ?? 'Unnamed Business',
                (($biz['businessMode'] ?? 'instance') === 'unique') ? 'unique' : 'instance',
                $biz['flavorText'] ?? '',
                (float)($biz['BaseCost'] ?? 10),
                (float)($biz['BaseProfit'] ?? 1),
                (float)($biz['TimerInSeconds'] ?? 1),
                (float)($biz['CostMultiplier'] ?? 1.07),
                (int)($biz['TimerDivision'] ?? 25),
                json_encode($biz['identityColor'] ?? []),
                json_encode($biz['regularColor'] ?? []),
                json_encode($biz['highlightColor'] ?? []),
                json_encode($biz['darkColor'] ?? []),
                (int)($biz['calledExternally'] ?? 0),
                (int)($biz['makeExternalCall'] ?? 0),
                json_encode($biz['conditions'] ?? []),
                json_encode($biz['changeStates'] ?? []),
                json_encode($biz['spriteSettings'] ?? [])
            ]);

            if (isset($biz['Managers']) && is_array($biz['Managers'])) {
                foreach ($biz['Managers'] as $m) {
                    $stmtMgr->execute([
                        $m['nodeId'] ?? uniqid(),
                        $biz['nodeId'],
                        $m['managerName'] ?? 'New Manager',
                        (float)($m['managerCost'] ?? 1000),
                        $m['managerDesc'] ?? '',
                        (int)($m['useAutomation'] ?? 0),
                        (int)($m['enableCostDiscount'] ?? 0),
                        (float)($m['costDiscountMultiplier'] ?? 0),
                        $m['costDiscountDescription'] ?? '',
                        (int)($m['useClickModifier'] ?? 0),
                        (float)($m['clickStrength'] ?? 0),
                        $m['clickStrengthDescription'] ?? '',
                        (int)($m['useOfflineProfitModifier'] ?? 0),
                        (float)($m['offlineProfitMultiplier'] ?? 1.05),
                        $m['offlineProfitDescription'] ?? '',
                        json_encode($m['managerIcon'] ?? []),
                        json_encode($m['conditions'] ?? []),
                        json_encode($m['changeStates'] ?? []),
                        (int)($m['calledExternally'] ?? 0),
                        (int)($m['makeExternalCall'] ?? 0)
                    ]);
                }
            }

            if (isset($biz['Upgrades']) && is_array($biz['Upgrades'])) {
                foreach ($biz['Upgrades'] as $u) {
                    $stmtUpg->execute([
                        $u['nodeId'] ?? uniqid(),
                        $biz['nodeId'],
                        $u['upgradeName'] ?? 'New Upgrade',
                        (float)($u['upgradeCost'] ?? 100),
                        $u['upgradeDesc'] ?? '',
                        $u['profitDescription'] ?? '',
                        (int)($u['useProfitMultiplier'] ?? 1),
                        (float)($u['profitMultiplier'] ?? 2),
                        (int)($u['modifiesTime'] ?? 0),
                        (float)($u['timeMultiplier'] ?? 1),
                        $u['timeDescription'] ?? '',
                        (int)($u['targetType'] ?? 0),
                        $u['targetScope'] ?? 'local',
                        $u['specificTargetId'] ?? '',
                        json_encode($u['specificBusinessIds'] ?? []),
                        (int)($u['useClickStrengthModifier'] ?? 0),
                        (float)($u['clickStrengthAmount'] ?? 0),
                        $u['clickStrengthDescription'] ?? '',
                        (int)($u['modifyOfflineProfit'] ?? 0),
                        (float)($u['offlineModifier'] ?? 1),
                        $u['offlineDescription'] ?? '',
                        json_encode($u['upgradeIcon'] ?? []),
                        json_encode($u['conditions'] ?? []),
                        json_encode($u['changeStates'] ?? []),
                        (int)($u['calledExternally'] ?? 0),
                        (int)($u['makeExternalCall'] ?? 0)
                    ]);
                }
            }
        }

        if (isset($payload['Sprites']) && is_array($payload['Sprites'])) {
            $stmtDir = $pdo->prepare("
                INSERT INTO FSG_IDLE_sprite_directories 
                (id, name, rootPath, identityColor, expanded, isSprite) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");

            $stmtSprite = $pdo->prepare("
                INSERT INTO FSG_IDLE_sprites 
                (directory_id, name, file) 
                VALUES (?, ?, ?)
            ");

            foreach ($payload['Sprites'] as $dir) {
                $dirId = $dir['id'] ?? uniqid();
                $stmtDir->execute([
                    $dirId,
                    $dir['name'] ?? 'Unnamed Directory',
                    $dir['rootPath'] ?? '',
                    $dir['identityColor'] ?? '#ffffff',
                    (int)($dir['expanded'] ?? 1),
                    (int)($dir['isSprite'] ?? 1)
                ]);

                if (isset($dir['sprites']) && is_array($dir['sprites'])) {
                    foreach ($dir['sprites'] as $sprite) {
                        $stmtSprite->execute([
                            $dirId,
                            $sprite['name'] ?? 'Unnamed Sprite',
                            $sprite['file'] ?? ''
                        ]);
                    }
                }
            }
        }

        $valuesPayload = isset($payload['Values']) && is_array($payload['Values']) ? $payload['Values'] : idle_default_values();
        $sessionId = trim((string)($_GET['sessionId'] ?? ($valuesPayload['serverSessionId'] ?? '')));
        if ($sessionId === '') {
            $sessionId = 'IDLE-' . strtoupper(bin2hex(random_bytes(3))) . '-' . strtoupper(substr(dechex(time()), -8));
            $valuesPayload['serverSessionId'] = $sessionId;
        }

        idle_save_values($pdo, $valuesPayload);

        try { idle_save_shared_dialogue_values($pdo, $valuesPayload, $sessionId, $userId); } catch (Throwable $ignoredSharedValuesSave) {}
        $payload['Values'] = array_replace_recursive(idle_default_values(), $valuesPayload);

        $stmtSavedSession = $pdo->prepare("
            INSERT INTO FSG_IDLE_server_sessions (session_id, user_id, payload_json)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE
                user_id = VALUES(user_id),
                payload_json = VALUES(payload_json),
                updated_at = CURRENT_TIMESTAMP
        ");
        $stmtSavedSession->execute([
            $sessionId,
            $userId,
            json_encode($payload, JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR)
        ]);

        idle_record_shared_session($pdo, $userId, $sessionId, true);

        $pdo->commit();

        echo json_encode([
            "status" => "success",
            "message" => "Data serialization matrix securely committed to schema.",
            "sessionId" => $sessionId,
            "userId" => $userId
        ], JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
        exit();
    }

} catch (\Throwable $e) { // Captures ALL Exceptions and System Fatal Errors
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Architectural failure during database operations.",
        "details" => $e->getMessage(),
        "file" => $e->getFile(),
        "line" => $e->getLine()
    ], JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit();
}
?>