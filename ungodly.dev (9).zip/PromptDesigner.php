<?php
declare(strict_types=1);
ini_set('display_errors', '0');
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Auth-Token');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
$authPath = __DIR__ . '/_private/AuthShared.php';
if (is_file($authPath)) require_once $authPath;
if (function_exists('fsgAuth_startSharedSession')) fsgAuth_startSharedSession();
elseif (session_status() !== PHP_SESSION_ACTIVE) session_start();
function pd_json(array $payload, int $code = 200): void { http_response_code($code); echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR); exit; }
function pd_text(mixed $value): string { if ($value === null) return ''; if (is_bool($value)) return $value ? '1' : '0'; if (is_scalar($value)) return (string)$value; return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: ''; }
function pd_body(): array { if (function_exists('fsgAuth_requestBody')) return fsgAuth_requestBody(); $raw = file_get_contents('php://input'); if ($raw === false || trim($raw) === '') return []; $data = json_decode($raw, true); return is_array($data) ? $data : []; }
function pd_pdo(): PDO { if (function_exists('fsgAuth_dbConnection')) return fsgAuth_dbConnection(); $path = __DIR__ . '/_private/databaseCredentials.php'; if (!is_file($path)) pd_json(['ok'=>false,'error'=>'Missing _private/databaseCredentials.php'], 500); require $path; return new PDO("mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4", $dbUser, $dbPass, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]); }
function pd_user(PDO $pdo): int { try { if (function_exists('fsgAuth_ensureAccountTables')) fsgAuth_ensureAccountTables($pdo); if (function_exists('fsgAuth_currentUserIdFromRequest')) return (int)fsgAuth_currentUserIdFromRequest($pdo); } catch (Throwable $e) {} return (int)($_SESSION['fsg_user_id'] ?? $_SESSION['user_id'] ?? 0); }
function pd_table(PDO $pdo, string $table): bool { try { $stmt=$pdo->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?'); $stmt->execute([$table]); return ((int)$stmt->fetchColumn()) > 0; } catch (Throwable $e) { return false; } }
function pd_col(PDO $pdo, string $table, string $col): bool { try { $stmt=$pdo->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?'); $stmt->execute([$table,$col]); return ((int)$stmt->fetchColumn()) > 0; } catch (Throwable $e) { return false; } }
function pd_ensure(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_PD_server_sessions (session_id VARCHAR(128) NOT NULL, user_id INT NULL, dialogue_session_id VARCHAR(128) NULL, payload_json LONGTEXT NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY(session_id), KEY idx_pd_user_updated(user_id, updated_at), KEY idx_pd_dialogue(dialogue_session_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_PD_Tags (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, session_id VARCHAR(128) NOT NULL, sort_order INT NOT NULL DEFAULT 0, tag_name VARCHAR(255) NOT NULL, color VARCHAR(32) NOT NULL DEFAULT '#00f2ff', raw_json LONGTEXT NULL, PRIMARY KEY(id), KEY idx_pd_tags_session(session_id, sort_order)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_PD_PositionTypes (id VARCHAR(96) NOT NULL, session_id VARCHAR(128) NOT NULL, sort_order INT NOT NULL DEFAULT 0, type_name VARCHAR(255) NOT NULL, collapsed TINYINT(1) NOT NULL DEFAULT 0, raw_json LONGTEXT NULL, PRIMARY KEY(id), KEY idx_pd_pos_type_session(session_id, sort_order)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_PD_GlobalFrames (id VARCHAR(96) NOT NULL, session_id VARCHAR(128) NOT NULL, sort_order INT NOT NULL DEFAULT 0, frame_name VARCHAR(255) NOT NULL, color VARCHAR(32) NOT NULL DEFAULT '#00f2ff', raw_json LONGTEXT NULL, PRIMARY KEY(id), KEY idx_pd_frames_session(session_id, sort_order)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_PD_Prompts (id VARCHAR(96) NOT NULL, session_id VARCHAR(128) NOT NULL, tag_name VARCHAR(255) NOT NULL DEFAULT '', sort_order INT NOT NULL DEFAULT 0, title VARCHAR(255) NOT NULL DEFAULT '', raw_json LONGTEXT NOT NULL, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY(id), KEY idx_pd_prompts_session(session_id, sort_order), KEY idx_pd_prompts_tag(tag_name)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_PD_PromptAdvanced (session_id VARCHAR(128) NOT NULL, prompt_id VARCHAR(96) NOT NULL, advanced_json LONGTEXT NULL, conditions_json LONGTEXT NULL, state_changes_json LONGTEXT NULL, triggers_json LONGTEXT NULL, visual_payloads_json LONGTEXT NULL, frames_json LONGTEXT NULL, window_json LONGTEXT NULL, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY(session_id, prompt_id), KEY idx_pd_prompt_adv_prompt(prompt_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_PD_ResponseAdvanced (session_id VARCHAR(128) NOT NULL, prompt_id VARCHAR(96) NOT NULL, response_id VARCHAR(96) NOT NULL, sort_order INT NOT NULL DEFAULT 0, response_text TEXT NULL, voice_line TINYINT(1) NOT NULL DEFAULT 0, called_externally TINYINT(1) NOT NULL DEFAULT 0, externally_call TINYINT(1) NOT NULL DEFAULT 0, collapsed TINYINT(1) NOT NULL DEFAULT 0, conditions_json LONGTEXT NULL, state_changes_json LONGTEXT NULL, advanced_json LONGTEXT NULL, translations_json LONGTEXT NULL, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY(session_id, response_id), KEY idx_pd_resp_adv_prompt(session_id, prompt_id, sort_order)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}
function pd_default(): array { return ['version'=>'PromptDesigner','serverSessionId'=>'','dialogueSessionId'=>'','availableLanguages'=>['ENG'],'currentLanguage'=>'ENG','tokens'=>[],'tags'=>[['name'=>'News Alert','color'=>'#00f2ff'],['name'=>'Advertisement','color'=>'#ff8c00'],['name'=>'Dev Message','color'=>'#ff007b']],'positionTypes'=>[],'prompts'=>[],'globalCast'=>[],'globalStates'=>[],'globalMoods'=>[],'globalSettings'=>[],'timesOfDay'=>[],'daysOfWeek'=>[],'menuOptions'=>[],'imageSequences'=>[],'globalFrames'=>[]]; }
function pd_decode(string $json = ''): array { $data = json_decode($json, true); return is_array($data) ? $data : []; }
function pd_latest_pd_session(PDO $pdo, int $userId): string { if ($userId <= 0) return ''; if (pd_table($pdo,'FSG_PD_server_sessions')) { $stmt=$pdo->prepare('SELECT session_id FROM FSG_PD_server_sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1'); $stmt->execute([$userId]); $sid=trim(pd_text($stmt->fetchColumn() ?: '')); if ($sid !== '') return $sid; } try { if (function_exists('fsgAuth_listUserSessions')) { foreach (fsgAuth_listUserSessions($pdo,$userId,'PromptDesigner') as $row) { $sid=trim(pd_text($row['session_id'] ?? '')); if ($sid !== '') return $sid; } } } catch (Throwable $e) {} return ''; }
function pd_account_sessions(PDO $pdo, int $userId): array { if ($userId <= 0) return []; $out=[]; if (pd_table($pdo,'FSG_PD_server_sessions')) { $stmt=$pdo->prepare('SELECT session_id, created_at AS first_pushed_at, updated_at AS last_pushed_at, updated_at AS last_viewed_at, 1 AS workspace_count FROM FSG_PD_server_sessions WHERE user_id = ? ORDER BY updated_at DESC'); $stmt->execute([$userId]); foreach ($stmt->fetchAll() as $r) $out[$r['session_id']]=$r; } try { if (function_exists('fsgAuth_listUserSessions')) foreach (fsgAuth_listUserSessions($pdo,$userId,'PromptDesigner') as $r) { $sid=trim(pd_text($r['session_id'] ?? '')); if ($sid !== '' && !isset($out[$sid])) $out[$sid]=$r; } } catch (Throwable $e) {} return array_values($out); }
function pd_auth_payload(PDO $pdo, int $userId): array { if ($userId <= 0) return ['loggedIn'=>false,'user'=>null,'sessions'=>[]]; $user=null; try { if (pd_table($pdo,'FSG_users')) { $s=$pdo->prepare('SELECT id, username, email FROM FSG_users WHERE id = ? LIMIT 1'); $s->execute([$userId]); $row=$s->fetch(); if ($row) $user=['id'=>(int)$row['id'],'username'=>$row['username'] ?? '', 'email'=>$row['email'] ?? '']; } } catch (Throwable $e) {} return ['loggedIn'=>true,'user'=>$user,'sessions'=>pd_account_sessions($pdo,$userId)]; }
function pd_latest_dd_session(PDO $pdo, int $userId, string $preferred = ''): string { $preferred=trim($preferred); if ($preferred !== '') return $preferred; try { if ($userId > 0 && function_exists('fsgAuth_listUserSessions')) foreach (fsgAuth_listUserSessions($pdo,$userId,'DialogueDesigner') as $row) { $sid=trim(pd_text($row['session_id'] ?? '')); if ($sid !== '') return $sid; } } catch (Throwable $e) {} if ($userId > 0 && pd_table($pdo,'FSG_DD_UserSessions')) { $stmt=$pdo->prepare('SELECT session_id FROM FSG_DD_UserSessions WHERE user_id = ? ORDER BY last_viewed_at DESC, last_pushed_at DESC, id DESC LIMIT 1'); $stmt->execute([$userId]); $sid=trim(pd_text($stmt->fetchColumn() ?: '')); if ($sid !== '') return $sid; } if (pd_table($pdo,'FSG_DD_Workspaces')) { $stmt=$pdo->query('SELECT session_id FROM FSG_DD_Workspaces ORDER BY id DESC LIMIT 1'); return trim(pd_text($stmt->fetchColumn() ?: '')); } return ''; }
function pd_load_dd_workspace(PDO $pdo, string $sid): array { if (!pd_table($pdo,'FSG_DD_Workspaces')) return []; if ($sid !== '') { $stmt=$pdo->prepare('SELECT id, raw_json, session_id FROM FSG_DD_Workspaces WHERE session_id = ? ORDER BY id DESC LIMIT 1'); $stmt->execute([$sid]); } else { $stmt=$pdo->query('SELECT id, raw_json, session_id FROM FSG_DD_Workspaces ORDER BY id DESC LIMIT 1'); } $row=$stmt->fetch(); if (!$row) return []; $data=pd_decode(pd_text($row['raw_json'] ?? '')); if (!empty($row['session_id'])) $data['__sessionId']=$row['session_id']; if (!empty($row['id'])) $data['__workspaceDbId']=(int)$row['id']; return $data; }
function pd_raw_or_named(array $row, string $nameCol, string $defaultColor = '#00f2ff'): array { $raw=pd_decode(pd_text($row['raw_json'] ?? '')); if (!$raw) $raw=[]; $name=pd_text($raw['name'] ?? $raw['character_name'] ?? $row[$nameCol] ?? ''); $color=pd_text($raw['color'] ?? $row['color'] ?? $defaultColor); $raw['name']=$name; if ($color!=='') $raw['color']=$color; if (isset($row['id']) && !isset($raw['id'])) $raw['id']=pd_text($row['id']); return $raw; }
function pd_load_dd_shared_tables(PDO $pdo, array $payload, array $dd): array { $workspaceId=(int)($dd['__workspaceDbId'] ?? 0); if ($workspaceId <= 0) return $payload; try { if (pd_table($pdo,'FSG_DD_Languages')) { $stmt=$pdo->prepare('SELECT language_code FROM FSG_DD_Languages WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC'); $stmt->execute([$workspaceId]); $langs=[]; foreach ($stmt->fetchAll() as $row) { $l=strtoupper(trim(pd_text($row['language_code'] ?? ''))); if ($l!=='' && !in_array($l,$langs,true)) $langs[]=$l; } if ($langs) $payload['availableLanguages']=$langs; } if (pd_table($pdo,'FSG_DD_GlobalTokens')) { $stmt=$pdo->prepare('SELECT token_key, token_value, raw_json FROM FSG_DD_GlobalTokens WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC'); $stmt->execute([$workspaceId]); $items=[]; foreach ($stmt->fetchAll() as $row) { $raw=pd_decode(pd_text($row['raw_json'] ?? '')); $items[]=['key'=>pd_text($raw['key'] ?? $row['token_key'] ?? ''), 'value'=>pd_text($raw['value'] ?? $row['token_value'] ?? '')]; } $payload['tokens']=$items; } if (pd_table($pdo,'FSG_DD_Cast')) { $stmt=$pdo->prepare('SELECT id, character_name, color, raw_json FROM FSG_DD_Cast WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC'); $stmt->execute([$workspaceId]); $payload['globalCast']=array_map(fn($r)=>pd_raw_or_named($r,'character_name'),$stmt->fetchAll()); } $named=['globalStates'=>'FSG_DD_GlobalStates','globalMoods'=>'FSG_DD_GlobalMoods','globalSettings'=>'FSG_DD_GlobalSettings','timesOfDay'=>'FSG_DD_GlobalTimesOfDay','daysOfWeek'=>'FSG_DD_GlobalDaysOfWeek','menuOptions'=>'FSG_DD_GlobalMenuOptions']; foreach ($named as $key=>$table) { if (!pd_table($pdo,$table)) continue; $stmt=$pdo->prepare("SELECT id, item_name, color, raw_json FROM {$table} WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC"); $stmt->execute([$workspaceId]); $payload[$key]=array_map(fn($r)=>pd_raw_or_named($r,'item_name'),$stmt->fetchAll()); } if (pd_table($pdo,'FSG_DD_GlobalImageSequences')) { $stmt=$pdo->prepare('SELECT id, sequence_name, color, path, raw_json FROM FSG_DD_GlobalImageSequences WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC'); $stmt->execute([$workspaceId]); $seqs=[]; foreach ($stmt->fetchAll() as $row) { $raw=pd_raw_or_named($row,'sequence_name'); $raw['path']=pd_text($raw['path'] ?? $row['path'] ?? ''); $raw['images']=is_array($raw['images'] ?? null) ? $raw['images'] : []; if (pd_table($pdo,'FSG_DD_GlobalImageSequenceImages')) { $img=$pdo->prepare('SELECT image_name FROM FSG_DD_GlobalImageSequenceImages WHERE image_sequence_id = ? ORDER BY sort_order ASC, id ASC'); $img->execute([(int)$row['id']]); $raw['images']=array_map(fn($ir)=>pd_text($ir['image_name'] ?? ''),$img->fetchAll()); } $seqs[]=$raw; } $payload['imageSequences']=$seqs; } } catch (Throwable $e) {} return $payload; }
function pd_merge_dd(array $payload, array $dd): array { if (!$dd) return $payload; $payload['dialogueSessionId'] = pd_text($dd['serverSessionId'] ?? $dd['sessionId'] ?? $dd['__sessionId'] ?? $payload['dialogueSessionId'] ?? ''); $payload['tokens'] = is_array($dd['globalTokens'] ?? null) ? $dd['globalTokens'] : ($payload['tokens'] ?? []); $payload['globalCast'] = is_array($dd['cast'] ?? null) ? $dd['cast'] : (is_array($dd['globalCast'] ?? null) ? $dd['globalCast'] : ($payload['globalCast'] ?? [])); foreach (['globalStates','globalMoods','globalSettings','menuOptions','imageSequences'] as $key) { $ddKey = $key === 'imageSequences' ? 'globalImageSequences' : ($key === 'menuOptions' ? 'globalMenuOptions' : $key); if (is_array($dd[$ddKey] ?? null)) $payload[$key] = $dd[$ddKey]; } if (is_array($dd['globalTimesOfDay'] ?? null)) $payload['timesOfDay']=$dd['globalTimesOfDay']; if (is_array($dd['globalDaysOfWeek'] ?? null)) $payload['daysOfWeek']=$dd['globalDaysOfWeek']; return $payload; }
function pd_load_workspace(PDO $pdo, int $userId, string $sid): array { $payload=pd_default(); if ($sid !== '' && pd_table($pdo,'FSG_PD_server_sessions')) { $stmt=$pdo->prepare('SELECT payload_json, dialogue_session_id FROM FSG_PD_server_sessions WHERE session_id = ? LIMIT 1'); $stmt->execute([$sid]); if ($row=$stmt->fetch()) { $payload=array_replace($payload,pd_decode(pd_text($row['payload_json'] ?? ''))); if (!empty($row['dialogue_session_id'])) $payload['dialogueSessionId']=$row['dialogue_session_id']; } } $preferred=pd_text($payload['dialogueSessionId'] ?? ''); if ($preferred==='' && str_starts_with($sid,'DD-')) $preferred=$sid; $ddSid=pd_latest_dd_session($pdo,$userId,$preferred); $dd=pd_load_dd_workspace($pdo,$ddSid); $payload=pd_merge_dd($payload,$dd); $payload=pd_load_dd_shared_tables($pdo,$payload,$dd); if (!$payload['dialogueSessionId']) $payload['dialogueSessionId']=$ddSid; $assigned=$sid !== '' ? $sid : (pd_text($payload['serverSessionId'] ?? '') ?: $ddSid); $payload['serverSessionId']=$assigned; $payload=pd_apply_advanced_cache($pdo,$assigned,$payload); return $payload; }
function pd_json_encode(mixed $value): string { return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR) ?: ''; }
function pd_pick(array $source, array $keys): array { $out=[]; foreach ($keys as $k) if (array_key_exists($k,$source)) $out[$k]=$source[$k]; return $out; }
function pd_save_advanced_cache(PDO $pdo, string $sid, array $payload): void {
    $pdo->prepare('DELETE FROM FSG_PD_PromptAdvanced WHERE session_id = ?')->execute([$sid]);
    $pdo->prepare('DELETE FROM FSG_PD_ResponseAdvanced WHERE session_id = ?')->execute([$sid]);
    $promptStmt = $pdo->prepare('INSERT INTO FSG_PD_PromptAdvanced (session_id, prompt_id, advanced_json, conditions_json, state_changes_json, triggers_json, visual_payloads_json, frames_json, window_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $responseStmt = $pdo->prepare('INSERT INTO FSG_PD_ResponseAdvanced (session_id, prompt_id, response_id, sort_order, response_text, voice_line, called_externally, externally_call, collapsed, conditions_json, state_changes_json, advanced_json, translations_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($payload['prompts'] ?? []) as $prompt) {
        if (!is_array($prompt)) continue;
        $promptId = pd_text($prompt['id'] ?? '');
        if ($promptId === '') continue;
        $promptAdvanced = pd_pick($prompt, ['advancedOpen','externalCall','makeExternalCall','controlSequence','sequenceName','sequenceImage','controlPuppets','puppetUsePath','puppetUseTag','changePuppetState','changePuppetMood','changePuppetInvert','puppets','conditionsOpen','statesOpen','triggersOpen','visualPayloadsOpen','responsesOpen','framesOpen','isCollapsed','voiceLine','textFormat','backgroundTintType','backgroundTintOpacity']);
        $window = pd_pick($prompt, ['winReopenDialogue','winCloseDialogue','winReopenMainMenu','winCloseMainMenu','winReopenPromptPanel','winClosePromptPanel','windowPositionId','priority','isRepeatable']);
        $promptStmt->execute([$sid, $promptId, pd_json_encode($promptAdvanced), pd_json_encode($prompt['conditions'] ?? []), pd_json_encode($prompt['gameStateChanges'] ?? []), pd_json_encode($prompt['triggers'] ?? []), pd_json_encode($prompt['visualPayloads'] ?? []), pd_json_encode($prompt['frames'] ?? []), pd_json_encode($window)]);
        $buttons = is_array($prompt['buttons'] ?? null) ? $prompt['buttons'] : [];
        foreach ($buttons as $sort => $button) {
            if (!is_array($button)) continue;
            $responseId = pd_text($button['id'] ?? '');
            if ($responseId === '') continue;
            $responseAdvanced = pd_pick($button, ['advancedOpen','isBranching','branchPromptId','closeMenu','isExternalLink','externalUrl','conditionsOpen','statesOpen','isCollapsed','textFormat']);
            $responseStmt->execute([$sid, $promptId, $responseId, (int)$sort, pd_text($button['text'] ?? ''), !empty($button['voiceLine']) ? 1 : 0, !empty($button['calledExternally']) ? 1 : 0, !empty($button['externallyCall']) ? 1 : 0, !empty($button['isCollapsed']) ? 1 : 0, pd_json_encode($button['conditions'] ?? []), pd_json_encode($button['stateChanges'] ?? []), pd_json_encode($responseAdvanced), pd_json_encode($button['translations'] ?? [])]);
        }
    }
}
function pd_apply_advanced_cache(PDO $pdo, string $sid, array $payload): array {
    if ($sid === '' || empty($payload['prompts']) || !is_array($payload['prompts'])) return $payload;
    if (!pd_table($pdo,'FSG_PD_PromptAdvanced') && !pd_table($pdo,'FSG_PD_ResponseAdvanced')) return $payload;

    $promptIndex = [];
    foreach ($payload['prompts'] as $idx => $prompt) {
        if (!is_array($prompt)) continue;
        $promptId = pd_text($prompt['id'] ?? '');
        if ($promptId !== '') $promptIndex[$promptId] = $idx;
    }

    if (pd_table($pdo,'FSG_PD_PromptAdvanced')) {
        $stmt = $pdo->prepare('SELECT prompt_id, advanced_json, conditions_json, state_changes_json FROM FSG_PD_PromptAdvanced WHERE session_id = ?');
        $stmt->execute([$sid]);
        foreach ($stmt->fetchAll() as $row) {
            $promptId = pd_text($row['prompt_id'] ?? '');
            if ($promptId === '' || !array_key_exists($promptId,$promptIndex)) continue;
            $idx = $promptIndex[$promptId];
            $advanced = pd_decode(pd_text($row['advanced_json'] ?? ''));
            if (is_array($advanced)) $payload['prompts'][$idx] = array_replace($payload['prompts'][$idx], $advanced);
            $conditions = pd_decode(pd_text($row['conditions_json'] ?? ''));
            $stateChanges = pd_decode(pd_text($row['state_changes_json'] ?? ''));
            if (is_array($conditions)) $payload['prompts'][$idx]['conditions'] = $conditions;
            if (is_array($stateChanges)) $payload['prompts'][$idx]['gameStateChanges'] = $stateChanges;
        }
    }

    if (pd_table($pdo,'FSG_PD_ResponseAdvanced')) {
        $stmt = $pdo->prepare('SELECT prompt_id, response_id, response_text, voice_line, called_externally, externally_call, collapsed, conditions_json, state_changes_json, advanced_json, translations_json FROM FSG_PD_ResponseAdvanced WHERE session_id = ? ORDER BY sort_order ASC');
        $stmt->execute([$sid]);
        foreach ($stmt->fetchAll() as $row) {
            $promptId = pd_text($row['prompt_id'] ?? '');
            $responseId = pd_text($row['response_id'] ?? '');
            if ($promptId === '' || $responseId === '' || !array_key_exists($promptId,$promptIndex)) continue;
            $pIdx = $promptIndex[$promptId];
            if (!isset($payload['prompts'][$pIdx]['buttons']) || !is_array($payload['prompts'][$pIdx]['buttons'])) $payload['prompts'][$pIdx]['buttons'] = [];
            foreach ($payload['prompts'][$pIdx]['buttons'] as $bIdx => $button) {
                if (!is_array($button) || pd_text($button['id'] ?? '') !== $responseId) continue;
                $advanced = pd_decode(pd_text($row['advanced_json'] ?? ''));
                if (is_array($advanced)) $payload['prompts'][$pIdx]['buttons'][$bIdx] = array_replace($payload['prompts'][$pIdx]['buttons'][$bIdx], $advanced);
                $conditions = pd_decode(pd_text($row['conditions_json'] ?? ''));
                $stateChanges = pd_decode(pd_text($row['state_changes_json'] ?? ''));
                $translations = pd_decode(pd_text($row['translations_json'] ?? ''));
                if (is_array($conditions)) $payload['prompts'][$pIdx]['buttons'][$bIdx]['conditions'] = $conditions;
                if (is_array($stateChanges)) $payload['prompts'][$pIdx]['buttons'][$bIdx]['stateChanges'] = $stateChanges;
                if (is_array($translations)) $payload['prompts'][$pIdx]['buttons'][$bIdx]['translations'] = $translations;
                $payload['prompts'][$pIdx]['buttons'][$bIdx]['text'] = pd_text($row['response_text'] ?? $payload['prompts'][$pIdx]['buttons'][$bIdx]['text'] ?? '');
                $payload['prompts'][$pIdx]['buttons'][$bIdx]['voiceLine'] = !empty($row['voice_line']);
                $payload['prompts'][$pIdx]['buttons'][$bIdx]['calledExternally'] = !empty($row['called_externally']);
                $payload['prompts'][$pIdx]['buttons'][$bIdx]['externallyCall'] = !empty($row['externally_call']);
                $payload['prompts'][$pIdx]['buttons'][$bIdx]['isCollapsed'] = !empty($row['collapsed']);
                break;
            }
        }
    }

    return $payload;
}
function pd_dd_langs(array $payload): array { $langs=[]; foreach (($payload['availableLanguages'] ?? ['ENG']) as $lang) { $l=strtoupper(trim(pd_text($lang))); if ($l!=='' && !in_array($l,$langs,true)) $langs[]=$l; } return $langs ?: ['ENG']; }
function pd_dd_named(array $items): array { $out=[]; foreach ($items as $item) { $row=is_array($item)?$item:['name'=>pd_text($item)]; $name=pd_text($row['name'] ?? $row['item_name'] ?? ''); if ($name==='') continue; $row['name']=$name; if (!isset($row['color'])) $row['color']='#00f2ff'; $out[]=$row; } return $out; }
function pd_dd_tokens(array $items): array { $out=[]; foreach ($items as $item) { $row=is_array($item)?$item:['key'=>pd_text($item),'value'=>'']; $key=pd_text($row['key'] ?? $row['token_key'] ?? ''); if ($key==='') continue; $out[]=['key'=>$key,'value'=>pd_text($row['value'] ?? $row['token_value'] ?? '')] + $row; } return $out; }
function pd_dd_payload(array $payload, array $existing, string $sid): array {
    unset($existing['__sessionId'],$existing['__workspaceDbId']);
    $dd=$existing ?: [];
    $dd['version']=pd_text($dd['version'] ?? 'DialogueDesigner');
    $dd['serverSessionId']=$sid;
    $dd['sessionId']=$sid;
    $dd['currentLanguage']=pd_text($payload['currentLanguage'] ?? $dd['currentLanguage'] ?? 'ENG') ?: 'ENG';
    $dd['availableLanguages']=pd_dd_langs($payload);
    $dd['globalTokens']=pd_dd_tokens(is_array($payload['tokens'] ?? null) ? $payload['tokens'] : []);
    $dd['cast']=pd_dd_named(is_array($payload['globalCast'] ?? null) ? $payload['globalCast'] : []);
    $dd['globalStates']=pd_dd_named(is_array($payload['globalStates'] ?? null) ? $payload['globalStates'] : []);
    $dd['globalMoods']=pd_dd_named(is_array($payload['globalMoods'] ?? null) ? $payload['globalMoods'] : []);
    $dd['globalSettings']=pd_dd_named(is_array($payload['globalSettings'] ?? null) ? $payload['globalSettings'] : []);
    $dd['globalTimesOfDay']=pd_dd_named(is_array($payload['timesOfDay'] ?? null) ? $payload['timesOfDay'] : []);
    $dd['globalDaysOfWeek']=pd_dd_named(is_array($payload['daysOfWeek'] ?? null) ? $payload['daysOfWeek'] : []);
    $dd['globalMenuOptions']=pd_dd_named(is_array($payload['menuOptions'] ?? null) ? $payload['menuOptions'] : []);
    $dd['globalImageSequences']=pd_dd_named(is_array($payload['imageSequences'] ?? null) ? $payload['imageSequences'] : []);
    foreach (['conversations','sequences'] as $key) if (!isset($dd[$key]) || !is_array($dd[$key])) $dd[$key]=[];
    if (empty($dd['workspaceId'])) $dd['workspaceId']='DD-WORKSPACE-' . strtoupper(bin2hex(random_bytes(8)));
    return $dd;
}
function pd_dd_insert_languages(PDO $pdo, int $workspaceId, array $langs): void { if (!pd_table($pdo,'FSG_DD_Languages')) return; $stmt=$pdo->prepare('INSERT INTO FSG_DD_Languages (workspace_id, language_code, sort_order) VALUES (?, ?, ?)'); foreach (array_values($langs) as $i=>$lang) $stmt->execute([$workspaceId,pd_text($lang),(int)$i]); }
function pd_dd_insert_tokens(PDO $pdo, int $workspaceId, array $items): void { if (!pd_table($pdo,'FSG_DD_GlobalTokens')) return; $stmt=$pdo->prepare('INSERT INTO FSG_DD_GlobalTokens (workspace_id, sort_order, token_key, token_value, raw_json) VALUES (?, ?, ?, ?, ?)'); foreach (array_values($items) as $i=>$row) $stmt->execute([$workspaceId,(int)$i,pd_text($row['key'] ?? ''),pd_text($row['value'] ?? ''),pd_json_encode($row)]); }
function pd_dd_insert_cast(PDO $pdo, int $workspaceId, array $items): void { if (!pd_table($pdo,'FSG_DD_Cast')) return; $stmt=$pdo->prepare('INSERT INTO FSG_DD_Cast (workspace_id, sort_order, character_name, color, raw_json) VALUES (?, ?, ?, ?, ?)'); foreach (array_values($items) as $i=>$row) $stmt->execute([$workspaceId,(int)$i,pd_text($row['name'] ?? ''),pd_text($row['color'] ?? ''),pd_json_encode($row)]); }
function pd_dd_insert_named(PDO $pdo, int $workspaceId, string $table, array $items): void { if (!pd_table($pdo,$table)) return; $allowed=['FSG_DD_GlobalStates','FSG_DD_GlobalMoods','FSG_DD_GlobalSettings','FSG_DD_GlobalTimesOfDay','FSG_DD_GlobalDaysOfWeek','FSG_DD_GlobalMenuOptions']; if (!in_array($table,$allowed,true)) return; $stmt=$pdo->prepare("INSERT INTO {$table} (workspace_id, sort_order, item_name, color, raw_json) VALUES (?, ?, ?, ?, ?)"); foreach (array_values($items) as $i=>$row) $stmt->execute([$workspaceId,(int)$i,pd_text($row['name'] ?? ''),pd_text($row['color'] ?? ''),pd_json_encode($row)]); }
function pd_dd_insert_image_sequences(PDO $pdo, int $workspaceId, array $items): void { if (!pd_table($pdo,'FSG_DD_GlobalImageSequences')) return; $seq=$pdo->prepare('INSERT INTO FSG_DD_GlobalImageSequences (workspace_id, sort_order, sequence_name, color, path, raw_json) VALUES (?, ?, ?, ?, ?, ?)'); $img=pd_table($pdo,'FSG_DD_GlobalImageSequenceImages') ? $pdo->prepare('INSERT INTO FSG_DD_GlobalImageSequenceImages (image_sequence_id, sort_order, image_name) VALUES (?, ?, ?)') : null; foreach (array_values($items) as $i=>$row) { $seq->execute([$workspaceId,(int)$i,pd_text($row['name'] ?? ''),pd_text($row['color'] ?? ''),pd_text($row['path'] ?? ''),pd_json_encode($row)]); $seqId=(int)$pdo->lastInsertId(); if ($img) foreach (array_values(is_array($row['images'] ?? null) ? $row['images'] : []) as $j=>$name) $img->execute([$seqId,(int)$j,pd_text(is_array($name)?($name['name'] ?? ''):$name)]); } }
function pd_dd_clear_global_rows(PDO $pdo, int $workspaceId): void {
    foreach (['FSG_DD_Languages','FSG_DD_Cast','FSG_DD_GlobalTokens','FSG_DD_GlobalStates','FSG_DD_GlobalMoods','FSG_DD_GlobalSettings','FSG_DD_GlobalTimesOfDay','FSG_DD_GlobalDaysOfWeek','FSG_DD_GlobalMenuOptions'] as $table) {
        if (pd_table($pdo,$table)) $pdo->prepare("DELETE FROM {$table} WHERE workspace_id = ?")->execute([$workspaceId]);
    }
    if (pd_table($pdo,'FSG_DD_GlobalImageSequenceImages') && pd_table($pdo,'FSG_DD_GlobalImageSequences')) {
        $ids=$pdo->prepare('SELECT id FROM FSG_DD_GlobalImageSequences WHERE workspace_id = ?');
        $ids->execute([$workspaceId]);
        foreach ($ids->fetchAll() as $row) $pdo->prepare('DELETE FROM FSG_DD_GlobalImageSequenceImages WHERE image_sequence_id = ?')->execute([(int)$row['id']]);
    }
    if (pd_table($pdo,'FSG_DD_GlobalImageSequences')) $pdo->prepare('DELETE FROM FSG_DD_GlobalImageSequences WHERE workspace_id = ?')->execute([$workspaceId]);
}
function pd_sync_dd_globals(PDO $pdo, int $userId, string $sid, array $payload): void {
    if ($userId <= 0 || !pd_table($pdo,'FSG_DD_Workspaces')) return;
    $existing=pd_load_dd_workspace($pdo,$sid);
    $workspaceId=(int)($existing['__workspaceDbId'] ?? 0);
    if ($workspaceId <= 0) return;
    $dd=pd_dd_payload($payload,$existing,$sid);
    $raw=pd_json_encode($dd);
    $pdo->beginTransaction();
    try {
        $sets=['raw_json = ?'];
        $args=[$raw];
        if (pd_col($pdo,'FSG_DD_Workspaces','current_language')) { $sets[]='current_language = ?'; $args[]=pd_text($dd['currentLanguage'] ?? 'ENG') ?: 'ENG'; }
        if (pd_col($pdo,'FSG_DD_Workspaces','available_languages_json')) { $sets[]='available_languages_json = ?'; $args[]=pd_json_encode($dd['availableLanguages'] ?? ['ENG']); }
        if (pd_col($pdo,'FSG_DD_Workspaces','updated_at')) $sets[]='updated_at = CURRENT_TIMESTAMP';
        $args[]=$workspaceId;
        $pdo->prepare('UPDATE FSG_DD_Workspaces SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($args);
        if (pd_table($pdo,'FSG_DD_RawJsonSnapshots')) $pdo->prepare('INSERT INTO FSG_DD_RawJsonSnapshots (workspace_id, snapshot_label, raw_json) VALUES (?, ?, ?)')->execute([$workspaceId,'PromptDesigner Global Sync',$raw]);
        pd_dd_clear_global_rows($pdo,$workspaceId);
        pd_dd_insert_languages($pdo,$workspaceId,$dd['availableLanguages'] ?? ['ENG']);
        pd_dd_insert_cast($pdo,$workspaceId,$dd['cast'] ?? []);
        pd_dd_insert_tokens($pdo,$workspaceId,$dd['globalTokens'] ?? []);
        pd_dd_insert_named($pdo,$workspaceId,'FSG_DD_GlobalStates',$dd['globalStates'] ?? []);
        pd_dd_insert_named($pdo,$workspaceId,'FSG_DD_GlobalMoods',$dd['globalMoods'] ?? []);
        pd_dd_insert_named($pdo,$workspaceId,'FSG_DD_GlobalSettings',$dd['globalSettings'] ?? []);
        pd_dd_insert_named($pdo,$workspaceId,'FSG_DD_GlobalTimesOfDay',$dd['globalTimesOfDay'] ?? []);
        pd_dd_insert_named($pdo,$workspaceId,'FSG_DD_GlobalDaysOfWeek',$dd['globalDaysOfWeek'] ?? []);
        pd_dd_insert_named($pdo,$workspaceId,'FSG_DD_GlobalMenuOptions',$dd['globalMenuOptions'] ?? []);
        pd_dd_insert_image_sequences($pdo,$workspaceId,$dd['globalImageSequences'] ?? []);
        if (pd_table($pdo,'FSG_DD_UserSessions')) $pdo->prepare('UPDATE FSG_DD_UserSessions SET last_viewed_at = CURRENT_TIMESTAMP WHERE user_id = ? AND session_id = ?')->execute([$userId,$sid]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}
function pd_save(PDO $pdo, int $userId, string $sid, array $payload): array { $payload=array_replace(pd_default(),$payload); $sid=trim($sid) ?: trim(pd_text($payload['serverSessionId'] ?? '')); if ($sid==='') $sid='PD-' . strtoupper(bin2hex(random_bytes(3))) . '-' . strtoupper(bin2hex(random_bytes(5))); $ddSid=pd_latest_dd_session($pdo,$userId,pd_text($payload['dialogueSessionId'] ?? '')); if ($ddSid) $payload['dialogueSessionId']=$ddSid; $payload['serverSessionId']=$sid; $json=pd_json_encode($payload); $stmt=$pdo->prepare('INSERT INTO FSG_PD_server_sessions (session_id, user_id, dialogue_session_id, payload_json) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id), dialogue_session_id=VALUES(dialogue_session_id), payload_json=VALUES(payload_json), updated_at=CURRENT_TIMESTAMP'); $stmt->execute([$sid,$userId ?: null,pd_text($payload['dialogueSessionId'] ?? ''),$json]); pd_save_advanced_cache($pdo,$sid,$payload); try { pd_sync_dd_globals($pdo,$userId,pd_text($payload['dialogueSessionId'] ?? '') ?: $sid,$payload); } catch (Throwable $e) { error_log('[PromptDesigner] DD global sync failed session='.$sid.' dialogue='.pd_text($payload['dialogueSessionId'] ?? '').' error='.$e->getMessage()); } try { if ($userId > 0 && function_exists('fsgAuth_touchServerSession')) fsgAuth_touchServerSession($pdo,$userId,'PromptDesigner',$sid,'push'); } catch (Throwable $e) { error_log('[PromptDesigner] touchServerSession failed session='.$sid.' user='.$userId.' error='.$e->getMessage()); } return $payload; }
try { $pdo=pd_pdo(); pd_ensure($pdo); $userId=pd_user($pdo); $action=pd_text($_GET['action'] ?? 'health'); $body=pd_body(); if ($action === '' && isset($body['action'])) $action=pd_text($body['action']); if ($action === 'health') pd_json(['ok'=>true,'api'=>'PromptDesigner','database'=>'connected']); if ($action === 'accountStatus') pd_json(['ok'=>true] + pd_auth_payload($pdo,$userId)); if ($action === 'loadLatest') { $sid=trim(pd_text($_GET['sessionId'] ?? '')) ?: pd_latest_pd_session($pdo,$userId); $workspace=pd_load_workspace($pdo,$userId,$sid); pd_json(['ok'=>true,'loggedIn'=>$userId>0,'sessionId'=>pd_text($workspace['serverSessionId'] ?? $sid),'dialogueSessionId'=>pd_text($workspace['dialogueSessionId'] ?? ''),'workspace'=>$workspace,'sessions'=>pd_account_sessions($pdo,$userId)]); } if ($action === 'loadSession') { $sid=trim(pd_text($_GET['sessionId'] ?? $body['sessionId'] ?? '')); if ($sid==='') pd_json(['ok'=>false,'error'=>'Missing sessionId'],400); $workspace=pd_load_workspace($pdo,$userId,$sid); pd_json(['ok'=>true,'loggedIn'=>$userId>0,'sessionId'=>pd_text($workspace['serverSessionId'] ?? $sid),'dialogueSessionId'=>pd_text($workspace['dialogueSessionId'] ?? ''),'workspace'=>$workspace,'sessions'=>pd_account_sessions($pdo,$userId)]); } if ($action === 'saveSession') { if ($userId<=0) pd_json(['ok'=>false,'error'=>'Login required'],401); $sid=trim(pd_text($_GET['sessionId'] ?? $body['serverSessionId'] ?? $body['sessionId'] ?? '')); if ($sid==='') $sid='PD-' . strtoupper(bin2hex(random_bytes(3))) . '-' . strtoupper(bin2hex(random_bytes(5))); $workspace=pd_save($pdo,$userId,$sid,$body); pd_json(['ok'=>true,'sessionId'=>pd_text($workspace['serverSessionId'] ?? $sid),'dialogueSessionId'=>pd_text($workspace['dialogueSessionId'] ?? ''),'workspace'=>$workspace,'sessions'=>pd_account_sessions($pdo,$userId)]); } pd_json(['ok'=>false,'error'=>'Unknown action'],404); } catch (Throwable $e) { $errId='PDERR-'.strtoupper(bin2hex(random_bytes(4))); $ctxAction=pd_text($action ?? ($_GET['action'] ?? '')); $ctxSid=pd_text($_GET['sessionId'] ?? ($body['serverSessionId'] ?? ($body['sessionId'] ?? ''))); error_log('[PromptDesigner '.$errId.'] action='.$ctxAction.' session='.$ctxSid.' user='.($userId ?? 0).' error='.$e->getMessage().' file='.$e->getFile().':'.$e->getLine()); pd_json(['ok'=>false,'error'=>$e->getMessage(),'errorId'=>$errId,'action'=>$ctxAction,'sessionId'=>$ctxSid],500); }
