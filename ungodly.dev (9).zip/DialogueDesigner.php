<?php
declare(strict_types=1);

$sharedAuthPath = __DIR__ . '/_private/AuthShared.php';
if (is_file($sharedAuthPath)) {
    require_once $sharedAuthPath;
    fsgAuth_startSharedSession();
} else {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function respondJson(array $payload, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function requireCredentials(): array
{
    $credentialsPath = __DIR__ . '/_private/databaseCredentials.php';
    if (!is_file($credentialsPath)) {
        respondJson(['ok' => false, 'error' => 'Missing _private/databaseCredentials.php'], 500);
    }

    require $credentialsPath;

    foreach (['dbHost', 'dbUser', 'dbPass', 'dbName'] as $varName) {
        if (!isset(${$varName})) {
            respondJson(['ok' => false, 'error' => "Missing database credential variable: {$varName}"], 500);
        }
    }

    return [$dbHost, $dbUser, $dbPass, $dbName];
}

function dbConnection(): PDO
{
    [$dbHost, $dbUser, $dbPass, $dbName] = requireCredentials();
    $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
    return new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}


function sharedFsgUserIdSqlType(PDO $pdo): string
{
    $stmt = $pdo->query("SHOW COLUMNS FROM FSG_users LIKE 'id'");
    $column = $stmt ? $stmt->fetch() : null;
    $type = strtolower((string)($column['Type'] ?? 'int'));
    $isUnsigned = strpos($type, 'unsigned') !== false;
    if (strpos($type, 'bigint') !== false) return $isUnsigned ? 'BIGINT UNSIGNED' : 'BIGINT';
    return $isUnsigned ? 'INT UNSIGNED' : 'INT';
}

function ensureAccountTables(PDO $pdo): void
{
    if (function_exists('fsgAuth_ensureAccountTables')) {
        try { fsgAuth_ensureAccountTables($pdo); } catch (Throwable $e) {}
    }
    // DialogueDesigner intentionally uses the shared front-end FSG_users table.
    // This CREATE only runs on a fresh database; existing FSG site accounts are never dropped here.
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_users (
        id INT NOT NULL AUTO_INCREMENT,
        username VARCHAR(64) NOT NULL,
        email VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        is_over_18 TINYINT(1) NOT NULL DEFAULT 0,
        agreed_terms TINYINT(1) NOT NULL DEFAULT 0,
        agreed_privacy TINYINT(1) NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        is_admin TINYINT(1) NOT NULL DEFAULT 0,
        banned_until DATETIME NULL DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_FSG_users_active_username (is_active, username),
        KEY idx_FSG_users_active_email (is_active, email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $userColumns = [
        'is_over_18' => "ALTER TABLE FSG_users ADD COLUMN is_over_18 TINYINT(1) NOT NULL DEFAULT 0",
        'agreed_terms' => "ALTER TABLE FSG_users ADD COLUMN agreed_terms TINYINT(1) NOT NULL DEFAULT 0",
        'agreed_privacy' => "ALTER TABLE FSG_users ADD COLUMN agreed_privacy TINYINT(1) NOT NULL DEFAULT 0",
        'is_active' => "ALTER TABLE FSG_users ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1",
        'is_admin' => "ALTER TABLE FSG_users ADD COLUMN is_admin TINYINT(1) NOT NULL DEFAULT 0",
        'banned_until' => "ALTER TABLE FSG_users ADD COLUMN banned_until DATETIME NULL DEFAULT NULL",
        'created_at' => "ALTER TABLE FSG_users ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP",
        'updated_at' => "ALTER TABLE FSG_users ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
    ];
    foreach ($userColumns as $columnName => $alterSql) {
        $check = $pdo->query("SHOW COLUMNS FROM FSG_users LIKE " . $pdo->quote($columnName));
        if ($check && $check->rowCount() === 0) $pdo->exec($alterSql);
    }

    $sharedUserIdSqlType = sharedFsgUserIdSqlType($pdo);

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_user_identity_history (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$sharedUserIdSqlType} NOT NULL,
        field_name ENUM('username','email','password') NOT NULL,
        old_value VARCHAR(255) NOT NULL DEFAULT '',
        new_value VARCHAR(255) NOT NULL DEFAULT '',
        changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_FSG_user_identity_history_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DD_UserSessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$sharedUserIdSqlType} NOT NULL,
        session_id VARCHAR(96) NOT NULL,
        first_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_viewed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        workspace_count INT UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_DD_UserSessions_session (session_id),
        KEY idx_FSG_DD_UserSessions_user_viewed (user_id, last_viewed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_auth_sessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$sharedUserIdSqlType} NOT NULL,
        token_hash CHAR(64) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME NOT NULL,
        last_seen_at DATETIME NULL DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_auth_sessions_token_hash (token_hash),
        KEY idx_FSG_auth_sessions_user_seen (user_id, last_seen_at),
        KEY idx_FSG_auth_sessions_expires (expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->prepare('DELETE FROM FSG_auth_sessions WHERE expires_at < UTC_TIMESTAMP()')->execute();

    try {
        $check = $pdo->query("SHOW COLUMNS FROM FSG_DD_Workspaces LIKE 'user_id'");
        if ($check && $check->rowCount() === 0) {
            $pdo->exec("ALTER TABLE FSG_DD_Workspaces ADD COLUMN user_id {$sharedUserIdSqlType} NULL DEFAULT NULL AFTER session_id");
            $pdo->exec("CREATE INDEX idx_FSG_DD_Workspaces_user_session ON FSG_DD_Workspaces (user_id, session_id, created_at)");
        }
    } catch (Throwable $e) {
        // Workspaces table may not exist before the main schema is run.
    }
}

function currentUserId(?PDO $pdo = null): int
{
    if (isset($_SESSION['fsg_user_id'])) return (int)$_SESSION['fsg_user_id'];
    if (isset($_SESSION['dd_user_id'])) return (int)$_SESSION['dd_user_id'];
    if (isset($_SESSION['user_id'])) return (int)$_SESSION['user_id'];
    if ($pdo && function_exists('fsgAuth_currentUserIdFromRequest')) {
        try {
            return (int)fsgAuth_currentUserIdFromRequest($pdo);
        } catch (Throwable $e) {
            return 0;
        }
    }
    return 0;
}

function passwordMeetsPolicy(string $password): bool
{
    return (bool)preg_match('/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z0-9]).{8,}/', $password);
}

function normalizeUsername(string $username): string
{
    return trim($username);
}

function normalizeEmail(string $email): string
{
    return strtolower(trim($email));
}

function activeIdentityExists(PDO $pdo, string $username, string $email, int $excludeUserId = 0): bool
{
    $sql = 'SELECT id FROM FSG_users WHERE is_active = 1 AND (LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?))';
    $params = [$username, $email];
    if ($excludeUserId > 0) {
        $sql .= ' AND id != ?';
        $params[] = $excludeUserId;
    }
    $sql .= ' LIMIT 1';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (bool)$stmt->fetch();
}

function getUserById(PDO $pdo, int $userId): ?array
{
    if ($userId <= 0) return null;
    $stmt = $pdo->prepare('SELECT id, username, email, created_at FROM FSG_users WHERE id = ? AND is_active = 1 LIMIT 1');
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function listUserSessions(PDO $pdo, int $userId): array
{
    if ($userId <= 0) return [];

    $sessionsById = [];

    try {
        $stmt = $pdo->prepare('SELECT session_id, first_pushed_at, last_pushed_at, last_viewed_at, workspace_count FROM FSG_DD_UserSessions WHERE user_id = ? ORDER BY last_viewed_at DESC, last_pushed_at DESC, id DESC');
        $stmt->execute([$userId]);
        foreach ($stmt->fetchAll() as $row) {
            $sid = trim((string)($row['session_id'] ?? ''));
            if ($sid === '') continue;
            $sessionsById[$sid] = $row;
        }
    } catch (Throwable $e) {
        $sessionsById = [];
    }

    try {
        $stmt = $pdo->prepare("SELECT session_id, MIN(created_at) AS first_pushed_at, MAX(created_at) AS last_pushed_at, MAX(updated_at) AS last_viewed_at, COUNT(*) AS workspace_count FROM FSG_DD_Workspaces WHERE user_id = ? AND session_id <> '' GROUP BY session_id ORDER BY last_pushed_at DESC");
        $stmt->execute([$userId]);
        foreach ($stmt->fetchAll() as $row) {
            $sid = trim((string)($row['session_id'] ?? ''));
            if ($sid === '') continue;
            if (!isset($sessionsById[$sid])) {
                $sessionsById[$sid] = $row;
            } else {
                $sessionsById[$sid]['workspace_count'] = max((int)($sessionsById[$sid]['workspace_count'] ?? 0), (int)($row['workspace_count'] ?? 0));
                if (empty($sessionsById[$sid]['first_pushed_at'])) $sessionsById[$sid]['first_pushed_at'] = $row['first_pushed_at'] ?? null;
                if (empty($sessionsById[$sid]['last_pushed_at']) || strtotime((string)($row['last_pushed_at'] ?? '')) > strtotime((string)($sessionsById[$sid]['last_pushed_at'] ?? ''))) {
                    $sessionsById[$sid]['last_pushed_at'] = $row['last_pushed_at'] ?? null;
                }
            }
        }
    } catch (Throwable $e) {}

    $sessions = array_values($sessionsById);
    usort($sessions, function($a, $b) {
        $aTime = strtotime((string)($a['last_viewed_at'] ?? $a['last_pushed_at'] ?? $a['first_pushed_at'] ?? '')) ?: 0;
        $bTime = strtotime((string)($b['last_viewed_at'] ?? $b['last_pushed_at'] ?? $b['first_pushed_at'] ?? '')) ?: 0;
        return $bTime <=> $aTime;
    });
    return $sessions;
}

function authPayload(PDO $pdo): array
{
    $user = getUserById($pdo, currentUserId($pdo));
    if (!$user) {
        unset($_SESSION['dd_user_id'], $_SESSION['dd_username'], $_SESSION['user_id'], $_SESSION['username']);
        return ['loggedIn' => false, 'user' => null, 'sessions' => []];
    }
    return [
        'loggedIn' => true,
        'user' => [
            'id' => (int)$user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'createdAt' => $user['created_at'],
        ],
        'sessions' => listUserSessions($pdo, (int)$user['id']),
    ];
}

function registerAccount(PDO $pdo, array $body): array
{
    $username = normalizeUsername(textValue($body['username'] ?? ''));
    $email = normalizeEmail(textValue($body['email'] ?? ''));
    $password = textValue($body['password'] ?? '');
    $passwordConfirm = textValue($body['passwordConfirm'] ?? '');
    $over18 = boolValue($body['over18'] ?? false);
    $terms = boolValue($body['terms'] ?? false);
    $privacy = boolValue($body['privacy'] ?? false);

    if ($username === '' || $email === '') respondJson(['ok' => false, 'error' => 'Username and email are required.'], 400);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) respondJson(['ok' => false, 'error' => 'Enter a valid email address.'], 400);
    if (!$over18 || !$terms || !$privacy) respondJson(['ok' => false, 'error' => 'You must confirm 18+ and agree to the Terms of Service and Privacy Policy.'], 400);
    if ($password !== $passwordConfirm) respondJson(['ok' => false, 'error' => 'Passwords do not match.'], 400);
    if (!passwordMeetsPolicy($password)) respondJson(['ok' => false, 'error' => 'Password must be at least 8 characters with 1 uppercase, 1 lowercase, 1 number, and 1 special character.'], 400);
    if (activeIdentityExists($pdo, $username, $email)) respondJson(['ok' => false, 'error' => 'Username or email is already active.'], 409);

    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO FSG_users (username, email, password, is_over_18, agreed_terms, agreed_privacy, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)');
    $stmt->execute([$username, $email, $hash, $over18, $terms, $privacy]);
    $_SESSION['dd_user_id'] = (int)$pdo->lastInsertId();
    $_SESSION['dd_username'] = $username;
    $_SESSION['user_id'] = $_SESSION['dd_user_id'];
    $_SESSION['username'] = $username;
    $payload = authPayload($pdo);
    if (function_exists('fsgAuth_issueAuthToken')) {
        $payload['authToken'] = fsgAuth_issueAuthToken($pdo, (int)$_SESSION['dd_user_id']);
    }
    return $payload;
}

function loginAccount(PDO $pdo, array $body): array
{
    $identity = trim(textValue($body['identity'] ?? ''));
    $password = textValue($body['password'] ?? '');
    if ($identity === '' || $password === '') respondJson(['ok' => false, 'error' => 'Username/email and password are required.'], 400);
    $stmt = $pdo->prepare('SELECT id, username, password FROM FSG_users WHERE is_active = 1 AND (LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)) LIMIT 1');
    $stmt->execute([$identity, $identity]);
    $row = $stmt->fetch();
    if (!$row || !password_verify($password, $row['password'])) {
        respondJson(['ok' => false, 'error' => 'Invalid credentials.'], 401);
    }
    $_SESSION['dd_user_id'] = (int)$row['id'];
    $_SESSION['dd_username'] = $row['username'];
    $_SESSION['user_id'] = $_SESSION['dd_user_id'];
    $_SESSION['username'] = $row['username'];
    $payload = authPayload($pdo);
    if (function_exists('fsgAuth_issueAuthToken')) {
        $payload['authToken'] = fsgAuth_issueAuthToken($pdo, (int)$_SESSION['dd_user_id']);
    }
    return $payload;
}

function updateProfile(PDO $pdo, array $body): array
{
    $userId = currentUserId($pdo);
    $user = getUserById($pdo, $userId);
    if (!$user) respondJson(['ok' => false, 'error' => 'You are not logged in.'], 401);
    $username = normalizeUsername(textValue($body['username'] ?? ''));
    $email = normalizeEmail(textValue($body['email'] ?? ''));
    if ($username === '' || $email === '') respondJson(['ok' => false, 'error' => 'Username and email are required.'], 400);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) respondJson(['ok' => false, 'error' => 'Enter a valid email address.'], 400);
    if (activeIdentityExists($pdo, $username, $email, $userId)) respondJson(['ok' => false, 'error' => 'Username or email is already active.'], 409);

    $pdo->beginTransaction();
    try {
        if ($username !== $user['username']) {
            $hist = $pdo->prepare("INSERT INTO FSG_user_identity_history (user_id, field_name, old_value, new_value) VALUES (?, 'username', ?, ?)");
            $hist->execute([$userId, $user['username'], $username]);
        }
        if ($email !== strtolower($user['email'])) {
            $hist = $pdo->prepare("INSERT INTO FSG_user_identity_history (user_id, field_name, old_value, new_value) VALUES (?, 'email', ?, ?)");
            $hist->execute([$userId, $user['email'], $email]);
        }
        $stmt = $pdo->prepare('UPDATE FSG_users SET username = ?, email = ? WHERE id = ?');
        $stmt->execute([$username, $email, $userId]);
        $_SESSION['dd_username'] = $username;
        $_SESSION['username'] = $username;
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    return authPayload($pdo);
}

function changePassword(PDO $pdo, array $body): array
{
    $userId = currentUserId($pdo);
    if (!getUserById($pdo, $userId)) respondJson(['ok' => false, 'error' => 'You are not logged in.'], 401);
    $password = textValue($body['password'] ?? '');
    $passwordConfirm = textValue($body['passwordConfirm'] ?? '');
    if ($password !== $passwordConfirm) respondJson(['ok' => false, 'error' => 'Passwords do not match.'], 400);
    if (!passwordMeetsPolicy($password)) respondJson(['ok' => false, 'error' => 'Password must be at least 8 characters with 1 uppercase, 1 lowercase, 1 number, and 1 special character.'], 400);
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('UPDATE FSG_users SET password = ? WHERE id = ?');
        $stmt->execute([$hash, $userId]);
        $hist = $pdo->prepare("INSERT INTO FSG_user_identity_history (user_id, field_name, old_value, new_value) VALUES (?, 'password', '[password changed]', '[password changed]')");
        $hist->execute([$userId]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    return authPayload($pdo);
}

function generateUniqueSessionId(PDO $pdo): string
{
    for ($attempt = 0; $attempt < 25; $attempt++) {
        $bytes = strtoupper(bin2hex(random_bytes(8)));
        $sessionId = 'DD-' . substr($bytes, 0, 6) . '-' . substr($bytes, 6, 10);
        $stmt = $pdo->prepare('SELECT session_id FROM FSG_DD_Workspaces WHERE session_id = ? LIMIT 1');
        $stmt->execute([$sessionId]);
        if ($stmt->fetch()) continue;
        $stmt = $pdo->prepare('SELECT session_id FROM FSG_DD_UserSessions WHERE session_id = ? LIMIT 1');
        $stmt->execute([$sessionId]);
        if ($stmt->fetch()) continue;
        return $sessionId;
    }
    return 'DD-' . strtoupper(bin2hex(random_bytes(4))) . '-' . strtoupper(bin2hex(random_bytes(5)));
}

function touchUserSessionViewed(PDO $pdo, string $sessionId): void
{
    $userId = currentUserId($pdo);
    if ($userId <= 0 || trim($sessionId) === '') return;
    $stmt = $pdo->prepare('UPDATE FSG_DD_UserSessions SET last_viewed_at = CURRENT_TIMESTAMP WHERE user_id = ? AND session_id = ?');
    $stmt->execute([$userId, $sessionId]);
}

function attachWorkspaceToUserSession(PDO $pdo, string $sessionId, ?int $explicitUserId = null): void
{
    $userId = $explicitUserId !== null ? $explicitUserId : currentUserId();
    if ($userId <= 0 || trim($sessionId) === '') return;
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_UserSessions (user_id, session_id, first_pushed_at, last_pushed_at, last_viewed_at, workspace_count)
        VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1)
        ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), last_pushed_at = CURRENT_TIMESTAMP, last_viewed_at = CURRENT_TIMESTAMP, workspace_count = workspace_count + 1');
    $stmt->execute([$userId, $sessionId]);
    if (function_exists('fsgAuth_touchServerSession')) {
        try { fsgAuth_touchServerSession($pdo, $userId, 'DialogueDesigner', $sessionId, 'push'); } catch (Throwable $e) {}
    }
}

function requestBody(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        respondJson(['ok' => false, 'error' => 'Invalid JSON body.'], 400);
    }

    return $decoded;
}

function uuidv4(): string
{
    $data = random_bytes(16);
    $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
    $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

function textValue(mixed $value): string
{
    if ($value === null) return '';
    if (is_bool($value)) return $value ? '1' : '0';
    if (is_scalar($value)) return (string)$value;
    return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '';
}

function boolValue(mixed $value): int
{
    if (is_bool($value)) return $value ? 1 : 0;
    if (is_numeric($value)) return ((int)$value) !== 0 ? 1 : 0;
    if (is_string($value)) return in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true) ? 1 : 0;
    return 0;
}

function jsonText(mixed $value): string
{
    return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: 'null';
}

function arr(mixed $value): array
{
    return is_array($value) ? $value : [];
}

function insertLanguages(PDO $pdo, int $workspaceId, array $languages): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_Languages (workspace_id, language_code, sort_order) VALUES (?, ?, ?)');
    foreach (array_values($languages) as $index => $language) {
        $languageCode = strtoupper(trim(textValue($language)));
        if ($languageCode === '') continue;
        $stmt->execute([$workspaceId, $languageCode, $index]);
    }
}

function insertCast(PDO $pdo, int $workspaceId, array $items): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_Cast (workspace_id, sort_order, character_name, color, raw_json) VALUES (?, ?, ?, ?, ?)');
    foreach (array_values($items) as $index => $item) {
        $data = is_array($item) ? $item : ['name' => textValue($item), 'color' => ''];
        $stmt->execute([
            $workspaceId,
            $index,
            textValue($data['name'] ?? ''),
            textValue($data['color'] ?? ''),
            jsonText($data),
        ]);
    }
}

function insertGlobalTokens(PDO $pdo, int $workspaceId, array $items): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_GlobalTokens (workspace_id, sort_order, token_key, token_value, raw_json) VALUES (?, ?, ?, ?, ?)');
    foreach (array_values($items) as $index => $item) {
        $data = is_array($item) ? $item : ['key' => textValue($item), 'value' => ''];
        $stmt->execute([
            $workspaceId,
            $index,
            textValue($data['key'] ?? ''),
            textValue($data['value'] ?? ''),
            jsonText($data),
        ]);
    }
}

function insertNamedGlobals(PDO $pdo, int $workspaceId, string $tableName, array $items): void
{
    $allowed = [
        'FSG_DD_GlobalStates',
        'FSG_DD_GlobalMoods',
        'FSG_DD_GlobalSettings',
        'FSG_DD_GlobalTimesOfDay',
        'FSG_DD_GlobalDaysOfWeek',
        'FSG_DD_GlobalMenuOptions',
    ];
    if (!in_array($tableName, $allowed, true)) {
        throw new RuntimeException('Unsupported global table.');
    }

    $stmt = $pdo->prepare("INSERT INTO {$tableName} (workspace_id, sort_order, item_name, color, raw_json) VALUES (?, ?, ?, ?, ?)");
    foreach (array_values($items) as $index => $item) {
        $data = is_array($item) ? $item : ['name' => textValue($item), 'color' => ''];
        $stmt->execute([
            $workspaceId,
            $index,
            textValue($data['name'] ?? ''),
            textValue($data['color'] ?? ''),
            jsonText($data),
        ]);
    }
}

function insertImageSequences(PDO $pdo, int $workspaceId, array $items): void
{
    $seqStmt = $pdo->prepare('INSERT INTO FSG_DD_GlobalImageSequences (workspace_id, sort_order, sequence_name, color, path, raw_json) VALUES (?, ?, ?, ?, ?, ?)');
    $imgStmt = $pdo->prepare('INSERT INTO FSG_DD_GlobalImageSequenceImages (image_sequence_id, sort_order, image_name) VALUES (?, ?, ?)');

    foreach (array_values($items) as $index => $item) {
        $data = is_array($item) ? $item : ['name' => textValue($item), 'images' => []];
        $seqStmt->execute([
            $workspaceId,
            $index,
            textValue($data['name'] ?? ''),
            textValue($data['color'] ?? ''),
            textValue($data['path'] ?? ''),
            jsonText($data),
        ]);
        $sequenceId = (int)$pdo->lastInsertId();
        foreach (array_values(arr($data['images'] ?? [])) as $imgIndex => $imageName) {
            $imgStmt->execute([$sequenceId, $imgIndex, textValue($imageName)]);
        }
    }
}

function collectProjectLogic(array $project): array
{
    $tags = [];
    $add = static function (mixed $key, mixed $value, string $type) use (&$tags): void {
        $variable = trim(textValue($key));
        $val = textValue($value);
        if ($variable === '' && trim($val) === '') return;
        $mapKey = $variable . "\0" . $val;
        if (!isset($tags[$mapKey])) {
            $tags[$mapKey] = [
                'key' => $variable,
                'value' => $val,
                'condition_count' => 0,
                'state_change_count' => 0,
            ];
        }
        if ($type === 'condition') $tags[$mapKey]['condition_count']++;
        if ($type === 'state') $tags[$mapKey]['state_change_count']++;
    };

    foreach (arr($project['nodes'] ?? []) as $node) {
        foreach (arr($node['conditions'] ?? []) as $condition) $add($condition['variable'] ?? '', $condition['value'] ?? '', 'condition');
        foreach (arr($node['gameStateChanges'] ?? []) as $change) $add($change['variable'] ?? '', $change['value'] ?? '', 'state');
        foreach (arr($node['responses'] ?? []) as $response) {
            foreach (arr($response['conditions'] ?? []) as $condition) $add($condition['variable'] ?? '', $condition['value'] ?? '', 'condition');
            foreach (arr($response['gameStateChanges'] ?? []) as $change) $add($change['variable'] ?? '', $change['value'] ?? '', 'state');
        }
    }

    return array_values($tags);
}

function insertActiveProjectLogic(PDO $pdo, int $projectId, array $project): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_ActiveProjectLogic (project_id, sort_order, key_variable, value_text, condition_count, state_change_count, total_references, usage_classification) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (collectProjectLogic($project) as $index => $tag) {
        $conditionCount = (int)$tag['condition_count'];
        $stateCount = (int)$tag['state_change_count'];
        $usage = 'Matched';
        if ($conditionCount > 0 && $stateCount === 0) $usage = 'Condition Only';
        if ($conditionCount === 0 && $stateCount > 0) $usage = 'State Change Only';
        $stmt->execute([
            $projectId,
            $index,
            $tag['key'],
            $tag['value'],
            $conditionCount,
            $stateCount,
            $conditionCount + $stateCount,
            $usage,
        ]);
    }
}

function insertLogicRows(PDO $pdo, string $tableName, string $ownerColumn, int $ownerId, array $rows): void
{
    $allowed = [
        'FSG_DD_NodeConditions' => 'node_id',
        'FSG_DD_NodeGameStateChanges' => 'node_id',
        'FSG_DD_ResponseConditions' => 'response_id',
        'FSG_DD_ResponseGameStateChanges' => 'response_id',
    ];
    if (!isset($allowed[$tableName]) || $allowed[$tableName] !== $ownerColumn) {
        throw new RuntimeException('Unsupported logic row target.');
    }

    $stmt = $pdo->prepare("INSERT INTO {$tableName} ({$ownerColumn}, sort_order, key_variable, operator_text, value_text) VALUES (?, ?, ?, ?, ?)");
    foreach (array_values($rows) as $index => $row) {
        $data = is_array($row) ? $row : [];
        $stmt->execute([
            $ownerId,
            $index,
            textValue($data['variable'] ?? ''),
            textValue($data['operator'] ?? '==') ?: '==',
            textValue($data['value'] ?? ''),
        ]);
    }
}

function insertNamedChangeRows(PDO $pdo, string $tableName, string $ownerColumn, string $nameColumn, int $ownerId, array $rows, string $sourceNameKey): void
{
    $allowed = [
        'FSG_DD_NodeTimeOfDayChanges' => ['node_id', 'time_name'],
        'FSG_DD_NodeDayOfWeekChanges' => ['node_id', 'day_name'],
        'FSG_DD_NodeMenuOptionChanges' => ['node_id', 'menu_name'],
        'FSG_DD_NodeSettingChanges' => ['node_id', 'setting_name'],
        'FSG_DD_ResponseTimeOfDayChanges' => ['response_id', 'time_name'],
        'FSG_DD_ResponseDayOfWeekChanges' => ['response_id', 'day_name'],
        'FSG_DD_ResponseMenuOptionChanges' => ['response_id', 'menu_name'],
        'FSG_DD_ResponseSettingChanges' => ['response_id', 'setting_name'],
    ];
    if (!isset($allowed[$tableName]) || $allowed[$tableName] !== [$ownerColumn, $nameColumn]) {
        throw new RuntimeException('Unsupported named change target.');
    }

    $stmt = $pdo->prepare("INSERT INTO {$tableName} ({$ownerColumn}, sort_order, {$nameColumn}, value_text) VALUES (?, ?, ?, ?)");
    foreach (array_values($rows) as $index => $row) {
        $data = is_array($row) ? $row : [];
        $stmt->execute([
            $ownerId,
            $index,
            textValue($data[$sourceNameKey] ?? ''),
            textValue($data['value'] ?? ''),
        ]);
    }
}

function insertPuppets(PDO $pdo, string $tableName, string $ownerColumn, int $ownerId, array $puppets): void
{
    $allowed = [
        'FSG_DD_NodePuppets' => 'node_id',
        'FSG_DD_ResponsePuppets' => 'response_id',
    ];
    if (!isset($allowed[$tableName]) || $allowed[$tableName] !== $ownerColumn) {
        throw new RuntimeException('Unsupported puppet target.');
    }

    $stmt = $pdo->prepare("INSERT INTO {$tableName} ({$ownerColumn}, sort_order, puppet_name, enabled, position_text, path, state_name, mood_name, invert, raw_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    foreach (array_values($puppets) as $index => $puppet) {
        $data = is_array($puppet) ? $puppet : [];
        $stmt->execute([
            $ownerId,
            $index,
            textValue($data['name'] ?? ''),
            boolValue($data['enabled'] ?? true),
            textValue($data['position'] ?? ''),
            textValue($data['path'] ?? ''),
            textValue($data['state'] ?? ''),
            textValue($data['mood'] ?? ''),
            boolValue($data['invert'] ?? false),
            jsonText($data),
        ]);
    }
}

function insertTranslations(PDO $pdo, string $tableName, string $ownerColumn, int $ownerId, array $translations): void
{
    $allowed = [
        'FSG_DD_NodeTranslations' => 'node_id',
        'FSG_DD_ResponseTranslations' => 'response_id',
    ];
    if (!isset($allowed[$tableName]) || $allowed[$tableName] !== $ownerColumn) {
        throw new RuntimeException('Unsupported translation target.');
    }

    $stmt = $pdo->prepare("INSERT INTO {$tableName} ({$ownerColumn}, language_code, text) VALUES (?, ?, ?)");
    foreach ($translations as $language => $text) {
        $languageCode = strtoupper(trim(textValue($language)));
        if ($languageCode === '') continue;
        $stmt->execute([$ownerId, $languageCode, textValue($text)]);
    }
}

function insertResponses(PDO $pdo, int $nodeId, array $responses): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_Responses (
        node_id, response_uuid, sort_order, speaker, text, next_statement_uuid, auto_increment_flag, voice_line, is_collapsed, advanced_open, conditions_open, states_open,
        resource_path, use_path, close_main_menu, close_dialogue_menu, open_prompt_panel, close_prompt_panel, change_time_of_day, change_day_of_week,
        change_menu_option, change_setting, control_sequence, sequence_name, sequence_image, control_puppets, puppet_use_path, puppet_use_tag,
        change_puppet_state, change_puppet_mood, change_puppet_invert, text_format_json, raw_json
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');

    foreach (array_values($responses) as $index => $response) {
        $r = is_array($response) ? $response : [];
        $responseUuid = textValue($r['id'] ?? '') ?: uuidv4();
        $stmt->execute([
            $nodeId,
            $responseUuid,
            $index,
            textValue($r['speaker'] ?? ''),
            textValue($r['text'] ?? ''),
            textValue($r['nextStatementId'] ?? '') ?: null,
            boolValue($r['autoIncrement'] ?? false),
            boolValue($r['voiceLine'] ?? false),
            boolValue($r['isCollapsed'] ?? false),
            boolValue($r['advancedOpen'] ?? false),
            boolValue($r['conditionsOpen'] ?? true),
            boolValue($r['statesOpen'] ?? true),
            textValue($r['resourcePath'] ?? ''),
            boolValue($r['usePath'] ?? false),
            boolValue($r['closeMainMenu'] ?? false),
            boolValue($r['closeDialogueMenu'] ?? false),
            boolValue($r['openPromptPanel'] ?? false),
            boolValue($r['closePromptPanel'] ?? false),
            boolValue($r['changeTimeOfDay'] ?? false),
            boolValue($r['changeDayOfWeek'] ?? false),
            boolValue($r['changeMenuOption'] ?? false),
            boolValue($r['changeSetting'] ?? false),
            boolValue($r['controlSequence'] ?? false),
            textValue($r['sequenceName'] ?? ''),
            textValue($r['sequenceImage'] ?? ''),
            boolValue($r['controlPuppets'] ?? false),
            boolValue($r['puppetUsePath'] ?? false),
            boolValue($r['puppetUseTag'] ?? false),
            boolValue($r['changePuppetState'] ?? false),
            boolValue($r['changePuppetMood'] ?? false),
            boolValue($r['changePuppetInvert'] ?? false),
            jsonText($r['textFormat'] ?? null),
            jsonText($r),
        ]);
        $responseId = (int)$pdo->lastInsertId();

        insertTranslations($pdo, 'FSG_DD_ResponseTranslations', 'response_id', $responseId, arr($r['translations'] ?? []));
        insertLogicRows($pdo, 'FSG_DD_ResponseConditions', 'response_id', $responseId, arr($r['conditions'] ?? []));
        insertLogicRows($pdo, 'FSG_DD_ResponseGameStateChanges', 'response_id', $responseId, arr($r['gameStateChanges'] ?? []));
        insertNamedChangeRows($pdo, 'FSG_DD_ResponseTimeOfDayChanges', 'response_id', 'time_name', $responseId, arr($r['timeOfDayChanges'] ?? []), 'time');
        insertNamedChangeRows($pdo, 'FSG_DD_ResponseDayOfWeekChanges', 'response_id', 'day_name', $responseId, arr($r['dayOfWeekChanges'] ?? []), 'day');
        insertNamedChangeRows($pdo, 'FSG_DD_ResponseMenuOptionChanges', 'response_id', 'menu_name', $responseId, arr($r['menuOptionChanges'] ?? []), 'menu');
        insertNamedChangeRows($pdo, 'FSG_DD_ResponseSettingChanges', 'response_id', 'setting_name', $responseId, arr($r['settingChanges'] ?? []), 'setting');
        insertPuppets($pdo, 'FSG_DD_ResponsePuppets', 'response_id', $responseId, arr($r['puppets'] ?? []));
    }
}

function insertNodes(PDO $pdo, int $projectId, array $nodes): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_Nodes (
        project_id, node_uuid, sort_order, speaker, text, node_color, voice_line, is_collapsed, advanced_open, conditions_open, states_open, responses_open,
        resource_path, use_path, close_main_menu, close_dialogue_menu, open_prompt_panel, close_prompt_panel, change_time_of_day, change_day_of_week,
        change_menu_option, change_setting, control_sequence, sequence_name, sequence_image, control_puppets, puppet_use_path, puppet_use_tag,
        change_puppet_state, change_puppet_mood, change_puppet_invert, can_player_respond, external_call, make_external_call, parent_response_uuid,
        parent_response_preview, text_format_json, raw_json
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');

    foreach (array_values($nodes) as $index => $node) {
        $n = is_array($node) ? $node : [];
        $nodeUuid = textValue($n['id'] ?? '') ?: uuidv4();
        $stmt->execute([
            $projectId,
            $nodeUuid,
            $index,
            textValue($n['speaker'] ?? ''),
            textValue($n['text'] ?? ''),
            textValue($n['nodeColor'] ?? ''),
            boolValue($n['voiceLine'] ?? true),
            boolValue($n['isCollapsed'] ?? false),
            boolValue($n['advancedOpen'] ?? false),
            boolValue($n['conditionsOpen'] ?? true),
            boolValue($n['statesOpen'] ?? true),
            boolValue($n['responsesOpen'] ?? true),
            textValue($n['resourcePath'] ?? ''),
            boolValue($n['usePath'] ?? false),
            boolValue($n['closeMainMenu'] ?? false),
            boolValue($n['closeDialogueMenu'] ?? false),
            boolValue($n['openPromptPanel'] ?? false),
            boolValue($n['closePromptPanel'] ?? false),
            boolValue($n['changeTimeOfDay'] ?? false),
            boolValue($n['changeDayOfWeek'] ?? false),
            boolValue($n['changeMenuOption'] ?? false),
            boolValue($n['changeSetting'] ?? false),
            boolValue($n['controlSequence'] ?? false),
            textValue($n['sequenceName'] ?? ''),
            textValue($n['sequenceImage'] ?? ''),
            boolValue($n['controlPuppets'] ?? false),
            boolValue($n['puppetUsePath'] ?? false),
            boolValue($n['puppetUseTag'] ?? false),
            boolValue($n['changePuppetState'] ?? false),
            boolValue($n['changePuppetMood'] ?? false),
            boolValue($n['changePuppetInvert'] ?? false),
            boolValue($n['canPlayerRespond'] ?? false),
            boolValue($n['externalCall'] ?? false),
            boolValue($n['makeExternalCall'] ?? false),
            textValue($n['parentResponseId'] ?? '') ?: null,
            textValue($n['parentResponsePreview'] ?? ''),
            jsonText($n['textFormat'] ?? null),
            jsonText($n),
        ]);
        $nodeId = (int)$pdo->lastInsertId();

        insertTranslations($pdo, 'FSG_DD_NodeTranslations', 'node_id', $nodeId, arr($n['translations'] ?? []));
        insertLogicRows($pdo, 'FSG_DD_NodeConditions', 'node_id', $nodeId, arr($n['conditions'] ?? []));
        insertLogicRows($pdo, 'FSG_DD_NodeGameStateChanges', 'node_id', $nodeId, arr($n['gameStateChanges'] ?? []));
        insertNamedChangeRows($pdo, 'FSG_DD_NodeTimeOfDayChanges', 'node_id', 'time_name', $nodeId, arr($n['timeOfDayChanges'] ?? []), 'time');
        insertNamedChangeRows($pdo, 'FSG_DD_NodeDayOfWeekChanges', 'node_id', 'day_name', $nodeId, arr($n['dayOfWeekChanges'] ?? []), 'day');
        insertNamedChangeRows($pdo, 'FSG_DD_NodeMenuOptionChanges', 'node_id', 'menu_name', $nodeId, arr($n['menuOptionChanges'] ?? []), 'menu');
        insertNamedChangeRows($pdo, 'FSG_DD_NodeSettingChanges', 'node_id', 'setting_name', $nodeId, arr($n['settingChanges'] ?? []), 'setting');
        insertPuppets($pdo, 'FSG_DD_NodePuppets', 'node_id', $nodeId, arr($n['puppets'] ?? []));
        insertResponses($pdo, $nodeId, arr($n['responses'] ?? []));
    }
}

function insertProjects(PDO $pdo, int $workspaceId, string $projectType, array $projects): int
{
    $inserted = 0;
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_Projects (workspace_id, project_uuid, project_type, sort_order, title, color, is_repeatable, repeat_variable, raw_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $participantStmt = $pdo->prepare('INSERT INTO FSG_DD_ProjectParticipants (project_id, sort_order, participant_name) VALUES (?, ?, ?)');

    foreach (array_values($projects) as $index => $project) {
        $p = is_array($project) ? $project : [];
        $projectUuid = textValue($p['id'] ?? '') ?: uuidv4();
        $stmt->execute([
            $workspaceId,
            $projectUuid,
            $projectType,
            $index,
            textValue($p['title'] ?? ''),
            textValue($p['color'] ?? ''),
            boolValue($p['isRepeatable'] ?? false),
            textValue($p['repeatVariable'] ?? ''),
            jsonText($p),
        ]);
        $projectId = (int)$pdo->lastInsertId();
        $inserted++;

        foreach (array_values(arr($p['participants'] ?? [])) as $participantIndex => $participant) {
            $participantStmt->execute([$projectId, $participantIndex, textValue($participant)]);
        }

        insertActiveProjectLogic($pdo, $projectId, $p);
        insertNodes($pdo, $projectId, arr($p['nodes'] ?? []));
    }

    return $inserted;
}

function saveSuite(PDO $pdo, array $data): array
{
    $workspaceId = textValue($data['workspaceId'] ?? $data['id'] ?? '') ?: uuidv4();
    $sessionId = textValue($data['serverSessionId'] ?? $data['sessionId'] ?? $_GET['sessionId'] ?? '');
    if ($sessionId === '') $sessionId = generateUniqueSessionId($pdo);
    $userId = currentUserId($pdo);
    if ($userId <= 0) {
        respondJson(['ok' => false, 'error' => 'You must be logged in before pushing Dialogue Designer data to the server.'], 401);
    }
    $rawJson = jsonText($data);

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('INSERT INTO FSG_DD_Workspaces (workspace_uuid, session_id, user_id, version, current_language, available_languages_json, raw_json) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            $workspaceId,
            $sessionId,
            $userId,
            textValue($data['version'] ?? ''),
            textValue($data['currentLanguage'] ?? 'ENG') ?: 'ENG',
            jsonText(arr($data['availableLanguages'] ?? ['ENG'])),
            $rawJson,
        ]);
        $workspacePk = (int)$pdo->lastInsertId();

        $snapshotStmt = $pdo->prepare('INSERT INTO FSG_DD_RawJsonSnapshots (workspace_id, snapshot_label, raw_json) VALUES (?, ?, ?)');
        $snapshotStmt->execute([$workspacePk, 'Full Workspace Save', $rawJson]);

        insertLanguages($pdo, $workspacePk, arr($data['availableLanguages'] ?? ['ENG']));
        insertCast($pdo, $workspacePk, arr($data['cast'] ?? []));
        insertGlobalTokens($pdo, $workspacePk, arr($data['globalTokens'] ?? []));
        insertNamedGlobals($pdo, $workspacePk, 'FSG_DD_GlobalStates', arr($data['globalStates'] ?? []));
        insertNamedGlobals($pdo, $workspacePk, 'FSG_DD_GlobalMoods', arr($data['globalMoods'] ?? []));
        insertNamedGlobals($pdo, $workspacePk, 'FSG_DD_GlobalSettings', arr($data['globalSettings'] ?? []));
        insertNamedGlobals($pdo, $workspacePk, 'FSG_DD_GlobalTimesOfDay', arr($data['globalTimesOfDay'] ?? []));
        insertNamedGlobals($pdo, $workspacePk, 'FSG_DD_GlobalDaysOfWeek', arr($data['globalDaysOfWeek'] ?? []));
        insertNamedGlobals($pdo, $workspacePk, 'FSG_DD_GlobalMenuOptions', arr($data['globalMenuOptions'] ?? []));
        insertImageSequences($pdo, $workspacePk, arr($data['globalImageSequences'] ?? []));

        $conversationCount = insertProjects($pdo, $workspacePk, 'conversation', arr($data['conversations'] ?? []));
        $sequenceCount = insertProjects($pdo, $workspacePk, 'sequence', arr($data['sequences'] ?? []));
        attachWorkspaceToUserSession($pdo, $sessionId, $userId);

        $pdo->commit();
        $account = authPayload($pdo);
        return [
            'workspaceId' => $workspaceId,
            'sessionId' => $sessionId,
            'databaseId' => $workspacePk,
            'conversationCount' => $conversationCount,
            'sequenceCount' => $sequenceCount,
            'attachedToUserId' => $userId,
            'account' => $account,
            'sessions' => $account['sessions'] ?? [],
        ];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function loadLatestSuite(PDO $pdo, string $sessionId = ''): array
{
    $sessionId = trim($sessionId);
    if ($sessionId !== '') {
        $stmt = $pdo->prepare('SELECT workspace_uuid, session_id, raw_json, created_at FROM FSG_DD_Workspaces WHERE session_id = ? ORDER BY id DESC LIMIT 1');
        $stmt->execute([$sessionId]);
    } else {
        $stmt = $pdo->query('SELECT workspace_uuid, session_id, raw_json, created_at FROM FSG_DD_Workspaces ORDER BY id DESC LIMIT 1');
    }

    $row = $stmt->fetch();
    if (!$row) {
        return [
            'hasWorkspace' => false,
            'workspaceId' => '',
            'sessionId' => $sessionId,
            'createdAt' => '',
            'data' => null,
            'message' => $sessionId !== '' ? "No saved DialogueDesigner workspace exists yet for this session." : "No saved DialogueDesigner workspace exists yet."
        ];
    }

    $data = json_decode($row['raw_json'], true);
    if (!is_array($data)) {
        respondJson(['ok' => false, 'error' => 'Latest workspace raw_json is not valid JSON.'], 500);
    }

    touchUserSessionViewed($pdo, textValue($row['session_id'] ?? $sessionId));

    return [
        'workspaceId' => $row['workspace_uuid'],
        'sessionId' => $row['session_id'],
        'createdAt' => $row['created_at'],
        'data' => $data,
    ];
}

function listSavedSuites(PDO $pdo): array
{
    $stmt = $pdo->query('SELECT id, workspace_uuid, session_id, version, current_language, created_at, updated_at FROM FSG_DD_Workspaces ORDER BY id DESC LIMIT 100');
    return $stmt->fetchAll();
}

try {
    $action = $_GET['action'] ?? '';
    $body = requestBody();
    if ($action === '' && isset($body['action'])) {
        $action = textValue($body['action']);
    }
    if ($action === '') {
        $action = $_SERVER['REQUEST_METHOD'] === 'GET' ? 'health' : 'saveSuite';
    }

    $pdo = dbConnection();
    ensureAccountTables($pdo);

    if ($action === 'health') {
        respondJson(['ok' => true, 'api' => 'DialogueDesigner', 'database' => 'connected']);
    }

    if ($action === 'authStatus') {
        respondJson(['ok' => true] + authPayload($pdo));
    }

    if ($action === 'register') {
        respondJson(['ok' => true] + registerAccount($pdo, $body));
    }

    if ($action === 'login') {
        respondJson(['ok' => true] + loginAccount($pdo, $body));
    }

    if ($action === 'logout') {
        if (function_exists('fsgAuth_logout')) fsgAuth_logout($pdo);
        else session_destroy();
        respondJson(['ok' => true, 'loggedIn' => false, 'user' => null, 'sessions' => []]);
    }

    if ($action === 'updateProfile') {
        respondJson(['ok' => true] + updateProfile($pdo, $body));
    }

    if ($action === 'changePassword') {
        respondJson(['ok' => true] + changePassword($pdo, $body));
    }

    if ($action === 'generateSessionId') {
        respondJson(['ok' => true, 'sessionId' => generateUniqueSessionId($pdo)]);
    }

    if ($action === 'saveSuite') {
        $data = isset($body['data']) && is_array($body['data']) ? $body['data'] : $body;
        if (!$data) {
            respondJson(['ok' => false, 'error' => 'No workspace JSON was sent.'], 400);
        }
        $saved = saveSuite($pdo, $data);
        respondJson(['ok' => true] + $saved);
    }

    if ($action === 'loadLatestSuite') {
        respondJson(['ok' => true] + loadLatestSuite($pdo, textValue($_GET['sessionId'] ?? $body['sessionId'] ?? '')));
    }

    if ($action === 'listSuites') {
        respondJson(['ok' => true, 'suites' => listSavedSuites($pdo)]);
    }

    respondJson(['ok' => false, 'error' => 'Unknown action.'], 404);
} catch (Throwable $e) {
    respondJson(['ok' => false, 'error' => $e->getMessage()], 500);
}
