document.addEventListener('DOMContentLoaded', () => {
    // --- API Configuration ---
    const API_ENDPOINT = 'api9.php';

    // --- DOM Elements ---
    const mainContent = document.getElementById('main-content');
    const mapCanvas = document.getElementById('map-canvas');
    const bgImage = document.getElementById('map-background');
    const nodeLinesSvg = document.getElementById('node-lines');

    const addPoiModal = document.getElementById('add-poi-modal');
    const assetsModal = document.getElementById('map-assets-modal');
    const renderModal = document.getElementById('render-modal');
    const editorModal = document.getElementById('editor-modal');

    const newMapBtn = document.getElementById('new-map-btn');
    const mapSelector = document.getElementById('map-selector');
    const pushBtn = document.getElementById('push-btn');
    const renderBtn = document.getElementById('render-btn');
    const importBtn = document.getElementById('import-btn');
    const exportBtn = document.getElementById('export-btn');
    const importFile = document.getElementById('import-file');
    const deleteSelectedBtn = document.getElementById('delete-selected-btn');

    const toolButtons = {
        move: document.getElementById('tool-move'),
        scale: document.getElementById('tool-scale'),
        rotate: document.getElementById('tool-rotate'),
    };

    const addPoiBtn = document.getElementById('add-poi-btn');
    const createPoiBtn = document.getElementById('create-poi-btn');
    const poiLabelInput = document.getElementById('poi-label-input');
    const poiFontSelect = document.getElementById('poi-font-select');
    const poiFontColorInput = document.getElementById('poi-font-color-input');
    const poiColorInput = document.getElementById('poi-color-input');

    const assetsModalBtn = document.getElementById('assets-modal-btn');
    const bgUrlInput = document.getElementById('bg-url');
    const bgScaleSlider = document.getElementById('bg-scale');
    const bgScaleValue = document.getElementById('bg-scale-value');
    const bgRotateSlider = document.getElementById('bg-rotate');
    const bgRotateValue = document.getElementById('bg-rotate-value');
    const bgPosXSlider = document.getElementById('bg-pos-x');
    const bgPosXValue = document.getElementById('bg-pos-x-value');
    const bgPosYSlider = document.getElementById('bg-pos-y');
    const bgPosYValue = document.getElementById('bg-pos-y-value');
    const assetUrlsContainer = document.getElementById('asset-urls-container');
    const addAssetUrlBtn = document.getElementById('add-asset-url-btn');
    const spawnAssetsBtn = document.getElementById('spawn-assets-btn');

    const addNodeBtn = document.getElementById('add-node-btn');
    const addNoteBtn = document.getElementById('add-note-btn');

    const renderMapSelector = document.getElementById('render-map-selector');
    const renderWidthInput = document.getElementById('render-width');
    const renderHeightInput = document.getElementById('render-height');
    const generateImageBtn = document.getElementById('generate-image-btn');

    const editorTitle = document.getElementById('editor-title');
    const editorLabelInput = document.getElementById('editor-label-input');
    const editorFontSelect = document.getElementById('editor-font-select');
    const editorLabelVisibleCheckbox = document.getElementById('editor-label-visible-checkbox');
    const editorIconColorInput = document.getElementById('editor-icon-color-input');
    const editorFontColorInput = document.getElementById('editor-font-color-input');
    const editorGlowColorInput = document.getElementById('editor-glow-color-input');
    const applyEditorChangesBtn = document.getElementById('apply-editor-changes-btn');

    const editorGroups = {
        label: document.getElementById('editor-group-label'),
        font: document.getElementById('editor-group-font'),
        labelVisible: document.getElementById('editor-group-label-visible'),
        iconColor: document.getElementById('editor-group-icon-color'),
        fontColor: document.getElementById('editor-group-font-color'),
        glowColor: document.getElementById('editor-group-glow-color'),
    };

    document.querySelectorAll('.modal .close-btn').forEach(btn => {
        btn.onclick = () => btn.closest('.modal').style.display = 'none';
    });

    // --- State Management ---
    let allMaps = {};
    let currentMapId = null;
    let isDirty = false;
    let activeTool = 'move';
    let selectedElement = { type: null, id: null, element: null };
    let editedElementId = null;
    let isDragging = false;
    let isPanning = false;
    let dragStart = { x: 0, y: 0 };
    let elementStart = { x: 0, y: 0 };
    let panStart = { x:0, y:0, scrollLeft:0, scrollTop:0 };
    let shiftSelectStartNode = null; // For connecting nodes

    // --- Core Functions ---

    function getMapData() {
        return allMaps[currentMapId] || null;
    }

    function getViewportCenter() {
        const rect = mainContent.getBoundingClientRect();
        const centerX = mainContent.scrollLeft + rect.width / 2;
        const centerY = mainContent.scrollTop + rect.height / 2;
        // Add a little randomness so items don't stack perfectly
        const randomOffsetX = Math.random() * 80 - 40;
        const randomOffsetY = Math.random() * 80 - 40;
        return { x: centerX + randomOffsetX, y: centerY + randomOffsetY };
    }

    function createNewMap(name, data = null, id = null) {
        const newId = (data && data.id) ? data.id : (id || `map_${Date.now()}`);

        if (!data) {
            data = {
                id: newId,
                name: name,
                background: { url: '', baseWidth: 4000, baseHeight: 4000, scale: 1, rotation: 0, x: 0, y: 0 },
                assets: [],
                pois: [],
                nodes: [],       // Now a flat array of node objects
                connections: [], // Stores connections like {from: 'nodeId1', to: 'nodeId2'}
                notes: []
            };
        }

        data.id = newId;

        allMaps[newId] = data;

        currentMapId = newId;
        updateMapSelector();
        loadMap(newId);
        setDirty(true);
        return newId;
    }

    function loadMap(mapId) {
        if (isDirty && currentMapId !== mapId) {
            if (!confirm("You have unsaved changes. Are you sure you want to switch maps?")) {
                mapSelector.value = currentMapId;
                return;
            }
        }
        currentMapId = mapId;
        const mapData = getMapData();
        if (!mapData) return;

        // --- NEW: Automatic Migration for Old Map Format ---
        if (mapData.nodes && mapData.nodes.length > 0 && Array.isArray(mapData.nodes[0])) {
            console.warn("Old map format detected. Migrating to new branching format.");
            const oldPaths = mapData.nodes;
            const newNodes = [];
            const newConnections = [];
            const addedNodeIds = new Set();

            oldPaths.forEach(path => {
                for (let i = 0; i < path.length; i++) {
                    const node = path[i];
                    if (!addedNodeIds.has(node.id)) {
                        newNodes.push(node);
                        addedNodeIds.add(node.id);
                    }
                    if (i > 0) {
                        const prevNode = path[i - 1];
                        newConnections.push({ from: prevNode.id, to: node.id });
                    }
                }
            });
            mapData.nodes = newNodes;
            mapData.connections = newConnections;
            setDirty(true); // Mark for saving in the new format
        }

        // Ensure default properties exist
        mapData.background = mapData.background || { url: '', baseWidth: 4000, baseHeight: 4000, scale: 1, rotation: 0, x: 0, y: 0 };
        mapData.assets = mapData.assets || [];
        mapData.pois = mapData.pois || [];
        mapData.notes = mapData.notes || [];
        mapData.nodes = mapData.nodes || [];
        mapData.connections = mapData.connections || [];

        bgUrlInput.value = mapData.background.url;
        bgScaleSlider.value = mapData.background.scale;
        bgScaleValue.textContent = `${parseFloat(mapData.background.scale).toFixed(2)}x`;
        bgRotateSlider.value = mapData.background.rotation;
        bgRotateValue.textContent = `${mapData.background.rotation}°`;
        bgPosXSlider.value = mapData.background.x;
        bgPosXValue.textContent = `${mapData.background.x}px`;
        bgPosYSlider.value = mapData.background.y;
        bgPosYValue.textContent = `${mapData.background.y}px`;

        renderMap();
        setDirty(false);
    }

    function updateMapSelector() {
        mapSelector.innerHTML = '';
        renderMapSelector.innerHTML = '';

        const sortedMaps = Object.values(allMaps).sort((a, b) => a.name.localeCompare(b.name));

        sortedMaps.forEach(map => {
            const option = new Option(map.name, map.id);
            mapSelector.add(option.cloneNode(true));
            renderMapSelector.add(option);
        });

        if (allMaps[currentMapId]) {
            mapSelector.value = currentMapId;
            renderMapSelector.value = currentMapId;
        }
    }

    function setDirty(state) {
        isDirty = state;
        pushBtn.classList.toggle('dirty', isDirty);
    }

    function renderMap() {
        const mapData = getMapData();
        if (!mapData) return;

        bgImage.src = mapData.background.url;
        const bgWidth = (mapData.background.baseWidth || 4000) * mapData.background.scale;
        const bgHeight = (mapData.background.baseHeight || 4000) * mapData.background.scale;
        bgImage.style.width = `${bgWidth}px`;
        bgImage.style.height = `${bgHeight}px`;
        bgImage.style.left = `calc(50% + ${mapData.background.x}px)`;
        bgImage.style.top = `calc(50% + ${mapData.background.y}px)`;
        bgImage.style.transform = `translate(-50%, -50%) rotate(${mapData.background.rotation}deg)`;

        mapCanvas.querySelectorAll('.map-asset, .poi, .node, .note-box').forEach(el => el.remove());

        renderAssets(mapData.assets);
        renderPois(mapData.pois);
        renderNodes(mapData.nodes); // Renders individual nodes
        renderNotes(mapData.notes);
        renderNodeLines(mapData.nodes, mapData.connections); // Renders connections between nodes
    }

    function renderAssets(assets) {
        assets.forEach(asset => {
            const el = document.createElement('div');
            el.className = 'map-asset';
            el.dataset.id = asset.id;
            el.dataset.type = 'asset';
            el.style.left = `${asset.x}px`;
            el.style.top = `${asset.y}px`;
            el.style.width = `${asset.width}px`;
            el.style.transform = `scale(${asset.scale}) rotate(${asset.rotation}deg)`;
            const img = document.createElement('img');
            img.src = asset.url;
            el.appendChild(img);
            mapCanvas.appendChild(el);
        });
    }

    function renderPois(pois) {
        pois.forEach(poi => {
            const el = document.createElement('div');
            el.className = 'poi';
            el.dataset.id = poi.id;
            el.dataset.type = 'poi';
            const label = (poi.label && poi.labelVisible) ? `<div class="label" style="font-family: ${poi.fontFamily || 'var(--font-family)'}; color: ${poi.fontColor || 'var(--color-text)'};">${poi.label}</div>` : '';
            const icon = `<div class="poi-icon" style="background-color: ${poi.color || 'var(--color-primary)'}; box-shadow: 0 0 15px ${poi.glowColor || poi.color};"></div>`;
            el.innerHTML = label + icon;
            el.style.left = `${poi.x}px`;
            el.style.top = `${poi.y}px`;
            mapCanvas.appendChild(el);
        });
    }

    function renderNodes(nodes) {
        if (!nodes) return;
        nodes.forEach(node => {
            const el = document.createElement('div');
            el.className = 'node';
            el.dataset.id = node.id;
            el.dataset.type = 'node';
            const icon = `<div class="node-icon" style="background-color: ${node.color || 'var(--color-accent)'}; box-shadow: 0 0 15px ${node.glowColor || node.color};"></div>`;
            const label = (node.label && node.labelVisible) ? `<div class="label" style="font-family: ${node.fontFamily || 'var(--font-family)'}; color: ${node.fontColor || 'var(--color-text)'};">${node.label}</div>` : '';
            el.innerHTML = label + icon;
            el.style.left = `${node.x}px`;
            el.style.top = `${node.y}px`;
            mapCanvas.appendChild(el);
        });
    }

    function renderNotes(notes) {
        notes.forEach(note => {
            const el = document.createElement('div');
            el.className = 'note-box';
            el.dataset.id = note.id;
            el.dataset.type = 'note';
            el.style.left = `${note.x}px`;
            el.style.top = `${note.y}px`;
            el.style.width = `${note.width}px`;
            el.style.backgroundColor = note.bgColor;
            el.style.color = note.textColor;
            el.style.boxShadow = `0 0 15px ${note.glowColor || 'rgba(0,0,0,0)'}`;
            const textEl = document.createElement('div');
            textEl.className = 'note-box-text';
            textEl.textContent = note.text;
            el.appendChild(textEl);
            mapCanvas.appendChild(el);
        });
    }

    function renderNodeLines(nodes, connections) {
        nodeLinesSvg.innerHTML = '';
        if (!connections || !nodes) return;

        const nodeMap = new Map(nodes.map(node => [node.id, node])); // Create a lookup map for efficiency

        connections.forEach(conn => {
            const startNode = nodeMap.get(conn.from);
            const endNode = nodeMap.get(conn.to);

            if (startNode && endNode) {
                const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
                line.setAttribute('x1', startNode.x + 8); line.setAttribute('y1', startNode.y + 8);
                line.setAttribute('x2', endNode.x + 8); line.setAttribute('y2', endNode.y + 8);
                line.setAttribute('stroke', 'white'); line.setAttribute('stroke-width', '4');
                line.setAttribute('stroke-dasharray', '5,5'); line.setAttribute('stroke-opacity', '0.7');
                line.dataset.from = conn.from; // For identification
                line.dataset.to = conn.to;     // For identification
                line.dataset.type = 'line';
                nodeLinesSvg.appendChild(line);
            }
        });
    }

    function setActiveTool(tool) {
        if (!toolButtons[tool]) return;
        activeTool = tool;
        Object.values(toolButtons).forEach(btn => btn.classList.remove('active'));
        toolButtons[tool].classList.add('active');

        if (selectedElement.element) {
            createInteractionSlider();
        } else {
            deselectElement();
        }
    }

    function generateId() {
        return `id_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    function selectElement(type, id, element) {
        deselectElement();
        selectedElement = { type, id, element };
        if (element) {
            element.classList.add('selected');
        }
        deleteSelectedBtn.disabled = false;

        createInteractionSlider();
    }

    function deselectElement() {
        if (selectedElement.element) {
            selectedElement.element.classList.remove('selected');
        }
        selectedElement = { type: null, id: null, element: null };
        deleteSelectedBtn.disabled = true;
        document.querySelector('.interaction-slider')?.remove();
    }

    function createInteractionSlider() {
        document.querySelector('.interaction-slider')?.remove();
        if (!selectedElement.element || selectedElement.type !== 'asset' || (activeTool !== 'scale' && activeTool !== 'rotate')) return;

        const assetData = getMapData().assets.find(a => a.id === selectedElement.id);
        if (!assetData) return;

        const sliderContainer = document.createElement('div');
        sliderContainer.className = 'interaction-slider';

        const slider = document.createElement('input');
        slider.type = 'range';

        if (activeTool === 'scale') {
            slider.min = 0.1; slider.max = 5; slider.step = 0.05; slider.value = assetData.scale;
        } else if (activeTool === 'rotate') {
            slider.min = 0; slider.max = 360; slider.step = 1; slider.value = assetData.rotation;
        }

        slider.addEventListener('input', (e) => {
            const value = parseFloat(e.target.value);
            if (activeTool === 'scale') {
                assetData.scale = value;
            } else if (activeTool === 'rotate') {
                assetData.rotation = value;
            }
            selectedElement.element.style.transform = `scale(${assetData.scale}) rotate(${assetData.rotation}deg)`;
            setDirty(true);
        });

        sliderContainer.appendChild(slider);
        mapCanvas.appendChild(sliderContainer);

        const elRect = selectedElement.element.getBoundingClientRect();
        sliderContainer.style.left = `${selectedElement.element.offsetLeft}px`;
        sliderContainer.style.top = `${selectedElement.element.offsetTop + elRect.height + 10}px`;
    }

    function addAssetUrlField(url = '') {
        const div = document.createElement('div');
        div.className = 'asset-url-item';
        div.innerHTML = `
            <input type="checkbox" checked style="width: 20px; height: 20px; flex-shrink: 0;">
            <input type="text" class="asset-url-input" placeholder="https://example.com/asset.png" value="${url}">
            <input type="number" class="asset-quantity" value="1" min="1">
            <button class="btn">X</button>
        `;
        div.querySelector('button').onclick = () => div.remove();
        assetUrlsContainer.appendChild(div);
    }

    function openEditorModal(element, type, id) {
        editedElementId = id;
        const mapData = getMapData();
        let data;

        switch(type) {
            case 'poi': data = mapData.pois.find(d => d.id === id); editorTitle.textContent = 'Edit POI'; break;
            case 'node': data = mapData.nodes.find(d => d.id === id); editorTitle.textContent = 'Edit Node'; break;
            case 'note': data = mapData.notes.find(d => d.id === id); editorTitle.textContent = 'Edit Note'; break;
            default: return;
        }
        if (!data) return;

        const isPoiOrNode = type === 'poi' || type === 'node';
        editorGroups.label.style.display = isPoiOrNode ? 'block' : 'none';
        editorGroups.font.style.display = isPoiOrNode ? 'block' : 'none';
        editorGroups.labelVisible.style.display = isPoiOrNode ? 'block' : 'none';
        editorGroups.fontColor.style.display = isPoiOrNode ? 'block' : 'none';
        editorGroups.iconColor.style.display = isPoiOrNode || type === 'note' ? 'block' : 'none';
        editorGroups.glowColor.style.display = isPoiOrNode || type === 'note' ? 'block' : 'none';

        if (isPoiOrNode) {
            editorGroups.iconColor.querySelector('label').textContent = 'Icon Color';
            editorGroups.label.querySelector('label').textContent = 'Label';
            editorLabelInput.value = data.label || '';
            editorFontSelect.value = data.fontFamily || 'Rajdhani, sans-serif';
            editorLabelVisibleCheckbox.checked = data.labelVisible !== false;
            editorIconColorInput.value = data.color || '#000000';
            editorFontColorInput.value = data.fontColor || '#EAEAEA';
            editorGlowColorInput.value = data.glowColor || data.color || '#000000';
        } else if (type === 'note') {
            editorGroups.iconColor.querySelector('label').textContent = 'Background Color';
            editorGroups.label.style.display = 'block';
            editorGroups.label.querySelector('label').textContent = 'Note Text';
            editorGroups.fontColor.style.display = 'block';
            editorGroups.fontColor.querySelector('label').textContent = 'Text Color';

            editorLabelInput.value = data.text || '';
            editorIconColorInput.value = data.bgColor || '#141418';
            editorFontColorInput.value = data.textColor || '#EAEAEA';
            editorGlowColorInput.value = data.glowColor || '#000000';
        }

        editorModal.style.display = 'flex';
    }

    applyEditorChangesBtn.addEventListener('click', () => {
        if (!editedElementId) return;

        const mapData = getMapData();
        const elementDOM = document.querySelector(`[data-id='${editedElementId}']`);
        if (!elementDOM) return;

        const type = elementDOM.dataset.type;
        let data;

        switch(type) {
            case 'poi': data = mapData.pois.find(d => d.id === editedElementId); break;
            case 'node': data = mapData.nodes.find(d => d.id === editedElementId); break;
            case 'note': data = mapData.notes.find(d => d.id === editedElementId); break;
            default: return;
        }
        if (!data) return;

        if (type === 'poi' || type === 'node') {
            data.label = editorLabelInput.value;
            data.fontFamily = editorFontSelect.value;
            data.labelVisible = editorLabelVisibleCheckbox.checked;
            data.color = editorIconColorInput.value;
            data.fontColor = editorFontColorInput.value;
            data.glowColor = editorGlowColorInput.value;
        } else if (type === 'note') {
            data.text = editorLabelInput.value;
            data.bgColor = editorIconColorInput.value;
            data.textColor = editorFontColorInput.value;
            data.glowColor = editorGlowColorInput.value;
        }

        renderMap();
        setDirty(true);
        editorModal.style.display = 'none';
        editedElementId = null;
    });

    // --- Event Listeners ---

    newMapBtn.addEventListener('click', () => {
        const name = prompt("Enter a name for the new map:");
        if (name) createNewMap(name);
    });
    mapSelector.addEventListener('change', (e) => loadMap(e.target.value));

    addPoiBtn.addEventListener('click', () => addPoiModal.style.display = 'flex');
    assetsModalBtn.addEventListener('click', () => assetsModal.style.display = 'flex');
    renderBtn.addEventListener('click', () => renderModal.style.display = 'flex');

    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.style.display = 'none';
        }
        const line = e.target.closest('line');
        if (line) {
            // Create a stable, parsable ID from the node IDs stored on the line
            const fromId = line.dataset.from;
            const toId = line.dataset.to;
            const lineId = `line#${fromId}#${toId}`; // Use '#' as a safe separator
            selectElement('line', lineId, line);
        } else if (!e.target.closest('.map-asset, .poi, .node, .note-box, .header, .interaction-slider, .modal')) {
            deselectElement();
        }
    });

    createPoiBtn.addEventListener('click', () => {
        const { x, y } = getViewportCenter();
        const color = poiColorInput.value;
        getMapData().pois.push({
            id: generateId(),
            label: poiLabelInput.value || 'POI',
            x: x, y: y,
            fontFamily: poiFontSelect.value,
            fontColor: poiFontColorInput.value,
            color: color,
            glowColor: color,
            labelVisible: true,
        });
        renderMap();
        setDirty(true);
        addPoiModal.style.display = 'none';
        poiLabelInput.value = '';
        poiFontSelect.value = 'Rajdhani, sans-serif';
        poiFontColorInput.value = '#EAEAEA';
        poiColorInput.value = '#D90429';
    });

    addAssetUrlBtn.addEventListener('click', () => addAssetUrlField());

    spawnAssetsBtn.addEventListener('click', () => {
        const mapData = getMapData();
        const assetItems = assetUrlsContainer.querySelectorAll('.asset-url-item');

        assetItems.forEach(item => {
            const checkbox = item.querySelector('input[type="checkbox"]');
            if (checkbox.checked) {
                const url = item.querySelector('.asset-url-input').value;
                const quantity = parseInt(item.querySelector('.asset-quantity').value, 10) || 1;
                if (url) {
                    for (let i = 0; i < quantity; i++) {
                        const img = new Image();
                        img.onload = () => {
                            const { x, y } = getViewportCenter();
                            mapData.assets.push({
                                id: generateId(), url: url,
                                x: x,
                                y: y,
                                width: img.naturalWidth > 300 ? 300 : img.naturalWidth,
                                scale: 1, rotation: 0
                            });
                            renderMap(); setDirty(true);
                        };
                        img.onerror = () => console.warn(`Could not load image: ${url}`);
                        img.src = url;
                    }
                }
            }
        });
        assetsModal.style.display = 'none';
    });

    const updateBg = () => { renderMap(); setDirty(true); };
    bgUrlInput.addEventListener('input', e => { getMapData().background.url = e.target.value; updateBg(); });
    bgScaleSlider.addEventListener('input', e => {
        getMapData().background.scale = e.target.value;
        bgScaleValue.textContent = `${parseFloat(e.target.value).toFixed(2)}x`;
        updateBg();
    });
    bgRotateSlider.addEventListener('input', e => {
        getMapData().background.rotation = e.target.value;
        bgRotateValue.textContent = `${e.target.value}°`;
        updateBg();
    });
    bgPosXSlider.addEventListener('input', e => {
        getMapData().background.x = parseInt(e.target.value, 10);
        bgPosXValue.textContent = `${e.target.value}px`;
        updateBg();
    });
    bgPosYSlider.addEventListener('input', e => {
        getMapData().background.y = parseInt(e.target.value, 10);
        bgPosYValue.textContent = `${e.target.value}px`;
        updateBg();
    });

    Object.keys(toolButtons).forEach(tool => toolButtons[tool].addEventListener('click', () => setActiveTool(tool)));

    mapCanvas.addEventListener('mousedown', (e) => {
        if (e.target.type === 'range' || e.button === 2) return;

        const targetEl = e.target.closest('.map-asset, .poi, .node, .note-box');
        const mapData = getMapData();

        // --- SHIFT-CLICK LOGIC TO CONNECT NODES ---
        if (e.shiftKey && targetEl && targetEl.dataset.type === 'node') {
            e.preventDefault();
            const clickedNodeId = targetEl.dataset.id;

            if (!shiftSelectStartNode) {
                // First node clicked with Shift.
                shiftSelectStartNode = { id: clickedNodeId };
                selectElement('node', clickedNodeId, targetEl);
            } else {
                // Second node. Time to connect.
                if (shiftSelectStartNode.id === clickedNodeId) return; // Ignore clicking same node twice

                const startId = shiftSelectStartNode.id;
                const endId = clickedNodeId;

                // Check if connection already exists in either direction
                const connectionExists = mapData.connections.some(
                    c => (c.from === startId && c.to === endId) || (c.from === endId && c.to === startId)
                );

                if (!connectionExists) {
                    mapData.connections.push({ from: startId, to: endId });
                    setDirty(true);
                    renderMap();
                }

                // Reset for the next operation
                shiftSelectStartNode = null;
                deselectElement();
            }
            return; // Stop further processing
        }

        // If a normal click happens, cancel any pending shift-select operation
        if (shiftSelectStartNode) {
            shiftSelectStartNode = null;
            deselectElement();
        }

        // --- ORIGINAL CLICK AND PAN LOGIC ---
        if (targetEl) {
            selectElement(targetEl.dataset.type, targetEl.dataset.id, targetEl);
            if (activeTool === 'move') {
                isDragging = true;
                dragStart = { x: e.clientX, y: e.clientY };
                elementStart = { x: targetEl.offsetLeft, y: targetEl.offsetTop };
            }
        } else if (!e.target.closest('line, .interaction-slider')) {
            isPanning = true;
            mapCanvas.classList.add('panning');
            panStart = { x: e.clientX, y: e.clientY, scrollLeft: mainContent.scrollLeft, scrollTop: mainContent.scrollTop };
        }
    });

    window.addEventListener('mousemove', (e) => {
        if (isDragging && selectedElement.element) {
            const dx = e.clientX - dragStart.x;
            const dy = e.clientY - dragStart.y;
            selectedElement.element.style.left = `${elementStart.x + dx}px`;
            selectedElement.element.style.top = `${elementStart.y + dy}px`;
            createInteractionSlider();
        } else if (isPanning) {
            const dx = e.clientX - panStart.x;
            const dy = e.clientY - panStart.y;
            mainContent.scrollLeft = panStart.scrollLeft - dx;
            mainContent.scrollTop = panStart.scrollTop - dy;
        }
    });

    window.addEventListener('mouseup', () => {
        if (isDragging && selectedElement.id) {
            const mapData = getMapData();
            let dataObj;
            switch(selectedElement.type) {
                case 'asset': dataObj = mapData.assets.find(item => item.id === selectedElement.id); break;
                case 'poi': dataObj = mapData.pois.find(item => item.id === selectedElement.id); break;
                case 'node': dataObj = mapData.nodes.find(item => item.id === selectedElement.id); break;
                case 'note': dataObj = mapData.notes.find(item => item.id === selectedElement.id); break;
            }
            if (dataObj) {
                dataObj.x = selectedElement.element.offsetLeft;
                dataObj.y = selectedElement.element.offsetTop;
                if(selectedElement.type === 'node') renderNodeLines(mapData.nodes, mapData.connections);
                setDirty(true);
            }
        }
        isDragging = false;
        isPanning = false;
        mapCanvas.classList.remove('panning');
    });

    mapCanvas.addEventListener('contextmenu', (e) => {
        const targetEl = e.target.closest('.poi, .node, .note-box');
        if (targetEl) {
            e.preventDefault();
            openEditorModal(targetEl, targetEl.dataset.type, targetEl.dataset.id);
        }
    });

    mapCanvas.addEventListener('dblclick', (e) => {
        const noteEl = e.target.closest('.note-box');
        if (noteEl) {
            const noteData = getMapData().notes.find(n => n.id === noteEl.dataset.id);
            if (!noteData) return;
            const textEl = noteEl.querySelector('.note-box-text');
            if (!textEl || noteEl.querySelector('textarea')) return;
            const textarea = document.createElement('textarea');
            textarea.value = noteData.text;
            textarea.addEventListener('blur', () => {
                noteData.text = textarea.value;
                textEl.textContent = noteData.text;
                noteEl.replaceChild(textEl, textarea);
                setDirty(true);
            });
            noteEl.replaceChild(textarea, textEl);
            textarea.focus();
        }
    });

    addNodeBtn.addEventListener('click', () => {
        const mapData = getMapData();
        if (!mapData) return;
        const { x, y } = getViewportCenter();

        const color = '#F7B538';
        const newNode = { id: generateId(), x: x, y: y, label: '', color, glowColor: color, fontFamily: 'Rajdhani, sans-serif', fontColor: '#EAEAEA', labelVisible: true };

        if (selectedElement.type === 'node' && selectedElement.element) {
            const parentNode = mapData.nodes.find(n => n.id === selectedElement.id);
            if(parentNode) {
                newNode.x = parentNode.x + 80 + (Math.random() * 40 - 20);
                newNode.y = parentNode.y + (Math.random() * 40 - 20);
                mapData.connections.push({ from: parentNode.id, to: newNode.id });
            }
        }

        mapData.nodes.push(newNode);
        renderMap();
        setDirty(true);
    });

    addNoteBtn.addEventListener('click', () => {
        const { x, y } = getViewportCenter();
        getMapData().notes.push({ id: generateId(), x: x, y: y, width: '200px', text: 'Double-click to edit...', bgColor: 'rgba(20, 20, 24, 0.9)', textColor: '#EAEAEA', glowColor: '#000000' });
        renderMap();
        setDirty(true);
    });

    deleteSelectedBtn.addEventListener('click', () => {
        if (!selectedElement.type || !selectedElement.id) return;
        const mapData = getMapData();

        switch(selectedElement.type) {
            case 'asset':
                mapData.assets = mapData.assets.filter(item => item.id !== selectedElement.id);
                break;
            case 'poi':
                mapData.pois = mapData.pois.filter(item => item.id !== selectedElement.id);
                break;
            case 'note':
                mapData.notes = mapData.notes.filter(item => item.id !== selectedElement.id);
                break;
            case 'node':
                const nodeIdToDelete = selectedElement.id;
                // Remove the node itself
                mapData.nodes = mapData.nodes.filter(n => n.id !== nodeIdToDelete);
                // Remove all connections to/from that node
                mapData.connections = mapData.connections.filter(c => c.from !== nodeIdToDelete && c.to !== nodeIdToDelete);
                break;
            case 'line':
                // The ID is now "line#FROMID#TOID"
                const [_, fromId, toId] = selectedElement.id.split('#');

                // Filter out the connection, checking for both directions
                mapData.connections = mapData.connections.filter(c =>
                    !((c.from === fromId && c.to === toId) || (c.from === toId && c.to === fromId))
                );
                break;
        }

        deselectElement();
        renderMap();
        setDirty(true);
    });

    // --- Server Communication, Import/Export ---
    async function fetchAllMaps() {
        try {
            const response = await fetch(`${API_ENDPOINT}?action=list`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const maps = await response.json();

            allMaps = maps.reduce((acc, map) => {
                try {
                    const mapData = JSON.parse(map.map_data);
                    acc[map.id] = { ...map, ...mapData };
                    delete acc[map.id].map_data;
                } catch (e) { console.error(`Failed to parse map_data for map ID ${map.id}:`, e); }
                return acc;
            }, {});

            updateMapSelector();
            const mapIds = Object.keys(allMaps);
            if (mapIds.length > 0) {
                loadMap(mapIds[0]);
            } else {
                createNewMap("Default Map");
            }
        } catch (error) {
            console.error('Error fetching maps:', error);
            alert('Could not connect to the server. Working in offline mode.');
            createNewMap("Default Map (Offline)");
        }
    }

    pushBtn.addEventListener('click', async () => {
        if (!isDirty) return;
        const mapData = getMapData();
        if (!mapData) return;

        const { created_at, updated_at, ...dataToSave } = mapData;

        try {
            const response = await fetch(API_ENDPOINT, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'save',
                    id: currentMapId,
                    name: mapData.name,
                    map_data: JSON.stringify(dataToSave)
                })
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Server responded with status ${response.status}: ${errorText}`);
            }

            const result = await response.json();

            if (result.success) {
                console.log('Map saved successfully!');
                setDirty(false);
            } else {
                throw new Error(result.message || 'Failed to save map.');
            }
        } catch (error) {
            console.error('Error pushing to server:', error);
            alert(`Error saving map: ${error.message}`);
        }
    });

    exportBtn.addEventListener('click', () => {
        const mapData = getMapData();
        if (!mapData) {
            console.error("Export failed: No map data available.");
            return;
        }
        const dataStr = JSON.stringify(mapData, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', `${mapData.name.replace(/\s/g, "_")}.json`);
        linkElement.click();
    });

    importBtn.addEventListener('click', () => importFile.click());
    importFile.addEventListener('change', (e) => {
        const file = e.target.files[0]; if (!file) return;
        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const importedData = JSON.parse(event.target.result);
                if (importedData.name && importedData.background) {
                    createNewMap(importedData.name, importedData);
                } else { alert('Invalid map JSON file format.'); }
            } catch (error) { alert('Error parsing JSON file: ' + error.message); }
        };
        reader.readAsText(file);
        importFile.value = '';
    });

    generateImageBtn.addEventListener('click', async () => {
        const width = parseInt(renderWidthInput.value, 10);
        const height = parseInt(renderHeightInput.value, 10);
        if (!width || !height) {
            alert("Please enter valid render dimensions.");
            return;
        }

        const renderMapId = renderMapSelector.value;
        const mapToRender = allMaps[renderMapId];
        if (!mapToRender) {
            alert(`Error: Could not find map data for ID ${renderMapId}`);
            return;
        }

        deselectElement();

        const clonedCanvas = mapCanvas.cloneNode(true);

        clonedCanvas.style.position = 'absolute';
        clonedCanvas.style.top = '-9999px';
        clonedCanvas.style.left = '-9999px';
        document.body.appendChild(clonedCanvas);

        generateImageBtn.textContent = 'Preparing Images...';
        generateImageBtn.disabled = true;

        try {
            const images = clonedCanvas.querySelectorAll('.map-asset img, .map-background');
            const imageLoadPromises = [];

            images.forEach(img => {
                const originalSrc = img.src;
                if (originalSrc && (originalSrc.startsWith('http://') || originalSrc.startsWith('https://'))) {
                    const proxySrc = `${API_ENDPOINT}?action=proxy&url=${encodeURIComponent(originalSrc)}`;

                    const promise = new Promise((resolve, reject) => {
                        const tempImg = new Image();
                        tempImg.crossOrigin = "anonymous";
                        const timeout = setTimeout(() => reject(new Error(`Image timed out: ${originalSrc}`)), 15000);
                        tempImg.onload = () => {
                            clearTimeout(timeout);
                            img.src = tempImg.src;
                            resolve();
                        };
                        tempImg.onerror = () => {
                            clearTimeout(timeout);
                            console.warn(`Failed to load image via proxy: ${originalSrc}`);
                            resolve();
                        };
                        tempImg.src = proxySrc;
                    });
                    imageLoadPromises.push(promise);
                }
            });

            await Promise.all(imageLoadPromises);

            generateImageBtn.textContent = 'Rendering...';

            const renderedCanvas = await html2canvas(clonedCanvas, {
                width: width,
                height: height,
                backgroundColor: '#000',
                useCORS: true,
                logging: false
            });

            const link = document.createElement('a');
            link.download = `${mapToRender.name.replace(/ /g, "_")}_render.png`;
            link.href = renderedCanvas.toDataURL("image/png");
            link.click();

        } catch (error) {
            console.error("Rendering failed:", error);
            alert("Could not render the map. An image may have failed to load. Check the console for details.");
        } finally {
            document.body.removeChild(clonedCanvas);

            generateImageBtn.textContent = 'Generate Image';
            generateImageBtn.disabled = false;
            renderModal.style.display = 'none';
        }
    });

    // --- Initial Setup ---
    addAssetUrlField();
    fetchAllMaps();
});