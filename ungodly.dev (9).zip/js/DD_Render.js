// ============================================================================
// DD_RENDER.JS - DOM Updates, UI Building, and State Rendering
// ============================================================================

// Global UI State Guarantees
window.editingResponseRef = window.editingResponseRef || null;
window.scrollIndicatorTimeout = window.scrollIndicatorTimeout || null;
window.editTarget = window.editTarget || { type: null, index: null, seqIndex: null, imgIndex: null };
window.contextMenuTarget = window.contextMenuTarget || null;

document.addEventListener('click', (e) => {
    const menu = document.getElementById('project-context-menu');
    if (menu && menu.style.display === 'flex' && !menu.contains(e.target)) {
        closeProjectContextMenu();
    }
});

// Helper to generate SVG Copy Icon
const getCopyIcon = () => `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>`;

const getGearIcon = () => `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.65 1.65 0 0 0 15 19.4a1.65 1.65 0 0 0-1 .6 1.65 1.65 0 0 0-.33 1.05V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-.6-1 1.65 1.65 0 0 0-1.05-.33H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-.6 1.65 1.65 0 0 0 .33-1.05V3a2 2 0 1 1 4 0v.09A1.65 1.65 0 0 0 15 4.6a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 .6 1 1.65 1.65 0 0 0 1.05.33H21a2 2 0 1 1 0 4h-.09A1.65 1.65 0 0 0 19.4 15z"></path></svg>`;


function getDefaultTextFormat() {
    return { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
}

function normalizeTextFormat(tf) {
    const defaults = getDefaultTextFormat();
    return Object.assign({}, defaults, tf || {});
}

function getTextFormatStyle(tf) {
    const f = normalizeTextFormat(tf);
    const decos = [];
    if (f.underline) decos.push('underline');
    if (f.strikethrough) decos.push('line-through');
    let textStyleStr = '';
    textStyleStr += f.bold ? 'font-weight: bold; ' : 'font-weight: normal; ';
    textStyleStr += f.italic ? 'font-style: italic; ' : 'font-style: normal; ';
    textStyleStr += `text-decoration: ${decos.length > 0 ? decos.join(' ') : 'none'}; `;
    textStyleStr += `text-align: ${f.alignH === 'justified' ? 'justify' : f.alignH}; `;
    if (f.listStyle !== 'none') textStyleStr += 'padding-left: 30px; ';
    return textStyleStr;
}

function renderFormatToolbar(tf, commandPrefix, extraClass = '') {
    const f = normalizeTextFormat(tf);
    return `
        <div class="format-toolbar ${extraClass}">
            <button class="format-btn font-bold ${f.bold ? 'active' : ''}" type="button" style="font-family: serif;" onclick="${commandPrefix}'b')" title="Bold">B</button>
            <button class="format-btn italic ${f.italic ? 'active' : ''}" type="button" style="font-family: serif;" onclick="${commandPrefix}'i')" title="Italic">I</button>
            <button class="format-btn underline ${f.underline ? 'active' : ''}" type="button" style="font-family: serif;" onclick="${commandPrefix}'u')" title="Underline">U</button>
            <button class="format-btn line-through ${f.strikethrough ? 'active' : ''}" type="button" style="font-family: serif;" onclick="${commandPrefix}'s')" title="Strikethrough">S</button>
            <div class="format-divider"></div>
            <button class="format-btn ${f.listStyle === 'bullet' ? 'active' : ''}" type="button" onclick="${commandPrefix}'bullet')" title="Bullet List"><svg viewBox="0 0 24 24"><path d="M4 6h2v2H4zm0 5h2v2H4zm0 5h2v2H4zm4-10h12v2H8zm0 5h12v2H8zm0 5h12v2H8z"></path></svg></button>
            <button class="format-btn ${f.listStyle === 'number' ? 'active' : ''}" type="button" onclick="${commandPrefix}'number')" title="Numbered List"><svg viewBox="0 0 24 24"><path d="M5 7h1v2H5zm0 4h1v2H5zm0 4h1v2H5zm3-8h12v2H8zm0 4h12v2H8zm0 4h12v2H8z"></path></svg></button>
            <div class="format-divider"></div>
            <button class="format-btn ${f.alignH === 'left' ? 'active' : ''}" type="button" onclick="${commandPrefix}'align', 'left')" title="Align Left"><svg viewBox="0 0 24 24"><path d="M3 5h14v2H3V5zm0 6h8v2H3v-2zm0 6h14v2H3v-2z"></path></svg></button>
            <button class="format-btn ${f.alignH === 'center' ? 'active' : ''}" type="button" onclick="${commandPrefix}'align', 'center')" title="Align Center"><svg viewBox="0 0 24 24"><path d="M5 5h14v2H5V5zm3 6h8v2H8v-2zm-3 6h14v2H5v-2z"></path></svg></button>
            <button class="format-btn ${f.alignH === 'right' ? 'active' : ''}" type="button" onclick="${commandPrefix}'align', 'right')" title="Align Right"><svg viewBox="0 0 24 24"><path d="M7 5h14v2H7V5zm6 6h8v2h-8v-2zm-6 6h14v2H7v-2z"></path></svg></button>
            <button class="format-btn ${f.alignH === 'justified' ? 'active' : ''}" type="button" onclick="${commandPrefix}'align', 'justified')" title="Justified"><svg viewBox="0 0 24 24"><path d="M3 5h18v2H3V5zm0 6h18v2H3v-2zm0 6h18v2H3v-2z"></path></svg></button>
            <div class="format-divider"></div>
            <button class="format-btn ${f.alignV === 'top' ? 'active' : ''}" type="button" onclick="${commandPrefix}'top')" title="Align Top"><svg viewBox="0 0 24 24"><path d="M5 3h14v2H5V3zm0 4h14v2H5V7zm0 4h8v2H5v-2z"></path></svg></button>
            <button class="format-btn ${f.alignV === 'middle' ? 'active' : ''}" type="button" onclick="${commandPrefix}'middle')" title="Align Middle"><svg viewBox="0 0 24 24"><path d="M5 9h14v2H5V9zm0 4h8v2H5v-2zm0 4h14v2H5v-2z"></path></svg></button>
            <button class="format-btn ${f.alignV === 'bottom' ? 'active' : ''}" type="button" onclick="${commandPrefix}'bottom')" title="Align Bottom"><svg viewBox="0 0 24 24"><path d="M5 11h8v2H5v-2zm0 4h14v2H5v-2zm0 4h14v2H5v-2z"></path></svg></button>
        </div>
    `;
}

function getLogicWarningColor(flags) {
    if (!flags) return null;
    if (flags.red && flags.blue) return 'var(--accent-purple)';
    if (flags.red) return 'var(--accent-pink)';
    if (flags.blue) return 'var(--accent-teal)';
    return null;
}

function getResponseWarningFlags(project, response) {
    const validRConds = (response.conditions || []).filter(c => (c.variable && c.variable.trim() !== '') || (c.value && c.value.trim() !== ''));
    const validRStates = (response.gameStateChanges || []).filter(c => (c.variable && c.variable.trim() !== '') || (c.value && c.value.trim() !== ''));
    let hasUnmatchedCondition = false;
    if (validRConds.length > 0) {
        hasUnmatchedCondition = validRConds.some(cond => {
            return !project.nodes.some(n => 
                (n.gameStateChanges || []).some(gsc => gsc.variable === cond.variable && gsc.value === cond.value) || 
                (n.responses || []).some(res => (res.gameStateChanges || []).some(gsc => gsc.variable === cond.variable && gsc.value === cond.value))
            );
        });
    }
    let hasUnmatchedState = false;
    if (validRStates.length > 0) {
        hasUnmatchedState = validRStates.some(change => {
            return !project.nodes.some(n => 
                (n.conditions || []).some(cond => cond.variable === change.variable && cond.value === change.value) || 
                (n.responses || []).some(res => (res.conditions || []).some(cond => cond.variable === change.variable && cond.value === change.value))
            );
        });
    }
    return { red: hasUnmatchedCondition && !response.externalCall, blue: hasUnmatchedState && !response.makeExternalCall };
}

function getWarningIconSvg() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`;
}

// Utility to copy node and response IDs cleanly
window.copyToClipboard = function(text, btn) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
            const oldHtml = btn.innerHTML;
            btn.innerHTML = `<span style="font-size:0.55rem; font-weight:bold; color:var(--accent-teal);">COPIED</span>`;
            setTimeout(() => { btn.innerHTML = oldHtml; }, 1000);
        });
    } else {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        const oldHtml = btn.innerHTML;
        btn.innerHTML = `<span style="font-size:0.55rem; font-weight:bold; color:var(--accent-teal);">COPIED</span>`;
        setTimeout(() => { btn.innerHTML = oldHtml; }, 1000);
    }
};

window.toggleResponseCollapse = function(nIdx, rIdx, ev) {
    if(ev) ev.stopPropagation();
    const project = getActiveProject();
    if(project && project.nodes[nIdx] && project.nodes[nIdx].responses[rIdx]) {
        project.nodes[nIdx].responses[rIdx].isCollapsed = !project.nodes[nIdx].responses[rIdx].isCollapsed;
        renderNodes();
    }
};

window.toggleResponseLogicSection = function(nIdx, rIdx, section, ev) {
    if (ev) ev.stopPropagation();
    const project = getActiveProject();
    if (!project || !project.nodes[nIdx] || !project.nodes[nIdx].responses[rIdx]) return;
    const response = project.nodes[nIdx].responses[rIdx];
    let prop = 'statesOpen';
    if (section === 'conditions') prop = 'conditionsOpen';
    if (section === 'advanced') prop = 'advancedOpen';
    response[prop] = response[prop] === false;
    renderNodes();
};

function openProjectContextMenu(ev, type, idx) {
    ev.preventDefault();
    contextMenuTarget = { type, index: idx };
    const menu = document.getElementById('project-context-menu');
    menu.style.display = 'flex';
    menu.style.left = ev.clientX + 'px';
    menu.style.top = ev.clientY + 'px';
}

function closeProjectContextMenu() {
    const menu = document.getElementById('project-context-menu');
    if (menu) menu.style.display = 'none';
    contextMenuTarget = null;
}

function handleProjectContextAction(action) {
    if (!contextMenuTarget) return;
    const { type, index } = contextMenuTarget;
    
    if (action === 'delete') {
        deleteProject(type, index);
    } else if (action === 'duplicate') {
        duplicateProject(type, index);
    }
    
    closeProjectContextMenu();
}

function startEditing(type, index) {
    editTarget = { type, index, seqIndex: null, imgIndex: null };
    if (type === 'cast') renderCast();
    if (type === 'state') renderStates();
    if (type === 'mood') renderMoods();
    if (type === 'setting') renderSettings();
    if (type === 'time') renderTimesOfDay();
    if (type === 'day') renderDaysOfWeek();
    if (type === 'menu') renderMenuOptions();
    if (type === 'imageseq') renderImageSequences();
    if (type === 'token') renderTokens();
}

function cancelEdit() {
    editTarget = { type: null, index: null, seqIndex: null, imgIndex: null };
    renderCast(); renderStates(); renderMoods(); renderSettings(); renderTimesOfDay();
    renderDaysOfWeek(); renderMenuOptions(); renderImageSequences(); renderTokens();
}

function startEditingImage(seqIndex, imgIndex) {
    editTarget = { type: 'image', seqIndex, imgIndex };
    renderImageSequences();
}

function startEditingResponse(nIdx, rIdx) {
    editingResponseRef = { nIdx, rIdx };
    renderNodes();
    setTimeout(() => {
        const input = document.getElementById(`edit-input-${nIdx}-${rIdx}`);
        if (input) {
            input.focus();
            input.selectionStart = input.selectionEnd = input.value.length;
        }
    }, 0);
}

window.expandCollapsedResponseForEditing = function(nIdx, rIdx, ev) {
    if (ev) ev.stopPropagation();
    const project = getActiveProject();
    if (!project || !project.nodes || !project.nodes[nIdx] || !project.nodes[nIdx].responses || !project.nodes[nIdx].responses[rIdx]) return;
    project.nodes[nIdx].responses[rIdx].isCollapsed = false;
    if (project.nodes[nIdx].responses[rIdx].conditionsOpen === undefined) project.nodes[nIdx].responses[rIdx].conditionsOpen = false;
    if (project.nodes[nIdx].responses[rIdx].statesOpen === undefined) project.nodes[nIdx].responses[rIdx].statesOpen = false;
    if (project.nodes[nIdx].responses[rIdx].advancedOpen === undefined) project.nodes[nIdx].responses[rIdx].advancedOpen = false;
    startEditingResponse(nIdx, rIdx);
};


function toggleImageSeqPanel(name, isOpen) {
    if (isOpen) openImageSeqs.add(name);
    else openImageSeqs.delete(name);
}

// --- DRAG AND DROP FOR IMAGES & SEQUENCES ---
function handleImageSeqDragStart(ev, seqIdx) {
    ev.stopPropagation();
    ev.dataTransfer.setData('text/plain', JSON.stringify({ type: 'image_seq_order', seqIdx }));
}

function handleImageSeqDrop(ev, targetSeqIdx) {
    ev.preventDefault();
    ev.stopPropagation();
    try {
        const data = JSON.parse(ev.dataTransfer.getData('text/plain'));
        if (data.type === 'image_seq_order' && data.seqIdx !== targetSeqIdx) {
            const seqToMove = globalImageSequences.splice(data.seqIdx, 1)[0];
            globalImageSequences.splice(targetSeqIdx, 0, seqToMove);
            renderImageSequences();
            renderNodes();
            if (typeof markWorkspaceDirty === 'function') markWorkspaceDirty();
        }
    } catch(e) {}
}

function handleImageDragStart(ev, seqIdx, imgIdx) {
    ev.stopPropagation();
    ev.dataTransfer.setData('text/plain', JSON.stringify({ type: 'image_order', seqIdx, imgIdx }));
}

function handleImageDrop(ev, targetSeqIdx, targetImgIdx) {
    ev.preventDefault();
    ev.stopPropagation();
    try {
        const data = JSON.parse(ev.dataTransfer.getData('text/plain'));
        if (data.type === 'image_order' && data.seqIdx === targetSeqIdx && data.imgIdx !== targetImgIdx) {
            const seq = globalImageSequences[targetSeqIdx];
            const imgToMove = seq.images.splice(data.imgIdx, 1)[0];
            seq.images.splice(targetImgIdx, 0, imgToMove);
            renderImageSequences();
            renderNodes();
            if (typeof markWorkspaceDirty === 'function') markWorkspaceDirty();
        }
    } catch(e) {}
}


const GLOBAL_SIDEBAR_REORDER_CONFIG = {
    token: {
        getItems: () => window.globalTokens || [],
        render: () => { if (typeof renderTokens === 'function') renderTokens(); },
        refresh: () => { if (typeof renderNodes === 'function') renderNodes(); }
    },
    cast: {
        getItems: () => window.cast || [],
        render: () => { if (typeof renderCast === 'function') renderCast(); },
        refresh: () => {
            if (typeof updateLocalAddDropdown === 'function') updateLocalAddDropdown();
            if (typeof renderLocalCast === 'function') renderLocalCast();
            if (typeof renderNodes === 'function') renderNodes();
        }
    },
    state: {
        getItems: () => window.globalStates || [],
        render: () => { if (typeof renderStates === 'function') renderStates(); },
        refresh: () => { if (typeof renderNodes === 'function') renderNodes(); }
    },
    mood: {
        getItems: () => window.globalMoods || [],
        render: () => { if (typeof renderMoods === 'function') renderMoods(); },
        refresh: () => { if (typeof renderNodes === 'function') renderNodes(); }
    },
    setting: {
        getItems: () => window.globalSettings || [],
        render: () => { if (typeof renderSettings === 'function') renderSettings(); },
        refresh: () => { if (typeof renderNodes === 'function') renderNodes(); }
    },
    time: {
        getItems: () => window.globalTimesOfDay || [],
        render: () => { if (typeof renderTimesOfDay === 'function') renderTimesOfDay(); },
        refresh: () => { if (typeof renderNodes === 'function') renderNodes(); }
    },
    day: {
        getItems: () => window.globalDaysOfWeek || [],
        render: () => { if (typeof renderDaysOfWeek === 'function') renderDaysOfWeek(); },
        refresh: () => { if (typeof renderNodes === 'function') renderNodes(); }
    },
    menu: {
        getItems: () => window.globalMenuOptions || [],
        render: () => { if (typeof renderMenuOptions === 'function') renderMenuOptions(); },
        refresh: () => { if (typeof renderNodes === 'function') renderNodes(); }
    }
};

function handleGlobalSidebarDragStart(ev, type, index) {
    ev.stopPropagation();
    if (ev.dataTransfer) {
        ev.dataTransfer.effectAllowed = 'move';
        ev.dataTransfer.setData('text/plain', JSON.stringify({ type: 'global_sidebar_order', sidebarType: type, index }));
    }
}

function handleGlobalSidebarDragOver(ev) {
    ev.preventDefault();
    ev.stopPropagation();
    if (ev.dataTransfer) ev.dataTransfer.dropEffect = 'move';
}

function handleGlobalSidebarDrop(ev, type, targetIndex) {
    ev.preventDefault();
    ev.stopPropagation();
    try {
        const data = JSON.parse(ev.dataTransfer.getData('text/plain'));
        if (!data || data.type !== 'global_sidebar_order' || data.sidebarType !== type) return;
        const config = GLOBAL_SIDEBAR_REORDER_CONFIG[type];
        if (!config) return;
        const items = config.getItems();
        const sourceIndex = Number(data.index);
        if (!Array.isArray(items) || sourceIndex === targetIndex || sourceIndex < 0 || targetIndex < 0 || sourceIndex >= items.length || targetIndex >= items.length) return;
        const moved = items.splice(sourceIndex, 1)[0];
        items.splice(targetIndex, 0, moved);
        if (window.editTarget && window.editTarget.type === type && window.editTarget.index !== null) {
            if (window.editTarget.index === sourceIndex) window.editTarget.index = targetIndex;
            else if (sourceIndex < window.editTarget.index && targetIndex >= window.editTarget.index) window.editTarget.index--;
            else if (sourceIndex > window.editTarget.index && targetIndex <= window.editTarget.index) window.editTarget.index++;
        }
        config.render();
        config.refresh();
        if (typeof markWorkspaceDirty === 'function') markWorkspaceDirty();
    } catch (err) {
        console.warn('Global sidebar reorder failed:', err);
    }
}

// --- ADDITIVE COLLAPSE/EXPAND HELPERS ---
function toggleNodeCollapse(nIdx, ev) {
    if (ev) ev.stopPropagation();
    const project = getActiveProject();
    if (project && project.nodes[nIdx]) {
        project.nodes[nIdx].isCollapsed = !project.nodes[nIdx].isCollapsed;
        renderNodes();
    }
}

function toggleNodeDeep(nIdx, expand, ev) {
    if (ev) ev.stopPropagation();
    const project = getActiveProject();
    if (project && project.nodes[nIdx]) {
        project.nodes[nIdx].advancedOpen = expand;
        project.nodes[nIdx].conditionsOpen = expand;
        project.nodes[nIdx].statesOpen = expand;
        project.nodes[nIdx].responsesOpen = expand;
        
        // Deep toggle inner responses
        (project.nodes[nIdx].responses || []).forEach(r => { 
            r.isCollapsed = !expand; 
            r.conditionsOpen = expand;
            r.statesOpen = expand;
        });
        
        if (!expand) {
            project.nodes[nIdx].isCollapsed = true;
        } else {
            project.nodes[nIdx].isCollapsed = false;
        }
        renderNodes();
    }
}

function toggleAdvancedSettings(nIdx, ev) {
    if(ev) ev.stopPropagation();
    const node = getActiveProject().nodes[nIdx];
    node.advancedOpen = !node.advancedOpen;
    renderNodes();
}

// --- DYNAMIC GLOW UPDATE ---
function updateNodeGlows() {
    const project = getActiveProject();
    if (!project) return;
    
    project.nodes.forEach((node, nIdx) => {
        // 1. UPDATE STATEMENT NODE GLOW
        const el = document.getElementById(`node-${node.id}`);
        if (el) {
            const validConds = (node.conditions || []).filter(c => (c.variable && c.variable.trim() !== '') || (c.value && c.value.trim() !== ''));
            const validStates = (node.gameStateChanges || []).filter(c => (c.variable && c.variable.trim() !== '') || (c.value && c.value.trim() !== ''));
            
            let hasUnmatchedCondition = false;
            if (validConds.length > 0) {
                hasUnmatchedCondition = validConds.some(cond => {
                    return !project.nodes.some(n => 
                        (n.gameStateChanges || []).some(gsc => gsc.variable === cond.variable && gsc.value === cond.value) || 
                        (n.responses || []).some(r => (r.gameStateChanges || []).some(gsc => gsc.variable === cond.variable && gsc.value === cond.value))
                    );
                });
            }

            let hasUnmatchedState = false;
            if (validStates.length > 0) {
                hasUnmatchedState = validStates.some(change => {
                    return !project.nodes.some(n => 
                        (n.conditions || []).some(cond => cond.variable === change.variable && cond.value === change.value) || 
                        (n.responses || []).some(res => (res.conditions || []).some(cond => cond.variable === change.variable && cond.value === change.value))
                    );
                });
            }

            const needsRedGlow = hasUnmatchedCondition && !node.externalCall;
            const needsBlueGlow = hasUnmatchedState && !node.makeExternalCall;

            if (needsRedGlow && needsBlueGlow) {
                el.style.borderColor = 'var(--accent-purple)';
                el.style.boxShadow = '0 0 20px rgba(176, 38, 255, 0.6)';
            } else if (needsRedGlow) {
                el.style.borderColor = 'var(--accent-pink)';
                el.style.boxShadow = '0 0 20px rgba(255, 0, 123, 0.6)';
            } else if (needsBlueGlow) {
                el.style.borderColor = 'var(--accent-teal)';
                el.style.boxShadow = '0 0 20px rgba(0, 242, 255, 0.6)';
            } else {
                el.style.borderColor = 'var(--border-color)';
                el.style.boxShadow = 'none';
            }

            const collapsedCard = document.getElementById(`collapsed-node-card-${node.id}`);
            if (collapsedCard) {
                if (needsRedGlow && needsBlueGlow) {
                    collapsedCard.style.borderColor = 'var(--accent-purple)';
                    collapsedCard.style.boxShadow = '0 0 20px rgba(176, 38, 255, 0.6)';
                } else if (needsRedGlow) {
                    collapsedCard.style.borderColor = 'var(--accent-pink)';
                    collapsedCard.style.boxShadow = '0 0 20px rgba(255, 0, 123, 0.6)';
                } else if (needsBlueGlow) {
                    collapsedCard.style.borderColor = 'var(--accent-teal)';
                    collapsedCard.style.boxShadow = '0 0 20px rgba(0, 242, 255, 0.6)';
                } else {
                    collapsedCard.style.borderColor = 'var(--border-color)';
                    collapsedCard.style.boxShadow = 'none';
                }
                collapsedCard.style.borderLeftColor = node.nodeColor || project.color || '#ff007b';
            }
        }

        // 2. UPDATE INDIVIDUAL RESPONSE GLOWS
        (node.responses || []).forEach((r, rIdx) => {
            const rEl = document.getElementById(`response-item-${nIdx}-${rIdx}`);
            if (rEl) {
                const validRConds = (r.conditions || []).filter(c => (c.variable && c.variable.trim() !== '') || (c.value && c.value.trim() !== ''));
                const validRStates = (r.gameStateChanges || []).filter(c => (c.variable && c.variable.trim() !== '') || (c.value && c.value.trim() !== ''));
                
                let hasUnmatchedCondition = false;
                if (validRConds.length > 0) {
                    hasUnmatchedCondition = validRConds.some(cond => {
                        return !project.nodes.some(n => 
                            (n.gameStateChanges || []).some(gsc => gsc.variable === cond.variable && gsc.value === cond.value) || 
                            (n.responses || []).some(res => (res.gameStateChanges || []).some(gsc => gsc.variable === cond.variable && gsc.value === cond.value))
                        );
                    });
                }

                let hasUnmatchedState = false;
                if (validRStates.length > 0) {
                    hasUnmatchedState = validRStates.some(change => {
                        return !project.nodes.some(n => 
                            (n.conditions || []).some(cond => cond.variable === change.variable && cond.value === change.value) || 
                            (n.responses || []).some(res => (res.conditions || []).some(cond => cond.variable === change.variable && cond.value === change.value))
                        );
                    });
                }

                const needsRespRedGlow = hasUnmatchedCondition && !r.externalCall;
                const needsRespBlueGlow = hasUnmatchedState && !r.makeExternalCall;

                if (needsRespRedGlow && needsRespBlueGlow) {
                    rEl.style.borderColor = 'var(--accent-purple)';
                    rEl.style.boxShadow = '0 0 15px rgba(176, 38, 255, 0.4)';
                } else if (needsRespRedGlow) {
                    rEl.style.borderColor = 'var(--accent-pink)';
                    rEl.style.boxShadow = '0 0 15px rgba(255, 0, 123, 0.4)';
                } else if (needsRespBlueGlow) {
                    rEl.style.borderColor = 'var(--accent-teal)';
                    rEl.style.boxShadow = '0 0 15px rgba(0, 242, 255, 0.4)';
                } else {
                    rEl.style.borderColor = '#333';
                    rEl.style.boxShadow = 'none';
                }
            }
        });
    });
}

// --- GLOBAL SIDEBAR LISTS ---
function renderTokens() {
    const list = document.getElementById('active-tokens');
    if (!list) return;
    list.innerHTML = globalTokens.map((t, i) => {
        if (editTarget.type === 'token' && editTarget.index === i) {
            return `
                <li style="background: #000; padding: 10px; margin-bottom: 8px; border: 1px solid var(--border-color);">
                    <div style="display:flex; gap:6px; align-items:center;">
                        <span style="color:var(--text-dim);">{{</span>
                        <input type="text" id="edit-token-key-${i}" value="${escapeHtml(t.key)}" draggable="false" ondragstart="event.stopPropagation();" style="flex:1; min-width:0; padding:4px; font-size:0.75rem; background:#111; color:#fff; border:1px solid var(--accent-teal);">
                        <span style="color:var(--text-dim);">}}</span>
                        <button class="btn btn-teal" style="padding: 4px 8px;" onclick="saveTokenEdit(${i})">✓</button>
                        <button class="btn btn-outline" style="padding: 4px 8px; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                    </div>
                </li>`;
        }
        return `
            <li class="global-sidebar-item global-token-item" style="background: #000; padding: 10px; margin-bottom: 8px; border: 1px solid var(--border-color); display:flex; flex-direction:column; gap:6px; cursor:grab;"
                draggable="true" ondragstart="handleGlobalSidebarDragStart(event, 'token', ${i})" ondragover="handleGlobalSidebarDragOver(event)" ondrop="handleGlobalSidebarDrop(event, 'token', ${i})">
                <div style="display:flex; justify-content:space-between; align-items:center; gap:8px;">
                    <span style="display:flex; align-items:center; gap:7px; min-width:0;">
                        <span style="color:var(--text-dim); font-size:0.8rem; cursor:grab; flex-shrink:0;">☰</span>
                        <span class="token-tag cursor-pointer" ondblclick="startEditing('token', ${i})" title="Drag to reorder. Double click to edit key.">{{${escapeHtml(t.key)}}}</span>
                    </span>
                    <span class="text-pink-500 cursor-pointer" style="font-weight:bold; font-size:1.2rem; line-height:1; flex-shrink:0;" onclick="removeToken(${i}); event.stopPropagation();">×</span>
                </div>
                <input type="text" value="${escapeHtml(t.value)}" draggable="false" ondragstart="event.stopPropagation();" style="width:100%; padding:8px 10px; font-size:0.8rem; background:#050505; border:1px solid var(--accent-teal); color:#fff; border-radius:3px; outline:none;" onchange="updateTokenValue(${i}, this.value)" placeholder="Token Value...">
            </li>`;
    }).join('');
}

function generateSidebarList(items, type, idPrefix) {
    return items.map((item, i) => {
        if (editTarget.type === type && editTarget.index === i) {
            return `
                <li style="border-left-color: ${item.color}; display:flex; gap:6px; align-items:center; padding: 12px 8px; overflow: hidden;">
                    <input type="text" id="edit-${idPrefix}-name-${i}" value="${escapeHtml(item.name)}" draggable="false" ondragstart="event.stopPropagation();" style="flex:1; min-width:0; padding:6px; font-size:0.75rem;">
                    <input type="color" id="edit-${idPrefix}-color-${i}" value="${item.color}" draggable="false" ondragstart="event.stopPropagation();" style="flex-shrink:0; width:28px; height:28px; padding:0; border:1px solid #333; cursor:pointer;">
                    <button class="btn btn-teal" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1;" onclick="save${type.charAt(0).toUpperCase() + type.slice(1)}Edit(${i})">✓</button>
                    <button class="btn btn-outline" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                </li>`;
        }
        return `
            <li class="global-sidebar-item" style="border-left-color: ${item.color}; cursor:grab;" ondblclick="startEditing('${type}', ${i})" title="Drag to reorder. Double-click to edit."
                draggable="true" ondragstart="handleGlobalSidebarDragStart(event, '${type}', ${i})" ondragover="handleGlobalSidebarDragOver(event)" ondrop="handleGlobalSidebarDrop(event, '${type}', ${i})">
                <span style="display:flex; align-items:center; gap:7px; min-width:0;">
                    <span style="color:var(--text-dim); font-size:0.8rem; cursor:grab; flex-shrink:0;">☰</span>
                    <span style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${escapeHtml(item.name)}</span>
                </span>
                <span style="color:var(--accent-pink); cursor:pointer; flex-shrink:0; padding-left:8px;" onclick="removeGlobal${idPrefix === 'cast' ? 'Char' : (idPrefix === 'time' ? 'TimeOfDay' : (idPrefix === 'day' ? 'DayOfWeek' : (idPrefix === 'menu' ? 'MenuOption' : idPrefix.charAt(0).toUpperCase() + idPrefix.slice(1))))}(${i}); event.stopPropagation();">×</span>
            </li>`;
    }).join('');
}

function renderCast() { const l = document.getElementById('active-participants'); if (l) l.innerHTML = generateSidebarList(cast, 'cast', 'cast'); const c = document.getElementById('cast-count'); if(c) c.textContent = cast.length; }
function renderStates() { const l = document.getElementById('active-states'); if (l) l.innerHTML = generateSidebarList(globalStates, 'state', 'state'); const c = document.getElementById('state-count'); if(c) c.textContent = globalStates.length; }
function renderMoods() { const l = document.getElementById('active-moods'); if (l) l.innerHTML = generateSidebarList(globalMoods, 'mood', 'mood'); const c = document.getElementById('mood-count'); if(c) c.textContent = globalMoods.length; }
function renderSettings() { const l = document.getElementById('active-settings'); if (l) l.innerHTML = generateSidebarList(globalSettings, 'setting', 'setting'); const c = document.getElementById('setting-count'); if(c) c.textContent = globalSettings.length; }
function renderTimesOfDay() { const l = document.getElementById('active-times'); if (l) l.innerHTML = generateSidebarList(globalTimesOfDay, 'time', 'time'); const c = document.getElementById('time-count'); if(c) c.textContent = globalTimesOfDay.length; }
function renderDaysOfWeek() { const l = document.getElementById('active-days'); if (l) l.innerHTML = generateSidebarList(globalDaysOfWeek, 'day', 'day'); const c = document.getElementById('day-count'); if(c) c.textContent = globalDaysOfWeek.length; }
function renderMenuOptions() { const l = document.getElementById('active-menus'); if (l) l.innerHTML = generateSidebarList(globalMenuOptions, 'menu', 'menu'); const c = document.getElementById('menu-count'); if(c) c.textContent = globalMenuOptions.length; }

function renderImageSequences() {
    const container = document.getElementById('active-image-sequences');
    const countTag = document.getElementById('image-seq-count');
    if (!container) return;
    
    container.innerHTML = globalImageSequences.map((seq, i) => {
        if (editTarget.type === 'imageseq' && editTarget.index === i) {
            return `
                <div style="background:#111; border: 1px solid var(--border-color); border-left: 3px solid ${seq.color || '#fff'}; margin-bottom: 8px;">
                    <div style="padding: 10px; display:flex; gap:6px; align-items:center;">
                        <input type="text" id="edit-imgseq-name-${i}" value="${escapeHtml(seq.name)}" style="flex:1; min-width:0; padding:6px; font-size:0.75rem;">
                        <input type="color" id="edit-imgseq-color-${i}" value="${seq.color || '#00f2ff'}" style="flex-shrink:0; width:28px; height:28px; padding:0; cursor:pointer;">
                        <button class="btn btn-teal" style="padding: 6px;" onclick="saveImageSeqEdit(${i})">✓</button>
                        <button class="btn btn-outline" style="padding: 6px; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                    </div>
                </div>`;
        }

        const imagesHtml = seq.images.map((img, j) => {
            if (editTarget.type === 'image' && editTarget.seqIndex === i && editTarget.imgIndex === j) {
                return `
                    <div style="display: flex; justify-content: space-between; font-size: 0.7rem; padding: 6px; background: #000; border: 1px solid var(--accent-teal); gap: 5px;">
                        <input type="text" id="edit-img-name-${i}-${j}" value="${escapeHtml(img)}" style="flex:1; padding:4px;">
                        <button class="btn btn-teal" style="padding: 4px;" onclick="saveImageEdit(${i}, ${j})">✓</button>
                        <button class="btn btn-outline" style="padding: 4px; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                    </div>`;
            }
            return `
                <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.7rem; color: #ccc; padding: 6px; background: #151515; border: 1px solid #222; cursor: grab; overflow: hidden;"
                     draggable="true" ondragstart="handleImageDragStart(event, ${i}, ${j})" ondragover="event.preventDefault()" ondrop="handleImageDrop(event, ${i}, ${j})"
                     ondblclick="startEditingImage(${i}, ${j}); event.stopPropagation();" title="Drag to reorder or double-click to edit name">
                    <span style="display:flex; align-items:center; gap:6px; flex:1; min-width:0; padding-right:10px;">
                        <span style="color:var(--text-dim); font-size:0.8rem; cursor:grab; flex-shrink:0;">☰</span> 
                        <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; min-width: 0;" title="${escapeHtml(img)}">${escapeHtml(img)}</span>
                    </span>
                    <span onclick="deleteImageFromSequence(${i}, ${j}); event.stopPropagation();" style="color: var(--accent-pink); font-weight: bold; cursor: pointer; flex-shrink: 0; padding: 0 4px;">×</span>
                </div>`;
        }).join('');

        const isOpen = openImageSeqs.has(seq.name) ? 'open' : '';
        const hasSeqProject = sequences.some(s => s.title === seq.name);
        const isLinkedToNode = [...conversations, ...sequences].some(p => p.nodes.some(n => n.sequenceName === seq.name));
        
        const regenStyle = hasSeqProject ? 'color: #444; cursor: not-allowed;' : 'color: var(--accent-teal); cursor: pointer;';
        const regenAction = hasSeqProject ? '' : `onclick="regenerateSequenceProject('${escapeHtml(seq.name)}'); event.stopPropagation(); event.preventDefault();"`;
        const regenIcon = `<svg style="${regenStyle}" ${regenAction} title="${hasSeqProject ? 'Already has a Sequence Project' : 'Regenerate Sequence Project'}" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M2.13 15.57a10 10 0 1 0 3.43-8.07l-3.56 3.5"/></svg>`;
        
        let linkIcon = '';
        if (isLinkedToNode) {
            linkIcon = `<svg style="color: var(--accent-pink); cursor: pointer; pointer-events: auto;" onclick="unlinkSequenceCompletely('${escapeHtml(seq.name)}'); event.stopPropagation(); event.preventDefault();" title="Unlink Sequence from all nodes" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.36 6.64a9 9 0 0 1-1.27 1.28m-4.34 2.82a5 5 0 0 1-7.07-7.07l1.71-1.72M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><line x1="2" y1="2" x2="22" y2="22"></line></svg>`;
        } else {
            linkIcon = `<svg style="color: var(--accent-orange); cursor: pointer; pointer-events: auto;" onclick="openLinkSequenceModal('${escapeHtml(seq.name)}'); event.stopPropagation(); event.preventDefault();" title="Link Sequence to Node" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>`;
        }

        return `
            <details ${isOpen} ontoggle="toggleImageSeqPanel('${escapeHtml(seq.name)}', this.open)" style="background: #111; border: 1px solid var(--border-color); border-left: 3px solid ${seq.color || '#fff'}; margin-bottom: 8px;"
                     draggable="true" ondragstart="handleImageSeqDragStart(event, ${i})" ondragover="event.preventDefault()" ondrop="handleImageSeqDrop(event, ${i})">
                <summary style="padding: 10px; cursor: pointer; font-size: 0.75rem; font-weight: bold; color: ${seq.color || 'var(--accent-teal)'}; display: flex; justify-content: space-between; align-items:center;"
                         ondblclick="startEditing('imageseq', ${i}); event.preventDefault();" title="Drag to reorder. Double-click to rename sequence.">
                    <span style="display:flex; align-items:center; gap:8px;">
                        <span style="color:var(--text-dim); font-size:0.8rem; cursor:grab;">☰</span>
                        <span class="seq-arrow" style="display:inline-block; font-size:0.6rem; transition:0.2s;">▶</span>
                        ${escapeHtml(seq.name)} (${seq.images.length})
                    </span>
                    <span style="display:flex; align-items:center; gap: 8px;">
                        ${linkIcon}
                        ${regenIcon}
                        <span onclick="deleteImageSequence(${i}); event.preventDefault(); event.stopPropagation();" style="color: var(--accent-pink); padding: 0 5px; font-weight: bold; margin-left: 4px;">×</span>
                    </span>
                </summary>
                
                <div style="padding: 10px; background: #0a0a0a; border-top: 1px solid var(--border-color);" draggable="false" ondragstart="event.stopPropagation()">
                    <div style="display:flex; align-items:center; gap:8px; margin-bottom: 8px;">
                        <label style="font-size: 0.65rem; color: var(--text-dim); text-transform: uppercase; font-weight: 800;">Path:</label>
                        <input type="text" value="${escapeHtml(seq.path || 'Assets/2D/Sequences/')}" onchange="updateImageSeqPath(${i}, this.value)" style="flex:1; padding: 4px 8px; font-size: 0.75rem; background: #000; border: 1px solid var(--border-color); color: #fff;">
                    </div>
                    <div style="display:flex; gap: 5px;">
                        <button class="btn btn-outline" style="flex:1; padding: 4px; font-size: 0.6rem; border-color: var(--accent-teal); color: var(--accent-teal);" onclick="triggerSequenceImageImport(${i}); event.stopPropagation();">Import</button>
                        <button class="btn btn-outline" style="flex:1; padding: 4px; font-size: 0.6rem; border-color: var(--accent-teal); color: var(--accent-teal);" onclick="sortImageSequence(${i}); event.stopPropagation();">A-Z</button>
                        <button class="btn btn-outline" style="flex:1; padding: 4px; font-size: 0.6rem; border-color: var(--accent-pink); color: var(--accent-pink);" onclick="clearImageSequence(${i}); event.stopPropagation();">Clear</button>
                    </div>
                </div>

                <div style="padding: 10px; border-top: 1px solid var(--border-color); background: #0a0a0a; display: flex; flex-direction: column; gap: 5px;" draggable="false" ondragstart="event.stopPropagation()">
                    ${imagesHtml}
                </div>
            </details>`;
    }).join('');
    if(countTag) countTag.textContent = globalImageSequences.length;
}

// --- PROJECT LIST RENDERING ---
function generateProjectList(items, type) {
    const searchInput = document.getElementById(`search-${type}s`);
    const filterTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';

    return items.map((item, i) => {
        if (filterTerm && !item.title.toLowerCase().includes(filterTerm)) return '';

        if (window.renamingProject && window.renamingProject.type === type && window.renamingProject.index === i) {
            return `
            <li class="project-item renaming">
                <div style="display:flex; gap:5px;">
                    <input type="text" id="rename-${type}-${i}" value="${escapeHtml(item.title)}" style="flex:1; font-size:0.8rem; padding:4px; background:#111; color:#fff; border:1px solid var(--accent-teal);">
                    <button class="btn btn-teal" style="padding:4px 8px;" onclick="saveProjectRename('${type}', ${i}); event.stopPropagation();">✓</button>
                    <button class="btn btn-outline" style="padding:4px 8px; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelProjectRename(); event.stopPropagation();">×</button>
                </div>
            </li>`;
        }

        const isActive = (i === window.activeIndex && window.activeType === type);
        return `
        <li class="project-item ${isActive ? 'active' : ''}" 
            style="border-left: 4px solid ${item.color || 'transparent'} !important; background: ${isActive ? '#000' : '#151515'}; cursor: pointer;" 
            onclick="openEditor(${i}, '${type}')"
            ondblclick="startProjectRename('${type}', ${i}); event.stopPropagation();"
            oncontextmenu="openProjectContextMenu(event, '${type}', ${i})"
            draggable="true" ondragstart="handleDragStart(event, '${type}', ${i})"
            ondragover="event.preventDefault(); event.stopPropagation();"
            ondrop="handleProjectItemDrop(event, '${type}', ${i})">
            <div class="project-title-row">
                <strong>${escapeHtml(item.title)}</strong>
                <div class="project-action-strip">
                    <button class="project-clone-btn" title="Clone Project" onclick="openCloneProjectModal('${type}', ${i}, event)">${getCopyIcon()}</button>
                    <button class="project-delete-btn" title="Delete Project" onclick="deleteProject('${type}', ${i}); event.stopPropagation();">DELETE</button>
                </div>
            </div>
            <div class="project-list-meta-row" style="display:flex; justify-content:space-between; align-items:center; margin-top:5px; padding-right: 92px;">
                <span class="conv-cast-preview">Cast: ${escapeHtml(item.participants.join(', ') || 'None')}</span>
                ${item.isRepeatable ? '<span style="color:var(--accent-green); font-size:0.6rem; font-weight:800; letter-spacing:1px;">REPEATABLE</span>' : ''}
            </div>
        </li>`;
    }).join('');
}

function renderConversations() {
    const list = document.getElementById('conversation-master-list');
    if (!list) return;
    list.innerHTML = generateProjectList(window.conversations || [], 'conversation');
    const countTag = document.getElementById('conv-item-count');
    if (countTag) countTag.textContent = (window.conversations || []).length;
}

function renderSequences() {
    const list = document.getElementById('sequence-master-list');
    if (!list) return;
    list.innerHTML = generateProjectList(window.sequences || [], 'sequence');
    const countTag = document.getElementById('sequence-count');
    if (countTag) countTag.textContent = (window.sequences || []).length;
}

function openEditor(index, type) {
    window.activeIndex = index;
    window.activeType = type;
    const project = window.getActiveProject();
    
    if (window.editedNodes) window.editedNodes.clear();
    window.lastTraversedIndex = -1;
    window.currentlyVisibleIndex = -1;
    window.activeNavIndex = -1; 
    
    document.getElementById('editor-placeholder').style.display = 'none';
    document.getElementById('active-editor-content').style.display = 'block';
    
    if (project) {
        document.getElementById('edit-conv-name').value = project.title;
        const colorInput = document.getElementById('edit-conv-color');
        if (colorInput) colorInput.value = project.color || '#00f2ff';
        
        const repeatCheck = document.getElementById('repeatable-toggle');
        const repeatVarContainer = document.getElementById('repeat-variable-container');
        const repeatVarInput = document.getElementById('repeat-variable-input');
        
        if (repeatCheck) repeatCheck.checked = project.isRepeatable || false;
        if (repeatVarContainer) repeatVarContainer.style.display = (project.isRepeatable) ? 'flex' : 'none';
        if (repeatVarInput) repeatVarInput.value = project.repeatVariable || '';
    }
    
    renderLocalCast();
    renderNodes();
    renderConversations();
    renderSequences();
    if (typeof updateProjectKindSwitch === 'function') updateProjectKindSwitch();
    if (typeof schedulePushStateRefresh === 'function') schedulePushStateRefresh();
    if (typeof renderProjectTags === 'function') renderProjectTags();
}

function renderLocalCast() {
    const container = document.getElementById('local-cast-tags');
    const project = window.getActiveProject();
    if (!container || !project) {
        if (container) container.innerHTML = '';
        const select = document.getElementById('add-to-local-cast');
        if (select) select.innerHTML = '<option value="">+ Add Character to Scene</option>';
        return;
    }
    
    container.innerHTML = project.participants.map(pName => {
        const cData = window.cast.find(c => c.name === pName) || { color: '#444' };
        return `
            <div class="local-tag" style="border-left-color: ${cData.color}">
                ${escapeHtml(pName)} <span onclick="removeCharFromLocal('${escapeHtml(pName)}')" style="cursor:pointer; margin-left:8px; color:var(--accent-pink);">×</span>
            </div>`;
    }).join('');
    
    updateLocalAddDropdown();
}

function updateLocalAddDropdown() {
    const select = document.getElementById('add-to-local-cast');
    if (!select) return;
    const currentLocal = (window.activeIndex !== null) ? window.getActiveProject().participants : [];
    const available = window.cast.filter(c => !currentLocal.includes(c.name));
    select.innerHTML = `<option value="">+ Add Character to Scene</option>` + 
                       available.map(c => `<option value="${escapeHtml(c.name)}">${escapeHtml(c.name)}</option>`).join('');
}

function injectProjectHeaderUI(project) {
    if (!project) {
        if (typeof window.resetProjectContextUI === 'function') {
            window.resetProjectContextUI({ clearDraftInputs: false });
        }
        return;
    }
    if (!project.id) project.id = crypto.randomUUID();

    const titleInput = document.getElementById('edit-conv-name');
    if (!titleInput) return;

    const idRow = document.getElementById('project-id-row');
    const langRow = document.getElementById('dynamic-lang-row');
    const downloadButton = document.getElementById('download-single-project');

    if (downloadButton) {
        downloadButton.onclick = () => window.exportSingleProject();
        downloadButton.disabled = false;
    }

    if (idRow) {
        idRow.innerHTML = '';

        const idValue = document.createElement('div');
        idValue.className = 'project-id-value';
        idValue.textContent = project.id;

        const idButton = document.createElement('button');
        idButton.className = 'project-id-copy-button';
        idButton.type = 'button';
        idButton.title = 'Copy Conversation ID';
        idButton.innerHTML = getCopyIcon();
        idButton.onclick = (event) => {
            copyToClipboard(project.id, idButton);
            event.stopPropagation();
        };

        idRow.appendChild(idValue);
        idRow.appendChild(idButton);
    }

    if (typeof updateProjectKindSwitch === 'function') updateProjectKindSwitch();
    if (typeof updatePushToServerButton === 'function') updatePushToServerButton();

    if (langRow) {
        langRow.innerHTML = `
            <div class="project-language-row">
                <label class="project-language-label">Language</label>
                <select class="custom-scrollbar project-language-select" onchange="setCurrentLanguage(this.value);">
                    ${(window.availableLanguages || []).map(l => `<option value="${escapeHtml(l)}" ${window.currentLanguage === l ? 'selected' : ''}>${escapeHtml(l)}</option>`).join('')}
                </select>
                <button class="btn btn-green project-language-add-button" type="button" title="Add new translation language" onclick="toggleAddLanguage()">+</button>
            </div>
            <div class="project-language-add-row" style="display:${window.isAddingLanguage ? 'flex' : 'none'};">
                <input class="project-language-add-input" type="text" id="new-lang-code" placeholder="EX: ITA" maxlength="3">
                <button class="btn btn-teal" type="button" style="padding: 7px 12px; font-size: 0.7rem;" onclick="confirmAddLanguage()">Add</button>
            </div>
        `;
    }
}

// --- NODE RENDERING (UPDATED) ---
function renderNodes() {
    const container = document.getElementById('node-container');
    const project = window.getActiveProject();
    if (!container || !project) return;
    
    injectProjectHeaderUI(project);
    if (typeof ensureProjectTranslationContainers === 'function') ensureProjectTranslationContainers(project);
    
    let contentHTML = '';

    project.nodes.forEach((node, nIdx) => {
        const themeColor = node.nodeColor || project.color || '#ff007b';
        const speakerData = window.cast.find(c => c.name === node.speaker) || { color: themeColor };
        const speakerColor = speakerData.color || themeColor;
        
        const nodeText = typeof getLocalizedText === 'function' ? getLocalizedText(node, window.currentLanguage) : ((node.translations && Object.prototype.hasOwnProperty.call(node.translations, window.currentLanguage)) ? node.translations[window.currentLanguage] : '');

        const incomingLinks = [];
        project.nodes.forEach((parentNode, parentNodeIdx) => {
            (parentNode.responses || []).forEach((response, responseIdx) => {
                if (response.nextStatementId === node.id) {
                    incomingLinks.push({ parentNode, parentNodeIdx, response, responseIdx });
                }
            });
        });

        const incomingLinksCount = incomingLinks.length;
        const validNodeConds = (node.conditions || []).filter(c => (c.variable && c.variable.trim() !== '') || (c.value && c.value.trim() !== ''));
        const validNodeStates = (node.gameStateChanges || []).filter(c => (c.variable && c.variable.trim() !== '') || (c.value && c.value.trim() !== ''));
        let hasMatchingStateChange = false;
        if (validNodeConds.length > 0) {
            hasMatchingStateChange = validNodeConds.some(cond => {
                return project.nodes.some(n =>
                    (n.gameStateChanges || []).some(gsc => gsc.variable === cond.variable && gsc.value === cond.value) ||
                    (n.responses || []).some(r => (r.gameStateChanges || []).some(gsc => gsc.variable === cond.variable && gsc.value === cond.value))
                );
            });
        }

        const needsBlueGlow = validNodeConds.length > 0 && !hasMatchingStateChange && !node.makeExternalCall;
        const needsRedGlow = incomingLinksCount === 0 && !node.externalCall && !hasMatchingStateChange;
        let nodeGlowBorder = 'var(--border-color)';
        let nodeGlowShadow = 'none';
        if (needsRedGlow && needsBlueGlow) {
            nodeGlowBorder = 'var(--accent-purple)';
            nodeGlowShadow = '0 0 20px rgba(176, 38, 255, 0.6)';
        } else if (needsRedGlow) {
            nodeGlowBorder = 'var(--accent-pink)';
            nodeGlowShadow = '0 0 20px rgba(255, 0, 123, 0.6)';
        } else if (needsBlueGlow) {
            nodeGlowBorder = 'var(--accent-teal)';
            nodeGlowShadow = '0 0 20px rgba(0, 242, 255, 0.6)';
        }
        const collapsedHoverBorder = nodeGlowBorder !== 'var(--border-color)' ? nodeGlowBorder : themeColor;
        const collapsedHoverShadow = nodeGlowShadow !== 'none' ? nodeGlowShadow : '0 0 10px ' + themeColor + '40';
        const nodeHasWarning = needsRedGlow || needsBlueGlow;
        const responseWarningCount = (node.responses || []).reduce((total, response) => {
            const flags = getResponseWarningFlags(project, response);
            return total + ((flags.red || flags.blue) ? 1 : 0);
        }, 0);
        const collapsedWarningCount = Math.min(5, (nodeHasWarning ? 1 : 0) + responseWarningCount);
        const collapsedWarningHtml = collapsedWarningCount > 0 ? `<div class="collapsed-warning-badge">${getWarningIconSvg()}<span>${collapsedWarningCount}</span></div>` : '';

        const nodeHeaderTab = `
            <div class="node-header-tab" style="position: absolute; top: -30px; left: -5px; display: flex; border: 1px solid ${themeColor}; border-bottom: none; border-top-left-radius: 6px; border-top-right-radius: 6px; overflow: hidden; z-index: 10; height: 30px; box-shadow: 0 -2px 10px rgba(0,0,0,0.5);">
                <div onclick="toggleNodeCollapse(${nIdx}, event)" style="background: ${themeColor}; color: #000; font-size: 0.8rem; font-weight: 900; padding: 0 12px; display: flex; align-items: center; justify-content: center; cursor: pointer;" title="Click to Collapse Statement">
                    #${nIdx + 1}
                </div>
                <div style="background: #000; padding: 0 8px; display: flex; flex-direction: column; justify-content: center; line-height: 1.1;">
                    <span style="font-size: 0.45rem; color: #fff; text-transform: uppercase; font-weight: 900; letter-spacing: 1px;">Move</span>
                    <span style="font-size: 0.45rem; color: #fff; text-transform: uppercase; font-weight: 900; letter-spacing: 1px;">To</span>
                </div>
                <div style="background: #000; padding: 0 8px; display: flex; align-items: center; border-left: 1px solid #222; position: relative;">
                    <select class="custom-scrollbar" onchange="moveNode(${nIdx}, parseInt(this.value))" style="font-size: 0.75rem; padding: 2px 22px 2px 6px; background: #0a0a0a; border: 1px solid #333; color: ${themeColor}; font-weight: bold; cursor: pointer; outline: none; appearance: none; -webkit-appearance: none;">
                        ${project.nodes.map((_, i) => `<option value="${i}" ${i === nIdx ? 'selected' : ''} style="background: #111; color: #fff;">#${i + 1}</option>`).join('')}
                    </select>
                    <svg style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); pointer-events: none; color: ${themeColor};" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>
                </div>
                <div style="background: #000; display: flex; flex-direction: column; justify-content: center; gap: 2px; padding: 0 6px; border-left: 1px solid #222;">
                    <button onclick="toggleNodeDeep(${nIdx}, true, event)" style="background: #1a1a1a; color: #fff; border: 1px solid #333; border-radius: 2px; height: 10px; width: 20px; font-weight: 900; font-size: 8px; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: 0.2s; line-height: 1;" onmouseover="this.style.borderColor='var(--accent-teal)'; this.style.color='var(--accent-teal)';" onmouseout="this.style.borderColor='#333'; this.style.color='#fff';" title="Expand Internal Settings">+</button>
                    <button onclick="toggleNodeDeep(${nIdx}, false, event)" style="background: #1a1a1a; color: #fff; border: 1px solid #333; border-radius: 2px; height: 10px; width: 20px; font-weight: 900; font-size: 8px; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: 0.2s; line-height: 1;" onmouseover="this.style.borderColor='var(--accent-teal)'; this.style.color='var(--accent-teal)';" onmouseout="this.style.borderColor='#333'; this.style.color='#fff';" title="Collapse Internal Settings">-</button>
                </div>
            </div>
        `;

        // --- COLLAPSED VIEW RENDER ---
        if (node.isCollapsed) {
            const cleanText = nodeText ? nodeText.replace(/<[^>]*>?/gm, '') : '';
            const isBranching = node.conditions.length > 0 || (node.gameStateChanges && node.gameStateChanges.length > 0);
            const respCount = (node.responses || []).length;
            const voiceLineCount = (node.voiceLine !== false ? 1 : 0) + (node.responses || []).filter(r => r && r.voiceLine === true).length;
            const voiceLineLabel = voiceLineCount === 1 ? 'Voice Line' : `${voiceLineCount} Voice Lines`;
            
            contentHTML += `
                <div class="dialogue-node collapsed" id="node-${node.id}" onmousedown="setTraversedNode(${nIdx})" style="padding: 0; background: transparent; border: none; border-left: 5px solid transparent; box-shadow: none; margin-bottom: 40px; margin-top: 15px;">
                    ${nodeHeaderTab}
                    <div id="collapsed-node-card-${node.id}" style="padding: 15px 15px 15px 20px; background: #0a0a0a; border: 1px solid ${nodeGlowBorder}; border-left: 5px solid ${themeColor}; border-top-left-radius: 0; border-top-right-radius: 8px; border-bottom-right-radius: 8px; border-bottom-left-radius: 8px; color: #888; cursor: pointer; position: relative; transition: 0.2s; display: flex; align-items: stretch; justify-content: space-between; min-height: 80px; box-shadow: ${nodeGlowShadow};" 
                         onclick="toggleNodeCollapse(${nIdx}, event)"
                         onmouseover="this.style.borderColor='${collapsedHoverBorder}'; this.style.boxShadow='${collapsedHoverShadow}';" 
                         onmouseout="this.style.borderColor='${nodeGlowBorder}'; this.style.boxShadow='${nodeGlowShadow}';">
                        ${collapsedWarningHtml}
                        
                        <div style="display: flex; flex-direction: column; justify-content: center; overflow: hidden; padding-right: 15px; flex: 1;">
                            <div style="display: flex; align-items: baseline; gap: 6px; margin-bottom: 4px;">
                                <span style="font-size: 0.7rem; color: var(--text-dim); text-transform: uppercase; font-weight: bold;">Speaker:</span>
                                <strong style="color: ${speakerColor}; font-size: 0.95rem;">${escapeHtml(node.speaker || 'Unassigned')}</strong>
                            </div>
                            <div style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 0.7rem; color: #888; font-style: italic; width: 100%; display: block;">
                                "${escapeHtml(cleanText)}"
                            </div>
                        </div>

                        <div style="display: flex; flex-direction: column; justify-content: space-between; align-items: flex-end; flex-shrink: 0;">
                            <div style="display: flex; align-items: center; gap: 5px; pointer-events: auto;">
                                <div style="font-size: 0.55rem; color: #666; font-style: italic; font-family: monospace; user-select: text;">${node.id}</div>
                                <button onclick="copyToClipboard('${node.id}', this); event.stopPropagation();" style="background: transparent; border: 1px solid #444; color: #888; border-radius: 3px; cursor: pointer; padding: 2px 4px; display:flex; align-items:center;">${getCopyIcon()}</button>
                            </div>
                            <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 2px; margin-top: 5px;">
                                ${voiceLineCount > 0 ? `<span style="font-size: 0.6rem; font-weight: bold; color: var(--accent-pink); text-transform:uppercase;">${voiceLineLabel}</span>` : ''}
                                ${isBranching ? '<span style="font-size: 0.6rem; font-weight: bold; color: var(--accent-orange); text-transform:uppercase;">Branching</span>' : ''}
                                ${respCount > 0 ? `<span style="font-size: 0.6rem; font-weight: bold; color: #fff; text-transform:uppercase;">${respCount} Response${respCount > 1 ? 's' : ''}</span>` : ''}
                            </div>
                        </div>
                    </div>
                </div>
            `;
            return; 
        }

        // --- EXPANDED VIEW RENDER ---
        let nodeStyle = `position: relative; transition: border-color 0.3s, box-shadow 0.3s; padding: 30px; margin-top: 15px; margin-bottom: 40px; background: var(--bg-node); border: 1px solid ${nodeGlowBorder}; border-left: 5px solid ${themeColor}; border-top-left-radius: 0; box-shadow: ${nodeGlowShadow};`;
        
        const nodeSysToggles = `
            <div style="position: absolute; top: 10px; right: 15px; display: flex; flex-direction: column; align-items: flex-end; gap: 4px; z-index: 10;">
                <div style="display: flex; align-items: center; gap: 5px;">
                    <div style="font-size: 0.55rem; color: #777; font-style: italic; font-family: monospace; user-select: text;">${node.id}</div>
                    <button onclick="copyToClipboard('${node.id}', this)" style="background: transparent; border: 1px solid #444; color: #888; border-radius: 3px; cursor: pointer; padding: 2px 4px; display:flex; align-items:center;">${getCopyIcon()}</button>
                </div>
                <div style="display: flex; gap: 10px; align-items: center; margin-top: 4px;">
                    <label style="font-size: 0.6rem; color: #ffffff; display: flex; align-items: center; gap: 4px; cursor: pointer; text-transform: uppercase; font-weight: bold;">
                        Called Externally
                        <input type="checkbox" ${node.externalCall ? 'checked' : ''} onclick="window.getActiveProject().nodes[${nIdx}].externalCall = this.checked; markNodeEdited(${nIdx}); updateNodeGlows();">
                    </label>
                    <label style="font-size: 0.6rem; color: #ffffff; display: flex; align-items: center; gap: 4px; cursor: pointer; text-transform: uppercase; font-weight: bold;">
                        Make External Call
                        <input type="checkbox" ${node.makeExternalCall ? 'checked' : ''} onclick="window.getActiveProject().nodes[${nIdx}].makeExternalCall = this.checked; markNodeEdited(${nIdx}); updateNodeGlows();">
                    </label>
                </div>
            </div>
        `;
        
        let replyTag = '';
        const eligibleParents = project.nodes.filter(n => n.id !== node.id && (n.responses || []).length < 4);
        
        let incomingLinksHtml = incomingLinks.map(link => `
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom: 8px; padding-bottom: 8px; border-bottom: 1px dashed rgba(255, 140, 0, 0.2);">
                <div>
                    <button style="background: var(--accent-orange); color: #000; font-weight: 900; font-size: 0.6rem; padding: 3px 8px; border-radius: 2px; border: none; cursor: pointer; text-transform: uppercase; letter-spacing: 1px; display: inline-flex; align-items: center; gap: 5px; margin-bottom: 5px;"
                            onclick="jumpToResponseFromIncoming(${link.parentNodeIdx}, ${link.responseIdx})" title="Jump to parent response">
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 10 20 15 15 20"></polyline><path d="M4 4v7a4 4 0 0 0 4 4h12"></path></svg>
                        FROM: ${escapeHtml(link.parentNode.speaker || 'Unknown')} (Statement #${link.parentNodeIdx + 1})
                    </button>
                    <div style="font-size: 0.75rem; color: #aaa; font-style: italic; line-height: 1.3;">
                        "${escapeHtml(link.parentNode.text ? link.parentNode.text.substring(0, 40) + '...' : 'Empty Statement')}"<br>
                        <span style="color:var(--accent-teal); font-weight: bold;">↳ via Response: "${escapeHtml(link.response.text)}"</span>
                    </div>
                </div>
                <button class="btn btn-outline" style="padding: 3px 6px; font-size: 0.55rem; color: var(--accent-pink); border-color: var(--accent-pink);" onclick="unlinkSpecificReverseReply(${nIdx}, '${link.parentNode.id}', '${link.response.id}')" title="Sever this connection">Unlink</button>
            </div>
        `).join('');

        let reverseReplyDropdownHtml = '';
        if (eligibleParents.length > 0) {
            reverseReplyDropdownHtml = `
                <div style="display: flex; align-items: center; gap: 10px; margin-top: ${incomingLinks.length > 0 ? '10px' : '0'};">
                    <span style="font-size: 0.65rem; color: var(--text-dim); text-transform: uppercase; font-weight: 800; white-space:nowrap;">Connect From:</span>
                    <select id="reverse-link-select-${nIdx}" class="custom-scrollbar" style="flex: 1; padding: 4px; font-size: 0.75rem; background: #000; border: 1px solid var(--border-color); color: #fff;">
                        <option value="">-- Select a previous statement... --</option>
                        ${eligibleParents.map((n, i) => `<option value="${n.id}">Statement #${i + 1} [node_id:${n.id.substring(0,8)}...] (${escapeHtml(n.speaker || 'Unknown')})</option>`).join('')}
                    </select>
                    <button class="btn btn-outline" style="padding: 4px 10px; font-size: 0.65rem; border-color: var(--accent-teal); color: var(--accent-teal);" onclick="establishReverseReply(${nIdx})">Link</button>
                </div>
            `;
        }

        if (incomingLinks.length > 0 || eligibleParents.length > 0) {
            replyTag = `
                <div style="margin-top: 15px; margin-bottom: 20px; padding: 15px; background: rgba(255, 140, 0, 0.05); border-left: 3px solid var(--accent-orange); border-radius: 0 4px 4px 0;">
                    ${incomingLinks.length > 0 ? `<div style="font-size: 0.65rem; color: var(--accent-orange); font-weight: 800; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 10px;">Incoming Connections (${incomingLinks.length})</div>` : ''}
                    ${incomingLinksHtml}
                    ${reverseReplyDropdownHtml}
                </div>
            `;
        }

        const selectedPuppetNames = new Set((node.puppets || []).map(p => p.name));
        const availablePuppets = (project.participants || [])
            .filter(name => !selectedPuppetNames.has(name))
            .map(name => window.cast.find(c => c.name === name) || { name, color: '#444' });
        const tf = node.textFormat || { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
        
        let textStyleStr = '';
        textStyleStr += tf.bold ? 'font-weight: bold; ' : 'font-weight: normal; ';
        textStyleStr += tf.italic ? 'font-style: italic; ' : 'font-style: normal; ';
        let decos = [];
        if (tf.underline) decos.push('underline');
        if (tf.strikethrough) decos.push('line-through');
        textStyleStr += `text-decoration: ${decos.length > 0 ? decos.join(' ') : 'none'}; `;
        textStyleStr += `text-align: ${tf.alignH === 'justified' ? 'justify' : tf.alignH}; `;
        if (tf.listStyle !== 'none') textStyleStr += 'padding-left: 30px; ';

        contentHTML += `
            <div class="dialogue-node" id="node-${node.id}" onmousedown="setTraversedNode(${nIdx})" style="${nodeStyle}">
            ${nodeHeaderTab}
            ${nodeSysToggles}
            <div style="height:25px;"></div>
            ${replyTag}

            <details class="logic-block" style="margin-top: 25px; margin-bottom: 20px; padding: 0; background: #050505; border: 1px solid var(--border-color); border-radius: 8px; box-shadow: inset 0 0 10px rgba(0,0,0,0.5); width: 100%; box-sizing: border-box; overflow: hidden;" ${node.conditionsOpen !== false ? 'open' : ''} ontoggle="window.getActiveProject().nodes[${nIdx}].conditionsOpen = this.open;">
                <summary class="logic-header" style="background: var(--bg-node); padding: 15px; outline: none; cursor: pointer; border-bottom: ${node.conditionsOpen !== false ? '1px dashed #333' : 'none'}; margin-bottom: 0;">
                    <div style="display: flex; align-items: center; justify-content: space-between; width: 100%;">
                        <div class="logic-title">Conditions</div>
                        <button class="logic-add-btn btn-green" onclick="addConditionRow(${nIdx}); event.stopPropagation(); event.preventDefault();">+</button>
                    </div>
                </summary>
                <div style="padding: 15px;">
                    ${(node.conditions || []).map((cond, cIdx) => `
                        <div class="logic-row" id="node-condition-row-${nIdx}-${cIdx}">
                            <input type="text" class="logic-input" value="${escapeHtml(cond.variable || '')}" oninput="updateCondition(${nIdx}, ${cIdx}, 'variable', this.value); updateNodeGlows();" placeholder="Variable...">
                            <select class="logic-select" onchange="updateCondition(${nIdx}, ${cIdx}, 'operator', this.value); updateNodeGlows();">
                                <option value="==" ${cond.operator === '==' ? 'selected' : ''}>==</option>
                                <option value="!=" ${cond.operator === '!=' ? 'selected' : ''}>!=</option>
                                <option value=">" ${cond.operator === '>' ? 'selected' : ''}>&gt;</option>
                                <option value="<" ${cond.operator === '<' ? 'selected' : ''}>&lt;</option>
                                <option value=">=" ${cond.operator === '>=' ? 'selected' : ''}>&gt;=</option>
                                <option value="<=" ${cond.operator === '<=' ? 'selected' : ''}>&lt;=</option>
                            </select>
                            <input type="text" class="logic-input" value="${escapeHtml(cond.value || '')}" oninput="updateCondition(${nIdx}, ${cIdx}, 'value', this.value); updateNodeGlows();" placeholder="Value...">
                            <span class="logic-delete" onclick="removeConditionRow(${nIdx}, ${cIdx})">×</span>
                        </div>
                    `).join('')}
                </div>
            </details>

            <div class="node-header" style="margin-top: 15px; align-items: flex-start;">
                <div style="display:flex; align-items:center; gap:15px; flex:1;">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <span class="${node.speaker === '' ? 'missing-speaker' : ''}" style="font-size:0.7rem; color:var(--text-dim); font-weight:800; text-transform:uppercase; transition: 0.3s;">Speaker</span>
                        <select class="custom-scrollbar" onchange="window.getActiveProject().nodes[${nIdx}].speaker = this.value; markNodeEdited(${nIdx}); renderNodes();">
                            <option value="">-- Select --</option>
                            ${project.participants.map(p => `<option value="${escapeHtml(p)}" ${p === node.speaker ? 'selected' : ''} style="color:white;">${escapeHtml(p)}</option>`).join('')}
                        </select>
                    </div>
                    <div style="display:flex; align-items:center; gap:8px;">
                        <span style="font-size:0.7rem; color:var(--text-dim); font-weight:800; text-transform:uppercase;">Panel Color</span>
                        <input type="color" value="${themeColor}" onchange="window.getActiveProject().nodes[${nIdx}].nodeColor = this.value; markNodeEdited(${nIdx}); renderNodes();" style="width:28px; height:28px; padding:0; border:1px solid #333; cursor:pointer;">
                    </div>
                </div>
                <div style="display:flex; flex-direction:column; align-items:flex-end; gap:6px;">
                    <button class="btn btn-outline" style="color:var(--accent-pink); border-color:transparent; padding:0 10px; margin-bottom: 2px;" 
                        onclick="deleteNode(${nIdx})">Delete Node</button>
                    <label style="font-size: 0.7rem; color: var(--text-dim); font-weight: 800; text-transform: uppercase; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                        Voice Line
                        <input type="checkbox" ${node.voiceLine !== false ? 'checked' : ''} 
                            onclick="window.getActiveProject().nodes[${nIdx}].voiceLine = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                    </label>
                    <label style="font-size: 0.7rem; color: var(--text-dim); font-weight: 800; text-transform: uppercase; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                        Branching
                        <input type="checkbox" ${node.canPlayerRespond ? 'checked' : ''} 
                            onclick="window.getActiveProject().nodes[${nIdx}].canPlayerRespond = !window.getActiveProject().nodes[${nIdx}].canPlayerRespond; markNodeEdited(${nIdx}); renderNodes();">
                    </label>
                </div>
            </div>
            
            <div class="format-toolbar">
                <button class="format-btn font-bold ${tf.bold ? 'active' : ''}" style="font-family: serif;" onclick="applyTextFormat(${nIdx}, 'b')" title="Bold">B</button>
                <button class="format-btn italic ${tf.italic ? 'active' : ''}" style="font-family: serif;" onclick="applyTextFormat(${nIdx}, 'i')" title="Italic">I</button>
                <button class="format-btn underline ${tf.underline ? 'active' : ''}" style="font-family: serif;" onclick="applyTextFormat(${nIdx}, 'u')" title="Underline">U</button>
                <button class="format-btn line-through ${tf.strikethrough ? 'active' : ''}" style="font-family: serif;" onclick="applyTextFormat(${nIdx}, 's')" title="Strikethrough">S</button>
                
                <div class="format-divider"></div>

                <button class="format-btn ${tf.listStyle === 'bullet' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'bullet')" title="Bullet List">
                    <svg viewBox="0 0 24 24"><path d="M4 6h2v2H4zm0 5h2v2H4zm0 5h2v2H4zm4-10h12v2H8zm0 5h12v2H8zm0 5h12v2H8z"></path></svg>
                </button>
                <button class="format-btn ${tf.listStyle === 'number' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'number')" title="Numbered List">
                    <svg viewBox="0 0 24 24"><path d="M5 7h1v2H5zm0 4h1v2H5zm0 4h1v2H5zm3-8h12v2H8zm0 4h12v2H8zm0 4h12v2H8z"></path></svg>
                </button>
                
                <div class="format-divider"></div>

                <button class="format-btn ${tf.alignH === 'left' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'align', 'left')" title="Align Left">
                    <svg viewBox="0 0 24 24"><path d="M3 5h14v2H3V5zm0 6h8v2H3v-2zm0 6h14v2H3v-2z"></path></svg>
                </button>
                <button class="format-btn ${tf.alignH === 'center' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'align', 'center')" title="Align Center">
                    <svg viewBox="0 0 24 24"><path d="M5 5h14v2H5V5zm3 6h8v2H8v-2zm-3 6h14v2H5v-2z"></path></svg>
                </button>
                <button class="format-btn ${tf.alignH === 'right' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'align', 'right')" title="Align Right">
                    <svg viewBox="0 0 24 24"><path d="M7 5h14v2H7V5zm6 6h8v2h-8v-2zm-6 6h14v2H7v-2z"></path></svg>
                </button>
                <button class="format-btn ${tf.alignH === 'justified' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'align', 'justified')" title="Justified">
                    <svg viewBox="0 0 24 24"><path d="M3 5h18v2H3V5zm0 6h18v2H3v-2zm0 6h18v2H3v-2z"></path></svg>
                </button>

                <div class="format-divider"></div>

                <button class="format-btn ${tf.alignV === 'top' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'top')" title="Align Top">
                    <svg viewBox="0 0 24 24"><path d="M5 3h14v2H5V3zm0 4h14v2H5V7zm0 4h8v2H5v-2z"></path></svg>
                </button>
                <button class="format-btn ${tf.alignV === 'middle' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'middle')" title="Align Middle">
                    <svg viewBox="0 0 24 24"><path d="M5 9h14v2H5V9zm0 4h8v2H5v-2zm0 4h14v2H5v-2z"></path></svg>
                </button>
                <button class="format-btn ${tf.alignV === 'bottom' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'bottom')" title="Align Bottom">
                    <svg viewBox="0 0 24 24"><path d="M5 11h8v2H5v-2zm0 4h14v2H5v-2zm0 4h14v2H5v-2z"></path></svg>
                </button>
            </div>
            <textarea id="node-text-${nIdx}" class="node-body custom-scrollbar" placeholder="Enter dialogue..." onchange="updateNodeText(${nIdx}, this.value)" style="${textStyleStr}">${escapeHtml(nodeText)}</textarea>

            ${node.canPlayerRespond ? `
                <details class="logic-block" style="margin-top: 15px; padding: 0; background: #050505; border: 1px solid var(--border-color); border-radius: 8px; box-shadow: inset 0 0 10px rgba(0,0,0,0.5); width: 100%; box-sizing: border-box; overflow: hidden;" ${node.responsesOpen !== false ? 'open' : ''} ontoggle="window.getActiveProject().nodes[${nIdx}].responsesOpen = this.open;">
                    <summary class="logic-header" style="background: var(--bg-node); padding: 15px; outline: none; cursor: pointer; border-bottom: ${node.responsesOpen !== false ? '1px dashed #333' : 'none'}; margin-bottom: 0;">
                        <div style="display: flex; align-items: center; justify-content: space-between; width: 100%;">
                            <div class="logic-title">Response Settings</div>
                        </div>
                    </summary>
                    <div style="padding: 15px;">
                        ${renderResponseSection(nIdx, project)}
                    </div>
                </details>
            ` : ''}

            <div class="game-state-controls">
                <div onclick="toggleAdvancedSettings(${nIdx}, event)" style="cursor: pointer; display: flex; align-items: center; gap: 8px; padding-bottom: 5px; border-bottom: 1px dashed var(--border-color); margin-top: 20px;">
                    <span style="font-size: 0.75rem; color: var(--accent-teal); font-weight: 800; text-transform: uppercase; letter-spacing: 1px;">Advanced</span>
                    <span style="color: var(--accent-teal); font-size: 0.8rem; transform: ${node.advancedOpen ? 'rotate(90deg)' : 'rotate(0deg)'}; transition: transform 0.2s; display: inline-block;">▶</span>
                </div>

                <div style="display: ${node.advancedOpen ? 'flex' : 'none'}; flex-direction: column; gap: 12px; padding-top: 10px;">
                    
                    <div class="state-row">
                        <div class="state-input-group">
                            <label style="color:var(--accent-gold)">Close Main Menu?</label>
                            <input type="checkbox" ${node.closeMainMenu ? 'checked' : ''} onchange="window.getActiveProject().nodes[${nIdx}].closeMainMenu = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        <div class="state-input-group">
                            <label style="color:var(--accent-pink)">Close Dialogue Menu?</label>
                            <input type="checkbox" ${node.closeDialogueMenu ? 'checked' : ''} onchange="window.getActiveProject().nodes[${nIdx}].closeDialogueMenu = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        <div class="state-input-group">
                            <label style="color:var(--accent-teal)">Open Prompt Panel?</label>
                            <input type="checkbox" ${node.openPromptPanel ? 'checked' : ''} onchange="handleNodeExclusivity(${nIdx}, 'openPromptPanel', 'closePromptPanel', this.checked)">
                        </div>
                        <div class="state-input-group">
                            <label style="color:var(--accent-teal)">Close Prompt Panel?</label>
                            <input type="checkbox" ${node.closePromptPanel ? 'checked' : ''} onchange="handleNodeExclusivity(${nIdx}, 'closePromptPanel', 'openPromptPanel', this.checked)">
                        </div>
                    </div>
                    <hr class="cyber-hr" style="margin: 5px 0;">

                    <div class="state-row">
                        <div class="state-input-group">
                            <label style="color:var(--accent-purple)">Control Sequence Image?</label>
                            <input type="checkbox" ${node.controlSequence ? 'checked' : ''} onchange="window.getActiveProject().nodes[${nIdx}].controlSequence = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                    </div>
                    ${node.controlSequence ? `
                        <div class="state-row" style="margin-left: 15px; border-left: 2px solid var(--accent-purple); padding-left: 10px; margin-bottom: 10px;">
                            <div class="state-input-group" style="flex:1;">
                                <label>Sequence</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="window.getActiveProject().nodes[${nIdx}].sequenceName = this.value; window.getActiveProject().nodes[${nIdx}].sequenceImage = ''; markNodeEdited(${nIdx}); renderNodes();">
                                    <option value="">-- Select Sequence --</option>
                                    ${window.globalImageSequences.map(s => `<option value="${escapeHtml(s.name)}" ${node.sequenceName === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Image Name</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="window.getActiveProject().nodes[${nIdx}].sequenceImage = this.value; markNodeEdited(${nIdx}); renderNodes();">
                                    <option value="">-- Select Image --</option>
                                    ${(window.globalImageSequences.find(s => s.name === node.sequenceName)?.images || []).map(img => `<option value="${escapeHtml(img)}" ${node.sequenceImage === img ? 'selected' : ''}>${escapeHtml(img)}</option>`).join('')}
                                </select>
                            </div>
                        </div>
                    ` : ''}

                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Change Menu Option?</label>
                            <input type="checkbox" ${node.changeMenuOption ? 'checked' : ''} 
                                onchange="window.getActiveProject().nodes[${nIdx}].changeMenuOption = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        ${node.changeMenuOption ? `
                            <button class="btn btn-outline" style="padding: 4px 10px; font-size: 0.6rem; margin-left: auto; border-color: var(--accent-orange); color: var(--accent-orange);" 
                                onclick="addMenuChangeRow(${nIdx})">+ Add Menu Change</button>
                        ` : ''}
                    </div>
                    ${node.changeMenuOption ? (node.menuOptionChanges || []).map((change, cIdx) => `
                        <div class="state-row">
                            <div class="state-input-group" style="flex:1;">
                                <label>Menu Option</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="updateMenuChange(${nIdx}, ${cIdx}, 'menu', this.value)">
                                    <option value="">-- Select Menu --</option>
                                    ${window.globalMenuOptions.map(s => `<option value="${escapeHtml(s.name)}" ${change.menu === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Value</label>
                                <input type="text" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" 
                                    value="${escapeHtml(change.value || '')}" 
                                    onchange="updateMenuChange(${nIdx}, ${cIdx}, 'value', this.value)">
                            </div>
                            ${(node.menuOptionChanges.length > 1) ? `
                                <span onclick="removeMenuChangeRow(${nIdx}, ${cIdx})" 
                                      style="cursor:pointer; color:var(--accent-pink); font-weight:bold; padding: 0 5px;">×</span>
                            ` : ''}
                        </div>
                    `).join('') : ''}

                    <hr class="cyber-hr" style="margin: 5px 0;">
                    
                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Background Use Path?</label>
                            <input type="checkbox" ${node.usePath ? 'checked' : ''} 
                                onchange="window.getActiveProject().nodes[${nIdx}].usePath = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        ${node.usePath ? `
                            <input type="text" style="flex:1; padding: 6px 12px; font-size: 0.8rem;" 
                                placeholder="Path..." 
                                value="${escapeHtml(node.resourcePath || 'Assets/Resources/Slides/')}" 
                                onchange="window.getActiveProject().nodes[${nIdx}].resourcePath = this.value; markNodeEdited(${nIdx});">
                        ` : ''}
                    </div>

                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Change Setting?</label>
                            <input type="checkbox" ${node.changeSetting ? 'checked' : ''} 
                                onchange="window.getActiveProject().nodes[${nIdx}].changeSetting = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        ${node.changeSetting ? `
                            <button class="btn btn-outline" style="padding: 4px 10px; font-size: 0.6rem; margin-left: auto; border-color: var(--accent-orange); color: var(--accent-orange);" 
                                onclick="addSettingChangeRow(${nIdx})">+ Add Setting Change</button>
                        ` : ''}
                    </div>
                    ${node.changeSetting ? (node.settingChanges || []).map((change, cIdx) => `
                        <div class="state-row">
                            <div class="state-input-group" style="flex:1;">
                                <label>Setting</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="updateSettingChange(${nIdx}, ${cIdx}, 'setting', this.value)">
                                    <option value="">-- Select Setting --</option>
                                    ${window.globalSettings.map(s => `<option value="${escapeHtml(s.name)}" ${change.setting === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Value</label>
                                <input type="text" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" 
                                    value="${escapeHtml(change.value || '')}" 
                                    onchange="updateSettingChange(${nIdx}, ${cIdx}, 'value', this.value)">
                            </div>
                            ${(node.settingChanges.length > 1) ? `
                                <span onclick="removeSettingChangeRow(${nIdx}, ${cIdx})" 
                                      style="cursor:pointer; color:var(--accent-pink); font-weight:bold; padding: 0 5px;">×</span>
                            ` : ''}
                        </div>
                    `).join('') : ''}

                    <hr class="cyber-hr" style="margin: 5px 0;">

                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Change Time of Day?</label>
                            <input type="checkbox" ${node.changeTimeOfDay ? 'checked' : ''} 
                                onchange="window.getActiveProject().nodes[${nIdx}].changeTimeOfDay = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        ${node.changeTimeOfDay ? `
                            <button class="btn btn-outline" style="padding: 4px 10px; font-size: 0.6rem; margin-left: auto; border-color: var(--accent-orange); color: var(--accent-orange);" 
                                onclick="addTimeChangeRow(${nIdx})">+ Add Time Change</button>
                        ` : ''}
                    </div>
                    ${node.changeTimeOfDay ? (node.timeOfDayChanges || []).map((change, cIdx) => `
                        <div class="state-row">
                            <div class="state-input-group" style="flex:1;">
                                <label>Time</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="updateTimeChange(${nIdx}, ${cIdx}, 'time', this.value)">
                                    <option value="">-- Select Time --</option>
                                    ${window.globalTimesOfDay.map(s => `<option value="${escapeHtml(s.name)}" ${change.time === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Value</label>
                                <input type="text" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" 
                                    value="${escapeHtml(change.value || '')}" 
                                    onchange="updateTimeChange(${nIdx}, ${cIdx}, 'value', this.value)">
                            </div>
                            ${(node.timeOfDayChanges.length > 1) ? `
                                <span onclick="removeTimeChangeRow(${nIdx}, ${cIdx})" 
                                      style="cursor:pointer; color:var(--accent-pink); font-weight:bold; padding: 0 5px;">×</span>
                            ` : ''}
                        </div>
                    `).join('') : ''}

                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Change Day of Week?</label>
                            <input type="checkbox" ${node.changeDayOfWeek ? 'checked' : ''} 
                                onchange="window.getActiveProject().nodes[${nIdx}].changeDayOfWeek = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        ${node.changeDayOfWeek ? `
                            <button class="btn btn-outline" style="padding: 4px 10px; font-size: 0.6rem; margin-left: auto; border-color: var(--accent-orange); color: var(--accent-orange);" 
                                onclick="addDayChangeRow(${nIdx})">+ Add Day Change</button>
                        ` : ''}
                    </div>
                    ${node.changeDayOfWeek ? (node.dayOfWeekChanges || []).map((change, cIdx) => `
                        <div class="state-row">
                            <div class="state-input-group" style="flex:1;">
                                <label>Day</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="updateDayChange(${nIdx}, ${cIdx}, 'day', this.value)">
                                    <option value="">-- Select Day --</option>
                                    ${window.globalDaysOfWeek.map(s => `<option value="${escapeHtml(s.name)}" ${change.day === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Value</label>
                                <input type="text" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" 
                                    value="${escapeHtml(change.value || '')}" 
                                    onchange="updateDayChange(${nIdx}, ${cIdx}, 'value', this.value)">
                            </div>
                            ${(node.dayOfWeekChanges.length > 1) ? `
                                <span onclick="removeDayChangeRow(${nIdx}, ${cIdx})" 
                                      style="cursor:pointer; color:var(--accent-pink); font-weight:bold; padding: 0 5px;">×</span>
                            ` : ''}
                        </div>
                    `).join('') : ''}

                    <hr class="cyber-hr" style="margin: 5px 0;">
                    
                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Control Puppets?</label>
                            <input type="checkbox" ${node.controlPuppets ? 'checked' : ''} 
                                onchange="toggleControlPuppets(${nIdx}, this.checked)">
                        </div>
                    </div>

                    ${node.controlPuppets ? `
                        <div style="margin-top: 5px; padding-left: 10px; border-left: 2px solid var(--accent-orange);">
                            <select class="custom-scrollbar" onchange="addPuppetToNode(${nIdx}, this.value)" style="width: 100%; font-size: 0.8rem; padding: 8px;">
                                <option value="">+ Add Character Puppet to Statement</option>
                                ${availablePuppets.map(c => `<option value="${escapeHtml(c.name)}">${escapeHtml(c.name)}</option>`).join('')}
                            </select>

                            <div style="display:flex; flex-wrap:wrap; gap:10px; margin-top:15px;">
                                ${(node.puppets || []).map((p, pIdx) => `
                                    <div class="puppet-tag ${p.enabled ? '' : 'disabled'}">
                                        <input type="checkbox" ${p.enabled ? 'checked' : ''} onchange="togglePuppetEnabled(${nIdx}, ${pIdx}, this.checked)" title="Enable/Disable Puppet">
                                        <span>${escapeHtml(p.name)}</span>
                                        ${p.enabled ? `
                                            <label style="font-size:0.6rem; color:var(--text-dim); margin-left:5px;">POS:</label>
                                            <input type="text" maxlength="2" class="puppet-pos-input" value="${escapeHtml(p.position || '')}" onchange="updatePuppetPosition(${nIdx}, ${pIdx}, this.value)" placeholder="--">
                                        ` : ''}
                                        <span onclick="removePuppetFromNode(${nIdx}, ${pIdx})" style="cursor:pointer; margin-left:5px; color:var(--accent-pink); font-weight:bold;">×</span>
                                    </div>
                                `).join('')}
                            </div>

                            ${(node.puppets || []).length > 0 ? `
                                <div class="state-row" style="margin-top: 15px; flex-wrap: wrap;">
                                    <div class="state-input-group">
                                        <label>Change State?</label>
                                        <input type="checkbox" ${node.changePuppetState ? 'checked' : ''} onchange="toggleChangePuppetState(${nIdx}, this.checked)">
                                    </div>
                                    ${node.changePuppetState ? `
                                        <div class="state-input-group" style="margin-left: 10px; border-left: 1px dashed var(--border-color); padding-left: 10px;">
                                            <label style="color:var(--accent-teal)">Puppet Use Tag?</label>
                                            <input type="checkbox" ${node.puppetUseTag ? 'checked' : ''} onchange="togglePuppetUseTag(${nIdx}, this.checked)">
                                        </div>
                                        <div class="state-input-group">
                                            <label style="color:var(--accent-orange)">Puppet Use Path?</label>
                                            <input type="checkbox" ${node.puppetUsePath ? 'checked' : ''} onchange="togglePuppetUsePath(${nIdx}, this.checked)">
                                        </div>
                                    ` : ''}
                                    <div class="state-input-group" style="${node.changePuppetState ? 'margin-left: 10px; border-left: 1px dashed var(--border-color); padding-left: 10px;' : ''}">
                                        <label>Change Mood?</label>
                                        <input type="checkbox" ${node.changePuppetMood ? 'checked' : ''} onchange="toggleChangePuppetMood(${nIdx}, this.checked)">
                                    </div>
                                    <div class="state-input-group">
                                        <label>Invert?</label>
                                        <input type="checkbox" ${node.changePuppetInvert ? 'checked' : ''} onchange="toggleChangePuppetInvert(${nIdx}, this.checked)">
                                    </div>
                                </div>
                                ${((node.changePuppetState && (node.puppetUsePath || node.puppetUseTag)) || node.changePuppetMood || node.changePuppetInvert) ? `
                                    <div style="display:flex; flex-direction:column; gap:10px; margin-top:10px;">
                                        ${(node.puppets || []).map((p, pIdx) => `
                                            <div class="puppet-path-row">
                                                <span style="font-size:0.75rem; color:var(--accent-teal); min-width:80px; font-weight:bold;">${escapeHtml(p.name)}</span>
                                                ${(node.changePuppetState && node.puppetUsePath) ? `
                                                    <input type="text" style="flex:1; padding:6px 10px; font-size:0.8rem; min-width: 150px;" 
                                                        value="${escapeHtml(p.path || 'Assets/Resources/Puppets/')}" 
                                                        onchange="updatePuppetPath(${nIdx}, ${pIdx}, this.value)">
                                                ` : ''}
                                                ${(node.changePuppetState && node.puppetUseTag) ? `
                                                    <select class="custom-scrollbar" style="flex:1; padding:6px; font-size:0.8rem; min-width: 100px;" onchange="updatePuppetState(${nIdx}, ${pIdx}, this.value)">
                                                        <option value="">-- Select State --</option>
                                                        ${window.globalStates.map(s => `<option value="${escapeHtml(s.name)}" ${p.state === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                                    </select>
                                                ` : ''}
                                                ${node.changePuppetMood ? `
                                                    <select class="custom-scrollbar" style="flex:1; padding:6px; font-size:0.8rem; min-width: 100px;" onchange="updatePuppetMood(${nIdx}, ${pIdx}, this.value)">
                                                        <option value="">-- Select Mood --</option>
                                                        ${window.globalMoods.map(m => `<option value="${escapeHtml(m.name)}" ${p.mood === m.name ? 'selected' : ''}>${escapeHtml(m.name)}</option>`).join('')}
                                                    </select>
                                                ` : ''}
                                                ${node.changePuppetInvert ? `
                                                    <div style="display:flex; align-items:center; gap:5px; margin-left:10px;">
                                                        <input type="checkbox" ${p.invert ? 'checked' : ''} onchange="updatePuppetInvert(${nIdx}, ${pIdx}, this.checked)" title="Invert this puppet?">
                                                        <span style="font-size:0.7rem; color:var(--text-dim);">INVERT</span>
                                                    </div>
                                                ` : ''}
                                            </div>
                                        `).join('')}
                                    </div>
                                ` : ''}
                            ` : ''}
                        </div>
                    ` : ''}
                </div>
            </div>

            <details class="logic-block" style="margin-top: 20px; padding: 0; background: #050505; border: 1px solid var(--border-color); border-radius: 8px; box-shadow: inset 0 0 10px rgba(0,0,0,0.5); width: 100%; box-sizing: border-box; overflow: hidden;" ${node.statesOpen !== false ? 'open' : ''} ontoggle="window.getActiveProject().nodes[${nIdx}].statesOpen = this.open;">
                <summary class="logic-header" style="background: var(--bg-node); padding: 15px; outline: none; cursor: pointer; border-bottom: ${node.statesOpen !== false ? '1px dashed #333' : 'none'}; margin-bottom: 0;">
                    <div style="display: flex; align-items: center; justify-content: space-between; width: 100%;">
                        <div class="logic-title">Change Game State</div>
                        <button class="logic-add-btn btn-cyan" onclick="addStateChangeRow(${nIdx}); event.stopPropagation(); event.preventDefault();">+</button>
                    </div>
                </summary>
                <div style="padding: 15px;">
                    ${(node.gameStateChanges || []).map((change, cIdx) => `
                        <div class="logic-row" id="node-state-row-${nIdx}-${cIdx}">
                            <input type="text" class="logic-input" value="${escapeHtml(change.variable || '')}" oninput="updateStateChange(${nIdx}, ${cIdx}, 'variable', this.value); updateNodeGlows();" placeholder="Variable...">
                            <select class="logic-select" onchange="updateStateChange(${nIdx}, ${cIdx}, 'operator', this.value); updateNodeGlows();">
                                <option value="==" ${change.operator === '==' ? 'selected' : ''}>==</option>
                                <option value="=" ${change.operator === '=' ? 'selected' : ''}>=</option>
                                <option value="+=" ${change.operator === '+=' ? 'selected' : ''}>+=</option>
                                <option value="-=" ${change.operator === '-=' ? 'selected' : ''}>-=</option>
                            </select>
                            <input type="text" class="logic-input" value="${escapeHtml(change.value || '')}" oninput="updateStateChange(${nIdx}, ${cIdx}, 'value', this.value); updateNodeGlows();" placeholder="Value...">
                            <span class="logic-delete" onclick="removeStateChangeRow(${nIdx}, ${cIdx})">×</span>
                        </div>
                    `).join('')}
                </div>
            </details>

            </div>
        `;
    });

    container.innerHTML = contentHTML;
    if (typeof renderProjectTags === 'function') renderProjectTags();
    if (typeof updateProjectKindSwitch === 'function') updateProjectKindSwitch();
    if (typeof updatePushToServerButton === 'function') updatePushToServerButton();
}

function renderResponseSection(nIdx, project) {
    const node = project.nodes[nIdx];
    const currentResponses = (node.responses || []).length;
    const remaining = Math.max(0, 4 - currentResponses);
    const isMaxedOut = remaining === 0;
    if (!node.responseDraftFormat) node.responseDraftFormat = getDefaultTextFormat();
    const responseDraftStyleStr = getTextFormatStyle(node.responseDraftFormat);

    return `
        <div style="background: transparent;">
            <div>
                ${(node.responses || []).map((r, rIdx) => {
                    if (r.isCollapsed === undefined) r.isCollapsed = false;
                    if (!r.conditions) r.conditions = [];
                    if (!r.gameStateChanges) r.gameStateChanges = [];
                    if (typeof ensureResponseAdvancedDefaults === 'function') ensureResponseAdvancedDefaults(r);
                    if (r.conditionsOpen === undefined) r.conditionsOpen = true;
                    if (r.statesOpen === undefined) r.statesOpen = true;
                    if (r.advancedOpen === undefined) r.advancedOpen = false;
                    if (!r.textFormat) r.textFormat = getDefaultTextFormat();
                    
                    const charData = window.cast.find(c => c.name === r.speaker) || { color: '#ff007b' };
                    const isLinked = r.nextStatementId && project.nodes.some(n => n.id === r.nextStatementId);
                    const isEditing = window.editingResponseRef && window.editingResponseRef.nIdx === nIdx && window.editingResponseRef.rIdx === rIdx;
                    
                    const validRConds = (r.conditions || []).filter(c => (c.variable && c.variable.trim() !== '') || (c.value && c.value.trim() !== ''));
                    const validRStates = (r.gameStateChanges || []).filter(c => (c.variable && c.variable.trim() !== '') || (c.value && c.value.trim() !== ''));
                    
                    let hasUnmatchedCondition = false;
                    if (validRConds.length > 0) {
                        hasUnmatchedCondition = validRConds.some(cond => {
                            return !project.nodes.some(n => 
                                (n.gameStateChanges || []).some(gsc => gsc.variable === cond.variable && gsc.value === cond.value) || 
                                (n.responses || []).some(res => (res.gameStateChanges || []).some(gsc => gsc.variable === cond.variable && gsc.value === cond.value))
                            );
                        });
                    }

                    let hasUnmatchedState = false;
                    if (validRStates.length > 0) {
                        hasUnmatchedState = validRStates.some(change => {
                            return !project.nodes.some(n => 
                                (n.conditions || []).some(cond => cond.variable === change.variable && cond.value === change.value) || 
                                (n.responses || []).some(res => (res.conditions || []).some(cond => cond.variable === change.variable && cond.value === change.value))
                            );
                        });
                    }

                    const needsRespRedGlow = hasUnmatchedCondition && !r.externalCall;
                    const needsRespBlueGlow = hasUnmatchedState && !r.makeExternalCall;

                    let responseStyle = `position: relative; margin-bottom: 10px; padding: 15px; background: #151515; border: 1px solid #333; border-left: 4px solid ${charData.color}; transition: 0.3s;`;
                    if (needsRespRedGlow && needsRespBlueGlow) {
                        responseStyle += " border-color: var(--accent-purple); box-shadow: 0 0 15px rgba(176, 38, 255, 0.4);";
                    } else if (needsRespRedGlow) {
                        responseStyle += " border-color: var(--accent-pink); box-shadow: 0 0 15px rgba(255, 0, 123, 0.4);";
                    } else if (needsRespBlueGlow) {
                        responseStyle += " border-color: var(--accent-teal); box-shadow: 0 0 15px rgba(0, 242, 255, 0.4);";
                    }
                    
                    const responseText = typeof getLocalizedText === 'function' ? getLocalizedText(r, window.currentLanguage) : ((r.translations && Object.prototype.hasOwnProperty.call(r.translations, window.currentLanguage)) ? r.translations[window.currentLanguage] : '');
                    const responseTextStyleStr = getTextFormatStyle(r.textFormat);
                    
                    if (r.isCollapsed) {
                        return `
                        <div id="response-item-${nIdx}-${rIdx}" class="collapsed-response-entry" style="${responseStyle} display: flex; flex-direction: column;">
                            <div style="display: flex; align-items: center; justify-content: space-between; width: 100%;">
                                <div style="display: flex; align-items: center; gap: 10px; flex: 1; overflow: hidden;">
                                    <button onclick="window.toggleResponseCollapse(${nIdx}, ${rIdx}, event)" style="background: #ff007b; color: #fff; border: none; border-radius: 3px; width: 20px; height: 20px; font-weight: bold; cursor: pointer; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">+</button>
                                    <div class="collapsed-response-text-row">
                                        <strong style="color:${charData.color}; font-size: 0.85rem; flex-shrink: 0;">${escapeHtml(r.speaker)}:</strong>
                                        <span class="collapsed-response-preview" style="${responseTextStyleStr}">"${escapeHtml(responseText)}"</span>
                                        <button class="collapsed-response-edit-btn" type="button" onclick="window.expandCollapsedResponseForEditing(${nIdx}, ${rIdx}, event)" title="Edit Response">${getGearIcon()}</button>
                                    </div>
                                </div>
                                <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 4px; flex-shrink: 0;">
                                    <div style="display: flex; align-items: center; gap: 5px;">
                                        <div style="font-size: 0.65rem; color: #666; font-style: italic; font-family: monospace;">${r.id}</div>
                                        <button onclick="copyToClipboard('${r.id}', this); event.stopPropagation();" style="background: transparent; border: 1px solid #444; color: #888; border-radius: 3px; cursor: pointer; padding: 2px 4px; display:flex; align-items:center;">${getCopyIcon()}</button>
                                    </div>
                                    ${r.voiceLine ? `<div style="font-size: 0.6rem; color: #ff007b; font-weight: bold; text-transform: uppercase;">VOICE LINE</div>` : ''}
                                </div>
                            </div>
                        </div>
                        `;
                    }
                    
                    return `
                    <div id="response-item-${nIdx}-${rIdx}" style="${responseStyle}">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
                            <button onclick="window.toggleResponseCollapse(${nIdx}, ${rIdx}, event)" style="background: #ff007b; color: #fff; border: none; border-radius: 3px; width: 20px; height: 20px; font-weight: bold; cursor: pointer; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">-</button>
                            
                            <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 6px; width: 100%;">
                                <div style="display: flex; align-items: center; gap: 5px;">
                                    <div style="font-size: 0.65rem; color: #666; font-style: italic; font-family: monospace; user-select: text;" title="Response ID">${r.id}</div>
                                    <button onclick="copyToClipboard('${r.id}', this); event.stopPropagation();" style="background: transparent; border: 1px solid #444; color: #888; border-radius: 3px; cursor: pointer; padding: 2px 4px; display:flex; align-items:center;">${getCopyIcon()}</button>
                                </div>
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <label style="font-size: 0.6rem; color: #ffffff; font-weight: 800; text-transform: uppercase; cursor: pointer; display: flex; align-items: center; gap: 4px;">
                                        Called Externally
                                        <input type="checkbox" ${r.externalCall ? 'checked' : ''} onchange="window.getActiveProject().nodes[${nIdx}].responses[${rIdx}].externalCall = this.checked; markNodeEdited(${nIdx}); updateNodeGlows();">
                                    </label>
                                    <label style="font-size: 0.6rem; color: #ffffff; font-weight: 800; text-transform: uppercase; cursor: pointer; display: flex; align-items: center; gap: 4px;">
                                        Make External Call
                                        <input type="checkbox" ${r.makeExternalCall ? 'checked' : ''} onchange="window.getActiveProject().nodes[${nIdx}].responses[${rIdx}].makeExternalCall = this.checked; markNodeEdited(${nIdx}); updateNodeGlows();">
                                    </label>
                                </div>
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <label style="font-size: 0.6rem; color: var(--accent-pink); font-weight: 800; text-transform: uppercase; cursor: pointer; display: flex; align-items: center; gap: 4px;">
                                        Voice Line
                                        <input type="checkbox" ${r.voiceLine ? 'checked' : ''} onchange="window.getActiveProject().nodes[${nIdx}].responses[${rIdx}].voiceLine = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                                    </label>
                                    <label style="font-size: 0.6rem; color: var(--text-dim); font-weight: 800; text-transform: uppercase; cursor: pointer; display: flex; align-items: center; gap: 4px;">
                                        Auto Increment
                                        <input type="checkbox" ${r.autoIncrement ? 'checked' : ''} onchange="toggleResponseAutoIncrement(${nIdx}, ${rIdx}, this.checked)">
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="response-logic-section response-logic-conditions">
                            <div class="response-logic-header" onclick="window.toggleResponseLogicSection(${nIdx}, ${rIdx}, 'conditions', event)">
                                <div class="response-logic-title"><span class="response-logic-arrow">${r.conditionsOpen !== false ? '▾' : '▸'}</span> Conditions</div>
                                <button class="response-logic-add-btn" type="button" title="Add Condition" onclick="addResponseConditionRow(${nIdx}, ${rIdx}); event.stopPropagation();">+</button>
                            </div>
                            ${r.conditionsOpen !== false ? `
                                <div class="response-logic-body">
                                    ${r.conditions.map((cond, cIdx) => `
                                        <div class="response-logic-row" id="response-condition-row-${nIdx}-${rIdx}-${cIdx}" onclick="event.stopPropagation()">
                                            <input type="text" placeholder="Variable..." value="${escapeHtml(cond.variable)}" oninput="updateResponseConditionRow(${nIdx}, ${rIdx}, ${cIdx}, 'variable', this.value); updateNodeGlows();">
                                            <select onchange="updateResponseConditionRow(${nIdx}, ${rIdx}, ${cIdx}, 'operator', this.value); updateNodeGlows();">
                                                <option value="==" ${cond.operator === '==' ? 'selected' : ''}>==</option>
                                                <option value="!=" ${cond.operator === '!=' ? 'selected' : ''}>!=</option>
                                                <option value=">" ${cond.operator === '>' ? 'selected' : ''}>&gt;</option>
                                                <option value="<" ${cond.operator === '<' ? 'selected' : ''}>&lt;</option>
                                                <option value=">=" ${cond.operator === '>=' ? 'selected' : ''}>&gt;=</option>
                                                <option value="<=" ${cond.operator === '<=' ? 'selected' : ''}>&lt;=</option>
                                            </select>
                                            <input type="text" placeholder="Value..." value="${escapeHtml(cond.value)}" oninput="updateResponseConditionRow(${nIdx}, ${rIdx}, ${cIdx}, 'value', this.value); updateNodeGlows();">
                                            <span onclick="removeResponseConditionRow(${nIdx}, ${rIdx}, ${cIdx}); event.stopPropagation();" class="response-logic-remove">×</span>
                                        </div>
                                    `).join('')}
                                </div>
                            ` : ''}
                        </div>

                        <div style="display: flex; flex-direction: column; width: 100%;">
                            <div style="display:flex; justify-content:space-between; align-items:flex-end; width:100%; border-top: 1px dashed #333; padding-top: 15px;">
                                ${isEditing ? `
                                    <div style="display:flex; flex:1; flex-direction:column; gap: 0; align-items:stretch; min-width:0;">
                                        <div style="display:flex; align-items:center; gap:8px; margin-bottom:8px;">
                                            <select id="edit-speaker-${nIdx}-${rIdx}" class="custom-scrollbar" style="padding: 4px; background: #111; color: #fff; border: 1px solid var(--accent-teal); font-size: 0.8rem; max-width: 140px;">
                                                ${project.participants.map(p => `<option value="${escapeHtml(p)}" ${p === r.speaker ? 'selected' : ''}>${escapeHtml(p)}</option>`).join('')}
                                            </select>
                                            <button class="btn btn-teal" onclick="saveEditedResponse(${nIdx}, ${rIdx})" style="padding:4px 8px;" title="Save Change">✓</button>
                                        </div>
                                        ${renderFormatToolbar(r.textFormat, `applyResponseTextFormat(${nIdx}, ${rIdx}, `, 'response-format-toolbar')}
                                        <textarea class="edit-response-input response-edit-textarea custom-scrollbar" id="edit-input-${nIdx}-${rIdx}" style="${responseTextStyleStr}">${escapeHtml(responseText)}</textarea>
                                    </div>
                                ` : `
                                    <span style="display:flex; align-items:center; flex-wrap:wrap; gap:8px; width:100%; ${isLinked ? 'cursor:pointer;' : ''}" 
                                          ondblclick="startEditingResponse(${nIdx}, ${rIdx})"
                                          ${isLinked ? `onclick="scrollToNode('${r.nextStatementId}'); event.stopPropagation();" title="Jump to Linked Statement"` : ''}>
                                        <strong style="color:${charData.color}; cursor:pointer;" onclick="startEditingResponse(${nIdx}, ${rIdx}); event.stopPropagation();">${escapeHtml(r.speaker)}:</strong> 
                                        <span style="cursor:pointer; flex: 1; ${responseTextStyleStr} ${isLinked ? 'text-decoration: underline; text-decoration-color: var(--text-dim); text-underline-offset: 3px; color: var(--accent-teal);' : ''}" onclick="startEditingResponse(${nIdx}, ${rIdx}); event.stopPropagation();">${escapeHtml(responseText)}</span>
                                    </span>
                                `}

                                <div style="display:flex; justify-content:flex-end; align-items:center; gap:6px; flex-shrink: 0; padding-left: 15px; border-left: 1px dashed #333; margin-left: 10px;">
                                    ${!isEditing ? `
                                        <button class="btn btn-outline" style="padding: 4px 8px; font-size: 0.6rem; color: var(--accent-teal); border-color: var(--accent-teal);" onclick="startEditingResponse(${nIdx}, ${rIdx}); event.stopPropagation();" title="Edit Response">Edit</button>
                                        
                                        ${!isLinked ? `
                                            <select class="custom-scrollbar" onchange="linkExistingStatement(${nIdx}, ${rIdx}, this.value); event.stopPropagation();" style="padding: 4px; background: #000; color: var(--text-dim); border: 1px solid var(--border-color); font-size: 0.6rem; max-width: 140px; outline: none; cursor: pointer;">
                                                <option value="">Link to existing...</option>
                                                ${project.nodes.map((n, i) => `<option value="${n.id}">Statement #${i + 1} (${escapeHtml(n.speaker || '?')})</option>`).join('')}
                                            </select>
                                        ` : `
                                            <button class="btn btn-outline" style="padding: 4px 8px; font-size: 0.6rem; color: var(--accent-pink); border-color: var(--accent-pink);" onclick="unlinkResponse(${nIdx}, ${rIdx}); event.stopPropagation();">
                                                Unlink
                                            </button>
                                        `}

                                        <button class="btn btn-outline" 
                                            ${isLinked ? 'disabled' : ''}
                                            style="padding: 4px 8px; font-size: 0.6rem;" 
                                            onclick="createReplyStatement(${nIdx}, ${rIdx}); event.stopPropagation();">
                                            ${isLinked ? 'Statement Linked' : 'Reply Statement'}
                                        </button>
                                        ${isLinked ? `<button class="btn btn-teal" style="padding: 4px 8px; font-size: 0.6rem; font-weight:800; border-radius:2px;" onclick="scrollToNode('${r.nextStatementId}'); event.stopPropagation();">JUMP ↳</button>` : ''}
                                    ` : ''}
                                    
                                    ${currentResponses > 1 ? `
                                    <div style="display: flex; align-items: center; gap: 4px; border-left: 1px solid #333; padding-left: 6px;">
                                        ${rIdx > 0 ? `<button style="background:transparent; border:none; color:var(--text-dim); cursor:pointer; font-size: 0.8rem; padding: 2px; line-height: 1;" onclick="moveResponseUp(${nIdx}, ${rIdx}); event.stopPropagation();" onmouseover="this.style.color='var(--accent-teal)'" onmouseout="this.style.color='var(--text-dim)'">▲</button>` : `<span style="width: 16px;"></span>`}
                                        ${rIdx < currentResponses - 1 ? `<button style="background:transparent; border:none; color:var(--text-dim); cursor:pointer; font-size: 0.8rem; padding: 2px; line-height: 1;" onclick="moveResponseDown(${nIdx}, ${rIdx}); event.stopPropagation();" onmouseover="this.style.color='var(--accent-teal)'" onmouseout="this.style.color='var(--text-dim)'">▼</button>` : `<span style="width: 16px;"></span>`}
                                    </div>
                                    ` : ''}
                                    
                                    <button onclick="removeResponse(${nIdx}, ${rIdx}); event.stopPropagation();" 
                                        style="background:transparent; border:none; cursor:pointer; color:var(--accent-pink); font-weight:bold; font-size: 1.2rem; margin-left: 5px; padding: 0 4px;" title="Delete Response">×</button>
                                </div>
                            </div>
                        </div>

                        ${renderResponseAdvancedDropdown(nIdx, rIdx, r)}

                        <div class="response-logic-section response-logic-state">
                            <div class="response-logic-header" onclick="window.toggleResponseLogicSection(${nIdx}, ${rIdx}, 'states', event)">
                                <div class="response-logic-title"><span class="response-logic-arrow">${r.statesOpen !== false ? '▾' : '▸'}</span> Change Game State</div>
                                <button class="response-logic-add-btn" type="button" title="Add Change Game State" onclick="addResponseStateChangeRow(${nIdx}, ${rIdx}); event.stopPropagation();">+</button>
                            </div>
                            ${r.statesOpen !== false ? `
                                <div class="response-logic-body">
                                    ${r.gameStateChanges.map((change, cIdx) => `
                                        <div class="response-logic-row" id="response-state-row-${nIdx}-${rIdx}-${cIdx}" onclick="event.stopPropagation()">
                                            <input type="text" placeholder="Variable..." value="${escapeHtml(change.variable)}" oninput="updateResponseStateChangeRow(${nIdx}, ${rIdx}, ${cIdx}, 'variable', this.value); updateNodeGlows();">
                                            <select onchange="updateResponseStateChangeRow(${nIdx}, ${rIdx}, ${cIdx}, 'operator', this.value); updateNodeGlows();">
                                                <option value="=" ${change.operator === '=' ? 'selected' : ''}>=</option>
                                                <option value="+=" ${change.operator === '+=' ? 'selected' : ''}>+=</option>
                                                <option value="-=" ${change.operator === '-=' ? 'selected' : ''}>-=</option>
                                            </select>
                                            <input type="text" placeholder="Value..." value="${escapeHtml(change.value)}" oninput="updateResponseStateChangeRow(${nIdx}, ${rIdx}, ${cIdx}, 'value', this.value); updateNodeGlows();">
                                            <span onclick="removeResponseStateChangeRow(${nIdx}, ${rIdx}, ${cIdx}); event.stopPropagation();" class="response-logic-remove">×</span>
                                        </div>
                                    `).join('')}
                                </div>
                            ` : ''}
                        </div>
                    </div>
                `}).join('')}
            </div>
            <div style="display:flex; flex-direction:column; gap:0; margin-top:10px;">
                ${renderFormatToolbar(node.responseDraftFormat, `applyResponseDraftTextFormat(${nIdx}, `, 'response-format-toolbar')}
                <textarea id="resp-input-${nIdx}" class="response-draft-textarea custom-scrollbar" placeholder="${isMaxedOut ? 'Max 4 responses reached...' : 'Response Text...'}" style="${responseDraftStyleStr}" oninput="window.getActiveProject().nodes[${nIdx}].responseDraftText = this.value;" ${isMaxedOut ? 'disabled' : ''}>${escapeHtml(node.responseDraftText || '')}</textarea>
                <div style="display:flex; gap:10px; margin-top:10px; align-items:center;">
                    <select id="resp-speaker-${nIdx}" class="custom-scrollbar" style="width:30%" ${isMaxedOut ? 'disabled' : ''}>
                        ${window.getActiveProject().participants.map(p => `<option value="${escapeHtml(p)}">${escapeHtml(p)}</option>`).join('')}
                    </select>
                    <button class="btn btn-teal" onclick="applyResp(${nIdx})" ${isMaxedOut ? 'disabled' : ''}>APPLY (${remaining} LEFT)</button>
                </div>
            </div>
        </div>
    `;
}


function renderResponseAdvancedDropdown(nIdx, rIdx, response) {
    if (typeof ensureResponseAdvancedDefaults === 'function') ensureResponseAdvancedDefaults(response);
    const targetRef = `window.getActiveProject().nodes[${nIdx}].responses[${rIdx}]`;
    const touch = `markNodeEdited(${nIdx}); renderNodes();`;
    const markOnly = `markNodeEdited(${nIdx});`;
    const boolToggle = (field) => `${targetRef}.${field} = this.checked; ${touch}`;
    const boolExclusive = (field, opposite) => `${targetRef}.${field} = this.checked; if (this.checked) ${targetRef}.${opposite} = false; ${touch}`;
    const project = window.getActiveProject();
    const responseSelectedPuppetNames = new Set((response.puppets || []).map(p => p.name));
    const safePuppets = ((project && Array.isArray(project.participants)) ? project.participants : [])
        .filter(name => !responseSelectedPuppetNames.has(name))
        .map(name => window.cast.find(c => c.name === name) || { name, color: '#444' });

    return `
        <div class="response-logic-section response-logic-advanced">
            <div class="response-logic-header" onclick="window.toggleResponseLogicSection(${nIdx}, ${rIdx}, 'advanced', event)">
                <div class="response-logic-title"><span class="response-logic-arrow">${response.advancedOpen ? '▾' : '▸'}</span> Advanced</div>
            </div>
            ${response.advancedOpen ? `
                <div class="response-advanced-body">
                    <div class="state-row">
                        <div class="state-input-group">
                            <label style="color:var(--accent-gold)">Close Main Menu?</label>
                            <input type="checkbox" ${response.closeMainMenu ? 'checked' : ''} onchange="${boolToggle('closeMainMenu')}">
                        </div>
                        <div class="state-input-group">
                            <label style="color:var(--accent-pink)">Close Dialogue Menu?</label>
                            <input type="checkbox" ${response.closeDialogueMenu ? 'checked' : ''} onchange="${boolToggle('closeDialogueMenu')}">
                        </div>
                        <div class="state-input-group">
                            <label style="color:var(--accent-teal)">Open Prompt Panel?</label>
                            <input type="checkbox" ${response.openPromptPanel ? 'checked' : ''} onchange="${boolExclusive('openPromptPanel', 'closePromptPanel')}">
                        </div>
                        <div class="state-input-group">
                            <label style="color:var(--accent-teal)">Close Prompt Panel?</label>
                            <input type="checkbox" ${response.closePromptPanel ? 'checked' : ''} onchange="${boolExclusive('closePromptPanel', 'openPromptPanel')}">
                        </div>
                    </div>
                    <hr class="cyber-hr" style="margin: 5px 0;">

                    <div class="state-row">
                        <div class="state-input-group">
                            <label style="color:var(--accent-purple)">Control Sequence Image?</label>
                            <input type="checkbox" ${response.controlSequence ? 'checked' : ''} onchange="${boolToggle('controlSequence')}">
                        </div>
                    </div>
                    ${response.controlSequence ? `
                        <div class="state-row response-advanced-nested">
                            <div class="state-input-group" style="flex:1;">
                                <label>Sequence</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="${targetRef}.sequenceName = this.value; ${targetRef}.sequenceImage = ''; ${touch}">
                                    <option value="">-- Select Sequence --</option>
                                    ${window.globalImageSequences.map(s => `<option value="${escapeHtml(s.name)}" ${response.sequenceName === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Image Name</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="${targetRef}.sequenceImage = this.value; ${touch}">
                                    <option value="">-- Select Image --</option>
                                    ${(window.globalImageSequences.find(s => s.name === response.sequenceName)?.images || []).map(img => `<option value="${escapeHtml(img)}" ${response.sequenceImage === img ? 'selected' : ''}>${escapeHtml(img)}</option>`).join('')}
                                </select>
                            </div>
                        </div>
                    ` : ''}

                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Change Menu Option?</label>
                            <input type="checkbox" ${response.changeMenuOption ? 'checked' : ''} onchange="${boolToggle('changeMenuOption')}">
                        </div>
                        ${response.changeMenuOption ? `<button class="btn btn-outline response-advanced-add-small" onclick="${targetRef}.menuOptionChanges.push({ menu: '', value: '' }); ${touch}">+ Add Menu Change</button>` : ''}
                    </div>
                    ${response.changeMenuOption ? (response.menuOptionChanges || []).map((change, cIdx) => `
                        <div class="state-row">
                            <div class="state-input-group" style="flex:1;">
                                <label>Menu Option</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="${targetRef}.menuOptionChanges[${cIdx}].menu = this.value; ${markOnly}">
                                    <option value="">-- Select Menu --</option>
                                    ${window.globalMenuOptions.map(s => `<option value="${escapeHtml(s.name)}" ${change.menu === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Value</label>
                                <input type="text" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" value="${escapeHtml(change.value || '')}" onchange="${targetRef}.menuOptionChanges[${cIdx}].value = this.value; ${markOnly}">
                            </div>
                            ${(response.menuOptionChanges.length > 1) ? `<span onclick="${targetRef}.menuOptionChanges.splice(${cIdx}, 1); ${touch}" style="cursor:pointer; color:var(--accent-pink); font-weight:bold; padding: 0 5px;">×</span>` : ''}
                        </div>
                    `).join('') : ''}

                    <hr class="cyber-hr" style="margin: 5px 0;">
                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Background Use Path?</label>
                            <input type="checkbox" ${response.usePath ? 'checked' : ''} onchange="${boolToggle('usePath')}">
                        </div>
                        ${response.usePath ? `<input type="text" style="flex:1; padding: 6px 12px; font-size: 0.8rem;" placeholder="Path..." value="${escapeHtml(response.resourcePath || 'Assets/Resources/Slides/')}" onchange="${targetRef}.resourcePath = this.value; ${markOnly}">` : ''}
                    </div>

                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Change Setting?</label>
                            <input type="checkbox" ${response.changeSetting ? 'checked' : ''} onchange="${boolToggle('changeSetting')}">
                        </div>
                        ${response.changeSetting ? `<button class="btn btn-outline response-advanced-add-small" onclick="${targetRef}.settingChanges.push({ setting: '', value: '' }); ${touch}">+ Add Setting Change</button>` : ''}
                    </div>
                    ${response.changeSetting ? (response.settingChanges || []).map((change, cIdx) => `
                        <div class="state-row">
                            <div class="state-input-group" style="flex:1;">
                                <label>Setting</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="${targetRef}.settingChanges[${cIdx}].setting = this.value; ${markOnly}">
                                    <option value="">-- Select Setting --</option>
                                    ${window.globalSettings.map(s => `<option value="${escapeHtml(s.name)}" ${change.setting === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Value</label>
                                <input type="text" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" value="${escapeHtml(change.value || '')}" onchange="${targetRef}.settingChanges[${cIdx}].value = this.value; ${markOnly}">
                            </div>
                            ${(response.settingChanges.length > 1) ? `<span onclick="${targetRef}.settingChanges.splice(${cIdx}, 1); ${touch}" style="cursor:pointer; color:var(--accent-pink); font-weight:bold; padding: 0 5px;">×</span>` : ''}
                        </div>
                    `).join('') : ''}

                    <hr class="cyber-hr" style="margin: 5px 0;">
                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Change Time of Day?</label>
                            <input type="checkbox" ${response.changeTimeOfDay ? 'checked' : ''} onchange="${boolToggle('changeTimeOfDay')}">
                        </div>
                        ${response.changeTimeOfDay ? `<button class="btn btn-outline response-advanced-add-small" onclick="${targetRef}.timeOfDayChanges.push({ time: '', value: '' }); ${touch}">+ Add Time Change</button>` : ''}
                    </div>
                    ${response.changeTimeOfDay ? (response.timeOfDayChanges || []).map((change, cIdx) => `
                        <div class="state-row">
                            <div class="state-input-group" style="flex:1;">
                                <label>Time</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="${targetRef}.timeOfDayChanges[${cIdx}].time = this.value; ${markOnly}">
                                    <option value="">-- Select Time --</option>
                                    ${window.globalTimesOfDay.map(s => `<option value="${escapeHtml(s.name)}" ${change.time === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Value</label>
                                <input type="text" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" value="${escapeHtml(change.value || '')}" onchange="${targetRef}.timeOfDayChanges[${cIdx}].value = this.value; ${markOnly}">
                            </div>
                            ${(response.timeOfDayChanges.length > 1) ? `<span onclick="${targetRef}.timeOfDayChanges.splice(${cIdx}, 1); ${touch}" style="cursor:pointer; color:var(--accent-pink); font-weight:bold; padding: 0 5px;">×</span>` : ''}
                        </div>
                    `).join('') : ''}

                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Change Day of Week?</label>
                            <input type="checkbox" ${response.changeDayOfWeek ? 'checked' : ''} onchange="${boolToggle('changeDayOfWeek')}">
                        </div>
                        ${response.changeDayOfWeek ? `<button class="btn btn-outline response-advanced-add-small" onclick="${targetRef}.dayOfWeekChanges.push({ day: '', value: '' }); ${touch}">+ Add Day Change</button>` : ''}
                    </div>
                    ${response.changeDayOfWeek ? (response.dayOfWeekChanges || []).map((change, cIdx) => `
                        <div class="state-row">
                            <div class="state-input-group" style="flex:1;">
                                <label>Day</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="${targetRef}.dayOfWeekChanges[${cIdx}].day = this.value; ${markOnly}">
                                    <option value="">-- Select Day --</option>
                                    ${window.globalDaysOfWeek.map(s => `<option value="${escapeHtml(s.name)}" ${change.day === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Value</label>
                                <input type="text" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" value="${escapeHtml(change.value || '')}" onchange="${targetRef}.dayOfWeekChanges[${cIdx}].value = this.value; ${markOnly}">
                            </div>
                            ${(response.dayOfWeekChanges.length > 1) ? `<span onclick="${targetRef}.dayOfWeekChanges.splice(${cIdx}, 1); ${touch}" style="cursor:pointer; color:var(--accent-pink); font-weight:bold; padding: 0 5px;">×</span>` : ''}
                        </div>
                    `).join('') : ''}

                    <hr class="cyber-hr" style="margin: 5px 0;">
                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Control Puppets?</label>
                            <input type="checkbox" ${response.controlPuppets ? 'checked' : ''} onchange="${boolToggle('controlPuppets')}">
                        </div>
                    </div>
                    ${response.controlPuppets ? `
                        <div class="response-advanced-puppet-block">
                            <select class="custom-scrollbar" onchange="if(this.value){${targetRef}.puppets.push({ name: this.value, enabled: true, position: '', path: 'Assets/Resources/Puppets/', state: '', mood: '', invert: false }); ${touch}}" style="width: 100%; font-size: 0.8rem; padding: 8px;">
                                <option value="">+ Add Character Puppet to Response</option>
                                ${safePuppets.map(c => `<option value="${escapeHtml(c.name)}">${escapeHtml(c.name)}</option>`).join('')}
                            </select>
                            <div style="display:flex; flex-wrap:wrap; gap:10px; margin-top:15px;">
                                ${(response.puppets || []).map((p, pIdx) => `
                                    <div class="puppet-tag ${p.enabled ? '' : 'disabled'}">
                                        <input type="checkbox" ${p.enabled ? 'checked' : ''} onchange="${targetRef}.puppets[${pIdx}].enabled = this.checked; ${touch}" title="Enable/Disable Puppet">
                                        <span>${escapeHtml(p.name)}</span>
                                        ${p.enabled ? `<label style="font-size:0.6rem; color:var(--text-dim); margin-left:5px;">POS:</label><input type="text" maxlength="2" class="puppet-pos-input" value="${escapeHtml(p.position || '')}" onchange="${targetRef}.puppets[${pIdx}].position = this.value; ${markOnly}" placeholder="--">` : ''}
                                        <span onclick="${targetRef}.puppets.splice(${pIdx}, 1); ${touch}" style="cursor:pointer; margin-left:5px; color:var(--accent-pink); font-weight:bold;">×</span>
                                    </div>
                                `).join('')}
                            </div>
                            ${(response.puppets || []).length > 0 ? `
                                <div class="state-row" style="margin-top: 15px; flex-wrap: wrap;">
                                    <div class="state-input-group"><label>Change State?</label><input type="checkbox" ${response.changePuppetState ? 'checked' : ''} onchange="${boolToggle('changePuppetState')}"></div>
                                    ${response.changePuppetState ? `
                                        <div class="state-input-group" style="margin-left: 10px; border-left: 1px dashed var(--border-color); padding-left: 10px;"><label style="color:var(--accent-teal)">Puppet Use Tag?</label><input type="checkbox" ${response.puppetUseTag ? 'checked' : ''} onchange="${boolToggle('puppetUseTag')}"></div>
                                        <div class="state-input-group"><label style="color:var(--accent-orange)">Puppet Use Path?</label><input type="checkbox" ${response.puppetUsePath ? 'checked' : ''} onchange="${boolToggle('puppetUsePath')}"></div>
                                    ` : ''}
                                    <div class="state-input-group" style="${response.changePuppetState ? 'margin-left: 10px; border-left: 1px dashed var(--border-color); padding-left: 10px;' : ''}"><label>Change Mood?</label><input type="checkbox" ${response.changePuppetMood ? 'checked' : ''} onchange="${boolToggle('changePuppetMood')}"></div>
                                    <div class="state-input-group"><label>Invert?</label><input type="checkbox" ${response.changePuppetInvert ? 'checked' : ''} onchange="${boolToggle('changePuppetInvert')}"></div>
                                </div>
                                ${((response.changePuppetState && (response.puppetUsePath || response.puppetUseTag)) || response.changePuppetMood || response.changePuppetInvert) ? `
                                    <div style="display:flex; flex-direction:column; gap:10px; margin-top:10px;">
                                        ${(response.puppets || []).map((p, pIdx) => `
                                            <div class="puppet-path-row">
                                                <span style="font-size:0.75rem; color:var(--accent-teal); min-width:80px; font-weight:bold;">${escapeHtml(p.name)}</span>
                                                ${(response.changePuppetState && response.puppetUsePath) ? `<input type="text" style="flex:1; padding:6px 10px; font-size:0.8rem; min-width: 150px;" value="${escapeHtml(p.path || 'Assets/Resources/Puppets/')}" onchange="${targetRef}.puppets[${pIdx}].path = this.value; ${markOnly}">` : ''}
                                                ${(response.changePuppetState && response.puppetUseTag) ? `<select class="custom-scrollbar" style="flex:1; padding:6px; font-size:0.8rem; min-width: 100px;" onchange="${targetRef}.puppets[${pIdx}].state = this.value; ${markOnly}"><option value="">-- Select State --</option>${window.globalStates.map(s => `<option value="${escapeHtml(s.name)}" ${p.state === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}</select>` : ''}
                                                ${response.changePuppetMood ? `<select class="custom-scrollbar" style="flex:1; padding:6px; font-size:0.8rem; min-width: 100px;" onchange="${targetRef}.puppets[${pIdx}].mood = this.value; ${markOnly}"><option value="">-- Select Mood --</option>${window.globalMoods.map(m => `<option value="${escapeHtml(m.name)}" ${p.mood === m.name ? 'selected' : ''}>${escapeHtml(m.name)}</option>`).join('')}</select>` : ''}
                                                ${response.changePuppetInvert ? `<div style="display:flex; align-items:center; gap:5px; margin-left:10px;"><input type="checkbox" ${p.invert ? 'checked' : ''} onchange="${targetRef}.puppets[${pIdx}].invert = this.checked; ${markOnly}" title="Invert this puppet?"><span style="font-size:0.7rem; color:var(--text-dim);">INVERT</span></div>` : ''}
                                            </div>
                                        `).join('')}
                                    </div>
                                ` : ''}
                            ` : ''}
                        </div>
                    ` : ''}
                </div>
            ` : ''}
        </div>
    `;
}


function updateProjectTitleEditorLabel() {
    const label = document.getElementById('project-title-editor-label') || document.querySelector('.project-title-label');
    const input = document.getElementById('edit-conv-name');
    const hasActiveProject = window.activeIndex !== null && window.activeIndex !== undefined && !!window.getActiveProject();
    let typeLabel = 'Project';
    if (hasActiveProject) typeLabel = window.activeType === 'sequence' ? 'Sequence' : 'Conversation';
    if (label) label.textContent = `${typeLabel} Title Editor`;
    if (input) input.placeholder = `${typeLabel} Title...`;
}
window.updateProjectTitleEditorLabel = updateProjectTitleEditorLabel;

function updateProjectKindSwitch() {
    const conversationButton = document.getElementById('project-kind-conversation');
    const sequenceButton = document.getElementById('project-kind-sequence');
    if (!conversationButton || !sequenceButton) {
        updateProjectTitleEditorLabel();
        return;
    }

    const hasActiveProject = window.activeIndex !== null && window.activeIndex !== undefined && !!window.getActiveProject();
    [conversationButton, sequenceButton].forEach(button => {
        button.disabled = !hasActiveProject;
        button.classList.remove('active');
        button.setAttribute('aria-checked', 'false');
    });

    updateProjectTitleEditorLabel();
    if (!hasActiveProject) return;

    const activeButton = window.activeType === 'sequence' ? sequenceButton : conversationButton;
    activeButton.classList.add('active');
    activeButton.setAttribute('aria-checked', 'true');
}

// --- GLOBAL COLLAPSE / EXPAND TOGGLES ---
function getAccountManagementIconSvg() {
    return `<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21a8 8 0 0 0-16 0"></path><circle cx="12" cy="7" r="4"></circle></svg>`;
}

function ensureHiddenJsonInput(id, accept, onchangeName, allowMultiple = false) {
    let input = document.getElementById(id);
    if (!input) {
        input = document.createElement('input');
        input.type = 'file';
        input.id = id;
        input.style.display = 'none';
        document.body.appendChild(input);
    }
    input.accept = accept;
    input.style.display = 'none';
    if (allowMultiple) input.multiple = true;
    else input.removeAttribute('multiple');
    input.setAttribute('onchange', `${onchangeName}(this)`);
    return input;
}


function setupManageJsonHoverDelay(manageWrap) {
    if (!manageWrap || manageWrap.dataset.hoverDelayReady === 'true') return;
    manageWrap.dataset.hoverDelayReady = 'true';
    let closeTimer = null;
    const button = () => manageWrap.querySelector('#manage-json-button, .manage-json-button');

    const openMenu = () => {
        if (closeTimer) {
            clearTimeout(closeTimer);
            closeTimer = null;
        }
        manageWrap.classList.add('manage-json-open');
        const btn = button();
        if (btn) btn.setAttribute('aria-expanded', 'true');
    };

    const closeMenuSoon = () => {
        if (closeTimer) clearTimeout(closeTimer);
        closeTimer = setTimeout(() => {
            manageWrap.classList.remove('manage-json-open');
            const btn = button();
            if (btn) btn.setAttribute('aria-expanded', 'false');
            closeTimer = null;
        }, 500);
    };

    manageWrap.addEventListener('mouseenter', openMenu);
    manageWrap.addEventListener('mouseleave', closeMenuSoon);
    manageWrap.addEventListener('focusin', openMenu);
    manageWrap.addEventListener('focusout', closeMenuSoon);
    manageWrap.addEventListener('click', (ev) => {
        const btn = button();
        if (btn && ev.target && (ev.target === btn || btn.contains(ev.target))) {
            ev.preventDefault();
            if (manageWrap.classList.contains('manage-json-open')) closeMenuSoon();
            else openMenu();
        }
    });
}

function removeLegacyJsonHeaderButtons(headerActions) {
    const legacyTextMatches = [
        'IMPORT JSON',
        'EXPORT JSON',
        'IMPORT CONVERSATION',
        'IMPORT SEQUENCE',
        'IMPORT CONVERSATIONIMPORT SEQUENCE'
    ];

    const isProtectedHeaderControl = (el) => {
        return !!(el.closest && (
            el.closest('.manage-json-wrap') ||
            el.closest('.global-toggle-wrapper') ||
            el.classList.contains('account-management-button') ||
            el.id === 'account-management-button'
        ));
    };

    const isLegacyJsonControl = (el) => {
        if (!el || isProtectedHeaderControl(el)) return false;
        if (el.tagName === 'INPUT' && el.type === 'file') return false;
        const normalizedText = (el.textContent || '').replace(/\s+/g, ' ').trim().toUpperCase();
        const compactText = normalizedText.replace(/\s+/g, '');
        const textMatch = legacyTextMatches.some(match => {
            const compactMatch = match.replace(/\s+/g, '');
            return normalizedText === match || normalizedText.includes(match) || compactText === compactMatch || compactText.includes(compactMatch);
        });
        const hasLegacyClick = typeof el.getAttribute === 'function' && /importProjectJSON|importConversationJSON|importSequenceJSON|exportProjectJSON|import-json-trigger|import-conv-trigger|import-seq-trigger/i.test(el.getAttribute('onclick') || '');
        return textMatch || hasLegacyClick;
    };

    Array.from(headerActions.children).forEach(child => {
        if (isLegacyJsonControl(child)) child.remove();
    });

    const header = document.querySelector('.header');
    if (header) {
        header.querySelectorAll('button, a, div').forEach(el => {
            if (el === headerActions || headerActions.contains(el)) return;
            if (el.closest && el.closest('.nav-grid')) return;
            if (isLegacyJsonControl(el)) el.remove();
        });
    }
}

function ensureManageJsonAndAccountHeaderControls() {
    const headerActions = document.querySelector('.header-actions') || document.querySelector('.header .actions');
    if (!headerActions) return null;

    ensureHiddenJsonInput('import-conv-trigger', '.json', 'importConversationJSON');
    ensureHiddenJsonInput('import-seq-trigger', '.json', 'importSequenceJSON');
    ensureHiddenJsonInput('import-json-trigger', '.json', 'importProjectJSON');
    ensureHiddenJsonInput('import-csv-trigger', '.csv,text/csv', 'importVoiceLinesCSV');
    ensureHiddenJsonInput('direct-image-import-trigger', '', 'handleDirectImageImport', true);

    removeLegacyJsonHeaderButtons(headerActions);

    let manageWrap = document.getElementById('manage-json-wrap') || document.querySelector('.manage-json-wrap');
    if (!manageWrap) {
        manageWrap = document.createElement('div');
        manageWrap.className = 'manage-json-wrap';
        manageWrap.id = 'manage-json-wrap';
    }
    manageWrap.innerHTML = `
        <button id="manage-json-button" class="manage-json-button" type="button" aria-haspopup="true" aria-expanded="false">
            <span>Manage</span>
            <span>Json</span>
        </button>
        <div class="manage-json-menu" id="manage-json-menu">
            <button class="manage-json-menu-export" type="button" onclick="exportProjectJSON()">Export JSON</button>
            <button type="button" onclick="document.getElementById('import-json-trigger').click()">Import Project</button>
            <button type="button" onclick="document.getElementById('import-conv-trigger').click()">Import Conversation</button>
            <button type="button" onclick="document.getElementById('import-seq-trigger').click()">Import Sequence</button>
            <div class="manage-json-section-title">CSV SETTINGS</div>
            <button class="manage-json-menu-csv" type="button" onclick="exportVoiceLinesCSV()">Export Voice Lines</button>
            <button class="manage-json-menu-csv" type="button" onclick="document.getElementById('import-csv-trigger').click()">Import Voice Lines</button>
        </div>
    `;

    let accountButton = document.getElementById('account-management-button') || document.querySelector('.account-management-button');
    if (!accountButton) {
        accountButton = document.createElement('button');
        accountButton.id = 'account-management-button';
        accountButton.className = 'account-management-button';
        accountButton.type = 'button';
    }
    accountButton.title = 'Manage Account';
    accountButton.setAttribute('aria-label', 'Manage Account');
    accountButton.onclick = function(ev) {
        ev.preventDefault();
        ev.stopPropagation();
        if (typeof window.openAccountModal === 'function') window.openAccountModal();
        else {
            const modal = document.getElementById('account-modal');
            if (modal) modal.style.display = 'flex';
            else console.error('Account modal is missing and openAccountModal is not loaded.');
        }
    };
    accountButton.innerHTML = getAccountManagementIconSvg();

    setupManageJsonHoverDelay(manageWrap);

    headerActions.appendChild(manageWrap);
    headerActions.appendChild(accountButton);

    const existingGlobalToggle = document.querySelector('.global-toggle-wrapper');
    if (existingGlobalToggle) headerActions.appendChild(existingGlobalToggle);

    return headerActions;
}

function injectGlobalToggleButtons() {
    const headerActions = ensureManageJsonAndAccountHeaderControls();
    if (headerActions && !document.querySelector('.global-toggle-wrapper')) {
        const btnContainer = document.createElement('div');
        btnContainer.className = 'global-toggle-wrapper';
        btnContainer.style.display = 'flex';
        btnContainer.style.flexDirection = 'column';
        btnContainer.style.gap = '4px';
        btnContainer.style.marginLeft = '0';
        
        const style = "width: 20px; height: 20px; border-radius: 50%; border: 1px solid var(--accent-teal); background: #000; color: var(--accent-teal); cursor: pointer; display: flex; align-items: center; justify-content: center; font-weight: 900; font-size: 14px; line-height: 1; padding: 0; transition: 0.2s;";
        
        btnContainer.innerHTML = `
            <button style="${style}" onmouseover="this.style.background='var(--accent-teal)'; this.style.color='#000';" onmouseout="this.style.background='#000'; this.style.color='var(--accent-teal)';" onclick="toggleGlobalAccordions(true)" title="Expand All UI Elements">+</button>
            <button style="${style}" onmouseover="this.style.background='var(--accent-teal)'; this.style.color='#000';" onmouseout="this.style.background='#000'; this.style.color='var(--accent-teal)';" onclick="toggleGlobalAccordions(false)" title="Collapse All UI Elements">-</button>
        `;
        
        headerActions.appendChild(btnContainer);
    }

    ensureManageJsonAndAccountHeaderControls();
}

function toggleGlobalAccordions(expand) {
    document.querySelectorAll('details').forEach(d => {
        if (expand) d.setAttribute('open', '');
        else d.removeAttribute('open');
    });

    if (expand) {
        window.globalImageSequences.forEach(seq => window.openImageSeqs.add(seq.name));
    } else {
        window.openImageSeqs.clear();
    }

    const project = window.getActiveProject();
    if (project && project.nodes) {
        project.nodes.forEach(n => {
            n.isCollapsed = !expand; 
            n.advancedOpen = expand;
            n.conditionsOpen = expand;
            n.statesOpen = expand;
            n.responsesOpen = expand;
            (n.responses || []).forEach(r => {
                r.isCollapsed = !expand;
                r.conditionsOpen = expand;
                r.statesOpen = expand;
                r.advancedOpen = expand;
            });
        });
        renderNodes();
    }
    
    if (typeof renderImageSequences === 'function') renderImageSequences();
}

// Inject on boot
document.addEventListener('DOMContentLoaded', injectGlobalToggleButtons);
if (document.readyState === 'interactive' || document.readyState === 'complete') injectGlobalToggleButtons();