// ============================================================================
// DD_DATA.JS - Data Manipulation, Logic Models, and Project State
// ============================================================================

// --- LANGUAGE STATE ---
let availableLanguages = ['ENG', 'SPN', 'RUS', 'IRI', 'SCO', 'FRE', 'POL', 'GER', 'ARA', 'JAP'];
let currentLanguage = 'ENG';
let isAddingLanguage = false;

// --- HELPERS ---
function getEmptyNode(speaker = '') {
    return {
        id: crypto.randomUUID(), 
        isCollapsed: false,
        voiceLine: true,
        nodeColor: getRandomColor(),
        advancedOpen: false,
        conditionsOpen: true,
        statesOpen: true,
        responsesOpen: true,
        conditions: [], speaker: speaker, 
        resourcePath: 'Assets/Resources/Slides/', usePath: false, closeMainMenu: false, closeDialogueMenu: false,
        openPromptPanel: false, closePromptPanel: false, changeTimeOfDay: false, timeOfDayChanges: [{ time: '', value: '' }],
        changeDayOfWeek: false, dayOfWeekChanges: [{ day: '', value: '' }], changeMenuOption: false, menuOptionChanges: [{ menu: '', value: '' }],
        gameStateChanges: [], changeSetting: false, settingChanges: [{ setting: '', value: '' }], controlSequence: false,
        sequenceName: '', sequenceImage: '', controlPuppets: false, puppetUsePath: false, puppetUseTag: false, 
        changePuppetState: false, changePuppetMood: false, changePuppetInvert: false, puppets: [], canPlayerRespond: false,
        externalCall: false, makeExternalCall: false, responses: [], parentResponseId: null, parentResponsePreview: null,
        textFormat: { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' },
        translations: {} // Translation Map Support
    };
}

// --- DRAG AND DROP HANDLING ---
function handleDragStart(ev, type, idx) {
    ev.dataTransfer.setData('text/plain', JSON.stringify({ type, index: idx }));
}

function handleProjectItemDrop(ev, targetType, targetIndex) {
    ev.preventDefault();
    ev.stopPropagation(); 
    try {
        const data = JSON.parse(ev.dataTransfer.getData('text/plain'));
        const sourceType = data.type;
        const sourceIndex = data.index;

        if ((sourceType === 'conversation' || sourceType === 'sequence') && (targetType === 'conversation' || targetType === 'sequence')) {
            const sourceList = sourceType === 'conversation' ? conversations : sequences;
            const targetList = targetType === 'conversation' ? conversations : sequences;

            if (sourceType === targetType) {
                if (sourceIndex === targetIndex) return;
                const item = sourceList.splice(sourceIndex, 1)[0];
                targetList.splice(targetIndex, 0, item);
                
                if (activeType === targetType) {
                    if (activeIndex === sourceIndex) activeIndex = targetIndex;
                    else if (activeIndex > sourceIndex && activeIndex <= targetIndex) activeIndex--;
                    else if (activeIndex < sourceIndex && activeIndex >= targetIndex) activeIndex++;
                }
            } else {
                const itemToMove = sourceList[sourceIndex];
                
                if (sourceType === 'sequence' && targetType === 'conversation') {
                    if (!confirm("Warning: Moving this project from Sequences to Conversations will unlink it from its associated Image Sequence. Proceed?")) return;
                    itemToMove.nodes.forEach(n => {
                        if (n.sequenceName === itemToMove.title || n.controlSequence) {
                            n.controlSequence = false;
                            n.sequenceName = '';
                            n.sequenceImage = '';
                        }
                    });
                    renderImageSequences(); 
                }

                const item = sourceList.splice(sourceIndex, 1)[0];
                targetList.splice(targetIndex, 0, item); 

                if (sourceType === 'conversation' && targetType === 'sequence') {
                    if (!globalImageSequences.some(s => s.name === item.title)) {
                        globalImageSequences.push({ name: item.title, color: item.color || getRandomColor(), path: 'Assets/2D/Sequences/', images: [] });
                    }
                    if (item.nodes.length === 0) item.nodes.push(getEmptyNode());
                    item.nodes[0].controlSequence = true;
                    item.nodes[0].sequenceName = item.title;
                    const imgSeq = globalImageSequences.find(s => s.name === item.title);
                    if (imgSeq && imgSeq.images.length > 0) item.nodes[0].sequenceImage = imgSeq.images[0];
                    renderImageSequences();
                }

                if (activeType === sourceType && activeIndex === sourceIndex) {
                    activeType = targetType;
                    activeIndex = targetIndex;
                } else if (activeType === sourceType && activeIndex > sourceIndex) {
                    activeIndex--;
                } else if (activeType === targetType && activeIndex >= targetIndex) {
                    activeIndex++;
                }
            }
            renderConversations();
            renderSequences();
        }
    } catch(e) { console.error("Drop handle error:", e); }
}

function handleDrop(ev, targetType) {
    ev.preventDefault();
    try {
        const data = JSON.parse(ev.dataTransfer.getData('text/plain'));
        
        if ((data.type === 'conversation' || data.type === 'sequence') && (targetType === 'conversation' || targetType === 'sequence')) {
            const sourceList = data.type === 'conversation' ? conversations : sequences;
            const targetList = targetType === 'conversation' ? conversations : sequences;
            
            if (data.type === targetType) {
                const item = sourceList.splice(data.index, 1)[0];
                targetList.push(item);
                if (activeType === targetType) {
                    if (activeIndex === data.index) activeIndex = targetList.length - 1;
                    else if (activeIndex > data.index) activeIndex--;
                }
            } else {
                const itemToMove = sourceList[data.index];

                if (data.type === 'sequence' && targetType === 'conversation') {
                    if (!confirm("Warning: Moving this project from Sequences to Conversations will unlink it from its associated Image Sequence. Proceed?")) return;
                    itemToMove.nodes.forEach(n => {
                        if (n.sequenceName === itemToMove.title || n.controlSequence) {
                            n.controlSequence = false;
                            n.sequenceName = '';
                            n.sequenceImage = '';
                        }
                    });
                    renderImageSequences(); 
                }

                const item = sourceList.splice(data.index, 1)[0];
                targetList.push(item);
                
                if (data.type === 'conversation' && targetType === 'sequence') {
                    if (!globalImageSequences.some(s => s.name === item.title)) {
                        globalImageSequences.push({
                            name: item.title,
                            color: item.color || getRandomColor(),
                            path: 'Assets/2D/Sequences/',
                            images: []
                        });
                    }
                    
                    if (item.nodes.length === 0) item.nodes.push(getEmptyNode());
                    item.nodes[0].controlSequence = true;
                    item.nodes[0].sequenceName = item.title;
                    const imgSeq = globalImageSequences.find(s => s.name === item.title);
                    if (imgSeq && imgSeq.images.length > 0) item.nodes[0].sequenceImage = imgSeq.images[0];
                    renderImageSequences();
                }
                
                if (activeType === data.type && activeIndex === data.index) {
                    activeType = targetType;
                    activeIndex = targetList.length - 1;
                } else if (activeType === data.type && activeIndex > data.index) {
                    activeIndex--;
                }
            }
            
            renderConversations();
            renderSequences();
        }
    } catch(err) {
        console.error("Drop handling error:", err);
    }
}

// --- PROJECT MANAGEMENT ---
function createNewConversation() {
    const title = document.getElementById('new-conv-name').value.trim();
    if (!title) return;
    
    conversations.push({ 
        title, 
        color: getRandomColor(),
        participants: [], 
        nodes: [],
        isRepeatable: false,
        repeatVariable: ''
    });
    renderConversations();
    openEditor(conversations.length - 1, 'conversation');
    document.getElementById('new-conv-name').value = '';
}

function startProjectRename(type, idx) {
    renamingProject = { type, index: idx };
    if (type === 'conversation') renderConversations();
    if (type === 'sequence') renderSequences();
}

function cancelProjectRename() {
    const oldType = renamingProject.type;
    renamingProject = { type: null, index: null };
    if (oldType === 'conversation') renderConversations();
    if (oldType === 'sequence') renderSequences();
}

function saveProjectRename(type, idx) {
    const input = document.getElementById(`rename-${type}-${idx}`);
    if (input && input.value.trim()) {
        const targetList = type === 'conversation' ? conversations : sequences;
        const oldName = targetList[idx].title;
        const newName = input.value.trim();
        targetList[idx].title = newName;
        
        if (type === 'sequence' && oldName !== newName) {
            const imgSeq = globalImageSequences.find(s => s.name === oldName);
            if (imgSeq) {
                imgSeq.name = newName;
                propagateImageSeqRename(oldName, newName);
                renderImageSequences();
            }
        }

        if (activeType === type && activeIndex === idx) {
            document.getElementById('edit-conv-name').value = newName;
        }
    }
    cancelProjectRename();
}

function duplicateProject(type, idx) {
    const sourceList = type === 'conversation' ? conversations : sequences;
    const sourceProj = sourceList[idx];

    const newProj = JSON.parse(JSON.stringify(sourceProj));

    let copyNum = 1;
    let baseTitle = newProj.title;
    if (/\s\(\d+\)$/.test(baseTitle)) {
        baseTitle = baseTitle.replace(/\s\(\d+\)$/, '');
    }
    
    while(sourceList.some(p => p.title === `${baseTitle} (${copyNum})`)) { copyNum++; }
    newProj.title = `${baseTitle} (${copyNum})`;

    const idMap = {};
    newProj.nodes.forEach(n => {
        const oldId = n.id;
        const newId = crypto.randomUUID();
        n.id = newId;
        idMap[oldId] = newId;

        n.responses.forEach(r => {
            const oldRespId = r.id;
            const newRespId = crypto.randomUUID();
            r.id = newRespId;
            idMap[oldRespId] = newRespId;
        });
    });

    newProj.nodes.forEach(n => {
        if (n.parentResponseId && idMap[n.parentResponseId]) n.parentResponseId = idMap[n.parentResponseId];
        n.responses.forEach(r => {
            if (r.nextStatementId && idMap[r.nextStatementId]) r.nextStatementId = idMap[r.nextStatementId];
        });
    });

    sourceList.splice(idx + 1, 0, newProj);
    
    if (activeType === type && activeIndex > idx) activeIndex++;
    
    if (type === 'conversation') renderConversations();
    if (type === 'sequence') renderSequences();
    showNotification("Project Duplicated successfully");
}

function deleteProject(type, idx) {
    if (confirm("Are you sure you want to delete this? This action cannot be undone.")) {
        const targetList = type === 'conversation' ? conversations : sequences;
        targetList.splice(idx, 1);
        
        if (activeType === type && activeIndex === idx) {
            activeIndex = null;
            document.getElementById('active-editor-content').style.display = 'none';
            document.getElementById('editor-placeholder').style.display = 'block';
            document.getElementById('active-project-tags-section').style.display = 'none';
        } else if (activeType === type && activeIndex > idx) {
            activeIndex--;
        }
        
        if (type === 'conversation') renderConversations();
        if (type === 'sequence') renderSequences();
    }
}

function updateConvTitle(val) {
    if (activeIndex === null) return;
    const proj = getActiveProject();
    const oldName = proj.title;
    proj.title = val;
    
    if (activeType === 'sequence' && oldName !== val) {
        const imgSeq = globalImageSequences.find(s => s.name === oldName);
        if (imgSeq) {
            imgSeq.name = val;
            propagateImageSeqRename(oldName, val);
            renderImageSequences();
        }
    }
    
    if (activeType === 'conversation') renderConversations();
    else renderSequences();
}

function updateConvColor(val) {
    if (activeIndex === null) return;
    const proj = getActiveProject();
    proj.color = val;
    
    if (activeType === 'sequence') {
        const imgSeq = globalImageSequences.find(s => s.name === proj.title);
        if (imgSeq) {
            imgSeq.color = val;
            renderImageSequences();
        }
        renderSequences();
    } else {
        renderConversations();
    }
    
    renderNodes();
}

function updateRepeatStatus(checked) {
    if (activeIndex === null) return;
    getActiveProject().isRepeatable = checked;
    const container = document.getElementById('repeat-variable-container');
    if (container) container.style.display = checked ? 'flex' : 'none';
    if (activeType === 'conversation') renderConversations();
    else renderSequences();
}

function updateRepeatVariable(val) {
    if (activeIndex === null) return;
    getActiveProject().repeatVariable = val;
}

// --- GLOBAL ASSET CREATION & DELETION ---

function addGlobalToken() {
    const input = document.getElementById('new-token-key');
    const key = input.value.trim().replace(/[^a-zA-Z0-9_]/g, '');
    if (!key) return;
    if (globalTokens.some(t => t.key === key)) {
        showNotification("Token key already exists.", true);
        return;
    }
    globalTokens.push({ key, value: "Sample Value" });
    input.value = '';
    renderTokens();
    renderNodes();
}

function removeToken(idx) {
    globalTokens.splice(idx, 1);
    renderTokens();
    renderNodes();
}

function updateTokenValue(idx, val) {
    globalTokens[idx].value = val;
}

function saveTokenEdit(index) {
    const input = document.getElementById(`edit-token-key-${index}`);
    if (!input) return cancelEdit();
    
    const newKey = input.value.trim().replace(/[^a-zA-Z0-9_]/g, '');
    if (!newKey) return cancelEdit();

    if (globalTokens[index].key !== newKey && globalTokens.some(t => t.key === newKey)) {
        showNotification("Token key already exists.", true);
        return cancelEdit();
    }

    const oldKey = globalTokens[index].key;
    if (oldKey !== newKey) propagateTokenRename(oldKey, newKey);

    globalTokens[index].key = newKey;
    cancelEdit();
    renderNodes();
}

function addNewImageSequence() {
    const input = document.getElementById('custom-image-seq-name');
    const colorInput = document.getElementById('custom-image-seq-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();

    if (!name || globalImageSequences.some(s => s.name === name)) return;
    globalImageSequences.push({ name, color, path: 'Assets/2D/Sequences/', images: [] });
    
    if (!sequences.some(s => s.title === name)) {
        sequences.push({
            title: name, color: color, participants: [], nodes: [],
            isRepeatable: false, repeatVariable: ''
        });
        renderSequences();
    }
    
    renderImageSequences();
    renderNodes();
    input.value = '';
    randomizePickerColors();
}

function regenerateSequenceProject(seqName) {
    if (sequences.some(s => s.title === seqName)) return; 
    const imgSeq = globalImageSequences.find(s => s.name === seqName);
    if (!imgSeq) return;
    
    const seqProj = {
        title: seqName,
        color: imgSeq.color,
        participants: [],
        nodes: [],
        isRepeatable: false,
        repeatVariable: ''
    };
    seqProj.nodes.push(getEmptyNode());
    sequences.push(seqProj);
    
    seqProj.nodes[0].controlSequence = true;
    seqProj.nodes[0].sequenceName = seqName;
    if (imgSeq && imgSeq.images.length > 0) {
        seqProj.nodes[0].sequenceImage = imgSeq.images[0];
    }

    renderSequences();
    renderImageSequences(); 
    showNotification(`Generated Sequence Project for '${seqName}'`);
}

function saveImageSeqEdit(index) {
    const newName = document.getElementById(`edit-imgseq-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-imgseq-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalImageSequences[index].name !== newName && globalImageSequences.some(s => s.name === newName)) return cancelEdit();

    const oldName = globalImageSequences[index].name;
    globalImageSequences[index].name = newName;
    globalImageSequences[index].color = newColor;

    if (oldName !== newName) {
        if (openImageSeqs.has(oldName)) {
            openImageSeqs.delete(oldName);
            openImageSeqs.add(newName);
        }
        propagateImageSeqRename(oldName, newName);
        const seq = sequences.find(s => s.title === oldName);
        if (seq) {
            seq.title = newName;
            seq.color = newColor;
            if (activeType === 'sequence' && sequences[activeIndex] === seq) {
                document.getElementById('edit-conv-name').value = newName;
                document.getElementById('edit-conv-color').value = newColor;
            }
        }
    } else {
        const seq = sequences.find(s => s.title === oldName);
        if (seq) {
            seq.color = newColor;
            if (activeType === 'sequence' && sequences[activeIndex] === seq) {
                document.getElementById('edit-conv-color').value = newColor;
            }
        }
    }
    
    cancelEdit();
    renderSequences();
    renderImageSequences();
    renderNodes();
}

function updateImageSeqPath(index, val) {
    globalImageSequences[index].path = val;
}

function saveImageEdit(seqIndex, imgIndex) {
    const newName = document.getElementById(`edit-img-name-${seqIndex}-${imgIndex}`).value.trim();
    if (!newName) return cancelEdit();
    
    const seq = globalImageSequences[seqIndex];
    const oldName = seq.images[imgIndex];
    if (oldName !== newName && seq.images.includes(newName)) return cancelEdit();
    
    seq.images[imgIndex] = newName;
    if (oldName !== newName) propagateImageRename(seq.name, oldName, newName);
    
    cancelEdit();
    renderImageSequences();
    renderNodes();
}

function deleteImageSequence(idx) {
    if (confirm("Delete this entire Image Sequence?")) {
        const seqName = globalImageSequences[idx].name;
        openImageSeqs.delete(seqName);
        globalImageSequences.splice(idx, 1);
        renderImageSequences();
        renderNodes();
    }
}

function deleteImageFromSequence(seqIdx, imgIdx) {
    globalImageSequences[seqIdx].images.splice(imgIdx, 1);
    renderImageSequences();
    renderNodes();
}

function sortImageSequence(seqIndex) {
    globalImageSequences[seqIndex].images.sort(new Intl.Collator('en', { numeric: true, sensitivity: 'base' }).compare);
    renderImageSequences();
    renderNodes();
}

function clearImageSequence(seqIndex) {
    if (confirm("Clear all images from this sequence?")) {
        globalImageSequences[seqIndex].images = [];
        renderImageSequences();
        renderNodes();
    }
}

function addNewCustomParticipant() {
    const nameInput = document.getElementById('custom-participant-name');
    const colorInput = document.getElementById('custom-participant-color');
    const name = nameInput.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();

    if (!name || cast.some(c => c.name === name)) return;
    cast.push({ name, color });
    renderCast();
    updateLocalAddDropdown();
    nameInput.value = '';
    randomizePickerColors();
}

function removeGlobalChar(index) {
    cast.splice(index, 1);
    renderCast();
    updateLocalAddDropdown();
}

function saveCastEdit(index) {
    const newName = document.getElementById(`edit-cast-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-cast-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (cast[index].name !== newName && cast.some(c => c.name === newName)) return cancelEdit();

    const oldName = cast[index].name;
    if (oldName !== newName) propagateCastRename(oldName, newName);
    
    cast[index].name = newName;
    cast[index].color = newColor;
    
    cancelEdit();
    renderLocalCast();
    updateLocalAddDropdown();
    renderNodes();
    renderConversations();
    renderSequences();
}

function addNewState() {
    const input = document.getElementById('custom-state-name');
    const colorInput = document.getElementById('custom-state-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();
    if (!name || globalStates.some(s => s.name === name)) return;
    globalStates.push({ name, color });
    renderStates();
    renderNodes(); 
    input.value = '';
    randomizePickerColors();
}

function removeGlobalState(index) {
    globalStates.splice(index, 1);
    renderStates();
    renderNodes();
}

function saveStateEdit(index) {
    const newName = document.getElementById(`edit-state-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-state-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalStates[index].name !== newName && globalStates.some(s => s.name === newName)) return cancelEdit();
    const oldName = globalStates[index].name;
    if (oldName !== newName) propagateStateRename(oldName, newName);
    globalStates[index].name = newName;
    globalStates[index].color = newColor;
    cancelEdit();
    renderNodes();
}

function addNewMood() {
    const input = document.getElementById('custom-mood-name');
    const colorInput = document.getElementById('custom-mood-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();
    if (!name || globalMoods.some(m => m.name === name)) return;
    globalMoods.push({ name, color });
    renderMoods();
    renderNodes();
    input.value = '';
    randomizePickerColors();
}

function removeGlobalMood(index) {
    globalMoods.splice(index, 1);
    renderMoods();
    renderNodes();
}

function saveMoodEdit(index) {
    const newName = document.getElementById(`edit-mood-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-mood-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalMoods[index].name !== newName && globalMoods.some(m => m.name === newName)) return cancelEdit();
    const oldName = globalMoods[index].name;
    if (oldName !== newName) propagateMoodRename(oldName, newName);
    globalMoods[index].name = newName;
    globalMoods[index].color = newColor;
    cancelEdit();
    renderNodes();
}

function addNewSetting() {
    const input = document.getElementById('custom-setting-name');
    const colorInput = document.getElementById('custom-setting-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();
    if (!name || globalSettings.some(s => s.name === name)) return;
    globalSettings.push({ name, color });
    renderSettings();
    renderNodes();
    input.value = '';
    randomizePickerColors();
}

function removeGlobalSetting(index) {
    globalSettings.splice(index, 1);
    renderSettings();
    renderNodes();
}

function saveSettingEdit(index) {
    const newName = document.getElementById(`edit-setting-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-setting-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalSettings[index].name !== newName && globalSettings.some(s => s.name === newName)) return cancelEdit();
    const oldName = globalSettings[index].name;
    if (oldName !== newName) propagateSettingRename(oldName, newName);
    globalSettings[index].name = newName;
    globalSettings[index].color = newColor;
    cancelEdit();
    renderNodes();
}

function addNewTimeOfDay() {
    const input = document.getElementById('custom-time-name');
    const colorInput = document.getElementById('custom-time-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();
    if (!name || globalTimesOfDay.some(s => s.name === name)) return;
    globalTimesOfDay.push({ name, color });
    renderTimesOfDay();
    renderNodes();
    input.value = '';
    randomizePickerColors();
}

function removeGlobalTimeOfDay(index) {
    globalTimesOfDay.splice(index, 1);
    renderTimesOfDay();
    renderNodes();
}

function saveTimeOfDayEdit(index) {
    const newName = document.getElementById(`edit-time-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-time-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalTimesOfDay[index].name !== newName && globalTimesOfDay.some(s => s.name === newName)) return cancelEdit();
    const oldName = globalTimesOfDay[index].name;
    if (oldName !== newName) propagateTimeOfDayRename(oldName, newName);
    globalTimesOfDay[index].name = newName;
    globalTimesOfDay[index].color = newColor;
    cancelEdit();
    renderNodes();
}

function addNewDayOfWeek() {
    const input = document.getElementById('custom-day-name');
    const colorInput = document.getElementById('custom-day-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();
    if (!name || globalDaysOfWeek.some(s => s.name === name)) return;
    globalDaysOfWeek.push({ name, color });
    renderDaysOfWeek();
    renderNodes();
    input.value = '';
    randomizePickerColors();
}

function removeGlobalDayOfWeek(index) {
    globalDaysOfWeek.splice(index, 1);
    renderDaysOfWeek();
    renderNodes();
}

function saveDayOfWeekEdit(index) {
    const newName = document.getElementById(`edit-day-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-day-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalDaysOfWeek[index].name !== newName && globalDaysOfWeek.some(s => s.name === newName)) return cancelEdit();
    const oldName = globalDaysOfWeek[index].name;
    if (oldName !== newName) propagateDayOfWeekRename(oldName, newName);
    globalDaysOfWeek[index].name = newName;
    globalDaysOfWeek[index].color = newColor;
    cancelEdit();
    renderNodes();
}

function addNewMenuOption() {
    const input = document.getElementById('custom-menu-name');
    const colorInput = document.getElementById('custom-menu-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();
    if (!name || globalMenuOptions.some(s => s.name === name)) return;
    globalMenuOptions.push({ name, color });
    renderMenuOptions();
    renderNodes();
    input.value = '';
    randomizePickerColors();
}

function removeGlobalMenuOption(index) {
    globalMenuOptions.splice(index, 1);
    renderMenuOptions();
    renderNodes();
}

function saveMenuOptionEdit(index) {
    const newName = document.getElementById(`edit-menu-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-menu-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalMenuOptions[index].name !== newName && globalMenuOptions.some(s => s.name === newName)) return cancelEdit();
    const oldName = globalMenuOptions[index].name;
    if (oldName !== newName) propagateMenuOptionRename(oldName, newName);
    globalMenuOptions[index].name = newName;
    globalMenuOptions[index].color = newColor;
    cancelEdit();
    renderNodes();
}

// --- LINKING MODAL & LOGIC ---
function openLinkSequenceModal(seqName) {
    const modal = document.getElementById('link-sequence-modal');
    const select = document.getElementById('link-node-select');
    document.getElementById('linking-seq-name-display').textContent = seqName;
    document.getElementById('linking-seq-name').value = seqName;
    
    let optionsHtml = '<option value="">-- Select Target Project --</option>';
    
    const buildOptions = (projects, typeKey, sectionName) => {
        if (projects.length === 0) return '';
        let html = `<optgroup label="${sectionName}">`;
        projects.forEach((proj, pIdx) => {
            if(proj.nodes.length === 0) return;
            const nodeIdShort = proj.nodes[0].id.substring(proj.nodes[0].id.length - 6);
            const currentLink = proj.nodes.some(n => n.sequenceName === seqName) ? ' (LINKED IN PROJECT)' : '';
            html += `<option value="${typeKey}|${pIdx}">${escapeHtml(proj.title)} - [${nodeIdShort}]${currentLink}</option>`;
        });
        html += `</optgroup>`;
        return html;
    };

    optionsHtml += buildOptions(conversations, 'conv', 'Conversations');
    optionsHtml += buildOptions(sequences, 'seq', 'Sequences');
    
    select.innerHTML = optionsHtml;
    modal.style.display = 'flex';
}

function closeLinkSequenceModal() {
    document.getElementById('link-sequence-modal').style.display = 'none';
}

function applySequenceLink() {
    const seqName = document.getElementById('linking-seq-name').value;
    const val = document.getElementById('link-node-select').value;
    
    if (!val) {
        showNotification("No target project selected.", true);
        return;
    }

    const [typeKey, pIdxStr] = val.split('|');
    const pIdx = parseInt(pIdxStr);

    const targetList = typeKey === 'conv' ? conversations : sequences;
    const targetProj = targetList[pIdx];

    if (targetProj.nodes.length === 0) {
        targetProj.nodes.push(getEmptyNode());
    }
    const targetNode = targetProj.nodes[0];

    if (targetNode.controlSequence && targetNode.sequenceName && targetNode.sequenceName !== seqName) {
        if (!confirm(`This project is already linked to Image Sequence '${targetNode.sequenceName}'. Overwrite?`)) {
            return;
        }
    }

    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach((node, pNIdx) => {
            if (node.sequenceName === seqName) {
                node.controlSequence = false;
                node.sequenceName = '';
                node.sequenceImage = '';
                if (activeIndex !== null && getActiveProject() === proj) {
                    markNodeEdited(pNIdx);
                }
            }
        });
    });

    targetNode.controlSequence = true;
    targetNode.sequenceName = seqName;
    const imgSeq = globalImageSequences.find(s => s.name === seqName);
    if (imgSeq && imgSeq.images.length > 0) {
        targetNode.sequenceImage = imgSeq.images[0];
    }

    closeLinkSequenceModal();
    showNotification(`Sequence successfully linked to ${targetProj.title}`);
    
    renderImageSequences();
    if ((activeType === 'conversation' && typeKey === 'conv' && activeIndex === pIdx) ||
        (activeType === 'sequence' && typeKey === 'seq' && activeIndex === pIdx)) {
        markNodeEdited(0);
        renderNodes();
    }
}

function unlinkSequenceCompletely(passedSeqName = null) {
    const seqName = passedSeqName || document.getElementById('linking-seq-name').value;
    
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach((node, nIdx) => {
            if (node.sequenceName === seqName) {
                node.controlSequence = false;
                node.sequenceName = '';
                node.sequenceImage = '';
                if (activeIndex !== null && getActiveProject() === proj) {
                    markNodeEdited(nIdx);
                }
            }
        });
    });
    
    closeLinkSequenceModal();
    showNotification(`Unlinked all associations for ${seqName}`);
    renderImageSequences();
    renderNodes();
}

function propagateTokenRename(oldKey, newKey) {
    const oldTag = `{{${oldKey}}}`;
    const newTag = `{{${newKey}}}`;
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => {
            if (node.text && node.text.includes(oldTag)) node.text = node.text.split(oldTag).join(newTag);
            (node.responses || []).forEach(r => {
                if (r.text && r.text.includes(oldTag)) r.text = r.text.split(oldTag).join(newTag);
            });
        });
    });
}

function propagateCastRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        const pIdx = proj.participants.indexOf(oldName);
        if (pIdx !== -1) proj.participants[pIdx] = newName;
        proj.nodes.forEach(node => {
            if (node.speaker === oldName) node.speaker = newName;
            node.responses.forEach(r => { if (r.speaker === oldName) r.speaker = newName; });
            node.puppets.forEach(p => { if (p.name === oldName) p.name = newName; });
        });
    });
}

function propagateStateRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => { node.puppets.forEach(p => { if (p.state === oldName) p.state = newName; }); });
    });
}

function propagateMoodRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => { node.puppets.forEach(p => { if (p.mood === oldName) p.mood = newName; }); });
    });
}

function propagateSettingRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => { (node.settingChanges || []).forEach(change => { if (change.setting === oldName) change.setting = newName; }); });
    });
}

function propagateTimeOfDayRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => { (node.timeOfDayChanges || []).forEach(change => { if (change.time === oldName) change.time = newName; }); });
    });
}

function propagateDayOfWeekRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => { (node.dayOfWeekChanges || []).forEach(change => { if (change.day === oldName) change.day = newName; }); });
    });
}

function propagateMenuOptionRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => { (node.menuOptionChanges || []).forEach(change => { if (change.menu === oldName) change.menu = newName; }); });
    });
}

function propagateImageSeqRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => { if (node.sequenceName === oldName) node.sequenceName = newName; });
    });
}

function propagateImageRename(seqName, oldImgName, newImgName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => { if (node.sequenceName === seqName && node.sequenceImage === oldImgName) node.sequenceImage = newImgName; });
    });
}

// --- NODE MANAGEMENT ---
function addCharToLocal(name) {
    if (!name || activeIndex === null) return;
    getActiveProject().participants.push(name);
    renderLocalCast();
    renderNodes();
    if (activeType === 'conversation') renderConversations();
    else renderSequences();
}

function removeCharFromLocal(name) {
    const project = getActiveProject();
    project.participants = project.participants.filter(p => p !== name);
    renderLocalCast();
    renderNodes();
}

function handleNodeExclusivity(nIdx, checkedKey, uncheckedKey, isChecked) {
    const node = getActiveProject().nodes[nIdx];
    node[checkedKey] = isChecked;
    if (isChecked) node[uncheckedKey] = false;
    markNodeEdited(nIdx);
    renderNodes();
}

function addDialogueNode(sourceResponseId = null, previewText = null, insertIndex = null) {
    if (activeIndex === null) return;
    const project = getActiveProject();
    const newNode = getEmptyNode(project.participants[0] || '');
    newNode.parentResponseId = sourceResponseId;
    newNode.parentResponsePreview = previewText;
    
    if (insertIndex !== null) project.nodes.splice(insertIndex, 0, newNode);
    else project.nodes.push(newNode);
    
    renderNodes();
    return newNode.id;
}

function deleteNode(nodeIdx) {
    const project = getActiveProject();
    const nodeToDelete = project.nodes[nodeIdx];
    
    project.nodes.forEach(n => {
        n.responses.forEach(r => {
            if (r.nextStatementId === nodeToDelete.id || r.id === nodeToDelete.parentResponseId) r.nextStatementId = null;
        });
    });

    project.nodes.splice(nodeIdx, 1);
    renderNodes();
}

function moveNode(fromIdx, toIdx) {
    if (activeIndex === null || fromIdx === toIdx) return;
    const project = getActiveProject();
    const nodeToMove = project.nodes.splice(fromIdx, 1)[0];
    project.nodes.splice(toIdx, 0, nodeToMove);
    renderNodes();
    setTimeout(() => scrollToElement(`node-${nodeToMove.id}`), 50);
}

// --- TRANSLATION SUPPORT API ---
function updateNodeText(nIdx, val) { 
    const p = getActiveProject(); 
    if (currentLanguage === 'ENG') p.nodes[nIdx].text = val; 
    else { 
        if (!p.nodes[nIdx].translations) p.nodes[nIdx].translations = {}; 
        p.nodes[nIdx].translations[currentLanguage] = val; 
    } 
    markNodeEdited(nIdx); 
}

function updateResponseText(nIdx, rIdx, val) { 
    const p = getActiveProject(); 
    if (currentLanguage === 'ENG') p.nodes[nIdx].responses[rIdx].text = val; 
    else { 
        if (!p.nodes[nIdx].responses[rIdx].translations) p.nodes[nIdx].responses[rIdx].translations = {}; 
        p.nodes[nIdx].responses[rIdx].translations[currentLanguage] = val; 
    } 
    markNodeEdited(nIdx); 
}

function toggleAddLanguage() {
    isAddingLanguage = !isAddingLanguage;
    renderNodes();
}

function confirmAddLanguage() {
    const input = document.getElementById('new-lang-code');
    const val = input.value.trim().toUpperCase();
    if (val.length === 3 && !availableLanguages.includes(val)) {
        availableLanguages.push(val);
        currentLanguage = val;
        isAddingLanguage = false;
        renderNodes();
    } else {
        showNotification("Invalid Language Code. Use exactly 3 characters.", true);
    }
}

// --- PUPPET & STATE MODIFIERS ---
function toggleControlPuppets(nIdx, isChecked) { getActiveProject().nodes[nIdx].controlPuppets = isChecked; markNodeEdited(nIdx); renderNodes(); }
function addPuppetToNode(nIdx, charName) {
    if(!charName) return;
    const node = getActiveProject().nodes[nIdx];
    if (!node.puppets.some(p => p.name === charName)) {
        node.puppets.push({ name: charName, enabled: true, position: '', path: 'Assets/Resources/Puppets/', state: '', mood: '', invert: false });
        markNodeEdited(nIdx); renderNodes();
    }
}
function removePuppetFromNode(nIdx, pIdx) { getActiveProject().nodes[nIdx].puppets.splice(pIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function togglePuppetEnabled(nIdx, pIdx, isChecked) { getActiveProject().nodes[nIdx].puppets[pIdx].enabled = isChecked; markNodeEdited(nIdx); renderNodes(); }
function updatePuppetPosition(nIdx, pIdx, val) { getActiveProject().nodes[nIdx].puppets[pIdx].position = val; markNodeEdited(nIdx); }
function toggleChangePuppetState(nIdx, isChecked) { getActiveProject().nodes[nIdx].changePuppetState = isChecked; markNodeEdited(nIdx); renderNodes(); }
function togglePuppetUseTag(nIdx, isChecked) {
    const node = getActiveProject().nodes[nIdx];
    node.puppetUseTag = isChecked;
    if (isChecked) node.puppetUsePath = false;
    markNodeEdited(nIdx); renderNodes();
}
function togglePuppetUsePath(nIdx, isChecked) {
    const node = getActiveProject().nodes[nIdx];
    node.puppetUsePath = isChecked;
    if (isChecked) node.puppetUseTag = false;
    markNodeEdited(nIdx); renderNodes();
}
function toggleChangePuppetMood(nIdx, isChecked) { getActiveProject().nodes[nIdx].changePuppetMood = isChecked; markNodeEdited(nIdx); renderNodes(); }
function toggleChangePuppetInvert(nIdx, isChecked) { getActiveProject().nodes[nIdx].changePuppetInvert = isChecked; markNodeEdited(nIdx); renderNodes(); }
function updatePuppetPath(nIdx, pIdx, val) { getActiveProject().nodes[nIdx].puppets[pIdx].path = val; markNodeEdited(nIdx); }
function updatePuppetState(nIdx, pIdx, val) { getActiveProject().nodes[nIdx].puppets[pIdx].state = val; markNodeEdited(nIdx); }
function updatePuppetMood(nIdx, pIdx, val) { getActiveProject().nodes[nIdx].puppets[pIdx].mood = val; markNodeEdited(nIdx); }
function updatePuppetInvert(nIdx, pIdx, isChecked) { getActiveProject().nodes[nIdx].puppets[pIdx].invert = isChecked; markNodeEdited(nIdx); }

function addConditionRow(nIdx) { getActiveProject().nodes[nIdx].conditions.push({ variable: '', operator: '==', value: '' }); markNodeEdited(nIdx); renderNodes(); }
function removeConditionRow(nIdx, cIdx) { getActiveProject().nodes[nIdx].conditions.splice(cIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function updateCondition(nIdx, cIdx, field, val) { getActiveProject().nodes[nIdx].conditions[cIdx][field] = val; markNodeEdited(nIdx); renderProjectTags(); updateNodeGlows(); }
function addTimeChangeRow(nIdx) { getActiveProject().nodes[nIdx].timeOfDayChanges.push({ time: '', value: '' }); markNodeEdited(nIdx); renderNodes(); }
function removeTimeChangeRow(nIdx, cIdx) { getActiveProject().nodes[nIdx].timeOfDayChanges.splice(cIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function updateTimeChange(nIdx, cIdx, field, val) { getActiveProject().nodes[nIdx].timeOfDayChanges[cIdx][field] = val; markNodeEdited(nIdx); }
function addDayChangeRow(nIdx) { getActiveProject().nodes[nIdx].dayOfWeekChanges.push({ day: '', value: '' }); markNodeEdited(nIdx); renderNodes(); }
function removeDayChangeRow(nIdx, cIdx) { getActiveProject().nodes[nIdx].dayOfWeekChanges.splice(cIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function updateDayChange(nIdx, cIdx, field, val) { getActiveProject().nodes[nIdx].dayOfWeekChanges[cIdx][field] = val; markNodeEdited(nIdx); }
function addMenuChangeRow(nIdx) { getActiveProject().nodes[nIdx].menuOptionChanges.push({ menu: '', value: '' }); markNodeEdited(nIdx); renderNodes(); }
function removeMenuChangeRow(nIdx, cIdx) { getActiveProject().nodes[nIdx].menuOptionChanges.splice(cIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function updateMenuChange(nIdx, cIdx, field, val) { getActiveProject().nodes[nIdx].menuOptionChanges[cIdx][field] = val; markNodeEdited(nIdx); }
function addStateChangeRow(nIdx) { getActiveProject().nodes[nIdx].gameStateChanges.push({ variable: '', operator: '==', value: '' }); markNodeEdited(nIdx); renderNodes(); }
function removeStateChangeRow(nIdx, cIdx) { getActiveProject().nodes[nIdx].gameStateChanges.splice(cIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function updateStateChange(nIdx, cIdx, field, val) { getActiveProject().nodes[nIdx].gameStateChanges[cIdx][field] = val; markNodeEdited(nIdx); renderProjectTags(); updateNodeGlows(); }
function addSettingChangeRow(nIdx) { getActiveProject().nodes[nIdx].settingChanges.push({ setting: '', value: '' }); markNodeEdited(nIdx); renderNodes(); }
function removeSettingChangeRow(nIdx, cIdx) { getActiveProject().nodes[nIdx].settingChanges.splice(cIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function updateSettingChange(nIdx, cIdx, field, val) { getActiveProject().nodes[nIdx].settingChanges[cIdx][field] = val; markNodeEdited(nIdx); }

function linkExistingStatement(nodeIndex, responseIndex, targetNodeId) {
    if (!targetNodeId) return;
    const project = getActiveProject();
    const response = project.nodes[nodeIndex].responses[responseIndex];
    const targetNode = project.nodes.find(n => n.id === targetNodeId);
    if (targetNode) {
        response.nextStatementId = targetNodeId;
        markNodeEdited(nodeIndex);
        renderNodes();
    }
}

function establishReverseReply(nIdx) {
    const project = getActiveProject();
    const currentNode = project.nodes[nIdx];
    const selectEl = document.getElementById(`reverse-link-select-${nIdx}`);
    if (!selectEl) return;
    
    const parentNodeId = selectEl.value;
    if (!parentNodeId) return;

    const parentNode = project.nodes.find(n => n.id === parentNodeId);
    if (!parentNode) return;
    if ((parentNode.responses || []).length >= 4) {
        showNotification("Target statement already has 4 responses.", true);
        return;
    }

    parentNode.canPlayerRespond = true;
    const newResponseId = crypto.randomUUID();
    const responseSpeaker = project.participants[0] || '';
    
    parentNode.responses.push({
        id: newResponseId, speaker: responseSpeaker, text: 'Continue...', nextStatementId: currentNode.id,
        voiceLine: false, externalCall: false, makeExternalCall: false, conditions: [], gameStateChanges: [], conditionsOpen: true, statesOpen: true, autoIncrement: false, translations: {}
    });

    markNodeEdited(nIdx);
    markNodeEdited(project.nodes.indexOf(parentNode));
    renderNodes();
}

function unlinkResponse(nIdx, rIdx) {
    if (activeIndex === null) return;
    const project = getActiveProject();
    if (project.nodes[nIdx] && project.nodes[nIdx].responses[rIdx]) {
        project.nodes[nIdx].responses[rIdx].nextStatementId = null;
        markNodeEdited(nIdx);
        renderNodes();
    }
}

function unlinkSpecificReverseReply(childNIdx, parentNodeId, responseId) {
    const project = getActiveProject();
    const parentNode = project.nodes.find(n => n.id === parentNodeId);
    if (parentNode) {
        const resp = parentNode.responses.find(r => r.id === responseId);
        if (resp) resp.nextStatementId = null;
    }
    markNodeEdited(childNIdx);
    renderNodes();
}

function applyResp(nIdx) {
    const node = getActiveProject().nodes[nIdx];
    if ((node.responses || []).length >= 4) {
        showNotification("Maximum 4 responses allowed.", true);
        return;
    }
    const textInput = document.getElementById(`resp-input-${nIdx}`);
    const speakerSelect = document.getElementById(`resp-speaker-${nIdx}`);
    if (!textInput || !textInput.value.trim()) return;
    
    node.responses.push({ 
        id: crypto.randomUUID(), speaker: speakerSelect.value, text: textInput.value,
        nextStatementId: null, voiceLine: false, externalCall: false, makeExternalCall: false, conditions: [], gameStateChanges: [], conditionsOpen: true, statesOpen: true, autoIncrement: false, translations: {}
    });
    markNodeEdited(nIdx);
    renderNodes();
    textInput.value = '';
}

function createReplyStatement(nodeIndex, responseIndex) {
    const project = getActiveProject();
    const response = project.nodes[nodeIndex].responses[responseIndex];
    if (response.nextStatementId && project.nodes.some(n => n.id === response.nextStatementId)) return;
    
    const nodeText = currentLanguage === 'ENG' ? (response.text || '') : (response.translations?.[currentLanguage] || '');
    const preview = `${response.speaker}: ${nodeText.substring(0, 30)}${nodeText.length > 30 ? '...' : ''}`;
    const newNodeId = addDialogueNode(response.id, preview, nodeIndex + 1);
    response.nextStatementId = newNodeId;
    
    markNodeEdited(nodeIndex);
    renderNodes();
    setTimeout(() => scrollToElement(`node-${newNodeId}`), 50);
}

function removeResponse(nIdx, rIdx) {
    if (activeIndex === null) return;
    const project = getActiveProject();
    const response = project.nodes[nIdx].responses[rIdx];
    
    if (response.nextStatementId) {
        const targetNode = project.nodes.find(n => n.id === response.nextStatementId);
        if (targetNode && targetNode.parentResponseId === response.id) {
            targetNode.parentResponseId = null;
            targetNode.parentResponsePreview = null;
        }
    }
    
    project.nodes[nIdx].responses.splice(rIdx, 1);
    markNodeEdited(nIdx);
    renderNodes();
}

function saveEditedResponse(nIdx, rIdx) {
    const input = document.getElementById(`edit-input-${nIdx}-${rIdx}`);
    const speakerSelect = document.getElementById(`edit-speaker-${nIdx}-${rIdx}`);
    
    if (input && speakerSelect) {
        const project = getActiveProject();
        updateResponseText(nIdx, rIdx, input.value.trim());
        project.nodes[nIdx].responses[rIdx].speaker = speakerSelect.value;
        
        const response = project.nodes[nIdx].responses[rIdx];
        if (response.nextStatementId) {
            const targetNode = project.nodes.find(n => n.id === response.nextStatementId);
            if (targetNode) {
                const updatedText = currentLanguage === 'ENG' ? (response.text || '') : (response.translations?.[currentLanguage] || '');
                targetNode.parentResponsePreview = `${response.speaker}: ${updatedText.substring(0, 30)}${updatedText.length > 30 ? '...' : ''}`;
            }
        }
    }
    editingResponseRef = null;
    markNodeEdited(nIdx);
    renderNodes();
}

function moveResponseUp(nIdx, rIdx) {
    if (activeIndex === null || rIdx <= 0) return;
    const project = getActiveProject();
    const responses = project.nodes[nIdx].responses;
    const temp = responses[rIdx - 1];
    responses[rIdx - 1] = responses[rIdx];
    responses[rIdx] = temp;
    markNodeEdited(nIdx);
    renderNodes();
}

function moveResponseDown(nIdx, rIdx) {
    if (activeIndex === null) return;
    const project = getActiveProject();
    const responses = project.nodes[nIdx].responses;
    if (rIdx >= responses.length - 1) return;
    const temp = responses[rIdx + 1];
    responses[rIdx + 1] = responses[rIdx];
    responses[rIdx] = temp;
    markNodeEdited(nIdx);
    renderNodes();
}

function toggleResponseAutoIncrement(nIdx, rIdx, isChecked) { getActiveProject().nodes[nIdx].responses[rIdx].autoIncrement = isChecked; markNodeEdited(nIdx); updateResponseGlow(nIdx, rIdx); }
function addResponseConditionRow(nIdx, rIdx) { const response = getActiveProject().nodes[nIdx].responses[rIdx]; response.conditionsOpen = true; response.conditions.push({ variable: '', operator: '==', value: '' }); markNodeEdited(nIdx); renderNodes(); }
function removeResponseConditionRow(nIdx, rIdx, cIdx) { getActiveProject().nodes[nIdx].responses[rIdx].conditions.splice(cIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function updateResponseConditionRow(nIdx, rIdx, cIdx, field, val) { getActiveProject().nodes[nIdx].responses[rIdx].conditions[cIdx][field] = val; markNodeEdited(nIdx); renderProjectTags(); updateNodeGlows(); }
function addResponseStateChangeRow(nIdx, rIdx) { const response = getActiveProject().nodes[nIdx].responses[rIdx]; response.statesOpen = true; response.gameStateChanges.push({ variable: '', operator: '=', value: '' }); markNodeEdited(nIdx); renderNodes(); }
function removeResponseStateChangeRow(nIdx, rIdx, cIdx) { getActiveProject().nodes[nIdx].responses[rIdx].gameStateChanges.splice(cIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function updateResponseStateChangeRow(nIdx, rIdx, cIdx, field, val) { getActiveProject().nodes[nIdx].responses[rIdx].gameStateChanges[cIdx][field] = val; markNodeEdited(nIdx); renderProjectTags(); updateNodeGlows(); updateResponseGlow(nIdx, rIdx); }