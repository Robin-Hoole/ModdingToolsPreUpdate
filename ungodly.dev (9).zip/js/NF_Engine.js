/**
 * NF_Engine.js
 * Visual/Mathematical engine for the canvas, connections, transformations, group boxes, and Glow processing.
 */

function updateTransform() {
    bgLayer.style.transform = `translate(${panX}px, ${panY}px) scale(${scale})`;
    groupLayer.style.transform = `translate(${panX}px, ${panY}px) scale(${scale})`;
    nodeLayer.style.transform = `translate(${panX}px, ${panY}px) scale(${scale})`;
    document.getElementById('zoom-level').innerText = `Zoom: ${Math.round(scale * 100)}%`;
    requestAnimationFrame(() => drawConnections());
}

function resizeCanvas() {
    const dpr = window.devicePixelRatio || 1; const rect = container.getBoundingClientRect();
    canvas.width = rect.width * dpr; canvas.height = rect.height * dpr;
    requestAnimationFrame(() => drawConnections());
}

function drawConnections() {
    const dpr = window.devicePixelRatio || 1;
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.translate(panX, panY); ctx.scale(scale, scale); ctx.lineWidth = 3 / scale;
    connectionPaths = []; 
    
    storyNodes.filter(n => n.canvasId === currentCanvasId).forEach(src => {
        src.nextConversations.forEach(dstId => {
            const dst = storyNodes.find(n => n.id === dstId && n.canvasId === currentCanvasId);
            if (dst) {
                const outColor = src.type === 'task' ? 'var(--accent-gold)' : (src.type === 'sequence' ? 'var(--accent-blue)' : (src.type === 'menu' ? 'var(--accent-green)' : (src.type==='trans'||src.type==='imgnode')?'var(--accent-orange)' : 'var(--accent-teal)'));
                const inColor = dst.color || (dst.type === 'task' ? 'var(--accent-purple)' : (dst.type === 'sequence' ? 'var(--accent-blue)' : (dst.type === 'menu' ? 'var(--accent-green)' : (dst.type==='trans'||dst.type==='imgnode')?'var(--accent-orange)' : 'var(--accent-teal)')));
                const srcEl = document.querySelector(`.story-node[data-id="${src.id}"]`);
                const dstEl = document.querySelector(`.story-node[data-id="${dst.id}"]`);
                const sW = srcEl ? srcEl.offsetWidth : 240; const sH = srcEl ? srcEl.offsetHeight : 90; const dH = dstEl ? dstEl.offsetHeight : 90;
                const path = drawCurve(src.x + sW, src.y + sH/2, dst.x, dst.y + dH/2, outColor, inColor);
                connectionPaths.push({ path, srcId: src.id, dstId: dst.id });
            }
        });
    });

    if (isLinking && linkSourceId) {
        const src = storyNodes.find(n => n.id === linkSourceId && n.canvasId === currentCanvasId);
        if (src) {
            const srcEl = document.querySelector(`.story-node[data-id="${src.id}"]`);
            const sW = srcEl ? srcEl.offsetWidth : 240; const sH = srcEl ? srcEl.offsetHeight : 90;
            const rect = container.getBoundingClientRect();
            const mx = (lastMousePos.x - rect.left - panX) / scale; const my = (lastMousePos.y - rect.top - panY) / scale;
            const outColor = src.type === 'task' ? 'var(--accent-gold)' : (src.type === 'sequence' ? 'var(--accent-blue)' : (src.type === 'menu' ? 'var(--accent-green)' : 'var(--accent-teal)'));
            drawCurve(src.x + sW, src.y + sH/2, mx, my, outColor, outColor);
        }
    }
}

function drawCurve(x1, y1, x2, y2, c1, c2) {
    const path = new Path2D(); path.moveTo(x1, y1); const cp = Math.max(Math.abs(x2 - x1) * 0.5, 50); path.bezierCurveTo(x1 + cp, y1, x2 - cp, y2, x2, y2);
    const g = ctx.createLinearGradient(x1, y1, x2, y2);
    const colorMap = { 'var(--accent-pink)': '#ff007b', 'var(--accent-teal)': '#00f2ff', 'var(--accent-orange)': '#ff8c00', 'var(--accent-purple)': '#b026ff', 'var(--accent-gold)': '#ffd700', 'var(--accent-blue)': '#3b82f6', 'var(--accent-green)': '#00ff88' };
    g.addColorStop(0, colorMap[c1] || c1); g.addColorStop(1, colorMap[c2] || c2); ctx.strokeStyle = g; ctx.stroke(path); return path;
}

function createGroupBox() {
    const group = {
        id: `group_${Date.now()}`,
        canvasId: currentCanvasId,
        title: "New Group",
        color: getRandomColor(),
        x: (-panX + container.clientWidth/2) / scale - 200,
        y: (-panY + container.clientHeight/2) / scale - 150,
        width: 400,
        height: 300
    };
    flowGroups.push(group);
    renderNodes();
}

function updateGroup(id, field, val) {
    const g = flowGroups.find(x => x.id === id);
    if(g) {
        g[field] = val;
        if(field === 'color') renderNodes();
    }
}

function deleteGroup(id) {
    flowGroups = flowGroups.filter(g => g.id !== id);
    renderNodes();
}

function jumpToNode(id) {
    const n = storyNodes.find(x => x.id === id);
    if(n) {
        const el = document.querySelector(`.story-node[data-id="${n.id}"]`);
        const sW = el ? el.offsetWidth : 240; const sH = el ? el.offsetHeight : 90;
        panX = (container.clientWidth / 2) - ((n.x + sW / 2) * scale);
        panY = (container.clientHeight / 2) - ((n.y + sH / 2) * scale);
        selectedNodeIds = [id]; updateTransform(); renderNodes();
        if(rightTab === 'inspector') renderInspector();
    }
}

function jumpToChainNode(nodeId) {
    const currentTask = storyNodes.find(t => t.id === nodeId);
    if (!currentTask || !currentTask.chainName) return;
    let targetTask = null;
    if (currentTask.taskType !== 'root') targetTask = storyNodes.find(t => t.chainName === currentTask.chainName && t.taskType === 'root' && t.canvasId === currentCanvasId);
    else {
        const chainNodes = storyNodes.filter(t => t.chainName === currentTask.chainName && t.taskType !== 'root' && t.canvasId === currentCanvasId);
        if (chainNodes.length > 0) targetTask = chainNodes[chainNodes.length - 1]; 
    }
    if (targetTask) jumpToNode(targetTask.id);
    else showNotification(currentTask.taskType === 'root' ? "No other nodes exist in this chain." : "Root node not found.", true);
}

function duplicateSelectedNodes() {
    if (selectedNodeIds.length === 0) return;
    const newSelectedIds = [];
    selectedNodeIds.forEach(id => {
        const src = storyNodes.find(n => n.id === id);
        if (src) {
            const newNode = JSON.parse(JSON.stringify(src));
            let prefix = src.type === 'conversation' ? 'conv' : (src.type === 'task' ? 'task' : (src.type === 'sequence' ? 'seq' : (src.type === 'menu' ? 'menu' : 'prmpt')));
            newNode.id = `${prefix}_${String(idCounter++).padStart(4, '0')}`;
            newNode.x += 30; newNode.y += 30; newNode.nextConversations = []; newNode.snapParent = null; newNode.snapChild = null;
            storyNodes.push(newNode); newSelectedIds.push(newNode.id);
        }
    });
    selectedNodeIds = newSelectedIds; renderNodes(); renderInspector(); showNotification(`${newSelectedIds.length} Node(s) Duplicated`);
}

function deleteSelectedNodes() {
    if (selectedNodeIds.length === 0) return;
    storyNodes = storyNodes.filter(n => !selectedNodeIds.includes(n.id));
    storyNodes.forEach(n => { n.nextConversations = n.nextConversations.filter(id => !selectedNodeIds.includes(id)); });
    selectedNodeIds = []; renderNodes(); renderInspector(); updateProjectLogic(); showNotification("Nodes Deleted", true);
}

// Tooling Context & Glow Engines
function getToolGlowState(node) {
    if(!node) return 'none';
    let needsRed = false; let needsBlue = false;
    
    if(!node.isExternallyCalled && node.conditions) {
        for(let c of node.conditions) {
            let stmt = normalizeStatement(c.key, c.op, c.val);
            if(projectLogic[stmt] && !projectLogic[stmt].stateChange) { needsRed = true; break; }
        }
    }
    
    if(!node.makeExternalCall && node.stateChanges) {
        for(let c of node.stateChanges) {
            let stmt = normalizeStatement(c.key, c.op, c.val);
            if(projectLogic[stmt] && !projectLogic[stmt].condition) { needsBlue = true; break; }
        }
    }
    
    if(needsRed && needsBlue) return 'purple';
    if(needsRed) return 'red';
    if(needsBlue) return 'blue';
    return 'none';
}

function getLocalToolLogic() {
    let map = Object.create(null);
    const register = (key, op, val, type, source) => {
        const stmt = normalizeStatement(key, op, val);
        if(!stmt) return;
        if(!map[stmt]) map[stmt] = { condition: false, stateChange: false, sources: new Set(), count: 0 };
        if(type === 'condition') map[stmt].condition = true;
        if(type === 'stateChange') map[stmt].stateChange = true;
        map[stmt].sources.add(source);
        map[stmt].count++;
    };
    toolingData.transitions.forEach(n => {
        const srcStr = `Tool Node: ${n.title}`;
        (n.conditions||[]).forEach(c => register(c.key, c.op, c.val, 'condition', srcStr));
        (n.stateChanges||[]).forEach(c => register(c.key, c.op, c.val, 'stateChange', srcStr));
    });
    toolingData.imageNodes.forEach(n => {
        const srcStr = `Tool Node: ${n.title}`;
        (n.conditions||[]).forEach(c => register(c.key, c.op, c.val, 'condition', srcStr));
        (n.stateChanges||[]).forEach(c => register(c.key, c.op, c.val, 'stateChange', srcStr));
    });
    for(let stmt in map) {
        if(map[stmt].condition && map[stmt].stateChange) map[stmt].usage = 'mixed';
        else if(map[stmt].condition) map[stmt].usage = 'condition';
        else if(map[stmt].stateChange) map[stmt].usage = 'stateChange';
        else map[stmt].usage = 'unknown';
    }
    return map;
}

// Sidebar/Node Menus logic preserved
function showNodeContextMenu(e, id) {
    contextTargetNodeId = id;
    const menu = document.getElementById('node-context-menu');
    menu.style.left = e.clientX + 'px';
    menu.style.top = e.clientY + 'px';
    menu.classList.remove('hidden');
}

function deleteContextNode() {
    if(contextTargetNodeId) {
        if(!selectedNodeIds.includes(contextTargetNodeId)) {
            selectedNodeIds = [contextTargetNodeId];
        }
        deleteSelectedNodes();
        contextTargetNodeId = null;
        closeContextMenus();
    }
}

function showSidebarContextMenu(e, actionData) {
    e.preventDefault(); e.stopPropagation();
    pendingSpawnAction = actionData;
    const menu = document.getElementById('sidebar-context-menu');
    menu.style.left = e.clientX + 'px';
    menu.style.top = e.clientY + 'px';
    menu.classList.remove('hidden');
}

function executeSidebarSpawn() {
    if (!pendingSpawnAction) return;
    const a = pendingSpawnAction;
    let toSpawn = []; let typeStr = '';
    
    if (a.type === 'conversation') { toSpawn = sourceData.dialogues; typeStr = 'conversation'; }
    else if (a.type === 'sequence') { toSpawn = sourceData.sequences; typeStr = 'sequence'; }
    else if (a.type === 'task') { toSpawn = sourceData.tasks.filter(t => (t.tab || 'Uncategorized') === a.tab); typeStr = 'task'; }
    else if (a.type === 'menu') {
        toSpawn = sourceData.menus.filter(m => (m.groupName || 'GLOBAL MENUS') === a.group);
        if (a.char) toSpawn = toSpawn.filter(m => (m.characterName || 'General') === a.char);
        typeStr = 'menu';
    }
    else if (a.type === 'prompt') { toSpawn = sourceData.prompts.filter(p => (p.tag || 'Uncategorized') === a.tag); typeStr = 'prompt'; }
    else if (a.type === 'trans') { toSpawn = toolingData.transitions.filter(t => t.sectionId === a.section); typeStr = 'trans'; }
    else if (a.type === 'imgnode') { toSpawn = toolingData.imageNodes.filter(t => t.sectionId === a.section); typeStr = 'imgnode'; }

    let spawnedItems = [];
    toSpawn.forEach(item => {
        let n = generateNodeData(item, typeStr);
        n.x += spawnOffset; n.y += spawnOffset; spawnOffset += 30;
        storyNodes.push(n); spawnedItems.push(n);
    });

    if (typeStr === 'menu') {
        for (let i = 0; i < spawnedItems.length; i++) {
            if (i % 5 !== 0) { 
                let prev = spawnedItems[i-1]; let curr = spawnedItems[i];
                curr.snapParent = prev.id; prev.snapChild = curr.id;
                curr.x = prev.x; curr.y = prev.y + 70; 
            }
        }
    }

    if (typeStr === 'task') {
        let chains = {};
        spawnedItems.forEach(n => {
            if (n.chainName) {
                if (!chains[n.chainName]) chains[n.chainName] = { root: null, nodes: [], endpoint: null };
                if (n.taskType === 'root') chains[n.chainName].root = n;
                else if (n.taskType === 'endpoint') chains[n.chainName].endpoint = n;
                else chains[n.chainName].nodes.push(n);
            }
        });
        for (let c in chains) {
            let seq = [];
            if (chains[c].root) seq.push(chains[c].root);
            seq.push(...chains[c].nodes);
            if (chains[c].endpoint) seq.push(chains[c].endpoint);
            for (let i = 0; i < seq.length - 1; i++) {
                if (!seq[i].nextConversations.includes(seq[i+1].id)) seq[i].nextConversations.push(seq[i+1].id);
            }
        }
    }

    updateProjectLogic(); showNotification(`Spawned ${spawnedItems.length} Nodes`);
}

// Context Menus
function showToolSectionContext(e, sectionId) {
    e.preventDefault(); e.stopPropagation();
    contextMenuSectionTarget = sectionId;
    const menu = document.getElementById('tool-section-context-menu');
    menu.style.left = e.clientX + 'px';
    menu.style.top = e.clientY + 'px';
    menu.classList.remove('hidden');
}

function duplicateToolSection() {
    if(!contextMenuSectionTarget) return;
    let secArr = activeToolCategory === 'trans' ? toolingData.transitionSections : (activeToolCategory === 'imgnode' ? toolingData.imageNodeSections : toolingData.imageDbSections);
    let itemArr = activeToolCategory === 'trans' ? toolingData.transitions : (activeToolCategory === 'imgnode' ? toolingData.imageNodes : toolingData.imageDbItems);
    
    let sec = secArr.find(s => s.id === contextMenuSectionTarget);
    if(sec) {
        const newId = generateUUID();
        secArr.push({ id: newId, name: sec.name + " (Copy)"});
        itemArr.filter(i => i.sectionId === contextMenuSectionTarget).forEach(item => {
            let copy = JSON.parse(JSON.stringify(item));
            copy.id = generateUUID();
            copy.sectionId = newId;
            itemArr.push(copy);
        });
        renderToolLibrary();
    }
    closeContextMenus();
}

function deleteToolSection() {
    if(!contextMenuSectionTarget) return;
    let secArr = activeToolCategory === 'trans' ? toolingData.transitionSections : (activeToolCategory === 'imgnode' ? toolingData.imageNodeSections : toolingData.imageDbSections);
    let itemArr = activeToolCategory === 'trans' ? toolingData.transitions : (activeToolCategory === 'imgnode' ? toolingData.imageNodes : toolingData.imageDbItems);
    
    let count = itemArr.filter(i => i.sectionId === contextMenuSectionTarget).length;
    if(confirm(`This is irreversible. It will delete this section and ${count} associated tags. Confirm Delete?`)) {
        if(activeToolCategory === 'trans') {
            toolingData.transitionSections = secArr.filter(s => s.id !== contextMenuSectionTarget);
            toolingData.transitions = itemArr.filter(i => i.sectionId !== contextMenuSectionTarget);
        } else if (activeToolCategory === 'imgnode') {
            toolingData.imageNodeSections = secArr.filter(s => s.id !== contextMenuSectionTarget);
            toolingData.imageNodes = itemArr.filter(i => i.sectionId !== contextMenuSectionTarget);
        } else {
            toolingData.imageDbSections = secArr.filter(s => s.id !== contextMenuSectionTarget);
            toolingData.imageDbItems = itemArr.filter(i => i.sectionId !== contextMenuSectionTarget);
        }
        updateProjectLogic();
        renderToolLibrary();
    }
    closeContextMenus();
}