let cast = []; // Global Master Cast: [{name, color}]
let globalTokens = []; // Global Tokens list: [{key, value}]
let globalStates = []; // Global States list: [{name, color}]
let globalMoods = []; // Global Moods list: [{name, color}]
let globalSettings = []; // Global Settings list: [{name, color}]
let globalTimesOfDay = []; // Global Times of Day list: [{name, color}]
let globalDaysOfWeek = []; // Global Days of Week list: [{name, color}]
let globalMenuOptions = []; // Global Menu Options list: [{name, color}]
let globalImageSequences = []; // Global Image Sequences: [{name, color, images: []}]

let conversations = []; // Projects
let sequences = []; // Imported Sequences

let activeIndex = null;
let activeType = 'conversation'; // 'conversation' or 'sequence'
let editingResponseRef = null; // { nIdx, rIdx }

// State tracking for UI elements
let openImageSeqs = new Set(); 
let activeNavIndex = -1; // Tracks current keyboard navigation index
let scrollIndicatorTimeout = null;

// Minimap State Tracking
let editedNodes = new Set();
let lastTraversedIndex = -1;
let currentlyVisibleIndex = -1;

// Inline editing tracking
let editTarget = { type: null, index: null, seqIndex: null, imgIndex: null }; // type: 'cast', 'state', 'mood', 'setting', 'time', 'day', 'menu', 'imageseq', 'image', 'token'
let renamingProject = { type: null, index: null }; // type: 'conversation' or 'sequence'
let currentEditingTag = null; // For the logic tag modal

function getActiveProject() {
    if (activeIndex === null) return null;
    return activeType === 'conversation' ? conversations[activeIndex] : sequences[activeIndex];
}

document.addEventListener('DOMContentLoaded', () => {
    injectSequenceUI();
    renderTokens();
    renderCast();
    renderStates();
    renderMoods();
    renderSettings();
    renderTimesOfDay();
    renderDaysOfWeek();
    renderMenuOptions();
    renderImageSequences();
    renderConversations();
    renderSequences();
    randomizePickerColors();
    setupKeyboardNavigation();
    setupMinimap();
});

// --- DYNAMIC UI INJECTION ---
function injectSequenceUI() {
    // Inject Import Buttons
    const headerActions = document.querySelector('.header-actions');
    if (headerActions) {
        headerActions.insertAdjacentHTML('afterbegin', `
            <button class="btn btn-outline" onclick="openImportImagesModal()">Import Images</button>
            <button class="btn btn-outline" onclick="document.getElementById('import-conv-trigger').click()">Import Conversation</button>
            <input type="file" id="import-conv-trigger" style="display:none" accept=".json" onchange="importConversationJSON(this)">
            <button class="btn btn-outline" onclick="document.getElementById('import-seq-trigger').click()">Import Sequence</button>
            <input type="file" id="import-seq-trigger" style="display:none" accept=".json" onchange="importSequenceJSON(this)">
        `);
    }

    // Label the Title Editors so they are never confused for search bars
    const editConvName = document.getElementById('edit-conv-name');
    if (editConvName && !document.getElementById('title-editor-label')) {
        editConvName.insertAdjacentHTML('beforebegin', '<label id="title-editor-label" style="font-size: 0.65rem; color: var(--accent-teal); text-transform: uppercase; font-weight: 800; letter-spacing: 1px; display: block; margin-bottom: 5px;">Project Title Editor</label>');
    }

    const newConvName = document.getElementById('new-conv-name');
    if (newConvName && !document.getElementById('new-project-label')) {
        newConvName.insertAdjacentHTML('beforebegin', '<label id="new-project-label" style="font-size: 0.65rem; color: var(--text-dim); text-transform: uppercase; font-weight: 800; letter-spacing: 1px; display: block; margin-bottom: 5px;">Create New Project</label>');
    }

    const leftPanel = document.querySelector('.left-panel .sidebar-section');
    if (leftPanel) {
        // Inject Global Tokens at the very top of the Left Panel
        leftPanel.insertAdjacentHTML('afterbegin', `
            <h3>Global Tokens</h3>
            <p style="font-size:10px; opacity:0.4; margin-bottom:12px; text-transform:uppercase; font-weight:bold; letter-spacing:-0.05em;">Use in prompts via {{token}}</p>
            <div style="display:flex; gap:8px; margin-bottom: 15px;">
                <input type="text" id="new-token-key" placeholder="Key (e.g. name)" style="flex:1;">
                <button class="btn btn-teal" style="padding: 0 15px;" onclick="addGlobalToken()">+</button>
            </div>
            <ul id="active-tokens" style="list-style:none; padding:0; margin:0; margin-bottom:30px;"></ul>
            <hr class="cyber-hr">
        `);

        leftPanel.insertAdjacentHTML('beforeend', `
            <hr class="cyber-hr">
            <h3>Image Sequences <span class="count-tag" id="image-seq-count">0</span></h3>
            <div class="input-stack">
                <input type="text" id="custom-image-seq-name" placeholder="Sequence Name...">
                <div class="color-picker-container">
                    <span>Identity Color</span>
                    <input type="color" id="custom-image-seq-color" value="#00f2ff">
                </div>
                <button class="btn btn-teal btn-large" onclick="addNewImageSequence()">Add Image Sequence</button>
            </div>
            <div id="active-image-sequences" style="display:flex; flex-direction:column; gap:8px; margin-top: 15px;"></div>
        `);
    }

    // Inject Active Tags & Sequences List into Right Panel
    const rightPanel = document.querySelector('.right-panel .sidebar-section');
    
    const convList = document.getElementById('conversation-master-list');
    if (convList && !document.getElementById('search-conversations')) {
        convList.setAttribute('ondragover', 'event.preventDefault()');
        convList.setAttribute('ondrop', "handleDrop(event, 'conversation')");
        
        // Inject Conversations Label and Search directly above the list
        convList.insertAdjacentHTML('beforebegin', `
            <h3>Conversations <span class="count-tag" id="conv-item-count">0</span></h3>
            <input type="text" id="search-conversations" class="search-input" placeholder="Search Conversations..." oninput="renderConversations()">
        `);
    }

    if (rightPanel && !document.getElementById('search-sequences')) {
        // Sequences Section
        rightPanel.insertAdjacentHTML('beforeend', `
            <hr class="cyber-hr">
            <h3>Sequences <span class="count-tag" id="sequence-count">0</span></h3>
            <input type="text" id="search-sequences" class="search-input" placeholder="Search Sequences..." oninput="renderSequences()">
            <ul class="conv-list" id="sequence-master-list" ondragover="event.preventDefault()" ondrop="handleDrop(event, 'sequence')"></ul>
        `);

        // Active Tags Section
        rightPanel.insertAdjacentHTML('beforeend', `
            <div id="active-project-tags-section" style="display:none; margin-top: 30px; margin-bottom: 20px;">
                <hr class="cyber-hr" style="margin-bottom: 20px;">
                <h3>Active Project Logic</h3>
                <input type="text" id="search-tags" class="search-input" placeholder="Search Tags..." oninput="renderProjectTags()">
                <div id="project-tags-list" style="display:flex; flex-direction:column; gap:5px;"></div>
            </div>
        `);
    }

    // Inject Statements Search Bar precisely into the Statement Section (above nodes)
    const nodeContainer = document.getElementById('node-container');
    if (nodeContainer && !document.getElementById('statement-search-wrapper')) {
        nodeContainer.insertAdjacentHTML('beforebegin', `
            <div id="statement-search-wrapper" style="margin-bottom: 30px; padding: 15px; background: rgba(0,0,0,0.4); border: 1px dashed var(--accent-orange); border-left: 4px solid var(--accent-orange);">
                <label style="font-size: 0.7rem; color: var(--accent-orange); text-transform: uppercase; font-weight: 800; display: block; margin-bottom: 10px; letter-spacing: 1px;">Statement Database</label>
                <input type="text" id="search-statements" class="search-input" style="margin-bottom: 5px; border-color: var(--accent-orange); background: #000;" placeholder="Search statements by text, speaker, or ID..." oninput="filterStatements()">
                <div style="font-size: 0.55rem; color: var(--text-dim); line-height: 1.4;">
                    <strong>Navigation:</strong> Press ↑/↓ to snap between statements. Hold ↑/↓ to traverse rapidly. Use PgUp/PgDn to skip 10 statements. Press Home/End to jump to the top or bottom.
                </div>
            </div>
        `);
    }

    // Inject Modals & Overlays into Body
    if (!document.getElementById('tag-editor-modal')) {
        document.body.insertAdjacentHTML('beforeend', `
            <!-- Fast Scroll Indicator Overlay -->
            <div id="fast-scroll-indicator" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%, -50%); background:var(--accent-teal); color:#000; font-size:6rem; font-weight:900; padding:40px 80px; border-radius:16px; z-index:10000; pointer-events:none; box-shadow: 0 0 50px var(--accent-teal); text-align:center; min-width: 250px;">
                #1
            </div>

            <!-- Logic Tag Modal -->
            <div id="tag-editor-modal" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.85); z-index:9999; align-items:center; justify-content:center; backdrop-filter: blur(4px);">
               <div style="background:var(--bg-panel); border:1px solid var(--accent-teal); padding:30px; width:600px; max-width:90%; max-height:85vh; display:flex; flex-direction:column; gap:20px; box-shadow: var(--glow-teal);">
                  <div style="display:flex; justify-content:space-between; align-items:center;">
                      <h3 style="margin:0; color:#fff;">Modify Logic Tag</h3>
                      <button class="btn btn-outline" style="padding:4px 8px; font-size:1rem; border:none; color:var(--text-dim);" onclick="closeTagModal()">×</button>
                  </div>
                  <div style="display:flex; gap:10px; align-items: stretch;">
                     <div style="flex:1;">
                        <label style="font-size:0.6rem; color:var(--text-dim); text-transform:uppercase; font-weight:bold;">Key Variable</label>
                        <input type="text" id="tag-edit-var" style="width:100%; margin-top:5px;">
                     </div>
                     <div style="flex:1;">
                        <label style="font-size:0.6rem; color:var(--text-dim); text-transform:uppercase; font-weight:bold;">Value</label>
                        <input type="text" id="tag-edit-val" style="width:100%; margin-top:5px;">
                     </div>
                     <div style="display:flex; align-items:flex-end;">
                        <button class="btn btn-teal" style="height: 41px;" onclick="applyTagChange()">Change Throughout</button>
                     </div>
                  </div>
                  <div>
                    <label style="font-size:0.6rem; color:var(--text-dim); text-transform:uppercase; font-weight:bold;">Tag Dependencies</label>
                    <div id="tag-references-list" class="scrollable" style="margin-top:5px; max-height: 40vh; border:1px solid var(--border-color); background:#0a0a0a; padding:10px; display:flex; flex-direction:column; gap:10px;">
                    </div>
                  </div>
               </div>
            </div>

            <!-- Import Images Modal -->
            <div id="import-images-modal" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.85); z-index:9999; align-items:center; justify-content:center; backdrop-filter: blur(4px);">
               <div style="background:var(--bg-panel); border:1px solid var(--accent-teal); padding:30px; width:400px; max-width:90%; display:flex; flex-direction:column; gap:20px; box-shadow: var(--glow-teal);">
                  <div style="display:flex; justify-content:space-between; align-items:center;">
                      <h3 style="margin:0; color:#fff;">Import Image Sequence</h3>
                      <button class="btn btn-outline" style="padding:4px 8px; font-size:1rem; border:none; color:var(--text-dim);" onclick="closeImportImagesModal()">×</button>
                  </div>
                  <div>
                      <label style="font-size:0.6rem; color:var(--text-dim); text-transform:uppercase; font-weight:bold;">Create New Sequence</label>
                      <input type="text" id="new-image-seq-name" style="width:100%; margin-top:5px; margin-bottom:15px;" placeholder="Sequence Name...">
                      
                      <label style="font-size:0.6rem; color:var(--text-dim); text-transform:uppercase; font-weight:bold;">OR Choose Existing</label>
                      <select id="existing-image-seq-select" class="custom-scrollbar" style="width:100%; margin-top:5px; padding: 8px; font-size: 0.8rem; background: #111; border: 1px solid var(--border-color); color: var(--accent-teal);">
                          <!-- options injected dynamically -->
                      </select>
                  </div>
                  <button class="btn btn-teal" style="width:100%; padding:15px;" onclick="document.getElementById('image-files-trigger').click()">Select Images to Import</button>
                  <input type="file" id="image-files-trigger" style="display:none;" multiple onchange="handleImageFiles(this)">
               </div>
            </div>
        `);
    }

    // Inject CSS for Hover Delete, Renaming, Red Pulsing Text, Search Inputs, Scrollbars and Tokens
    const style = document.createElement('style');
    style.innerHTML = `
        .project-item { position: relative; }
        .project-item .project-delete-btn { display: none; position: absolute; right: 10px; top: 50%; transform: translateY(-50%); color: var(--accent-pink); font-weight: 900; background: rgba(0,0,0,0.85); padding: 6px 12px; border-radius: 4px; z-index: 10; font-size: 0.7rem; border: 1px solid var(--accent-pink); }
        .project-item:hover .project-delete-btn { display: block; }
        .project-item.renaming { background: #000; border-left: 4px solid var(--accent-gold); padding: 10px; }
        .logic-tag-item:hover { background: #1a1a1a !important; }
        
        @keyframes pulseWarningText {
            0% { color: var(--accent-pink); text-shadow: 0 0 5px var(--accent-pink); }
            50% { color: #ff80bf; text-shadow: 0 0 15px var(--accent-pink); }
            100% { color: var(--accent-pink); text-shadow: 0 0 5px var(--accent-pink); }
        }
        .missing-speaker {
            animation: pulseWarningText 1.5s infinite;
            color: var(--accent-pink) !important;
        }

        .search-input {
            width: 100%;
            background: #050505;
            border: 1px solid var(--border-color);
            color: #fff;
            padding: 8px 12px;
            font-size: 0.75rem;
            margin-bottom: 15px;
            border-radius: 2px;
            transition: 0.3s border-color;
        }
        .search-input:focus {
            border-color: var(--accent-teal);
            outline: none;
        }

        /* Custom Scrollbar configurations for Select elements and Textareas */
        select.custom-scrollbar, textarea {
            scrollbar-width: thin;
            scrollbar-color: var(--accent-teal) #0a0a0a;
        }
        select.custom-scrollbar::-webkit-scrollbar, textarea::-webkit-scrollbar { width: 8px; height: 8px; }
        select.custom-scrollbar::-webkit-scrollbar-track, textarea::-webkit-scrollbar-track { background: #0a0a0a; border-left: 1px solid var(--border-color); }
        select.custom-scrollbar::-webkit-scrollbar-thumb, textarea::-webkit-scrollbar-thumb { background: var(--accent-teal); border-radius: 4px; }
        select.custom-scrollbar::-webkit-scrollbar-thumb:hover, textarea::-webkit-scrollbar-thumb:hover { background: #00c3cc; }

        /* Details styling for left panel */
        details > summary {
            list-style: none;
        }
        details > summary::-webkit-details-marker {
            display: none;
        }
        details[open] > summary .seq-arrow {
            transform: rotate(90deg);
        }

        /* Formatting Toolbar */
        .format-toolbar {
            background: #151515;
            border: 1px solid var(--border-color);
            border-bottom: none;
            border-radius: 4px 4px 0 0;
            padding: 6px 12px;
            display: flex;
            gap: 4px;
            align-items: center;
            flex-wrap: wrap;
        }
        .format-btn {
            width: 24px; height: 24px;
            display: inline-flex; align-items: center; justify-content: center;
            background: transparent; border: 1px solid transparent; border-radius: 4px;
            color: var(--text-dim); cursor: pointer; transition: 0.2s; font-size: 0.8rem;
        }
        .format-btn:hover { background: #2a2a2a; color: #fff; }
        .format-btn.active { background: rgba(0, 242, 255, 0.2); color: var(--accent-teal); border-color: var(--accent-teal); }
        .format-btn svg { width: 14px; height: 14px; pointer-events: none; fill: currentColor; }

        /* Token Tag Styling */
        .token-tag {
            background: #00f2ff22;
            border: 1px solid var(--accent-teal);
            color: var(--accent-teal);
            padding: 2px 6px;
            border-radius: 3px;
            font-family: monospace;
            font-size: 0.8rem;
            transition: 0.2s;
        }
        .token-tag:hover {
            background: #00f2ff44;
        }
    `;
    document.head.appendChild(style);
}

// --- GLOBAL TOKENS LOGIC ---
function addGlobalToken() {
    const input = document.getElementById('new-token-key');
    const key = input.value.trim().replace(/[^a-zA-Z0-9_]/g, '');
    
    if (!key) return;
    if (globalTokens.some(t => t.key === key)) {
        showNotification("Token key already exists.", true);
        return;
    }
    
    globalTokens.push({ key, value: "Sample Value" });
    input.value = '';
    renderTokens();
    renderNodes(); // Refresh active UI to see effect in body text if desired
}

function removeToken(idx) {
    globalTokens.splice(idx, 1);
    renderTokens();
    renderNodes();
}

function updateTokenValue(idx, val) {
    globalTokens[idx].value = val;
}

function renderTokens() {
    const list = document.getElementById('active-tokens');
    if (!list) return;
    
    list.innerHTML = globalTokens.map((t, i) => {
        if (editTarget.type === 'token' && editTarget.index === i) {
            return `
                <li style="background: #000; padding: 10px; margin-bottom: 8px; border: 1px solid var(--border-color);">
                    <div style="display:flex; gap:6px; align-items:center;">
                        <span style="color:var(--text-dim);">{{</span>
                        <input type="text" id="edit-token-key-${i}" value="${escapeHtml(t.key)}" style="flex:1; min-width:0; padding:4px; font-size:0.75rem; background:#111; color:#fff; border:1px solid var(--accent-teal);">
                        <span style="color:var(--text-dim);">}}</span>
                        <button class="btn btn-teal" style="padding: 4px 8px;" onclick="saveTokenEdit(${i})">✓</button>
                        <button class="btn btn-outline" style="padding: 4px 8px; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                    </div>
                </li>
            `;
        }
        return `
            <li style="background: #000; padding: 10px; margin-bottom: 8px; border: 1px solid var(--border-color); display:flex; flex-direction:column; gap:6px;">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <span class="token-tag cursor-pointer" ondblclick="startEditing('token', ${i})" title="Double click to edit key">{{${escapeHtml(t.key)}}}</span>
                    <span class="text-pink-500 cursor-pointer" style="font-weight:bold; font-size:1.2rem; line-height:1;" onclick="removeToken(${i})">×</span>
                </div>
                <input type="text" value="${escapeHtml(t.value)}" style="width:100%; padding:6px; font-size:0.75rem; background:rgba(0,0,0,0.5); border:none; outline:none;" onchange="updateTokenValue(${i}, this.value)" placeholder="Token Value...">
            </li>
        `;
    }).join('');
}

function saveTokenEdit(index) {
    const input = document.getElementById(`edit-token-key-${index}`);
    if (!input) return cancelEdit();
    
    const newKey = input.value.trim().replace(/[^a-zA-Z0-9_]/g, '');
    if (!newKey) return cancelEdit();

    if (globalTokens[index].key !== newKey && globalTokens.some(t => t.key === newKey)) {
        showNotification("Token key already exists.", true);
        return cancelEdit();
    }

    const oldKey = globalTokens[index].key;
    if (oldKey !== newKey) {
        propagateTokenRename(oldKey, newKey);
    }

    globalTokens[index].key = newKey;
    cancelEdit();
    renderNodes();
}

function propagateTokenRename(oldKey, newKey) {
    const oldTag = `{{${oldKey}}}`;
    const newTag = `{{${newKey}}}`;
    
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => {
            if (node.text && node.text.includes(oldTag)) {
                node.text = node.text.split(oldTag).join(newTag);
            }
            (node.responses || []).forEach(r => {
                if (r.text && r.text.includes(oldTag)) {
                    r.text = r.text.split(oldTag).join(newTag);
                }
            });
        });
    });
}

// --- TRACKING FOR IDE MINIMAP ---
function markNodeEdited(nIdx) {
    const proj = getActiveProject();
    if (proj && proj.nodes[nIdx]) {
        editedNodes.add(proj.nodes[nIdx].id);
        updateMinimap();
    }
}

function setupMinimap() {
    // Inject minimap overlay physically detached from the scrolling flow
    if (!document.getElementById('minimap-track')) {
        document.body.insertAdjacentHTML('beforeend', `
            <div id="minimap-track" style="position: fixed; right: 330px; top: 90px; bottom: 30px; width: 45px; pointer-events: none; z-index: 150;"></div>
        `);
    }

    const middlePanel = document.querySelector('.middle-panel');
    if (middlePanel) {
        let scrollTimeout;
        middlePanel.addEventListener('scroll', () => {
            if (scrollTimeout) clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(() => {
                currentlyVisibleIndex = getCurrentlyVisibleNodeIndex();
                updateMinimap();
            }, 50);
        });
    }
}

function updateMinimap() {
    const track = document.getElementById('minimap-track');
    if (!track) return;
    
    const scrollable = document.querySelector('.middle-panel');
    if (!scrollable) return;
    
    track.innerHTML = '';
    
    const proj = getActiveProject();
    if (!proj) return;
    
    const scrollHeight = scrollable.scrollHeight;
    if (scrollHeight === 0) return;
    
    let html = '';
    const scrollableRect = scrollable.getBoundingClientRect();
    
    proj.nodes.forEach((node, nIdx) => {
        const el = document.getElementById(`node-${node.id}`);
        if (!el || el.style.display === 'none') return;
        
        const elRect = el.getBoundingClientRect();
        // Calculate dynamic offset completely ignoring the absolute viewport top
        const topOffset = (elRect.top - scrollableRect.top) + scrollable.scrollTop; 
        const topPercent = (topOffset / scrollHeight) * 100;
        
        const isVisible = (nIdx === currentlyVisibleIndex);
        const isTraversed = (nIdx === lastTraversedIndex);
        const isEdited = editedNodes.has(node.id);
        
        if (!isVisible && !isTraversed && !isEdited) return;
        
        let marker = '';
        const baseStyle = "pointer-events: auto; cursor: pointer; font-size:0.55rem; font-weight:900; padding:2px 4px; border-radius:2px; text-align:center; width: 100%; transition: 0.1s;";
        
        // Prioritize visual hierarchy: Visible > Traversed > Edited (Prevents noisy overlapping blobs)
        if (isVisible) {
            marker = `<div onclick="scrollToNode('${node.id}'); event.stopPropagation();" style="${baseStyle} background:#fff; color:#000; box-shadow: 0 0 5px rgba(255,255,255,0.8);" title="Currently Viewing">#${nIdx+1}</div>`;
        } else if (isTraversed) {
            marker = `<div onclick="scrollToNode('${node.id}'); event.stopPropagation();" style="${baseStyle} background:var(--accent-teal); color:#000; box-shadow: 0 0 5px var(--accent-teal);" title="Last Traversed">#${nIdx+1}</div>`;
        } else if (isEdited) {
            marker = `<div onclick="scrollToNode('${node.id}'); event.stopPropagation();" style="${baseStyle} background:var(--accent-orange); color:#000; box-shadow: 0 0 5px var(--accent-orange);" title="Edited">#${nIdx+1}</div>`;
        }
        
        if (marker !== '') {
            html += `<div style="position:absolute; top:${topPercent}%; right:0; transform:translateY(-50%); display:flex; flex-direction:column; gap:2px; align-items:flex-end; width: 35px;">${marker}</div>`;
        }
    });
    
    track.innerHTML = html;
}

// --- KEYBOARD NAVIGATION LOGIC ---
function setupKeyboardNavigation() {
    // Reset active nav index if user manually scrolls so the next arrow press starts from where they are looking
    const middlePanel = document.querySelector('.middle-panel') || window;
    middlePanel.addEventListener('wheel', () => { activeNavIndex = -1; }, { passive: true });
    middlePanel.addEventListener('touchmove', () => { activeNavIndex = -1; }, { passive: true });

    document.addEventListener('keydown', (e) => {
        // Prevent navigation if the user is typing in a text field
        if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName) || e.target.isContentEditable) {
            return;
        }

        const project = getActiveProject();
        if (!project || !project.nodes || project.nodes.length === 0) return;

        const isUp = e.key === 'ArrowUp';
        const isDown = e.key === 'ArrowDown';
        const isPgUp = e.key === 'PageUp';
        const isPgDown = e.key === 'PageDown';
        const isHome = e.key === 'Home';
        const isEnd = e.key === 'End';

        if (isUp || isDown || isPgUp || isPgDown || isHome || isEnd) {
            e.preventDefault(); // Stop default browser page jumping

            // If we don't have a focused index, calculate what statement is closest to the middle of the screen
            if (activeNavIndex === -1) {
                activeNavIndex = getCurrentlyVisibleNodeIndex();
            }

            if (isUp) activeNavIndex = Math.max(0, activeNavIndex - 1);
            if (isDown) activeNavIndex = Math.min(project.nodes.length - 1, activeNavIndex + 1);
            if (isPgUp) activeNavIndex = Math.max(0, activeNavIndex - 10);
            if (isPgDown) activeNavIndex = Math.min(project.nodes.length - 1, activeNavIndex + 10);
            if (isHome) activeNavIndex = 0;
            if (isEnd) activeNavIndex = project.nodes.length - 1;

            const targetNode = project.nodes[activeNavIndex];
            const el = document.getElementById(`node-${targetNode.id}`);
            
            if (el) {
                // Use 'auto' (instant) for rapid traverse/hold down, use 'smooth' for single taps
                const behavior = (e.repeat || isPgUp || isPgDown || isHome || isEnd) ? 'auto' : 'smooth';
                el.scrollIntoView({ behavior: behavior, block: 'center' });
                
                lastTraversedIndex = activeNavIndex;
                updateMinimap();

                // Unconditionally show the fast scroll indicator on every navigation action
                showFastScrollIndicator(activeNavIndex + 1);
            }
        }
    });
}

function getCurrentlyVisibleNodeIndex() {
    const project = getActiveProject();
    if (!project || !project.nodes || project.nodes.length === 0) return 0;
    
    let closestIdx = 0;
    let minDiff = Infinity;
    
    // Evaluate center against the scrollable container window, not the whole body
    const scrollable = document.querySelector('.middle-panel');
    if (!scrollable) return 0;
    const rectScrollable = scrollable.getBoundingClientRect();
    const centerY = rectScrollable.top + (rectScrollable.height / 2);

    project.nodes.forEach((node, idx) => {
        const el = document.getElementById(`node-${node.id}`);
        if (el) {
            const rect = el.getBoundingClientRect();
            const elCenter = rect.top + rect.height / 2;
            const diff = Math.abs(elCenter - centerY);
            if (diff < minDiff) {
                minDiff = diff;
                closestIdx = idx;
            }
        }
    });
    return closestIdx;
}

function showFastScrollIndicator(num) {
    const indicator = document.getElementById('fast-scroll-indicator');
    if (!indicator) return;
    
    indicator.textContent = `#${num}`;
    indicator.style.display = 'block';

    clearTimeout(scrollIndicatorTimeout);
    scrollIndicatorTimeout = setTimeout(() => {
        indicator.style.display = 'none';
    }, 300); // Fade out after key release
}

// --- FORMATTING LOGIC ---
function applyTextFormat(nIdx, tagType, tagParam = '') {
    const project = getActiveProject();
    if (!project || !project.nodes[nIdx]) return;
    const node = project.nodes[nIdx];
    
    if (!node.textFormat) {
        node.textFormat = { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
    }

    const textarea = document.getElementById(`node-text-${nIdx}`);
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = textarea.value.substring(start, end);

    if (selectedText.length > 0) {
        if (['top', 'middle', 'bottom'].includes(tagType)) {
            showNotification("Vertical alignment must be applied globally (select no text).", true);
            return;
        }

        let newText = '';
        let offsetCursor = 0;

        if (tagType === 'align') {
            newText = textarea.value.substring(0, start) + `<align="${tagParam}">` + selectedText + `</align>` + textarea.value.substring(end);
            offsetCursor = 17 + tagParam.length; 
        } else if (tagType === 'bullet') {
            const lines = selectedText.split('\n').map(l => `• ${l}`).join('\n');
            newText = textarea.value.substring(0, start) + lines + textarea.value.substring(end);
            offsetCursor = newText.length - selectedText.length;
        } else if (tagType === 'number') {
            const lines = selectedText.split('\n').map((l, i) => `${i+1}. ${l}`).join('\n');
            newText = textarea.value.substring(0, start) + lines + textarea.value.substring(end);
            offsetCursor = newText.length - selectedText.length;
        } else {
            const tagMap = { 'b': 'b', 'i': 'i', 'u': 'u', 's': 's' };
            const tag = tagMap[tagType] || tagType;
            newText = textarea.value.substring(0, start) + `<${tag}>` + selectedText + `</${tag}>` + textarea.value.substring(end);
            offsetCursor = 5 + (tag.length * 2); 
        }

        textarea.value = newText;
        node.text = newText;
        markNodeEdited(nIdx);

        textarea.focus();
        textarea.setSelectionRange(start, end + offsetCursor);
    } else {
        if (tagType === 'align') {
            node.textFormat.alignH = tagParam;
        } else if (['top', 'middle', 'bottom'].includes(tagType)) {
            node.textFormat.alignV = tagType;
        } else if (tagType === 'bullet') {
            node.textFormat.listStyle = node.textFormat.listStyle === 'bullet' ? 'none' : 'bullet';
        } else if (tagType === 'number') {
            node.textFormat.listStyle = node.textFormat.listStyle === 'number' ? 'none' : 'number';
        } else {
            const keyMap = { 'b': 'bold', 'i': 'italic', 'u': 'underline', 's': 'strikethrough' };
            const key = keyMap[tagType];
            if (key) node.textFormat[key] = !node.textFormat[key];
        }
        markNodeEdited(nIdx);
        renderNodes();
    }
}

// --- IMAGE SEQUENCE LOGIC ---
function addNewImageSequence() {
    const input = document.getElementById('custom-image-seq-name');
    const colorInput = document.getElementById('custom-image-seq-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();

    if (!name || globalImageSequences.some(s => s.name === name)) return;
    globalImageSequences.push({ name, color, images: [] });
    
    if (!sequences.some(s => s.title === name)) {
        sequences.push({
            title: name,
            color: color,
            participants: [],
            nodes: [],
            isRepeatable: false,
            repeatVariable: ''
        });
        renderSequences();
    }
    
    renderImageSequences();
    renderNodes();
    input.value = '';
    randomizePickerColors();
}

function openImportImagesModal() {
    const select = document.getElementById('existing-image-seq-select');
    select.innerHTML = '<option value="">-- Choose Existing --</option>' + 
                       globalImageSequences.map(s => `<option value="${escapeHtml(s.name)}">${escapeHtml(s.name)}</option>`).join('');
    document.getElementById('new-image-seq-name').value = '';
    document.getElementById('import-images-modal').style.display = 'flex';
}

function closeImportImagesModal() {
    document.getElementById('import-images-modal').style.display = 'none';
}

function handleImageFiles(input) {
    const files = input.files;
    if (!files || files.length === 0) return;
    
    const newName = document.getElementById('new-image-seq-name').value.trim();
    const existingName = document.getElementById('existing-image-seq-select').value;
    
    let targetSeqName = newName || existingName;
    if (!targetSeqName) {
        showNotification("Please specify a sequence name.", true);
        input.value = '';
        return;
    }
    
    let seq = globalImageSequences.find(s => s.name === targetSeqName);
    if (!seq) {
        seq = { name: targetSeqName, color: getRandomColor(), images: [] };
        globalImageSequences.push(seq);
        
        if (!sequences.some(s => s.title === targetSeqName)) {
            sequences.push({
                title: targetSeqName,
                color: seq.color,
                participants: [],
                nodes: [],
                isRepeatable: false,
                repeatVariable: ''
            });
            renderSequences();
        }
    }
    
    Array.from(files).forEach(file => {
        const nameWithoutExt = file.name.replace(/\.[^/.]+$/, "");
        if (!seq.images.includes(nameWithoutExt)) {
            seq.images.push(nameWithoutExt);
        }
    });
    
    renderImageSequences();
    renderNodes();
    closeImportImagesModal();
    input.value = '';
    showNotification(`Imported ${files.length} images to ${targetSeqName}`);
}

function toggleImageSeqPanel(name, isOpen) {
    if (isOpen) openImageSeqs.add(name);
    else openImageSeqs.delete(name);
}

function renderImageSequences() {
    const container = document.getElementById('active-image-sequences');
    const countTag = document.getElementById('image-seq-count');
    if (!container) return;
    
    container.innerHTML = globalImageSequences.map((seq, i) => {
        if (editTarget.type === 'imageseq' && editTarget.index === i) {
            return `
                <div style="background:#111; border: 1px solid var(--border-color); border-left: 3px solid ${seq.color || '#fff'}; margin-bottom: 8px;">
                    <div style="padding: 10px; display:flex; gap:6px; align-items:center;">
                        <input type="text" id="edit-imgseq-name-${i}" value="${escapeHtml(seq.name)}" style="flex:1; min-width:0; padding:6px; font-size:0.75rem;">
                        <input type="color" id="edit-imgseq-color-${i}" value="${seq.color || '#00f2ff'}" style="flex-shrink:0; width:28px; height:28px; padding:0; cursor:pointer;">
                        <button class="btn btn-teal" style="padding: 6px;" onclick="saveImageSeqEdit(${i})">✓</button>
                        <button class="btn btn-outline" style="padding: 6px; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                    </div>
                </div>
            `;
        }

        const imagesHtml = seq.images.map((img, j) => {
            if (editTarget.type === 'image' && editTarget.seqIndex === i && editTarget.imgIndex === j) {
                return `
                    <div style="display: flex; justify-content: space-between; font-size: 0.7rem; padding: 6px; background: #000; border: 1px solid var(--accent-teal); gap: 5px;">
                        <input type="text" id="edit-img-name-${i}-${j}" value="${escapeHtml(img)}" style="flex:1; padding:4px;">
                        <button class="btn btn-teal" style="padding: 4px;" onclick="saveImageEdit(${i}, ${j})">✓</button>
                        <button class="btn btn-outline" style="padding: 4px; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                    </div>
                `;
            }
            return `
                <div style="display: flex; justify-content: space-between; font-size: 0.7rem; color: #ccc; padding: 6px; background: #151515; border: 1px solid #222; cursor: pointer;"
                     ondblclick="startEditingImage(${i}, ${j}); event.stopPropagation();" title="Double-click to edit image name">
                    <span>${escapeHtml(img)}</span>
                    <span onclick="deleteImageFromSequence(${i}, ${j}); event.stopPropagation();" style="color: var(--accent-pink); font-weight: bold;">×</span>
                </div>
            `;
        }).join('');

        const isOpen = openImageSeqs.has(seq.name) ? 'open' : '';

        return `
            <details ${isOpen} ontoggle="toggleImageSeqPanel('${escapeHtml(seq.name)}', this.open)" style="background: #111; border: 1px solid var(--border-color); border-left: 3px solid ${seq.color || '#fff'}; margin-bottom: 8px;">
                <summary style="padding: 10px; cursor: pointer; font-size: 0.75rem; font-weight: bold; color: ${seq.color || 'var(--accent-teal)'}; display: flex; justify-content: space-between; align-items:center;"
                         ondblclick="startEditing('imageseq', ${i}); event.preventDefault();" title="Double-click to rename sequence">
                    <span style="display:flex; align-items:center; gap:8px;">
                        <span class="seq-arrow" style="display:inline-block; font-size:0.6rem; transition:0.2s;">▶</span>
                        ${escapeHtml(seq.name)} (${seq.images.length})
                    </span>
                    <span onclick="deleteImageSequence(${i}); event.preventDefault(); event.stopPropagation();" style="color: var(--accent-pink); padding: 0 5px;">×</span>
                </summary>
                <div style="padding: 10px; border-top: 1px solid var(--border-color); background: #0a0a0a; display: flex; flex-direction: column; gap: 5px;">
                    ${imagesHtml}
                </div>
            </details>
        `;
    }).join('');
    if(countTag) countTag.textContent = globalImageSequences.length;
}

function saveImageSeqEdit(index) {
    const newName = document.getElementById(`edit-imgseq-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-imgseq-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalImageSequences[index].name !== newName && globalImageSequences.some(s => s.name === newName)) return cancelEdit();

    const oldName = globalImageSequences[index].name;
    
    globalImageSequences[index].name = newName;
    globalImageSequences[index].color = newColor;

    if (oldName !== newName) {
        if (openImageSeqs.has(oldName)) {
            openImageSeqs.delete(oldName);
            openImageSeqs.add(newName);
        }
        propagateImageSeqRename(oldName, newName);
        const seq = sequences.find(s => s.title === oldName);
        if (seq) {
            seq.title = newName;
            seq.color = newColor;
            if (activeType === 'sequence' && sequences[activeIndex] === seq) {
                document.getElementById('edit-conv-name').value = newName;
                document.getElementById('edit-conv-color').value = newColor;
            }
        }
    } else {
        const seq = sequences.find(s => s.title === oldName);
        if (seq) {
            seq.color = newColor;
            if (activeType === 'sequence' && sequences[activeIndex] === seq) {
                document.getElementById('edit-conv-color').value = newColor;
            }
        }
    }
    
    cancelEdit();
    renderSequences();
    renderImageSequences();
    renderNodes();
}

function startEditingImage(seqIndex, imgIndex) {
    editTarget = { type: 'image', seqIndex, imgIndex };
    renderImageSequences();
}

function saveImageEdit(seqIndex, imgIndex) {
    const newName = document.getElementById(`edit-img-name-${seqIndex}-${imgIndex}`).value.trim();
    if (!newName) return cancelEdit();
    
    const seq = globalImageSequences[seqIndex];
    const oldName = seq.images[imgIndex];
    
    if (oldName !== newName && seq.images.includes(newName)) return cancelEdit();
    
    seq.images[imgIndex] = newName;
    
    if (oldName !== newName) {
        propagateImageRename(seq.name, oldName, newName);
    }
    
    cancelEdit();
    renderImageSequences();
    renderNodes();
}

function deleteImageSequence(idx) {
    if (confirm("Delete this entire Image Sequence?")) {
        const seqName = globalImageSequences[idx].name;
        openImageSeqs.delete(seqName);
        globalImageSequences.splice(idx, 1);
        renderImageSequences();
        renderNodes();
    }
}

function deleteImageFromSequence(seqIdx, imgIdx) {
    globalImageSequences[seqIdx].images.splice(imgIdx, 1);
    renderImageSequences();
    renderNodes();
}

function propagateImageSeqRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => {
            if (node.sequenceName === oldName) node.sequenceName = newName;
        });
    });
}

function propagateImageRename(seqName, oldImgName, newImgName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => {
            if (node.sequenceName === seqName && node.sequenceImage === oldImgName) {
                node.sequenceImage = newImgName;
            }
        });
    });
}

// --- PROJECT TAG LOGIC ENGINE ---
function renderProjectTags() {
    const section = document.getElementById('active-project-tags-section');
    const list = document.getElementById('project-tags-list');
    const searchInput = document.getElementById('search-tags');
    if (!section || !list) return;

    const project = getActiveProject();
    if (!project) {
        section.style.display = 'none';
        return;
    }

    section.style.display = 'block';
    const tags = {};
    const filterTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';

    const addTag = (variable, value, isCond, sourceInfo) => {
        if (!variable || variable.trim() === '') return; 
        const key = variable + '|||' + value;
        if (!tags[key]) {
            tags[key] = { variable, value, isCond: false, isState: false, references: [] };
        }
        if (isCond) tags[key].isCond = true;
        else tags[key].isState = true;
        tags[key].references.push(sourceInfo);
    };

    project.nodes.forEach((node, nIdx) => {
        const preview = `Statement #${nIdx + 1} (${node.speaker || '?'}): ${node.text ? node.text.substring(0, 30) + '...' : 'Empty Statement'}`;
        
        (node.conditions || []).forEach(c => addTag(c.variable, c.value, true, { nodeId: node.id, text: preview, type: 'Node Condition' }));
        (node.gameStateChanges || []).forEach(c => addTag(c.variable, c.value, false, { nodeId: node.id, text: preview, type: 'Node State Change' }));

        (node.responses || []).forEach((r, rIdx) => {
            const rPreview = `Response on Statement #${nIdx + 1} (${r.speaker || '?'}): ${r.text.substring(0, 30)}...`;
            (r.conditions || []).forEach(c => addTag(c.variable, c.value, true, { nodeId: node.id, text: rPreview, type: 'Response Condition' }));
            (r.gameStateChanges || []).forEach(c => addTag(c.variable, c.value, false, { nodeId: node.id, text: rPreview, type: 'Response State Change' }));
        });
    });

    list.innerHTML = Object.values(tags).map(tag => {
        const tagTextMatch = `${tag.variable} ${tag.value}`.toLowerCase();
        if (filterTerm && !tagTextMatch.includes(filterTerm)) return '';

        let color = 'var(--text-dim)';
        if (tag.isCond && !tag.isState) color = 'var(--accent-green)';
        if (!tag.isCond && tag.isState) color = '#00f2ff'; // Cyan/Blue
        if (tag.isCond && tag.isState) color = '#b026ff'; // Purple

        return `
            <div class="logic-tag-item" style="background:#111; border-left: 4px solid ${color}; padding: 8px 12px; cursor: pointer; font-size: 0.75rem; display: flex; justify-content: space-between; align-items:center; transition:0.2s;" 
                 onclick="openTagModal('${escapeHtml(tag.variable)}', '${escapeHtml(tag.value)}')">
                <span style="color:#fff; letter-spacing:0.5px;"><strong>${escapeHtml(tag.variable)}</strong> <span style="color:var(--text-dim); padding:0 4px;">==</span> ${escapeHtml(tag.value)}</span>
                <span style="color: #666; font-weight:bold;">[${tag.references.length}]</span>
            </div>
        `;
    }).join('');
}

function openTagModal(variable, value) {
    currentEditingTag = { variable, value };
    const modal = document.getElementById('tag-editor-modal');
    document.getElementById('tag-edit-var').value = variable;
    document.getElementById('tag-edit-val').value = value;
    
    const project = getActiveProject();
    const refs = [];
    const checkMatch = (c) => c.variable === variable && c.value === value;
    
    project.nodes.forEach((node, nIdx) => {
        const preview = `Statement #${nIdx + 1} (${node.speaker || '?'}): ${node.text ? node.text.substring(0, 30) + '...' : 'Empty Statement'}`;
        
        if ((node.conditions || []).some(checkMatch)) refs.push({ nodeId: node.id, responseId: null, text: preview, type: 'node_condition', displayType: 'NODE CONDITION' });
        if ((node.gameStateChanges || []).some(checkMatch)) refs.push({ nodeId: node.id, responseId: null, text: preview, type: 'node_state', displayType: 'NODE STATE CHANGE' });

        (node.responses || []).forEach((r, rIdx) => {
            const rPreview = `Response on Statement #${nIdx + 1} (${r.speaker || '?'}): ${r.text.substring(0, 30)}...`;
            if ((r.conditions || []).some(checkMatch)) refs.push({ nodeId: node.id, responseId: r.id, text: rPreview, type: 'response_condition', displayType: 'RESPONSE CONDITION' });
            if ((r.gameStateChanges || []).some(checkMatch)) refs.push({ nodeId: node.id, responseId: r.id, text: rPreview, type: 'response_state', displayType: 'RESPONSE STATE CHANGE' });
        });
    });

    const listEl = document.getElementById('tag-references-list');
    listEl.innerHTML = refs.map(ref => `
        <div style="background:#151515; padding:12px; border:1px solid #222; display:flex; justify-content:space-between; align-items:center;">
            <div>
                <div style="font-size:0.6rem; color:var(--accent-gold); text-transform:uppercase; font-weight:bold; letter-spacing:1px; margin-bottom:4px;">${ref.displayType}</div>
                <div style="font-size:0.8rem; color:#fff; font-style:italic;">"${escapeHtml(ref.text)}"</div>
            </div>
            <div style="display:flex; gap:8px;">
                <button class="btn btn-outline" style="padding:6px 12px; font-size:0.65rem; color:var(--accent-teal); border-color:var(--accent-teal);" onclick="jumpFromTagModal('${ref.nodeId}', ${ref.responseId ? `'${ref.responseId}'` : 'null'})">Jump ↳</button>
                <button class="btn btn-outline" style="padding:6px 12px; font-size:0.65rem; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="deleteTagReference('${ref.nodeId}', ${ref.responseId ? `'${ref.responseId}'` : 'null'}, '${ref.type}')">Delete</button>
            </div>
        </div>
    `).join('');

    modal.style.display = 'flex';
}

function closeTagModal() {
    document.getElementById('tag-editor-modal').style.display = 'none';
    currentEditingTag = null;
}

function jumpFromTagModal(nodeId, responseId) {
    closeTagModal();
    if (responseId && responseId !== 'null') {
        const project = getActiveProject();
        const nIdx = project.nodes.findIndex(n => n.id === nodeId);
        if (nIdx !== -1) {
            const rIdx = project.nodes[nIdx].responses.findIndex(r => r.id === responseId);
            if (rIdx !== -1) {
                scrollToElement(`response-item-${nIdx}-${rIdx}`);
                return;
            }
        }
    }
    scrollToNode(nodeId);
}

function deleteTagReference(nodeId, responseId, type) {
    if (!currentEditingTag) return;
    if (!confirm("Are you sure you want to completely remove this logic tag from this specific location?")) return;
    
    const project = getActiveProject();
    if (!project) return;
    
    const node = project.nodes.find(n => n.id === nodeId);
    if (!node) return;
    
    const { variable, value } = currentEditingTag;
    let targetArray = null;
    
    if (type === 'node_condition') targetArray = node.conditions;
    if (type === 'node_state') targetArray = node.gameStateChanges;
    
    if (responseId && responseId !== 'null') {
        const response = node.responses.find(r => r.id === responseId);
        if (response) {
            if (type === 'response_condition') targetArray = response.conditions;
            if (type === 'response_state') targetArray = response.gameStateChanges;
        }
    }
    
    if (targetArray) {
        const idx = targetArray.findIndex(c => c.variable === variable && c.value === value);
        if (idx !== -1) {
            targetArray.splice(idx, 1);
            markNodeEdited(project.nodes.indexOf(node));
            renderNodes(); 
            
            // Check if there are any refs left to keep the modal open
            const stillExists = project.nodes.some(n => 
                (n.conditions || []).some(c => c.variable === variable && c.value === value) ||
                (n.gameStateChanges || []).some(c => c.variable === variable && c.value === value) ||
                (n.responses || []).some(r => 
                    (r.conditions || []).some(c => c.variable === variable && c.value === value) ||
                    (r.gameStateChanges || []).some(c => c.variable === variable && c.value === value)
                )
            );
            
            if (stillExists) {
                openTagModal(variable, value); // Refresh the modal's list to hide the deleted item
            } else {
                closeTagModal();
            }
        }
    }
}

function applyTagChange() {
    const newVar = document.getElementById('tag-edit-var').value.trim();
    const newVal = document.getElementById('tag-edit-val').value.trim();
    
    if (!newVar) {
        showNotification("Variable Key cannot be empty.", true);
        return;
    }

    if (confirm("Are you sure? This will permanently rename all matching conditions and game state variables across this specific project.")) {
        const project = getActiveProject();
        const match = (c) => c.variable === currentEditingTag.variable && c.value === currentEditingTag.value;
        const update = (c, nIdx) => {
            if (match(c)) {
                c.variable = newVar;
                c.value = newVal;
                markNodeEdited(nIdx);
            }
        };

        project.nodes.forEach((node, nIdx) => {
            (node.conditions || []).forEach(c => update(c, nIdx));
            (node.gameStateChanges || []).forEach(c => update(c, nIdx));
            (node.responses || []).forEach(r => {
                (r.conditions || []).forEach(c => update(c, nIdx));
                (r.gameStateChanges || []).forEach(c => update(c, nIdx));
            });
        });

        renderNodes(); // Re-renders the nodes and automatically re-renders the tags
        closeTagModal();
        showNotification("Logic variables updated successfully.");
    }
}


// --- DRAG AND DROP HANDLING ---
function handleDragStart(ev, type, idx) {
    ev.dataTransfer.setData('text/plain', JSON.stringify({ type, index: idx }));
}

function handleDrop(ev, targetType) {
    ev.preventDefault();
    try {
        const data = JSON.parse(ev.dataTransfer.getData('text/plain'));
        if (data.type !== targetType) {
            const sourceList = data.type === 'conversation' ? conversations : sequences;
            const targetList = targetType === 'conversation' ? conversations : sequences;
            
            const item = sourceList.splice(data.index, 1)[0];
            targetList.push(item);
            
            if (activeType === data.type && activeIndex === data.index) {
                activeType = targetType;
                activeIndex = targetList.length - 1;
            } else if (activeType === data.type && activeIndex > data.index) {
                activeIndex--;
            }
            
            renderConversations();
            renderSequences();
        }
    } catch(err) {
        console.error("Drop handling error:", err);
    }
}

// --- RENAME & DELETE PROJECT ---
function startProjectRename(type, idx) {
    renamingProject = { type, index: idx };
    if (type === 'conversation') renderConversations();
    if (type === 'sequence') renderSequences();
}

function cancelProjectRename() {
    const oldType = renamingProject.type;
    renamingProject = { type: null, index: null };
    if (oldType === 'conversation') renderConversations();
    if (oldType === 'sequence') renderSequences();
}

function saveProjectRename(type, idx) {
    const input = document.getElementById(`rename-${type}-${idx}`);
    if (input && input.value.trim()) {
        const targetList = type === 'conversation' ? conversations : sequences;
        const oldName = targetList[idx].title;
        const newName = input.value.trim();
        targetList[idx].title = newName;
        
        if (type === 'sequence' && oldName !== newName) {
            const imgSeq = globalImageSequences.find(s => s.name === oldName);
            if (imgSeq) {
                imgSeq.name = newName;
                propagateImageSeqRename(oldName, newName);
                renderImageSequences();
            }
        }

        if (activeType === type && activeIndex === idx) {
            document.getElementById('edit-conv-name').value = newName;
        }
    }
    cancelProjectRename();
}

function deleteProject(type, idx) {
    if (confirm("Are you sure you want to delete this? This action cannot be undone.")) {
        const targetList = type === 'conversation' ? conversations : sequences;
        targetList.splice(idx, 1);
        
        if (activeType === type && activeIndex === idx) {
            activeIndex = null;
            document.getElementById('active-editor-content').style.display = 'none';
            document.getElementById('editor-placeholder').style.display = 'block';
            document.getElementById('active-project-tags-section').style.display = 'none';
        } else if (activeType === type && activeIndex > idx) {
            activeIndex--;
        }
        
        if (type === 'conversation') renderConversations();
        if (type === 'sequence') renderSequences();
    }
}

// --- PROJECT IMPORT & APPEND LOGIC ---
function handleProjectImport(newProject, targetList, typeStr) {
    let existingIdx = targetList.findIndex(p => p.title === newProject.title);
    if (existingIdx !== -1) {
        if (confirm(`A ${typeStr} named "${newProject.title}" already exists.\n\nClick OK to OVERWRITE.\nClick Cancel to APPEND as a new project.`)) {
            targetList[existingIdx] = newProject;
            return existingIdx;
        } else {
            let copyNum = 1;
            let baseTitle = newProject.title;
            while(targetList.some(p => p.title === `${baseTitle} (${copyNum})`)) {
                copyNum++;
            }
            newProject.title = `${baseTitle} (${copyNum})`;
            targetList.push(newProject);
            return targetList.length - 1;
        }
    } else {
        targetList.push(newProject);
        return targetList.length - 1;
    }
}

function importConversationJSON(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            if (!data.title || !data.nodes) {
                showNotification("Invalid Conversation JSON Format", true);
                return;
            }
            
            normalizeProject(data);
            handleProjectImport(data, conversations, 'conversation');
            renderConversations();
            showNotification("Conversation Imported Successfully");
        } catch (err) {
            console.error(err);
            showNotification("Error parsing Conversation JSON", true);
        }
    };
    reader.readAsText(file);
    input.value = '';
}

function importSequenceJSON(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            let newSeq;

            if (data.title && data.nodes) {
                newSeq = data;
                normalizeProject(newSeq);
            } else if (data.sequenceName && data.elements) {
                newSeq = { 
                    title: data.sequenceName, 
                    color: getRandomColor(),
                    participants: [], 
                    nodes: [],
                    isRepeatable: false,
                    repeatVariable: ''
                };

                let lastMainNodeId = null;
                let currentBranchKey = null;
                let lastBranchNodeId = null;

                data.elements.forEach((el) => {
                    const nodeId = crypto.randomUUID();
                    const node = {
                        id: nodeId,
                        conditions: [],
                        speaker: '',
                        advancedOpen: false,
                        resourcePath: 'Assets/Resources/Slides/' + el.imageName,
                        usePath: false,
                        closeMainMenu: false,
                        closeDialogueMenu: false,
                        openPromptPanel: false,
                        closePromptPanel: false,
                        changeTimeOfDay: false,
                        timeOfDayChanges: [{ time: '', value: '' }],
                        changeDayOfWeek: false,
                        dayOfWeekChanges: [{ day: '', value: '' }],
                        changeMenuOption: false,
                        menuOptionChanges: [{ menu: '', value: '' }],
                        gameStateChanges: [], 
                        changeSetting: false,
                        settingChanges: [{ setting: '', value: '' }],
                        controlSequence: false,
                        sequenceName: '',
                        sequenceImage: '',
                        controlPuppets: false,         
                        puppetUsePath: false,          
                        puppetUseTag: false,          
                        changePuppetState: false,
                        changePuppetMood: false,
                        changePuppetInvert: false,
                        puppets: [],
                        canPlayerRespond: false,
                        externalCall: false,
                        responses: [],
                        parentResponseId: null,
                        parentResponsePreview: null,
                        textFormat: { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' }
                    };

                    // Track and construct the branch logic based on keys and values
                    if (el.optionalBranch && el.optionKey) {
                        node.conditions.push({ 
                            variable: el.optionKey, 
                            operator: '==', 
                            value: el.optionValue.toString() 
                        });

                        // If it's the start of a branch, break the chain and make a fresh statement
                        if (el.optionValue == 1 || currentBranchKey !== el.optionKey) {
                            currentBranchKey = el.optionKey;
                            lastBranchNodeId = nodeId;
                        } else {
                            // If it's a continuing branch, chain it to the last node IN THIS SPECIFIC BRANCH
                            if (lastBranchNodeId) {
                                const lastNode = newSeq.nodes.find(n => n.id === lastBranchNodeId);
                                if (lastNode) {
                                    const respId = crypto.randomUUID();
                                    lastNode.responses.push({ 
                                        id: respId, 
                                        speaker: '', 
                                        text: 'Continue...', 
                                        nextStatementId: nodeId,
                                        conditions: [],
                                        gameStateChanges: [],
                                        autoIncrement: false
                                    });
                                    lastNode.canPlayerRespond = true;
                                }
                            }
                            lastBranchNodeId = nodeId;
                        }
                    } else {
                        // It's the main linear trunk
                        currentBranchKey = null; // Clear branch tracker
                        if (lastMainNodeId) {
                            const lastNode = newSeq.nodes.find(n => n.id === lastMainNodeId);
                            if (lastNode) {
                                const respId = crypto.randomUUID();
                                lastNode.responses.push({ 
                                    id: respId, 
                                    speaker: '', 
                                    text: 'Continue...', 
                                    nextStatementId: nodeId,
                                    conditions: [],
                                    gameStateChanges: [],
                                    autoIncrement: false
                                });
                                lastNode.canPlayerRespond = true;
                            }
                        }
                        lastMainNodeId = nodeId;
                    }

                    newSeq.nodes.push(node);
                });
            } else {
                showNotification("Invalid Sequence JSON Format", true);
                return;
            }

            handleProjectImport(newSeq, sequences, 'sequence');
            
            if (!globalImageSequences.some(s => s.name === newSeq.title)) {
                globalImageSequences.push({ name: newSeq.title, color: newSeq.color || getRandomColor(), images: [] });
                renderImageSequences();
            }

            renderSequences();
            showNotification("Sequence Imported Successfully");
        } catch (err) {
            console.error(err);
            showNotification("Error parsing Sequence JSON", true);
        }
    };
    reader.readAsText(file);
    input.value = '';
}

// --- NAVIGATION HELPERS ---
function findNodeIdByResponseId(respId) {
    const project = getActiveProject();
    if (!project) return null;
    for (let n of project.nodes) {
        if (n.responses.some(r => r.id === respId)) return n.id;
    }
    return null;
}

function scrollToNode(nodeId) {
    if (!nodeId) return;
    const el = document.getElementById(`node-${nodeId}`);
    if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        const oldBorder = el.style.borderColor;
        const oldBoxShadow = el.style.boxShadow;
        el.style.borderColor = 'var(--accent-orange)';
        el.style.boxShadow = '0 0 20px var(--accent-orange)';
        setTimeout(() => {
            el.style.borderColor = oldBorder;
            el.style.boxShadow = oldBoxShadow;
        }, 1000);
    }
}

function scrollToElement(elId) {
    const el = document.getElementById(elId);
    if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        const oldOutline = el.style.outline;
        const oldBoxShadow = el.style.boxShadow;
        el.style.outline = '2px solid var(--accent-orange)';
        el.style.boxShadow = '0 0 20px var(--accent-orange)';
        setTimeout(() => {
            el.style.outline = oldOutline;
            el.style.boxShadow = oldBoxShadow;
        }, 1500);
    }
}

function filterStatements() {
    const input = document.getElementById('search-statements');
    if (!input) return;
    const term = input.value.toLowerCase().trim();
    const project = getActiveProject();
    if (!project) return;
    
    project.nodes.forEach((node, nIdx) => {
        const el = document.getElementById(`node-${node.id}`);
        if (!el) return;
        
        if (!term) {
            el.style.display = ''; // Reset
            return;
        }
        
        const searchStr = `${node.speaker || ''} ${node.text || ''} ${node.id}`.toLowerCase();
        let isMatch = searchStr.includes(term);
        
        if (!isMatch && node.responses) {
            isMatch = node.responses.some(r => `${r.speaker || ''} ${r.text || ''}`.toLowerCase().includes(term));
        }
        
        el.style.display = isMatch ? '' : 'none';
    });
    
    updateMinimap();
}

// --- HELPER: RANDOM COLOR ---
function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

function randomizePickerColors() {
    const pickers = [
        'custom-participant-color', 'custom-state-color', 'custom-mood-color', 'custom-setting-color', 
        'custom-time-color', 'custom-day-color', 'custom-menu-color', 'custom-image-seq-color'
    ];
    pickers.forEach(id => {
        const p = document.getElementById(id);
        if (p) p.value = getRandomColor();
    });
}

// --- GLOBAL LISTS (LEFT PANEL) ---
function addNewCustomParticipant() {
    const nameInput = document.getElementById('custom-participant-name');
    const colorInput = document.getElementById('custom-participant-color');
    const name = nameInput.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();

    if (!name || cast.some(c => c.name === name)) return;

    cast.push({ name, color });
    renderCast();
    updateLocalAddDropdown();
    
    nameInput.value = '';
    randomizePickerColors();
}

function renderCast() {
    const list = document.getElementById('active-participants');
    if (!list) return;
    list.innerHTML = cast.map((c, i) => {
        if (editTarget.type === 'cast' && editTarget.index === i) {
            return `
                <li style="border-left-color: ${c.color}; display:flex; gap:6px; align-items:center; padding: 12px 8px; overflow: hidden;">
                    <input type="text" id="edit-cast-name-${i}" value="${escapeHtml(c.name)}" style="flex:1; min-width:0; padding:6px; font-size:0.75rem;">
                    <input type="color" id="edit-cast-color-${i}" value="${c.color}" style="flex-shrink:0; width:28px; height:28px; padding:0; border:1px solid #333; cursor:pointer;">
                    <button class="btn btn-teal" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1;" onclick="saveCastEdit(${i})">✓</button>
                    <button class="btn btn-outline" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                </li>
            `;
        }
        return `
            <li style="border-left-color: ${c.color}" ondblclick="startEditing('cast', ${i})" title="Double-click to edit">
                <span>${escapeHtml(c.name)}</span>
                <span style="color:var(--accent-pink); cursor:pointer" onclick="removeGlobalChar(${i}); event.stopPropagation();">×</span>
            </li>
        `;
    }).join('');
    const countTag = document.getElementById('cast-count');
    if (countTag) countTag.textContent = cast.length;
}

function removeGlobalChar(index) {
    cast.splice(index, 1);
    renderCast();
    updateLocalAddDropdown();
}

// Global States
function addNewState() {
    const input = document.getElementById('custom-state-name');
    const colorInput = document.getElementById('custom-state-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();

    if (!name || globalStates.some(s => s.name === name)) return;
    globalStates.push({ name, color });
    renderStates();
    renderNodes(); 
    input.value = '';
    randomizePickerColors();
}

function renderStates() {
    const list = document.getElementById('active-states');
    if (!list) return;
    list.innerHTML = globalStates.map((s, i) => {
        if (editTarget.type === 'state' && editTarget.index === i) {
            return `
                <li style="border-left-color: ${s.color}; display:flex; gap:6px; align-items:center; padding: 12px 8px; overflow: hidden;">
                    <input type="text" id="edit-state-name-${i}" value="${escapeHtml(s.name)}" style="flex:1; min-width:0; padding:6px; font-size:0.75rem;">
                    <input type="color" id="edit-state-color-${i}" value="${s.color}" style="flex-shrink:0; width:28px; height:28px; padding:0; border:1px solid #333; cursor:pointer;">
                    <button class="btn btn-teal" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1;" onclick="saveStateEdit(${i})">✓</button>
                    <button class="btn btn-outline" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                </li>
            `;
        }
        return `
            <li style="border-left-color: ${s.color}" ondblclick="startEditing('state', ${i})" title="Double-click to edit">
                <span>${escapeHtml(s.name)}</span>
                <span style="color:var(--accent-pink); cursor:pointer" onclick="removeGlobalState(${i}); event.stopPropagation();">×</span>
            </li>
        `;
    }).join('');
    const countTag = document.getElementById('state-count');
    if (countTag) countTag.textContent = globalStates.length;
}

function removeGlobalState(index) {
    globalStates.splice(index, 1);
    renderStates();
    renderNodes();
}

// Global Moods
function addNewMood() {
    const input = document.getElementById('custom-mood-name');
    const colorInput = document.getElementById('custom-mood-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();

    if (!name || globalMoods.some(m => m.name === name)) return;
    globalMoods.push({ name, color });
    renderMoods();
    renderNodes();
    input.value = '';
    randomizePickerColors();
}

function renderMoods() {
    const list = document.getElementById('active-moods');
    if (!list) return;
    list.innerHTML = globalMoods.map((m, i) => {
        if (editTarget.type === 'mood' && editTarget.index === i) {
            return `
                <li style="border-left-color: ${m.color}; display:flex; gap:6px; align-items:center; padding: 12px 8px; overflow: hidden;">
                    <input type="text" id="edit-mood-name-${i}" value="${escapeHtml(m.name)}" style="flex:1; min-width:0; padding:6px; font-size:0.75rem;">
                    <input type="color" id="edit-mood-color-${i}" value="${m.color}" style="flex-shrink:0; width:28px; height:28px; padding:0; border:1px solid #333; cursor:pointer;">
                    <button class="btn btn-teal" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1;" onclick="saveMoodEdit(${i})">✓</button>
                    <button class="btn btn-outline" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                </li>
            `;
        }
        return `
            <li style="border-left-color: ${m.color}" ondblclick="startEditing('mood', ${i})" title="Double-click to edit">
                <span>${escapeHtml(m.name)}</span>
                <span style="color:var(--accent-pink); cursor:pointer" onclick="removeGlobalMood(${i}); event.stopPropagation();">×</span>
            </li>
        `;
    }).join('');
    const countTag = document.getElementById('mood-count');
    if (countTag) countTag.textContent = globalMoods.length;
}

function removeGlobalMood(index) {
    globalMoods.splice(index, 1);
    renderMoods();
    renderNodes();
}

// Global Settings
function addNewSetting() {
    const input = document.getElementById('custom-setting-name');
    const colorInput = document.getElementById('custom-setting-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();

    if (!name || globalSettings.some(s => s.name === name)) return;
    globalSettings.push({ name, color });
    renderSettings();
    renderNodes();
    input.value = '';
    randomizePickerColors();
}

function renderSettings() {
    const list = document.getElementById('active-settings');
    if (!list) return;
    list.innerHTML = globalSettings.map((s, i) => {
        if (editTarget.type === 'setting' && editTarget.index === i) {
            return `
                <li style="border-left-color: ${s.color}; display:flex; gap:6px; align-items:center; padding: 12px 8px; overflow: hidden;">
                    <input type="text" id="edit-setting-name-${i}" value="${escapeHtml(s.name)}" style="flex:1; min-width:0; padding:6px; font-size:0.75rem;">
                    <input type="color" id="edit-setting-color-${i}" value="${s.color}" style="flex-shrink:0; width:28px; height:28px; padding:0; border:1px solid #333; cursor:pointer;">
                    <button class="btn btn-teal" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1;" onclick="saveSettingEdit(${i})">✓</button>
                    <button class="btn btn-outline" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                </li>
            `;
        }
        return `
            <li style="border-left-color: ${s.color}" ondblclick="startEditing('setting', ${i})" title="Double-click to edit">
                <span>${escapeHtml(s.name)}</span>
                <span style="color:var(--accent-pink); cursor:pointer" onclick="removeGlobalSetting(${i}); event.stopPropagation();">×</span>
            </li>
        `;
    }).join('');
    const countTag = document.getElementById('setting-count');
    if (countTag) countTag.textContent = globalSettings.length;
}

function removeGlobalSetting(index) {
    globalSettings.splice(index, 1);
    renderSettings();
    renderNodes();
}

// Global Times Of Day
function addNewTimeOfDay() {
    const input = document.getElementById('custom-time-name');
    const colorInput = document.getElementById('custom-time-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();

    if (!name || globalTimesOfDay.some(s => s.name === name)) return;
    globalTimesOfDay.push({ name, color });
    renderTimesOfDay();
    renderNodes();
    input.value = '';
    randomizePickerColors();
}

function renderTimesOfDay() {
    const list = document.getElementById('active-times');
    if (!list) return;
    list.innerHTML = globalTimesOfDay.map((s, i) => {
        if (editTarget.type === 'time' && editTarget.index === i) {
            return `
                <li style="border-left-color: ${s.color}; display:flex; gap:6px; align-items:center; padding: 12px 8px; overflow: hidden;">
                    <input type="text" id="edit-time-name-${i}" value="${escapeHtml(s.name)}" style="flex:1; min-width:0; padding:6px; font-size:0.75rem;">
                    <input type="color" id="edit-time-color-${i}" value="${s.color}" style="flex-shrink:0; width:28px; height:28px; padding:0; border:1px solid #333; cursor:pointer;">
                    <button class="btn btn-teal" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1;" onclick="saveTimeOfDayEdit(${i})">✓</button>
                    <button class="btn btn-outline" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                </li>
            `;
        }
        return `
            <li style="border-left-color: ${s.color}" ondblclick="startEditing('time', ${i})" title="Double-click to edit">
                <span>${escapeHtml(s.name)}</span>
                <span style="color:var(--accent-pink); cursor:pointer" onclick="removeGlobalTimeOfDay(${i}); event.stopPropagation();">×</span>
            </li>
        `;
    }).join('');
    const countTag = document.getElementById('time-count');
    if (countTag) countTag.textContent = globalTimesOfDay.length;
}

function removeGlobalTimeOfDay(index) {
    globalTimesOfDay.splice(index, 1);
    renderTimesOfDay();
    renderNodes();
}

// Global Days of Week
function addNewDayOfWeek() {
    const input = document.getElementById('custom-day-name');
    const colorInput = document.getElementById('custom-day-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();

    if (!name || globalDaysOfWeek.some(s => s.name === name)) return;
    globalDaysOfWeek.push({ name, color });
    renderDaysOfWeek();
    renderNodes();
    input.value = '';
    randomizePickerColors();
}

function renderDaysOfWeek() {
    const list = document.getElementById('active-days');
    if (!list) return;
    list.innerHTML = globalDaysOfWeek.map((s, i) => {
        if (editTarget.type === 'day' && editTarget.index === i) {
            return `
                <li style="border-left-color: ${s.color}; display:flex; gap:6px; align-items:center; padding: 12px 8px; overflow: hidden;">
                    <input type="text" id="edit-day-name-${i}" value="${escapeHtml(s.name)}" style="flex:1; min-width:0; padding:6px; font-size:0.75rem;">
                    <input type="color" id="edit-day-color-${i}" value="${s.color}" style="flex-shrink:0; width:28px; height:28px; padding:0; border:1px solid #333; cursor:pointer;">
                    <button class="btn btn-teal" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1;" onclick="saveDayOfWeekEdit(${i})">✓</button>
                    <button class="btn btn-outline" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                </li>
            `;
        }
        return `
            <li style="border-left-color: ${s.color}" ondblclick="startEditing('day', ${i})" title="Double-click to edit">
                <span>${escapeHtml(s.name)}</span>
                <span style="color:var(--accent-pink); cursor:pointer" onclick="removeGlobalDayOfWeek(${i}); event.stopPropagation();">×</span>
            </li>
        `;
    }).join('');
    const countTag = document.getElementById('day-count');
    if (countTag) countTag.textContent = globalDaysOfWeek.length;
}

function removeGlobalDayOfWeek(index) {
    globalDaysOfWeek.splice(index, 1);
    renderDaysOfWeek();
    renderNodes();
}

// Global Menu Options
function addNewMenuOption() {
    const input = document.getElementById('custom-menu-name');
    const colorInput = document.getElementById('custom-menu-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : getRandomColor();

    if (!name || globalMenuOptions.some(s => s.name === name)) return;
    globalMenuOptions.push({ name, color });
    renderMenuOptions();
    renderNodes();
    input.value = '';
    randomizePickerColors();
}

function renderMenuOptions() {
    const list = document.getElementById('active-menus');
    if (!list) return;
    list.innerHTML = globalMenuOptions.map((s, i) => {
        if (editTarget.type === 'menu' && editTarget.index === i) {
            return `
                <li style="border-left-color: ${s.color}; display:flex; gap:6px; align-items:center; padding: 12px 8px; overflow: hidden;">
                    <input type="text" id="edit-menu-name-${i}" value="${escapeHtml(s.name)}" style="flex:1; min-width:0; padding:6px; font-size:0.75rem;">
                    <input type="color" id="edit-menu-color-${i}" value="${s.color}" style="flex-shrink:0; width:28px; height:28px; padding:0; border:1px solid #333; cursor:pointer;">
                    <button class="btn btn-teal" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1;" onclick="saveMenuOptionEdit(${i})">✓</button>
                    <button class="btn btn-outline" style="flex-shrink:0; padding: 6px; font-size: 0.7rem; line-height:1; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelEdit()">×</button>
                </li>
            `;
        }
        return `
            <li style="border-left-color: ${s.color}" ondblclick="startEditing('menu', ${i})" title="Double-click to edit">
                <span>${escapeHtml(s.name)}</span>
                <span style="color:var(--accent-pink); cursor:pointer" onclick="removeGlobalMenuOption(${i}); event.stopPropagation();">×</span>
            </li>
        `;
    }).join('');
    const countTag = document.getElementById('menu-count');
    if (countTag) countTag.textContent = globalMenuOptions.length;
}

function removeGlobalMenuOption(index) {
    globalMenuOptions.splice(index, 1);
    renderMenuOptions();
    renderNodes();
}


// --- INLINE EDITING LOGIC & PROPAGATION ---
function startEditing(type, index) {
    editTarget = { type, index, seqIndex: null, imgIndex: null };
    if (type === 'cast') renderCast();
    if (type === 'state') renderStates();
    if (type === 'mood') renderMoods();
    if (type === 'setting') renderSettings();
    if (type === 'time') renderTimesOfDay();
    if (type === 'day') renderDaysOfWeek();
    if (type === 'menu') renderMenuOptions();
    if (type === 'imageseq') renderImageSequences();
    if (type === 'token') renderTokens();
}

function cancelEdit() {
    editTarget = { type: null, index: null, seqIndex: null, imgIndex: null };
    renderCast();
    renderStates();
    renderMoods();
    renderSettings();
    renderTimesOfDay();
    renderDaysOfWeek();
    renderMenuOptions();
    renderImageSequences();
    renderTokens();
}

function saveCastEdit(index) {
    const newName = document.getElementById(`edit-cast-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-cast-color-${index}`).value;
    if (!newName) return cancelEdit();
    
    // Check for duplicates
    if (cast[index].name !== newName && cast.some(c => c.name === newName)) return cancelEdit();

    const oldName = cast[index].name;
    if (oldName !== newName) propagateCastRename(oldName, newName);
    
    cast[index].name = newName;
    cast[index].color = newColor;
    
    cancelEdit();
    renderLocalCast();
    updateLocalAddDropdown();
    renderNodes();
    renderConversations();
    renderSequences();
}

function saveStateEdit(index) {
    const newName = document.getElementById(`edit-state-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-state-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalStates[index].name !== newName && globalStates.some(s => s.name === newName)) return cancelEdit();

    const oldName = globalStates[index].name;
    if (oldName !== newName) propagateStateRename(oldName, newName);
    
    globalStates[index].name = newName;
    globalStates[index].color = newColor;
    cancelEdit();
    renderNodes();
}

function saveMoodEdit(index) {
    const newName = document.getElementById(`edit-mood-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-mood-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalMoods[index].name !== newName && globalMoods.some(m => m.name === newName)) return cancelEdit();

    const oldName = globalMoods[index].name;
    if (oldName !== newName) propagateMoodRename(oldName, newName);
    
    globalMoods[index].name = newName;
    globalMoods[index].color = newColor;
    cancelEdit();
    renderNodes();
}

function saveSettingEdit(index) {
    const newName = document.getElementById(`edit-setting-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-setting-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalSettings[index].name !== newName && globalSettings.some(s => s.name === newName)) return cancelEdit();

    const oldName = globalSettings[index].name;
    if (oldName !== newName) propagateSettingRename(oldName, newName);
    
    globalSettings[index].name = newName;
    globalSettings[index].color = newColor;
    cancelEdit();
    renderNodes();
}

function saveTimeOfDayEdit(index) {
    const newName = document.getElementById(`edit-time-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-time-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalTimesOfDay[index].name !== newName && globalTimesOfDay.some(s => s.name === newName)) return cancelEdit();

    const oldName = globalTimesOfDay[index].name;
    if (oldName !== newName) propagateTimeOfDayRename(oldName, newName);
    
    globalTimesOfDay[index].name = newName;
    globalTimesOfDay[index].color = newColor;
    cancelEdit();
    renderNodes();
}

function saveDayOfWeekEdit(index) {
    const newName = document.getElementById(`edit-day-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-day-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalDaysOfWeek[index].name !== newName && globalDaysOfWeek.some(s => s.name === newName)) return cancelEdit();

    const oldName = globalDaysOfWeek[index].name;
    if (oldName !== newName) propagateDayOfWeekRename(oldName, newName);
    
    globalDaysOfWeek[index].name = newName;
    globalDaysOfWeek[index].color = newColor;
    cancelEdit();
    renderNodes();
}

function saveMenuOptionEdit(index) {
    const newName = document.getElementById(`edit-menu-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-menu-color-${index}`).value;
    if (!newName) return cancelEdit();
    if (globalMenuOptions[index].name !== newName && globalMenuOptions.some(s => s.name === newName)) return cancelEdit();

    const oldName = globalMenuOptions[index].name;
    if (oldName !== newName) propagateMenuOptionRename(oldName, newName);
    
    globalMenuOptions[index].name = newName;
    globalMenuOptions[index].color = newColor;
    cancelEdit();
    renderNodes();
}

function propagateCastRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        const pIdx = proj.participants.indexOf(oldName);
        if (pIdx !== -1) proj.participants[pIdx] = newName;
        
        proj.nodes.forEach(node => {
            if (node.speaker === oldName) node.speaker = newName;
            node.responses.forEach(r => {
                if (r.speaker === oldName) r.speaker = newName;
            });
            node.puppets.forEach(p => {
                if (p.name === oldName) p.name = newName;
            });
        });
    });
}

function propagateStateRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => {
            node.puppets.forEach(p => {
                if (p.state === oldName) p.state = newName;
            });
        });
    });
}

function propagateMoodRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => {
            node.puppets.forEach(p => {
                if (p.mood === oldName) p.mood = newName;
            });
        });
    });
}

function propagateSettingRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => {
            (node.settingChanges || []).forEach(change => {
                if (change.setting === oldName) change.setting = newName;
            });
        });
    });
}

function propagateTimeOfDayRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => {
            (node.timeOfDayChanges || []).forEach(change => {
                if (change.time === oldName) change.time = newName;
            });
        });
    });
}

function propagateDayOfWeekRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => {
            (node.dayOfWeekChanges || []).forEach(change => {
                if (change.day === oldName) change.day = newName;
            });
        });
    });
}

function propagateMenuOptionRename(oldName, newName) {
    [...conversations, ...sequences].forEach(proj => {
        proj.nodes.forEach(node => {
            (node.menuOptionChanges || []).forEach(change => {
                if (change.menu === oldName) change.menu = newName;
            });
        });
    });
}

// --- CONVERSATION AUTHORING ---
function createNewConversation() {
    const title = document.getElementById('new-conv-name').value.trim();
    if (!title) return;
    
    conversations.push({ 
        title, 
        color: getRandomColor(),
        participants: [], 
        nodes: [],
        isRepeatable: false,
        repeatVariable: ''
    });
    renderConversations();
    openEditor(conversations.length - 1, 'conversation');
    document.getElementById('new-conv-name').value = '';
}

function renderConversations() {
    const list = document.getElementById('conversation-master-list');
    const searchInput = document.getElementById('search-conversations');
    if (!list) return;

    const filterTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';
    
    list.innerHTML = conversations.map((c, i) => {
        if (filterTerm && !c.title.toLowerCase().includes(filterTerm)) return '';

        if (renamingProject.type === 'conversation' && renamingProject.index === i) {
            return `
            <li class="project-item renaming">
                <div style="display:flex; gap:5px;">
                    <input type="text" id="rename-conversation-${i}" value="${escapeHtml(c.title)}" style="flex:1; font-size:0.8rem; padding:4px; background:#111; color:#fff; border:1px solid var(--accent-teal);">
                    <button class="btn btn-teal" style="padding:4px 8px;" onclick="saveProjectRename('conversation', ${i}); event.stopPropagation();">✓</button>
                    <button class="btn btn-outline" style="padding:4px 8px; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelProjectRename(); event.stopPropagation();">×</button>
                </div>
            </li>`;
        }

        return `
        <li class="project-item ${i === activeIndex && activeType === 'conversation' ? 'active' : ''}" 
            style="border-left: 4px solid ${c.color || 'transparent'}; background: ${i === activeIndex && activeType === 'conversation' ? '#000' : '#151515'}; cursor: pointer;" 
            onclick="openEditor(${i}, 'conversation')"
            ondblclick="startProjectRename('conversation', ${i}); event.stopPropagation();"
            draggable="true" ondragstart="handleDragStart(event, 'conversation', ${i})">
            <strong>${escapeHtml(c.title)}</strong>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-top:5px;">
                <span class="conv-cast-preview">Cast: ${escapeHtml(c.participants.join(', ') || 'None')}</span>
                ${c.isRepeatable ? '<span style="color:var(--accent-green); font-size:0.6rem; font-weight:800; letter-spacing:1px;">REPEATABLE</span>' : ''}
            </div>
            <span class="project-delete-btn" onclick="deleteProject('conversation', ${i}); event.stopPropagation();">DELETE</span>
        </li>
        `;
    }).join('');
    const countTag = document.getElementById('conv-item-count');
    if (countTag) countTag.textContent = conversations.length;
}

function renderSequences() {
    const list = document.getElementById('sequence-master-list');
    const searchInput = document.getElementById('search-sequences');
    if (!list) return;

    const filterTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';
    
    list.innerHTML = sequences.map((s, i) => {
        if (filterTerm && !s.title.toLowerCase().includes(filterTerm)) return '';

        if (renamingProject.type === 'sequence' && renamingProject.index === i) {
            return `
            <li class="project-item renaming">
                <div style="display:flex; gap:5px;">
                    <input type="text" id="rename-sequence-${i}" value="${escapeHtml(s.title)}" style="flex:1; font-size:0.8rem; padding:4px; background:#111; color:#fff; border:1px solid var(--accent-teal);">
                    <button class="btn btn-teal" style="padding:4px 8px;" onclick="saveProjectRename('sequence', ${i}); event.stopPropagation();">✓</button>
                    <button class="btn btn-outline" style="padding:4px 8px; color:var(--accent-pink); border-color:var(--accent-pink);" onclick="cancelProjectRename(); event.stopPropagation();">×</button>
                </div>
            </li>`;
        }

        return `
        <li class="project-item ${i === activeIndex && activeType === 'sequence' ? 'active' : ''}" 
            style="border-left: 4px solid ${s.color || 'transparent'}; background: ${i === activeIndex && activeType === 'sequence' ? '#000' : '#151515'}; cursor: pointer;" 
            onclick="openEditor(${i}, 'sequence')"
            ondblclick="startProjectRename('sequence', ${i}); event.stopPropagation();"
            draggable="true" ondragstart="handleDragStart(event, 'sequence', ${i})">
            <strong>${escapeHtml(s.title)}</strong>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-top:5px;">
                <span class="conv-cast-preview">Cast: ${escapeHtml(s.participants.join(', ') || 'None')}</span>
                ${s.isRepeatable ? '<span style="color:var(--accent-green); font-size:0.6rem; font-weight:800; letter-spacing:1px;">REPEATABLE</span>' : ''}
            </div>
            <span class="project-delete-btn" onclick="deleteProject('sequence', ${i}); event.stopPropagation();">DELETE</span>
        </li>
        `;
    }).join('');
    const countTag = document.getElementById('sequence-count');
    if (countTag) countTag.textContent = sequences.length;
}

function exportSingleProject() {
    const project = getActiveProject();
    if (!project) return;
    const projectData = extractProjectVariables(project);
    const blob = new Blob([JSON.stringify(projectData, null, 2)], {type: "application/json"});
    const url = URL.createObjectURL(blob);
    const dl = document.createElement('a');
    
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10);
    const timeStr = now.toISOString().slice(11, 19).replace(/:/g, '-');

    dl.href = url;
    dl.download = `${project.title.replace(/[^a-z0-9]/gi, '_')}_Export_${dateStr}_${timeStr}.json`;
    dl.click();
    URL.revokeObjectURL(url);
    showNotification("Single Project Exported");
}

function openEditor(index, type) {
    activeIndex = index;
    activeType = type;
    const project = getActiveProject();
    
    // Reset minimap states on project load
    editedNodes.clear();
    lastTraversedIndex = -1;
    currentlyVisibleIndex = -1;
    activeNavIndex = -1; 
    
    document.getElementById('editor-placeholder').style.display = 'none';
    document.getElementById('active-editor-content').style.display = 'block';
    document.getElementById('edit-conv-name').value = project.title;
    
    let projectColorWrapper = document.getElementById('project-color-wrapper');
    if (!projectColorWrapper) {
        const authoringZone = document.querySelector('.authoring-zone');
        const editConvName = document.getElementById('edit-conv-name');
        if (editConvName && authoringZone) {
            projectColorWrapper = document.createElement('div');
            projectColorWrapper.id = 'project-color-wrapper';
            projectColorWrapper.style.display = 'flex';
            projectColorWrapper.style.alignItems = 'center';
            projectColorWrapper.style.gap = '10px';
            projectColorWrapper.style.marginBottom = '20px';
            editConvName.parentNode.insertBefore(projectColorWrapper, editConvName.nextSibling);
        }
    }
    
    if (projectColorWrapper) {
        projectColorWrapper.innerHTML = `
            <span style="font-size:0.65rem; color:var(--text-dim); text-transform:uppercase; font-weight:800; letter-spacing:1px;">Project Theme Color:</span>
            <input type="color" id="edit-conv-color" onchange="updateConvColor(this.value)" style="height:30px; width:50px; padding:2px; cursor:pointer; background:var(--bg-deep); border:1px solid var(--border-color);" value="${project.color || '#00f2ff'}">
            <button class="btn btn-outline" style="padding: 4px 8px; margin-left: 15px; border-color: var(--accent-teal); color: var(--accent-teal); display:flex; align-items:center; gap:5px;" onclick="exportSingleProject()" title="Download This Individual Project">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                Download ${activeType === 'conversation' ? 'Conversation' : 'Sequence'}
            </button>
        `;
    }
    
    const repeatCheck = document.getElementById('repeatable-toggle');
    const repeatVarContainer = document.getElementById('repeat-variable-container');
    const repeatVarInput = document.getElementById('repeat-variable-input');
    
    if (repeatCheck) repeatCheck.checked = project.isRepeatable || false;
    if (repeatVarContainer) repeatVarContainer.style.display = (project.isRepeatable) ? 'flex' : 'none';
    if (repeatVarInput) repeatVarInput.value = project.repeatVariable || '';
    
    renderLocalCast();
    renderNodes();
    renderConversations();
    renderSequences();
}

function updateConvTitle(val) {
    if (activeIndex === null) return;
    const proj = getActiveProject();
    const oldName = proj.title;
    proj.title = val;
    
    if (activeType === 'sequence' && oldName !== val) {
        const imgSeq = globalImageSequences.find(s => s.name === oldName);
        if (imgSeq) {
            imgSeq.name = val;
            propagateImageSeqRename(oldName, val);
            renderImageSequences();
        }
    }
    
    if (activeType === 'conversation') renderConversations();
    else renderSequences();
}

function updateConvColor(val) {
    if (activeIndex === null) return;
    const proj = getActiveProject();
    proj.color = val;
    
    if (activeType === 'sequence') {
        const imgSeq = globalImageSequences.find(s => s.name === proj.title);
        if (imgSeq) {
            imgSeq.color = val;
            renderImageSequences();
        }
        renderSequences();
    } else {
        renderConversations();
    }
}

function updateRepeatStatus(checked) {
    if (activeIndex === null) return;
    getActiveProject().isRepeatable = checked;
    const container = document.getElementById('repeat-variable-container');
    if (container) container.style.display = checked ? 'flex' : 'none';
    if (activeType === 'conversation') renderConversations();
    else renderSequences();
}

function updateRepeatVariable(val) {
    if (activeIndex === null) return;
    getActiveProject().repeatVariable = val;
}

function renderLocalCast() {
    const container = document.getElementById('local-cast-tags');
    const project = getActiveProject();
    if (!container || !project) return;
    
    container.innerHTML = project.participants.map(pName => {
        const cData = cast.find(c => c.name === pName) || { color: '#444' };
        return `
            <div class="local-tag" style="border-left-color: ${cData.color}">
                ${escapeHtml(pName)} <span onclick="removeCharFromLocal('${escapeHtml(pName)}')" style="cursor:pointer; margin-left:8px; color:var(--accent-pink);">×</span>
            </div>
        `;
    }).join('');
    
    updateLocalAddDropdown();
}

function updateLocalAddDropdown() {
    const select = document.getElementById('add-to-local-cast');
    if (!select) return;
    const currentLocal = (activeIndex !== null) ? getActiveProject().participants : [];
    const available = cast.filter(c => !currentLocal.includes(c.name));
    select.innerHTML = `<option value="">+ Add Character to Scene</option>` + 
                       available.map(c => `<option value="${escapeHtml(c.name)}">${escapeHtml(c.name)}</option>`).join('');
}

function addCharToLocal(name) {
    if (!name || activeIndex === null) return;
    getActiveProject().participants.push(name);
    renderLocalCast();
    renderNodes();
    if (activeType === 'conversation') renderConversations();
    else renderSequences();
}

function removeCharFromLocal(name) {
    const project = getActiveProject();
    project.participants = project.participants.filter(p => p !== name);
    renderLocalCast();
    renderNodes();
}

// --- NODE EXCLUSIVITY & WINDOW MANAGEMENT ---
function handleNodeExclusivity(nIdx, checkedKey, uncheckedKey, isChecked) {
    const node = getActiveProject().nodes[nIdx];
    node[checkedKey] = isChecked;
    if (isChecked) {
        node[uncheckedKey] = false;
    }
    markNodeEdited(nIdx);
    renderNodes();
}

// --- NODE MANAGEMENT ---
function addDialogueNode(sourceResponseId = null, previewText = null, insertIndex = null) {
    if (activeIndex === null) return;
    const project = getActiveProject();
    const newNode = {
        id: crypto.randomUUID(),
        conditions: [],
        speaker: project.participants[0] || '',
        advancedOpen: false,
        resourcePath: 'Assets/Resources/Slides/',
        usePath: false,
        closeMainMenu: false,
        closeDialogueMenu: false,
        openPromptPanel: false,
        closePromptPanel: false,
        changeTimeOfDay: false,
        timeOfDayChanges: [{ time: '', value: '' }],
        changeDayOfWeek: false,
        dayOfWeekChanges: [{ day: '', value: '' }],
        changeMenuOption: false,
        menuOptionChanges: [{ menu: '', value: '' }],
        gameStateChanges: [], 
        changeSetting: false,
        settingChanges: [{ setting: '', value: '' }],
        controlSequence: false,
        sequenceName: '',
        sequenceImage: '',
        controlPuppets: false,         
        puppetUsePath: false,          
        puppetUseTag: false,          
        changePuppetState: false,
        changePuppetMood: false,
        changePuppetInvert: false,
        puppets: [],
        canPlayerRespond: false,
        externalCall: false,
        responses: [],
        parentResponseId: sourceResponseId,
        parentResponsePreview: previewText,
        textFormat: { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' }
    };
    
    if (insertIndex !== null) {
        project.nodes.splice(insertIndex, 0, newNode);
    } else {
        project.nodes.push(newNode);
    }
    
    renderNodes();
    return newNode.id;
}

function deleteNode(nodeIdx) {
    const project = getActiveProject();
    const nodeToDelete = project.nodes[nodeIdx];
    
    project.nodes.forEach(n => {
        n.responses.forEach(r => {
            if (r.nextStatementId === nodeToDelete.id || r.id === nodeToDelete.parentResponseId) {
                r.nextStatementId = null;
            }
        });
    });

    project.nodes.splice(nodeIdx, 1);
    renderNodes();
}

// --- PUPPET MANAGEMENT ---
function toggleAdvancedSettings(nIdx) {
    getActiveProject().nodes[nIdx].advancedOpen = !getActiveProject().nodes[nIdx].advancedOpen;
    markNodeEdited(nIdx);
    renderNodes();
}

function toggleControlPuppets(nIdx, isChecked) {
    getActiveProject().nodes[nIdx].controlPuppets = isChecked;
    markNodeEdited(nIdx);
    renderNodes();
}

function addPuppetToNode(nIdx, charName) {
    if(!charName) return;
    const node = getActiveProject().nodes[nIdx];
    if (!node.puppets.some(p => p.name === charName)) {
        node.puppets.push({
            name: charName,
            enabled: true,
            position: '',
            path: 'Assets/Resources/Puppets/',
            state: '',
            mood: '',
            invert: false
        });
        markNodeEdited(nIdx);
        renderNodes();
    }
}

function removePuppetFromNode(nIdx, pIdx) {
    getActiveProject().nodes[nIdx].puppets.splice(pIdx, 1);
    markNodeEdited(nIdx);
    renderNodes();
}

function togglePuppetEnabled(nIdx, pIdx, isChecked) {
    getActiveProject().nodes[nIdx].puppets[pIdx].enabled = isChecked;
    markNodeEdited(nIdx);
    renderNodes();
}

function updatePuppetPosition(nIdx, pIdx, val) {
    getActiveProject().nodes[nIdx].puppets[pIdx].position = val;
    markNodeEdited(nIdx);
}

function toggleChangePuppetState(nIdx, isChecked) {
    getActiveProject().nodes[nIdx].changePuppetState = isChecked;
    markNodeEdited(nIdx);
    renderNodes();
}

function togglePuppetUseTag(nIdx, isChecked) {
    const node = getActiveProject().nodes[nIdx];
    node.puppetUseTag = isChecked;
    if (isChecked) node.puppetUsePath = false;
    markNodeEdited(nIdx);
    renderNodes();
}

function togglePuppetUsePath(nIdx, isChecked) {
    const node = getActiveProject().nodes[nIdx];
    node.puppetUsePath = isChecked;
    if (isChecked) node.puppetUseTag = false;
    markNodeEdited(nIdx);
    renderNodes();
}

function toggleChangePuppetMood(nIdx, isChecked) {
    getActiveProject().nodes[nIdx].changePuppetMood = isChecked;
    markNodeEdited(nIdx);
    renderNodes();
}

function toggleChangePuppetInvert(nIdx, isChecked) {
    getActiveProject().nodes[nIdx].changePuppetInvert = isChecked;
    markNodeEdited(nIdx);
    renderNodes();
}

function updatePuppetPath(nIdx, pIdx, val) {
    getActiveProject().nodes[nIdx].puppets[pIdx].path = val;
    markNodeEdited(nIdx);
}

function updatePuppetState(nIdx, pIdx, val) {
    getActiveProject().nodes[nIdx].puppets[pIdx].state = val;
    markNodeEdited(nIdx);
}

function updatePuppetMood(nIdx, pIdx, val) {
    getActiveProject().nodes[nIdx].puppets[pIdx].mood = val;
    markNodeEdited(nIdx);
}

function updatePuppetInvert(nIdx, pIdx, isChecked) {
    getActiveProject().nodes[nIdx].puppets[pIdx].invert = isChecked;
    markNodeEdited(nIdx);
}

// Node specific updates
function addConditionRow(nIdx) {
    getActiveProject().nodes[nIdx].conditions.push({ variable: '', operator: '==', value: '' });
    markNodeEdited(nIdx);
    renderNodes();
}
function removeConditionRow(nIdx, cIdx) {
    getActiveProject().nodes[nIdx].conditions.splice(cIdx, 1);
    markNodeEdited(nIdx);
    renderNodes();
}
function updateCondition(nIdx, cIdx, field, val) {
    getActiveProject().nodes[nIdx].conditions[cIdx][field] = val;
    markNodeEdited(nIdx);
    renderProjectTags();
}

function addTimeChangeRow(nIdx) { getActiveProject().nodes[nIdx].timeOfDayChanges.push({ time: '', value: '' }); markNodeEdited(nIdx); renderNodes(); }
function removeTimeChangeRow(nIdx, cIdx) { getActiveProject().nodes[nIdx].timeOfDayChanges.splice(cIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function updateTimeChange(nIdx, cIdx, field, val) { getActiveProject().nodes[nIdx].timeOfDayChanges[cIdx][field] = val; markNodeEdited(nIdx); }

function addDayChangeRow(nIdx) { getActiveProject().nodes[nIdx].dayOfWeekChanges.push({ day: '', value: '' }); markNodeEdited(nIdx); renderNodes(); }
function removeDayChangeRow(nIdx, cIdx) { getActiveProject().nodes[nIdx].dayOfWeekChanges.splice(cIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function updateDayChange(nIdx, cIdx, field, val) { getActiveProject().nodes[nIdx].dayOfWeekChanges[cIdx][field] = val; markNodeEdited(nIdx); }

function addMenuChangeRow(nIdx) { getActiveProject().nodes[nIdx].menuOptionChanges.push({ menu: '', value: '' }); markNodeEdited(nIdx); renderNodes(); }
function removeMenuChangeRow(nIdx, cIdx) { getActiveProject().nodes[nIdx].menuOptionChanges.splice(cIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function updateMenuChange(nIdx, cIdx, field, val) { getActiveProject().nodes[nIdx].menuOptionChanges[cIdx][field] = val; markNodeEdited(nIdx); }

function addStateChangeRow(nIdx) { getActiveProject().nodes[nIdx].gameStateChanges.push({ variable: '', operator: '==', value: '' }); markNodeEdited(nIdx); renderNodes(); }
function removeStateChangeRow(nIdx, cIdx) { getActiveProject().nodes[nIdx].gameStateChanges.splice(cIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function updateStateChange(nIdx, cIdx, field, val) {
    getActiveProject().nodes[nIdx].gameStateChanges[cIdx][field] = val;
    markNodeEdited(nIdx);
    renderProjectTags();
}

function addSettingChangeRow(nIdx) { getActiveProject().nodes[nIdx].settingChanges.push({ setting: '', value: '' }); markNodeEdited(nIdx); renderNodes(); }
function removeSettingChangeRow(nIdx, cIdx) { getActiveProject().nodes[nIdx].settingChanges.splice(cIdx, 1); markNodeEdited(nIdx); renderNodes(); }
function updateSettingChange(nIdx, cIdx, field, val) { getActiveProject().nodes[nIdx].settingChanges[cIdx][field] = val; markNodeEdited(nIdx); }

function linkExistingStatement(nodeIndex, responseIndex, targetNodeId) {
    if (!targetNodeId) return;
    const project = getActiveProject();
    const response = project.nodes[nodeIndex].responses[responseIndex];
    const targetNode = project.nodes.find(n => n.id === targetNodeId);
    
    if (targetNode) {
        response.nextStatementId = targetNodeId;
        markNodeEdited(nodeIndex);
        renderNodes();
    }
}

function establishReverseReply(nIdx) {
    const project = getActiveProject();
    const currentNode = project.nodes[nIdx];
    const selectEl = document.getElementById(`reverse-link-select-${nIdx}`);
    if (!selectEl) return;
    
    const parentNodeId = selectEl.value;
    if (!parentNodeId) return;

    const parentNode = project.nodes.find(n => n.id === parentNodeId);
    if (!parentNode) return;

    if ((parentNode.responses || []).length >= 4) {
        showNotification("Target statement already has 4 responses.", true);
        return;
    }

    parentNode.canPlayerRespond = true;

    const newResponseId = crypto.randomUUID();
    const responseSpeaker = project.participants[0] || '';
    const responseText = 'Continue...';
    
    parentNode.responses.push({
        id: newResponseId,
        speaker: responseSpeaker,
        text: responseText,
        nextStatementId: currentNode.id,
        conditions: [],
        gameStateChanges: [],
        autoIncrement: false
    });

    markNodeEdited(nIdx);
    markNodeEdited(project.nodes.indexOf(parentNode));
    renderNodes();
}

function unlinkResponse(nIdx, rIdx) {
    if (activeIndex === null) return;
    const project = getActiveProject();
    if (project.nodes[nIdx] && project.nodes[nIdx].responses[rIdx]) {
        project.nodes[nIdx].responses[rIdx].nextStatementId = null;
        markNodeEdited(nIdx);
        renderNodes();
    }
}

function unlinkSpecificReverseReply(childNIdx, parentNodeId, responseId) {
    const project = getActiveProject();
    const parentNode = project.nodes.find(n => n.id === parentNodeId);
    
    if (parentNode) {
        const resp = parentNode.responses.find(r => r.id === responseId);
        if (resp) {
            resp.nextStatementId = null;
        }
    }
    markNodeEdited(childNIdx);
    renderNodes();
}

// Response-Specific Logic Functions
function toggleResponseAutoIncrement(nIdx, rIdx, isChecked) {
    getActiveProject().nodes[nIdx].responses[rIdx].autoIncrement = isChecked;
    markNodeEdited(nIdx);
    updateResponseGlow(nIdx, rIdx);
}

function addResponseConditionRow(nIdx, rIdx) {
    getActiveProject().nodes[nIdx].responses[rIdx].conditions.push({ variable: '', operator: '==', value: '' });
    markNodeEdited(nIdx);
    renderNodes();
}

function removeResponseConditionRow(nIdx, rIdx, cIdx) {
    getActiveProject().nodes[nIdx].responses[rIdx].conditions.splice(cIdx, 1);
    markNodeEdited(nIdx);
    renderNodes();
}

function updateResponseConditionRow(nIdx, rIdx, cIdx, field, val) {
    getActiveProject().nodes[nIdx].responses[rIdx].conditions[cIdx][field] = val;
    markNodeEdited(nIdx);
    renderProjectTags();
}

function addResponseStateChangeRow(nIdx, rIdx) {
    getActiveProject().nodes[nIdx].responses[rIdx].gameStateChanges.push({ variable: '', operator: '=', value: '' });
    markNodeEdited(nIdx);
    renderNodes();
}

function removeResponseStateChangeRow(nIdx, rIdx, cIdx) {
    getActiveProject().nodes[nIdx].responses[rIdx].gameStateChanges.splice(cIdx, 1);
    markNodeEdited(nIdx);
    renderNodes();
}

function updateResponseStateChangeRow(nIdx, rIdx, cIdx, field, val) {
    getActiveProject().nodes[nIdx].responses[rIdx].gameStateChanges[cIdx][field] = val;
    markNodeEdited(nIdx);
    renderProjectTags();
    updateResponseGlow(nIdx, rIdx);
}

function updateResponseGlow(nIdx, rIdx) {
    const project = getActiveProject();
    if (!project) return;
    const r = project.nodes[nIdx].responses[rIdx];
    if (!r) return;

    const isLinked = r.nextStatementId && project.nodes.some(n => n.id === r.nextStatementId);
    const hasGameState = r.autoIncrement || (r.gameStateChanges && r.gameStateChanges.some(c => c.variable.trim() !== '' || c.value.trim() !== ''));

    const el = document.getElementById(`response-item-${nIdx}-${rIdx}`);
    if (el) {
        if (!isLinked && !hasGameState) {
            // Missing both: half blue, half gold
            el.style.boxShadow = '-5px 0 15px #0055ff, 5px 0 15px #ffaa00';
            el.style.outline = '1px solid #777';
        } else if (!isLinked) {
            // Missing link only: Pure BLUE
            el.style.boxShadow = '0 0 15px #0055ff';
            el.style.outline = '1px solid #0055ff';
        } else if (!hasGameState) {
            // Missing game state only: Pure GOLD
            el.style.boxShadow = '0 0 15px #ffaa00';
            el.style.outline = '1px solid #ffaa00';
        } else {
            // Both fulfilled: No glow
            el.style.boxShadow = 'none';
            el.style.outline = 'none';
        }
    }
}

// Response Reordering Logic
function moveResponseUp(nIdx, rIdx) {
    if (activeIndex === null || rIdx <= 0) return;
    const project = getActiveProject();
    const responses = project.nodes[nIdx].responses;
    const temp = responses[rIdx - 1];
    responses[rIdx - 1] = responses[rIdx];
    responses[rIdx] = temp;
    markNodeEdited(nIdx);
    renderNodes();
}

function moveResponseDown(nIdx, rIdx) {
    if (activeIndex === null) return;
    const project = getActiveProject();
    const responses = project.nodes[nIdx].responses;
    if (rIdx >= responses.length - 1) return;
    const temp = responses[rIdx + 1];
    responses[rIdx + 1] = responses[rIdx];
    responses[rIdx] = temp;
    markNodeEdited(nIdx);
    renderNodes();
}

// Node Reordering Logic
function moveNode(fromIdx, toIdx) {
    if (activeIndex === null || fromIdx === toIdx) return;
    const project = getActiveProject();
    const nodeToMove = project.nodes.splice(fromIdx, 1)[0];
    project.nodes.splice(toIdx, 0, nodeToMove);
    renderNodes();
    setTimeout(() => scrollToElement(`node-${nodeToMove.id}`), 50);
}

// --- RENDERING ---
function renderNodes() {
    const container = document.getElementById('node-container');
    const project = getActiveProject();
    if (!container || !project) return;
    container.innerHTML = '';

    // Re-inject Statement Search Bar exactly above nodes (so it's clearly attached to Statements)
    const editorContent = document.getElementById('active-editor-content');
    if (editorContent && !document.getElementById('statement-search-wrapper')) {
        container.insertAdjacentHTML('beforebegin', `
            <div id="statement-search-wrapper" style="margin-bottom: 30px; padding: 15px; background: rgba(0,0,0,0.4); border: 1px dashed var(--accent-orange); border-left: 4px solid var(--accent-orange);">
                <label style="font-size: 0.7rem; color: var(--accent-orange); text-transform: uppercase; font-weight: 800; display: block; margin-bottom: 10px; letter-spacing: 1px;">Statement Database</label>
                <input type="text" id="search-statements" class="search-input" style="margin-bottom: 5px; border-color: var(--accent-orange); background: #000;" placeholder="Search statements by text, speaker, or ID..." oninput="filterStatements()">
                <div style="font-size: 0.55rem; color: var(--text-dim); line-height: 1.4;">
                    <strong>Navigation:</strong> Press ↑/↓ to snap between statements. Hold ↑/↓ to traverse rapidly. Use PgUp/PgDn to skip 10 statements. Press Home/End to jump to the top or bottom.
                </div>
            </div>
        `);
    }

    project.nodes.forEach((node, nIdx) => {
        const div = document.createElement('div');
        div.className = 'dialogue-node';
        div.id = `node-${node.id}`;
        
        const incomingLinks = [];
        
        // Scan ALL responses in the project for ANY that point to this specific statement
        project.nodes.forEach((pNode, pIdx) => {
            (pNode.responses || []).forEach((resp, rIdx) => {
                if (resp.nextStatementId === node.id) {
                    incomingLinks.push({ parentNode: pNode, parentNodeIdx: pIdx, response: resp, responseIdx: rIdx });
                }
            });
        });

        // Node Warning Glow Logic (Red glow if NO incoming links AND externalCall is false)
        const needsRedGlow = incomingLinks.length === 0 && !node.externalCall;
        
        let nodeStyle = 'position: relative; transition: border-color 0.3s, box-shadow 0.3s;';
        if (needsRedGlow) {
            nodeStyle += ' border-color: var(--accent-pink); box-shadow: 0 0 20px rgba(255, 0, 123, 0.6);';
        }
        div.setAttribute('style', nodeStyle);
        
        const nodeNumberBadge = `<div style="position: absolute; top: 0; left: 0; background: var(--accent-teal); color: #000; font-size: 0.6rem; font-weight: 900; padding: 2px 8px; border-bottom-right-radius: 4px; z-index: 10;">#${nIdx + 1}</div>`;
        
        const nodeReorderDropdown = `
            <div style="position: absolute; top: 18px; left: 0; background: #000; border-right: 1px solid var(--accent-teal); border-bottom: 1px solid var(--accent-teal); padding: 3px 8px; border-bottom-right-radius: 4px; z-index: 10; display: flex; align-items: center; gap: 6px;">
                <span style="font-size: 0.5rem; color: var(--text-dim); text-transform: uppercase; font-weight: 800;">Move To</span>
                <select class="custom-scrollbar" onchange="moveNode(${nIdx}, parseInt(this.value))" style="font-size: 0.6rem; padding: 2px 4px; background: #111; border: 1px solid var(--border-color); color: var(--accent-teal); cursor: pointer; outline: none; min-width: 65px; max-width: 80px;">
                    ${project.nodes.map((_, i) => `<option value="${i}" ${i === nIdx ? 'selected' : ''}>#${i + 1}</option>`).join('')}
                </select>
            </div>
        `;

        const nodeIdBadge = `<div style="position: absolute; top: 5px; right: 10px; font-size: 0.55rem; color: #555; font-style: italic; z-index: 10; pointer-events: none;">node_id: ${node.id}</div>`;
        
        let replyTag = '';

        const eligibleParents = project.nodes.filter(n => n.id !== node.id && (n.responses || []).length < 4);
        
        let incomingLinksHtml = incomingLinks.map(link => `
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom: 8px; padding-bottom: 8px; border-bottom: 1px dashed rgba(255, 140, 0, 0.2);">
                <div>
                    <button style="background: var(--accent-orange); color: #000; font-weight: 900; font-size: 0.6rem; padding: 3px 8px; border-radius: 2px; border: none; cursor: pointer; text-transform: uppercase; letter-spacing: 1px; display: inline-flex; align-items: center; gap: 5px; margin-bottom: 5px;"
                            onclick="scrollToElement('response-item-${link.parentNodeIdx}-${link.responseIdx}')" title="Jump to parent response">
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 10 20 15 15 20"></polyline><path d="M4 4v7a4 4 0 0 0 4 4h12"></path></svg>
                        FROM: ${escapeHtml(link.parentNode.speaker || 'Unknown')} (Statement #${link.parentNodeIdx + 1})
                    </button>
                    <div style="font-size: 0.75rem; color: #aaa; font-style: italic; line-height: 1.3;">
                        "${escapeHtml(link.parentNode.text ? link.parentNode.text.substring(0, 40) + '...' : 'Empty Statement')}"<br>
                        <span style="color:var(--accent-teal); font-weight: bold;">↳ via Response: "${escapeHtml(link.response.text)}"</span>
                    </div>
                </div>
                <button class="btn btn-outline" style="padding: 3px 6px; font-size: 0.55rem; color: var(--accent-pink); border-color: var(--accent-pink);" onclick="unlinkSpecificReverseReply(${nIdx}, '${link.parentNode.id}', '${link.response.id}')" title="Sever this connection">Unlink</button>
            </div>
        `).join('');

        let reverseReplyDropdownHtml = '';
        if (eligibleParents.length > 0) {
            reverseReplyDropdownHtml = `
                <div style="display: flex; align-items: center; gap: 10px; margin-top: ${incomingLinks.length > 0 ? '10px' : '0'};">
                    <span style="font-size: 0.65rem; color: var(--text-dim); text-transform: uppercase; font-weight: 800; white-space:nowrap;">Connect From:</span>
                    <select id="reverse-link-select-${nIdx}" class="custom-scrollbar" style="flex: 1; padding: 4px; font-size: 0.75rem; background: #000; border: 1px solid var(--border-color); color: #fff;">
                        <option value="">-- Select a previous statement... --</option>
                        ${eligibleParents.map((n, i) => `<option value="${n.id}">Statement #${i + 1} [node_id:${n.id.substring(0,8)}...] (${escapeHtml(n.speaker || 'Unknown')})</option>`).join('')}
                    </select>
                    <button class="btn btn-outline" style="padding: 4px 10px; font-size: 0.65rem; border-color: var(--accent-teal); color: var(--accent-teal);" onclick="establishReverseReply(${nIdx})">Link</button>
                </div>
            `;
        }

        if (incomingLinks.length > 0 || eligibleParents.length > 0) {
            replyTag = `
                <div style="margin-bottom: 20px; padding: 15px; background: rgba(255, 140, 0, 0.05); border-left: 3px solid var(--accent-orange); border-radius: 0 4px 4px 0;">
                    ${incomingLinks.length > 0 ? `<div style="font-size: 0.65rem; color: var(--accent-orange); font-weight: 800; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 10px;">Incoming Connections (${incomingLinks.length})</div>` : ''}
                    ${incomingLinksHtml}
                    ${reverseReplyDropdownHtml}
                </div>
            `;
        }

        const availablePuppets = cast.filter(c => !node.puppets.some(p => p.name === c.name));
        
        const tf = node.textFormat || { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
        
        let textStyleStr = '';
        textStyleStr += tf.bold ? 'font-weight: bold; ' : 'font-weight: normal; ';
        textStyleStr += tf.italic ? 'font-style: italic; ' : 'font-style: normal; ';
        
        let decos = [];
        if (tf.underline) decos.push('underline');
        if (tf.strikethrough) decos.push('line-through');
        textStyleStr += `text-decoration: ${decos.length > 0 ? decos.join(' ') : 'none'}; `;
        
        textStyleStr += `text-align: ${tf.alignH === 'justified' ? 'justify' : tf.alignH}; `;
        if (tf.listStyle !== 'none') textStyleStr += 'padding-left: 30px; ';

        div.innerHTML = `
            ${nodeNumberBadge}
            ${nodeReorderDropdown}
            ${nodeIdBadge}
            ${replyTag}

            <!-- CONDITIONS SECTION -->
            <div class="logic-block">
                <div class="logic-header">
                    <div class="logic-title">Conditions</div>
                    <button class="logic-add-btn btn-green" onclick="addConditionRow(${nIdx})">+</button>
                </div>
                ${(node.conditions || []).map((cond, cIdx) => `
                    <div class="logic-row">
                        <input type="text" class="logic-input" value="${escapeHtml(cond.variable || '')}" oninput="updateCondition(${nIdx}, ${cIdx}, 'variable', this.value)" placeholder="Variable...">
                        <select class="logic-select" onchange="updateCondition(${nIdx}, ${cIdx}, 'operator', this.value)">
                            <option value="==" ${cond.operator === '==' ? 'selected' : ''}>==</option>
                            <option value="!=" ${cond.operator === '!=' ? 'selected' : ''}>!=</option>
                            <option value=">" ${cond.operator === '>' ? 'selected' : ''}>&gt;</option>
                            <option value="<" ${cond.operator === '<' ? 'selected' : ''}>&lt;</option>
                            <option value=">=" ${cond.operator === '>=' ? 'selected' : ''}>&gt;=</option>
                            <option value="<=" ${cond.operator === '<=' ? 'selected' : ''}>&lt;=</option>
                        </select>
                        <input type="text" class="logic-input" value="${escapeHtml(cond.value || '')}" oninput="updateCondition(${nIdx}, ${cIdx}, 'value', this.value)" placeholder="Value...">
                        <span class="logic-delete" onclick="removeConditionRow(${nIdx}, ${cIdx})">×</span>
                    </div>
                `).join('')}
            </div>

            <div class="node-header">
                <div style="display:flex; align-items:center; gap:15px; flex:1;">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <span class="${node.speaker === '' ? 'missing-speaker' : ''}" style="font-size:0.7rem; color:var(--text-dim); font-weight:800; text-transform:uppercase; transition: 0.3s;">Speaker</span>
                        <select class="custom-scrollbar" onchange="getActiveProject().nodes[${nIdx}].speaker = this.value; markNodeEdited(${nIdx}); renderNodes();">
                            <option value="">-- Select --</option>
                            ${project.participants.map(p => `<option value="${escapeHtml(p)}" ${p === node.speaker ? 'selected' : ''} style="color:white;">${escapeHtml(p)}</option>`).join('')}
                        </select>
                    </div>
                </div>
                <div style="display:flex; align-items:center; gap:10px;">
                    <span style="font-size:0.7rem; color:var(--text-dim); margin-right:5px;">EXTERNAL CALL</span>
                    <input type="checkbox" ${node.externalCall ? 'checked' : ''} 
                        onclick="getActiveProject().nodes[${nIdx}].externalCall = !getActiveProject().nodes[${nIdx}].externalCall; markNodeEdited(${nIdx}); renderNodes();"
                        style="margin-right:10px;">
                    <span style="font-size:0.7rem; color:var(--text-dim); margin-right:5px;">BRANCHING</span>
                    <input type="checkbox" ${node.canPlayerRespond ? 'checked' : ''} 
                        onclick="getActiveProject().nodes[${nIdx}].canPlayerRespond = !getActiveProject().nodes[${nIdx}].canPlayerRespond; markNodeEdited(${nIdx}); renderNodes();">
                    <button class="btn btn-outline" style="color:var(--accent-pink); border-color:transparent; padding:0 10px;" 
                        onclick="deleteNode(${nIdx})">Delete</button>
                </div>
            </div>
            
            <div class="format-toolbar">
                <button class="format-btn font-bold ${tf.bold ? 'active' : ''}" style="font-family: serif;" onclick="applyTextFormat(${nIdx}, 'b')" title="Bold">B</button>
                <button class="format-btn italic ${tf.italic ? 'active' : ''}" style="font-family: serif;" onclick="applyTextFormat(${nIdx}, 'i')" title="Italic">I</button>
                <button class="format-btn underline ${tf.underline ? 'active' : ''}" style="font-family: serif;" onclick="applyTextFormat(${nIdx}, 'u')" title="Underline">U</button>
                <button class="format-btn line-through ${tf.strikethrough ? 'active' : ''}" style="font-family: serif;" onclick="applyTextFormat(${nIdx}, 's')" title="Strikethrough">S</button>
                
                <div style="width: 1px; height: 18px; background: rgba(255,255,255,0.1); margin: 0 4px;"></div>

                <button class="format-btn ${tf.listStyle === 'bullet' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'bullet')" title="Bullet List">
                    <svg viewBox="0 0 24 24"><path d="M4 6h2v2H4zm0 5h2v2H4zm0 5h2v2H4zm4-10h12v2H8zm0 5h12v2H8zm0 5h12v2H8z"></path></svg>
                </button>
                <button class="format-btn ${tf.listStyle === 'number' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'number')" title="Numbered List">
                    <svg viewBox="0 0 24 24"><path d="M5 7h1v2H5zm0 4h1v2H5zm0 4h1v2H5zm3-8h12v2H8zm0 4h12v2H8zm0 4h12v2H8z"></path></svg>
                </button>
                
                <div style="width: 1px; height: 18px; background: rgba(255,255,255,0.1); margin: 0 4px;"></div>

                <button class="format-btn ${tf.alignH === 'left' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'align', 'left')" title="Align Left">
                    <svg viewBox="0 0 24 24"><path d="M3 5h14v2H3V5zm0 6h8v2H3v-2zm0 6h14v2H3v-2z"></path></svg>
                </button>
                <button class="format-btn ${tf.alignH === 'center' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'align', 'center')" title="Align Center">
                    <svg viewBox="0 0 24 24"><path d="M5 5h14v2H5V5zm3 6h8v2H8v-2zm-3 6h14v2H5v-2z"></path></svg>
                </button>
                <button class="format-btn ${tf.alignH === 'right' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'align', 'right')" title="Align Right">
                    <svg viewBox="0 0 24 24"><path d="M7 5h14v2H7V5zm6 6h8v2h-8v-2zm-6 6h14v2H7v-2z"></path></svg>
                </button>
                <button class="format-btn ${tf.alignH === 'justified' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'align', 'justified')" title="Justified">
                    <svg viewBox="0 0 24 24"><path d="M3 5h18v2H3V5zm0 6h18v2H3v-2zm0 6h18v2H3v-2z"></path></svg>
                </button>

                <div style="width: 1px; height: 18px; background: rgba(255,255,255,0.1); margin: 0 4px;"></div>

                <button class="format-btn ${tf.alignV === 'top' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'top')" title="Align Top">
                    <svg viewBox="0 0 24 24"><path d="M5 3h14v2H5V3zm0 4h14v2H5V7zm0 4h8v2H5v-2z"></path></svg>
                </button>
                <button class="format-btn ${tf.alignV === 'middle' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'middle')" title="Align Middle">
                    <svg viewBox="0 0 24 24"><path d="M5 9h14v2H5V9zm0 4h8v2H5v-2zm0 4h14v2H5v-2z"></path></svg>
                </button>
                <button class="format-btn ${tf.alignV === 'bottom' ? 'active' : ''}" onclick="applyTextFormat(${nIdx}, 'bottom')" title="Align Bottom">
                    <svg viewBox="0 0 24 24"><path d="M5 11h8v2H5v-2zm0 4h14v2H5v-2zm0 4h14v2H5v-2z"></path></svg>
                </button>
            </div>
            <textarea id="node-text-${nIdx}" class="node-body custom-scrollbar" placeholder="Enter dialogue..." onchange="getActiveProject().nodes[${nIdx}].text = this.value; markNodeEdited(${nIdx});" style="border-top-left-radius: 0; border-top-right-radius: 0; ${textStyleStr}">${escapeHtml(node.text || '')}</textarea>

            ${node.canPlayerRespond ? renderResponseSection(nIdx, project) : ''}

            <div class="game-state-controls">
                <!-- Advanced Settings Toggle -->
                <div onclick="toggleAdvancedSettings(${nIdx})" style="cursor: pointer; display: flex; align-items: center; gap: 8px; padding-bottom: 5px; border-bottom: 1px dashed var(--border-color);">
                    <span style="font-size: 0.75rem; color: var(--accent-teal); font-weight: 800; text-transform: uppercase; letter-spacing: 1px;">Advanced</span>
                    <span style="color: var(--accent-teal); font-size: 0.8rem; transform: ${node.advancedOpen ? 'rotate(90deg)' : 'rotate(0deg)'}; transition: transform 0.2s; display: inline-block;">▶</span>
                </div>

                <div style="display: ${node.advancedOpen ? 'flex' : 'none'}; flex-direction: column; gap: 12px; padding-top: 10px;">
                    
                    <!-- Window Management Controls -->
                    <div class="state-row" style="flex-wrap: wrap;">
                        <div class="state-input-group">
                            <label style="color:var(--accent-gold)">Close Main Menu?</label>
                            <input type="checkbox" ${node.closeMainMenu ? 'checked' : ''} onchange="getActiveProject().nodes[${nIdx}].closeMainMenu = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        <div class="state-input-group">
                            <label style="color:var(--accent-pink)">Close Dialogue Menu?</label>
                            <input type="checkbox" ${node.closeDialogueMenu ? 'checked' : ''} onchange="getActiveProject().nodes[${nIdx}].closeDialogueMenu = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        <div class="state-input-group">
                            <label style="color:var(--accent-teal)">Open Prompt Panel?</label>
                            <input type="checkbox" ${node.openPromptPanel ? 'checked' : ''} onchange="handleNodeExclusivity(${nIdx}, 'openPromptPanel', 'closePromptPanel', this.checked)">
                        </div>
                        <div class="state-input-group">
                            <label style="color:var(--accent-teal)">Close Prompt Panel?</label>
                            <input type="checkbox" ${node.closePromptPanel ? 'checked' : ''} onchange="handleNodeExclusivity(${nIdx}, 'closePromptPanel', 'openPromptPanel', this.checked)">
                        </div>
                    </div>
                    <hr style="border:0; border-top:1px dashed var(--border-color); width:100%; margin: 5px 0;">

                    <!-- Sequence Controls -->
                    <div class="state-row" style="flex-wrap: wrap;">
                        <div class="state-input-group">
                            <label style="color:var(--accent-purple)">Control Sequence Image?</label>
                            <input type="checkbox" ${node.controlSequence ? 'checked' : ''} onchange="getActiveProject().nodes[${nIdx}].controlSequence = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                    </div>
                    ${node.controlSequence ? `
                        <div class="state-row" style="margin-left: 15px; border-left: 2px solid var(--accent-purple); padding-left: 10px; margin-bottom: 10px;">
                            <div class="state-input-group" style="flex:1;">
                                <label>Sequence</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="getActiveProject().nodes[${nIdx}].sequenceName = this.value; getActiveProject().nodes[${nIdx}].sequenceImage = ''; markNodeEdited(${nIdx}); renderNodes();">
                                    <option value="">-- Select Sequence --</option>
                                    ${globalImageSequences.map(s => `<option value="${escapeHtml(s.name)}" ${node.sequenceName === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Image Name</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="getActiveProject().nodes[${nIdx}].sequenceImage = this.value; markNodeEdited(${nIdx}); renderNodes();">
                                    <option value="">-- Select Image --</option>
                                    ${(globalImageSequences.find(s => s.name === node.sequenceName)?.images || []).map(img => `<option value="${escapeHtml(img)}" ${node.sequenceImage === img ? 'selected' : ''}>${escapeHtml(img)}</option>`).join('')}
                                </select>
                            </div>
                        </div>
                    ` : ''}

                    <!-- Menu Options Controls -->
                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Change Menu Option?</label>
                            <input type="checkbox" ${node.changeMenuOption ? 'checked' : ''} 
                                onchange="getActiveProject().nodes[${nIdx}].changeMenuOption = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        ${node.changeMenuOption ? `
                            <button class="btn btn-outline" style="padding: 4px 10px; font-size: 0.6rem; margin-left: auto; border-color: var(--accent-orange); color: var(--accent-orange);" 
                                onclick="addMenuChangeRow(${nIdx})">+ Add Menu Change</button>
                        ` : ''}
                    </div>
                    
                    ${node.changeMenuOption ? (node.menuOptionChanges || []).map((change, cIdx) => `
                        <div class="state-row">
                            <div class="state-input-group" style="flex:1;">
                                <label>Menu Option</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="updateMenuChange(${nIdx}, ${cIdx}, 'menu', this.value)">
                                    <option value="">-- Select Menu --</option>
                                    ${globalMenuOptions.map(s => `<option value="${escapeHtml(s.name)}" ${change.menu === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Value</label>
                                <input type="text" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" 
                                    value="${escapeHtml(change.value || '')}" 
                                    onchange="updateMenuChange(${nIdx}, ${cIdx}, 'value', this.value)">
                            </div>
                            ${(node.menuOptionChanges.length > 1) ? `
                                <span onclick="removeMenuChangeRow(${nIdx}, ${cIdx})" 
                                      style="cursor:pointer; color:var(--accent-pink); font-weight:bold; padding: 0 5px;">×</span>
                            ` : ''}
                        </div>
                    `).join('') : ''}

                    <hr style="border:0; border-top:1px dashed var(--border-color); width:100%; margin: 5px 0;">
                    
                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Background Use Path?</label>
                            <input type="checkbox" ${node.usePath ? 'checked' : ''} 
                                onchange="getActiveProject().nodes[${nIdx}].usePath = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        ${node.usePath ? `
                            <input type="text" style="flex:1; padding: 6px 12px; font-size: 0.8rem;" 
                                placeholder="Path..." 
                                value="${escapeHtml(node.resourcePath || 'Assets/Resources/Slides/')}" 
                                onchange="getActiveProject().nodes[${nIdx}].resourcePath = this.value; markNodeEdited(${nIdx});">
                        ` : ''}
                    </div>

                    <!-- Global Settings Controls -->
                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Change Setting?</label>
                            <input type="checkbox" ${node.changeSetting ? 'checked' : ''} 
                                onchange="getActiveProject().nodes[${nIdx}].changeSetting = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        ${node.changeSetting ? `
                            <button class="btn btn-outline" style="padding: 4px 10px; font-size: 0.6rem; margin-left: auto; border-color: var(--accent-orange); color: var(--accent-orange);" 
                                onclick="addSettingChangeRow(${nIdx})">+ Add Setting Change</button>
                        ` : ''}
                    </div>

                    ${node.changeSetting ? (node.settingChanges || []).map((change, cIdx) => `
                        <div class="state-row">
                            <div class="state-input-group" style="flex:1;">
                                <label>Setting</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="updateSettingChange(${nIdx}, ${cIdx}, 'setting', this.value)">
                                    <option value="">-- Select Setting --</option>
                                    ${globalSettings.map(s => `<option value="${escapeHtml(s.name)}" ${change.setting === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Value</label>
                                <input type="text" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" 
                                    value="${escapeHtml(change.value || '')}" 
                                    onchange="updateSettingChange(${nIdx}, ${cIdx}, 'value', this.value)">
                            </div>
                            ${(node.settingChanges.length > 1) ? `
                                <span onclick="removeSettingChangeRow(${nIdx}, ${cIdx})" 
                                      style="cursor:pointer; color:var(--accent-pink); font-weight:bold; padding: 0 5px;">×</span>
                            ` : ''}
                        </div>
                    `).join('') : ''}

                    <hr style="border:0; border-top:1px dashed var(--border-color); width:100%; margin: 5px 0;">

                    <!-- Time of Day Controls -->
                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Change Time of Day?</label>
                            <input type="checkbox" ${node.changeTimeOfDay ? 'checked' : ''} 
                                onchange="getActiveProject().nodes[${nIdx}].changeTimeOfDay = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        ${node.changeTimeOfDay ? `
                            <button class="btn btn-outline" style="padding: 4px 10px; font-size: 0.6rem; margin-left: auto; border-color: var(--accent-orange); color: var(--accent-orange);" 
                                onclick="addTimeChangeRow(${nIdx})">+ Add Time Change</button>
                        ` : ''}
                    </div>
                    
                    ${node.changeTimeOfDay ? (node.timeOfDayChanges || []).map((change, cIdx) => `
                        <div class="state-row">
                            <div class="state-input-group" style="flex:1;">
                                <label>Time</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="updateTimeChange(${nIdx}, ${cIdx}, 'time', this.value)">
                                    <option value="">-- Select Time --</option>
                                    ${globalTimesOfDay.map(s => `<option value="${escapeHtml(s.name)}" ${change.time === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Value</label>
                                <input type="text" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" 
                                    value="${escapeHtml(change.value || '')}" 
                                    onchange="updateTimeChange(${nIdx}, ${cIdx}, 'value', this.value)">
                            </div>
                            ${(node.timeOfDayChanges.length > 1) ? `
                                <span onclick="removeTimeChangeRow(${nIdx}, ${cIdx})" 
                                      style="cursor:pointer; color:var(--accent-pink); font-weight:bold; padding: 0 5px;">×</span>
                            ` : ''}
                        </div>
                    `).join('') : ''}

                    <!-- Days of the Week Controls -->
                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Change Day of Week?</label>
                            <input type="checkbox" ${node.changeDayOfWeek ? 'checked' : ''} 
                                onchange="getActiveProject().nodes[${nIdx}].changeDayOfWeek = this.checked; markNodeEdited(${nIdx}); renderNodes();">
                        </div>
                        ${node.changeDayOfWeek ? `
                            <button class="btn btn-outline" style="padding: 4px 10px; font-size: 0.6rem; margin-left: auto; border-color: var(--accent-orange); color: var(--accent-orange);" 
                                onclick="addDayChangeRow(${nIdx})">+ Add Day Change</button>
                        ` : ''}
                    </div>
                    
                    ${node.changeDayOfWeek ? (node.dayOfWeekChanges || []).map((change, cIdx) => `
                        <div class="state-row">
                            <div class="state-input-group" style="flex:1;">
                                <label>Day</label>
                                <select class="custom-scrollbar" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" onchange="updateDayChange(${nIdx}, ${cIdx}, 'day', this.value)">
                                    <option value="">-- Select Day --</option>
                                    ${globalDaysOfWeek.map(s => `<option value="${escapeHtml(s.name)}" ${change.day === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                </select>
                            </div>
                            <div class="state-input-group" style="flex:1;">
                                <label>Value</label>
                                <input type="text" style="flex:1; padding: 6px 10px; font-size: 0.75rem;" 
                                    value="${escapeHtml(change.value || '')}" 
                                    onchange="updateDayChange(${nIdx}, ${cIdx}, 'value', this.value)">
                            </div>
                            ${(node.dayOfWeekChanges.length > 1) ? `
                                <span onclick="removeDayChangeRow(${nIdx}, ${cIdx})" 
                                      style="cursor:pointer; color:var(--accent-pink); font-weight:bold; padding: 0 5px;">×</span>
                            ` : ''}
                        </div>
                    `).join('') : ''}

                    <!-- Puppet Controls -->
                    <hr style="border:0; border-top:1px dashed var(--border-color); width:100%; margin: 5px 0;">
                    
                    <div class="state-row">
                        <div class="state-input-group">
                            <label>Control Puppets?</label>
                            <input type="checkbox" ${node.controlPuppets ? 'checked' : ''} 
                                onchange="toggleControlPuppets(${nIdx}, this.checked)">
                        </div>
                    </div>

                    ${node.controlPuppets ? `
                        <div style="margin-top: 5px; padding-left: 10px; border-left: 2px solid var(--accent-orange);">
                            
                            <select class="custom-scrollbar" onchange="addPuppetToNode(${nIdx}, this.value)" style="width: 100%; font-size: 0.8rem; padding: 8px;">
                                <option value="">+ Add Character Puppet to Statement</option>
                                ${availablePuppets.map(c => `<option value="${escapeHtml(c.name)}">${escapeHtml(c.name)}</option>`).join('')}
                            </select>

                            <div style="display:flex; flex-wrap:wrap; gap:10px; margin-top:15px;">
                                ${(node.puppets || []).map((p, pIdx) => `
                                    <div class="puppet-tag ${p.enabled ? '' : 'disabled'}">
                                        <input type="checkbox" ${p.enabled ? 'checked' : ''} onchange="togglePuppetEnabled(${nIdx}, ${pIdx}, this.checked)" title="Enable/Disable Puppet">
                                        <span>${escapeHtml(p.name)}</span>
                                        ${p.enabled ? `
                                            <label style="font-size:0.6rem; color:var(--text-dim); margin-left:5px;">POS:</label>
                                            <input type="text" maxlength="2" class="puppet-pos-input" value="${escapeHtml(p.position || '')}" onchange="updatePuppetPosition(${nIdx}, ${pIdx}, this.value)" placeholder="--">
                                        ` : ''}
                                        <span onclick="removePuppetFromNode(${nIdx}, ${pIdx})" style="cursor:pointer; margin-left:5px; color:var(--accent-pink); font-weight:bold;">×</span>
                                    </div>
                                `).join('')}
                            </div>

                            ${(node.puppets || []).length > 0 ? `
                                <div class="state-row" style="margin-top: 15px; flex-wrap: wrap;">
                                    <div class="state-input-group">
                                        <label>Change State?</label>
                                        <input type="checkbox" ${node.changePuppetState ? 'checked' : ''} onchange="toggleChangePuppetState(${nIdx}, this.checked)">
                                    </div>
                                    
                                    ${node.changePuppetState ? `
                                        <div class="state-input-group" style="margin-left: 10px; border-left: 1px dashed var(--border-color); padding-left: 10px;">
                                            <label style="color:var(--accent-teal)">Puppet Use Tag?(Exact Spelling)</label>
                                            <input type="checkbox" ${node.puppetUseTag ? 'checked' : ''} onchange="togglePuppetUseTag(${nIdx}, this.checked)">
                                        </div>
                                        <div class="state-input-group">
                                            <label style="color:var(--accent-orange)">Puppet Use Path?</label>
                                            <input type="checkbox" ${node.puppetUsePath ? 'checked' : ''} onchange="togglePuppetUsePath(${nIdx}, this.checked)">
                                        </div>
                                    ` : ''}

                                    <div class="state-input-group" style="${node.changePuppetState ? 'margin-left: 10px; border-left: 1px dashed var(--border-color); padding-left: 10px;' : ''}">
                                        <label>Change Mood?</label>
                                        <input type="checkbox" ${node.changePuppetMood ? 'checked' : ''} onchange="toggleChangePuppetMood(${nIdx}, this.checked)">
                                    </div>
                                    <div class="state-input-group">
                                        <label>Invert?</label>
                                        <input type="checkbox" ${node.changePuppetInvert ? 'checked' : ''} onchange="toggleChangePuppetInvert(${nIdx}, this.checked)">
                                    </div>
                                </div>

                                ${((node.changePuppetState && (node.puppetUsePath || node.puppetUseTag)) || node.changePuppetMood || node.changePuppetInvert) ? `
                                    <div style="display:flex; flex-direction:column; gap:10px; margin-top:10px;">
                                        ${(node.puppets || []).map((p, pIdx) => `
                                            <div class="puppet-path-row" style="flex-wrap: wrap;">
                                                <span style="font-size:0.75rem; color:var(--accent-teal); min-width:80px; font-weight:bold;">${escapeHtml(p.name)}</span>
                                                
                                                ${(node.changePuppetState && node.puppetUsePath) ? `
                                                    <input type="text" style="flex:1; padding:6px 10px; font-size:0.8rem; min-width: 150px;" 
                                                        value="${escapeHtml(p.path || 'Assets/Resources/Puppets/')}" 
                                                        onchange="updatePuppetPath(${nIdx}, ${pIdx}, this.value)">
                                                ` : ''}
                                                
                                                ${(node.changePuppetState && node.puppetUseTag) ? `
                                                    <select class="custom-scrollbar" style="flex:1; padding:6px; font-size:0.8rem; min-width: 100px;" onchange="updatePuppetState(${nIdx}, ${pIdx}, this.value)">
                                                        <option value="">-- Select State --</option>
                                                        ${globalStates.map(s => `<option value="${escapeHtml(s.name)}" ${p.state === s.name ? 'selected' : ''}>${escapeHtml(s.name)}</option>`).join('')}
                                                    </select>
                                                ` : ''}
                                                
                                                ${node.changePuppetMood ? `
                                                    <select class="custom-scrollbar" style="flex:1; padding:6px; font-size:0.8rem; min-width: 100px;" onchange="updatePuppetMood(${nIdx}, ${pIdx}, this.value)">
                                                        <option value="">-- Select Mood --</option>
                                                        ${globalMoods.map(m => `<option value="${escapeHtml(m.name)}" ${p.mood === m.name ? 'selected' : ''}>${escapeHtml(m.name)}</option>`).join('')}
                                                    </select>
                                                ` : ''}
                                                
                                                ${node.changePuppetInvert ? `
                                                    <div style="display:flex; align-items:center; gap:5px; margin-left:10px;">
                                                        <input type="checkbox" ${p.invert ? 'checked' : ''} onchange="updatePuppetInvert(${nIdx}, ${pIdx}, this.checked)" title="Invert this puppet?">
                                                        <span style="font-size:0.7rem; color:var(--text-dim);">INVERT</span>
                                                    </div>
                                                ` : ''}
                                            </div>
                                        `).join('')}
                                    </div>
                                ` : ''}
                            ` : ''}
                        </div>
                    ` : ''}
                </div>

                <!-- CHANGE GAME STATE SECTION -->
                <div class="logic-block" style="margin-top: 20px; margin-bottom: 0;">
                    <div class="logic-header">
                        <div class="logic-title">Change Game State</div>
                        <button class="logic-add-btn btn-cyan" onclick="addStateChangeRow(${nIdx})">+</button>
                    </div>
                    ${(node.gameStateChanges || []).map((change, cIdx) => `
                        <div class="logic-row">
                            <input type="text" class="logic-input" value="${escapeHtml(change.variable || '')}" oninput="updateStateChange(${nIdx}, ${cIdx}, 'variable', this.value)" placeholder="Variable...">
                            <select class="logic-select" onchange="updateStateChange(${nIdx}, ${cIdx}, 'operator', this.value)">
                                <option value="==" ${change.operator === '==' ? 'selected' : ''}>==</option>
                                <option value="=" ${change.operator === '=' ? 'selected' : ''}>=</option>
                                <option value="+=" ${change.operator === '+=' ? 'selected' : ''}>+=</option>
                                <option value="-=" ${change.operator === '-=' ? 'selected' : ''}>-=</option>
                            </select>
                            <input type="text" class="logic-input" value="${escapeHtml(change.value || '')}" oninput="updateStateChange(${nIdx}, ${cIdx}, 'value', this.value)" placeholder="Value...">
                            <span class="logic-delete" onclick="removeStateChangeRow(${nIdx}, ${cIdx})">×</span>
                        </div>
                    `).join('')}
                </div>

            `;
            container.appendChild(div);
        });

        // Trigger tag rendering loop safely
        renderProjectTags();

        // Trigger the search statement filter so it persists after any DOM re-render
        filterStatements();

        // Update scroll minimap visually
        updateMinimap();
    }

    function renderResponseSection(nIdx, project) {
        const node = project.nodes[nIdx];
        const currentResponses = (node.responses || []).length;
        const remaining = Math.max(0, 4 - currentResponses);
        const isMaxedOut = remaining === 0;

        return `
            <div class="response-section">
                <div>
                    ${(node.responses || []).map((r, rIdx) => {
                        const charData = cast.find(c => c.name === r.speaker) || { color: '#ff007b' };
                        const isLinked = r.nextStatementId && project.nodes.some(n => n.id === r.nextStatementId);
                        const isEditing = editingResponseRef && editingResponseRef.nIdx === nIdx && editingResponseRef.rIdx === rIdx;
                        
                        const hasGameState = r.autoIncrement || (r.gameStateChanges && r.gameStateChanges.some(c => c.variable.trim() !== '' || c.value.trim() !== ''));
                        
                        let attentionStyle = '';
                        if (!isLinked && !hasGameState) {
                            attentionStyle = 'box-shadow: -5px 0 15px #0088ff, 5px 0 15px #ffaa00; outline: 1px solid #777;';
                        } else if (!isLinked) {
                            attentionStyle = 'box-shadow: 0 0 15px #0088ff; outline: 1px solid #0088ff;';
                        } else if (!hasGameState) {
                            attentionStyle = 'box-shadow: 0 0 15px #ffaa00; outline: 1px solid #ffaa00;';
                        }
                        
                        return `
                        <div class="applied-text-item" id="response-item-${nIdx}-${rIdx}" style="--speaker-color: ${charData.color}; flex-direction: column; align-items: stretch; gap: 8px; ${attentionStyle}">
                            
                            <!-- AUTO INCREMENT ROW -->
                            <div style="display:flex; justify-content:flex-end;">
                                <label style="font-size: 0.6rem; color: var(--text-dim); font-weight: 800; text-transform: uppercase; cursor: pointer; display: flex; align-items: center; gap: 5px;">
                                    <input type="checkbox" ${r.autoIncrement ? 'checked' : ''} onchange="toggleResponseAutoIncrement(${nIdx}, ${rIdx}, this.checked)">
                                    Auto Increment
                                </label>
                            </div>

                            <!-- CONDITIONS SECTION (ABOVE RESPONSE TEXT) -->
                            ${(r.conditions && r.conditions.length > 0) ? `
                                <div style="background: rgba(0,0,0,0.5); padding: 8px; border: 1px dashed var(--accent-green); margin-bottom: 5px;">
                                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 8px;">
                                        <span style="font-size: 0.6rem; color: var(--accent-green); font-weight: 900; text-transform: uppercase;">Conditions</span>
                                        <button class="logic-add-btn btn-green" style="width: 20px; height: 20px; font-size: 0.9rem; line-height: 1;" onclick="addResponseConditionRow(${nIdx}, ${rIdx}); event.stopPropagation();">+</button>
                                    </div>
                                    ${r.conditions.map((cond, cIdx) => `
                                        <div style="display:flex; gap:5px; margin-bottom: 5px;" onclick="event.stopPropagation()">
                                            <input type="text" placeholder="Variable..." value="${escapeHtml(cond.variable)}" oninput="updateResponseConditionRow(${nIdx}, ${rIdx}, ${cIdx}, 'variable', this.value)" style="flex:1; padding: 4px 6px; font-size: 0.75rem; background: #000; color: #fff; border: 1px solid var(--border-color);">
                                            <select onchange="updateResponseConditionRow(${nIdx}, ${rIdx}, ${cIdx}, 'operator', this.value)" style="padding: 4px; font-size: 0.75rem; background: #000; color: #fff; border: 1px solid var(--border-color);">
                                                <option value="==" ${cond.operator === '==' ? 'selected' : ''}>==</option>
                                                <option value="!=" ${cond.operator === '!=' ? 'selected' : ''}>!=</option>
                                                <option value=">" ${cond.operator === '>' ? 'selected' : ''}>&gt;</option>
                                                <option value="<" ${cond.operator === '<' ? 'selected' : ''}>&lt;</option>
                                                <option value=">=" ${cond.operator === '>=' ? 'selected' : ''}>&gt;=</option>
                                                <option value="<=" ${cond.operator === '<=' ? 'selected' : ''}>&lt;=</option>
                                            </select>
                                            <input type="text" placeholder="Value..." value="${escapeHtml(cond.value)}" oninput="updateResponseConditionRow(${nIdx}, ${rIdx}, ${cIdx}, 'value', this.value)" style="flex:1; padding: 4px 6px; font-size: 0.75rem; background: #000; color: #fff; border: 1px solid var(--border-color);">
                                            <span onclick="removeResponseConditionRow(${nIdx}, ${rIdx}, ${cIdx}); event.stopPropagation();" style="cursor:pointer; color:var(--accent-pink); padding: 0 4px; font-weight: bold; font-size: 1.2rem; display: flex; align-items: center;">×</span>
                                        </div>
                                    `).join('')}
                                </div>
                            ` : ''}

                            <!-- Top Row (Text and Buttons) -->
                            <div style="display:flex; justify-content:space-between; align-items:center; width:100%;">
                                ${isEditing ? `
                                    <div style="display:flex; flex:1; align-items:center; gap: 8px;">
                                        <select id="edit-speaker-${nIdx}-${rIdx}" class="custom-scrollbar" style="padding: 4px; background: #111; color: #fff; border: 1px solid var(--accent-teal); font-size: 0.8rem; max-width: 100px;">
                                            ${project.participants.map(p => `<option value="${escapeHtml(p)}" ${p === r.speaker ? 'selected' : ''}>${escapeHtml(p)}</option>`).join('')}
                                        </select>
                                        <input type="text" class="edit-response-input" id="edit-input-${nIdx}-${rIdx}" value="${escapeHtml(r.text)}" />
                                        <button class="save-edit-btn" onclick="saveEditedResponse(${nIdx}, ${rIdx})" title="Save Change">
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                                        </button>
                                    </div>
                                ` : `
                                    <span style="display:flex; align-items:center; flex:1; ${isLinked ? 'cursor:pointer;' : ''}" 
                                          ondblclick="startEditingResponse(${nIdx}, ${rIdx})"
                                          ${isLinked ? `onclick="scrollToNode('${r.nextStatementId}'); event.stopPropagation();" title="Jump to Linked Statement"` : ''}>
                                        <strong style="color:${charData.color}; cursor:pointer;" onclick="startEditingResponse(${nIdx}, ${rIdx}); event.stopPropagation();">${escapeHtml(r.speaker)}:</strong> 
                                        <span style="cursor:pointer; ${isLinked ? 'text-decoration: underline; text-decoration-color: var(--text-dim); text-underline-offset: 3px; color: var(--accent-teal);' : ''}" onclick="startEditingResponse(${nIdx}, ${rIdx}); event.stopPropagation();">${escapeHtml(r.text)}</span>
                                        ${isLinked ? `<button style="margin-left:10px; background:var(--accent-teal); color:#000; border:none; padding:2px 8px; font-size:0.6rem; font-weight:800; border-radius:2px; cursor:pointer;" onclick="scrollToNode('${r.nextStatementId}'); event.stopPropagation();">JUMP ↳</button>` : ''}
                                    </span>
                                `}

                                <div style="display:flex; align-items:center; gap:10px; margin-left:10px;">
                                    ${!isEditing ? `
                                        <button class="btn btn-outline" style="padding: 4px 8px; font-size: 0.6rem; color: var(--accent-teal); border-color: var(--accent-teal);" onclick="startEditingResponse(${nIdx}, ${rIdx}); event.stopPropagation();" title="Edit Response">Edit</button>
                                        
                                        ${!isLinked ? `
                                            <select class="custom-scrollbar" onchange="linkExistingStatement(${nIdx}, ${rIdx}, this.value); event.stopPropagation();" style="padding: 4px; background: #000; color: var(--text-dim); border: 1px solid var(--border-color); font-size: 0.6rem; max-width: 130px; outline: none; cursor: pointer;">
                                                <option value="">Link to existing...</option>
                                                ${project.nodes.map((n, i) => `<option value="${n.id}">Statement #${i + 1} [node_id:${n.id.substring(0,8)}...] (${escapeHtml(n.speaker || '?')})</option>`).join('')}
                                            </select>
                                        ` : `
                                            <button class="btn btn-outline" style="padding: 4px 8px; font-size: 0.6rem; color: var(--accent-pink); border-color: var(--accent-pink);" onclick="unlinkResponse(${nIdx}, ${rIdx}); event.stopPropagation();">
                                                Unlink
                                            </button>
                                        `}

                                        <button class="btn btn-outline" 
                                            ${isLinked ? 'disabled' : ''}
                                            style="padding: 4px 8px; font-size: 0.6rem;" 
                                            onclick="createReplyStatement(${nIdx}, ${rIdx}); event.stopPropagation();">
                                            ${isLinked ? 'Statement Linked' : 'Reply Statement'}
                                        </button>
                                    ` : ''}
                                    
                                    ${currentResponses > 1 ? `
                                    <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; min-width: 15px;">
                                        ${rIdx > 0 ? `<span style="cursor:pointer; color:var(--text-dim); font-size: 0.7rem; line-height: 1;" onclick="moveResponseUp(${nIdx}, ${rIdx}); event.stopPropagation();" onmouseover="this.style.color='var(--accent-teal)'" onmouseout="this.style.color='var(--text-dim)'">▲</span>` : `<span style="height: 0.7rem;"></span>`}
                                        ${rIdx < currentResponses - 1 ? `<span style="cursor:pointer; color:var(--text-dim); font-size: 0.7rem; line-height: 1;" onclick="moveResponseDown(${nIdx}, ${rIdx}); event.stopPropagation();" onmouseover="this.style.color='var(--accent-teal)'" onmouseout="this.style.color='var(--text-dim)'">▼</span>` : `<span style="height: 0.7rem;"></span>`}
                                    </div>
                                    ` : ''}
                                    
                                    <span onclick="removeResponse(${nIdx}, ${rIdx}); event.stopPropagation();" 
                                        style="cursor:pointer; color:var(--accent-pink); font-weight:bold; padding-left:5px; font-size: 1.2rem;">×</span>
                                </div>
                            </div>
                            
                            <!-- Bottom Row (Action Toggles) -->
                            <div style="display: flex; gap: 15px; padding-top: 8px; border-top: 1px dashed #333;">
                                <button class="btn btn-outline" style="padding: 3px 8px; font-size: 0.6rem; color: var(--accent-green); border-color: var(--accent-green);" onclick="addResponseConditionRow(${nIdx}, ${rIdx}); event.stopPropagation();">+ Add Condition</button>
                                <button class="btn btn-outline" style="padding: 3px 8px; font-size: 0.6rem; color: var(--accent-cyan); border-color: var(--accent-cyan);" onclick="addResponseStateChangeRow(${nIdx}, ${rIdx}); event.stopPropagation();">+ Change Game State</button>
                            </div>

                            <!-- GAME STATE CHANGES SECTION (BELOW RESPONSE TEXT) -->
                            ${(r.gameStateChanges && r.gameStateChanges.length > 0) ? `
                                <div style="background: rgba(0,0,0,0.5); padding: 8px; border: 1px dashed var(--accent-cyan); margin-top: 5px;">
                                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 8px;">
                                        <span style="font-size: 0.6rem; color: var(--accent-cyan); font-weight: 900; text-transform: uppercase;">Change Game State</span>
                                        <button class="logic-add-btn btn-cyan" style="width: 20px; height: 20px; font-size: 0.9rem; line-height: 1;" onclick="addResponseStateChangeRow(${nIdx}, ${rIdx}); event.stopPropagation();">+</button>
                                    </div>
                                    ${r.gameStateChanges.map((change, cIdx) => `
                                        <div style="display:flex; gap:5px; margin-bottom: 5px;" onclick="event.stopPropagation()">
                                            <input type="text" placeholder="Variable..." value="${escapeHtml(change.variable)}" oninput="updateResponseStateChangeRow(${nIdx}, ${rIdx}, ${cIdx}, 'variable', this.value)" style="flex:1; padding: 4px 6px; font-size: 0.75rem; background: #000; color: #fff; border: 1px solid var(--border-color);">
                                            <select onchange="updateResponseStateChangeRow(${nIdx}, ${rIdx}, ${cIdx}, 'operator', this.value)" style="padding: 4px; font-size: 0.75rem; background: #000; color: #fff; border: 1px solid var(--border-color);">
                                                <option value="=" ${change.operator === '=' ? 'selected' : ''}>=</option>
                                                <option value="+=" ${change.operator === '+=' ? 'selected' : ''}>+=</option>
                                                <option value="-=" ${change.operator === '-=' ? 'selected' : ''}>-=</option>
                                            </select>
                                            <input type="text" placeholder="Value..." value="${escapeHtml(change.value)}" oninput="updateResponseStateChangeRow(${nIdx}, ${rIdx}, ${cIdx}, 'value', this.value)" style="flex:1; padding: 4px 6px; font-size: 0.75rem; background: #000; color: #fff; border: 1px solid var(--border-color);">
                                            <span onclick="removeResponseStateChangeRow(${nIdx}, ${rIdx}, ${cIdx}); event.stopPropagation();" style="cursor:pointer; color:var(--accent-pink); padding: 0 4px; font-weight: bold; font-size: 1.2rem; display: flex; align-items: center;">×</span>
                                        </div>
                                    `).join('')}
                                </div>
                            ` : ''}

                        </div>
                    `}).join('')}
                </div>
                <div style="display:flex; gap:10px; margin-top:10px;">
                    <select id="resp-speaker-${nIdx}" class="custom-scrollbar" style="width:30%" ${isMaxedOut ? 'disabled' : ''}>
                        ${project.participants.map(p => `<option value="${escapeHtml(p)}">${escapeHtml(p)}</option>`).join('')}
                    </select>
                    <input type="text" id="resp-input-${nIdx}" placeholder="${isMaxedOut ? 'Max 4 responses reached...' : 'Response Text...'}" style="flex:1;" ${isMaxedOut ? 'disabled' : ''}>
                    <button class="btn btn-teal" onclick="applyResp(${nIdx})" ${isMaxedOut ? 'disabled' : ''}>APPLY (${remaining} LEFT)</button>
                </div>
            </div>
        `;
    }

    function filterStatements() {
        const input = document.getElementById('search-statements');
        if (!input) return;
        const term = input.value.toLowerCase().trim();
        const project = getActiveProject();
        if (!project) return;
        
        project.nodes.forEach((node, nIdx) => {
            const el = document.getElementById(`node-${node.id}`);
            if (!el) return;
            
            if (!term) {
                el.style.display = ''; // Reset
                return;
            }
            
            const searchStr = `${node.speaker || ''} ${node.text || ''} ${node.id}`.toLowerCase();
            let isMatch = searchStr.includes(term);
            
            if (!isMatch && node.responses) {
                isMatch = node.responses.some(r => `${r.speaker || ''} ${r.text || ''}`.toLowerCase().includes(term));
            }
            
            el.style.display = isMatch ? '' : 'none';
        });
        updateMinimap();
    }

    function removeResponse(nIdx, rIdx) {
        if (activeIndex === null) return;
        const project = getActiveProject();
        const response = project.nodes[nIdx].responses[rIdx];
        
        if (response.nextStatementId) {
            const targetNode = project.nodes.find(n => n.id === response.nextStatementId);
            if (targetNode && targetNode.parentResponseId === response.id) {
                targetNode.parentResponseId = null;
                targetNode.parentResponsePreview = null;
            }
        }
        
        project.nodes[nIdx].responses.splice(rIdx, 1);
        markNodeEdited(nIdx);
        renderNodes();
    }

    function startEditingResponse(nIdx, rIdx) {
        editingResponseRef = { nIdx, rIdx };
        renderNodes();
        setTimeout(() => {
            const input = document.getElementById(`edit-input-${nIdx}-${rIdx}`);
            if (input) {
                input.focus();
                input.selectionStart = input.selectionEnd = input.value.length;
                input.addEventListener('keypress', (e) => {
                    if (e.key === 'Enter') saveEditedResponse(nIdx, rIdx);
                });
            }
        }, 0);
    }

    function saveEditedResponse(nIdx, rIdx) {
        const input = document.getElementById(`edit-input-${nIdx}-${rIdx}`);
        const speakerSelect = document.getElementById(`edit-speaker-${nIdx}-${rIdx}`);
        
        if (input && speakerSelect) {
            const project = getActiveProject();
            project.nodes[nIdx].responses[rIdx].text = input.value.trim();
            project.nodes[nIdx].responses[rIdx].speaker = speakerSelect.value;
            
            const response = project.nodes[nIdx].responses[rIdx];
            if (response.nextStatementId) {
                const targetNode = project.nodes.find(n => n.id === response.nextStatementId);
                if (targetNode) {
                    targetNode.parentResponsePreview = `${response.speaker}: ${response.text.substring(0, 30)}${response.text.length > 30 ? '...' : ''}`;
                }
            }
        }
        editingResponseRef = null;
        markNodeEdited(nIdx);
        renderNodes();
    }

    function applyResp(nIdx) {
        const node = getActiveProject().nodes[nIdx];
        if ((node.responses || []).length >= 4) {
            showNotification("Maximum 4 responses allowed.", true);
            return;
        }

        const textInput = document.getElementById(`resp-input-${nIdx}`);
        const speakerSelect = document.getElementById(`resp-speaker-${nIdx}`);
        if (!textInput || !textInput.value.trim()) return;
        
        node.responses.push({ 
            id: crypto.randomUUID(),
            speaker: speakerSelect.value, 
            text: textInput.value,
            nextStatementId: null,
            conditions: [],
            gameStateChanges: [],
            autoIncrement: false
        });
        markNodeEdited(nIdx);
        renderNodes();
        textInput.value = '';
    }

    function createReplyStatement(nodeIndex, responseIndex) {
        const project = getActiveProject();
        const response = project.nodes[nodeIndex].responses[responseIndex];
        
        if (response.nextStatementId && project.nodes.some(n => n.id === response.nextStatementId)) return;
        
        const preview = `${response.speaker}: ${response.text.substring(0, 30)}${response.text.length > 30 ? '...' : ''}`;
        
        // Pass nodeIndex + 1 to splice the new statement immediately below this one
        const newNodeId = addDialogueNode(response.id, preview, nodeIndex + 1);
        response.nextStatementId = newNodeId;
        
        markNodeEdited(nodeIndex);
        renderNodes();
        setTimeout(() => scrollToElement(`node-${newNodeId}`), 50);
    }

    // --- IO ---
    function extractProjectVariables(project) {
        const p = JSON.parse(JSON.stringify(project));
        const vars = new Set();
        
        p.nodes.forEach(n => {
            (n.conditions || []).forEach(c => { if(c.variable && c.variable.trim()) vars.add(c.variable.trim()); });
            (n.gameStateChanges || []).forEach(c => { if(c.variable && c.variable.trim()) vars.add(c.variable.trim()); });
            (n.responses || []).forEach(r => {
                (r.conditions || []).forEach(c => { if(c.variable && c.variable.trim()) vars.add(c.variable.trim()); });
                (r.gameStateChanges || []).forEach(c => { if(c.variable && c.variable.trim()) vars.add(c.variable.trim()); });
            });
        });
        
        p.activeLogicVariables = Array.from(vars);
        return p;
    }

    function exportProjectJSON() {
        const processedConversations = conversations.map(c => extractProjectVariables(c));
        const processedSequences = sequences.map(s => extractProjectVariables(s));

        const projectData = { version: "2.18", cast, globalTokens, globalStates, globalMoods, globalSettings, globalTimesOfDay, globalDaysOfWeek, globalMenuOptions, globalImageSequences, conversations: processedConversations, sequences: processedSequences };
        const blob = new Blob([JSON.stringify(projectData, null, 2)], {type: "application/json"});
        const url = URL.createObjectURL(blob);
        const dl = document.createElement('a');
        
        const now = new Date();
        const dateStr = now.toISOString().slice(0, 10);
        const timeStr = now.toISOString().slice(11, 19).replace(/:/g, '-');

        dl.href = url;
        dl.download = `DialogueDesigner_Export_${dateStr}_${timeStr}.json`;
        dl.click();
        URL.revokeObjectURL(url);
        showNotification("Project Exported");
    }

    function normalizeProject(c) {
        if (c.title === undefined) c.title = "Imported Project";
        if (c.participants === undefined) c.participants = [];
        if (c.nodes === undefined) c.nodes = [];
        if (c.isRepeatable === undefined) c.isRepeatable = false;
        if (c.repeatVariable === undefined) c.repeatVariable = '';
        if (c.color === undefined) c.color = getRandomColor();

        c.nodes.forEach(n => {
            if (!n.id) n.id = crypto.randomUUID();
            
            // Self-healing migration for node conditions & game states
            if (!n.conditions) n.conditions = [];
            
            if (!n.gameStateChanges) n.gameStateChanges = [];
            if (n.changeGameState !== undefined || n.gameStateVar !== undefined) {
                 const v = n.gameStateVar;
                 if (v && v.trim() !== '' && !n.gameStateChanges.some(gsc => gsc.variable === v)) {
                     n.gameStateChanges.push({ variable: v, operator: '==', value: n.gameStateVal || '' });
                 }
            }
            
            if (n.speaker === undefined) n.speaker = '';
            
            if (n.externalCall === undefined) n.externalCall = false;
            if (n.advancedOpen === undefined) n.advancedOpen = false;
            
            if (n.resourcePath === undefined) n.resourcePath = 'Assets/Resources/Slides/';
            if (n.usePath === undefined) n.usePath = false;
            
            if (n.closeMainMenu === undefined) n.closeMainMenu = false;
            if (n.closePromptPanel === undefined) n.closePromptPanel = false;
            if (n.openPromptPanel === undefined) n.openPromptPanel = false;
            if (n.closeDialogueMenu === undefined) n.closeDialogueMenu = false;

            if (n.changeTimeOfDay === undefined) n.changeTimeOfDay = false;
            if (n.timeOfDayChanges === undefined) n.timeOfDayChanges = [{ time: '', value: '' }];
            
            if (n.changeDayOfWeek === undefined) n.changeDayOfWeek = false;
            if (n.dayOfWeekChanges === undefined) n.dayOfWeekChanges = [{ day: '', value: '' }];
            
            if (n.changeMenuOption === undefined) n.changeMenuOption = false;
            if (n.menuOptionChanges === undefined) n.menuOptionChanges = [{ menu: '', value: '' }];
            
            n.gameStateChanges.forEach(gsc => {
                if(gsc.operator === undefined) gsc.operator = '==';
            });
            delete n.changeGameState;
            delete n.gameStateVar;
            delete n.gameStateVal;

            if (n.changeSetting === undefined) n.changeSetting = false;
            if (n.settingChanges === undefined) n.settingChanges = [{ setting: '', value: '' }];

            if (n.controlSequence === undefined) n.controlSequence = false;
            if (n.sequenceName === undefined) n.sequenceName = '';
            if (n.sequenceImage === undefined) n.sequenceImage = '';

            if (n.controlPuppets === undefined) n.controlPuppets = false;
            
            if (n.changePuppets !== undefined) {
                n.puppetUsePath = n.changePuppets;
                delete n.changePuppets;
            } else if (n.puppetUsePath === undefined) {
                n.puppetUsePath = false;
            }
            if (n.puppetUseTag === undefined) n.puppetUseTag = false;

            if (n.changePuppetState === undefined) n.changePuppetState = false;
            if (n.changePuppetMood === undefined) n.changePuppetMood = false;
            if (n.changePuppetInvert === undefined) n.changePuppetInvert = false;
            if (n.puppets === undefined) n.puppets = [];

            n.puppets.forEach(p => {
                if (p.name === undefined) p.name = '';
                if (p.enabled === undefined) p.enabled = true;
                if (p.position === undefined) p.position = '';
                if (p.path === undefined) p.path = 'Assets/Resources/Puppets/';
                if (p.state === undefined) p.state = '';
                if (p.mood === undefined) p.mood = '';
                if (p.invert === undefined) p.invert = false;
            });
            
            if (n.textFormat === undefined) {
                n.textFormat = { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
            }

            if (n.canPlayerRespond === undefined) n.canPlayerRespond = false;
            if (n.responses === undefined) n.responses = [];
            if (n.parentResponseId === undefined) n.parentResponseId = null;
            if (n.parentResponsePreview === undefined) n.parentResponsePreview = null;
            
            n.responses.forEach(r => {
                if (!r.id) r.id = crypto.randomUUID();
                if (r.speaker === undefined) r.speaker = '';
                if (r.text === undefined) r.text = '';
                if (r.nextStatementId === undefined) r.nextStatementId = null;
                if (r.autoIncrement === undefined) r.autoIncrement = false;
                
                // MULTI-ARRAY MIGRATION: Translate old logic values into logic arrays seamlessly
                if (!r.conditions) r.conditions = [];
                if (r.requiresCondition && r.conditionKey) {
                    if (!r.conditions.some(cond => cond.variable === r.conditionKey)) {
                        r.conditions.push({ variable: r.conditionKey, operator: r.conditionOp || '==', value: r.conditionVal || '' });
                    }
                }
                
                if (!r.gameStateChanges) r.gameStateChanges = [];
                if (r.changesGameState && r.gameStateKey) {
                    if (!r.gameStateChanges.some(gsc => gsc.variable === r.gameStateKey)) {
                        r.gameStateChanges.push({ variable: r.gameStateKey, operator: r.gameStateOp || '=', value: r.gameStateVal || '' });
                    }
                }

                // Purge the old single-variable keys safely from objects if they exist
                delete r.requiresCondition;
                delete r.conditionKey;
                delete r.conditionOp;
                delete r.conditionVal;
                delete r.changesGameState;
                delete r.gameStateKey;
                delete r.gameStateOp;
                delete r.gameStateVal;
            });
        });
    }

    function importProjectJSON(input) {
        const file = input.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = JSON.parse(e.target.result);
                cast = data.cast || [];
                globalTokens = data.globalTokens || [];
                
                // Migrate legacies to objects
                globalStates = (data.globalStates || []).map(s => typeof s === 'string' ? {name: s, color: getRandomColor()} : s);
                globalMoods = (data.globalMoods || []).map(m => typeof m === 'string' ? {name: m, color: getRandomColor()} : m);
                globalSettings = (data.globalSettings || []).map(s => typeof s === 'string' ? {name: s, color: getRandomColor()} : s);
                
                // Extract the new variables gracefully
                globalTimesOfDay = (data.globalTimesOfDay || []).map(s => typeof s === 'string' ? {name: s, color: getRandomColor()} : s);
                globalDaysOfWeek = (data.globalDaysOfWeek || []).map(s => typeof s === 'string' ? {name: s, color: getRandomColor()} : s);
                globalMenuOptions = (data.globalMenuOptions || []).map(s => typeof s === 'string' ? {name: s, color: getRandomColor()} : s);
                
                globalImageSequences = data.globalImageSequences || [];

                conversations = data.conversations || [];
                sequences = data.sequences || [];
                
                conversations.forEach(normalizeProject);
                sequences.forEach(normalizeProject);

                // Self-healing: if sequences were imported that don't have matching globalImageSequences, create them.
                sequences.forEach(seq => {
                    if (!globalImageSequences.some(s => s.name === seq.title)) {
                        globalImageSequences.push({ name: seq.title, color: seq.color || getRandomColor(), images: [] });
                    }
                });

                activeIndex = null;
                renderTokens();
                renderCast();
                renderStates();
                renderMoods();
                renderSettings();
                renderTimesOfDay();
                renderDaysOfWeek();
                renderMenuOptions();
                renderImageSequences();
                renderConversations();
                renderSequences();
                document.getElementById('active-editor-content').style.display = 'none';
                document.getElementById('editor-placeholder').style.display = 'block';
                showNotification("Project Imported");
            } catch (err) {
                console.error("Import failed", err);
                showNotification("Failed to import JSON", true);
            }
        };
        reader.readAsText(file);
        input.value = '';
    }

    function showNotification(text, isError = false) {
        const notif = document.getElementById('notification');
        notif.innerText = text;
        if (isError) notif.style.background = 'var(--accent-pink)';
        else notif.style.background = 'var(--accent-teal)';
        notif.classList.add('show');
        setTimeout(() => notif.classList.remove('show'), 3000);
    }

    function escapeHtml(text) {
        if (!text && text !== "") return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }