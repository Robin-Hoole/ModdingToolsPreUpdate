/**
 * PD_IO.js
 * Data pipeline for JSON Export, Project Import, and sync with Dialogue Designer exports.
 */

// --- IO ---
function importDialogues(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            
            const mapConfig = [
                { dKey: 'cast', pKey: 'globalCast', nameKey: 'name' },
                { dKey: 'globalStates', pKey: 'globalStates', nameKey: 'name' },
                { dKey: 'globalMoods', pKey: 'globalMoods', nameKey: 'name' },
                { dKey: 'globalSettings', pKey: 'globalSettings', nameKey: 'name' },
                { dKey: 'globalTimesOfDay', pKey: 'timesOfDay', nameKey: 'name' },
                { dKey: 'globalDaysOfWeek', pKey: 'daysOfWeek', nameKey: 'name' },
                { dKey: 'globalMenuOptions', pKey: 'menuOptions', nameKey: 'name' },
                { dKey: 'sequences', pKey: 'imageSequences', nameKey: 'title' }
            ];

            let itemsAdded = 0;

            mapConfig.forEach(config => {
                const sourceArray = data[config.dKey];
                if (sourceArray && Array.isArray(sourceArray)) {
                    sourceArray.forEach(item => {
                        let itemName = item[config.nameKey] || item.name || item.title || item.time || item.day || item.setting || item.menu || Object.values(item).find(v => typeof v === 'string') || "Unnamed";
                        let itemColor = item.color || getRandomHex();

                        if (itemName === "Unnamed" || itemName.trim() === "") return;

                        const existing = projectData[config.pKey].find(i => i.name.toLowerCase() === itemName.toLowerCase());
                        if (!existing) {
                            projectData[config.pKey].push({
                                id: crypto.randomUUID(),
                                name: itemName,
                                color: itemColor
                            });
                            itemsAdded++;
                        }
                    });
                }
            });

            renderGlobalSections();
            showNotification(`Imported ${itemsAdded} Global Items from Dialogues.`);
        } catch (err) {
            console.error(err);
            showNotification("Import Failed: Invalid Dialogue JSON");
        }
    };
    reader.readAsText(file);
    input.value = '';
}

function exportProject() {
    const now = new Date();
    const pad = num => String(num).padStart(2, '0');
    const dateStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
    const timeStr = `${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`;
    
    const activeLogicData = getProjectLogic().map(l => {
        let usage = "Unknown";
        if (l.isCondition && l.isStateChange) {
            usage = "Mixed Usage";
        } else if (l.isCondition) {
            usage = "Condition Only";
        } else if (l.isStateChange) {
            usage = "State Change Only";
        }

        return {
            key: l.key,
            operator: l.op,
            value: l.val,
            format: `${l.key} ${l.op} ${l.val}`,
            totalReferences: l.uses.length,
            usageClassification: usage
        };
    });

    if (typeof window.pdEnsureProject === 'function') window.pdEnsureProject();
    // Deep clone data to avoid structurally mutating live state.
    const exportObj = typeof window.pdPromptPayload === 'function'
        ? window.pdPromptPayload()
        : JSON.parse(JSON.stringify(projectData));
    
    // Inject continuous listIndex to position tags strictly for exporting
    let continuousPosIdx = 0;
    if (exportObj.positionTypes) {
        exportObj.positionTypes.forEach(pt => {
            if(pt.tags) {
                pt.tags.forEach((tag) => {
                    tag.listIndex = continuousPosIdx++;
                });
            }
        });
    }

    exportObj["Active Project Logic"] = activeLogicData;
    exportObj.exportTime = now.toISOString();
    exportObj.version = "3.0-PROMPT-ADVANCED";
    exportObj["Prompt Designer Advanced Cache"] = { note: "Prompt and response advanced data is stored directly on prompts/buttons and mirrored to FSG_PD_PromptAdvanced / FSG_PD_ResponseAdvanced on server push." };
    
    const blob = new Blob([JSON.stringify(exportObj, null, 2)], {type: "application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.download = `PromptDesigner_Export_${dateStr}_${timeStr}.json`;
    a.href = url;
    a.click();
    URL.revokeObjectURL(url);
    showNotification("Project Exported");
}



function pdDeepCloneForImport(value) {
    return JSON.parse(JSON.stringify(value || null));
}

function pdSidebarUniqueKey(item, key) {
    if (!item || typeof item !== 'object') return '';
    if (key === 'tokens') return String(item.key || item.token_key || item.name || '').trim().toLowerCase();
    if (key === 'tags') return String(item.name || item.tag_name || '').trim().toLowerCase();
    if (key === 'positionTypes') return String(item.name || item.type_name || item.id || '').trim().toLowerCase();
    if (key === 'imageSequences') return String(item.name || item.sequence_name || item.title || item.id || '').trim().toLowerCase();
    return String(item.name || item.item_name || item.character_name || item.title || item.id || '').trim().toLowerCase();
}

function pdMergeSidebarArray(existingValue, importedValue, key) {
    const existing = Array.isArray(existingValue) ? pdDeepCloneForImport(existingValue) : [];
    const imported = Array.isArray(importedValue) ? pdDeepCloneForImport(importedValue) : [];
    if (imported.length === 0) return existing;

    const output = existing.slice();
    const indexByKey = new Map();
    output.forEach((item, idx) => {
        const mapKey = pdSidebarUniqueKey(item, key);
        if (mapKey) indexByKey.set(mapKey, idx);
    });

    imported.forEach(item => {
        if (!item || typeof item !== 'object') return;
        const mapKey = pdSidebarUniqueKey(item, key);
        if (!mapKey || !indexByKey.has(mapKey)) {
            output.push(item);
            if (mapKey) indexByKey.set(mapKey, output.length - 1);
            return;
        }

        if (key === 'positionTypes') {
            const existingItem = output[indexByKey.get(mapKey)];
            if (!Array.isArray(existingItem.tags)) existingItem.tags = [];
            existingItem.tags = pdMergeSidebarArray(existingItem.tags, item.tags || [], 'tags');
        }

        if (key === 'imageSequences') {
            const existingItem = output[indexByKey.get(mapKey)];
            if (!Array.isArray(existingItem.images)) existingItem.images = [];
            existingItem.images = pdMergeSidebarArray(existingItem.images, item.images || [], 'imageSequenceImages');
            if (!existingItem.path && item.path) existingItem.path = item.path;
            if (!existingItem.rootPath && item.rootPath) existingItem.rootPath = item.rootPath;
        }
    });

    return output;
}

function pdApplyAdditiveSidebarImport(importedData, currentData) {
    const incoming = importedData && typeof importedData === 'object' ? importedData : {};
    const current = currentData && typeof currentData === 'object' ? currentData : {};
    const sidebarKeys = ['tokens', 'tags', 'positionTypes', 'globalFrames', 'globalCast', 'globalStates', 'globalMoods', 'globalSettings', 'timesOfDay', 'daysOfWeek', 'menuOptions', 'imageSequences'];

    sidebarKeys.forEach(key => {
        incoming[key] = pdMergeSidebarArray(current[key], incoming[key], key);
    });

    if (Array.isArray(current.availableLanguages) || Array.isArray(incoming.availableLanguages)) {
        const langs = new Set([...(current.availableLanguages || []), ...(incoming.availableLanguages || [])].map(v => String(v || '').trim().toUpperCase()).filter(Boolean));
        if (!langs.has('ENG')) langs.add('ENG');
        incoming.availableLanguages = Array.from(langs);
    }

    if (!incoming.currentLanguage && current.currentLanguage) incoming.currentLanguage = current.currentLanguage;
    if (!incoming.serverSessionId && current.serverSessionId) incoming.serverSessionId = current.serverSessionId;
    if (!incoming.dialogueSessionId && current.dialogueSessionId) incoming.dialogueSessionId = current.dialogueSessionId;

    return incoming;
}


function pdGenerateIdForImport() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
    return 'pd-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 12);
}

function pdNormalizeLangForImport(value) {
    return (String(value || 'ENG').replace(/[^A-Za-z0-9_-]/g, '').toUpperCase().slice(0, 8) || 'ENG');
}

function pdAsImportArray(value) {
    if (Array.isArray(value)) return value;
    if (value && typeof value === 'object') return Object.values(value);
    return [];
}

function pdBoolForImport(value, fallback = false) {
    if (value === undefined || value === null || value === '') return fallback;
    if (typeof value === 'boolean') return value;
    if (typeof value === 'number') return value !== 0;
    const s = String(value).trim().toLowerCase();
    if (['true', '1', 'yes', 'y', 'on'].includes(s)) return true;
    if (['false', '0', 'no', 'n', 'off'].includes(s)) return false;
    return fallback;
}

function pdStringForImport(value, fallback = '') {
    if (value === undefined || value === null) return fallback;
    return String(value);
}

function pdColorForImport(value, fallback) {
    const v = String(value || '').trim();
    if (/^#[0-9a-fA-F]{6}$/.test(v)) return v;
    if (/^#[0-9a-fA-F]{3}$/.test(v)) return '#' + v.slice(1).split('').map(ch => ch + ch).join('');
    return fallback || getRandomHex();
}

function pdNumberForImport(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
}

function pdNormalizeLogicEntryForImport(entry) {
    if (!entry) return null;
    if (typeof entry === 'string') {
        const match = entry.match(/^\s*([^=!<>+\-]+?)\s*(==|!=|>=|<=|>|<|\+=|-=|=|\+|-)\s*(.*?)\s*$/);
        if (match) return { key: match[1].trim(), op: match[2].trim(), val: match[3].trim() };
        const key = entry.trim();
        return key ? { key, op: '==', val: '1' } : null;
    }
    if (typeof entry !== 'object') return null;
    const hasLogicShape = ['key', 'variable', 'name', 'state', 'token', 'id', 'op', 'operator', 'comparison', 'operation', 'val', 'value', 'amount', 'target']
        .some(field => Object.prototype.hasOwnProperty.call(entry, field));
    const key = pdStringForImport(entry.key ?? entry.variable ?? entry.name ?? entry.state ?? entry.token ?? entry.id, '').trim();
    const op = pdStringForImport(entry.op ?? entry.operator ?? entry.comparison ?? entry.operation ?? '==', '==').trim() || '==';
    const val = pdStringForImport(entry.val ?? entry.value ?? entry.amount ?? entry.target ?? '', '');
    if (!key && !val && !hasLogicShape) return null;
    return { key, op, val };
}

function pdNormalizeLogicArrayForImport(value) {
    return pdAsImportArray(value).map(pdNormalizeLogicEntryForImport).filter(Boolean);
}

function pdNormalizeTextFormatForImport(value) {
    const f = value && typeof value === 'object' ? value : {};
    return {
        bold: pdBoolForImport(f.bold, false),
        italic: pdBoolForImport(f.italic, false),
        underline: pdBoolForImport(f.underline, false),
        strikethrough: pdBoolForImport(f.strikethrough, false),
        listStyle: ['none', 'bullet', 'number'].includes(f.listStyle) ? f.listStyle : 'none',
        alignH: ['left', 'center', 'right', 'justify'].includes(f.alignH) ? f.alignH : 'left',
        alignV: ['top', 'middle', 'bottom'].includes(f.alignV) ? f.alignV : 'top'
    };
}

function pdNormalizeTranslationBagForImport(existing, fields, defaultsByField) {
    const out = existing && typeof existing === 'object' && !Array.isArray(existing) ? pdDeepCloneForImport(existing) : {};
    const languages = Array.isArray(projectData?.availableLanguages) ? projectData.availableLanguages : ['ENG'];
    languages.forEach(rawLang => {
        const lang = pdNormalizeLangForImport(rawLang);
        if (!out[lang] || typeof out[lang] !== 'object') out[lang] = {};
        fields.forEach(field => {
            if (out[lang][field] === undefined) out[lang][field] = lang === 'ENG' ? pdStringForImport(defaultsByField[field], '') : '';
        });
    });
    if (!out.ENG || typeof out.ENG !== 'object') out.ENG = {};
    fields.forEach(field => {
        if (out.ENG[field] === undefined) out.ENG[field] = pdStringForImport(defaultsByField[field], '');
    });
    return out;
}

function pdNormalizeButtonForImport(rawButton) {
    const b = rawButton && typeof rawButton === 'object' ? rawButton : {};
    const text = pdStringForImport(b.text ?? b.buttonText ?? b.label ?? b.title ?? 'Continue', 'Continue');
    const branchPromptId = b.branchPromptId ?? b.branchId ?? b.nextPromptId ?? b.targetPromptId ?? null;
    const externalUrl = pdStringForImport(b.externalUrl ?? b.url ?? b.link ?? '', '');
    const out = Object.assign({}, b, {
        id: pdStringForImport(b.id || b.buttonId || '', '').trim() || pdGenerateIdForImport(),
        text,
        stateChanges: pdNormalizeLogicArrayForImport(b.stateChanges ?? b.gameStateChanges ?? b.stateChange ?? b.changes),
        conditions: pdNormalizeLogicArrayForImport(b.conditions ?? b.condition),
        isBranching: pdBoolForImport(b.isBranching, !!branchPromptId),
        branchPromptId,
        closeMenu: pdBoolForImport(b.closeMenu ?? b.winClosePromptPanel, false),
        isExternalLink: pdBoolForImport(b.isExternalLink, !!externalUrl),
        externalUrl,
        advancedOpen: pdBoolForImport(b.advancedOpen, false),
        calledExternally: pdBoolForImport(b.calledExternally, false),
        externallyCall: pdBoolForImport(b.externallyCall, false),
        voiceLine: pdBoolForImport(b.voiceLine, false),
        isCollapsed: pdBoolForImport(b.isCollapsed, false),
        conditionsOpen: pdBoolForImport(b.conditionsOpen, true),
        statesOpen: pdBoolForImport(b.statesOpen, true),
        ddAdvancedOpen: pdBoolForImport(b.ddAdvancedOpen, false)
    });
    out.translations = pdNormalizeTranslationBagForImport(b.translations, ['text'], { text });
    return out;
}

function pdNormalizeFrameForImport(rawFrame) {
    const f = rawFrame && typeof rawFrame === 'object' ? rawFrame : {};
    return Object.assign({}, f, {
        id: pdStringForImport(f.id || '', '').trim() || pdGenerateIdForImport(),
        frameId: pdStringForImport(f.frameId ?? f.frame ?? f.globalFrameId ?? '', ''),
        positionId: pdStringForImport(f.positionId ?? f.position ?? f.globalPositionId ?? '', ''),
        disableOnClose: pdBoolForImport(f.disableOnClose, true),
        invert: pdBoolForImport(f.invert, false)
    });
}

function pdNormalizeVisualPayloadForImport(rawPayload) {
    const v = rawPayload && typeof rawPayload === 'object' ? rawPayload : {};
    return Object.assign({}, v, {
        name: pdStringForImport(v.name ?? v.key ?? v.slot ?? 'MainImage', 'MainImage'),
        path: pdStringForImport(v.path ?? v.assetPath ?? v.url ?? 'Assets/Resources/Announcement/', 'Assets/Resources/Announcement/')
    });
}

function pdNormalizeTriggerArrayForImport(value, singleFallback) {
    let triggers = pdAsImportArray(value).map(v => {
        if (typeof v === 'string') return v.trim();
        if (v && typeof v === 'object') return pdStringForImport(v.name ?? v.event ?? v.type ?? v.trigger ?? '', '').trim();
        return '';
    }).filter(Boolean);
    if (triggers.length === 0 && singleFallback) triggers = [pdStringForImport(singleFallback, '').trim()].filter(Boolean);
    return triggers;
}

function pdNormalizePromptForImport(rawPrompt, index) {
    const p = rawPrompt && typeof rawPrompt === 'object' ? rawPrompt : {};
    const title = pdStringForImport(p.title ?? p.promptTitle ?? p.name ?? p.displayName ?? `Imported Prompt ${index + 1}`, `Imported Prompt ${index + 1}`);
    const bodyText = pdStringForImport(p.bodyText ?? p.body ?? p.text ?? p.description ?? p.message ?? '', '');
    let buttons = pdAsImportArray(p.buttons ?? p.responses ?? p.actions).map(pdNormalizeButtonForImport);
    if (buttons.length === 0 && (p.hasButton || p.buttonText || p.buttonLabel || p.responseText)) {
        buttons.push(pdNormalizeButtonForImport({
            text: p.buttonText ?? p.buttonLabel ?? p.responseText ?? 'Continue',
            stateChanges: p.buttonStateChanges ?? p.stateChanges ?? p.stateChange,
            branchPromptId: p.branchPromptId ?? p.nextPromptId,
            closeMenu: p.closeMenu ?? p.winClosePromptPanel,
            isExternalLink: p.isExternalLink,
            externalUrl: p.externalUrl
        }));
    }

    let backgroundTintType = p.backgroundTintType;
    let backgroundTintOpacity = p.backgroundTintOpacity;
    if (backgroundTintType === undefined) {
        if (p.backgroundTint === 'half') { backgroundTintType = 'half'; backgroundTintOpacity = 0.5; }
        else if (p.backgroundTint === 'black') { backgroundTintType = 'black'; backgroundTintOpacity = 1; }
        else if (p.backgroundTint === 'custom') { backgroundTintType = 'custom'; backgroundTintOpacity = pdNumberForImport(backgroundTintOpacity, 0.5); }
        else { backgroundTintType = 'none'; backgroundTintOpacity = 0; }
    }

    const triggers = pdNormalizeTriggerArrayForImport(p.triggers, p.triggerEvent);
    const visualPayloads = pdAsImportArray(p.visualPayloads ?? p.visualPayload ?? p.payloads ?? p.images).map(pdNormalizeVisualPayloadForImport);
    const frames = pdAsImportArray(p.frames ?? p.framePositions ?? p.positions).map(pdNormalizeFrameForImport);
    const tag = pdStringForImport(p.tag ?? p.type ?? p.category ?? activeTag ?? projectData?.tags?.[0]?.name ?? 'News Alert', 'News Alert').trim() || 'News Alert';

    const out = Object.assign({}, p, {
        id: pdStringForImport(p.id || p.promptId || '', '').trim() || pdGenerateIdForImport(),
        parentId: p.parentId === undefined ? null : p.parentId,
        rootId: p.rootId === undefined ? null : p.rootId,
        tag,
        title,
        bodyText,
        textFormat: pdNormalizeTextFormatForImport(p.textFormat),
        priority: pdNumberForImport(p.priority, 0),
        isRepeatable: pdBoolForImport(p.isRepeatable ?? p.repeatable, false),
        hasTriggers: pdBoolForImport(p.hasTriggers, triggers.length > 0),
        triggers,
        hasVisualPayload: pdBoolForImport(p.hasVisualPayload, visualPayloads.length > 0),
        visualPayloads,
        hasButton: pdBoolForImport(p.hasButton, buttons.length > 0),
        buttons,
        conditions: pdNormalizeLogicArrayForImport(p.conditions ?? p.condition),
        gameStateChanges: pdNormalizeLogicArrayForImport(p.gameStateChanges ?? p.stateChanges ?? p.stateChange ?? p.changes),
        winReopenDialogue: pdBoolForImport(p.winReopenDialogue, false),
        winCloseDialogue: pdBoolForImport(p.winCloseDialogue, false),
        winReopenMainMenu: pdBoolForImport(p.winReopenMainMenu, false),
        winCloseMainMenu: pdBoolForImport(p.winCloseMainMenu, false),
        winClosePromptPanel: pdBoolForImport(p.winClosePromptPanel, true),
        timestamp: pdNumberForImport(p.timestamp, Date.now()),
        isCalledExternally: pdBoolForImport(p.isCalledExternally, false),
        makeExternalCall: pdBoolForImport(p.makeExternalCall, false),
        backgroundTintType,
        backgroundTintOpacity: pdNumberForImport(backgroundTintOpacity, 0),
        frames,
        windowPositionId: pdStringForImport(p.windowPositionId ?? p.positionId ?? '', ''),
        voiceLine: pdBoolForImport(p.voiceLine, false),
        advancedOpen: pdBoolForImport(p.advancedOpen, false),
        triggersOpen: pdBoolForImport(p.triggersOpen, triggers.length > 0),
        visualPayloadsOpen: pdBoolForImport(p.visualPayloadsOpen, visualPayloads.length > 0),
        responsesOpen: pdBoolForImport(p.responsesOpen, buttons.length > 0),
        framesOpen: pdBoolForImport(p.framesOpen, true),
        conditionsOpen: pdBoolForImport(p.conditionsOpen, true),
        statesOpen: pdBoolForImport(p.statesOpen, true),
        ddAdvancedOpen: pdBoolForImport(p.ddAdvancedOpen, false),
        isCollapsed: pdBoolForImport(p.isCollapsed, false)
    });
    out.translations = pdNormalizeTranslationBagForImport(p.translations, ['title', 'bodyText'], { title, bodyText });
    return out;
}

function pdNormalizeSimpleNamedItemForImport(rawItem, fallbackName) {
    if (typeof rawItem === 'string') {
        return { id: pdGenerateIdForImport(), name: rawItem, color: getRandomHex() };
    }
    const item = rawItem && typeof rawItem === 'object' ? rawItem : {};
    const name = pdStringForImport(item.name ?? item.title ?? item.label ?? item.value ?? item.key ?? fallbackName, fallbackName).trim();
    return Object.assign({}, item, {
        id: pdStringForImport(item.id || '', '').trim() || pdGenerateIdForImport(),
        name: name || fallbackName,
        color: pdColorForImport(item.color, getRandomHex())
    });
}

function pdNormalizeTokenForImport(rawToken) {
    if (typeof rawToken === 'string') return { key: rawToken, value: '' };
    const t = rawToken && typeof rawToken === 'object' ? rawToken : {};
    const key = pdStringForImport(t.key ?? t.token_key ?? t.name ?? '', '').trim();
    if (!key) return null;
    return { key, value: pdStringForImport(t.value ?? t.token_value ?? t.defaultValue ?? '', '') };
}

function pdNormalizeProjectTagForImport(rawTag, index) {
    if (typeof rawTag === 'string') return { name: rawTag, color: getRandomHex() };
    const t = rawTag && typeof rawTag === 'object' ? rawTag : {};
    const name = pdStringForImport(t.name ?? t.tag_name ?? t.title ?? `Imported Tag ${index + 1}`, `Imported Tag ${index + 1}`).trim();
    return { name: name || `Imported Tag ${index + 1}`, color: pdColorForImport(t.color, getRandomHex()) };
}

function pdNormalizePositionTypeForImport(rawType, index) {
    const t = rawType && typeof rawType === 'object' ? rawType : {};
    const name = pdStringForImport(t.name ?? t.type_name ?? t.title ?? `Position Group ${index + 1}`, `Position Group ${index + 1}`);
    return Object.assign({}, t, {
        id: pdStringForImport(t.id || '', '').trim() || pdGenerateIdForImport(),
        name,
        collapsed: pdBoolForImport(t.collapsed, false),
        tags: pdAsImportArray(t.tags ?? t.positions ?? t.items).map((tag, tagIndex) => pdNormalizeSimpleNamedItemForImport(tag, `Position ${tagIndex + 1}`))
    });
}

function pdNormalizeImageSequenceForImport(rawSeq, index) {
    const s = rawSeq && typeof rawSeq === 'object' ? rawSeq : {};
    const name = pdStringForImport(s.name ?? s.title ?? s.sequence_name ?? `Image Sequence ${index + 1}`, `Image Sequence ${index + 1}`);
    return Object.assign({}, s, {
        id: pdStringForImport(s.id || '', '').trim() || pdGenerateIdForImport(),
        name,
        color: pdColorForImport(s.color, getRandomHex()),
        images: pdAsImportArray(s.images ?? s.frames ?? s.items).map((img, imgIndex) => pdNormalizeSimpleNamedItemForImport(img, `Image ${imgIndex + 1}`))
    });
}

function pdNormalizePromptDesignerImport(rawData) {
    const source = rawData && typeof rawData === 'object' ? rawData : {};
    const data = pdDeepCloneForImport(source.workspace || source.projectData || source.data || source);
    if (!data || typeof data !== 'object') throw new Error('Imported JSON did not contain a Prompt Designer project object.');

    if (!Array.isArray(data.prompts)) {
        if (Array.isArray(data.promptBlueprints)) data.prompts = data.promptBlueprints;
        else if (Array.isArray(data.items)) data.prompts = data.items;
        else if (Array.isArray(source)) data.prompts = source;
        else data.prompts = [];
    }

    const dialogueKeyMap = [
        ['cast', 'globalCast'],
        ['globalTimesOfDay', 'timesOfDay'],
        ['globalDaysOfWeek', 'daysOfWeek'],
        ['globalMenuOptions', 'menuOptions'],
        ['globalImageSequences', 'imageSequences']
    ];
    dialogueKeyMap.forEach(([fromKey, toKey]) => {
        if (!Array.isArray(data[toKey]) && Array.isArray(data[fromKey])) data[toKey] = data[fromKey];
    });

    const langSet = new Set(['ENG']);
    pdAsImportArray(data.availableLanguages ?? data.languages).forEach(lang => langSet.add(pdNormalizeLangForImport(lang)));
    if (data.currentLanguage) langSet.add(pdNormalizeLangForImport(data.currentLanguage));
    data.availableLanguages = Array.from(langSet).filter(Boolean);
    data.currentLanguage = pdNormalizeLangForImport(data.currentLanguage || 'ENG');

    data.tokens = pdAsImportArray(data.tokens ?? data.globalTokens).map(pdNormalizeTokenForImport).filter(Boolean);
    data.tags = pdAsImportArray(data.tags ?? data.promptTags ?? data.categories).map(pdNormalizeProjectTagForImport);
    if (data.tags.length === 0) data.tags = [{ name: 'News Alert', color: '#00f2ff' }];

    const tagNames = new Set(data.tags.map(t => String(t.name || '').trim()).filter(Boolean));
    data.prompts = pdAsImportArray(data.prompts).map((p, idx) => pdNormalizePromptForImport(p, idx));
    data.prompts.forEach(p => {
        if (!tagNames.has(p.tag)) {
            data.tags.push({ name: p.tag, color: getRandomHex() });
            tagNames.add(p.tag);
        }
    });

    ['globalCast', 'globalStates', 'globalMoods', 'globalSettings', 'timesOfDay', 'daysOfWeek', 'menuOptions', 'globalFrames'].forEach(key => {
        data[key] = pdAsImportArray(data[key]).map((item, idx) => pdNormalizeSimpleNamedItemForImport(item, `${key} ${idx + 1}`));
    });
    data.positionTypes = pdAsImportArray(data.positionTypes).map(pdNormalizePositionTypeForImport);
    data.imageSequences = pdAsImportArray(data.imageSequences).map(pdNormalizeImageSequenceForImport);

    if (!data.serverSessionId && source.sessionId) data.serverSessionId = source.sessionId;
    if (!data.dialogueSessionId && source.dialogueSessionId) data.dialogueSessionId = source.dialogueSessionId;

    return data;
}

function pdRenderAfterImport() {
    if (typeof populateTagDropdown === 'function') populateTagDropdown();
    if (typeof renderLists === 'function') renderLists();
    if (typeof renderGlobalSections === 'function') renderGlobalSections();
    if (typeof renderGlobalPositions === 'function') renderGlobalPositions();
    if (typeof renderLogicPanel === 'function') renderLogicPanel();
    if (typeof renderEditor === 'function') renderEditor();
    if (typeof window.pdFocusActivePromptInRightSidebar === 'function') window.setTimeout(() => window.pdFocusActivePromptInRightSidebar('auto'), 0);
}

function populateTagDropdown() {
    const activePrompt = projectData?.prompts?.find(p => p.id === activePromptId);
    const editTag = document.getElementById('edit-tag');
    if (editTag) {
        editTag.innerHTML = (projectData.tags || []).map(t => {
            const name = pdStringForImport(t.name, 'Untitled');
            return `<option value="${name.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}" ${activePrompt && activePrompt.tag === name ? 'selected' : ''}>${name.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</option>`;
        }).join('');
    }

    const categoryTabs = document.getElementById('category-tabs');
    if (categoryTabs) {
        categoryTabs.innerHTML = (projectData.tags || []).map(t => {
            const name = pdStringForImport(t.name, 'Untitled');
            const safeName = name.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            const label = name.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            const color = pdColorForImport(t.color, '#00f2ff');
            return `<button class="char-tab ${activeTag === name ? 'active' : ''}" style="border-color:${color}; color:${activeTag === name ? '#000' : color}; background:${activeTag === name ? color : 'transparent'}" onclick="selectCategory('${safeName}')">${label}</button>`;
        }).join('');
    }
}


function pdPromptDesignerRendererReady() {
    return true;
}

function escapeHtml(value) {
    const div = document.createElement('div');
    div.textContent = value === undefined || value === null ? '' : String(value);
    return div.innerHTML;
}

function pdAttr(value) {
    return escapeHtml(value).replace(/"/g, '&quot;');
}

function pdJsonArg(value) {
    return escapeHtml(JSON.stringify(value === undefined || value === null ? '' : String(value)));
}

function pdEnsureImportRuntimeShape() {
    if (!projectData || typeof projectData !== 'object') projectData = {};
    if (!Array.isArray(projectData.tokens)) projectData.tokens = [];
    if (!Array.isArray(projectData.tags)) projectData.tags = [{ name: 'News Alert', color: '#00f2ff' }];
    if (!Array.isArray(projectData.prompts)) projectData.prompts = [];
    if (!Array.isArray(projectData.positionTypes)) projectData.positionTypes = [];
    GLOBAL_SECTIONS.forEach(sec => { if (!Array.isArray(projectData[sec.key])) projectData[sec.key] = []; });
    if (!Array.isArray(projectData.availableLanguages)) projectData.availableLanguages = ['ENG'];
    projectData.availableLanguages = Array.from(new Set(projectData.availableLanguages.map(pdNormalizeLangForImport).filter(Boolean)));
    if (!projectData.availableLanguages.includes('ENG')) projectData.availableLanguages.unshift('ENG');
    projectData.currentLanguage = pdNormalizeLangForImport(projectData.currentLanguage || 'ENG');
    if (!projectData.availableLanguages.includes(projectData.currentLanguage)) projectData.availableLanguages.push(projectData.currentLanguage);
    projectData.tags.forEach((tag, index) => {
        if (!tag.name) tag.name = `Tag ${index + 1}`;
        tag.color = pdColorForImport(tag.color, getRandomHex());
    });
    projectData.prompts.forEach((prompt, index) => pdRepairPromptForRender(prompt, index));
    if (!activeTag || !projectData.tags.some(tag => tag.name === activeTag)) {
        activeTag = projectData.prompts[0]?.tag || projectData.tags[0]?.name || 'News Alert';
    }
    if (activePromptId && !projectData.prompts.some(prompt => prompt.id === activePromptId)) activePromptId = null;
    if (!activePromptId) {
        const firstInTag = projectData.prompts.find(prompt => prompt.tag === activeTag) || projectData.prompts[0] || null;
        activePromptId = firstInTag ? firstInTag.id : null;
        if (firstInTag) activeTag = firstInTag.tag;
    }
    window.activePromptId = activePromptId;
    window.activeTag = activeTag;
}

function pdRepairPromptForRender(prompt, index) {
    if (!prompt || typeof prompt !== 'object') return;
    if (!prompt.id) prompt.id = pdGenerateIdForImport();
    if (!prompt.tag) prompt.tag = activeTag || projectData.tags[0]?.name || 'News Alert';
    if (!projectData.tags.some(tag => tag.name === prompt.tag)) projectData.tags.push({ name: prompt.tag, color: getRandomHex() });
    prompt.title = pdStringForImport(prompt.title, `Prompt ${index + 1}`);
    prompt.bodyText = pdStringForImport(prompt.bodyText, '');
    prompt.priority = pdNumberForImport(prompt.priority, 0);
    prompt.textFormat = pdNormalizeTextFormatForImport(prompt.textFormat);
    prompt.conditions = pdNormalizeLogicArrayForImport(prompt.conditions);
    prompt.gameStateChanges = pdNormalizeLogicArrayForImport(prompt.gameStateChanges);
    prompt.buttons = pdAsImportArray(prompt.buttons).map(pdNormalizeButtonForImport);
    prompt.triggers = pdNormalizeTriggerArrayForImport(prompt.triggers, prompt.triggerEvent);
    prompt.frames = pdAsImportArray(prompt.frames).map(pdNormalizeFrameForImport);
    prompt.visualPayloads = pdAsImportArray(prompt.visualPayloads).map(pdNormalizeVisualPayloadForImport);
    prompt.hasTriggers = pdBoolForImport(prompt.hasTriggers, prompt.triggers.length > 0);
    prompt.hasVisualPayload = pdBoolForImport(prompt.hasVisualPayload, prompt.visualPayloads.length > 0);
    prompt.hasButton = pdBoolForImport(prompt.hasButton, prompt.buttons.length > 0);
    prompt.winReopenDialogue = pdBoolForImport(prompt.winReopenDialogue, false);
    prompt.winCloseDialogue = pdBoolForImport(prompt.winCloseDialogue, false);
    prompt.winReopenMainMenu = pdBoolForImport(prompt.winReopenMainMenu, false);
    prompt.winCloseMainMenu = pdBoolForImport(prompt.winCloseMainMenu, false);
    prompt.winClosePromptPanel = pdBoolForImport(prompt.winClosePromptPanel, true);
    prompt.isRepeatable = pdBoolForImport(prompt.isRepeatable, false);
    prompt.isCalledExternally = pdBoolForImport(prompt.isCalledExternally, false);
    prompt.makeExternalCall = pdBoolForImport(prompt.makeExternalCall, false);
    prompt.voiceLine = pdBoolForImport(prompt.voiceLine, false);
    prompt.backgroundTintType = prompt.backgroundTintType || 'none';
    prompt.backgroundTintOpacity = pdNumberForImport(prompt.backgroundTintOpacity, prompt.backgroundTintType === 'none' ? 0 : 0.5);
    prompt.windowPositionId = pdStringForImport(prompt.windowPositionId, '');
    prompt.parentId = prompt.parentId === undefined ? null : prompt.parentId;
    prompt.rootId = prompt.rootId === undefined ? null : prompt.rootId;
    prompt.translations = pdNormalizeTranslationBagForImport(prompt.translations, ['title', 'bodyText'], { title: prompt.title, bodyText: prompt.bodyText });
}

function pdGetPromptTextForRender(prompt, field) {
    const lang = pdNormalizeLangForImport(projectData.currentLanguage || 'ENG');
    if (prompt?.translations?.[lang]?.[field] !== undefined) return prompt.translations[lang][field];
    if (prompt?.translations?.ENG?.[field] !== undefined) return prompt.translations.ENG[field];
    return prompt?.[field] || '';
}

function pdGetButtonTextForRender(button) {
    const lang = pdNormalizeLangForImport(projectData.currentLanguage || 'ENG');
    if (button?.translations?.[lang]?.text !== undefined) return button.translations[lang].text;
    if (button?.translations?.ENG?.text !== undefined) return button.translations.ENG.text;
    return button?.text || '';
}

function pdSetButtonTextForRender(buttonIndex, value) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const button = prompt?.buttons?.[buttonIndex];
    if (!button) return;
    const lang = pdNormalizeLangForImport(projectData.currentLanguage || 'ENG');
    if (!button.translations || typeof button.translations !== 'object') button.translations = {};
    if (!button.translations[lang]) button.translations[lang] = {};
    button.translations[lang].text = value;
    if (lang === 'ENG') button.text = value;
}


function pdEnsureVisualPatchCSS() {
    let style = document.getElementById('pd-import-healer-visual-fixes');
    if (!style) {
        style = document.createElement('style');
        style.id = 'pd-import-healer-visual-fixes';
        document.head.appendChild(style);
    }
    style.textContent = `
        #prompt-list .pd-prompt-library-section { position:relative; border:1px solid rgba(255,255,255,.10); border-left-width:5px; border-radius:12px; background:#080808; margin:0 0 12px; overflow:hidden; transition:border-color .16s ease, box-shadow .16s ease; }
        #prompt-list .pd-prompt-library-section.drag-over { box-shadow:0 0 18px rgba(0,242,255,.35); border-color:var(--accent-teal) !important; }
        #prompt-list .pd-prompt-library-section-body.drag-over { outline:1px dashed rgba(0,242,255,.45); outline-offset:-3px; }
        #prompt-list .pd-prompt-library-section-header { width:100%; min-height:34px; display:flex; align-items:center; justify-content:space-between; gap:10px; padding:9px 10px 8px; background:#050505; border:0; border-bottom:1px solid rgba(255,255,255,.08); text-align:left; cursor:pointer; }
        #prompt-list .pd-prompt-library-section-header:hover { background:#0d0d0d; }
        #prompt-list .pd-prompt-library-section-title { min-width:0; font-size:10px; font-weight:1000; text-transform:uppercase; letter-spacing:.13em; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        #prompt-list .pd-prompt-library-section-count { color:#8d91a0; font-size:10px; font-weight:1000; white-space:nowrap; }
        #prompt-list .pd-prompt-library-section-body { padding:8px; }
        #prompt-list .pd-prompt-library-section-empty { color:#73737f; font-size:10px; font-weight:900; text-transform:uppercase; letter-spacing:.10em; font-style:italic; padding:10px 6px; }
        #prompt-list .pd-prompt-library-entry { position: relative; margin-bottom:8px; }
        #prompt-list .pd-prompt-library-entry:last-child { margin-bottom:0; }
        #prompt-list .pd-prompt-library-entry.drop-before::before,
        #prompt-list .pd-prompt-library-entry.drop-after::after { content:''; position:absolute; left:0; right:0; height:3px; border-radius:999px; background:var(--accent-teal); box-shadow:0 0 12px rgba(0,242,255,.8); z-index:6; }
        #prompt-list .pd-prompt-library-entry.drop-before::before { top:-5px; }
        #prompt-list .pd-prompt-library-entry.drop-after::after { bottom:-5px; }
        #prompt-list .pd-prompt-library-entry.pd-dragging { opacity:.45; }
        #prompt-list .pd-prompt-library-card { background:#050505; border:1px solid rgba(255,255,255,.12); border-left-width:4px; border-radius:9px; padding:10px 10px 9px 11px; cursor:pointer; transition:border-color .16s ease, box-shadow .16s ease, transform .16s ease; }
        #prompt-list .pd-prompt-library-card:hover { border-color: var(--accent-teal) !important; box-shadow: 0 0 14px rgba(0,242,255,.22); }
        #prompt-list .pd-prompt-library-card.pd-active { border-color: var(--accent-teal) !important; box-shadow: 0 0 18px rgba(0,242,255,.28); }
        #prompt-list .pd-prompt-library-topline { display:flex; align-items:flex-start; justify-content:space-between; gap:8px; }
        #prompt-list .pd-prompt-library-index { font-size:9px; font-weight:900; letter-spacing:.10em; text-transform:uppercase; opacity:.78; white-space:nowrap; }
        #prompt-list .pd-prompt-library-title { margin-top:4px; color:#fff; font-size:12px; font-weight:900; line-height:1.14; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        #prompt-list .pd-prompt-library-body { margin-top:5px; color:#8e8e98; font-size:10px; font-style:italic; line-height:1.25; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        #prompt-list .pd-prompt-library-tag { font-size:9px; font-weight:900; text-transform:uppercase; letter-spacing:.08em; opacity:.9; white-space:nowrap; }
        #prompt-list .pd-prompt-library-delete { opacity:0; position:absolute; top:6px; right:7px; color:var(--accent-pink); background:#080808; border:1px solid #333; width:20px; height:20px; border-radius:4px; font-weight:900; line-height:16px; z-index:3; }
        #prompt-list .pd-prompt-library-entry:hover .pd-prompt-library-delete { opacity:1; }
        #prompt-number-tab.pd-prompt-number-tab { position:absolute !important; left:-4px !important; top:-28px !important; z-index:40 !important; height:28px !important; min-height:28px !important; display:inline-flex !important; align-items:stretch !important; overflow:visible !important; padding:0 !important; margin:0 !important; }
        #prompt-number-tab .pd-prompt-number-chip { min-width:46px !important; height:28px !important; min-height:28px !important; padding:0 13px !important; border:1px solid rgba(255,255,255,.22) !important; border-bottom:0 !important; border-radius:8px 0 0 0 !important; display:flex !important; align-items:center !important; justify-content:center !important; color:#000 !important; font-size:13px !important; font-weight:1000 !important; line-height:1 !important; letter-spacing:.02em !important; box-shadow:0 0 14px rgba(0,242,255,.18); cursor:pointer !important; }
        #prompt-number-tab .pd-prompt-move-badge { height:28px !important; min-height:28px !important; display:flex !important; align-items:center !important; gap:7px !important; padding:0 8px !important; background:#050505 !important; border:1px solid currentColor !important; border-bottom:0 !important; font-size:9px !important; font-weight:1000 !important; text-transform:uppercase !important; letter-spacing:.10em !important; }
        #prompt-number-tab .pd-prompt-move-badge span { color:#777b87 !important; white-space:nowrap !important; }
        #prompt-number-tab .pd-prompt-move-badge select { max-width:210px !important; height:21px !important; background:#000 !important; border:1px solid rgba(255,255,255,.12) !important; color:inherit !important; outline:0 !important; font-size:10px !important; font-weight:900 !important; padding:1px 5px !important; cursor:pointer !important; }
        #prompt-number-tab .pd-local-toggle-stack { border-bottom:0 !important; }
        #logic-list-container { padding-top:5px !important; }
        #logic-list-container .pd-logic-pill { position:relative; width:100%; min-height:34px; background:#101010; border:1px solid #202020; border-radius:8px; margin:0 0 5px; padding:0 8px 0 0; display:grid; grid-template-columns:5px minmax(0,1fr) auto; align-items:center; gap:0; text-align:left; color:#fff; overflow:hidden; cursor:pointer; transition:border-color .16s ease, box-shadow .16s ease, transform .16s ease; }
        #logic-list-container .pd-logic-pill:hover { border-color: var(--accent-teal); box-shadow:0 0 10px rgba(0,242,255,.14); }
        #logic-list-container .pd-logic-accent { align-self:stretch; width:5px; box-shadow:0 0 10px currentColor; }
        #logic-list-container .pd-logic-main { padding:0 6px 0 9px; min-width:0; font-size:10.5px; font-weight:1000; line-height:1.05; letter-spacing:-.01em; color:#f5f5f5; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        #logic-list-container .pd-logic-op { color:#7f8491; padding:0 2px; }
        #logic-list-container .pd-logic-count { justify-self:end; color:#838895; font-size:9.5px; font-weight:1000; padding-left:6px; }
        #logic-list-container .pd-logic-empty { text-align:center; color:#888899; padding:16px 10px; font-size:10px; font-weight:900; text-transform:uppercase; letter-spacing:.13em; }
        #live-preview.pd-live-preview-formatted { display:flex; flex-direction:column; min-height:120px; white-space:pre-wrap; overflow:auto; }
        #live-preview.pd-live-preview-formatted ul,
        #live-preview.pd-live-preview-formatted ol { margin:.15rem 0 .15rem 1.25rem; padding-left:1rem; }
        #live-preview.pd-live-preview-formatted li { margin:.15rem 0; }
        .sidebar-list .pd-left-draggable-item { position:relative; cursor:grab; user-select:none; transition:border-color .16s ease, box-shadow .16s ease, opacity .16s ease; }
        .sidebar-list .pd-left-draggable-item:active { cursor:grabbing; }
        .sidebar-list .pd-left-draggable-item input,
        .sidebar-list .pd-left-draggable-item button,
        .sidebar-list .pd-left-draggable-item select { user-select:auto; }
        .sidebar-list .pd-left-editing-item { cursor:default; }
        .sidebar-list .pd-left-dragging { opacity:.42; }
        .sidebar-list .pd-drop-before::before,
        .sidebar-list .pd-drop-after::after,
        .pd-position-type-block.pd-drop-before::before,
        .pd-position-type-block.pd-drop-after::after { content:''; position:absolute; left:0; right:0; height:3px; border-radius:999px; background:var(--accent-teal); box-shadow:0 0 12px rgba(0,242,255,.78); z-index:20; pointer-events:none; }
        .sidebar-list .pd-drop-before::before,
        .pd-position-type-block.pd-drop-before::before { top:-4px; }
        .sidebar-list .pd-drop-after::after,
        .pd-position-type-block.pd-drop-after::after { bottom:-4px; }
        .sidebar-list.pd-left-list-drag-over,
        .pd-position-tag-list.pd-left-list-drag-over,
        .pd-position-type-block.pd-left-list-drag-over { outline:1px dashed rgba(0,242,255,.42); outline-offset:-3px; }
        .pd-position-type-block { position:relative; }
    `;
}
function pdPromptProjectIndex(prompt) {
    const index = (projectData.prompts || []).findIndex(p => p && p.id === prompt?.id);
    return index >= 0 ? index + 1 : 1;
}

function pdEnsurePromptNumberTab(prompt) {
    const card = document.getElementById('active-prompt-card');
    if (!card || !prompt) return;
    pdEnsureVisualPatchCSS();
    let tab = document.getElementById('prompt-number-tab');
    if (!tab) {
        card.insertAdjacentHTML('afterbegin', `<div id="prompt-number-tab" class="pd-prompt-number-tab"><div class="pd-prompt-number-chip"></div></div>`);
        tab = document.getElementById('prompt-number-tab');
    }
    tab.classList.add('pd-prompt-number-tab');
    const chip = tab.querySelector('.pd-prompt-number-chip') || tab.firstElementChild;
    const tag = (projectData.tags || []).find(t => t.name === prompt.tag) || {};
    const color = pdColorForImport(tag.color, '#00f2ff');
    if (chip) {
        chip.classList.add('pd-prompt-number-chip');
        chip.textContent = pdPromptLocalIndex(prompt);
        chip.style.background = color;
        chip.style.borderColor = color;
        chip.style.boxShadow = `0 0 16px ${color}55`;
        chip.title = 'Click to collapse or expand this prompt panel';
    }
    pdEnsurePromptMoveDropdown(prompt, color);
}

function pdEnsurePromptMoveDropdown(prompt, color) {
    const tab = document.getElementById('prompt-number-tab');
    if (!tab || !prompt) return;
    let moveBadge = tab.querySelector('.pd-prompt-move-badge');
    if (!moveBadge) {
        moveBadge = document.createElement('div');
        moveBadge.className = 'pd-prompt-move-badge';
        const toggleStack = tab.querySelector('.pd-local-toggle-stack');
        if (toggleStack) tab.insertBefore(moveBadge, toggleStack);
        else tab.appendChild(moveBadge);
    }
    moveBadge.style.color = color;
    moveBadge.style.borderColor = color;
    const tagPrompts = (projectData.prompts || []).filter(p => p.tag === prompt.tag);
    const options = tagPrompts.map((item, index) => {
        const title = pdGetPromptTextForRender(item, 'title') || item.title || item.id || `Prompt ${index + 1}`;
        return `<option value="${index}" ${item.id === prompt.id ? 'selected' : ''}>#${index + 1} ${escapeHtml(title)}</option>`;
    }).join('');
    moveBadge.innerHTML = `<span>Move To</span><select onclick="event.stopPropagation()" onchange="pdMovePromptOrderFromTab(${pdJsonArg(prompt.id)}, this.value)">${options}</select>`;
}

function pdMovePromptOrderFromTab(promptId, newLocalIdxStr) {
    const newLocalIdx = parseInt(newLocalIdxStr, 10);
    if (!Number.isFinite(newLocalIdx)) return;
    const prompt = (projectData.prompts || []).find(p => p.id === promptId);
    if (!prompt) return;
    const tagName = prompt.tag;
    const tagPrompts = (projectData.prompts || []).filter(p => p.tag === tagName);
    const oldLocalIdx = tagPrompts.findIndex(p => p.id === promptId);
    if (oldLocalIdx < 0 || oldLocalIdx === newLocalIdx) return;
    tagPrompts.splice(oldLocalIdx, 1);
    tagPrompts.splice(Math.max(0, Math.min(newLocalIdx, tagPrompts.length)), 0, prompt);
    let tagCursor = 0;
    projectData.prompts = (projectData.prompts || []).map(item => {
        if (item.tag !== tagName) return item;
        const replacement = tagPrompts[tagCursor];
        tagCursor += 1;
        return replacement;
    });
    activePromptId = prompt.id;
    activeTag = tagName;
    lastActivePerCategory[tagName] = prompt.id;
    renderLists();
    renderEditor();
}

function pdLogicRowColor(item) {
    if (item.isCondition && item.isStateChange) return '#b026ff';
    if (item.isStateChange) return '#00ff88';
    if (item.isCondition) return '#00f2ff';
    return '#ff8c00';
}

function pdAddLogicRowToMap(map, logic, use) {
    if (!logic || !logic.key) return;
    const key = pdStringForImport(logic.key, '').trim();
    if (!key) return;
    const op = pdStringForImport(logic.op, '==') || '==';
    const val = pdStringForImport(logic.val, '');
    const id = `${key}||${op}||${val}`;
    if (!map[id]) map[id] = { key, op, val, isCondition: false, isStateChange: false, uses: [] };
    if (use.kind === 'condition') map[id].isCondition = true;
    if (use.kind === 'state') map[id].isStateChange = true;
    map[id].uses.push(use.publicUse);
}

function pdGetActiveProjectLogicRows() {
    const map = {};
    (projectData.prompts || []).forEach(prompt => {
        const promptTitle = pdGetPromptTextForRender(prompt, 'title') || prompt.title || 'Untitled Prompt';
        (prompt.conditions || []).forEach(logic => pdAddLogicRowToMap(map, logic, {
            kind: 'condition',
            publicUse: { promptId: prompt.id, type: 'Condition', text: promptTitle, context: logic }
        }));
        (prompt.gameStateChanges || []).forEach(logic => pdAddLogicRowToMap(map, logic, {
            kind: 'state',
            publicUse: { promptId: prompt.id, type: 'State Change', text: promptTitle, context: logic }
        }));
        (prompt.buttons || []).forEach((button, buttonIndex) => {
            const buttonText = pdGetButtonTextForRender(button) || button.text || `Response ${buttonIndex + 1}`;
            (button.conditions || []).forEach(logic => pdAddLogicRowToMap(map, logic, {
                kind: 'condition',
                publicUse: { promptId: prompt.id, type: 'Button Condition', text: buttonText, context: logic, btnIdx: buttonIndex }
            }));
            (button.stateChanges || []).forEach(logic => pdAddLogicRowToMap(map, logic, {
                kind: 'state',
                publicUse: { promptId: prompt.id, type: 'Button State Change', text: buttonText, context: logic, btnIdx: buttonIndex }
            }));
        });
    });
    return Object.values(map).sort((a, b) => String(a.key).localeCompare(String(b.key)) || String(a.val).localeCompare(String(b.val)));
}

function renderLists() {
    pdEnsureImportRuntimeShape();
    pdEnsureVisualPatchCSS();
    renderTokenList();
    renderTagList();
    populateTagDropdown();
    renderPromptLibrary();
    updateDynamicGlows();
}

function renderTokenList() {
    const list = document.getElementById('list-tokens');
    if (!list) return;
    list.innerHTML = projectData.tokens.map((token, index) => {
        const key = pdStringForImport(token.key, '');
        const value = pdStringForImport(token.value, '');
        if (editingTokenIdx === index) {
            return `<li class="pd-left-draggable-item pd-left-editing-item" style="border-left-color:var(--accent-teal)"><div class="flex gap-1 w-full"><input id="edit-token-key-${index}" value="${pdAttr(key)}" class="text-xs" onkeydown="pdHandleTokenEditKey(event, ${index})"><button class="btn btn-green px-2 py-1" onclick="saveTokenKeyEdit(${index})">✓</button><button class="btn btn-outline px-2 py-1" onclick="cancelTokenEdit()">✖</button></div></li>`;
        }
        return `<li class="pd-left-draggable-item" style="border-left-color:var(--accent-teal)" draggable="true" data-pd-list-kind="tokens" data-pd-token-index="${index}" ondblclick="pdStartTokenEditFromDblClick(event, ${index})" ondragstart="pdLeftListDragStart(event, 'tokens', ${index})" ondragover="pdLeftListDragOver(event)" ondragleave="pdLeftListDragLeave(event)" ondrop="pdLeftListDrop(event, 'tokens', ${index})" ondragend="pdLeftListDragEnd(event)"><div class="min-w-0 flex-1"><button class="token-tag pd-inline-edit-trigger" onclick="startTokenEdit(${index})">{{${escapeHtml(key)}}}</button><input type="text" value="${pdAttr(value)}" oninput="updateTokenValue(${index}, this.value)" class="mt-2 text-xs" draggable="false" ondragstart="event.stopPropagation()"></div><button class="text-accent-pink font-black ml-2" onclick="event.stopPropagation(); removeToken(${index})">×</button></li>`;
    }).join('') || `<li class="text-dim italic">No tokens yet.</li>`;
}

function renderTagList() {
    const list = document.getElementById('list-tags');
    if (!list) return;
    list.innerHTML = projectData.tags.map((tag, index) => {
        const name = pdStringForImport(tag.name, `Tag ${index + 1}`);
        const color = pdColorForImport(tag.color, '#00f2ff');
        const count = projectData.prompts.filter(prompt => prompt.tag === name).length;
        if (editingTagIdx === index) {
            return `<li class="pd-left-draggable-item pd-left-editing-item" style="border-left-color:${color}"><div class="flex gap-1 w-full items-center"><input id="edit-tag-input-${index}" value="${pdAttr(name)}" class="text-xs" onkeydown="pdHandleTagEditKey(event, ${index})"><input id="edit-tag-color-${index}" type="color" value="${color}" class="w-7 h-7 p-0"><button class="btn btn-green px-2 py-1" onclick="saveTagEdit(${index})">✓</button><button class="btn btn-outline px-2 py-1" onclick="cancelTagEdit()">✖</button></div></li>`;
        }
        return `<li class="pd-left-draggable-item" style="border-left-color:${color}" draggable="true" data-pd-list-kind="tags" data-pd-tag-index="${index}" ondblclick="pdStartTagEditFromDblClick(event, ${index})" ondragstart="pdLeftListDragStart(event, 'tags', ${index})" ondragover="pdLeftListDragOver(event)" ondragleave="pdLeftListDragLeave(event)" ondrop="pdLeftListDrop(event, 'tags', ${index})" ondragend="pdLeftListDragEnd(event)"><button class="flex-1 text-left font-black uppercase pd-inline-edit-trigger" style="color:${color}" onclick="selectCategory(${pdJsonArg(name)})">${escapeHtml(name)} <span class="text-dim text-[10px]">(${count})</span></button><div class="flex gap-2"><button class="text-accent-teal" onclick="event.stopPropagation(); startTagEdit(${index})">✎</button><button class="text-accent-pink" onclick="event.stopPropagation(); removeTag(${index})">×</button></div></li>`;
    }).join('') || `<li class="text-dim italic">No tags yet.</li>`;
}

function renderPromptLibrary() {
    pdEnsureImportRuntimeShape();
    pdEnsureVisualPatchCSS();
    const list = document.getElementById('prompt-list');
    if (!list) return;
    const searchInput = document.getElementById('prompt-search');
    const query = String(searchInput?.value || '').trim().toLowerCase();
    const knownTags = (projectData.tags || []).slice();
    const knownNames = new Set(knownTags.map(t => t.name));
    (projectData.prompts || []).forEach(prompt => {
        if (prompt.tag && !knownNames.has(prompt.tag)) {
            knownNames.add(prompt.tag);
            knownTags.push({ name: prompt.tag, color: getRandomHex() });
        }
    });

    const sectionHtml = knownTags.map((tag, tagIndex) => {
        const tagName = pdStringForImport(tag.name, `Tag ${tagIndex + 1}`);
        const color = pdColorForImport(tag.color, '#00f2ff');
        const tagPrompts = (projectData.prompts || []).filter(prompt => (prompt.tag || '') === tagName);
        const filteredPrompts = query ? tagPrompts.filter(prompt => {
            const title = (pdGetPromptTextForRender(prompt, 'title') || prompt.title || '').toLowerCase();
            const body = (pdGetPromptTextForRender(prompt, 'bodyText') || prompt.bodyText || '').toLowerCase();
            return title.includes(query)
                || body.includes(query)
                || String(prompt.id || '').toLowerCase().includes(query)
                || String(prompt.tag || '').toLowerCase().includes(query);
        }) : tagPrompts;
        if (query && filteredPrompts.length === 0) return '';
        const collapsed = pdPromptLibrarySectionCollapsed(tagName) && !query;
        const bodyHtml = collapsed ? '' : (filteredPrompts.map((prompt) => pdRenderPromptLibraryEntry(prompt)).join('') || `<div class="pd-prompt-library-section-empty">No prompts in this tab.</div>`);
        return `<section class="pd-prompt-library-section ${activeTag === tagName ? 'pd-active-section' : ''}" data-tag-name="${pdAttr(tagName)}" style="border-left-color:${color}" ondragover="pdPromptLibraryDragOver(event)" ondragleave="pdPromptLibraryDragLeave(event)" ondrop="pdPromptLibraryDrop(event, ${pdJsonArg(tagName)})">
            <button type="button" class="pd-prompt-library-section-header" onclick="pdTogglePromptLibrarySection(${pdJsonArg(tagName)})" style="color:${color}">
                <span class="pd-prompt-library-section-title">${collapsed ? '▶' : '▼'} ${escapeHtml(tagName)}</span>
                <span class="pd-prompt-library-section-count">${filteredPrompts.length}/${tagPrompts.length}</span>
            </button>
            <div class="pd-prompt-library-section-body" data-tag-name="${pdAttr(tagName)}" ondragover="pdPromptLibrarySectionBodyDragOver(event)" ondragleave="pdPromptLibrarySectionBodyDragLeave(event)" ondrop="pdPromptLibraryDrop(event, ${pdJsonArg(tagName)})">${bodyHtml}</div>
        </section>`;
    }).join('');

    list.innerHTML = sectionHtml || `<div class="empty-state text-center text-dim py-8 text-xs font-bold uppercase tracking-widest">No prompts in this project.</div>`;
    pdInstallPromptLibraryInteractions(list);
}

function pdRenderPromptLibraryEntry(prompt) {
    const tag = projectData.tags.find(t => t.name === prompt.tag) || { color: '#00f2ff', name: prompt.tag || 'Uncategorized' };
    const color = pdColorForImport(tag.color, '#00f2ff');
    const title = pdCleanPromptSampleText(pdGetPromptTextForRender(prompt, 'title') || prompt.title || 'Untitled Prompt');
    const body = pdCleanPromptSampleText(pdGetPromptTextForRender(prompt, 'bodyText') || prompt.bodyText || '');
    const selected = prompt.id === activePromptId;
    const tagIndex = pdPromptLocalIndex(prompt);
    const glow = typeof getPromptGlowState === 'function' ? getPromptGlowState(prompt.id, typeof getProjectLogic === 'function' ? getProjectLogic() : []) : 'none';
    const glowClass = glow === 'red' ? 'pd-glow-red' : glow === 'blue' ? 'pd-glow-blue' : glow === 'purple' ? 'pd-glow-purple' : '';
    return `<div id="pd-prompt-lib-${pdAttr(prompt.id)}" data-prompt-id="${pdAttr(prompt.id)}" class="pd-prompt-library-entry prompt-item-container ${glowClass}" draggable="true" ondragstart="pdPromptLibraryDragStart(event, ${pdJsonArg(prompt.id)})" ondragend="pdPromptLibraryDragEnd(event)" ondragover="pdPromptLibraryEntryDragOver(event, ${pdJsonArg(prompt.id)})" ondragleave="pdPromptLibraryEntryDragLeave(event)" ondrop="pdPromptLibraryEntryDrop(event, ${pdJsonArg(prompt.id)})" onclick="selectPrompt(${pdJsonArg(prompt.id)})">
        <div class="pd-prompt-library-card ${selected ? 'pd-active' : ''}" style="border-left-color:${color}">
            <button type="button" class="pd-prompt-library-delete" onclick="event.stopPropagation(); deletePromptWithConfirm(${pdJsonArg(prompt.id)})">×</button>
            <div class="pd-prompt-library-topline">
                <div class="pd-prompt-library-index" style="color:${color}">#${tagIndex}</div>
                <div class="pd-prompt-library-tag" style="color:${color}">${escapeHtml(prompt.tag || 'Untagged')}</div>
            </div>
            <div class="pd-prompt-library-title">${escapeHtml(title)}</div>
            <div class="pd-prompt-library-body">${escapeHtml(body).slice(0, 180)}</div>
        </div>
    </div>`;
}

function pdCleanPromptSampleText(value) {
    let text = String(value || '');
    text = text.replace(/<\s*br\s*\/?>/gi, ' ');
    text = text.replace(/<\/?[^>]+>/g, '');
    text = text.replace(/\{\{\s*([^}]+?)\s*\}\}/g, '$1');
    text = text.replace(/&nbsp;/gi, ' ');
    text = text.replace(/&amp;/gi, '&').replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&quot;/gi, '"').replace(/&#39;/g, "'");
    text = text.replace(/<\/?[^>]+>/g, '');
    text = text.replace(/\s+/g, ' ').trim();
    return text;
}

function pdPromptLocalIndex(prompt) {
    const tagPrompts = (projectData.prompts || []).filter(p => p.tag === prompt?.tag);
    const idx = tagPrompts.findIndex(p => p.id === prompt?.id);
    return idx >= 0 ? idx + 1 : pdPromptProjectIndex(prompt);
}

function pdPromptLibrarySectionCollapsed(tagName) {
    if (!window.pdPromptLibraryCollapsedByTag || typeof window.pdPromptLibraryCollapsedByTag !== 'object') window.pdPromptLibraryCollapsedByTag = {};
    return !!window.pdPromptLibraryCollapsedByTag[tagName];
}

function pdTogglePromptLibrarySection(tagName) {
    if (!window.pdPromptLibraryCollapsedByTag || typeof window.pdPromptLibraryCollapsedByTag !== 'object') window.pdPromptLibraryCollapsedByTag = {};
    window.pdPromptLibraryCollapsedByTag[tagName] = !window.pdPromptLibraryCollapsedByTag[tagName];
    renderPromptLibrary();
}

function pdPromptLibraryDragStart(event, promptId) {
    window.pdPromptLibraryDraggingPromptId = promptId;
    if (event?.currentTarget?.classList) event.currentTarget.classList.add('pd-dragging');
    if (!event || !event.dataTransfer) return;
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('application/x-prompt-id', promptId);
    event.dataTransfer.setData('text/plain', promptId);
}

function pdPromptLibraryDragEnd(event) {
    if (event?.currentTarget?.classList) event.currentTarget.classList.remove('pd-dragging');
    pdPromptLibraryClearDropMarkers();
    window.pdPromptLibraryDraggingPromptId = null;
}

function pdPromptLibraryGetDragId(event) {
    return event?.dataTransfer?.getData('application/x-prompt-id')
        || event?.dataTransfer?.getData('promptId')
        || event?.dataTransfer?.getData('text/plain')
        || window.pdPromptLibraryDraggingPromptId
        || '';
}

function pdPromptLibraryClearDropMarkers() {
    document.querySelectorAll('#prompt-list .drop-before,#prompt-list .drop-after,#prompt-list .drag-over').forEach(el => el.classList.remove('drop-before', 'drop-after', 'drag-over'));
}

function pdPromptLibraryEntryInsertAfter(event) {
    const entry = event?.target?.closest?.('.pd-prompt-library-entry') || event?.currentTarget?.closest?.('.pd-prompt-library-entry');
    if (!entry || typeof entry.getBoundingClientRect !== 'function') return true;
    const rect = entry.getBoundingClientRect();
    return event.clientY > rect.top + (rect.height * 0.5);
}

function pdPromptLibraryEntryDragOver(event, targetPromptId) {
    if (!event) return;
    const draggedId = pdPromptLibraryGetDragId(event);
    if (!draggedId || draggedId === targetPromptId) return;
    event.preventDefault();
    event.stopPropagation();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    const entry = event.currentTarget?.closest?.('.pd-prompt-library-entry');
    if (!entry) return;
    entry.classList.remove('drop-before', 'drop-after');
    entry.classList.add(pdPromptLibraryEntryInsertAfter(event) ? 'drop-after' : 'drop-before');
}

function pdPromptLibraryEntryDragLeave(event) {
    const entry = event?.currentTarget?.closest?.('.pd-prompt-library-entry');
    entry?.classList?.remove('drop-before', 'drop-after');
}

function pdPromptLibraryEntryDrop(event, targetPromptId) {
    if (!event) return;
    event.preventDefault();
    event.stopPropagation();
    const draggedId = pdPromptLibraryGetDragId(event);
    const target = (projectData.prompts || []).find(p => p.id === targetPromptId);
    const insertAfter = pdPromptLibraryEntryInsertAfter(event);
    pdPromptLibraryClearDropMarkers();
    if (!draggedId || !target) return;
    pdMovePromptToTagAndIndex(draggedId, target.tag, targetPromptId, insertAfter);
}

function pdPromptLibraryDragOver(event) {
    if (!event) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    const section = event.currentTarget?.closest?.('.pd-prompt-library-section') || event.currentTarget;
    section?.classList?.add('drag-over');
}

function pdPromptLibraryDragLeave(event) {
    const section = event.currentTarget?.closest?.('.pd-prompt-library-section') || event.currentTarget;
    section?.classList?.remove('drag-over');
}

function pdPromptLibrarySectionBodyDragOver(event) {
    if (!event) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    event.currentTarget?.classList?.add('drag-over');
}

function pdPromptLibrarySectionBodyDragLeave(event) {
    event?.currentTarget?.classList?.remove('drag-over');
}

function pdPromptLibraryDrop(event, tagName) {
    if (!event) return;
    event.preventDefault();
    event.stopPropagation();
    const promptId = pdPromptLibraryGetDragId(event);
    pdPromptLibraryClearDropMarkers();
    pdMovePromptToTagAndIndex(promptId, tagName, null, true);
}

function pdMovePromptToTag(promptId, tagName) {
    pdMovePromptToTagAndIndex(promptId, tagName, null, true);
}

function pdMovePromptToTagAndIndex(promptId, tagName, targetPromptId, insertAfter) {
    if (!Array.isArray(projectData.prompts) || !promptId || !tagName) return;
    const sourceIndex = projectData.prompts.findIndex(p => p.id === promptId);
    if (sourceIndex < 0) return;
    const prompt = projectData.prompts[sourceIndex];
    const oldTag = prompt.tag;
    projectData.prompts.splice(sourceIndex, 1);
    prompt.tag = tagName;

    let insertIndex = projectData.prompts.length;
    if (targetPromptId) {
        const targetIndex = projectData.prompts.findIndex(p => p.id === targetPromptId);
        if (targetIndex >= 0) insertIndex = targetIndex + (insertAfter ? 1 : 0);
    } else {
        const lastInTag = projectData.prompts.reduce((last, item, index) => item.tag === tagName ? index : last, -1);
        insertIndex = lastInTag >= 0 ? lastInTag + 1 : projectData.prompts.length;
    }

    if (insertIndex < 0) insertIndex = 0;
    if (insertIndex > projectData.prompts.length) insertIndex = projectData.prompts.length;
    projectData.prompts.splice(insertIndex, 0, prompt);
    activePromptId = prompt.id;
    activeTag = tagName;
    window.activePromptId = activePromptId;
    window.activeTag = activeTag;
    pdEnsureLastActivePerCategory()[tagName] = prompt.id;
    if (window.pdPromptLibraryCollapsedByTag && typeof window.pdPromptLibraryCollapsedByTag === 'object') {
        window.pdPromptLibraryCollapsedByTag[tagName] = false;
    }

    if (typeof showNotification === 'function') {
        showNotification(oldTag === tagName ? `Moved within ${tagName}` : `Moved to ${tagName}`);
    }
    renderLists();
    renderLogicPanel();
    renderEditor();
    pdFocusActivePromptInCenter();
}

function handlePromptDragStart(event, id) {
    pdPromptLibraryDragStart(event, id);
}

function handlePromptDrop(event, tagName) {
    pdPromptLibraryDrop(event, tagName);
}


function pdLoadPromptFromSidebar(promptId) {
    const id = String(promptId || '');
    const prompt = (projectData.prompts || []).find(item => String(item.id || '') === id);
    if (!prompt) return;
    activePromptId = prompt.id;
    if (prompt.tag) {
        activeTag = prompt.tag;
        pdEnsureLastActivePerCategory()[prompt.tag] = prompt.id;
        if (window.pdPromptLibraryCollapsedByTag && typeof window.pdPromptLibraryCollapsedByTag === 'object') {
            window.pdPromptLibraryCollapsedByTag[prompt.tag] = false;
        }
    }
    window.activePromptId = activePromptId;
    window.activeTag = activeTag;
    renderLists();
    renderEditor();
    pdFocusActivePromptInCenter();
}

function pdFocusActivePromptInCenter() {
    window.setTimeout(() => {
        const card = document.getElementById('active-prompt-card');
        if (!card || typeof card.scrollIntoView !== 'function') return;
        try { card.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (err) { card.scrollIntoView(); }
    }, 0);
}

function pdInstallPromptLibraryInteractions(list) {
    if (!list || list.dataset.pdPromptLibraryInteractions === '1') return;
    list.dataset.pdPromptLibraryInteractions = '1';

    list.addEventListener('click', function(event) {
        const target = event.target;
        if (!target || target.closest('.pd-prompt-library-delete') || target.closest('.pd-prompt-library-section-header')) return;
        const entry = target.closest('.pd-prompt-library-entry[data-prompt-id]');
        if (!entry || !list.contains(entry)) return;
        if (window.pdPromptLibrarySuppressClickUntil && Date.now() < window.pdPromptLibrarySuppressClickUntil) return;
        event.preventDefault();
        event.stopPropagation();
        if (typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation();
        pdLoadPromptFromSidebar(entry.dataset.promptId);
    }, true);

    list.addEventListener('dragstart', function(event) {
        const entry = event.target?.closest?.('.pd-prompt-library-entry[data-prompt-id]');
        if (!entry || !list.contains(entry)) return;
        event.stopPropagation();
        if (typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation();
        entry.classList.add('pd-dragging');
        pdPromptLibraryDragStart(event, entry.dataset.promptId);
    }, true);

    list.addEventListener('dragover', function(event) {
        const promptId = window.pdPromptLibraryDraggingPromptId || '';
        if (!promptId) return;
        const entry = event.target?.closest?.('.pd-prompt-library-entry[data-prompt-id]');
        const section = event.target?.closest?.('.pd-prompt-library-section[data-tag-name]');
        const sectionBody = event.target?.closest?.('.pd-prompt-library-section-body[data-tag-name]');
        if (!entry && !section && !sectionBody) return;
        event.preventDefault();
        event.stopPropagation();
        if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
        pdPromptLibraryClearDropMarkers();
        if (entry && entry.dataset.promptId !== String(promptId)) {
            entry.classList.add(pdPromptLibraryEntryInsertAfter(event) ? 'drop-after' : 'drop-before');
        } else {
            (sectionBody || section)?.classList?.add('drag-over');
            section?.classList?.add('drag-over');
        }
    }, true);

    list.addEventListener('dragleave', function(event) {
        const leaving = event.target?.closest?.('.pd-prompt-library-entry, .pd-prompt-library-section, .pd-prompt-library-section-body');
        const entering = event.relatedTarget?.closest?.('.pd-prompt-library-entry, .pd-prompt-library-section, .pd-prompt-library-section-body');
        if (leaving && leaving === entering) return;
        if (leaving && (!entering || !leaving.contains(entering))) {
            leaving.classList.remove('drop-before', 'drop-after', 'drag-over');
        }
    }, true);

    list.addEventListener('drop', function(event) {
        const promptId = pdPromptLibraryGetDragId(event);
        if (!promptId) return;
        const entry = event.target?.closest?.('.pd-prompt-library-entry[data-prompt-id]');
        const section = event.target?.closest?.('.pd-prompt-library-section[data-tag-name]');
        const sectionBody = event.target?.closest?.('.pd-prompt-library-section-body[data-tag-name]');
        let handled = false;

        event.preventDefault();
        event.stopPropagation();
        if (typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation();
        pdPromptLibraryClearDropMarkers();
        window.pdPromptLibrarySuppressClickUntil = Date.now() + 350;

        if (entry && entry.dataset.promptId && entry.dataset.promptId !== String(promptId)) {
            const target = (projectData.prompts || []).find(p => String(p.id || '') === String(entry.dataset.promptId));
            if (target) {
                pdMovePromptToTagAndIndex(promptId, target.tag, target.id, pdPromptLibraryEntryInsertAfter(event));
                handled = true;
            }
        }

        if (!handled) {
            const tagName = sectionBody?.dataset?.tagName || section?.dataset?.tagName || '';
            if (tagName) {
                pdMovePromptToTagAndIndex(promptId, tagName, null, true);
                handled = true;
            }
        }

        if (handled) window.pdPromptLibraryDraggingPromptId = null;
    }, true);

    list.addEventListener('dragend', function(event) {
        pdPromptLibraryDragEnd(event);
        window.pdPromptLibrarySuppressClickUntil = Date.now() + 350;
    }, true);
}

function pdEnsureLastActivePerCategory() {
    if (typeof window.lastActivePerCategory === 'undefined' || !window.lastActivePerCategory || typeof window.lastActivePerCategory !== 'object') window.lastActivePerCategory = {};
    return window.lastActivePerCategory;
}

function selectCategory(tagName) {
    pdEnsureImportRuntimeShape();
    const tag = (projectData.tags || []).find(t => t.name === tagName) || null;
    activeTag = tag ? tag.name : tagName;
    const lastMap = pdEnsureLastActivePerCategory();
    if (lastMap[activeTag] && (projectData.prompts || []).some(prompt => prompt.id === lastMap[activeTag] && prompt.tag === activeTag)) {
        activePromptId = lastMap[activeTag];
    } else {
        const firstPrompt = (projectData.prompts || []).find(prompt => prompt.tag === activeTag);
        activePromptId = firstPrompt ? firstPrompt.id : null;
        if (activePromptId) lastMap[activeTag] = activePromptId;
    }
    window.activeTag = activeTag;
    window.activePromptId = activePromptId;
    renderLists();
    renderEditor();
}

function selectPrompt(id) {
    pdEnsureImportRuntimeShape();
    pdLoadPromptFromSidebar(id);
}

function updatePromptTag(tagName) {
    const prompt = (projectData.prompts || []).find(item => item.id === activePromptId);
    if (!prompt || !tagName) return;
    pdMovePromptToTag(prompt.id, tagName);
}

function renderEditor() {
    pdEnsureImportRuntimeShape();
    const editor = document.getElementById('editor-content');
    const placeholder = document.getElementById('placeholder-text');
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!editor || !placeholder) return;
    if (!prompt) {
        editor.style.display = 'none';
        placeholder.style.display = 'flex';
        return;
    }
    editor.style.display = 'block';
    placeholder.style.display = 'none';
    window.activePromptId = activePromptId;
    window.activeTag = activeTag;

    const tag = projectData.tags.find(t => t.name === prompt.tag) || projectData.tags[0] || { color: '#00f2ff', name: prompt.tag || 'News Alert' };
    const card = document.getElementById('active-prompt-card');
    if (card) {
        card.style.borderLeftColor = pdColorForImport(tag.color, '#00f2ff');
        card.classList.toggle('pd-prompt-collapsed', !!prompt.isCollapsed);
    }
    pdEnsurePromptNumberTab(prompt);

    const title = pdGetPromptTextForRender(prompt, 'title');
    const body = pdGetPromptTextForRender(prompt, 'bodyText');
    pdSetValue('view-title', title || 'Prompt Editor', 'text');
    pdSetValue('prompt-panel-id', prompt.id || '', 'text');
    pdSetValue('edit-title', title, 'value');
    pdSetValue('edit-body', body, 'value');
    pdSetValue('edit-priority', prompt.priority || 0, 'value');
    pdSetChecked('edit-repeatable', prompt.isRepeatable);
    pdSetChecked('edit-isCalledExternally', prompt.isCalledExternally);
    pdSetChecked('edit-makeExternalCall', prompt.makeExternalCall);
    pdSetChecked('edit-hasTriggers', prompt.hasTriggers);
    pdSetChecked('edit-hasVisualPayload', prompt.hasVisualPayload);
    pdSetChecked('edit-hasButton', prompt.hasButton);
    pdSetChecked('winReopenDialogue', prompt.winReopenDialogue);
    pdSetChecked('winCloseDialogue', prompt.winCloseDialogue);
    pdSetChecked('winReopenMainMenu', prompt.winReopenMainMenu);
    pdSetChecked('winCloseMainMenu', prompt.winCloseMainMenu);
    pdSetChecked('winClosePromptPanel', prompt.winClosePromptPanel);

    populateTagDropdown();
    renderWindowPositionSelect(prompt);
    renderBackgroundControls(prompt);
    renderArray('conditions');
    renderArray('gameStateChanges');
    pdSyncPromptLogicSectionVisibility();
    renderTriggers();
    renderVisualPayloads();
    renderActionButtons();
    renderFramesAndPositions();
    toggleTriggersUI();
    toggleVisualPayloadUI();
    toggleButtonUI();
    updateFormatButtons();
    updatePreview();
    updateDynamicGlows();
}

function pdSetValue(id, value, mode) {
    const el = document.getElementById(id);
    if (!el) return;
    if (mode === 'text') el.textContent = value === undefined || value === null ? '' : String(value);
    else el.value = value === undefined || value === null ? '' : value;
}

function pdSetChecked(id, value) {
    const el = document.getElementById(id);
    if (el) el.checked = !!value;
}

function renderWindowPositionSelect(prompt) {
    const select = document.getElementById('edit-window-position');
    if (!select) return;
    select.innerHTML = getPositionOptionsHTML(prompt.windowPositionId || '');
}

function renderBackgroundControls(prompt) {
    const container = document.getElementById('container-bg-controls');
    if (!container) return;
    const type = prompt.backgroundTintType || 'none';
    const opacity = pdNumberForImport(prompt.backgroundTintOpacity, 0);
    container.innerHTML = `<label class="section-header text-dim">Background Tint</label>
        <div class="bg-black/30 p-4 border border-white/5 flex flex-col gap-3">
            <select onchange="updateActivePromptBGType(this.value)">
                ${['none','half','black','custom'].map(option => `<option value="${option}" ${type === option ? 'selected' : ''}>${option.toUpperCase()}</option>`).join('')}
            </select>
            <div class="flex items-center gap-3 ${type === 'none' ? 'hidden' : ''}">
                <input type="range" min="0" max="1" step="0.01" value="${opacity}" oninput="updateActivePromptBGOpacity(this.value)">
                <span id="bg-opacity-display" class="text-xs text-dim font-mono">${opacity.toFixed(2)}</span>
            </div>
        </div>`;
}

function renderArray(type) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const container = document.getElementById(`container-${type}`);
    if (!prompt || !container) return;
    const rows = Array.isArray(prompt[type]) ? prompt[type] : [];
    const isCondition = type === 'conditions';
    container.innerHTML = rows.map((row, index) => `<div class="array-row">
        <input type="text" value="${pdAttr(row.key || '')}" placeholder="Key" oninput="updateArrayItem('${type}', ${index}, 'key', this.value)">
        <select onchange="updateArrayItem('${type}', ${index}, 'op', this.value)">${pdOperatorOptions(row.op, isCondition)}</select>
        <input type="text" value="${pdAttr(row.val || '')}" placeholder="Value" oninput="updateArrayItem('${type}', ${index}, 'val', this.value)">
        <button class="btn btn-outline text-accent-pink px-2 py-1" onclick="pdRemovePromptLogicItem('${type}', ${index})">×</button>
    </div>`).join('') || `<div class="pd-empty-note">No ${isCondition ? 'conditions' : 'state changes'} configured.</div>`;
}

function pdTogglePromptLogicSection(key) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    if (prompt[key] === undefined) prompt[key] = true;
    prompt[key] = !prompt[key];
    pdSyncPromptLogicSectionVisibility();
    if (typeof refreshPush === 'function') refreshPush();
}

function pdAddPromptLogicItem(type) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('pdAddPromptLogicItem: no active prompt', { type, activePromptId }, 'error');
        console.error('[PromptDesigner] Cannot add prompt logic row: no active prompt', { type, activePromptId });
        return;
    }
    if (!Array.isArray(prompt[type])) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('pdAddPromptLogicItem: repaired prompt logic array', { type, previousType: typeof prompt[type] }, 'warn');
        prompt[type] = [];
    }
    prompt[type].push({ key: '', op: '==', val: '' });
    if (type === 'conditions') prompt.conditionsOpen = true;
    if (type === 'gameStateChanges') prompt.statesOpen = true;
    if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('pdAddPromptLogicItem: added row', { type, length: prompt[type].length }, 'info');
    renderArray(type);
    pdSyncPromptLogicSectionVisibility();
    if (typeof renderLogicPanel === 'function') renderLogicPanel();
    if (typeof updateDynamicGlows === 'function') updateDynamicGlows();
    if (typeof refreshPush === 'function') refreshPush();
}

function pdRemovePromptLogicItem(type, index) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !Array.isArray(prompt[type])) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('pdRemovePromptLogicItem: missing prompt logic array', { type, index, activePromptId }, 'warn');
        return;
    }
    if (index < 0 || index >= prompt[type].length) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('pdRemovePromptLogicItem: index out of range', { type, index, length: prompt[type].length }, 'warn');
        return;
    }
    prompt[type].splice(index, 1);
    renderArray(type);
    pdSyncPromptLogicSectionVisibility();
    if (typeof renderLogicPanel === 'function') renderLogicPanel();
    if (typeof updateDynamicGlows === 'function') updateDynamicGlows();
    if (typeof refreshPush === 'function') refreshPush();
}

function pdInstallPromptLogicAddDelegation() {
    if (window.__pdPromptLogicAddDelegationInstalled) return;
    window.__pdPromptLogicAddDelegationInstalled = true;
    document.addEventListener('click', event => {
        const button = event.target.closest?.('[data-pd-logic-add-type]');
        if (!button || !document.getElementById('active-prompt-card')?.contains(button)) return;
        const type = button.dataset.pdLogicAddType;
        if (type !== 'conditions' && type !== 'gameStateChanges') return;
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        console.info('[PromptDesigner] prompt logic add button clicked', { type, engineBuild: window.PD_ENGINE_BUILD || null });
        pdAddPromptLogicItem(type);
    }, true);
}

function pdSyncPromptLogicSectionVisibility() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    pdInstallPromptLogicAddDelegation();

    [
        { type: 'conditions', key: 'conditionsOpen', fallbackTitle: 'Conditions', accentClass: 'pd-prompt-logic-pink' },
        { type: 'gameStateChanges', key: 'statesOpen', fallbackTitle: 'Change Game State', accentClass: 'pd-prompt-logic-green' }
    ].forEach(section => {
        if (prompt[section.key] === undefined) prompt[section.key] = true;
        const container = document.getElementById(`container-${section.type}`);
        if (!container) return;

        const titleRow = container.previousElementSibling;
        const innerBox = container.parentElement;
        const outerBlock = container.closest('.mb-6');
        if (innerBox) innerBox.classList.add('pd-prompt-logic-box', section.accentClass);
        if (outerBlock) outerBlock.classList.add('pd-prompt-logic-block');
        if (titleRow) {
            titleRow.classList.add('pd-prompt-logic-head');
            titleRow.style.cursor = 'pointer';
            titleRow.setAttribute('role', 'button');
            titleRow.setAttribute('tabindex', '0');
            titleRow.onclick = event => {
                if (event.target.closest('button,input,select,textarea,a')) return;
                if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('prompt logic section toggled', { key: section.key, type: section.type, nextOpen: !prompt[section.key] }, 'info');
                pdTogglePromptLogicSection(section.key);
            };
            titleRow.onkeydown = event => {
                if (event.key !== 'Enter' && event.key !== ' ') return;
                event.preventDefault();
                pdTogglePromptLogicSection(section.key);
            };
            const button = titleRow.querySelector('button');
            if (button) {
                button.classList.remove('pd-hidden-original-bool');
                button.classList.add('pd-prompt-logic-add');
                button.dataset.pdLogicAddType = section.type;
                button.type = 'button';
                button.onclick = event => {
                    event.preventDefault();
                    event.stopPropagation();
                    if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('prompt logic add clicked', { type: section.type, key: section.key }, 'info');
                    pdAddPromptLogicItem(section.type);
                };
            }
            const label = titleRow.querySelector('label');
            if (label) {
                if (!label.dataset.pdBaseTitle) label.dataset.pdBaseTitle = (label.textContent || '').replace(/\s[-+]$/, '').trim() || section.fallbackTitle;
                label.textContent = label.dataset.pdBaseTitle;
                let marker = titleRow.querySelector('.pd-prompt-logic-marker');
                if (!marker) {
                    marker = document.createElement('span');
                    marker.className = 'pd-prompt-logic-marker';
                    label.appendChild(marker);
                }
                marker.textContent = prompt[section.key] ? ' -' : ' +';
            }
        }

        container.classList.toggle('hidden', !prompt[section.key]);
    });
}

function pdOperatorOptions(selected, conditionMode) {
    const ops = conditionMode ? ['==', '!=', '>', '<', '>=', '<='] : ['==', '=', '+=', '-=', '!=', '>', '<', '>=', '<='];
    return ops.map(op => `<option value="${escapeHtml(op)}" ${selected === op ? 'selected' : ''}>${escapeHtml(op)}</option>`).join('');
}

function renderTriggers() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const container = document.getElementById('container-triggers');
    if (!prompt || !container) return;
    const triggers = Array.isArray(prompt.triggers) ? prompt.triggers : [];
    container.innerHTML = triggers.map((trigger, index) => `<div class="array-row" style="grid-template-columns:1fr 30px">
        <select onchange="updateTrigger(${index}, this.value)">${TRIGGER_EVENTS.map(evt => `<option value="${pdAttr(evt)}" ${trigger === evt ? 'selected' : ''}>${escapeHtml(evt)}</option>`).join('')}</select>
        <button class="btn btn-outline text-accent-pink px-2 py-1" onclick="removeTrigger(${index})">×</button>
    </div>`).join('') || `<div class="pd-empty-note">No trigger events configured.</div>`;
}

function renderVisualPayloads() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const container = document.getElementById('container-visualPayloads');
    if (!prompt || !container) return;
    const payloads = Array.isArray(prompt.visualPayloads) ? prompt.visualPayloads : [];
    container.innerHTML = payloads.map((payload, index) => `<div class="payload-row">
        <input type="text" value="${pdAttr(payload.name || '')}" placeholder="Slot Name" oninput="updateVisualPayload(${index}, 'name', this.value)">
        <input type="text" value="${pdAttr(payload.path || '')}" placeholder="Assets/Resources/..." oninput="updateVisualPayload(${index}, 'path', this.value)">
        <button class="btn btn-outline text-accent-pink px-2 py-1" onclick="removeVisualPayload(${index})">×</button>
    </div>`).join('') || `<div class="pd-empty-note">No visual payloads configured.</div>`;
}

function renderFramesAndPositions() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const container = document.getElementById('container-frames-positions');
    if (!prompt || !container) return;
    const frames = Array.isArray(prompt.frames) ? prompt.frames : [];
    const frameOptions = ['<option value="">-- Select Frame --</option>'].concat((projectData.globalFrames || []).map(frame => `<option value="${pdAttr(frame.id)}">${escapeHtml(frame.name || frame.id)}</option>`)).join('');
    container.innerHTML = frames.map((frame, index) => `<div class="bg-black/30 border border-white/10 p-3 space-y-2">
        <div class="flex justify-between items-center"><label class="section-header text-accent-pink mb-0">Frame ${index + 1}</label><button class="btn btn-outline text-accent-pink px-2 py-1" onclick="removeFrame(${index})">×</button></div>
        <select onchange="updateFrame(${index}, 'frameId', this.value)">${frameOptions.replace(`value=&quot;${pdAttr(frame.frameId || '')}&quot;`, `value=&quot;${pdAttr(frame.frameId || '')}&quot; selected`)}</select>
        <select onchange="updateFrame(${index}, 'positionId', this.value)">${getPositionOptionsHTML(frame.positionId || '')}</select>
        <div class="flex gap-6 text-[10px] uppercase font-black"><label><input type="checkbox" ${frame.disableOnClose ? 'checked' : ''} onchange="updateFrame(${index}, 'disableOnClose', this.checked)"> Disable On Close</label><label><input type="checkbox" ${frame.invert ? 'checked' : ''} onchange="updateFrame(${index}, 'invert', this.checked)"> Invert</label></div>
    </div>`).join('') + (frames.length < 2 ? `<button class="btn btn-outline w-full border-accent-pink text-accent-pink" onclick="addFrame()">+ ADD FRAME POSITION</button>` : '');
}

function renderActionButtons() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const container = document.getElementById('buttons-list');
    if (!prompt || !container) return;
    const buttons = Array.isArray(prompt.buttons) ? prompt.buttons : [];
    container.innerHTML = buttons.map((button, index) => {
        const text = pdGetButtonTextForRender(button);
        const branchOptions = ['<option value="">-- No Branch --</option>'].concat(projectData.prompts.filter(p => p.id !== prompt.id).map(p => `<option value="${pdAttr(p.id)}" ${button.branchPromptId === p.id ? 'selected' : ''}>${escapeHtml(pdGetPromptTextForRender(p, 'title') || p.title || p.id)}</option>`)).join('');
        return `<div class="pd-response-card ${button.isCollapsed ? 'collapsed' : ''}">
            <button class="pd-response-collapse-btn" onclick="buttonToggleCollapsed(${index})">${button.isCollapsed ? '+' : '-'}</button>
            <button class="pd-response-delete" onclick="removeActionButton(${index})">×</button>
            <div class="pd-response-id-row"><em>${escapeHtml(button.id || '')}</em><button class="pd-copy-button" onclick="pdCopyText('${pdAttr(button.id || '')}')">${pdCopyIcon()}</button></div>
            ${button.isCollapsed ? `<div class="pd-response-collapsed-text">${escapeHtml(text || 'Untitled Response')}</div>${button.voiceLine ? '<div class="pd-response-collapsed-voice">Voice Line</div>' : ''}` : `<div class="space-y-3">
                <label class="section-header text-accent-teal">Button Label</label>
                <input class="pd-response-text-input" type="text" value="${pdAttr(text)}" oninput="pdSetButtonTextForRender(${index}, this.value); updateActionButton(${index}, 'text', this.value)">
                <div class="pd-response-bool-row">
                    <label>Close Menu <input type="checkbox" ${button.closeMenu ? 'checked' : ''} onchange="updateActionButton(${index}, 'closeMenu', this.checked)"></label>
                    <label>External Link <input type="checkbox" ${button.isExternalLink ? 'checked' : ''} onchange="updateActionButton(${index}, 'isExternalLink', this.checked); renderActionButtons()"></label>
                    <label>Voice Line <input type="checkbox" ${button.voiceLine ? 'checked' : ''} onchange="updateActionButton(${index}, 'voiceLine', this.checked); renderActionButtons()"></label>
                </div>
                ${button.isExternalLink ? `<input type="text" value="${pdAttr(button.externalUrl || '')}" placeholder="https://..." oninput="updateActionButton(${index}, 'externalUrl', this.value)">` : ''}
                <label class="flex items-center gap-2 text-xs uppercase font-black text-accent-teal"><input type="checkbox" ${button.isBranching ? 'checked' : ''} onchange="toggleBranching(${index}, this.checked)"> Branch To Prompt</label>
                <select onchange="updateActionButton(${index}, 'branchPromptId', this.value || null); updateActionButton(${index}, 'isBranching', !!this.value)">${branchOptions}</select>
                <div class="pd-response-condition-head"><span>Button Conditions</span><button onclick="addButtonCondition(${index})">+ ADD</button></div>
                <div class="pd-response-condition-box">${renderButtonLogicRows(index, 'conditions')}</div>
                <div class="pd-response-condition-head"><span>Button State Changes</span><button onclick="addButtonStateChange(${index})">+ ADD</button></div>
                <div class="pd-response-condition-box">${renderButtonLogicRows(index, 'stateChanges')}</div>
            </div>`}
        </div>`;
    }).join('') || `<div class="pd-empty-note">No action buttons configured.</div>`;
}

function pdCopyIcon() {
    return `<svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>`;
}

function renderButtonLogicRows(buttonIndex, type) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const button = prompt?.buttons?.[buttonIndex];
    const rows = Array.isArray(button?.[type]) ? button[type] : [];
    const updateFn = type === 'conditions' ? 'updateButtonCondition' : 'updateButtonStateChange';
    const removeFn = type === 'conditions' ? 'removeButtonCondition' : 'removeButtonStateChange';
    return rows.map((row, rowIndex) => `<div class="array-row pd-mini-logic-row">
        <input value="${pdAttr(row.key || '')}" placeholder="Key" oninput="${updateFn}(${buttonIndex}, ${rowIndex}, 'key', this.value)">
        <select onchange="${updateFn}(${buttonIndex}, ${rowIndex}, 'op', this.value)">${pdOperatorOptions(row.op, type === 'conditions')}</select>
        <input value="${pdAttr(row.val || '')}" placeholder="Value" oninput="${updateFn}(${buttonIndex}, ${rowIndex}, 'val', this.value)">
        <button onclick="${removeFn}(${buttonIndex}, ${rowIndex})">×</button>
    </div>`).join('') || `<div class="pd-empty-note">No items configured.</div>`;
}

function buttonToggleCollapsed(index) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt?.buttons?.[index]) return;
    prompt.buttons[index].isCollapsed = !prompt.buttons[index].isCollapsed;
    renderActionButtons();
}

function addButtonCondition(buttonIndex) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt?.buttons?.[buttonIndex]) return;
    if (!Array.isArray(prompt.buttons[buttonIndex].conditions)) prompt.buttons[buttonIndex].conditions = [];
    prompt.buttons[buttonIndex].conditions.push({ key: '', op: '==', val: '' });
    renderActionButtons();
    renderLogicPanel();
    updateDynamicGlows();
}

function removeButtonCondition(buttonIndex, conditionIndex) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt?.buttons?.[buttonIndex]?.conditions) return;
    prompt.buttons[buttonIndex].conditions.splice(conditionIndex, 1);
    renderActionButtons();
    renderLogicPanel();
    updateDynamicGlows();
}

function updateButtonCondition(buttonIndex, conditionIndex, field, value) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt?.buttons?.[buttonIndex]?.conditions?.[conditionIndex]) return;
    prompt.buttons[buttonIndex].conditions[conditionIndex][field] = value;
    renderLogicPanel();
    updateDynamicGlows();
}

function toggleTriggersUI() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const container = document.getElementById('triggers-setup-container');
    if (container) container.classList.toggle('hidden', !(prompt && prompt.hasTriggers));
}

function toggleVisualPayloadUI() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const container = document.getElementById('visual-payload-container');
    if (container) container.classList.toggle('hidden', !(prompt && prompt.hasVisualPayload));
}

function toggleButtonUI() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const container = document.getElementById('button-setup-container');
    if (container) container.classList.toggle('hidden', !(prompt && prompt.hasButton));
}

function updateFormatButtons() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const f = prompt?.textFormat || {};
    const pairs = {
        'fmt-bold': !!f.bold,
        'fmt-italic': !!f.italic,
        'fmt-underline': !!f.underline,
        'fmt-strikethrough': !!f.strikethrough,
        'fmt-list-bullet': f.listStyle === 'bullet',
        'fmt-list-number': f.listStyle === 'number',
        'fmt-alignH-left': f.alignH === 'left',
        'fmt-alignH-center': f.alignH === 'center',
        'fmt-alignH-right': f.alignH === 'right',
        'fmt-alignH-justified': f.alignH === 'justified' || f.alignH === 'justify',
        'fmt-alignV-top': f.alignV === 'top',
        'fmt-alignV-middle': f.alignV === 'middle',
        'fmt-alignV-bottom': f.alignV === 'bottom'
    };
    Object.entries(pairs).forEach(([id, active]) => document.getElementById(id)?.classList.toggle('active', active));
}

function pdEscapePreviewHtml(value) {
    return String(value || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function pdTextWithTmpTagsToHtml(value) {
    let html = pdEscapePreviewHtml(value);
    html = html.replace(/&lt;b&gt;/gi, '<strong>').replace(/&lt;\/b&gt;/gi, '</strong>');
    html = html.replace(/&lt;i&gt;/gi, '<em>').replace(/&lt;\/i&gt;/gi, '</em>');
    html = html.replace(/&lt;u&gt;/gi, '<span style="text-decoration:underline">').replace(/&lt;\/u&gt;/gi, '</span>');
    html = html.replace(/&lt;s&gt;/gi, '<span style="text-decoration:line-through">').replace(/&lt;\/s&gt;/gi, '</span>');
    html = html.replace(/&lt;align=&quot;(left|center|right|justified|justify)&quot;&gt;/gi, (_, align) => `<span style="display:block;text-align:${align === 'justified' ? 'justify' : align}">`);
    html = html.replace(/&lt;\/align&gt;/gi, '</span>');
    html = html.replace(/&lt;\/?[^&]+?&gt;/g, '');
    return html;
}

function pdPreviewTextToHtml(value, format) {
    const lines = String(value || '').replace(/\r\n/g, '\n').split('\n');
    if (format?.listStyle === 'bullet' || format?.listStyle === 'number') {
        const tag = format.listStyle === 'number' ? 'ol' : 'ul';
        const items = lines.filter(line => line.trim().length > 0).map(line => `<li>${pdTextWithTmpTagsToHtml(line.replace(/^\s*(?:•|\d+\.)\s*/, ''))}</li>`).join('');
        return items ? `<${tag}>${items}</${tag}>` : '';
    }
    return lines.map(line => pdTextWithTmpTagsToHtml(line)).join('<br>');
}

function updatePreview() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const preview = document.getElementById('live-preview');
    if (!prompt || !preview) return;
    let text = pdGetPromptTextForRender(prompt, 'bodyText') || '';
    (projectData.tokens || []).forEach(token => {
        const key = token.key || '';
        if (!key) return;
        text = text.split(`{{${key}}}`).join(token.value || '');
    });

    const f = prompt.textFormat || {};
    const textDecorations = [];
    if (f.underline) textDecorations.push('underline');
    if (f.strikethrough) textDecorations.push('line-through');
    const alignH = f.alignH === 'justified' ? 'justify' : (f.alignH || 'left');
    const alignV = f.alignV === 'middle' ? 'center' : (f.alignV === 'bottom' ? 'flex-end' : 'flex-start');

    preview.classList.add('pd-live-preview-formatted');
    preview.style.fontWeight = f.bold ? '900' : '';
    preview.style.fontStyle = f.italic ? 'italic' : '';
    preview.style.textDecoration = textDecorations.join(' ');
    preview.style.textAlign = alignH;
    preview.style.justifyContent = alignV;
    preview.innerHTML = pdPreviewTextToHtml(text, f);
}

function renderGlobalSections() {
    pdEnsureImportRuntimeShape();
    const container = document.getElementById('global-sections-container');
    if (!container) return;
    container.innerHTML = GLOBAL_SECTIONS.map(section => {
        pdEnsureGlobalSectionItemIds(section.key);
        const items = Array.isArray(projectData[section.key]) ? projectData[section.key] : [];
        return `<hr class="border-white/10 my-6"><h3 class="text-accent-orange">${escapeHtml(section.title)}</h3>
            <div class="flex gap-1 mb-2 items-center bg-[#111] border border-white/10 p-1">
                <input type="text" id="new-${pdAttr(section.key)}-name" placeholder="${pdAttr(section.placeholder)}" class="flex-1 bg-transparent border-none focus:outline-none focus:border-none text-xs px-2">
                <input type="color" id="new-${pdAttr(section.key)}-color" value="${getRandomHex()}" class="w-6 h-6 p-0 cursor-pointer border border-white/20 bg-transparent shrink-0">
                <button class="btn bg-cyan-400 text-black px-3 py-1 hover:bg-cyan-300 ml-1" onclick="addGlobalItem('${pdAttr(section.key)}')">+</button>
            </div>
            <ul class="sidebar-list pd-global-sort-list" data-pd-global-section="${pdAttr(section.key)}" ondragover="pdGlobalSectionDragOver(event, '${pdAttr(section.key)}')" ondragleave="pdGlobalSectionDragLeave(event)" ondrop="pdGlobalSectionDrop(event, '${pdAttr(section.key)}')">${items.map(item => renderGlobalSectionItem(section.key, item)).join('') || '<li class="text-dim italic">No entries yet.</li>'}</ul>`;
    }).join('');
}

function renderGlobalSectionItem(sectionKey, item) {
    const id = item.id || '';
    const color = pdColorForImport(item.color, '#00f2ff');
    const name = pdStringForImport(item.name, 'Unnamed');
    if (editingGlobalItem.section === sectionKey && editingGlobalItem.id === id) {
        return `<li class="pd-left-draggable-item pd-left-editing-item" style="border-left-color:${color}"><div class="flex gap-1 w-full items-center"><input id="edit-${pdAttr(sectionKey)}-${pdAttr(id)}-name" value="${pdAttr(name)}" class="text-xs" onkeydown="pdHandleGlobalEditKey(event, '${pdAttr(sectionKey)}', '${pdAttr(id)}')"><input id="edit-${pdAttr(sectionKey)}-${pdAttr(id)}-color" type="color" value="${color}" class="w-7 h-7 p-0"><button class="btn btn-green px-2 py-1" onclick="saveGlobalItemEdit('${pdAttr(sectionKey)}', '${pdAttr(id)}')">✓</button><button class="btn btn-outline px-2 py-1" onclick="cancelGlobalItemEdit()">✖</button></div></li>`;
    }
    return `<li class="pd-left-draggable-item pd-global-entry" style="border-left-color:${color}" draggable="true" data-pd-global-section="${pdAttr(sectionKey)}" data-pd-global-id="${pdAttr(id)}" ondblclick="pdStartGlobalItemEditFromDblClick(event, '${pdAttr(sectionKey)}', '${pdAttr(id)}')" ondragstart="pdGlobalItemDragStart(event, '${pdAttr(sectionKey)}', '${pdAttr(id)}')" ondragover="pdGlobalItemDragOver(event, '${pdAttr(sectionKey)}', '${pdAttr(id)}')" ondragleave="pdGlobalItemDragLeave(event)" ondrop="pdGlobalItemDrop(event, '${pdAttr(sectionKey)}', '${pdAttr(id)}')" ondragend="pdGlobalItemDragEnd(event)"><span class="font-black uppercase pd-inline-edit-trigger" style="color:${color}">${escapeHtml(name)}</span><div class="flex gap-2"><button class="text-accent-teal" onclick="event.stopPropagation(); startGlobalItemEdit('${pdAttr(sectionKey)}', '${pdAttr(id)}')">✎</button><button class="text-accent-pink" onclick="event.stopPropagation(); deleteGlobalItem('${pdAttr(sectionKey)}', '${pdAttr(id)}')">×</button></div></li>`;
}

function pdEnsureGlobalSectionItemIds(sectionKey) {
    if (!Array.isArray(projectData[sectionKey])) projectData[sectionKey] = [];
    projectData[sectionKey].forEach(item => {
        if (item && !item.id) item.id = pdGenerateIdForImport();
    });
}

function pdShouldIgnoreInlineEditEvent(event) {
    if (event?.target?.closest?.('.pd-inline-edit-trigger')) return false;
    return !!event?.target?.closest?.('button, input, textarea, select, option, label, a');
}

function pdStartGlobalItemEditFromDblClick(event, sectionKey, id) {
    if (pdShouldIgnoreInlineEditEvent(event)) return;
    event.preventDefault();
    event.stopPropagation();
    startGlobalItemEdit(sectionKey, id);
}

function pdHandleGlobalEditKey(event, sectionKey, id) {
    if (event.key === 'Enter') {
        event.preventDefault();
        saveGlobalItemEdit(sectionKey, id);
    } else if (event.key === 'Escape') {
        event.preventDefault();
        cancelGlobalItemEdit();
    }
}

function pdGlobalItemDragStart(event, sectionKey, id) {
    const payload = JSON.stringify({ sectionKey, id });
    window.pdDraggingGlobalItem = { sectionKey, id };
    event.currentTarget?.classList?.add('pd-left-dragging');
    if (event.dataTransfer) {
        event.dataTransfer.effectAllowed = 'move';
        event.dataTransfer.setData('application/x-pd-global-item', payload);
        event.dataTransfer.setData('text/plain', payload);
    }
    event.stopPropagation();
}

function pdGetGlobalDragPayload(event) {
    const raw = event?.dataTransfer?.getData?.('application/x-pd-global-item') || event?.dataTransfer?.getData?.('text/plain') || '';
    if (raw) {
        try { return JSON.parse(raw); } catch (err) {}
    }
    return window.pdDraggingGlobalItem || null;
}

function pdGlobalInsertAfter(event) {
    const rect = event.currentTarget?.getBoundingClientRect?.();
    if (!rect) return true;
    return event.clientY > rect.top + rect.height / 2;
}

function pdGlobalItemDragOver(event, sectionKey, id) {
    const payload = pdGetGlobalDragPayload(event);
    if (!payload || payload.sectionKey !== sectionKey || payload.id === id) return;
    event.preventDefault();
    event.stopPropagation();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    pdClearLeftDropMarkers();
    event.currentTarget?.classList?.add(pdGlobalInsertAfter(event) ? 'pd-drop-after' : 'pd-drop-before');
}

function pdGlobalItemDragLeave(event) {
    event.currentTarget?.classList?.remove('pd-drop-before', 'pd-drop-after');
}

function pdGlobalItemDrop(event, sectionKey, targetId) {
    const payload = pdGetGlobalDragPayload(event);
    if (!payload || payload.sectionKey !== sectionKey || payload.id === targetId) return;
    event.preventDefault();
    event.stopPropagation();
    pdMoveGlobalItem(sectionKey, payload.id, targetId, pdGlobalInsertAfter(event));
}

function pdGlobalItemDragEnd(event) {
    event.currentTarget?.classList?.remove('pd-left-dragging');
    pdClearLeftDropMarkers();
    window.pdDraggingGlobalItem = null;
}

function pdGlobalSectionDragOver(event, sectionKey) {
    const payload = pdGetGlobalDragPayload(event);
    if (!payload || payload.sectionKey !== sectionKey) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    event.currentTarget?.classList?.add('pd-left-list-drag-over');
}

function pdGlobalSectionDragLeave(event) {
    if (!event.currentTarget?.contains?.(event.relatedTarget)) event.currentTarget?.classList?.remove('pd-left-list-drag-over');
}

function pdGlobalSectionDrop(event, sectionKey) {
    const payload = pdGetGlobalDragPayload(event);
    if (!payload || payload.sectionKey !== sectionKey) return;
    event.preventDefault();
    event.stopPropagation();
    if (event.target?.closest?.('.pd-global-entry')) return;
    pdMoveGlobalItem(sectionKey, payload.id, null, true);
}

function pdMoveGlobalItem(sectionKey, draggedId, targetId, insertAfter) {
    const list = projectData[sectionKey];
    if (!Array.isArray(list)) return;
    const from = list.findIndex(item => String(item.id || '') === String(draggedId));
    if (from < 0) return;
    const [moved] = list.splice(from, 1);
    if (targetId) {
        let to = list.findIndex(item => String(item.id || '') === String(targetId));
        if (to < 0) to = list.length;
        if (insertAfter) to += 1;
        list.splice(Math.min(to, list.length), 0, moved);
    } else {
        list.push(moved);
    }
    editingGlobalItem = { section: null, id: null };
    pdClearLeftDropMarkers();
    renderGlobalSections();
    if (activePromptId && sectionKey === 'globalFrames') renderEditor();
}

function pdClearLeftDropMarkers() {
    document.querySelectorAll('.pd-drop-before,.pd-drop-after,.pd-left-dragging,.pd-left-list-drag-over,.pd-left-list-drop').forEach(el => el.classList.remove('pd-drop-before', 'pd-drop-after', 'pd-left-dragging', 'pd-left-list-drag-over', 'pd-left-list-drop'));
}


function pdStartTokenEditFromDblClick(event, index) {
    if (pdShouldIgnoreInlineEditEvent(event)) return;
    event.preventDefault();
    event.stopPropagation();
    startTokenEdit(index);
}

function pdStartTagEditFromDblClick(event, index) {
    if (pdShouldIgnoreInlineEditEvent(event)) return;
    event.preventDefault();
    event.stopPropagation();
    startTagEdit(index);
}

function pdHandleTokenEditKey(event, index) {
    if (event.key === 'Enter') {
        event.preventDefault();
        saveTokenKeyEdit(index);
    } else if (event.key === 'Escape') {
        event.preventDefault();
        cancelTokenEdit();
    }
}

function pdHandleTagEditKey(event, index) {
    if (event.key === 'Enter') {
        event.preventDefault();
        saveTagEdit(index);
    } else if (event.key === 'Escape') {
        event.preventDefault();
        cancelTagEdit();
    }
}

function pdLeftListDragStart(event, kind, index) {
    const payload = JSON.stringify({ kind, index });
    window.pdDraggingLeftListItem = { kind, index };
    event.currentTarget?.classList?.add('pd-left-dragging');
    if (event.dataTransfer) {
        event.dataTransfer.effectAllowed = 'move';
        event.dataTransfer.setData('application/x-pd-left-list-item', payload);
        event.dataTransfer.setData('text/plain', payload);
    }
    event.stopPropagation();
}

function pdGetLeftListDragPayload(event) {
    const raw = event?.dataTransfer?.getData?.('application/x-pd-left-list-item') || event?.dataTransfer?.getData?.('text/plain') || '';
    if (raw) {
        try { return JSON.parse(raw); } catch (err) {}
    }
    return window.pdDraggingLeftListItem || null;
}

function pdLeftListInsertAfter(event) {
    const rect = event.currentTarget?.getBoundingClientRect?.();
    if (!rect) return true;
    return event.clientY > rect.top + rect.height / 2;
}

function pdLeftListDragOver(event) {
    const payload = pdGetLeftListDragPayload(event);
    const kind = event.currentTarget?.dataset?.pdListKind || '';
    if (!payload || payload.kind !== kind) return;
    const targetIndex = kind === 'tokens' ? Number(event.currentTarget.dataset.pdTokenIndex) : Number(event.currentTarget.dataset.pdTagIndex);
    if (!Number.isFinite(targetIndex) || targetIndex === Number(payload.index)) return;
    event.preventDefault();
    event.stopPropagation();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    pdClearLeftDropMarkers();
    event.currentTarget?.classList?.add(pdLeftListInsertAfter(event) ? 'pd-drop-after' : 'pd-drop-before');
}

function pdLeftListDragLeave(event) {
    event.currentTarget?.classList?.remove('pd-drop-before', 'pd-drop-after');
}

function pdLeftListDrop(event, kind, targetIndex) {
    const payload = pdGetLeftListDragPayload(event);
    if (!payload || payload.kind !== kind) return;
    event.preventDefault();
    event.stopPropagation();
    pdMoveLeftListItem(kind, Number(payload.index), Number(targetIndex), pdLeftListInsertAfter(event));
}

function pdLeftListDragEnd(event) {
    event.currentTarget?.classList?.remove('pd-left-dragging');
    pdClearLeftDropMarkers();
    window.pdDraggingLeftListItem = null;
}

function pdMoveLeftListItem(kind, fromIndex, targetIndex, insertAfter) {
    const list = kind === 'tokens' ? projectData.tokens : kind === 'tags' ? projectData.tags : null;
    if (!Array.isArray(list)) return;
    if (fromIndex < 0 || fromIndex >= list.length || targetIndex < 0 || targetIndex >= list.length || fromIndex === targetIndex) return;
    const [moved] = list.splice(fromIndex, 1);
    let to = targetIndex;
    if (fromIndex < targetIndex) to -= 1;
    if (insertAfter) to += 1;
    list.splice(Math.max(0, Math.min(to, list.length)), 0, moved);
    pdClearLeftDropMarkers();
    if (kind === 'tokens') {
        editingTokenIdx = null;
        renderTokenList();
        if (typeof updatePreview === 'function') updatePreview();
    } else if (kind === 'tags') {
        editingTagIdx = null;
        populateTagDropdown();
        renderLists();
        if (activePromptId) renderEditor();
    }
}

function renderGlobalPositions() {
    pdEnsureImportRuntimeShape();
    const container = document.getElementById('global-positions-container');
    if (!container) return;
    const selectedType = lastSelectedPosTypeId && projectData.positionTypes.some(type => type.id === lastSelectedPosTypeId) ? lastSelectedPosTypeId : projectData.positionTypes[0]?.id || '';
    const typeOptions = projectData.positionTypes.map(type => `<option value="${pdAttr(type.id)}" ${selectedType === type.id ? 'selected' : ''}>${escapeHtml(type.name || type.id)}</option>`).join('');
    container.innerHTML = `<h3 class="text-accent-pink">Global Positions</h3>
        <div class="flex gap-1 mb-2"><input type="text" id="new-pos-type" placeholder="Position Group..." class="flex-1"><button class="btn bg-pink-500 text-white" onclick="addPositionType()">+</button></div>
        <div class="flex gap-1 mb-3 items-center"><select id="new-pos-tag-type" class="flex-1">${typeOptions}</select><input type="text" id="new-pos-tag" placeholder="Position Name..." class="flex-1"><input type="color" id="new-pos-tag-color" value="${getRandomHex()}" class="w-7 h-7 p-0"><button class="btn bg-cyan-400 text-black" onclick="addPositionTag()">+</button></div>
        <div class="space-y-3">${projectData.positionTypes.map(type => renderPositionTypeBlock(type)).join('') || '<div class="pd-empty-note">No position groups yet.</div>'}</div>`;
}

function renderPositionTypeBlock(type) {
    const collapsed = !!type.collapsed;
    const tags = Array.isArray(type.tags) ? type.tags : [];
    tags.forEach(tag => { if (tag && !tag.id) tag.id = pdGenerateIdForImport(); });
    const header = editingPosTypeId === type.id ? `<div class="flex gap-1 w-full"><input id="edit-postype-${pdAttr(type.id)}" value="${pdAttr(type.name || '')}" onkeydown="pdHandlePosTypeEditKey(event, '${pdAttr(type.id)}')"><button class="btn btn-green px-2 py-1" onclick="savePosTypeEdit('${pdAttr(type.id)}')">✓</button><button class="btn btn-outline px-2 py-1" onclick="cancelPosTypeEdit()">✖</button></div>` : `<div class="flex justify-between items-center gap-2" ondblclick="pdStartPosTypeEditFromDblClick(event, '${pdAttr(type.id)}')"><button class="flex-1 text-left font-black uppercase pd-inline-edit-trigger" onclick="togglePosTypeCollapse('${pdAttr(type.id)}')"><span class="triangle ${collapsed ? 'collapsed' : ''}">▼</span> ${escapeHtml(type.name || 'Position Group')}</button><div class="flex gap-2"><button class="text-accent-teal" onclick="event.stopPropagation(); startPosTypeEdit('${pdAttr(type.id)}')">✎</button><button class="text-accent-gold" onclick="event.stopPropagation(); sortLocalPositions('${pdAttr(type.id)}')">A-Z</button><button class="text-accent-pink" onclick="event.stopPropagation(); clearLocalPositions('${pdAttr(type.id)}')">Clear</button></div></div>`;
    return `<div class="pd-position-type-block bg-black/30 border border-white/10 p-2" draggable="true" data-pd-position-type-id="${pdAttr(type.id)}" ondragstart="handlePosTypeDragStart(event, '${pdAttr(type.id)}')" ondragover="pdPositionTypeDragOver(event, '${pdAttr(type.id)}')" ondragleave="pdPositionTypeDragLeave(event)" ondrop="pdPositionTypeDrop(event, '${pdAttr(type.id)}')" ondragend="pdPositionDragEnd(event)" oncontextmenu="showPosTypeContextMenu(event, '${pdAttr(type.id)}')">
        ${header}
        ${collapsed ? '' : `<ul class="sidebar-list mt-2 pd-position-tag-list" data-pd-position-type-id="${pdAttr(type.id)}" ondragover="pdPositionTagListDragOver(event, '${pdAttr(type.id)}')" ondragleave="pdPositionTagListDragLeave(event)" ondrop="pdPositionTagListDrop(event, '${pdAttr(type.id)}')">${tags.map(tag => renderPositionTagItem(type.id, tag)).join('') || '<li class="text-dim italic">No positions yet.</li>'}</ul>`}
    </div>`;
}

function renderPositionTagItem(typeId, tag) {
    const color = pdColorForImport(tag.color, '#00f2ff');
    const name = pdStringForImport(tag.name, 'Position');
    if (editingPosTagId === tag.id) {
        return `<li class="pd-left-draggable-item pd-left-editing-item" style="border-left-color:${color}"><div class="flex gap-1 w-full items-center"><input id="edit-postag-${pdAttr(tag.id)}" value="${pdAttr(name)}" onkeydown="pdHandlePosTagEditKey(event, '${pdAttr(typeId)}', '${pdAttr(tag.id)}')"><input id="edit-postag-color-${pdAttr(tag.id)}" type="color" value="${color}" class="w-7 h-7 p-0"><button class="btn btn-green px-2 py-1" onclick="savePosTagEdit('${pdAttr(typeId)}', '${pdAttr(tag.id)}')">✓</button><button class="btn btn-outline px-2 py-1" onclick="cancelPosTagEdit()">✖</button></div></li>`;
    }
    return `<li class="pd-left-draggable-item pd-position-tag-entry" style="border-left-color:${color}" draggable="true" data-pd-position-type-id="${pdAttr(typeId)}" data-pd-position-tag-id="${pdAttr(tag.id)}" ondblclick="pdStartPosTagEditFromDblClick(event, '${pdAttr(tag.id)}')" ondragstart="pdPositionTagDragStart(event, '${pdAttr(typeId)}', '${pdAttr(tag.id)}')" ondragover="pdPositionTagDragOver(event, '${pdAttr(typeId)}', '${pdAttr(tag.id)}')" ondragleave="pdPositionTagDragLeave(event)" ondrop="pdPositionTagDrop(event, '${pdAttr(typeId)}', '${pdAttr(tag.id)}')" ondragend="pdPositionDragEnd(event)"><span class="font-black pd-inline-edit-trigger" style="color:${color}">${escapeHtml(name)}</span><div class="flex gap-2"><button class="text-accent-teal" onclick="event.stopPropagation(); startPosTagEdit('${pdAttr(tag.id)}')">✎</button><button class="text-accent-pink" onclick="event.stopPropagation(); deletePositionTag('${pdAttr(typeId)}', '${pdAttr(tag.id)}')">×</button></div></li>`;
}

function pdStartPosTypeEditFromDblClick(event, id) {
    if (pdShouldIgnoreInlineEditEvent(event)) return;
    event.preventDefault();
    event.stopPropagation();
    startPosTypeEdit(id);
}

function pdStartPosTagEditFromDblClick(event, id) {
    if (pdShouldIgnoreInlineEditEvent(event)) return;
    event.preventDefault();
    event.stopPropagation();
    startPosTagEdit(id);
}

function pdHandlePosTypeEditKey(event, id) {
    if (event.key === 'Enter') {
        event.preventDefault();
        savePosTypeEdit(id);
    } else if (event.key === 'Escape') {
        event.preventDefault();
        cancelPosTypeEdit();
    }
}

function pdHandlePosTagEditKey(event, typeId, tagId) {
    if (event.key === 'Enter') {
        event.preventDefault();
        savePosTagEdit(typeId, tagId);
    } else if (event.key === 'Escape') {
        event.preventDefault();
        cancelPosTagEdit();
    }
}

function pdPositionTypeDragOver(event, targetTypeId) {
    const type = event?.dataTransfer?.getData?.('dragType') || '';
    if (type !== 'type' && type !== 'tag') return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    if (type === 'type') {
        pdClearLeftDropMarkers();
        event.currentTarget?.classList?.add(pdLeftListInsertAfter(event) ? 'pd-drop-after' : 'pd-drop-before');
    } else {
        event.currentTarget?.classList?.add('pd-left-list-drag-over');
    }
}

function pdPositionTypeDragLeave(event) {
    if (!event.currentTarget?.contains?.(event.relatedTarget)) event.currentTarget?.classList?.remove('pd-drop-before', 'pd-drop-after', 'pd-left-list-drag-over');
}

function pdPositionTypeDrop(event, targetTypeId) {
    event.preventDefault();
    event.stopPropagation();
    const dragType = event.dataTransfer.getData('dragType');
    if (dragType === 'type') {
        pdMovePositionType(event.dataTransfer.getData('sourceTypeId'), targetTypeId, pdLeftListInsertAfter(event));
    } else if (dragType === 'tag') {
        pdMovePositionTag(event.dataTransfer.getData('sourceTypeId'), event.dataTransfer.getData('tagId'), targetTypeId, null, true);
    }
}

function pdPositionTagDragStart(event, sourceTypeId, tagId) {
    handlePosTagDragStart(event, sourceTypeId, tagId);
    event.currentTarget?.classList?.add('pd-left-dragging');
}

function pdPositionTagDragOver(event, targetTypeId, targetTagId) {
    if (event.dataTransfer.getData('dragType') !== 'tag') return;
    const sourceTagId = event.dataTransfer.getData('tagId');
    if (!sourceTagId || sourceTagId === targetTagId) return;
    event.preventDefault();
    event.stopPropagation();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    pdClearLeftDropMarkers();
    event.currentTarget?.classList?.add(pdLeftListInsertAfter(event) ? 'pd-drop-after' : 'pd-drop-before');
}

function pdPositionTagDragLeave(event) {
    event.currentTarget?.classList?.remove('pd-drop-before', 'pd-drop-after');
}

function pdPositionTagDrop(event, targetTypeId, targetTagId) {
    if (event.dataTransfer.getData('dragType') !== 'tag') return;
    event.preventDefault();
    event.stopPropagation();
    pdMovePositionTag(event.dataTransfer.getData('sourceTypeId'), event.dataTransfer.getData('tagId'), targetTypeId, targetTagId, pdLeftListInsertAfter(event));
}

function pdPositionTagListDragOver(event, targetTypeId) {
    if (event.dataTransfer.getData('dragType') !== 'tag') return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    event.currentTarget?.classList?.add('pd-left-list-drag-over');
}

function pdPositionTagListDragLeave(event) {
    if (!event.currentTarget?.contains?.(event.relatedTarget)) event.currentTarget?.classList?.remove('pd-left-list-drag-over');
}

function pdPositionTagListDrop(event, targetTypeId) {
    if (event.dataTransfer.getData('dragType') !== 'tag') return;
    event.preventDefault();
    event.stopPropagation();
    if (event.target?.closest?.('.pd-position-tag-entry')) return;
    pdMovePositionTag(event.dataTransfer.getData('sourceTypeId'), event.dataTransfer.getData('tagId'), targetTypeId, null, true);
}

function pdPositionDragEnd(event) {
    pdClearLeftDropMarkers();
}

function pdMovePositionType(sourceTypeId, targetTypeId, insertAfter) {
    if (!sourceTypeId || !targetTypeId || sourceTypeId === targetTypeId) return;
    const list = projectData.positionTypes || [];
    const from = list.findIndex(type => type.id === sourceTypeId);
    if (from < 0) return;
    const [moved] = list.splice(from, 1);
    let to = list.findIndex(type => type.id === targetTypeId);
    if (to < 0) to = list.length;
    if (from < to) to -= 1;
    if (insertAfter) to += 1;
    list.splice(Math.max(0, Math.min(to, list.length)), 0, moved);
    pdClearLeftDropMarkers();
    renderGlobalPositions();
    if (activePromptId) renderEditor();
}

function pdMovePositionTag(sourceTypeId, tagId, targetTypeId, targetTagId, insertAfter) {
    if (!sourceTypeId || !tagId || !targetTypeId) return;
    const sourceType = (projectData.positionTypes || []).find(type => type.id === sourceTypeId);
    const targetType = (projectData.positionTypes || []).find(type => type.id === targetTypeId);
    if (!sourceType || !targetType || !Array.isArray(sourceType.tags) || !Array.isArray(targetType.tags)) return;
    const from = sourceType.tags.findIndex(tag => tag.id === tagId);
    if (from < 0) return;
    const [moved] = sourceType.tags.splice(from, 1);
    if (targetTagId) {
        let to = targetType.tags.findIndex(tag => tag.id === targetTagId);
        if (to < 0) to = targetType.tags.length;
        if (sourceTypeId === targetTypeId && from < to) to -= 1;
        if (insertAfter) to += 1;
        targetType.tags.splice(Math.max(0, Math.min(to, targetType.tags.length)), 0, moved);
    } else {
        targetType.tags.push(moved);
    }
    if (targetType.collapsed) targetType.collapsed = false;
    lastSelectedPosTypeId = targetTypeId;
    pdClearLeftDropMarkers();
    renderGlobalPositions();
    if (activePromptId) renderEditor();
}

function renderLogicPanel() {
    pdEnsureImportRuntimeShape();
    pdEnsureVisualPatchCSS();
    const container = document.getElementById('logic-list-container');
    if (!container) return;
    const search = String(document.getElementById('logic-search')?.value || '').trim().toLowerCase();
    const rows = pdGetActiveProjectLogicRows();
    const filtered = rows.filter(item => {
        const haystack = `${item.key} ${item.op} ${item.val}`.toLowerCase();
        return !search || haystack.includes(search);
    });

    container.innerHTML = filtered.map(item => {
        const color = pdLogicRowColor(item);
        const count = Array.isArray(item.uses) ? item.uses.length : 0;
        return `<button type="button" class="pd-logic-pill" onclick="openLogicModal(${pdJsonArg(item.key)}, ${pdJsonArg(item.op)}, ${pdJsonArg(item.val)})" title="${pdAttr(count)} reference${count === 1 ? '' : 's'}">
            <span class="pd-logic-accent" style="background:${color}; color:${color}"></span>
            <span class="pd-logic-main"><span>${escapeHtml(item.key)}</span> <span class="pd-logic-op">${escapeHtml(item.op)}</span> <span>${escapeHtml(item.val)}</span></span>
            <span class="pd-logic-count">[${count}]</span>
        </button>`;
    }).join('') || `<div class="pd-logic-empty">No active project logic found.</div>`;
}

function renderLogicDependencies() {
    const container = document.getElementById('logic-dependencies-list');
    if (!container || !currentLogicEdit) return;
    const logic = pdGetActiveProjectLogicRows().find(item => item.key === currentLogicEdit.key && item.op === currentLogicEdit.op && item.val === currentLogicEdit.val);
    container.innerHTML = (logic?.uses || []).map(use => `<div class="bg-black/40 border border-white/10 p-3 flex justify-between gap-3 items-center">
        <div><div class="font-black text-white">${escapeHtml(use.text || 'Untitled')}</div><div class="text-[10px] text-dim uppercase">${escapeHtml(use.type || '')}</div></div>
        <div class="flex gap-2"><button class="btn btn-outline text-[9px]" onclick="jumpToLogicDependency('${pdAttr(use.promptId)}')">Go To</button><button class="btn btn-outline text-[9px] text-accent-pink" onclick="deleteLogicDependency('${pdAttr(use.promptId)}', '${pdAttr(use.type)}', ${use.btnIdx === undefined ? 'null' : use.btnIdx})">Remove</button></div>
    </div>`).join('') || `<div class="pd-empty-note">No dependencies found.</div>`;
}

function updateDynamicGlows() {
    updateCardGlowOnly();
}

function updateCardGlowOnly() {
    const logic = typeof getProjectLogic === 'function' ? getProjectLogic() : [];
    document.querySelectorAll('.pd-glow-red,.pd-glow-blue,.pd-glow-purple').forEach(el => el.classList.remove('pd-glow-red', 'pd-glow-blue', 'pd-glow-purple'));
    (projectData.prompts || []).forEach(prompt => {
        const glow = typeof getPromptGlowState === 'function' ? getPromptGlowState(prompt.id, logic) : 'none';
        const cls = glow === 'red' ? 'pd-glow-red' : glow === 'blue' ? 'pd-glow-blue' : glow === 'purple' ? 'pd-glow-purple' : '';
        if (!cls) return;
        document.getElementById(`pd-prompt-lib-${prompt.id}`)?.classList.add(cls);
        if (prompt.id === activePromptId) document.getElementById('active-prompt-card')?.classList.add(cls);
    });
}

window.renderLists = renderLists;
window.renderPromptLibrary = renderPromptLibrary;
window.pdRenderPromptLibraryEntry = pdRenderPromptLibraryEntry;
window.pdTogglePromptLibrarySection = pdTogglePromptLibrarySection;
window.pdPromptLibraryDragStart = pdPromptLibraryDragStart;
window.pdPromptLibraryDragEnd = pdPromptLibraryDragEnd;
window.pdPromptLibraryEntryDragOver = pdPromptLibraryEntryDragOver;
window.pdPromptLibraryEntryDragLeave = pdPromptLibraryEntryDragLeave;
window.pdPromptLibraryEntryDrop = pdPromptLibraryEntryDrop;
window.pdPromptLibrarySectionBodyDragOver = pdPromptLibrarySectionBodyDragOver;
window.pdPromptLibrarySectionBodyDragLeave = pdPromptLibrarySectionBodyDragLeave;
window.pdPromptLibraryDragOver = pdPromptLibraryDragOver;
window.pdPromptLibraryDragLeave = pdPromptLibraryDragLeave;
window.pdPromptLibraryDrop = pdPromptLibraryDrop;
window.pdInstallPromptLibraryInteractions = pdInstallPromptLibraryInteractions;
window.pdLoadPromptFromSidebar = pdLoadPromptFromSidebar;
window.pdFocusActivePromptInCenter = pdFocusActivePromptInCenter;
window.pdMovePromptToTag = pdMovePromptToTag;
window.pdMovePromptToTagAndIndex = pdMovePromptToTagAndIndex;
window.handlePromptDragStart = handlePromptDragStart;
window.handlePromptDrop = handlePromptDrop;
window.selectCategory = selectCategory;
window.selectPrompt = selectPrompt;
window.updatePromptTag = updatePromptTag;
window.pdMovePromptOrderFromTab = pdMovePromptOrderFromTab;
window.renderEditor = renderEditor;
window.renderGlobalSections = renderGlobalSections;
window.renderGlobalPositions = renderGlobalPositions;
window.renderLogicPanel = renderLogicPanel;
window.renderArray = renderArray;
window.pdTogglePromptLogicSection = pdTogglePromptLogicSection;
window.pdAddPromptLogicItem = pdAddPromptLogicItem;
window.pdRemovePromptLogicItem = pdRemovePromptLogicItem;
window.pdSyncPromptLogicSectionVisibility = pdSyncPromptLogicSectionVisibility;
window.renderTriggers = renderTriggers;
window.renderVisualPayloads = renderVisualPayloads;
window.renderFramesAndPositions = renderFramesAndPositions;
window.renderActionButtons = renderActionButtons;
window.renderLogicDependencies = renderLogicDependencies;
window.pdCleanPromptSampleText = pdCleanPromptSampleText;
window.updatePreview = updatePreview;
window.updateDynamicGlows = updateDynamicGlows;
window.updateCardGlowOnly = updateCardGlowOnly;
window.toggleTriggersUI = toggleTriggersUI;
window.toggleVisualPayloadUI = toggleVisualPayloadUI;
window.toggleButtonUI = toggleButtonUI;
window.addButtonCondition = addButtonCondition;
window.removeButtonCondition = removeButtonCondition;
window.updateButtonCondition = updateButtonCondition;
window.buttonToggleCollapsed = buttonToggleCollapsed;
window.pdSetButtonTextForRender = pdSetButtonTextForRender;
window.pdClearLeftDropMarkers = pdClearLeftDropMarkers;
window.pdStartTokenEditFromDblClick = pdStartTokenEditFromDblClick;
window.pdStartTagEditFromDblClick = pdStartTagEditFromDblClick;
window.pdHandleTokenEditKey = pdHandleTokenEditKey;
window.pdHandleTagEditKey = pdHandleTagEditKey;
window.pdLeftListDragStart = pdLeftListDragStart;
window.pdLeftListDragOver = pdLeftListDragOver;
window.pdLeftListDragLeave = pdLeftListDragLeave;
window.pdLeftListDrop = pdLeftListDrop;
window.pdLeftListDragEnd = pdLeftListDragEnd;
window.pdStartGlobalItemEditFromDblClick = pdStartGlobalItemEditFromDblClick;
window.pdHandleGlobalEditKey = pdHandleGlobalEditKey;
window.pdGlobalItemDragStart = pdGlobalItemDragStart;
window.pdGlobalItemDragOver = pdGlobalItemDragOver;
window.pdGlobalItemDragLeave = pdGlobalItemDragLeave;
window.pdGlobalItemDrop = pdGlobalItemDrop;
window.pdGlobalItemDragEnd = pdGlobalItemDragEnd;
window.pdGlobalSectionDragOver = pdGlobalSectionDragOver;
window.pdGlobalSectionDragLeave = pdGlobalSectionDragLeave;
window.pdGlobalSectionDrop = pdGlobalSectionDrop;
window.pdStartPosTypeEditFromDblClick = pdStartPosTypeEditFromDblClick;
window.pdStartPosTagEditFromDblClick = pdStartPosTagEditFromDblClick;
window.pdHandlePosTypeEditKey = pdHandlePosTypeEditKey;
window.pdHandlePosTagEditKey = pdHandlePosTagEditKey;
window.pdPositionTypeDragOver = pdPositionTypeDragOver;
window.pdPositionTypeDragLeave = pdPositionTypeDragLeave;
window.pdPositionTypeDrop = pdPositionTypeDrop;
window.pdPositionTagDragStart = pdPositionTagDragStart;
window.pdPositionTagDragOver = pdPositionTagDragOver;
window.pdPositionTagDragLeave = pdPositionTagDragLeave;
window.pdPositionTagDrop = pdPositionTagDrop;
window.pdPositionTagListDragOver = pdPositionTagListDragOver;
window.pdPositionTagListDragLeave = pdPositionTagListDragLeave;
window.pdPositionTagListDrop = pdPositionTagListDrop;
window.pdPositionDragEnd = pdPositionDragEnd;
window.pdMovePositionType = pdMovePositionType;
window.pdMovePositionTag = pdMovePositionTag;

function importProject(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const parsed = JSON.parse(e.target.result);
            const data = pdNormalizePromptDesignerImport(parsed);

            // Preserve and merge left-sidebar globals instead of clearing missing imported sections.
            pdApplyAdditiveSidebarImport(data, projectData);
            GLOBAL_SECTIONS.forEach(sec => { if (!Array.isArray(data[sec.key])) data[sec.key] = []; });
            if (!Array.isArray(data.positionTypes)) data.positionTypes = [];
            if (!Array.isArray(data.tags)) data.tags = [];
            if (!Array.isArray(data.tokens)) data.tokens = [];
            if (!Array.isArray(data.prompts)) data.prompts = [];

            projectData = data;
            if (typeof window.pdEnsureProject === 'function') window.pdEnsureProject();
            if (projectData.tags.length === 0) projectData.tags.push({ name: 'News Alert', color: '#00f2ff' });
            const keptPrompt = projectData.prompts.find(p => p.id === activePromptId) || null;
            const selectedPrompt = keptPrompt || projectData.prompts[0] || null;
            activePromptId = selectedPrompt ? selectedPrompt.id : null;
            if (selectedPrompt && projectData.tags.some(t => t.name === selectedPrompt.tag)) {
                activeTag = selectedPrompt.tag;
            } else if (!projectData.tags.some(t => t.name === activeTag)) {
                activeTag = projectData.tags[0].name;
            }

            pdRenderAfterImport();
            showNotification(`Project Imported: healed ${projectData.prompts.length} prompt${projectData.prompts.length === 1 ? '' : 's'}`);
            console.info('[PromptDesigner Import] normalized project loaded', {
                version: parsed && parsed.version,
                prompts: projectData.prompts.length,
                tags: projectData.tags.length,
                tokens: projectData.tokens.length,
                languages: projectData.availableLanguages
            });
        } catch (err) {
            console.error('Import failed', err);
            showNotification(`Import Failed: ${err.message || 'Invalid JSON'}`);
        }
    };
    reader.readAsText(file);
    input.value = '';
}
