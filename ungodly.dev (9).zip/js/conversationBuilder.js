document.addEventListener('DOMContentLoaded', () => {
    // --- STATE MANAGEMENT ---
    let state = {
        conversations: [],
        quests: [],
        conversationCategories: [],
        questCategories: [],
        activeItem: { id: null, type: null },
        nodes: {},
        choices: {},
        labels: {},
        gameVariables: {},
        worlds: [],
        characters: [],
        languages: [],
        activeLanguage: 'en',
        selectedElement: null,
        multiSelectedNodes: new Set(),
        isDragging: false,
        draggedElementId: null,
        dragOffset: { x: 0, y: 0 },
        isConnecting: false,
        connectionStartChoiceId: null,
        connectionStartNodeId: null,
        connectionLine: null,
        isPanning: false,
        panOffset: { x: 0, y: 0 },
        zoom: 1,
        panStart: { x: 0, y: 0 },
        isMarqueeSelecting: false,
        marqueeStart: { x: 0, y: 0 },
        isResizingLabel: false,
    };

    // --- DOM ELEMENTS ---
    const mainContainer = document.querySelector('.main-container');
    const conversationsContainer = document.getElementById('conversations-container');
    const questsContainer = document.getElementById('quests-container');
    const canvas = document.getElementById('editor-canvas');
    const canvasTransformer = document.getElementById('canvas-transformer');
    const nodeLayer = document.getElementById('node-layer');
    const labelLayer = document.getElementById('label-layer');
    const connectorLayer = document.getElementById('connector-layer');
    const marqueeBox = document.getElementById('marquee-box');
    const inspectorPanel = document.getElementById('inspector-panel');
    const inspectorContent = document.getElementById('inspector-content');
    const exportActionsPanel = document.getElementById('export-actions-panel');
    const exportToCsvBtn = document.getElementById('exportToCsvBtn');
    const exportToJsonBtn = document.getElementById('exportToJsonBtn');
    const statusMessage = document.getElementById('status-message');
    const mainNav = document.querySelector('.main-nav');
    const nodesTab = document.getElementById('nodes-tab');
    const languageSelectorWrapper = document.getElementById('language-selector-wrapper');
    const languageSelector = document.getElementById('language-selector');
    const modalBackdrop = document.getElementById('modal-backdrop');
    const testerModal = document.getElementById('tester-modal');
    const referenceModal = document.getElementById('reference-modal');
    const saveConfigBtn = document.getElementById('saveConfigBtn');
    const pushChangesBtn = document.getElementById('pushChangesBtn');
    const previewBtn = document.getElementById('previewBtn');
    const addNodeBtn = document.getElementById('addNodeBtn');
    const addEmptyNodeBtn = document.getElementById('addEmptyNodeBtn');
    const addLabelBtn = document.getElementById('addLabelBtn');
    const addLanguageBtn = document.getElementById('add-language-btn');
    const closeTesterBtn = document.getElementById('close-tester-btn');
    const closeReferenceBtn = document.getElementById('close-reference-btn');
    const addWorldBtn = document.getElementById('add-world-btn');
    const addCharacterBtn = document.getElementById('add-character-btn');

    // --- API FUNCTIONS ---
    const API_URL = 'api6.php';

    async function apiCall(action, data = {}) {
        try {
            const formData = new FormData();
            formData.append('action', action);
            for (const key in data) {
                if (data[key] === null) continue;
                if (typeof data[key] === 'object' && data[key] !== null) {
                    formData.append(key, JSON.stringify(data[key]));
                } else {
                    formData.append(key, data[key]);
                }
            }
            const response = await fetch(API_URL, { method: 'POST', body: formData });
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

            const resultText = await response.text();
            try {
                const result = JSON.parse(resultText);
                 if (!result.success) {
                     console.error('API Error:', result);
                     let errorMessage = result.message || 'Unknown API error';
                     if (result.error_details) {
                         errorMessage += `\nFile: ${result.error_details.file}\nLine: ${result.error_details.line}\nMessage: ${result.error_details.message}`;
                     }
                     throw new Error(errorMessage);
                 }
                return result;
            } catch (jsonError) {
                console.error("Failed to parse JSON response:", resultText);
                throw new Error("Received non-JSON response from server.");
            }

        } catch (error) {
            console.error('API Call Error:', error);
            updateStatus(`Error: ${error.message}`, true);
            return { success: false, message: error.message };
        }
    }

    // --- HIERARCHY & DRAG-DROP RENDER FUNCTIONS ---

    async function renderConversationsView() {
        const convResult = await apiCall('get_conversations');
        if (!convResult.success) return;
        state.conversations = convResult.data;

        const structure = [
            { name: 'Consciences', children: [
                { name: 'Good', children: state.worlds.map(w => ({ name: w.name })) },
                { name: 'Evil', children: state.worlds.map(w => ({ name: w.name })) },
                { name: 'Nature', children: state.worlds.map(w => ({ name: w.name })) },
                { name: 'War', children: state.worlds.map(w => ({ name: w.name })) },
                { name: 'Arcane', children: state.worlds.map(w => ({ name: w.name })) },
                { name: 'Economy', children: state.worlds.map(w => ({ name: w.name })) },
            ]},
            { name: 'Gods', children: state.characters.map(c => ({
                name: c.name, children: state.worlds.map(w => ({ name: w.name }))
            }))},
            { name: 'Villagers', children: state.worlds.map(w => ({ name: w.name })) },
        ];

        const dbCategoriesResult = await apiCall('get_categories', { type: 'conversation' });
        if (!dbCategoriesResult.success) return;
        state.conversationCategories = dbCategoriesResult.data;

        let hierarchyHtml = buildHierarchyHtml(structure, null, state.conversationCategories, 'conversation');
        const uncategorizedConversations = state.conversations.filter(c => !c.category_id);

        conversationsContainer.innerHTML = `
            <h2>Manage Conversations</h2>
            <div class="add-entity-form">
                <input type="text" id="new-conversation-title" placeholder="Enter new conversation title...">
                <button id="add-conversation-btn" class="action-btn"><i class="fa-solid fa-plus"></i> Add Conversation</button>
            </div>
            <h3>Uncategorized</h3>
            <div id="uncategorized-list" class="entity-list drop-zone" data-category-id="null">
                ${uncategorizedConversations.map(c => createConversationItemHtml(c)).join('')}
            </div>
            ${hierarchyHtml}
            <div class="search-container">
                <h3>Search by Conversation</h3>
                <div class="search-form">
                    <input type="text" id="conversation-search-input" placeholder="Enter Conversation title...">
                    <button id="conversation-search-btn" class="action-btn"><i class="fa-solid fa-search"></i> Search</button>
                </div>
                <div id="conversation-search-results" class="entity-list"></div>
            </div>
        `;

        initializeSortable('#conversations-container .drop-zone', 'conversation');
        conversationsContainer.removeEventListener('click', onContainerClick);
        conversationsContainer.addEventListener('click', onContainerClick);
    }

    async function renderQuestsView() {
        const questResult = await apiCall('get_quests');
        if (!questResult.success) return;
        state.quests = questResult.data;

        const structure = [
            { name: 'Main Quests', children: state.worlds.map(w => ({ name: w.name })) },
            { name: 'Side Quests', children: state.worlds.map(w => ({ name: w.name })) },
            { name: 'Character Quests', children: state.characters.map(c => ({
                name: c.name, children: state.worlds.map(w => ({ name: w.name }))
            }))},
        ];

        const dbCategoriesResult = await apiCall('get_categories', { type: 'quest' });
        if (!dbCategoriesResult.success) return;
        state.questCategories = dbCategoriesResult.data;

        let hierarchyHtml = buildHierarchyHtml(structure, null, state.questCategories, 'quest');
        const uncategorizedQuests = state.quests.filter(q => !q.category_id);

        questsContainer.innerHTML = `
            <h2>Manage Quests</h2>
            <div class="add-entity-form">
                <input type="text" id="new-quest-title" placeholder="Enter new quest title...">
                <button id="add-quest-btn" class="action-btn"><i class="fa-solid fa-plus"></i> Add Quest</button>
            </div>
            <h3>Uncategorized</h3>
            <div id="uncategorized-quests-list" class="entity-list drop-zone" data-category-id="null">
                ${uncategorizedQuests.map(q => createQuestItemHtml(q)).join('')}
            </div>
            ${hierarchyHtml}
            <div class="search-container">
                <h3>Search by Quest</h3>
                <div class="search-form">
                    <input type="text" id="quest-search-input" placeholder="Enter Quest name...">
                    <button id="quest-search-btn" class="action-btn"><i class="fa-solid fa-search"></i> Search</button>
                </div>
                <div id="quest-search-results" class="entity-list"></div>
            </div>
        `;

        initializeSortable('#quests-container .drop-zone', 'quest');
        questsContainer.removeEventListener('click', onContainerClick);
        questsContainer.addEventListener('click', onContainerClick);
    }

    function buildHierarchyHtml(structure, parentId, dbCategories, itemType) {
        let html = '';
        const items = itemType === 'conversation' ? state.conversations : state.quests;
        const itemHtmlGenerator = itemType === 'conversation' ? createConversationItemHtml : createQuestItemHtml;

        structure.forEach((item, index) => {
            const dbCategory = dbCategories.find(c => c.name === item.name && c.parent_id == parentId);
            const categoryId = dbCategory ? dbCategory.id : `client_${item.name.replace(/\s+/g, '_')}_${parentId || 'root'}`;
            const isCollapsed = true;

            html += `<div class="category-group" data-category-id="${categoryId}" data-category-name="${item.name}" data-parent-id="${parentId || ''}" data-sort-order="${index}">
                <div class="category-header ${isCollapsed ? 'collapsed' : ''}">
                    <i class="fas fa-chevron-down toggle-icon"></i>
                    <span>${item.name}</span>
                </div>
                <div class="category-content ${isCollapsed ? 'collapsed' : ''}">`;

            if (item.children && item.children.length > 0) {
                html += buildHierarchyHtml(item.children, categoryId, dbCategories, itemType);
            } else {
                const itemsInThisCategory = items.filter(i => i.category_id == categoryId);
                html += `<div class="entity-list drop-zone" data-category-id="${categoryId}">
                            ${itemsInThisCategory.map(i => itemHtmlGenerator(i)).join('')}
                         </div>`;
            }

            html += `</div></div>`;
        });
        return html;
    }

    function createConversationItemHtml(c) {
        return `<div class="entity-item" data-id="${c.id}" data-type="conversation" style="border-left-color: ${c.color || '#1e88e5'};">
            <span class="entity-name">${c.title}</span>
            <div class="entity-actions">
                <span class="entity-id">ID: ${c.id}</span>
                <div class="color-picker-wrapper">
                    <button class="color-picker-btn" title="Change Color"><i class="fa-solid fa-palette"></i></button>
                    <input type="color" class="color-input" value="${c.color || '#1e88e5'}" data-id="${c.id}" data-type="conversation">
                </div>
                <button class="delete-entity-btn" title="Delete Conversation" data-id="${c.id}" data-type="conversation">&times;</button>
            </div>
        </div>`;
    }

    function createQuestItemHtml(q) {
        return `<div class="entity-item" data-id="${q.id}" data-type="quest" style="border-left-color: ${q.color || '#1e88e5'};">
            <span class="entity-name">${q.title}</span>
            <div class="entity-actions">
                <span class="entity-id">ID: ${q.id}</span>
                <div class="color-picker-wrapper">
                    <button class="color-picker-btn" title="Change Color"><i class="fa-solid fa-palette"></i></button>
                    <input type="color" class="color-input" value="${q.color || '#1e88e5'}" data-id="${q.id}" data-type="quest">
                </div>
                <button class="delete-entity-btn" title="Delete Quest" data-id="${q.id}" data-type="quest">&times;</button>
            </div>
        </div>`;
    }
    
    function createSearchResultItemHtml(item, itemType) {
        return `<div class="entity-item" data-id="${item.id}" data-type="${itemType}" style="border-left-color: ${item.color || '#1e88e5'};">
            <span class="entity-name">${item.title}</span>
            <div class="entity-actions">
                <span class="entity-id">ID: ${item.id}</span>
                <button class="decouple-btn" title="Move to Uncategorized"><i class="fa-solid fa-unlink"></i></button>
            </div>
        </div>`;
    }

    function initializeSortable(selector, itemType) {
        const lists = document.querySelectorAll(selector);
        lists.forEach(list => {
            if (list.sortableInstance) {
                list.sortableInstance.destroy();
            }
            list.sortableInstance = new Sortable(list, {
                group: `shared-${itemType}`,
                animation: 150,
                ghostClass: 'sortable-ghost',
                chosenClass: 'sortable-chosen',
                onEnd: async function (evt) {
                    updateStatus('Saving new order...');
                    await ensureCategoriesExist(itemType);

                    const fromList = evt.from;
                    const toList = evt.to;
                    const itemsToUpdate = [];

                    const fromItems = Array.from(fromList.children);
                    fromItems.forEach((item, index) => {
                        itemsToUpdate.push({
                            id: item.dataset.id,
                            category_id: fromList.dataset.categoryId,
                            sort_order: index
                        });
                    });

                    if (fromList !== toList) {
                        const toItems = Array.from(toList.children);
                        toItems.forEach((item, index) => {
                             const existing = itemsToUpdate.find(i => i.id === item.dataset.id);
                             if (existing) {
                                existing.category_id = toList.dataset.categoryId;
                                existing.sort_order = index;
                             } else {
                                itemsToUpdate.push({
                                    id: item.dataset.id,
                                    category_id: toList.dataset.categoryId,
                                    sort_order: index
                                });
                             }
                        });
                    }

                    const result = await apiCall('update_item_order', { item_type: itemType, items: itemsToUpdate });

                    if (result.success) {
                        updateStatus('Order saved successfully.');
                        if (itemType === 'conversation') await renderConversationsView();
                        else await renderQuestsView();
                    } else {
                        updateStatus('Failed to save order.', true);
                    }
                },
            });
        });
    }

    async function ensureCategoriesExist(itemType) {
        const container = itemType === 'conversation' ? conversationsContainer : questsContainer;
        const categoryElements = container.querySelectorAll('.category-group');
        const newCategories = [];

        categoryElements.forEach(el => {
            const id = el.dataset.categoryId;
            if (String(id).startsWith('client_')) {
                newCategories.push({
                    id: id,
                    name: el.dataset.categoryName,
                    parent_id: el.dataset.parentId || null,
                    sort_order: el.dataset.sortOrder,
                });
            }
        });

        if (newCategories.length === 0) return;

        const result = await apiCall('ensure_categories', { type: itemType, categories: newCategories });

        if (result.success && result.id_map) {
            for (const [clientId, dbId] of Object.entries(result.id_map)) {
                const elementsToUpdate = container.querySelectorAll(`[data-category-id="${clientId}"]`);
                elementsToUpdate.forEach(el => el.dataset.categoryId = dbId);
                const childElements = container.querySelectorAll(`[data-parent-id="${clientId}"]`);
                childElements.forEach(el => el.dataset.parentId = dbId);
            }
            const categoriesResult = await apiCall('get_categories', { type: itemType });
            if(categoriesResult.success) {
                if(itemType === 'conversation') state.conversationCategories = categoriesResult.data;
                else state.questCategories = categoriesResult.data;
            }
        }
    }
    
    async function onContainerClick(e) {
        const container = e.currentTarget;
        const itemType = container.id === 'conversations-container' ? 'conversation' : 'quest';

        const header = e.target.closest('.category-header');
        if (header) {
            header.classList.toggle('collapsed');
            header.nextElementSibling?.classList.toggle('collapsed');
            return;
        }

        const addBtnId = itemType === 'conversation' ? 'add-conversation-btn' : 'add-quest-btn';
        if (e.target.id === addBtnId) {
            const titleInputId = itemType === 'conversation' ? 'new-conversation-title' : 'new-quest-title';
            const titleInput = document.getElementById(titleInputId);
            const title = titleInput.value.trim();
            if (title) {
                const action = itemType === 'conversation' ? 'create_conversation' : 'add_quest';
                const result = await apiCall(action, { title, category_id: null });
                if (result.success) {
                    titleInput.value = '';
                    if (itemType === 'conversation') await renderConversationsView();
                    else await renderQuestsView();
                }
            }
        }

        const searchBtnId = `${itemType}-search-btn`;
        if (e.target.id === searchBtnId) {
            const searchInputId = `${itemType}-search-input`;
            const searchInput = document.getElementById(searchInputId);
            const searchTerm = searchInput.value.trim();
            const resultsContainerId = `${itemType}-search-results`;
            const resultsContainer = document.getElementById(resultsContainerId);
            
            if (searchTerm) {
                const result = await apiCall('search_items', { item_type: itemType, search_term: searchTerm });
                if (result.success) {
                    resultsContainer.innerHTML = result.data.map(item => createSearchResultItemHtml(item, itemType)).join('');
                }
            } else {
                resultsContainer.innerHTML = '';
            }
        }
        
        const decoupleBtn = e.target.closest('.decouple-btn');
        if (decoupleBtn) {
            const itemEl = decoupleBtn.closest('.entity-item');
            const itemId = itemEl.dataset.id;
            
            updateStatus('Decoupling item...');
            const result = await apiCall('update_item_order', {
                item_type: itemType,
                items: [{ id: itemId, category_id: null, sort_order: 9999 }]
            });

            if (result.success) {
                updateStatus('Item moved to Uncategorized.');
                itemEl.remove(); // Remove from search results
                if (itemType === 'conversation') await renderConversationsView();
                else await renderQuestsView();
            } else {
                updateStatus('Failed to decouple item.', true);
            }
        }
    }


    function switchView(viewName) {
        document.querySelectorAll('.view-panel').forEach(p => p.classList.remove('active'));
        document.getElementById(`view-${viewName}`).classList.add('active');

        document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
        document.querySelector(`.nav-tab[data-view="${viewName}"]`).classList.add('active');

        document.querySelectorAll('.actions-group').forEach(ag => ag.classList.remove('active'));
        const actionsGroup = document.getElementById(`actions-${viewName}`);
        if (actionsGroup) actionsGroup.classList.add('active');

        languageSelectorWrapper.classList.toggle('hidden', viewName !== 'nodes');

        if (viewName === 'conversations') renderConversationsView();
        if (viewName === 'quests') renderQuestsView();
        if (viewName === 'worlds') loadWorlds();
        if (viewName === 'characters') loadCharacters();
        if (viewName === 'languages') loadLanguages();
    }

    function renderAll() {
        renderAllNodes();
        renderAllLabels();
        renderConnectors();
    }

    function renderNode(nodeId) {
        const node = state.nodes[nodeId];
        if (!node) return;
        const existingEl = document.getElementById(`node-${nodeId}`);
        const newEl = createNodeElement(node);
        if (existingEl) {
            existingEl.replaceWith(newEl);
        } else {
            nodeLayer.appendChild(newEl);
        }
        renderConnectors();
    }

    function renderAllNodes() {
        nodeLayer.innerHTML = '';
        Object.values(state.nodes).forEach(node => {
            const nodeEl = createNodeElement(node);
            nodeLayer.appendChild(nodeEl);
        });
    }

    function renderAllLabels() {
        labelLayer.innerHTML = '';
        Object.values(state.labels).forEach(label => {
            const labelEl = createLabelElement(label);
            labelLayer.appendChild(labelEl);
        });
    }

    function getTextForLanguage(textObject, langCode) {
        if (!textObject) return '';
        if (typeof textObject === 'string') return textObject;
        return textObject[langCode] || textObject[state.activeLanguage] || textObject['en'] || Object.values(textObject)[0] || '';
    }

    function createNodeElement(node) {
        const nodeEl = document.createElement('div');
        nodeEl.className = 'node';
        nodeEl.classList.add(`node-type-${node.node_type}`);
        nodeEl.id = `node-${node.id}`;
        nodeEl.style.left = `${node.x || 20}px`;
        nodeEl.style.top = `${node.y || 20}px`;
        nodeEl.dataset.nodeId = node.id;

        if (state.multiSelectedNodes.has(node.id)) {
            nodeEl.classList.add('multi-selected');
        }
        if (state.selectedElement && state.selectedElement.type === 'node' && state.selectedElement.id === node.id) {
            nodeEl.classList.add('selected');
        }

        const startNodeId = state.activeItem.type === 'conversation'
            ? state.conversations.find(c => c.id == state.activeItem.id)?.start_node_id
            : state.quests.find(q => q.id == state.activeItem.id)?.start_node_id;

        if (startNodeId === node.id) {
            nodeEl.classList.add('is-start');
        }

        let innerHtml = `<div class="node-input-connector" data-node-id="${node.id}"></div>`;
        const displayLanguage = node.displayLanguage || state.activeLanguage;

        if (node.node_type === 'dialog') {
            const worldOptions = state.worlds.map(w => `<option value="${w.id}" ${node.world_id == w.id ? 'selected' : ''}>${w.name}</option>`).join('');
            const characterOptions = state.characters.map(c => `<option value="${c.id}" ${node.character_id == c.id ? 'selected' : ''}>${c.name}</option>`).join('');
            const prefix = state.activeItem.type === 'conversation' ? 'C' : 'Q';
            const refIdParts = [
                `${prefix}:${state.activeItem.id || '?'}`,
                node.world_id || '?',
                node.character_id || '?',
                node.node_sequence_id || '?'
            ];
            const refId = refIdParts.join('.');
            const title = prefix === 'C' ? "C:Conversation.World.Character.Node" : "Q:Quest.World.Character.Node";
            let choicesHtml = '<ul class="node-choices">';
            const nodeChoices = Object.values(state.choices).filter(c => c.node_id === node.id);
            nodeChoices.forEach(choice => {
                let choiceClasses = 'node-choice';
                if (state.selectedElement && state.selectedElement.type === 'choice' && state.selectedElement.id === choice.id) {
                    choiceClasses += ' selected';
                }
                choicesHtml += `<li class="${choiceClasses}" data-choice-id="${choice.id}">
                    ${getTextForLanguage(choice.choice_text, displayLanguage) || 'Empty Choice'}
                    <div class="choice-connector" data-choice-id="${choice.id}"></div>
                </li>`;
            });
            choicesHtml += '</ul>';
            const languageOptions = state.languages.map(lang => `<option value="${lang.code}" ${displayLanguage === lang.code ? 'selected' : ''}>${lang.code.toUpperCase()}</option>`).join('');
            innerHtml += `
                <div class="node-output-connector" data-node-id="${node.id}"></div>
                <div class="node-header">
                    <span class="node-speaker">${node.speaker || 'NO SPEAKER'}</span>
                    <select class="node-language-selector" data-node-id="${node.id}">${languageOptions}</select>
                    <span class="node-ref-id" title="${title}">${refId}</span>
                </div>
                <div class="node-selects">
                    <select class="node-world-select" data-node-id="${node.id}"><option value="">-- World --</option>${worldOptions}</select>
                    <select class="node-character-select" data-node-id="${node.id}"><option value="">-- Character --</option>${characterOptions}</select>
                </div>
                <div class="node-content">${getTextForLanguage(node.dialog_text, displayLanguage) || '...'}</div>
                ${choicesHtml}
            `;
        } else if (node.node_type === 'empty') {
            innerHtml += `<div class="node-output-connector" data-node-id="${node.id}"></div>`;
        } else if (node.node_type === 'json' || node.node_type === 'sheet') {
            nodeEl.classList.add('node-export');
            const isJson = node.node_type === 'json';
            const icon = isJson ? 'fa-file-code' : 'fa-file-csv';
            const text = isJson ? 'to JSON' : 'to CSV';
            innerHtml += `
                <div class="node-header">
                    <span class="node-reference-type"><i class="fa-solid ${icon}"></i> ${text}</span>
                </div>
            `;
        } else {
            nodeEl.classList.add('node-reference');
            let iconClass = 'fa-solid';
            let refType = 'Reference';
            let refColor = '#1e88e5';
            let refName = node.speaker || '...';
            let refItem;
            switch (node.node_type) {
                case 'conversationRef': {
                    iconClass += ' fa-comments';
                    refType = 'Conversation';
                    refItem = state.conversations.find(c => c.id == node.reference_id);
                    break;
                }
                case 'questRef': {
                    iconClass += ' fa-scroll';
                    refType = 'Quest';
                    refItem = state.quests.find(q => q.id == node.reference_id);
                    break;
                }
                case 'characterRef': {
                    iconClass += ' fa-user';
                    refType = 'Character';
                    refItem = state.characters.find(c => c.id == node.reference_id);
                    break;
                }
                case 'worldRef': {
                    iconClass += ' fa-globe';
                    refType = 'World';
                    refItem = state.worlds.find(w => w.id == node.reference_id);
                    break;
                }
            }
            if (refItem) {
                refColor = refItem.color || refColor;
                const currentName = refItem.title || refItem.name;
                if (currentName && currentName !== refName) {
                    refName = currentName;
                    node.speaker = currentName;
                }
            } else {
                if (node.reference_id) {
                    refName = '... (Missing Ref)';
                }
            }
            nodeEl.style.borderColor = refColor;
            let selectsHtml = '';
            if (node.node_type !== 'worldRef') {
                const worldOptions = state.worlds.map(w => `<option value="${w.id}" ${node.world_id == w.id ? 'selected' : ''}>${w.name}</option>`).join('');
                selectsHtml += `<select class="node-world-select" data-node-id="${node.id}"><option value="">-- World --</option>${worldOptions}</select>`;
            }
            if (node.node_type !== 'characterRef') {
                const characterOptions = state.characters.map(c => `<option value="${c.id}" ${node.character_id == c.id ? 'selected' : ''}>${c.name}</option>`).join('');
                selectsHtml += `<select class="node-character-select" data-node-id="${node.id}"><option value="">-- Character --</option>${characterOptions}</select>`;
            }
            if (selectsHtml) {
                selectsHtml = `<div class="node-selects">${selectsHtml}</div>`;
            }
            innerHtml += `
                <div class="node-output-connector" data-node-id="${node.id}"></div>
                <div class="node-header">
                    <span class="node-reference-type"><i class="${iconClass}"></i> ${refType}</span>
                </div>
                ${selectsHtml}
                <div class="node-content">${refName}</div>
            `;
        }
        nodeEl.innerHTML = innerHtml;
        return nodeEl;
    }

    function createLabelElement(label) {
        const labelEl = document.createElement('div');
        labelEl.className = 'label-box';
        labelEl.id = `label-${label.id}`;
        labelEl.style.left = `${label.x}px`;
        labelEl.style.top = `${label.y}px`;
        labelEl.style.width = `${label.width}px`;
        labelEl.style.height = `${label.height}px`;
        labelEl.style.setProperty('--label-border-color', label.color || '#e53935');
        labelEl.style.setProperty('--label-bg-color', `${label.color || '#e53935'}20`);
        labelEl.style.setProperty('--label-bg-color-selected', `${label.color || '#e53935'}40`);

        if (state.selectedElement && state.selectedElement.type === 'label' && state.selectedElement.id === label.id) {
            labelEl.classList.add('selected');
        }

        labelEl.innerHTML = `
            <textarea class="label-textarea" data-label-id="${label.id}">${label.text || ''}</textarea>
            <div class="resizer" data-label-id="${label.id}"></div>
        `;
        return labelEl;
    }


    function renderConnectors() {
        connectorLayer.innerHTML = '';
        const drawConnection = (startX, startY, endX, endY, color, dataAttributes) => {
            const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            const d = `M ${startX} ${startY} C ${startX + 50} ${startY}, ${endX - 50} ${endY}, ${endX} ${endY}`;
            path.setAttribute('d', d);
            path.setAttribute('stroke', color);
            path.setAttribute('stroke-width', '2');
            path.setAttribute('fill', 'none');

            const interactionPath = path.cloneNode();
            interactionPath.setAttribute('stroke', 'transparent');
            interactionPath.setAttribute('stroke-width', '15');
            interactionPath.setAttribute('pointer-events', 'stroke');
            interactionPath.style.cursor = 'pointer';
            for (const attr in dataAttributes) {
                interactionPath.dataset[attr] = dataAttributes[attr];
            }

            connectorLayer.appendChild(path);
            connectorLayer.appendChild(interactionPath);
        };

        Object.values(state.choices).forEach(choice => {
            if (choice.next_node_id && state.nodes[choice.node_id] && state.nodes[choice.next_node_id]) {
                const startNodeEl = document.querySelector(`#node-${choice.node_id}`);
                const endNodeEl = document.querySelector(`#node-${choice.next_node_id}`);
                const choiceEl = startNodeEl.querySelector(`.node-choice[data-choice-id="${choice.id}"]`);
                if (!startNodeEl || !endNodeEl || !choiceEl) return;
                const startX = startNodeEl.offsetLeft + startNodeEl.offsetWidth;
                const startY = startNodeEl.offsetTop + choiceEl.offsetTop + choiceEl.offsetHeight / 2;
                const endX = endNodeEl.offsetLeft;
                const endY = endNodeEl.offsetTop + endNodeEl.offsetHeight / 2;
                drawConnection(startX, startY, endX, endY, '#a0a0a0', { connectionType: 'choice', choiceId: choice.id });
            }
        });

        Object.values(state.nodes).forEach(node => {
            if (node.next_node_id && state.nodes[node.next_node_id]) {
                const startNodeEl = document.querySelector(`#node-${node.id}`);
                const endNodeEl = document.querySelector(`#node-${node.next_node_id}`);
                if (!startNodeEl || !endNodeEl) return;
                const startX = startNodeEl.offsetLeft + startNodeEl.offsetWidth;
                const startY = startNodeEl.offsetTop + startNodeEl.offsetHeight / 2;
                const endX = endNodeEl.offsetLeft;
                const endY = endNodeEl.offsetTop + endNodeEl.offsetHeight / 2;
                drawConnection(startX, startY, endX, endY, '#43a047', { connectionType: 'node', nodeId: node.id });
            }
        });
    }

    function updateInspector() {
        inspectorContent.innerHTML = '';
        exportActionsPanel.classList.add('hidden');

        if (!state.selectedElement) {
            inspectorPanel.classList.add('hidden');
            return;
        }

        inspectorPanel.classList.remove('hidden');
        const { type, id } = state.selectedElement;

        if (type === 'node') {
            const node = state.nodes[id];
            const displayLanguage = node.displayLanguage || state.activeLanguage;
            if (node.node_type === 'dialog') {
                inspectorContent.innerHTML = `
                    <div class="inspector-section">
                        <h3>Node Properties (ID: ${node.node_sequence_id || id})</h3>
                        <label>Next Node ID: ${node.next_node_id || 'Not Connected'}</label>
                        <label for="insp-node-dialog">Dialog Text (${displayLanguage.toUpperCase()})</label>
                        <textarea id="insp-node-dialog" data-node-id="${id}">${getTextForLanguage(node.dialog_text, displayLanguage)}</textarea>

                        <button class="inspector-btn" id="setStartNodeBtn" data-node-id="${id}">Set as Start Node</button>
                        <button class="inspector-btn delete-btn" id="deleteNodeBtn" data-node-id="${id}">Delete Node</button>
                    </div>
                    <div class="inspector-section">
                        <h3>Choices</h3>
                        <button class="inspector-btn" id="addChoiceBtn" data-node-id="${id}">+ Add New Choice</button>
                    </div>
                `;
            } else if (node.node_type === 'json' || node.node_type === 'sheet') {
                inspectorContent.innerHTML = `
                    <div class="inspector-section">
                        <h3>Export Node: ${node.node_type.toUpperCase()}</h3>
                        <p>This node acts as a marker for exporting a specific branch of the dialogue tree.</p>
                        <label>Upstream Nodes (starting from here)</label>
                        <ul id="upstream-node-list"></ul>
                        <button class="inspector-btn delete-btn" id="deleteNodeBtn" data-node-id="${id}">Delete Node</button>
                    </div>
                `;
                const upstreamNodeList = document.getElementById('upstream-node-list');
                const upstreamNodes = getUpstreamNodes(id);
                upstreamNodes.forEach(nodeId => {
                    const listItem = document.createElement('li');
                    listItem.textContent = nodeId;
                    upstreamNodeList.appendChild(listItem);
                });

                exportActionsPanel.classList.remove('hidden');
                exportToCsvBtn.disabled = (node.node_type !== 'sheet');
                exportToJsonBtn.disabled = (node.node_type !== 'json');

            } else if (node.node_type === 'empty') {
                inspectorContent.innerHTML = `
                    <div class="inspector-section">
                        <h3>Empty Node</h3>
                        <p>This is a utility node with no content, useful for routing connections.</p>
                        <button class="inspector-btn delete-btn" id="deleteNodeBtn" data-node-id="${id}">Delete Node</button>
                    </div>
                `;
            } else { // Reference nodes
                inspectorContent.innerHTML = `
                    <div class="inspector-section">
                        <h3>Reference Node</h3>
                        <p>This node links to another item.</p>
                        <label>Next Node ID: ${node.next_node_id || 'Not Connected'}</label>
                        <button class="inspector-btn" id="setStartNodeBtn" data-node-id="${id}">Set as Start Node</button>
                        <button class="inspector-btn delete-btn" id="deleteNodeBtn" data-node-id="${id}">Delete Node</button>
                    </div>
                `;
            }
        } else if (type === 'choice') {
            const choice = state.choices[id];
            if (!choice) return;
            const parentNode = state.nodes[choice.node_id];
            const displayLanguage = parentNode.displayLanguage || state.activeLanguage;

            const conditions = choice.conditions || [];
            const setters = choice.setters || [];

            let conditionsHtml = conditions.map((cond, index) => `
                <div class="condition-item" data-index="${index}">
                    <input type="text" value="${cond.variable_name}" placeholder="Variable Name">
                    <select>
                        ${['==', '!=', '>', '<', '>=', '<='].map(op => `<option ${op === cond.operator ? 'selected' : ''}>${op}</option>`).join('')}
                    </select>
                    <input type="text" value="${cond.required_value}" placeholder="Required Value">
                    <button class="remove-btn" data-type="condition">&times;</button>
                </div>
            `).join('');

            let settersHtml = setters.map((setter, index) => `
                <div class="setter-item" data-index="${index}">
                    <input type="text" value="${setter.variable_name}" placeholder="Variable Name">
                    <select>
                        ${['=', '+=', '-='].map(op => `<option ${op === setter.operator ? 'selected' : ''}>${op}</option>`).join('')}
                    </select>
                    <input type="text" value="${setter.value}" placeholder="Value">
                    <button class="remove-btn" data-type="setter">&times;</button>
                </div>
            `).join('');

            inspectorContent.innerHTML = `
                <div class="inspector-section">
                    <h3>Choice Properties</h3>
                    <label for="insp-choice-text">Choice Text (${displayLanguage.toUpperCase()})</label>
                    <textarea id="insp-choice-text" data-choice-id="${id}">${getTextForLanguage(choice.choice_text, displayLanguage)}</textarea>
                    <label>Next Node ID: ${choice.next_node_id || 'Not Connected'}</label>
                    <button class="inspector-btn create-link-btn" id="createAndLinkNodeBtn" data-choice-id="${id}">Create & Link New Node</button>
                    <button class="inspector-btn delete-btn" id="deleteChoiceBtn" data-choice-id="${id}">Delete Choice</button>
                </div>
                <div class="inspector-section">
                    <h3>Conditions (ALL must be true)</h3>
                    <div id="conditions-list">${conditionsHtml}</div>
                    <button class="inspector-btn" id="addConditionBtn">+ Add Condition</button>
                </div>
                <div class="inspector-section">
                    <h3>Variable Setters (Run on select)</h3>
                    <div id="setters-list">${settersHtml}</div>
                    <button class="inspector-btn" id="addSetterBtn">+ Add Setter</button>
                </div>
            `;
        } else if (type === 'label') {
            const label = state.labels[id];
            const colors = ['#e53935', '#1e88e5', '#43a047', '#fdd835', '#fb8c00', '#8e24aa', '#d81b60', '#37474f'];
            const colorPaletteHtml = colors.map(color => `
                <div class="color-swatch ${label.color === color ? 'selected' : ''}" style="background-color: ${color};" data-color="${color}"></div>
            `).join('');

            inspectorContent.innerHTML = `
                <div class="inspector-section">
                    <h3>Label</h3>
                    <label>Color</label>
                    <div class="inspector-color-palette">${colorPaletteHtml}</div>
                    <button class="inspector-btn delete-btn" id="deleteLabelBtn" data-label-id="${id}">Delete Label</button>
                </div>
            `;
        }
    }

    function updateStatus(message, isError = false) {
        statusMessage.textContent = message;
        statusMessage.style.color = isError ? 'var(--accent-primary)' : 'var(--text-secondary)';
    }

    function updateButtonStates() {
        const isItemActive = !!state.activeItem.id;
        nodesTab.disabled = !isItemActive;
        saveConfigBtn.disabled = !isItemActive;
        pushChangesBtn.disabled = !isItemActive;
        previewBtn.disabled = !isItemActive || state.activeItem.type !== 'conversation';
    }

    function updateCanvasTransform() {
        canvasTransformer.style.transform = `translate(${state.panOffset.x}px, ${state.panOffset.y}px) scale(${state.zoom})`;
    }

    mainNav.addEventListener('click', e => {
        if (e.target.matches('.nav-tab:not(:disabled)')) {
            switchView(e.target.dataset.view);
        }
    });

    languageSelector.addEventListener('change', e => {
        state.activeLanguage = e.target.value;
        renderAll();
        updateInspector();
    });

    function clearSelections() {
        state.selectedElement = null;
        state.multiSelectedNodes.clear();
        document.querySelectorAll('.node.selected, .node-choice.selected, .node.multi-selected, .label-box.selected').forEach(el => el.classList.remove('selected', 'multi-selected'));
    }

    function handleSelection(type, id, event = {}) {
        const isCtrl = event.ctrlKey || event.metaKey;

        if (type === 'node' && isCtrl) {
            if (state.multiSelectedNodes.has(id)) {
                state.multiSelectedNodes.delete(id);
                document.getElementById(`node-${id}`)?.classList.remove('multi-selected', 'selected');
            } else {
                state.multiSelectedNodes.add(id);
                document.getElementById(`node-${id}`)?.classList.add('multi-selected');
            }
            state.selectedElement = null;
        } else {
            clearSelections();
            state.selectedElement = { type, id };
            if (type === 'node') {
                state.multiSelectedNodes.add(id);
                document.getElementById(`node-${id}`)?.classList.add('selected');
            } else if (type === 'choice') {
                document.querySelector(`.node-choice[data-choice-id="${id}"]`)?.classList.add('selected');
            } else if (type === 'label') {
                document.getElementById(`label-${id}`)?.classList.add('selected');
            }
        }
        updateInspector();
    }

    canvas.addEventListener('mousedown', e => {
        const target = e.target;
        const nodeEl = target.closest('.node');

        if (e.button === 1) {
            e.preventDefault();
            state.isPanning = true;
            state.panStart.x = e.clientX - state.panOffset.x;
            state.panStart.y = e.clientY - state.panOffset.y;
            canvas.style.cursor = 'grabbing';
            return;
        }

        if (e.button !== 0) return;

        const resizerEl = target.closest('.resizer');
        const choiceConnector = target.closest('.choice-connector');
        const nodeConnector = target.closest('.node-output-connector');
        const inputConnector = target.closest('.node-input-connector');
        const labelEl = target.closest('.label-box');

        if (resizerEl) {
            e.stopPropagation();
            state.isResizingLabel = true;
            state.draggedElementId = resizerEl.dataset.labelId;
            handleSelection('label', state.draggedElementId);
            return;
        }

        if (choiceConnector || nodeConnector || inputConnector) {
            e.stopPropagation();
            state.isConnecting = true;
            if (choiceConnector) {
                state.connectionStartChoiceId = choiceConnector.dataset.choiceId;
                state.connectionStartNodeId = null;
                updateStatus('Connecting choice...');
            } else {
                state.connectionStartNodeId = nodeConnector?.dataset.nodeId || inputConnector?.dataset.nodeId;
                state.connectionStartChoiceId = null;
                updateStatus('Connecting main output...');
            }

            state.connectionLine = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            state.connectionLine.setAttribute('stroke', 'var(--accent-secondary)');
            state.connectionLine.setAttribute('stroke-width', '2');
            state.connectionLine.setAttribute('fill', 'none');
            connectorLayer.appendChild(state.connectionLine);
            return;
        }

        if (nodeEl || labelEl) {
            const id = (nodeEl?.id || labelEl?.id).replace(/^(node|label)-/, '');
            const type = nodeEl ? 'node' : 'label';

            handleSelection(type, id, e);

            state.isDragging = true;
            state.draggedElementId = id;

            const element = type === 'node' ? state.nodes[id] : state.labels[id];

            const canvasRect = canvas.getBoundingClientRect();
            const mouseX = (e.clientX - canvasRect.left - state.panOffset.x) / state.zoom;
            const mouseY = (e.clientY - canvasRect.top - state.panOffset.y) / state.zoom;
            state.dragOffset = {
                x: mouseX - element.x,
                y: mouseY - element.y
            };
        } else {
            clearSelections();
            updateInspector();
            state.isMarqueeSelecting = true;
            const canvasRect = canvas.getBoundingClientRect();
            state.marqueeStart.x = (e.clientX - canvasRect.left - state.panOffset.x) / state.zoom;
            state.marqueeStart.y = (e.clientY - canvasRect.top - state.panOffset.y) / state.zoom;
            marqueeBox.style.left = `${state.marqueeStart.x}px`;
            marqueeBox.style.top = `${state.marqueeStart.y}px`;
            marqueeBox.style.width = '0px';
            marqueeBox.style.height = '0px';
            marqueeBox.style.display = 'block';
        }
    });

    canvas.addEventListener('click', e => {
        const choiceEl = e.target.closest('.node-choice');
        if (choiceEl) {
            const choiceId = choiceEl.dataset.choiceId;
            handleSelection('choice', choiceId, e);
        }
    });

    canvas.addEventListener('input', e => {
        if (e.target.matches('.label-textarea')) {
            const labelId = e.target.dataset.labelId;
            if (state.labels[labelId]) {
                state.labels[labelId].text = e.target.value;
            }
        }
    });

    canvas.addEventListener('change', e => {
        if (e.target.matches('.node-language-selector')) {
            const nodeId = e.target.dataset.nodeId;
            const selectedLang = e.target.value;
            const node = state.nodes[nodeId];
            if (node) {
                node.displayLanguage = selectedLang;
                renderNode(nodeId);
                if (state.selectedElement && state.selectedElement.type === 'node' && state.selectedElement.id === nodeId) {
                    updateInspector();
                }
            }
        } else if (e.target.matches('.node-world-select, .node-character-select')) {
            const nodeId = e.target.dataset.nodeId;
            const node = state.nodes[nodeId];
            if (e.target.matches('.node-world-select')) {
                node.world_id = e.target.value;
            }
            if (e.target.matches('.node-character-select')) {
                node.character_id = e.target.value;
                const character = state.characters.find(c => c.id == e.target.value);
                node.speaker = character ? character.name : 'NO SPEAKER';
            }
            renderNode(nodeId);
        }
    });

    canvas.addEventListener('mousemove', e => {
        const canvasRect = canvas.getBoundingClientRect();
        const mouseX = (e.clientX - canvasRect.left - state.panOffset.x) / state.zoom;
        const mouseY = (e.clientY - canvasRect.top - state.panOffset.y) / state.zoom;

        if (state.isPanning) {
            state.panOffset.x = e.clientX - state.panStart.x;
            state.panOffset.y = e.clientY - state.panStart.y;
            updateCanvasTransform();
        }

        if (state.isDragging && state.draggedElementId) {
            const element = state.selectedElement.type === 'node' ? state.nodes[state.draggedElementId] : state.labels[state.draggedElementId];
            const dx = mouseX - state.dragOffset.x - element.x;
            const dy = mouseY - state.dragOffset.y - element.y;

            if (state.selectedElement.type === 'node' && state.multiSelectedNodes.size > 0) {
                state.multiSelectedNodes.forEach(nodeId => {
                    const node = state.nodes[nodeId];
                    const nodeEl = document.getElementById(`node-${nodeId}`);
                    if (node && nodeEl) {
                        node.x += dx;
                        node.y += dy;
                        nodeEl.style.left = `${node.x}px`;
                        nodeEl.style.top = `${node.y}px`;
                    }
                });
            } else {
                const elementEl = document.getElementById(`${state.selectedElement.type}-${state.draggedElementId}`);
                if (element && elementEl) {
                    element.x += dx;
                    element.y += dy;
                    elementEl.style.left = `${element.x}px`;
                    elementEl.style.top = `${element.y}px`;
                }
            }
            renderConnectors();
        }

        if (state.isResizingLabel) {
            const label = state.labels[state.draggedElementId];
            const labelEl = document.getElementById(`label-${state.draggedElementId}`);
            if (label && labelEl) {
                label.width = Math.max(50, mouseX - label.x);
                label.height = Math.max(30, mouseY - label.y);
                labelEl.style.width = `${label.width}px`;
                labelEl.style.height = `${label.height}px`;
            }
        }

        if (state.isMarqueeSelecting) {
            const currentX = mouseX;
            const currentY = mouseY;
            const x = Math.min(state.marqueeStart.x, currentX);
            const y = Math.min(state.marqueeStart.y, currentY);
            const width = Math.abs(state.marqueeStart.x - currentX);
            const height = Math.abs(state.marqueeStart.y - currentY);
            marqueeBox.style.left = `${x}px`;
            marqueeBox.style.top = `${y}px`;
            marqueeBox.style.width = `${width}px`;
            marqueeBox.style.height = `${height}px`;
            marqueeBox.style.display = 'block';
        }

        if (state.isConnecting && state.connectionLine) {
            let startX, startY;
            const endX = mouseX;
            const endY = mouseY;

            if (state.connectionStartChoiceId) {
                const startChoiceEl = document.querySelector(`.choice-connector[data-choice-id="${state.connectionStartChoiceId}"]`);
                if (!startChoiceEl) return;
                const choiceRect = startChoiceEl.getBoundingClientRect();
                const canvasRect = canvas.getBoundingClientRect();
                startX = (choiceRect.left + choiceRect.width / 2 - canvasRect.left - state.panOffset.x) / state.zoom;
                startY = (choiceRect.top + choiceRect.height / 2 - canvasRect.top - state.panOffset.y) / state.zoom;
            } else if (state.connectionStartNodeId) {
                const startNodeEl = document.getElementById(`node-${state.connectionStartNodeId}`);
                if (!startNodeEl) return;
                const connector = startNodeEl.querySelector('.node-output-connector, .node-input-connector');
                const connectorRect = connector.getBoundingClientRect();
                const canvasRect = canvas.getBoundingClientRect();
                startX = (connectorRect.left + connectorRect.width / 2 - canvasRect.left - state.panOffset.x) / state.zoom;
                startY = (connectorRect.top + connectorRect.height / 2 - canvasRect.top - state.panOffset.y) / state.zoom;
            }

            const d = `M ${startX} ${startY} C ${startX + 50} ${startY}, ${endX - 50} ${endY}, ${endX} ${endY}`;
            state.connectionLine.setAttribute('d', d);
        }
    });

    canvas.addEventListener('mouseup', e => {
        if (state.isPanning) {
            state.isPanning = false;
            canvas.style.cursor = 'default';
        }

        if (state.isDragging) {
            state.isDragging = false;
            state.draggedElementId = null;
        }

        if (state.isResizingLabel) {
            state.isResizingLabel = false;
            state.draggedElementId = null;
        }

        if (state.isMarqueeSelecting) {
            state.isMarqueeSelecting = false;
            marqueeBox.style.display = 'none';
            const x = parseFloat(marqueeBox.style.left);
            const y = parseFloat(marqueeBox.style.top);
            const width = parseFloat(marqueeBox.style.width);
            const height = parseFloat(marqueeBox.style.height);
            const marqueeRect = { x, y, x2: x + width, y2: y + height };

            clearSelections();
            Object.values(state.nodes).forEach(node => {
                const nodeEl = document.getElementById(`node-${node.id}`);
                const nodeRect = { x: node.x, y: node.y, x2: node.x + nodeEl.offsetWidth, y2: node.y + nodeEl.offsetHeight };
                if (nodeRect.x < marqueeRect.x2 && nodeRect.x2 > marqueeRect.x && nodeRect.y < marqueeRect.y2 && nodeRect.y2 > marqueeRect.y) {
                    state.multiSelectedNodes.add(node.id);
                    nodeEl.classList.add('multi-selected');
                }
            });
        }

        if (state.isConnecting) {
            const targetNodeEl = e.target.closest('.node');
            let connected = false;

            if (targetNodeEl) {
                const targetNodeId = targetNodeEl.id.replace('node-', '');
                if (state.connectionStartChoiceId) {
                    const choice = state.choices[state.connectionStartChoiceId];
                    if (choice && choice.node_id !== targetNodeId) {
                        choice.next_node_id = targetNodeId;
                        updateStatus(`Connected choice to node ${targetNodeId}.`);
                        connected = true;
                    }
                } else if (state.connectionStartNodeId) {
                    const node = state.nodes[state.connectionStartNodeId];
                    if (node && node.id !== targetNodeId) {
                        node.next_node_id = targetNodeId;
                        updateStatus(`Connected node output to node ${targetNodeId}.`);
                        connected = true;
                    }
                }
            } else if (e.target.closest('#editor-canvas, #canvas-transformer, #label-layer, #node-layer')) {
                const canvasRect = canvas.getBoundingClientRect();
                const dropX = (e.clientX - canvasRect.left - state.panOffset.x) / state.zoom;
                const dropY = (e.clientY - canvasRect.top - state.panOffset.y) / state.zoom;

                const newNodeId = `node_${Date.now()}`;
                state.nodes[newNodeId] = { id: newNodeId, node_type: 'dialog', dialog_text: { [state.activeLanguage]: 'New dialog.' }, x: dropX, y: dropY, displayLanguage: state.activeLanguage };

                if (state.connectionStartChoiceId) {
                    state.choices[state.connectionStartChoiceId].next_node_id = newNodeId;
                } else if (state.connectionStartNodeId) {
                    state.nodes[state.connectionStartNodeId].next_node_id = newNodeId;
                }
                connected = true;
                renderNode(newNodeId);
                handleSelection('node', newNodeId);
            }

            state.isConnecting = false;
            state.connectionStartChoiceId = null;
            state.connectionStartNodeId = null;
            if (state.connectionLine) {
                state.connectionLine.remove();
                state.connectionLine = null;
            }
            if (connected) {
                renderConnectors();
                updateInspector();
            }
        }
    });

    connectorLayer.addEventListener('click', e => {
        if (e.target.tagName === 'path' && e.target.dataset.connectionType) {
            const { connectionType, choiceId, nodeId } = e.target.dataset;
            if (confirm('Are you sure you want to delete this connection?')) {
                if (connectionType === 'choice' && state.choices[choiceId]) {
                    state.choices[choiceId].next_node_id = null;
                } else if (connectionType === 'node' && state.nodes[nodeId]) {
                    state.nodes[nodeId].next_node_id = null;
                }
                renderConnectors();
            }
        }
    });

    canvas.addEventListener('wheel', e => {
        e.preventDefault();
        const zoomSpeed = 0.1;
        const oldZoom = state.zoom;
        const delta = e.deltaY > 0 ? -1 : 1;

        state.zoom = Math.max(0.2, Math.min(3, oldZoom + delta * zoomSpeed));

        const canvasRect = canvas.getBoundingClientRect();
        const mouseX = e.clientX - canvasRect.left;
        const mouseY = e.clientY - canvasRect.top;

        state.panOffset.x = mouseX - (mouseX - state.panOffset.x) * (state.zoom / oldZoom);
        state.panOffset.y = mouseY - (mouseY - state.panOffset.y) * (state.zoom / oldZoom);

        updateCanvasTransform();
    });

    inspectorPanel.addEventListener('input', e => {
        if (!state.selectedElement) return;
        const { type, id } = state.selectedElement;
        const target = e.target;

        if (type === 'node') {
            const node = state.nodes[id];
            if (target.id === 'insp-node-dialog') {
                const displayLanguage = node.displayLanguage || state.activeLanguage;
                if (typeof node.dialog_text !== 'object' || node.dialog_text === null) node.dialog_text = {};
                node.dialog_text[displayLanguage] = target.value;
                document.querySelector(`#node-${id} .node-content`).textContent = target.value || '...';
            }
        } else if (type === 'choice') {
            const choice = state.choices[id];
            const parentNode = state.nodes[choice.node_id];
            const displayLanguage = parentNode.displayLanguage || state.activeLanguage;

            if (target.id === 'insp-choice-text') {
                if (typeof choice.choice_text !== 'object' || choice.choice_text === null) choice.choice_text = {};
                choice.choice_text[displayLanguage] = target.value;
                const choiceEl = document.querySelector(`.node-choice[data-choice-id="${id}"]`);
                choiceEl.firstChild.textContent = (target.value || 'Empty Choice').trim() + ' ';
            }

            const itemEl = target.closest('.condition-item, .setter-item');
            if (itemEl) {
                const listId = itemEl.parentElement.id;
                const index = parseInt(itemEl.dataset.index);
                const list = listId === 'conditions-list' ? choice.conditions : choice.setters;
                const item = list[index];

                if (target.tagName === 'INPUT' && target.placeholder === 'Variable Name') item.variable_name = target.value;
                if (target.tagName === 'SELECT') item.operator = target.value;
                if (target.tagName === 'INPUT' && target.placeholder.includes('Value')) {
                    if (listId === 'conditions-list') item.required_value = target.value;
                    else item.value = target.value;
                }
            }
        }
    });

    inspectorPanel.addEventListener('click', e => {
        if (!state.selectedElement && !e.target.closest('.inspector-section')) return;

        const target = e.target;
        const { type, id } = state.selectedElement || {};

        if (target.id === 'addChoiceBtn') {
            const nodeId = target.dataset.nodeId;
            const parentNode = state.nodes[nodeId];
            const displayLanguage = parentNode.displayLanguage || state.activeLanguage;
            const newChoiceId = `choice_${Date.now()}`;
            state.choices[newChoiceId] = { id: newChoiceId, node_id: nodeId, choice_text: { [displayLanguage]: 'New Choice' }, next_node_id: null, conditions: [], setters: [] };

            renderNode(nodeId);
            handleSelection('choice', newChoiceId);
        }
        if (target.id === 'deleteNodeBtn') {
            if (confirm(`Are you sure you want to delete this node?`)) {
                delete state.nodes[id];
                Object.keys(state.choices).forEach(choiceId => {
                    if (state.choices[choiceId].node_id === id) delete state.choices[choiceId];
                });
                Object.values(state.choices).forEach(choice => {
                    if (choice.next_node_id === id) choice.next_node_id = null;
                });
                state.selectedElement = null;
                renderAll();
                updateInspector();
            }
        }
        if (target.id === 'deleteLabelBtn') {
            if (confirm('Are you sure you want to delete this label?')) {
                delete state.labels[id];
                state.selectedElement = null;
                renderAllLabels();
                updateInspector();
            }
        }
        if (target.id === 'setStartNodeBtn') {
            const activeCollection = state.activeItem.type === 'conversation' ? state.conversations : state.quests;
            const item = activeCollection.find(i => i.id == state.activeItem.id);
            if (item) {
                item.start_node_id = id;
                updateStatus(`Node set as start for this ${state.activeItem.type}.`);
                renderAllNodes();
            }
        }
        if (target.id === 'deleteChoiceBtn') {
            const parentNodeId = state.choices[id].node_id;
            delete state.choices[id];
            state.selectedElement = null;
            renderNode(parentNodeId);
            updateInspector();
        }
        if (target.id === 'createAndLinkNodeBtn') {
            const choiceId = target.dataset.choiceId;
            const choice = state.choices[choiceId];
            const parentNode = state.nodes[choice.node_id];

            const newNodeId = `node_${Date.now()}`;
            state.nodes[newNodeId] = { id: newNodeId, node_type: 'dialog', dialog_text: { [state.activeLanguage]: 'New dialog.' }, x: parentNode.x + 320, y: parentNode.y, displayLanguage: state.activeLanguage };

            choice.next_node_id = newNodeId;

            renderAll();
            handleSelection('node', newNodeId);
        }
        if (target.id === 'addConditionBtn' || target.id === 'addSetterBtn') {
            if (target.id === 'addConditionBtn') state.choices[id].conditions.push({ variable_name: '', operator: '==', required_value: '' });
            if (target.id === 'addSetterBtn') state.choices[id].setters.push({ variable_name: '', operator: '=', value: '' });
            updateInspector();
        }
        if (target.classList.contains('remove-btn')) {
            const itemEl = target.closest('.condition-item, .setter-item');
            const index = parseInt(itemEl.dataset.index);
            if (target.dataset.type === 'condition') state.choices[id].conditions.splice(index, 1);
            else state.choices[id].setters.splice(index, 1);
            updateInspector();
        }
        if (target.classList.contains('color-swatch')) {
            const newColor = target.dataset.color;
            if (type === 'label') {
                const label = state.labels[id];
                label.color = newColor;
                const labelEl = document.getElementById(`label-${id}`);
                if (labelEl) {
                    labelEl.style.setProperty('--label-border-color', newColor);
                    labelEl.style.setProperty('--label-bg-color', `${newColor}20`);
                    labelEl.style.setProperty('--label-bg-color-selected', `${newColor}40`);
                }
                updateInspector();
            }
        }
        if (target.id === 'exportToCsvBtn') {
            handleDownload('csv', id);
        }
        if (target.id === 'exportToJsonBtn') {
            handleDownload('json', id);
        }
    });

    mainContainer.addEventListener('click', async e => {
        const item = e.target.closest('.entity-item');
        if (!item) return;

        const deleteBtn = e.target.closest('.delete-entity-btn');
        const nameSpan = e.target.closest('.entity-name');
        const id = item.dataset.id;
        const type = item.dataset.type;

        if (deleteBtn) {
            e.stopPropagation();
            if (confirm(`Are you sure you want to permanently delete this ${type}?`)) {
                const result = await apiCall(`delete_${type}`, { [`${type}_id`]: id });
                if (result.success) {
                    if (type === 'conversation') renderConversationsView();
                    else if (type === 'quest') renderQuestsView();
                    else if (type === 'world') loadWorlds();
                    else if (type === 'character') loadCharacters();
                }
            }
        } else if (nameSpan) {
            await loadItem(type, id);
        }
    });

    function getCenterOfCanvas() {
        const canvasRect = canvas.getBoundingClientRect();
        return {
            x: (canvasRect.width / 2 - state.panOffset.x) / state.zoom,
            y: (canvasRect.height / 2 - state.panOffset.y) / state.zoom,
        };
    }

    addNodeBtn.addEventListener('click', () => {
        if (!state.activeItem.id) return;
        const center = getCenterOfCanvas();
        const newNodeId = `node_${Date.now()}`;
        state.nodes[newNodeId] = { id: newNodeId, node_type: 'dialog', dialog_text: { [state.activeLanguage]: 'New dialog.' }, x: center.x - 140, y: center.y - 50, displayLanguage: state.activeLanguage };
        const nodeEl = createNodeElement(state.nodes[newNodeId]);
        nodeLayer.appendChild(nodeEl);
        handleSelection('node', newNodeId);
    });

    addEmptyNodeBtn.addEventListener('click', () => {
        if (!state.activeItem.id) return;
        const center = getCenterOfCanvas();
        const newNodeId = `node_${Date.now()}`;
        state.nodes[newNodeId] = { id: newNodeId, node_type: 'empty', x: center.x - 20, y: center.y - 20 };
        const nodeEl = createNodeElement(state.nodes[newNodeId]);
        nodeLayer.appendChild(nodeEl);
        handleSelection('node', newNodeId);
    });

    addLabelBtn.addEventListener('click', () => {
        if (!state.activeItem.id) return;
        const center = getCenterOfCanvas();
        const newLabelId = `label_${Date.now()}`;
        state.labels[newLabelId] = { id: newLabelId, text: 'My Label', x: center.x - 100, y: center.y - 50, width: 200, height: 100, color: '#e53935' };
        const labelEl = createLabelElement(state.labels[newLabelId]);
        labelLayer.appendChild(labelEl);
        handleSelection('label', newLabelId);
    });

    saveConfigBtn.addEventListener('click', async () => {
        if (!state.activeItem.id) return;
        updateStatus('Saving...');

        const activeCollection = state.activeItem.type === 'conversation' ? state.conversations : state.quests;
        const item = activeCollection.find(i => i.id == state.activeItem.id);

        const nodesToSave = Object.values(state.nodes).map(node => {
            const { displayLanguage, ...rest } = node;
            return rest;
        });

        const data = {
            id: state.activeItem.id,
            type: state.activeItem.type,
            start_node_id: item.start_node_id,
            nodes: nodesToSave,
            choices: Object.values(state.choices)
        };

        const result = await apiCall('save_item_data', data);
        const labelResult = await apiCall('save_labels', { item_id: state.activeItem.id, item_type: state.activeItem.type, labels: Object.values(state.labels) });

        if (result.success && labelResult.success) {
            updateStatus('Save complete. Reloading...');
            await loadItem(state.activeItem.type, state.activeItem.id);
        } else {
            updateStatus('Save failed.', true);
        }
    });

    pushChangesBtn.addEventListener('click', async () => {
        if (!state.activeItem.id) return;
        if (!confirm("This will push the LAST SAVED version to the live server. Are you sure?")) return;
        updateStatus('Pushing changes...');
        await apiCall('push_changes', { id: state.activeItem.id, type: state.activeItem.type });
        updateStatus('Changes pushed successfully!');
    });

    mainContainer.addEventListener('change', async e => {
        if (e.target.matches('.color-input')) {
            const id = e.target.dataset.id;
            const type = e.target.dataset.type;
            const color = e.target.value;

            const entityItem = e.target.closest('.entity-item');
            if (entityItem) {
                entityItem.style.borderLeftColor = color;
            }

            const result = await apiCall('update_color', { id, type, color });

            if (result.success) {
                let collection;
                if (type === 'conversation') collection = state.conversations;
                else if (type === 'quest') collection = state.quests;
                else if (type === 'world') collection = state.worlds;
                else if (type === 'character') collection = state.characters;

                const item = collection.find(i => i.id == id);
                if (item) item.color = color;
            } else {
                updateStatus(`Failed to update color for ${type} ${id}. Reverting.`, true);
                if (type === 'conversation') renderConversationsView();
                else if (type === 'quest') renderQuestsView();
                else if (type === 'world') loadWorlds();
                else if (type === 'character') loadCharacters();
            }
        }
    });

    function openModal(modal) {
        modal.classList.remove('hidden');
        modalBackdrop.classList.remove('hidden');
    }

    function closeModal(modal) {
        modal.classList.add('hidden');
        modalBackdrop.classList.add('hidden');
    }

    modalBackdrop.addEventListener('click', () => {
        closeModal(testerModal);
        closeModal(referenceModal);
    });
    closeReferenceBtn.addEventListener('click', () => closeModal(referenceModal));

    async function loadItem(type, id) {
        updateStatus(`Loading ${type} ${id}...`);
        const itemDataResult = await apiCall('get_item_data', { type, id });
        const labelResult = await apiCall('get_labels', { item_id: id, item_type: type });

        if (itemDataResult.success && labelResult.success) {
            state.activeItem = { type, id };

            state.nodes = Object.entries(itemDataResult.data.nodes || {}).reduce((acc, [nodeId, nodeData]) => {
                acc[nodeId] = { ...nodeData, displayLanguage: state.activeLanguage };
                return acc;
            }, {});

            state.choices = (itemDataResult.data.choices || []).reduce((acc, choice) => {
                acc[choice.id] = choice;
                return acc;
            }, {});
            state.labels = labelResult.data || {};
            clearSelections();

            const activeCollection = type === 'conversation' ? state.conversations : state.quests;
            const itemTitle = activeCollection.find(i => i.id == id)?.title;
            updateStatus(`Editing: ${itemTitle}`);

            renderAll();
            updateButtonStates();
            updateInspector();
            switchView('nodes');
        }
    }

    async function loadWorlds() {
        const result = await apiCall('get_worlds');
        if (result.success) {
            state.worlds = result.data;
            const listEl = document.getElementById('worlds-list');
            listEl.innerHTML = state.worlds.map(world => `
                <div class="entity-item" data-id="${world.id}" data-type="world">
                    <span class="entity-name">${world.name}</span>
                    <div class="entity-actions">
                        <span class="entity-id">ID: ${world.id}</span>
                        <button class="delete-entity-btn" title="Delete World" data-id="${world.id}" data-type="world">&times;</button>
                    </div>
                </div>
            `).join('') || '<p>No worlds created yet.</p>';
        }
    }
    addWorldBtn.addEventListener('click', async () => {
        const nameInput = document.getElementById('new-world-name');
        const name = nameInput.value.trim();
        if (name) {
            const result = await apiCall('add_world', { name });
            if (result.success) {
                nameInput.value = '';
                await loadWorlds();
                if(state.activeItem.id) {
                    await loadItem(state.activeItem.type, state.activeItem.id);
                }
            }
        }
    });

    async function loadCharacters() {
        const result = await apiCall('get_characters');
        if (result.success) {
            state.characters = result.data;
            const listEl = document.getElementById('characters-list');
            listEl.innerHTML = state.characters.map(char => `
                <div class="entity-item" data-id="${char.id}" data-type="character" style="border-left-color: ${char.color || '#1e88e5'};">
                    <span class="entity-name">${char.name}</span>
                    <div class="entity-actions">
                        <span class="entity-id">ID: ${char.id}</span>
                        <div class="color-picker-wrapper">
                            <button class="color-picker-btn" title="Change Color"><i class="fa-solid fa-palette"></i></button>
                            <input type="color" class="color-input" value="${char.color || '#1e88e5'}" data-id="${char.id}" data-type="character">
                        </div>
                        <button class="delete-entity-btn" title="Delete Character" data-id="${char.id}" data-type="character">&times;</button>
                    </div>
                </div>
            `).join('') || '<p>No characters created yet.</p>';
        }
    }
    addCharacterBtn.addEventListener('click', async () => {
        const nameInput = document.getElementById('new-character-name');
        const name = nameInput.value.trim();
        if (name) {
            const result = await apiCall('add_character', { name });
            if (result.success) {
                nameInput.value = '';
                await loadCharacters();
                 if(state.activeItem.id) {
                    await loadItem(state.activeItem.type, state.activeItem.id);
                }
            }
        }
    });

    async function loadLanguages() {
        const result = await apiCall('get_languages');
        if (result.success) {
            state.languages = result.data;
            const listEl = document.getElementById('languages-list');
            listEl.innerHTML = state.languages.map(lang => `
                 <div class="entity-item" data-id="${lang.id}" data-type="language">
                     <span class="entity-name">${lang.name} (${lang.code})</span>
                 </div>
            `).join('');

            languageSelector.innerHTML = state.languages.map(lang => `<option value="${lang.code}">${lang.name}</option>`).join('');
            languageSelector.value = state.activeLanguage;
        }
    }
    addLanguageBtn.addEventListener('click', async () => {
        const nameInput = document.getElementById('new-language-name');
        const codeInput = document.getElementById('new-language-code');
        const name = nameInput.value.trim();
        const code = codeInput.value.trim();
        if (name && code) {
            const result = await apiCall('add_language', { name, code });
            if (result.success) {
                nameInput.value = '';
                codeInput.value = '';
                loadLanguages();
            }
        }
    });

    document.getElementById('actions-nodes').addEventListener('click', e => {
        const target = e.target.closest('.action-btn[data-type]');
        if (target) {
            const type = target.dataset.type;
            if (['json', 'sheet'].includes(type)) {
                addSpecialNode(type);
            } else {
                openReferenceModal(type);
            }
        }
    });

    function openReferenceModal(type) {
        const titleEl = document.getElementById('reference-modal-title');
        const listEl = document.getElementById('reference-modal-list');
        let data = [];
        let title = `Select ${type.charAt(0).toUpperCase() + type.slice(1)}`;

        switch (type) {
            case 'conversation': data = state.conversations; break;
            case 'quest': data = state.quests; break;
            case 'character': data = state.characters; break;
            case 'world': data = state.worlds; break;
        }

        titleEl.textContent = title;
        listEl.innerHTML = data.map(item => `
            <div class="entity-item" data-id="${item.id}" data-name="${item.title || item.name}" data-type="${type}" style="border-left-color: ${item.color || '#1e88e5'};">
                <span class="entity-name">${item.title || item.name}</span>
                <span class="entity-id">ID: ${item.id}</span>
            </div>
        `).join('') || '<p>No items found.</p>';

        openModal(referenceModal);
    }

    document.getElementById('reference-modal-list').addEventListener('click', e => {
        const item = e.target.closest('.entity-item');
        if (item) {
            const { id, name, type } = item.dataset;
            addReferenceNode(type, id, name);
            closeModal(referenceModal);
        }
    });

    function addReferenceNode(type, referenceId, name) {
        if (!state.activeItem.id) return;
        const center = getCenterOfCanvas();
        const newNodeId = `node_${Date.now()}`;
        state.nodes[newNodeId] = {
            id: newNodeId,
            node_type: `${type}Ref`,
            reference_id: referenceId,
            speaker: name,
            x: center.x - 140,
            y: center.y - 50,
            world_id: null,
            character_id: null,
            next_node_id: null,
            displayLanguage: state.activeLanguage
        };
        const id_column = state.activeItem.type === 'conversation' ? 'conversation_id' : 'quest_id';
        state.nodes[newNodeId][id_column] = state.activeItem.id;
        const nodeEl = createNodeElement(state.nodes[newNodeId]);
        nodeLayer.appendChild(nodeEl);
        handleSelection('node', newNodeId);
    }

    function addSpecialNode(type) {
        if (!state.activeItem.id) return;
        const center = getCenterOfCanvas();
        const newNodeId = `node_${Date.now()}`;
        state.nodes[newNodeId] = {
            id: newNodeId,
            node_type: type,
            x: center.x - 140,
            y: center.y - 50,
            displayLanguage: state.activeLanguage
        };
        const id_column = state.activeItem.type === 'conversation' ? 'conversation_id' : 'quest_id';
        state.nodes[newNodeId][id_column] = state.activeItem.id;
        const nodeEl = createNodeElement(state.nodes[newNodeId]);
        nodeLayer.appendChild(nodeEl);
        handleSelection('node', newNodeId);
    }

    function getUpstreamNodes(startNodeId) {
        const nodesToInclude = new Set();
        const queue = [startNodeId];
        const visited = new Set();
        const incomingConnections = {};
        Object.values(state.nodes).forEach(node => {
            if (node.next_node_id) {
                if (!incomingConnections[node.next_node_id]) {
                    incomingConnections[node.next_node_id] = new Set();
                }
                incomingConnections[node.next_node_id].add(node.id);
            }
        });
        Object.values(state.choices).forEach(choice => {
            if (choice.next_node_id) {
                if (!incomingConnections[choice.next_node_id]) {
                    incomingConnections[choice.next_node_id] = new Set();
                }
                incomingConnections[choice.next_node_id].add(choice.node_id);
            }
        });

        while (queue.length > 0) {
            const currentNodeId = queue.shift();
            if (visited.has(currentNodeId)) continue;

            visited.add(currentNodeId);
            nodesToInclude.add(currentNodeId);

            const parents = incomingConnections[currentNodeId];
            if (parents) {
                parents.forEach(parentId => {
                    if (!visited.has(parentId)) {
                        queue.push(parentId);
                    }
                });
            }
        }
        return Array.from(nodesToInclude);
    }

    async function handleDownload(format, startNodeId) {
        if (!startNodeId) {
            updateStatus(`No node selected to start export from.`, true);
            return;
        }

        const nodeIdsToExport = getUpstreamNodes(startNodeId);

        if (nodeIdsToExport.length === 0) {
            updateStatus('No connected nodes found to export.', true);
            return;
        }

        if (format === 'json') {
            updateStatus(`Exporting ${nodeIdsToExport.length} nodes to JSON...`);
            const exportData = {
                nodes: {},
                choices: {},
                metadata: {
                    type: state.activeItem.type,
                    id: state.activeItem.id,
                    start_node_id: startNodeId
                }
            };
            nodeIdsToExport.forEach(nodeId => {
                const node = state.nodes[nodeId];
                if (node) {
                    const { displayLanguage, ...rest } = node;
                    exportData.nodes[nodeId] = rest;
                    Object.values(state.choices).filter(c => c.node_id === nodeId).forEach(choice => {
                        exportData.choices[choice.id] = choice;
                    });
                }
            });

            const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportData, null, 2));
            const downloadAnchorNode = document.createElement('a');
            downloadAnchorNode.setAttribute("href", dataStr);
            downloadAnchorNode.setAttribute("download", `export_${state.activeItem.type}_${state.activeItem.id}_${Date.now()}.json`);
            document.body.appendChild(downloadAnchorNode);
            downloadAnchorNode.click();
            downloadAnchorNode.remove();
            updateStatus('JSON export complete!');

        } else if (format === 'csv') {
             updateStatus(`Exporting ${nodeIdsToExport.length} nodes to CSV...`);
             const formData = new FormData();
             formData.append('action', 'export_to_csv');
             formData.append('node_ids', JSON.stringify(nodeIdsToExport));

             try {
                 const response = await fetch(API_URL, {
                     method: 'POST',
                     body: formData
                 });
                 if (!response.ok) {
                     const errorText = await response.text();
                     throw new Error(`Server responded with status: ${response.status} - ${errorText}`);
                 }
                 const blob = await response.blob();
                 const url = window.URL.createObjectURL(blob);
                 const a = document.createElement('a');
                 a.style.display = 'none';
                 a.href = url;
                 const disposition = response.headers.get('content-disposition');
                 let filename = 'export.csv';
                 if (disposition && disposition.indexOf('attachment') !== -1) {
                     const filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                     const matches = filenameRegex.exec(disposition);
                     if (matches != null && matches[1]) {
                         filename = matches[1].replace(/['"]/g, '');
                     }
                 }
                 a.download = filename;
                 document.body.appendChild(a);
                 a.click();
                 window.URL.revokeObjectURL(url);
                 a.remove();
                 updateStatus('CSV export complete!');
             } catch (error) {
                 console.error('Export failed:', error);
                 updateStatus(`Export failed: ${error.message}`, true);
             }
        }
    }

    let testerState = {};

    previewBtn.addEventListener('click', async () => {
        if (!state.activeItem.id || state.activeItem.type !== 'conversation') return;
        const conv = state.conversations.find(c => c.id == state.activeItem.id);
        if (!conv || !conv.start_node_id || !state.nodes[conv.start_node_id]) {
            updateStatus('Cannot test: No start node set.', true);
            return;
        }
        updateStatus('Loading tester...');
        const result = await apiCall('get_game_variables');
        if (result.success) {
            testerState.variables = result.data;
            testerState.currentNodeId = conv.start_node_id;
            testerState.history = JSON.parse(JSON.stringify(state));
            renderTester();
            openModal(testerModal);
        }
    });

    closeTesterBtn.addEventListener('click', () => closeModal(testerModal));

    function renderTester() {
        const node = testerState.history.nodes[testerState.currentNodeId];
        if (!node) {
            document.getElementById('tester-dialog').innerHTML = '<strong>--- END OF CONVERSATION ---</strong>';
            document.getElementById('tester-speaker').textContent = '';
            document.getElementById('tester-choices').innerHTML = '';
            return;
        }

        document.getElementById('tester-speaker').textContent = node.speaker;
        document.getElementById('tester-dialog').textContent = getTextForLanguage(node.dialog_text, state.activeLanguage);

        const choices = Object.values(testerState.history.choices).filter(c => c.node_id === testerState.currentNodeId);
        const choicesContainer = document.getElementById('tester-choices');
        choicesContainer.innerHTML = '';

        choices.forEach(choice => {
            const isVisible = checkConditions(choice.conditions);
            const btn = document.createElement('button');
            btn.className = 'tester-choice-btn';
            btn.textContent = getTextForLanguage(choice.choice_text, state.activeLanguage);
            btn.disabled = !isVisible;
            if (isVisible) btn.onclick = () => selectTestChoice(choice);
            choicesContainer.appendChild(btn);
        });

        const varList = document.getElementById('tester-variable-list');
        varList.innerHTML = Object.entries(testerState.variables).map(([name, value]) =>
            `<div class="variable-item"><span class="name">${name}:</span> <span class="value">${value}</span></div>`
        ).join('');
    }

    function checkConditions(conditions = []) {
        if (!conditions || conditions.length === 0) return true;
        return conditions.every(cond => {
            const varValue = testerState.variables[cond.variable_name];
            if (varValue === undefined) return false;
            const val1 = isNaN(Number(varValue)) ? varValue : Number(varValue);
            const val2 = isNaN(Number(cond.required_value)) ? cond.required_value : Number(cond.required_value);
            switch (cond.operator) {
                case '==': return val1 == val2;
                case '!=': return val1 != val2;
                case '>': return val1 > val2;
                case '<': return val1 < val2;
                case '>=': return val1 >= val2;
                case '<=': return val1 <= val2;
                default: return false;
            }
        });
    }

    function selectTestChoice(choice) {
        (choice.setters || []).forEach(setter => {
            const currentValue = Number(testerState.variables[setter.variable_name]) || 0;
            const aValue = Number(setter.value) || 0;
            switch (setter.operator) {
                case '=': testerState.variables[setter.variable_name] = setter.value; break;
                case '+=': testerState.variables[setter.variable_name] = currentValue + aValue; break;
                case '-=': testerState.variables[setter.variable_name] = currentValue - aValue; break;
            }
        });
        testerState.currentNodeId = choice.next_node_id;
        renderTester();
    }

    async function init() {
        updateStatus('Loading editor data...');
        updateButtonStates();
        updateCanvasTransform();
        await loadLanguages();
        await loadWorlds();
        await loadCharacters();
        await renderQuestsView();
        await renderConversationsView();
        switchView('conversations');
        updateStatus('Ready. Please select an item to edit.');
    }

    init();
});
