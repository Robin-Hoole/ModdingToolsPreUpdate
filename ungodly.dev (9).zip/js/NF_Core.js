/**
 * NF_Core.js
 * Core configuration, state variables, and base utilities.
 */

function generateUUID() {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
        return crypto.randomUUID();
    }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

function getRandomHex() {
    return '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
}

let sourceData = { dialogues: [], sequences: [], tasks: [], menus: [], prompts: [], importedLogic: [], importedGameplayValues: [] };
let storyNodes = [];
let flowGroups = [];
let idCounter = 1;
let flowPages = [{ id: 'default', name: 'Main Flow', emoji: '🔮', desc: 'Default flow canvas.' }];
let currentCanvasId = 'default';
let searchResults = [];
let searchIndex = -1;
let globalTaskTabColors = {};
let globalPromptTagColors = {};
let collapsedLeftGroups = new Set();
let collapsedMiddleGroups = new Set();
let editingGpKey = null; 

let toolingData = {
    transitionSections: [], transitions: [],
    imageNodeSections: [], imageNodes: [],
    imageDbSections: [], imageDbItems: [],
    convSeqSections: [], convSeqs: [],
    puppetSeqSections: [], puppetSeqs: []
};

let activeOverTab = 'nodes'; 
let activeToolCategory = 'trans'; 
let activeToolLogicTab = 'local'; 
let activeToolItemId = null;
let toolSearchResults = [];
let toolSearchIndex = -1;
let contextMenuSectionTarget = null;
let contextMenuSectionType = null;
let contextTargetItem = null; 
let contextTargetNodeId = null;
let inlineEditingId = null;

let spawnOffset = 0; 
let pendingSpawnAction = null; 

let startupValues = []; 
let gameEndValues = [];
let gameplayValues = Object.create(null);
gameplayValues["Trust == 1"] = "#ff007b";
gameplayValues["Friendship == 1"] = "#00ff88";
gameplayValues["Suspicion == 1"] = "#ff8c00";
gameplayValues["Lust == 1"] = "#b026ff";

let projectLogic = Object.create(null);

let nfAvailableLanguages = ['ENG'];
let nfCurrentLanguage = 'ENG';
let nfAddingLanguage = false;

function nfNormalizeLanguageCode(value) {
    const code = String(value || '').trim().toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3);
    return code || 'ENG';
}

function nfToggleToolItemCollapseById(itemId, ev) {
    const card = document.getElementById('tool-card-' + itemId);
    return nfSetToolItemCollapsed(itemId, card ? !card.classList.contains('is-collapsed') : true, ev);
}

function nfSetToolItemCollapsed(itemId, shouldCollapse, ev) {
    if (ev) {
        ev.preventDefault();
        ev.stopPropagation();
    }
    const card = document.getElementById('tool-card-' + itemId);
    if (!shouldCollapse) document.body.classList.remove('nf-tools-deep-collapsed');
    console.info('[NarrativeFlow Collapse] set panel collapsed state', { itemId, shouldCollapse: !!shouldCollapse, found: !!card, source: 'core fallback' });
    if (!card) return false;
    card.classList.toggle('is-collapsed', !!shouldCollapse);
    if (typeof updateCardGlow === 'function') updateCardGlow(itemId);
    return false;
}

function nfDeepCollapseAllFromButton(shouldCollapse, ev) {
    if (ev) {
        ev.preventDefault();
        ev.stopPropagation();
    }
    const cards = document.querySelectorAll('.tool-card');
    document.body.classList.toggle('nf-tools-deep-collapsed', !!shouldCollapse);
    cards.forEach(card => {
        card.classList.toggle('is-collapsed', !!shouldCollapse);
        const itemId = String(card.id || '').replace(/^tool-card-/, '');
        if (itemId && typeof updateCardGlow === 'function') updateCardGlow(itemId);
    });
    console.info('[NarrativeFlow Collapse] global toggle', { shouldCollapse: !!shouldCollapse, cardCount: cards.length });
    return false;
}

async function nfCopyPanelId(text, btn) {
    const value = String(text || '').trim();
    console.info('[NarrativeFlow Copy] panel id copy requested', { value });
    if (!value) return false;
    try {
        await navigator.clipboard.writeText(value);
        if (btn) {
            const old = btn.innerHTML;
            btn.textContent = 'OK';
            setTimeout(() => { btn.innerHTML = old; }, 700);
        }
    } catch (err) {
        console.warn('[NarrativeFlow Copy] clipboard failed', err);
    }
    return false;
}

let leftTab = 'trans'; 
let rightTab = 'inspector';
let selectedNodeIds = [];
let scale = 1, panX = 0, panY = 0;
let isDraggingNode = false, isPanning = false, isLinking = false;
let isDraggingGroup = false, isResizingGroup = false;
let dragTarget = null, linkSourceId = null, activeGroupTarget = null;
let lastMousePos = { x: 0, y: 0 };
let spacePressed = false;
let connectionPaths = [];
let isDraggingZoom = false;
let zoomStartX = 0;
let zoomStartScale = 1;
let zoomMoved = false;

let container, bgLayer, nodeLayer, groupLayer, canvas, ctx, tooltip, zoomLevelEl;
const OPERATORS = ["==", ">=", "<=", "+", "-", "!="];

window.addEventListener('DOMContentLoaded', () => {
    // Force CSS Flexbox to allow scrolling by capping minimum height overrides natively
    const style = document.createElement('style');
    style.innerHTML = `
        .flex-1 { min-height: 0 !important; min-width: 0 !important; }
        .scrollable { overflow-y: auto !important; min-height: 0 !important; flex: 1 1 0% !important; }
        aside.panel { min-height: 0 !important; }
        #left-tools-view, #right-tools-view, #left-nodes-view, #right-nodes-view, #middle-tools-view { min-height: 0 !important; }
    `;
    document.head.appendChild(style);

    container = document.getElementById('canvas-area');
    bgLayer = document.getElementById('bg-layer');
    nodeLayer = document.getElementById('node-layer');
    groupLayer = document.getElementById('group-layer');
    canvas = document.getElementById('connections-canvas');
    ctx = canvas.getContext('2d');
    tooltip = document.getElementById('tooltip');
    zoomLevelEl = document.getElementById('zoom-level');

    // Create Context Menu for Node Sources (Left Panel)
    const nsMenu = document.createElement('div');
    nsMenu.id = 'node-source-context-menu';
    nsMenu.className = 'custom-context-menu hidden absolute bg-[#1a1a20] border border-[var(--accent-pink)] py-1 shadow-lg z-[2000] text-white font-bold text-xs cursor-pointer flex flex-col min-w-[120px]';
    nsMenu.innerHTML = `
        <div class="px-4 py-2 hover:bg-[var(--accent-teal)] hover:text-black" onclick="renameNodeSource()">Rename</div>
        <div class="px-4 py-2 hover:bg-[var(--accent-teal)] hover:text-black" onclick="duplicateNodeSource()">Duplicate</div>
        <div class="px-4 py-2 hover:bg-[var(--accent-pink)] text-[var(--accent-pink)] hover:text-white" onclick="deleteNodeSource()">Delete</div>
        <div class="border-t border-[#333] my-1"></div>
        <div class="px-4 py-2 text-dim hover:bg-[#333] hover:text-white" onclick="closeContextMenus()">Cancel</div>
    `;
    document.body.appendChild(nsMenu);

    // Overwrite the hardcoded Canvas Node Context Menu to match
    const nodeMenu = document.getElementById('node-context-menu');
    if (nodeMenu) {
        nodeMenu.classList.add('custom-context-menu', 'py-1', 'flex', 'flex-col', 'min-w-[120px]');
        nodeMenu.classList.remove('p-2');
        nodeMenu.innerHTML = `
            <div class="px-4 py-2 hover:bg-[var(--accent-teal)] hover:text-black" onclick="renameContextNode()">Rename Node</div>
            <div class="px-4 py-2 hover:bg-[var(--accent-teal)] hover:text-black" onclick="duplicateContextNode()">Duplicate Node</div>
            <div class="px-4 py-2 hover:bg-[var(--accent-pink)] text-[var(--accent-pink)] hover:text-white" onclick="deleteContextNode()">Delete Node</div>
            <div class="border-t border-[#333] my-1"></div>
            <div class="px-4 py-2 text-dim hover:bg-[#333] hover:text-white" onclick="closeContextMenus()">Cancel</div>
        `;
    }

    // Overwrite Tool Section Menu to include Rename
    const tsMenu = document.getElementById('tool-section-context-menu');
    if (tsMenu) {
        tsMenu.classList.add('custom-context-menu');
        tsMenu.innerHTML = `
            <div class="px-4 py-2 hover:bg-[var(--accent-teal)] hover:text-black" onclick="triggerRenameToolSection()">Rename Section</div>
            <div class="px-4 py-2 hover:bg-[var(--accent-teal)] hover:text-black" onclick="duplicateToolSection()">Duplicate</div>
            <div class="px-4 py-2 hover:bg-[var(--accent-pink)] text-[var(--accent-pink)] hover:text-white" onclick="deleteToolSection()">Delete Section</div>
            <div class="border-t border-[#333] my-1"></div>
            <div class="px-4 py-2 text-dim hover:bg-[#333] hover:text-white" onclick="closeContextMenus()">Cancel</div>
        `;
    }
    
    document.getElementById('sidebar-context-menu')?.classList.add('custom-context-menu');

    // Tooltips
    document.addEventListener('mousemove', (e) => {
        const tag = e.target.closest('.logic-tag');
        if (tag) {
            const key = tag.dataset.key;
            const logic = projectLogic[key] || getLocalToolLogic()[key];
            if(logic) {
                tooltip.innerHTML = `<b>${escapeHtml(key)}</b>${getTooltipDesc(key, logic)}`;
                tooltip.style.left = (e.clientX + 15) + 'px';
                tooltip.style.top = (e.clientY + 15) + 'px';
                tooltip.classList.add('show');
            }
        } else {
            tooltip.classList.remove('show');
        }
    });

    zoomLevelEl.addEventListener('mousedown', (e) => {
        isDraggingZoom = true; zoomMoved = false; zoomStartX = e.clientX; zoomStartScale = scale;
        e.stopPropagation(); e.preventDefault();
    });

    window.addEventListener('keydown', e => { 
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return;
        if(e.code === 'Space') spacePressed = true; 
        
        if (activeOverTab === 'nodes') {
            if((e.code === 'Delete' || e.code === 'Backspace') && selectedNodeIds.length > 0) deleteSelectedNodes();

            if (e.code === 'KeyF' && selectedNodeIds.length === 1) {
                e.preventDefault();
                const current = storyNodes.find(n => n.id === selectedNodeIds[0]);
                if (current) {
                    const el = document.querySelector(`.story-node[data-id="${current.id}"]`);
                    const sW = el ? el.offsetWidth : 240; 
                    const sH = el ? el.offsetHeight : 90;
                    const cX = (container.clientWidth / 2) - ((current.x + sW / 2) * scale);
                    const cY = (container.clientHeight / 2) - ((current.y + sH / 2) * scale);

                    if (Math.abs(panX - cX) < 10 && Math.abs(panY - cY) < 10 && scale >= 1.0) {
                        scale = 0.5;
                        panX = (container.clientWidth / 2) - ((current.x + sW / 2) * scale);
                        panY = (container.clientHeight / 2) - ((current.y + sH / 2) * scale);
                    } else {
                        scale = 1.0; 
                        panX = (container.clientWidth / 2) - ((current.x + sW / 2) * scale);
                        panY = (container.clientHeight / 2) - ((current.y + sH / 2) * scale);
                    }
                    updateTransform();
                }
            }

            if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code) && selectedNodeIds.length === 1) {
                e.preventDefault(); const current = storyNodes.find(n => n.id === selectedNodeIds[0]); if (!current) return;
                let bestNode = null; let minScore = Infinity;
                storyNodes.filter(n => n.canvasId === currentCanvasId).forEach(n => {
                    if (n.id === current.id) return;
                    const dx = n.x - current.x; const dy = n.y - current.y; const dist = Math.hypot(dx, dy);
                    let valid = false; let angleWeight = 0; 
                    if (e.code === 'ArrowRight' && dx > 0 && dx > Math.abs(dy)) { valid = true; angleWeight = Math.abs(dy/dx); }
                    if (e.code === 'ArrowLeft' && dx < 0 && -dx > Math.abs(dy)) { valid = true; angleWeight = Math.abs(dy/dx); }
                    if (e.code === 'ArrowDown' && dy > 0 && dy > Math.abs(dx)) { valid = true; angleWeight = Math.abs(dx/dy); }
                    if (e.code === 'ArrowUp' && dy < 0 && -dy > Math.abs(dx)) { valid = true; angleWeight = Math.abs(dx/dy); }
                    if (valid) { const score = dist + (dist * angleWeight * 2); if (score < minScore) { minScore = score; bestNode = n; } }
                });
                if (bestNode) jumpToNode(bestNode.id);
            }
        } else if (activeOverTab === 'tools') {
            if (e.code === 'ArrowLeft') { setToolCategory(activeToolCategory === 'imgdb' ? 'imgnode' : (activeToolCategory === 'imgnode' ? 'trans' : 'trans')); }
            if (e.code === 'ArrowRight') { setToolCategory(activeToolCategory === 'trans' ? 'imgnode' : (activeToolCategory === 'imgnode' ? 'imgdb' : 'imgdb')); }
            
            if (['ArrowUp', 'ArrowDown'].includes(e.code)) {
                e.preventDefault();
                let arr = getActiveToolArray();
                if(arr.length === 0) return;
                let idx = arr.findIndex(i => i.id === activeToolItemId);
                if(idx === -1) idx = 0;
                else {
                    if(e.code === 'ArrowUp') idx = Math.max(0, idx - 1);
                    if(e.code === 'ArrowDown') idx = Math.min(arr.length - 1, idx + 1);
                }
                scrollToToolCard(arr[idx].id);
            }

            if (['Home', 'End', 'PageUp', 'PageDown'].includes(e.code)) {
                e.preventDefault();
                const scrollable = document.getElementById('middle-tools-view');
                if(!scrollable) return;
                const top = scrollable.scrollTop;
                if(e.code === 'Home') scrollable.scrollTop = 0;
                if(e.code === 'End') scrollable.scrollTop = scrollable.scrollHeight;
                if(e.code === 'PageUp') scrollable.scrollTop = Math.max(0, top - 800);
                if(e.code === 'PageDown') scrollable.scrollTop = top + 800;
            }
        }
    });

    window.addEventListener('keyup', e => { if(e.code === 'Space') spacePressed = false; });
    
    container.addEventListener('wheel', e => {
        if (activeOverTab !== 'nodes') return;
        e.preventDefault(); const oldScale = scale; scale = Math.min(Math.max(0.1, scale - e.deltaY * 0.001), 2.0);
        const rect = container.getBoundingClientRect(); const mouseX = e.clientX - rect.left, mouseY = e.clientY - rect.top;
        panX = mouseX - (mouseX - panX) * (scale / oldScale); panY = mouseY - (mouseY - panY) * (scale / oldScale);
        updateTransform();
    }, { passive: false });

    container.addEventListener('mousedown', e => {
        if (activeOverTab !== 'nodes') return;
        lastMousePos = { x: e.clientX, y: e.clientY }; spawnOffset = 0;
        if (e.target.classList.contains('workspace-bg') || spacePressed || e.button === 1) {
            if (!e.shiftKey && e.target.classList.contains('workspace-bg')) { selectedNodeIds = []; renderNodes(); if(rightTab === 'inspector') renderInspector(); }
            if (e.button !== 2) isPanning = true; e.preventDefault();
        }
    });

    window.addEventListener('mousemove', e => {
        if (activeOverTab !== 'nodes') return;
        const dx = e.clientX - lastMousePos.x, dy = e.clientY - lastMousePos.y; lastMousePos = { x: e.clientX, y: e.clientY };
        if (isDraggingZoom) {
            if (Math.abs(e.clientX - zoomStartX) > 3) {
                zoomMoved = true; const dScale = (e.clientX - zoomStartX) * 0.01; scale = Math.min(Math.max(0.1, zoomStartScale + dScale), 2.0);
                updateTransform();
            } return;
        }
        if (isPanning) { panX += dx; panY += dy; updateTransform(); }
        if (isDraggingNode && dragTarget) {
            const toMove = [...selectedNodeIds];
            if (selectedNodeIds.includes(dragTarget)) {
                let c = storyNodes.find(n => n.id === dragTarget);
                while(c && c.snapChild) { toMove.push(c.snapChild); c = storyNodes.find(n => n.id === c.snapChild); }
            }
            Array.from(new Set(toMove)).forEach(id => { const node = storyNodes.find(n => n.id === id); if (node) { node.x += dx / scale; node.y += dy / scale; } });
            renderNodes();
        }
        if (isDraggingGroup && activeGroupTarget) { const group = flowGroups.find(g => g.id === activeGroupTarget); if (group) { group.x += dx / scale; group.y += dy / scale; renderNodes(); } }
        if (isResizingGroup && activeGroupTarget) { const group = flowGroups.find(g => g.id === activeGroupTarget); if (group) { group.width = Math.max(150, group.width + (dx / scale)); group.height = Math.max(100, group.height + (dy / scale)); renderNodes(); } }
        if (isLinking) requestAnimationFrame(() => drawConnections());
    });

    window.addEventListener('mouseup', e => {
        if (activeOverTab !== 'nodes') return;
        if (isDraggingZoom) {
            isDraggingZoom = false;
            if (!zoomMoved) { 
                scale = Math.round((scale + 0.1) * 10) / 10; 
                if (scale > 2.0) scale = 0.1; 
                if (scale > 1.0 && scale < 1.1) scale = 0.1; 
                updateTransform(); 
            }
        }
        if (isDraggingNode && dragTarget) {
            const draggedNode = storyNodes.find(n => n.id === dragTarget);
            if (draggedNode && draggedNode.type === 'menu' && !draggedNode.snapParent) {
                let snapped = false;
                const possibleTargets = storyNodes.filter(n => n.canvasId === currentCanvasId && n.type === 'menu' && n.id !== draggedNode.id && !n.snapChild);
                for (let target of possibleTargets) {
                    let targetEl = document.querySelector(`.story-node[data-id="${target.id}"]`);
                    let targetBottom = target.y + (targetEl ? targetEl.offsetHeight : 50);
                    const dy = draggedNode.y - targetBottom; const dx = Math.abs(draggedNode.x - target.x);
                    if (dx < 80 && Math.abs(dy) < 60) {
                        let count = 1; let p = target; while(p.snapParent) { count++; p = storyNodes.find(x => x.id === p.snapParent); }
                        let c = draggedNode; while(c.snapChild) { count++; c = storyNodes.find(x => x.id === c.snapChild); }
                        if (count <= 5) { target.snapChild = draggedNode.id; draggedNode.snapParent = target.id; snapped = true; break; } 
                        else { showNotification("Menu stacks limited to 5 options max.", true); }
                    }
                }
                if (snapped) renderNodes();
            }
        }
        isPanning = false; isDraggingNode = false; isDraggingGroup = false; isResizingGroup = false; activeGroupTarget = null;
        if (isLinking) {
            const targetPort = e.target.closest('.port.in');
            if (targetPort) {
                const targetId = targetPort.dataset.nodeid;
                const src = storyNodes.find(n => n.id === linkSourceId && n.canvasId === currentCanvasId);
                if (src && targetId !== linkSourceId && !src.nextConversations.includes(targetId)) {
                    src.nextConversations.push(targetId);
                }
            }
            isLinking = false; linkSourceId = null;
            requestAnimationFrame(() => drawConnections());
        }
    });

    container.addEventListener('contextmenu', e => {
        if (activeOverTab !== 'nodes') return;
        e.preventDefault();
        if (e.target.closest('.story-node') || e.target.closest('.logic-tag')) return;
        const dpr = window.devicePixelRatio || 1; const rect = canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) * dpr; const y = (e.clientY - rect.top) * dpr;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.translate(panX, panY); ctx.scale(scale, scale); ctx.lineWidth = 20 / scale;
        let broken = false;
        for (let i = connectionPaths.length - 1; i >= 0; i--) {
            if (ctx.isPointInStroke(connectionPaths[i].path, x, y)) {
                const src = storyNodes.find(n => n.id === connectionPaths[i].srcId);
                if (src) {
                    src.nextConversations = src.nextConversations.filter(id => id !== connectionPaths[i].dstId);
                    broken = true; showNotification("Connection Broken", true); break;
                }
            }
        }
        if (broken) requestAnimationFrame(() => drawConnections());
    });
    
    // Close context menus when clicking anywhere else
    window.addEventListener('mousedown', (e) => {
        if(!e.target.closest('.custom-context-menu')) closeContextMenus();
    });

    window.addEventListener('resize', resizeCanvas);
    renderFlowPages(); resizeCanvas(); updateTransform(); if (typeof nfRenderLanguageControls === 'function') nfRenderLanguageControls();
});

function showNotification(text, isError = false) {
    const notif = document.getElementById('notification');
    if(!notif) return;
    notif.innerText = text;
    notif.style.background = isError ? 'var(--accent-pink)' : 'var(--accent-teal)';
    notif.classList.add('show');
    setTimeout(() => notif.classList.remove('show'), 3000);
}

function escapeHtml(text) {
    if (!text) return '';
    return String(text)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function getRandomColor() {
    const letters = '6789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) color += letters[Math.floor(Math.random() * letters.length)];
    return color;
}

function getRandomSaturatedHex() {
    const colors = ['#ff0055', '#00ffaa', '#00aaff', '#ffaa00', '#aa00ff', '#ff00aa', '#aaff00', '#00ff55', '#5500ff', '#ff5500', '#0055ff', '#55ff00'];
    return colors[Math.floor(Math.random() * colors.length)];
}

function normalizeStatement(key, op, val) {
    if (!key) return null;
    key = String(key).trim();
    if ((val === undefined || val === null || val === '') && !op) return key; 
    let nOp = op ? String(op).trim() : '==';
    if (nOp === '=') nOp = '==';
    let nVal = (val !== undefined && val !== null) ? String(val).trim() : '';
    if (!nVal && nOp === '==') return key; 
    return `${key} ${nOp} ${nVal}`.trim();
}

function getToolArrays(type) {
    if(type === 'trans') return { sec: toolingData.transitionSections, items: toolingData.transitions };
    if(type === 'imgnode') return { sec: toolingData.imageNodeSections, items: toolingData.imageNodes };
    if(type === 'imgdb') return { sec: toolingData.imageDbSections, items: toolingData.imageDbItems };
    if(type === 'convseq') return { sec: toolingData.convSeqSections, items: toolingData.convSeqs };
    if(type === 'puppetseq') return { sec: toolingData.puppetSeqSections, items: toolingData.puppetSeqs };
    return {sec:[], items:[]};
}

function getArrayForItemId(id) {
    if (toolingData.transitions.some(i => i.id === id)) return toolingData.transitions;
    if (toolingData.imageNodes.some(i => i.id === id)) return toolingData.imageNodes;
    if (toolingData.imageDbItems.some(i => i.id === id)) return toolingData.imageDbItems;
    if (toolingData.convSeqs.some(i => i.id === id)) return toolingData.convSeqs;
    if (toolingData.puppetSeqs.some(i => i.id === id)) return toolingData.puppetSeqs;
    return [];
}

function getActiveToolArray() {
    return getToolArrays(activeToolCategory).items;
}

function closeContextMenus() { 
    document.querySelectorAll('.custom-context-menu').forEach(el => el.classList.add('hidden')); 
    contextTargetItem = null;
    contextTargetNodeId = null;
    contextMenuSectionTarget = null;
    contextMenuSectionType = null;
}
