const API_URL = 'jobs_list_api.php';
let appData = [];

document.addEventListener('DOMContentLoaded', () => {
    initParticles();
    fetchData();

    // Mobile Navigation
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    
    const toggleSidebar = () => {
        sidebar.classList.toggle('open');
        document.body.classList.toggle('sidebar-open');
    };

    document.getElementById('menu-toggle').addEventListener('click', toggleSidebar);
    document.getElementById('close-sidebar').addEventListener('click', toggleSidebar);
    overlay.addEventListener('click', toggleSidebar);

    // Global Event Listeners
    document.getElementById('add-hub-btn').addEventListener('click', createNewHub);
    document.getElementById('refresh-btn').addEventListener('click', fetchData);
    document.getElementById('search-input').addEventListener('input', handleSearch);

    // Export & Import
    document.getElementById('export-btn').addEventListener('click', exportData);
    document.getElementById('import-btn').addEventListener('click', () => {
        document.getElementById('import-input').click();
    });
    document.getElementById('import-input').addEventListener('change', importData);

    // Global Gallery Upload
    const galleryUploadBtn = document.getElementById('gallery-upload-btn');
    const galleryFileInput = document.getElementById('gallery-file-input');
    galleryUploadBtn.addEventListener('click', () => galleryFileInput.click());
    galleryFileInput.addEventListener('change', handleGlobalUpload);
});

// --- CORE DATA OPERATIONS ---

async function fetchData() {
    updateSidebar('Loading Data...');
    try {
        const res = await fetch(`${API_URL}?action=get_jobs`);
        const data = await res.json();
        
        if (data.status === 'error') {
            showNotification(data.message, 'error');
        } else {
            appData = data;
            renderApp();
            renderSidebar();
            renderGlobalGallery();
        }
    } catch (e) {
        showNotification('Network Error', 'error');
    }
}

async function saveJob(jobData, cardElement = null) {
    let collectedData;
    if (cardElement) {
        collectedData = scrapeCardData(cardElement);
        collectedData.id = jobData.id;
        collectedData.parent_id = jobData.parent_id;
    } else {
        collectedData = jobData;
    }

    try {
        const res = await fetch(`${API_URL}?action=save`, {
            method: 'POST',
            body: JSON.stringify(collectedData)
        });
        const result = await res.json();
        
        if (result.status === 'success') {
            if (cardElement) showNotification('Sync Complete');
            return result.id;
        } else {
            if (cardElement) showNotification(result.message || 'Error', 'error');
            return null;
        }
    } catch (e) {
        if (cardElement) showNotification('Save Failed', 'error');
        return null;
    }
}

// --- GALLERY MANAGEMENT ---

function renderGlobalGallery() {
    const grid = document.getElementById('global-gallery-grid');
    grid.innerHTML = '';
    
    const allImages = [];
    appData.forEach(hub => {
        (hub.images || []).forEach(img => {
            allImages.push({ ...img, source: hub.title, parentObj: hub });
        });
        (hub.children || []).forEach(child => {
            (child.images || []).forEach(img => {
                allImages.push({ ...img, source: `${hub.title} / ${child.title}`, parentObj: child });
            });
        });
    });

    if (allImages.length === 0) {
        grid.innerHTML = '<p style="color:var(--text-muted); padding:20px; font-family:var(--font-tech);">EMPTY ASSET BUFFER</p>';
        return;
    }

    allImages.forEach(img => {
        const container = createImageThumb(img.image_data);
        const tag = document.createElement('div');
        tag.className = 'image-source-tag';
        tag.textContent = img.source;
        container.appendChild(tag);
        
        container.querySelector('.del-image').addEventListener('click', async (e) => {
            e.stopPropagation();
            if(!confirm(`Remove asset from "${img.source}"?`)) return;
            img.parentObj.images = img.parentObj.images.filter(i => i.image_data !== img.image_data);
            const success = await saveJob(img.parentObj);
            if(success) {
                showNotification('Asset Purged');
                fetchData();
            }
        });
        grid.appendChild(container);
    });
}

async function handleGlobalUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    let targetHub = appData.find(h => h.title === 'Global Assets');
    const reader = new FileReader();
    reader.onload = async (re) => {
        const base64 = re.target.result;
        if (!targetHub) {
            await saveJob({
                title: 'Global Assets',
                images: [{image_data: base64}]
            });
            showNotification('New Global Assets Hub Created');
        } else {
            targetHub.images.push({image_data: base64});
            await saveJob(targetHub);
            showNotification('Uploaded to Global Assets');
        }
        fetchData();
    };
    reader.readAsDataURL(file);
    e.target.value = '';
}

// --- RENDERING ---

function renderApp() {
    const container = document.getElementById('resources-wrapper');
    container.innerHTML = '';
    appData.forEach((hub, index) => {
        container.appendChild(createHubElement(hub, index));
    });
}

function createHubElement(hub, index) {
    const div = document.createElement('div');
    div.className = 'hub-card';
    div.dataset.order = index;
    div.id = `hub-${hub.id}`;
    
    div.innerHTML = `
        <div class="hub-header">
            <div>
                <span style="font-size:0.7rem; color:var(--neon-teal); font-family:var(--font-tech)">HUB_${hub.id || 'NEW'}</span>
                <h3>${hub.title || 'New Company'}</h3>
            </div>
            <i class="fas fa-chevron-down" style="color:var(--text-muted)"></i>
        </div>
        <div class="hub-body">
            <div class="hub-form-container"></div>
            <div class="child-container" style="margin-top:30px; border-top:1px dashed #333; padding-top:20px;">
                <h4 style="font-size:0.8rem; color:var(--neon-orange); margin-bottom:15px; font-family:var(--font-tech)"><i class="fas fa-list"></i> JOB LISTINGS</h4>
                <div class="children-list"></div>
                <button class="glow-btn secondary add-child-btn" style="width:100%; justify-content:center; margin-top:10px;">
                    <i class="fas fa-plus"></i> ADD POSITION
                </button>
            </div>
        </div>
    `;

    const formContainer = div.querySelector('.hub-form-container');
    formContainer.appendChild(createFormHTML(hub, 'hub'));

    const childList = div.querySelector('.children-list');
    (hub.children || []).forEach((child, cIndex) => {
        childList.appendChild(createChildElement(child, cIndex, hub.id));
    });

    div.querySelector('.hub-header').addEventListener('click', () => {
        div.querySelector('.hub-body').classList.toggle('open');
    });

    div.querySelector('.add-child-btn').addEventListener('click', () => {
        const newChild = { id: null, parent_id: hub.id, title: '', contacts: [], websites: [], notes: [], images: [] };
        childList.appendChild(createChildElement(newChild, 999, hub.id));
    });

    formContainer.querySelector('.save-btn').addEventListener('click', () => saveJob(hub, div));
    if(hub.id) formContainer.querySelector('.delete-btn').addEventListener('click', () => deleteJob(hub.id));

    return div;
}

function createChildElement(child, index, parentId) {
    const div = document.createElement('div');
    div.className = 'child-card';
    div.style.background = 'rgba(255,255,255,0.02)';
    div.style.padding = '15px';
    div.style.borderRadius = '6px';
    div.style.marginBottom = '15px';
    div.style.borderLeft = '2px solid var(--neon-orange)';
    
    div.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
            <strong style="font-size:0.9rem; font-family:var(--font-tech)">${child.title || 'Listing Detail'}</strong>
            <button class="icon-btn delete-child-btn" style="color:var(--text-muted); font-size:1rem;"><i class="fas fa-trash"></i></button>
        </div>
        <div class="child-form-container"></div>
    `;

    const formContainer = div.querySelector('.child-form-container');
    formContainer.appendChild(createFormHTML(child, 'child'));

    formContainer.querySelector('.save-btn').addEventListener('click', () => saveJob(child, div));
    div.querySelector('.delete-child-btn').addEventListener('click', () => {
        if(child.id) deleteJob(child.id);
        else div.remove();
    });

    return div;
}

function createFormHTML(data, type) {
    const container = document.createElement('div');
    container.innerHTML = `
        <div class="form-grid">
            <div class="full-width">
                <label>POSITION / COMPANY</label>
                <input type="text" class="input-title" value="${data.title || ''}">
            </div>
            <div class="full-width">
                <label>HIRING CONTACT</label>
                <input type="text" class="input-manager" value="${data.hiring_manager_name || ''}">
            </div>
            <div class="full-width">
                <label>LOCATION</label>
                <input type="text" class="input-address" value="${data.address || ''}">
            </div>
            <div>
                <label>FOLLOW UP DATE</label>
                <input type="date" class="input-date" value="${data.last_follow_up_date || ''}">
            </div>
            <div class="checkbox-group" style="display:flex; gap:15px; align-items:flex-end; padding-bottom:5px;">
                <label style="margin:0"><input type="checkbox" class="input-applied" ${data.applied ? 'checked' : ''}> APPLIED</label>
                <label style="margin:0"><input type="checkbox" class="input-followup" ${data.follow_up ? 'checked' : ''}> FOLLOW-UP</label>
            </div>
        </div>
        <div class="sections-container"></div>
        <div style="margin-top:25px; display:flex; gap:10px; flex-direction:column;">
            <button class="glow-btn primary save-btn" style="width:100%; justify-content:center;"><i class="fas fa-save"></i> SYNC ${type.toUpperCase()}</button>
            ${type === 'hub' && data.id ? `<button class="glow-btn danger delete-btn" style="width:100%; justify-content:center;"><i class="fas fa-trash"></i> PURGE HUB</button>` : ''}
        </div>
    `;

    const sections = container.querySelector('.sections-container');
    
    const addSection = (title, key, icon, isTextarea = false) => {
        const sec = document.createElement('div');
        sec.className = 'dynamic-section';
        sec.dataset.key = key;
        sec.innerHTML = `
            <label style="color:var(--neon-teal); margin-bottom:10px;"><i class="fas ${icon}"></i> ${title}</label>
            <div class="list-container"></div>
            <div style="display:flex; gap:5px; margin-top:10px;">
                ${isTextarea ? `<textarea placeholder="..." style="height:50px; flex-grow:1;"></textarea>` : `<input type="text" placeholder="..." style="flex-grow:1;">`}
                <button class="glow-btn primary add-row-btn" style="padding:0 15px;"><i class="fas fa-plus"></i></button>
            </div>
        `;

        const list = sec.querySelector('.list-container');
        const items = (data[key] || []);
        
        items.forEach(item => {
            const val = item.value || item.url || item.note;
            list.appendChild(createDynamicRow(val, isTextarea ? 'textarea' : 'text'));
        });

        sec.querySelector('.add-row-btn').addEventListener('click', () => {
            const input = sec.querySelector('input, textarea');
            if(!input.value) return;
            list.appendChild(createDynamicRow(input.value, isTextarea ? 'textarea' : 'text'));
            input.value = '';
        });

        sections.appendChild(sec);
    };

    const addPhotoSection = () => {
        const sec = document.createElement('div');
        sec.className = 'dynamic-section photo-section';
        sec.dataset.key = 'images';
        sec.innerHTML = `
            <label style="color:var(--neon-teal)"><i class="fas fa-image"></i> GALLERY / SCREENSHOTS</label>
            <div class="image-grid"></div>
            <button class="glow-btn secondary upload-trigger" style="margin-top:10px; width:100%; justify-content:center;">
                <i class="fas fa-upload"></i> UPLOAD ASSET
            </button>
            <input type="file" class="hidden-file-input" accept="image/*" style="display:none;">
        `;

        const grid = sec.querySelector('.image-grid');
        (data.images || []).forEach(img => grid.appendChild(createImageThumb(img.image_data)));

        sec.querySelector('.upload-trigger').addEventListener('click', () => sec.querySelector('.hidden-file-input').click());
        sec.querySelector('.hidden-file-input').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = (re) => {
                grid.appendChild(createImageThumb(re.target.result));
            };
            reader.readAsDataURL(file);
        });

        sections.appendChild(sec);
    };

    addSection('Phones', 'contacts', 'fa-phone', false);
    addSection('Emails', 'contacts', 'fa-envelope', false);
    addSection('Links', 'websites', 'fa-link', false);
    addSection('Notes', 'notes', 'fa-sticky-note', true);
    addPhotoSection();

    return container;
}

function createImageThumb(base64) {
    const div = document.createElement('div');
    div.className = 'image-thumb-container';
    div.innerHTML = `
        <img src="${base64}">
        <button class="icon-btn del-image"><i class="fas fa-trash"></i></button>
    `;
    div.querySelector('.del-image').addEventListener('click', () => div.remove());
    return div;
}

function createDynamicRow(value, type) {
    const div = document.createElement('div');
    div.className = 'dynamic-row';
    div.innerHTML = `
        ${type === 'textarea' ? `<textarea>${value}</textarea>` : `<input type="text" value="${value}">`}
        <button class="icon-btn del-row"><i class="fas fa-times"></i></button>
    `;
    div.querySelector('.del-row').addEventListener('click', () => div.remove());
    return div;
}

function scrapeCardData(card) {
    const sections = card.querySelectorAll('.dynamic-section');
    return {
        title: card.querySelector('.input-title').value,
        hiring_manager_name: card.querySelector('.input-manager').value,
        address: card.querySelector('.input-address').value,
        applied: card.querySelector('.input-applied').checked,
        follow_up: card.querySelector('.input-followup').checked,
        last_follow_up_date: card.querySelector('.input-date').value,
        contacts: [
             ...Array.from(sections).filter(s => s.innerHTML.includes('Phones')).flatMap(s => Array.from(s.querySelectorAll('.dynamic-row input')).map(i => ({type: 'phone', value: i.value}))),
             ...Array.from(sections).filter(s => s.innerHTML.includes('Emails')).flatMap(s => Array.from(s.querySelectorAll('.dynamic-row input')).map(i => ({type: 'email', value: i.value})))
        ],
        websites: Array.from(sections).filter(s => s.innerHTML.includes('Links')).flatMap(s => Array.from(s.querySelectorAll('.dynamic-row input')).map(i => ({url: i.value}))),
        notes: Array.from(sections).filter(s => s.innerHTML.includes('Notes')).flatMap(s => Array.from(s.querySelectorAll('.dynamic-row textarea')).map(i => ({note: i.value}))),
        images: Array.from(sections).filter(s => s.classList.contains('photo-section')).flatMap(s => Array.from(s.querySelectorAll('.image-thumb-container img')).map(img => ({image_data: img.src})))
    };
}

// --- UI HELPERS ---

function renderSidebar() {
    const list = document.getElementById('sidebar-list');
    list.innerHTML = '';
    appData.forEach((hub) => {
        const li = document.createElement('li');
        li.className = 'sb-item';
        li.innerHTML = `<div class="sb-title">${hub.title || 'Untitled'}</div><div class="sb-meta">#${hub.id}</div>`;
        li.addEventListener('click', () => {
            const el = document.getElementById(`hub-${hub.id}`);
            if(el) {
                el.scrollIntoView({behavior: 'smooth'});
                el.querySelector('.hub-body').classList.add('open');
                if(window.innerWidth < 850) {
                    document.getElementById('sidebar').classList.remove('open');
                    document.body.classList.remove('sidebar-open');
                }
            }
        });
        list.appendChild(li);
    });
}

function updateSidebar(msg) {
    document.getElementById('sidebar-list').innerHTML = `<li style="padding:20px; color:var(--text-muted); font-size:0.8rem; font-family:var(--font-tech);">${msg}</li>`;
}

function handleSearch(e) {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('.hub-card').forEach(card => {
        card.style.display = card.innerText.toLowerCase().includes(term) ? 'block' : 'none';
    });
}

function createNewHub() {
    const newHub = { id: null, title: 'New Hub', children: [], images: [] };
    appData.push(newHub);
    renderApp();
    const wrapper = document.getElementById('resources-wrapper');
    wrapper.lastElementChild.querySelector('.hub-body').classList.add('open');
    wrapper.lastElementChild.scrollIntoView({behavior:'smooth'});
}

function showNotification(msg, type = 'success') {
    const area = document.getElementById('notification-area');
    area.textContent = msg;
    area.style.background = type === 'success' ? 'var(--neon-teal)' : 'var(--danger)';
    area.style.color = type === 'success' ? '#000' : '#fff';
    area.style.display = 'block';
    setTimeout(() => area.style.display = 'none', 3000);
}

function initParticles() {
    const canvas = document.getElementById('particle-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let w, h, particles = [];
    const setSize = () => { w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; };
    window.onresize = setSize; setSize();
    for(let i=0; i<30; i++) particles.push({x: Math.random()*w, y: Math.random()*h, vx: Math.random()-0.5, vy: Math.random()-0.5});
    function anim() {
        ctx.clearRect(0,0,w,h);
        ctx.fillStyle = '#00e0b7';
        particles.forEach(p => {
            p.x+=p.vx; p.y+=p.vy;
            if(p.x<0||p.x>w) p.vx*=-1; if(p.y<0||p.y>h) p.vy*=-1;
            ctx.beginPath(); ctx.arc(p.x,p.y,1,0,Math.PI*2); ctx.fill();
        });
        requestAnimationFrame(anim);
    }
    anim();
}

async function exportData() {
    if (!appData || appData.length === 0) return;
    const blob = new Blob([JSON.stringify(appData, null, 4)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `job_tracker_backup.json`;
    a.click();
}

async function importData(event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (e) => {
        try {
            const imported = JSON.parse(e.target.result);
            for (const hub of imported) {
                const hubToSave = { ...hub, id: null };
                const newParentId = await saveJob(hubToSave);
                if (newParentId && hub.children) {
                    for (const child of hub.children) {
                        await saveJob({ ...child, id: null, parent_id: newParentId });
                    }
                }
            }
            fetchData();
            showNotification('Import Successful');
        } catch (err) { showNotification('Import Failed', 'error'); }
    };
    reader.readAsText(file);
}

async function deleteJob(id) {
    if(!confirm("Delete this Hub?")) return;
    try {
        const res = await fetch(`${API_URL}?action=delete`, {
            method: 'POST',
            body: JSON.stringify({id: id})
        });
        const result = await res.json();
        if(result.status === 'success') fetchData();
    } catch (e) { showNotification('Delete Failed', 'error'); }
}