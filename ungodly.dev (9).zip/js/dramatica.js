document.addEventListener('DOMContentLoaded', () => {
    const API_URL = 'api18.php';
    const iterationsSelect = document.getElementById('iterations-select');
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toast-message');
    const importFile = document.getElementById('import-file');
    
      const elementMap = {
          os: {
              past: {
                  fate: ['knowledge', 'order', 'chaos', 'thought'],
                  prediction: ['actuality', 'inertia', 'change', 'perception'],
                  interdiction: ['ability', 'equity', 'inequity', 'desire'],
                  destiny: ['aware', 'projection', 'speculation', 'selfaware']
              },
              changing: {
                  fact: ['proven', 'accurate', 'nonaccurate', 'unproven'],
                  security: ['effect', 'result', 'process', 'cause'],
                  threat: ['theory', 'expectation', 'determination', 'hunch'],
                  fantasy: ['trust', 'ending', 'unending', 'test']
              },
              future: {
                  openness: ['consideration', 'faith', 'disbelief', 'reconsider'],
                  delay: ['pursuit', 'support', 'oppose', 'avoid'],
                  choice: ['logic', 'conscience', 'temptation', 'feeling'],
                  preconception: ['control', 'help', 'hinder', 'uncontrolled']
              },
              present: {
                  work: ['certainty', 'deduction', 'introduction', 'potentiality'],
                  attract: ['proaction', 'acceptance', 'nonacceptance', 'reaction'],
                  repel: ['probability', 'reduction', 'production', 'possibility'],
                  attempt: ['inaction', 'evaluation', 'reevaluation', 'protection']
              }
          },
          rs: {
              understanding: {
                  instinct: ['knowledge', 'ability', 'desire', 'thought'],
                  senses: ['actuality', 'aware', 'selfaware', 'perception'],
                  interpretation: ['order', 'equity', 'inequity', 'chaos'],
                  conditioning: ['inertia', 'projection', 'speculation', 'change']
              },
              doing: {
                  wisdom: ['proven', 'theory', 'hunch', 'unproven'],
                  skill: ['effect', 'trust', 'test', 'cause'],
                  experience: ['accurate', 'expectation', 'determination', 'nonaccurate'],
                  enlightenment: ['result', 'ending', 'unending', 'process']
              },
              obtaining: {
                  approach: ['consideration', 'logic', 'feeling', 'reconsider'],
                  selfinterest: ['pursuit', 'control', 'uncontrolled', 'avoid'],
                  morality: ['faith', 'conscience', 'temptation', 'disbelief'],
                  attitude: ['support', 'help', 'hinder', 'oppose']
              },
              gathering: {
                  prerequisites: ['certainty', 'probability', 'possibility', 'potentiality'],
                  strategy: ['proaction', 'inaction', 'protection', 'reaction'],
                  analysis: ['deduction', 'reduction', 'production', 'induction'],
                  preconditions: ['acceptance', 'evaluation', 'reevaluation', 'nonacceptance']
              }
          },
          ic: {
              plan: {
                  stateofbeing: ['knowledge', 'inertia', 'change', 'thought'],
                  situation: ['actuality', 'order', 'chaos', 'perception'],
                  circumstances: ['aware', 'equity', 'inequity', 'selfaware'],
                  senseofself: ['ability', 'projection', 'speculation', 'desire']
              },
              role: {
                  knowledge: ['proven', 'result', 'process', 'unproven'],
                  ability: ['effect', 'accurate', 'nonaccurate', 'cause'],
                  desire: ['trust', 'expectation', 'determination', 'test'],
                  thought: ['theory', 'ending', 'unending', 'hunch']
              },
              nature: {
                  rationalization: ['consideration', 'support', 'oppose', 'reconsider'],
                  commitment: ['pursuit', 'faith', 'disbelief', 'avoid'],
                  responsibility: ['control', 'conscience', 'temptation', 'uncontrolled'],
                  obligation: ['logic', 'help', 'hinder', 'feeling']
              },
              idea: {
                  permission: ['certainty', 'acceptance', 'nonacceptance', 'potentiality'],
                  need: ['proaction', 'deduction', 'induction', 'reaction'],
                  expediency: ['inaction', 'reduction', 'production', 'protection'],
                  deficiency: ['probability', 'evaluation', 'reevaluation', 'possibility']
              }
          },
          mc: {
              memories: {
                  truth: ['knowledge', 'actuality', 'perception', 'thought'],
                  evidence: ['ability', 'aware', 'selfaware', 'desire'],
                  suspicion: ['order', 'inertia', 'change', 'chaos'],
                  falsehood: ['equity', 'projection', 'speculation', 'inequity']
              },
              impulses: {
                  value: ['proven', 'effect', 'cause', 'unproven'],
                  confidence: ['theory', 'trust', 'test', 'hunch'],
                  worry: ['accurate', 'result', 'process', 'nonaccurate'],
                  worth: ['expectation', 'ending', 'unending', 'determination']
              },
              desires: {
                  closure: ['consideration', 'pursuit', 'avoid', 'reconsider'],
                  hope: ['logic', 'control', 'uncontrolled', 'feeling'],
                  dream: ['faith', 'support', 'oppose', 'disbelief'],
                  denial: ['conscience', 'help', 'hinder', 'temptation']
              },
              contemplations: {
                  investigation: ['certainty', 'proaction', 'reaction', 'potentiality'],
                  appraisal: ['probability', 'inaction', 'protection', 'possibility'],
                  reappraisal: ['deduction', 'acceptance', 'nonacceptance', 'induction'],
                  doubt: ['reduction', 'evaluation', 'reevaluation', 'production']
              }
          }
      };
    
    let currentIterationId = null;

    const getFormData = () => {
        const data = { os: {}, mc: {}, ic: {}, rs: {} };
        for (const throughline in elementMap) {
            for (const concern in elementMap[throughline]) {
                data[throughline][concern] = {};
                for (const variation in elementMap[throughline][concern]) {
                     data[throughline][concern][variation] = {};
                     elementMap[throughline][concern][variation].forEach(elementName => {
                         const elementId = `${throughline}-${concern}-${variation.replace(/\s/g, '')}-${elementName}`;
                         const element = document.getElementById(elementId);
                         data[throughline][concern][variation][elementName] = element ? element.value.trim() : '';
                     });
                }
            }
        }
        return data;
    };

    const populateForm = (data) => {
        clearForm(false);
        if (!data) return;
        for (const throughline in data) {
            for (const concern in data[throughline]) {
                for (const variation in data[throughline][concern]) {
                    for (const elementName in data[throughline][concern][variation]) {
                        const elementId = `${throughline}-${concern}-${variation.replace(/\s/g, '')}-${elementName.toLowerCase().replace(/\s/g, '')}`;
                        const element = document.getElementById(elementId);
                        if (element && data[throughline][concern][variation][elementName]) {
                            element.value = data[throughline][concern][variation][elementName];
                        }
                    }
                }
            }
        }
    };
    
    const apiCall = async (action, data = {}) => {
        const formData = new FormData();
        formData.append('action', action);
        for (const key in data) {
            formData.append(key, data[key]);
        }
        try {
            const response = await fetch(API_URL, { method: 'POST', body: formData });
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            showToast(`Error: ${error.message}`, 'error');
            return null;
        }
    };
    
    const loadIterations = async () => {
        const result = await apiCall('get_iterations');
        if (result && result.success) {
            iterationsSelect.innerHTML = '<option value="">Load an Iteration...</option>';
            result.data.forEach(iter => {
                const option = document.createElement('option');
                option.value = iter.id;
                option.textContent = iter.iteration_name;
                iterationsSelect.appendChild(option);
            });
        }
    };
    
    const loadIterationData = async (id) => {
        if (!id) return;
        const result = await apiCall('get_iteration', { id });
        if (result && result.success && result.data.storyform_data) {
            try {
                const storyData = JSON.parse(result.data.storyform_data);
                populateForm(storyData);
                currentIterationId = result.data.id;
                iterationsSelect.value = id;
                showToast(`Loaded '${result.data.iteration_name}'`);
            } catch (e) {
                 showToast('Failed to parse story data.', 'error');
            }
        }
    };

    const saveIteration = async (newName = null) => {
        const selectedOption = iterationsSelect.options[iterationsSelect.selectedIndex];
        let iterationName = newName;

        if (!iterationName) {
            iterationName = selectedOption && currentIterationId ? selectedOption.text : '';
        }

        if (!iterationName) {
            iterationName = prompt('Enter a name for this story iteration:');
            if (!iterationName) {
                showToast('Save cancelled.', 'error');
                return;
            }
        }
        
        const storyformData = getFormData();
        const data = {
            id: currentIterationId,
            iteration_name: iterationName,
            storyform_data: JSON.stringify(storyformData)
        };

        const result = await apiCall('save_iteration', data);
        if (result && result.success) {
            showToast(`Saved '${iterationName}' successfully!`);
            await loadIterations();
            iterationsSelect.value = result.id;
            currentIterationId = result.id;
        }
    };
    
    const clearForm = (showMsg = true) => {
        const textareas = document.querySelectorAll('.element-textarea');
        textareas.forEach(area => area.value = '');
        iterationsSelect.value = '';
        currentIterationId = null;
        if(showMsg) showToast('Cleared form for new iteration.');
    };
    
    const showToast = (message, type = 'success') => {
        toastMessage.textContent = message;
        toast.className = toast.className.replace(/bg-\w+-500/, type === 'success' ? 'bg-green-500' : 'bg-red-500');
        toast.classList.remove('opacity-0');
        setTimeout(() => { toast.classList.add('opacity-0'); }, 3000);
    };

    const exportToJson = () => {
        const storyData = getFormData();
        const iterationName = iterationsSelect.options[iterationsSelect.selectedIndex]?.text || 'Untitled-Storyform';
        const filename = `${iterationName.replace(/[\s/\\?%*:|"<>]/g, '_')}.json`;
        const jsonStr = JSON.stringify(storyData, null, 2);
        const blob = new Blob([jsonStr], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showToast('Exported to JSON!');
    };

    const importFromJson = (event) => {
        const file = event.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = JSON.parse(e.target.result);
                if (data.os && data.mc && data.ic && data.rs) {
                    populateForm(data);
                    currentIterationId = null;
                    iterationsSelect.value = '';
                    showToast(`Imported '${file.name}'. Save to create a new iteration.`);
                } else {
                    showToast('Invalid JSON structure.', 'error');
                }
            } catch (error) {
                showToast(`Error reading file: ${error.message}`, 'error');
            } finally {
                importFile.value = '';
            }
        };
        reader.readAsText(file);
    };
    
    const createNewIteration = () => {
        const iterationName = prompt('Enter a name for your new iteration:');
        if (iterationName) {
            clearForm(false); 
            currentIterationId = null; 
            saveIteration(iterationName); 
        } else {
            showToast('New iteration cancelled.');
        }
    };

    document.getElementById('new-btn').addEventListener('click', createNewIteration);
    document.getElementById('save-btn').addEventListener('click', () => saveIteration());
    document.getElementById('export-btn').addEventListener('click', exportToJson);
    document.getElementById('import-btn').addEventListener('click', () => importFile.click());
    importFile.addEventListener('change', importFromJson);
    iterationsSelect.addEventListener('change', (e) => loadIterationData(e.target.value));
    
    const rulesModal = document.getElementById('rules-modal');
    document.getElementById('rules-btn').addEventListener('click', () => rulesModal.classList.remove('hidden'));
    document.getElementById('close-modal-btn').addEventListener('click', () => rulesModal.classList.add('hidden'));
    rulesModal.addEventListener('click', (e) => {
        if (e.target === rulesModal) rulesModal.classList.add('hidden');
    });

    loadIterations();
});

