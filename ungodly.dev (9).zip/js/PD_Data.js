// --- TOKEN MANAGEMENT ---
function addGlobalToken() {
    const keyInput = document.getElementById('new-token-key');
    const key = keyInput.value.trim().replace(/[^a-zA-Z0-9]/g, '');
    if (!key) return;
    if (projectData.tokens.some(t => t.key === key)) return;
    
    projectData.tokens.push({ key, value: "Sample Value" });
    keyInput.value = '';
    renderLists();
    updatePreview();
}

function removeToken(idx) {
    projectData.tokens.splice(idx, 1);
    renderLists();
    updatePreview();
}

function updateTokenValue(idx, val) {
    projectData.tokens[idx].value = val;
    updatePreview();
}

function startTokenEdit(idx) {
    editingTokenIdx = idx;
    renderLists();
    setTimeout(() => {
        const input = document.getElementById(`edit-token-key-${idx}`);
        if (input) {
            input.focus();
            input.select();
        }
    }, 0);
}

function cancelTokenEdit() {
    editingTokenIdx = null;
    renderLists();
}

function saveTokenKeyEdit(idx) {
    const input = document.getElementById(`edit-token-key-${idx}`);
    if (!input) return;
    const newKey = input.value.trim().replace(/[^a-zA-Z0-9]/g, '');
    if (!newKey) {
        cancelTokenEdit();
        return;
    }

    const oldKey = projectData.tokens[idx].key;
    if (newKey !== oldKey) {
        if (projectData.tokens.some((t, i) => i !== idx && t.key === newKey)) {
            showNotification("Token key already exists.");
            return;
        }

        // Search and Replace across all prompts and buttons
        const oldTagStr = `{{${oldKey}}}`;
        const newTagStr = `{{${newKey}}}`;
        
        let replacementsMade = 0;
        projectData.prompts.forEach(p => {
            if(p.bodyText && p.bodyText.includes(oldTagStr)) {
                p.bodyText = p.bodyText.split(oldTagStr).join(newTagStr);
                replacementsMade++;
            }
            if(p.title && p.title.includes(oldTagStr)) {
                p.title = p.title.split(oldTagStr).join(newTagStr);
                replacementsMade++;
            }
            if(p.buttons) {
                p.buttons.forEach(b => {
                    if(b.text && b.text.includes(oldTagStr)) {
                        b.text = b.text.split(oldTagStr).join(newTagStr);
                        replacementsMade++;
                    }
                });
            }
        });

        projectData.tokens[idx].key = newKey;
        if(replacementsMade > 0) showNotification(`Updated ${replacementsMade} token instances.`);
    }

    editingTokenIdx = null;
    renderLists();
    updatePreview();
    if(activePromptId) renderEditor();
}


// --- TAG MANAGEMENT ---
function addProjectTag() {
    const nameInput = document.getElementById('new-tag-name');
    const colorInput = document.getElementById('new-tag-color');
    const name = nameInput.value.trim();
    if (!name) return;
    projectData.tags.push({ name, color: colorInput.value });
    nameInput.value = '';
    renderLists();
    populateTagDropdown();
}

function removeTag(idx) {
    const tagName = projectData.tags[idx].name;
    projectData.tags.splice(idx, 1);
    if (activeTag === tagName) activeTag = projectData.tags[0]?.name || null;
    renderLists();
    populateTagDropdown();
}

function startTagEdit(idx) {
    editingTagIdx = idx;
    renderLists();
    setTimeout(() => {
        const input = document.getElementById(`edit-tag-input-${idx}`);
        if (input) {
            input.focus();
            input.select();
        }
    }, 0);
}

function cancelTagEdit() {
    editingTagIdx = null;
    renderLists();
}

function saveTagEdit(idx) {
    const nameInput = document.getElementById(`edit-tag-input-${idx}`);
    const colorInput = document.getElementById(`edit-tag-color-${idx}`);
    if (!nameInput) return;
    
    const newName = nameInput.value.trim();
    if (!newName) {
        cancelTagEdit();
        return;
    }

    const oldName = projectData.tags[idx].name;
    
    if (newName !== oldName && projectData.tags.some((t, i) => i !== idx && t.name === newName)) {
        showNotification("Tag name already exists.");
        return;
    }

    projectData.prompts.forEach(p => {
        if (p.tag === oldName) p.tag = newName;
    });

    if (activeTag === oldName) activeTag = newName;

    projectData.tags[idx].name = newName;
    projectData.tags[idx].color = colorInput.value;
    editingTagIdx = null;
    
    populateTagDropdown();
    renderLists();
    if (activePromptId) renderEditor();
}

// --- DYNAMIC GLOBAL LISTS (LEFT PANEL - OTHER SECTIONS) ---
function addGlobalItem(sectionKey) {
    const nameInput = document.getElementById(`new-${sectionKey}-name`);
    const colorInput = document.getElementById(`new-${sectionKey}-color`);
    const name = nameInput.value.trim();
    if (!name) return;
    
    projectData[sectionKey].push({
        id: crypto.randomUUID(),
        name: name,
        color: colorInput.value
    });
    
    colorInput.value = getRandomHex();
    nameInput.value = '';
    
    renderGlobalSections();
    if (activePromptId && sectionKey === 'globalFrames') renderEditor(); // refresh dropdowns
    showNotification("Item Added");
}

function deleteGlobalItem(sectionKey, id) {
    projectData[sectionKey] = projectData[sectionKey].filter(i => i.id !== id);
    renderGlobalSections();
    if (activePromptId && sectionKey === 'globalFrames') renderEditor();
}

function startGlobalItemEdit(sectionKey, id) {
    editingGlobalItem = { section: sectionKey, id: id };
    renderGlobalSections();
    setTimeout(() => {
        const input = document.getElementById(`edit-${sectionKey}-${id}-name`);
        if (input) {
            input.focus();
            input.select();
        }
    }, 0);
}

function cancelGlobalItemEdit() {
    editingGlobalItem = { section: null, id: null };
    renderGlobalSections();
}

function saveGlobalItemEdit(sectionKey, id) {
    const nameInput = document.getElementById(`edit-${sectionKey}-${id}-name`);
    const colorInput = document.getElementById(`edit-${sectionKey}-${id}-color`);
    
    if (!nameInput) return;
    const newName = nameInput.value.trim();
    if (newName) {
        const item = projectData[sectionKey].find(i => i.id === id);
        if (item) {
            item.name = newName;
            item.color = colorInput.value;
        }
    }
    editingGlobalItem = { section: null, id: null };
    renderGlobalSections();
    if (activePromptId && sectionKey === 'globalFrames') renderEditor();
}

// --- GLOBAL POSITIONS MANAGER ---
// Positions Authoring Functions
function addPositionType() {
    const input = document.getElementById('new-pos-type');
    const name = input.value.trim();
    if (!name) return;
    
    projectData.positionTypes.push({
        id: crypto.randomUUID(),
        name: name,
        collapsed: false,
        tags: []
    });
    
    input.value = '';
    renderGlobalPositions();
    if(activePromptId) renderEditor(); // to update optgroups
}

function addPositionTag() {
    const nameInput = document.getElementById('new-pos-tag');
    const typeSelect = document.getElementById('new-pos-tag-type');
    const colorInput = document.getElementById('new-pos-tag-color');
    
    const name = nameInput.value.trim();
    const typeId = typeSelect.value;
    if (!name || !typeId) return;

    lastSelectedPosTypeId = typeId; // Store state of dropdown selection
    
    const targetType = projectData.positionTypes.find(pt => pt.id === typeId);
    if (targetType) {
        targetType.tags.push({
            id: crypto.randomUUID(),
            name: name,
            color: colorInput.value
        });
        
        nameInput.value = '';
        colorInput.value = getRandomHex();
        if (targetType.collapsed) targetType.collapsed = false; // reveal the newly added tag
        
        renderGlobalPositions();
        if(activePromptId) renderEditor();
    }
}

function sortLocalPositions(typeId) {
    const type = projectData.positionTypes.find(pt => pt.id === typeId);
    if (type) {
        type.tags.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));
        renderGlobalPositions();
        if(activePromptId) renderEditor();
    }
}

function clearLocalPositions(typeId) {
    if (confirm("Clear all tags in this category?")) {
        const type = projectData.positionTypes.find(pt => pt.id === typeId);
        if (type) {
            type.tags = [];
            renderGlobalPositions();
            if(activePromptId) renderEditor();
        }
    }
}

// Positions Interactions (Collapse/Edit/Delete)
function togglePosTypeCollapse(id) {
    const type = projectData.positionTypes.find(pt => pt.id === id);
    if (type) {
        type.collapsed = !type.collapsed;
        renderGlobalPositions();
    }
}

function startPosTypeEdit(id) {
    editingPosTypeId = id;
    renderGlobalPositions();
    setTimeout(() => {
        const input = document.getElementById(`edit-postype-${id}`);
        if (input) { input.focus(); input.select(); }
    }, 0);
}

function cancelPosTypeEdit() {
    editingPosTypeId = null;
    renderGlobalPositions();
}

function savePosTypeEdit(id) {
    const input = document.getElementById(`edit-postype-${id}`);
    if (!input) return;
    const newName = input.value.trim();
    if (newName) {
        const type = projectData.positionTypes.find(pt => pt.id === id);
        if (type) type.name = newName;
    }
    editingPosTypeId = null;
    renderGlobalPositions();
    if(activePromptId) renderEditor();
}

// Right Click Context Menu (Position Type)
function showPosTypeContextMenu(e, typeId) {
    e.preventDefault();
    contextMenuTargetId = typeId;
    const menu = document.getElementById('pos-type-context-menu');
    menu.style.left = e.pageX + 'px';
    menu.style.top = e.pageY + 'px';
    menu.classList.remove('hidden');
}

function deletePosTypeFromContext() {
    if (!contextMenuTargetId) return;
    projectData.positionTypes = projectData.positionTypes.filter(pt => pt.id !== contextMenuTargetId);
    closeContextMenus();
    renderGlobalPositions();
    if(activePromptId) renderEditor();
}

// Tag Editing
function startPosTagEdit(id) {
    editingPosTagId = id;
    renderGlobalPositions();
    setTimeout(() => {
        const input = document.getElementById(`edit-postag-${id}`);
        if (input) { input.focus(); input.select(); }
    }, 0);
}

function cancelPosTagEdit() {
    editingPosTagId = null;
    renderGlobalPositions();
}

function savePosTagEdit(typeId, tagId) {
    const nameInput = document.getElementById(`edit-postag-${tagId}`);
    const colorInput = document.getElementById(`edit-postag-color-${tagId}`);
    if (!nameInput) return;
    
    const newName = nameInput.value.trim();
    if (newName) {
        const type = projectData.positionTypes.find(pt => pt.id === typeId);
        if (type) {
            const tag = type.tags.find(t => t.id === tagId);
            if (tag) {
                tag.name = newName;
                tag.color = colorInput.value;
            }
        }
    }
    editingPosTagId = null;
    renderGlobalPositions();
    if(activePromptId) renderEditor();
}

function deletePositionTag(typeId, tagId) {
    const type = projectData.positionTypes.find(pt => pt.id === typeId);
    if (type) {
        type.tags = type.tags.filter(t => t.id !== tagId);
        renderGlobalPositions();
        if(activePromptId) renderEditor();
    }
}

// Unified Drag & Drop for Types & PosTags
function handlePosTypeDragStart(e, typeId) {
    e.dataTransfer.setData("sourceTypeId", typeId);
    e.dataTransfer.setData("dragType", "type");
    e.stopPropagation();
}

function handlePosTagDragStart(e, sourceTypeId, tagId) {
    e.dataTransfer.setData("sourceTypeId", sourceTypeId);
    e.dataTransfer.setData("tagId", tagId);
    e.dataTransfer.setData("dragType", "tag");
    e.stopPropagation();
}

function handlePosDrop(e, targetTypeId) {
    e.preventDefault();
    e.stopPropagation();
    
    const dragType = e.dataTransfer.getData("dragType");
    
    if (dragType === "type") {
        const sourceTypeId = e.dataTransfer.getData("sourceTypeId");
        if (!sourceTypeId || sourceTypeId === targetTypeId) return;

        const sourceIdx = projectData.positionTypes.findIndex(pt => pt.id === sourceTypeId);
        const targetIdx = projectData.positionTypes.findIndex(pt => pt.id === targetTypeId);

        if (sourceIdx > -1 && targetIdx > -1) {
            const [movedType] = projectData.positionTypes.splice(sourceIdx, 1);
            projectData.positionTypes.splice(targetIdx, 0, movedType);
            renderGlobalPositions();
            if (activePromptId) renderEditor();
        }
    } else if (dragType === "tag") {
        const sourceTypeId = e.dataTransfer.getData("sourceTypeId");
        const tagId = e.dataTransfer.getData("tagId");
        
        if (!sourceTypeId || !tagId) return;
        if (sourceTypeId === targetTypeId) return; 
        
        const sourceType = projectData.positionTypes.find(pt => pt.id === sourceTypeId);
        const targetType = projectData.positionTypes.find(pt => pt.id === targetTypeId);
        
        if (sourceType && targetType) {
            const tagIndex = sourceType.tags.findIndex(t => t.id === tagId);
            if (tagIndex > -1) {
                const tag = sourceType.tags.splice(tagIndex, 1)[0];
                targetType.tags.push(tag); // appending to bottom of new list
                if (targetType.collapsed) targetType.collapsed = false;
                
                renderGlobalPositions();
                if(activePromptId) renderEditor();
            }
        }
    }
}