const API_URL = 'api20.php';
let state = {
    // Structure Data
    types: [],
    pantheons: [],
    worlds: [],
    characters: [],
    
    // Love/Hate data
    personality_traits: [],
    relationship_traits: [],
    presets: [],
    preset_values: [],
    factions: [],
    faction_personality_values: [],
    faction_parents: [],
    relationships: [],
    relationship_values: [],
    deed_templates: [],
    deed_template_values: [],
    emotion_models: [],
    emotion_definitions: [],
    
    // UI state
    selectedFactionId: null,
    maxIds: {},
};

// DOM Elements
const factionList = document.getElementById('faction-list');
const editorContent = document.getElementById('editor-content');
const editorPlaceholder = document.getElementById('editor-placeholder');
const matrixContainer = document.getElementById('matrix-container');
const matrixPlaceholder = document.getElementById('matrix-placeholder');
const matrixTable = document.getElementById('matrix-table');
const matrixBody = document.getElementById('matrix-body');
const loadingOverlay = document.getElementById('loading-overlay');
const loadingMessage = document.getElementById('loading-message');

// --- Initialization ---
async function initializeApp() {
    showLoading('Initializing...');
    try {
        const response = await fetch(`${API_URL}?action=getAllData`);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const result = await response.json();
        
        if (result.success) {
            Object.assign(state, result.data);
            calculateMaxIds();
            
            // Initial Render
            renderFactionList();
            populateMatrixFilter();
            
            showToast('Data loaded successfully!', 'success');
        } else {
            throw new Error(result.message);
        }
    } catch (error) {
        console.error('Initialization failed:', error);
        showToast(`Error loading data: ${error.message}`, 'error');
    } finally {
        hideLoading();
    }
}

function calculateMaxIds() {
    // Helper to safely get max ID from arrays
    const max = (arr) => arr && arr.length ? Math.max(0, ...arr.map(x => parseInt(x.id))) : 0;
    
    state.maxIds = {
        personality_traits: max(state.personality_traits),
        relationship_traits: max(state.relationship_traits),
        presets: max(state.presets),
        factions: max(state.factions),
        relationships: max(state.relationships),
        deed_templates: max(state.deed_templates),
        emotion_models: max(state.emotion_models),
        emotion_definitions: max(state.emotion_definitions),
    };
}

function getNextId(key) {
    if (!state.maxIds[key]) state.maxIds[key] = 0;
    state.maxIds[key]++;
    return state.maxIds[key];
}

// --- Data Saving ---
async function saveData() {
    showLoading('Saving Data...');
    try {
        const payload = {
            personality_traits: state.personality_traits,
            relationship_traits: state.relationship_traits,
            presets: state.presets,
            preset_values: state.preset_values,
            factions: state.factions,
            faction_personality_values: state.faction_personality_values,
            faction_parents: state.faction_parents,
            relationships: state.relationships,
            relationship_values: state.relationship_values,
            deed_templates: state.deed_templates,
            deed_template_values: state.deed_template_values,
            emotion_models: state.emotion_models,
            emotion_definitions: state.emotion_definitions,
        };
        const response = await fetch(`${API_URL}?action=saveAllData`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ data: payload })
        });
        const result = await response.json();
        if (result.success) {
            showToast('All data saved successfully!', 'success');
        } else {
            throw new Error(result.message);
        }
    } catch (error) {
        showToast(`Save failed: ${error.message}`, 'error');
    } finally {
        hideLoading();
    }
}

// --- Sidebar: Faction List ---
function renderFactionList() {
    const searchTerm = document.getElementById('faction-search').value.toLowerCase();
    const factionsByCharId = new Map(state.factions.map(f => [f.character_id, f]));
    
    // Group characters by Type
    const groups = {};
    // Ensure standard types exist in the map
    groups[1] = { meta: {id:1, name:'Gods', organization_label:'Pantheon'}, items: [], orgs: {} };
    groups[2] = { meta: {id:2, name:'Villagers', organization_label:'World'}, items: [], orgs: {} };
    groups[3] = { meta: {id:3, name:'Consciences', organization_label:null}, items: [], orgs: {} };
    groups['unknown'] = { meta: {id:'unknown', name:'Others', organization_label:null}, items:[], orgs:{} };

    // Sort characters into groups
    state.characters.forEach(char => {
        if (!char.name.toLowerCase().includes(searchTerm)) return;
        
        const typeId = char.character_type_id || 'unknown';
        const targetGroup = groups[typeId] || groups['unknown'];
        
        // Handle Organizational Grouping (Pantheons/Worlds)
        if (targetGroup.meta.organization_label) {
            const orgId = char.organization_id || 'unassigned';
            if (!targetGroup.orgs[orgId]) targetGroup.orgs[orgId] = [];
            targetGroup.orgs[orgId].push(char);
        } else {
            targetGroup.items.push(char);
        }
    });

    let html = '';

    // Render logic
    Object.values(groups).forEach(group => {
        const hasItems = group.items.length > 0 || Object.keys(group.orgs).length > 0;
        if (!hasItems) return;

        // Type Header
        const colorClass = group.meta.id == 1 ? 'text-purple-400' : (group.meta.id == 2 ? 'text-green-400' : 'text-yellow-400');
        html += `<h3 class="text-lg font-bold uppercase orbitron ${colorClass} mt-4 mb-2 sticky top-0 bg-black/50 p-1 backdrop-blur-sm z-10">${group.meta.name}</h3>`;

        // Render Flat List (e.g., Consciences)
        if (group.items.length > 0) {
            group.items.sort((a,b) => a.name.localeCompare(b.name)).forEach(char => {
                const faction = factionsByCharId.get(char.id);
                html += createFactionListItem(char, faction);
            });
        }

        // Render Organized List (e.g., Gods/Villagers)
        if (Object.keys(group.orgs).length > 0) {
            const getOrgName = (id) => {
                if (id === 'unassigned') return 'Unassigned';
                const p = state.pantheons.find(x => x.id === id);
                if (p) return p.name;
                const w = state.worlds.find(x => x.id === id);
                return w ? w.name : 'Unknown Org';
            };

            Object.entries(group.orgs).sort((a,b) => getOrgName(a[0]).localeCompare(getOrgName(b[0]))).forEach(([orgId, chars]) => {
                const orgName = getOrgName(orgId);
                html += `
                    <details open class="mb-2 pl-2 border-l-2 border-gray-700/50">
                        <summary class="text-sm font-bold text-gray-400 hover:text-white mb-1 flex items-center">
                            <span class="mr-1">▼</span> ${orgName} 
                            <span class="text-xs font-normal opacity-50 ml-2">(${chars.length})</span>
                        </summary>
                        <div class="pl-2 pt-1 flex flex-col gap-1">
                            ${chars.sort((a,b) => a.name.localeCompare(b.name)).map(c => createFactionListItem(c, factionsByCharId.get(c.id))).join('')}
                        </div>
                    </details>
                `;
            });
        }
    });

    factionList.innerHTML = html;
}

function createFactionListItem(character, faction) {
    const isSelected = faction && faction.id === state.selectedFactionId;
    const factionId = faction ? faction.id : 'create';
    // Style adjustments for better visibility
    const bgClass = isSelected ? 'bg-cyan-500/20 border-l-4 border-cyan-500 text-white' : 'hover:bg-cyan-500/10 border-l-4 border-transparent text-gray-300';
    
    return `
        <div class="flex items-center p-2 rounded cursor-pointer transition-colors ${bgClass}" 
             data-faction-id="${factionId}" 
             data-character-id="${character.id}" 
             onclick="handleFactionSelect(event)">
            <div class="w-3 h-3 rounded-full mr-3 flex-shrink-0" style="background-color: ${character.color || '#666'}; box-shadow: 0 0 5px ${character.color || '#666'}"></div>
            <span class="flex-grow text-sm truncate">${character.name}</span>
        </div>`;
}

// --- Selection Logic ---
window.handleFactionSelect = (event) => {
    const target = event.currentTarget;
    const charId = target.dataset.characterId;
    let factionId = parseInt(target.dataset.factionId);

    // Create faction if it doesn't exist yet for this character
    if (isNaN(factionId) || target.dataset.factionId === 'create') {
        const newFaction = {
            id: getNextId('factions'),
            character_id: charId,
            description: '',
            gizmo_color: state.characters.find(c => c.id === charId).color || '#FFFFFF',
            judge_parents_percentage: 0,
        };
        state.factions.push(newFaction);
        factionId = newFaction.id;
        // Refresh list to update ID
        renderFactionList();
    }

    state.selectedFactionId = factionId;
    
    // UI Updates
    renderFactionList(); // update active state styling
    renderEditor(factionId);
    renderRelationshipMatrix(factionId);
};

// --- Center Panel: Relationship Matrix ---
function populateMatrixFilter() {
    const sel = document.getElementById('matrix-filter-org');
    sel.innerHTML = '<option value="all">All Organizations</option>';
    
    const orgs = [...state.pantheons, ...state.worlds].sort((a,b) => a.name.localeCompare(b.name));
    orgs.forEach(o => {
        sel.innerHTML += `<option value="${o.id}">${o.name}</option>`;
    });
    
    sel.addEventListener('change', () => renderRelationshipMatrix(state.selectedFactionId));
    document.getElementById('matrix-search').addEventListener('input', () => renderRelationshipMatrix(state.selectedFactionId));
}

function renderRelationshipMatrix(judgeFactionId) {
    if (!judgeFactionId) {
        matrixPlaceholder.classList.remove('hidden');
        matrixTable.classList.add('hidden');
        document.getElementById('matrix-subtitle').textContent = "Select a character to manage their relationships";
        return;
    }

    matrixPlaceholder.classList.add('hidden');
    matrixTable.classList.remove('hidden');

    const judgeFaction = state.factions.find(f => f.id === judgeFactionId);
    const judgeChar = state.characters.find(c => c.id === judgeFaction.character_id);
    document.getElementById('matrix-subtitle').textContent = `Editing relationships for: ${judgeChar.name}`;

    const filterOrg = document.getElementById('matrix-filter-org').value;
    const filterSearch = document.getElementById('matrix-search').value.toLowerCase();

    // Get all existing relationships for this judge
    const existingRels = state.relationships.filter(r => r.judge_faction_id === judgeFactionId);
    const relMap = new Map(existingRels.map(r => [r.subject_faction_id, r]));

    // Generate rows for ALL other factions (or filtered subset)
    let rowsHtml = '';
    
    // Sort factions: Existing relationships first, then alphabetical
    const sortedFactions = [...state.factions].filter(f => f.id !== judgeFactionId).sort((a,b) => {
        const hasA = relMap.has(a.id);
        const hasB = relMap.has(b.id);
        if (hasA && !hasB) return -1;
        if (!hasA && hasB) return 1;
        
        const charA = state.characters.find(c => c.id === a.character_id);
        const charB = state.characters.find(c => c.id === b.character_id);
        return charA.name.localeCompare(charB.name);
    });

    sortedFactions.forEach(subject => {
        const subjectChar = state.characters.find(c => c.id === subject.character_id);
        if (!subjectChar) return;

        // Apply Filters
        if (filterSearch && !subjectChar.name.toLowerCase().includes(filterSearch)) return;
        if (filterOrg !== 'all' && subjectChar.organization_id !== filterOrg) return;

        const rel = relMap.get(subject.id);
        const hasRel = !!rel;
        
        // Org Name for display
        let orgName = '-';
        if (subjectChar.organization_id) {
            const p = state.pantheons.find(x => x.id === subjectChar.organization_id);
            const w = state.worlds.find(x => x.id === subjectChar.organization_id);
            orgName = p ? p.name : (w ? w.name : '?');
        }

        // Action Button Logic
        const actionBtn = hasRel 
            ? `<button class="btn-sm bg-red-900/30 hover:bg-red-900/60 text-red-400 border border-red-900/50 rounded px-2 py-1 transition-colors" onclick="deleteRelationship(${rel.id})">Remove</button>`
            : `<button class="btn-sm bg-cyan-900/30 hover:bg-cyan-900/60 text-cyan-400 border border-cyan-900/50 rounded px-2 py-1 transition-colors" onclick="addRelationship(${judgeFactionId}, ${subject.id})">Add Rel</button>`;

        // Trait Inputs (Only show if relationship exists)
        let traitsHtml = '';
        let inheritHtml = '';
        
        if (hasRel) {
            // Inheritance Checkbox
            inheritHtml = `<input type="checkbox" ${rel.is_inheritable ? 'checked' : ''} onchange="updateRelInheritance(${rel.id}, this.checked)">`;

            // Traits Sliders
            const rValues = state.relationship_values.filter(v => v.relationship_id === rel.id);
            traitsHtml = `<div class="grid grid-cols-1 gap-1">`;
            state.relationship_traits.forEach(t => {
                const valObj = rValues.find(v => v.relationship_trait_id === t.id);
                const val = valObj ? valObj.value : 0;
                traitsHtml += `
                    <div class="flex items-center gap-2 text-xs">
                        <span class="w-16 truncate text-gray-400" title="${t.name}">${t.name}</span>
                        <input type="range" min="-100" max="100" value="${val}" class="flex-grow h-1" 
                               onchange="updateRelValue(${rel.id}, ${t.id}, this.value)" 
                               oninput="this.nextElementSibling.innerText = this.value">
                        <span class="w-8 text-right font-mono text-cyan-300">${val}</span>
                    </div>
                `;
            });
            traitsHtml += `</div>`;
        } else {
            traitsHtml = `<span class="text-xs text-gray-600 italic">No relationship defined</span>`;
            inheritHtml = `<span class="text-gray-700">-</span>`;
        }

        rowsHtml += `
            <tr class="${hasRel ? 'matrix-row-active' : ''}">
                <td>
                    <div class="flex items-center">
                        <div class="w-2 h-2 rounded-full mr-2" style="background-color: ${subjectChar.color}"></div>
                        <span class="font-bold text-sm ${hasRel ? 'text-white' : 'text-gray-400'}">${subjectChar.name}</span>
                    </div>
                </td>
                <td class="text-xs text-gray-500">${orgName}</td>
                <td>${traitsHtml}</td>
                <td class="text-center">${inheritHtml}</td>
                <td class="text-right">${actionBtn}</td>
            </tr>
        `;
    });

    matrixBody.innerHTML = rowsHtml;
}

// --- Matrix Actions ---
window.addRelationship = (judgeId, subjectId) => {
    const newRelId = getNextId('relationships');
    const newRel = {
        id: newRelId,
        judge_faction_id: judgeId,
        subject_faction_id: subjectId,
        is_inheritable: 1
    };
    state.relationships.push(newRel);
    
    // Init values
    state.relationship_traits.forEach(t => {
        state.relationship_values.push({
            relationship_id: newRelId,
            relationship_trait_id: t.id,
            value: 0 // Default to 0 affinity/etc
        });
    });

    renderRelationshipMatrix(judgeId);
    renderEditor(judgeId); // Update right panel if it shows relationships
};

window.deleteRelationship = (relId) => {
    state.relationships = state.relationships.filter(r => r.id !== relId);
    state.relationship_values = state.relationship_values.filter(v => v.relationship_id !== relId);
    renderRelationshipMatrix(state.selectedFactionId);
    renderEditor(state.selectedFactionId);
};

window.updateRelInheritance = (relId, checked) => {
    const rel = state.relationships.find(r => r.id === relId);
    if (rel) rel.is_inheritable = checked ? 1 : 0;
};

window.updateRelValue = (relId, traitId, value) => {
    let valObj = state.relationship_values.find(v => v.relationship_id === relId && v.relationship_trait_id === traitId);
    if (valObj) {
        valObj.value = parseInt(value);
    } else {
        state.relationship_values.push({
            relationship_id: relId,
            relationship_trait_id: traitId,
            value: parseInt(value)
        });
    }
};

// --- Right Panel: Editor (Personality & Settings) ---
function renderEditor(factionId) {
    if (!factionId) {
        editorContent.classList.add('hidden');
        editorPlaceholder.classList.remove('hidden');
        return;
    }
    
    const faction = state.factions.find(f => f.id === factionId);
    const char = state.characters.find(c => c.id === faction.character_id);
    const pValues = state.faction_personality_values.filter(v => v.faction_id === factionId);
    const parentLinks = state.faction_parents.filter(p => p.child_faction_id === factionId);
    const parentIds = parentLinks.map(p => p.parent_faction_id);

    editorContent.classList.remove('hidden');
    editorPlaceholder.classList.add('hidden');

    let html = `
        <div class="border-b border-white/10 pb-4">
            <h2 class="text-2xl font-bold text-white mb-1">${char.name}</h2>
            <div class="flex gap-2">
                <input type="color" value="${faction.gizmo_color}" onchange="updateFactionColor(${factionId}, this.value)" class="h-6 w-12 rounded cursor-pointer border border-gray-600">
                <span class="text-xs text-gray-400 self-center">Gizmo Color</span>
            </div>
        </div>

        <div>
            <label class="block text-xs uppercase text-gray-500 font-bold mb-1">Description</label>
            <textarea class="w-full h-20 text-sm bg-black/20 border border-white/10 rounded p-2 focus:border-cyan-500" 
                onchange="updateFactionDesc(${factionId}, this.value)">${faction.description || ''}</textarea>
        </div>

        <!-- Parents -->
        <div>
            <label class="block text-xs uppercase text-gray-500 font-bold mb-1">Parents (Inheritance)</label>
            <select multiple class="w-full h-24 text-sm bg-black/20 border border-white/10 rounded p-1 focus:border-cyan-500" onchange="updateParents(${factionId}, this)">
                ${state.factions.filter(f => f.id !== factionId).map(f => {
                    const c = state.characters.find(x => x.id === f.character_id);
                    return `<option value="${f.id}" ${parentIds.includes(f.id) ? 'selected' : ''}>${c.name}</option>`;
                }).join('')}
            </select>
            <div class="mt-2 flex items-center justify-between text-xs">
                <span class="text-gray-400">Judge Parents %</span>
                <input type="number" min="0" max="100" value="${faction.judge_parents_percentage}" 
                       class="w-16 bg-black/20 border border-white/10 rounded p-1 text-center"
                       onchange="updateJudgeParents(${factionId}, this.value)">
            </div>
        </div>

        <!-- Personality Traits -->
        <div>
            <div class="flex justify-between items-center mb-2">
                <label class="block text-xs uppercase text-gray-500 font-bold">Personality</label>
                <div class="flex gap-1">
                    <select id="preset-selector" class="text-xs w-24 py-0 h-6 bg-black/30 border border-white/10 rounded">
                        <option value="">Preset...</option>
                        ${state.presets.map(p => `<option value="${p.id}">${p.name}</option>`).join('')}
                    </select>
                    <button class="btn-sm bg-cyan-900/30 text-cyan-400 border border-cyan-900/50 rounded text-xs py-0 h-6" onclick="applyPreset(${factionId})">Apply</button>
                </div>
            </div>
            <div class="space-y-3 bg-black/20 p-3 rounded border border-white/5">
                ${state.personality_traits.map(t => {
                    const val = pValues.find(v => v.personality_trait_id === t.id)?.value || 0;
                    return `
                        <div>
                            <div class="flex justify-between text-xs mb-1">
                                <span class="text-gray-300">${t.name}</span>
                                <span class="font-mono text-primary-glow">${val}</span>
                            </div>
                            <input type="range" min="-100" max="100" value="${val}" class="w-full h-1"
                                   oninput="this.previousElementSibling.lastElementChild.innerText = this.value"
                                   onchange="updatePersonality(${factionId}, ${t.id}, this.value)">
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
    `;

    editorContent.innerHTML = html;
}

// --- Editor Helpers ---
window.updateFactionColor = (id, val) => { state.factions.find(f => f.id === id).gizmo_color = val; };
window.updateFactionDesc = (id, val) => { state.factions.find(f => f.id === id).description = val; };
window.updateJudgeParents = (id, val) => { state.factions.find(f => f.id === id).judge_parents_percentage = parseInt(val); };

window.updateParents = (factionId, selectEl) => {
    const newParents = Array.from(selectEl.selectedOptions).map(o => parseInt(o.value));
    state.faction_parents = state.faction_parents.filter(p => p.child_faction_id !== factionId);
    newParents.forEach(pid => {
        state.faction_parents.push({ child_faction_id: factionId, parent_faction_id: pid });
    });
};

window.updatePersonality = (factionId, traitId, val) => {
    let pVal = state.faction_personality_values.find(v => v.faction_id === factionId && v.personality_trait_id === traitId);
    if (pVal) pVal.value = parseInt(val);
    else state.faction_personality_values.push({ faction_id: factionId, personality_trait_id: traitId, value: parseInt(val) });
};

window.applyPreset = (factionId) => {
    const presetId = parseInt(document.getElementById('preset-selector').value);
    if (!presetId) return;
    const vals = state.preset_values.filter(v => v.preset_id === presetId);
    
    // Clear old values
    state.faction_personality_values = state.faction_personality_values.filter(v => v.faction_id !== factionId);
    
    // Apply new
    vals.forEach(pv => {
        state.faction_personality_values.push({
            faction_id: factionId,
            personality_trait_id: pv.personality_trait_id,
            value: pv.value
        });
    });
    renderEditor(factionId);
};

// --- Toast & Modal Utils ---
function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toast-message');
    toastMessage.textContent = message;
    
    toast.className = `fixed bottom-5 right-5 text-white py-2 px-4 rounded-lg shadow-lg transition-opacity duration-300 z-50 border pointer-events-none opacity-100 ${type === 'success' ? 'bg-gray-800 border-green-500' : 'bg-red-900 border-red-500'}`;

    setTimeout(() => {
        toast.classList.add('opacity-0');
    }, 3000);
}

function showLoading(message) {
    loadingMessage.textContent = message;
    loadingOverlay.classList.remove('hidden');
}

function hideLoading() {
    loadingOverlay.classList.add('hidden');
}

function showModal(content, onConfirm, confirmText = 'Confirm', onOpen = null) {
    const modalId = `modal-${Date.now()}`;
    const modalHTML = `
        <div id="${modalId}" class="modal fixed inset-0 z-50 flex items-center justify-center p-4">
            <div class="modal-content w-full max-w-4xl max-h-[90vh] overflow-y-auto p-6 rounded panel relative">
                ${content}
                <div class="mt-6 flex justify-end gap-4">
                    <button class="btn-cancel btn py-2 px-4 rounded orbitron bg-gray-700 hover:bg-gray-600">Cancel</button>
                    <button class="btn-confirm btn btn-glow py-2 px-4 rounded orbitron">${confirmText}</button>
                </div>
            </div>
        </div>
    `;
    document.getElementById('modals').insertAdjacentHTML('beforeend', modalHTML);

    const modalElement = document.getElementById(modalId);
    const closeModal = () => modalElement.remove();

    modalElement.addEventListener('click', (event) => {
        if (event.target === modalElement) closeModal();
    });

    modalElement.querySelector('.btn-cancel').addEventListener('click', closeModal);
    modalElement.querySelector('.btn-confirm').addEventListener('click', () => {
        onConfirm();
        closeModal();
    });
    
    if(onOpen) onOpen();
}

// --- Standard Event Listeners ---
document.getElementById('save-btn').addEventListener('click', saveData);
document.getElementById('faction-search').addEventListener('input', renderFactionList);
document.getElementById('library-btn').addEventListener('click', openLibraryModal);
document.getElementById('simulator-btn').addEventListener('click', openSimulatorModal);
document.getElementById('export-json-btn').addEventListener('click', exportJSON);
document.getElementById('help-btn').addEventListener('click', openHelpModal);

// Stub functions for modals (Library, Simulator, Export)
function openLibraryModal() { alert('Library Modal Logic Placeholder'); }
function openSimulatorModal() { alert('Simulator Logic Placeholder'); }
function openHelpModal() { 
    showModal(`
        <h2 class="text-2xl font-bold mb-2 text-cyan-400">How to Use</h2>
        <ul class="list-disc pl-5 space-y-2 text-gray-300">
            <li><strong>Select a Character</strong> from the left sidebar to edit them.</li>
            <li><strong>The Center Panel</strong> is your Relationship Matrix. It allows you to quickly add relationships to other characters.</li>
            <li><strong>The Right Panel</strong> controls the character's internal personality and parent inheritance.</li>
            <li><strong>Save All Data</strong> pushes changes back to the database.</li>
        </ul>
    `, () => {}, "Close"); 
}
function exportJSON() {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state));
    const dl = document.createElement('a');
    dl.href = dataStr;
    dl.download = "love_hate_export.json";
    dl.click();
}

// Start
initializeApp();