document.addEventListener('DOMContentLoaded', () => {
    const API_URL = 'api10.php';

    // --- DOM Elements ---
    const canvas = document.getElementById('skill-tree-canvas');
    const skillTreeContent = document.getElementById('skill-tree-content');
    const particleCanvas = document.getElementById('particle-canvas');
    const nodeContainer = document.getElementById('node-container');
    const svg = document.getElementById('skill-tree-svg');
    const treeSelector = document.getElementById('tree-selector');
    const treeColorPicker = document.getElementById('tree-color-picker');
    const pushToServerBtn = document.getElementById('push-to-server-btn');
    const expModifierInput = document.getElementById('exp-modifier-input');
    const saveExpModifierBtn = document.getElementById('save-exp-modifier');
    // Simulation UI
    const skillPointsDisplay = document.getElementById('skill-points-display');
    const prestigePointsDisplay = document.getElementById('prestige-points-display');
    const expBarProgress = document.getElementById('exp-bar-progress');
    const expBarText = document.getElementById('exp-bar-text');
    const levelDisplay = document.getElementById('level-display');
    const addExpInput = document.getElementById('add-exp-input');
    const addExpBtn = document.getElementById('add-exp-btn');
    const resetTreeBtn = document.getElementById('reset-tree-btn');
    // Editor UI
    const addSkillBtn = document.getElementById('add-skill-btn');
    const importBtn = document.getElementById('import-btn');
    const exportBtn = document.getElementById('export-btn');
    const importFileInput = document.getElementById('import-file-input');
    // Modals
    const skillDetailsModal = document.getElementById('skill-details-modal');
    const skillEditorModal = document.getElementById('skill-editor-modal');
    const treeCreationModal = document.getElementById('tree-creation-modal');
    const newTreeBtn = document.getElementById('new-tree-btn');
    const deleteTreeBtn = document.getElementById('delete-tree-btn');
    
    // --- State Variables ---
    let skillTrees = [];
    let currentTree = null;
    let skills = [];
    let simState = {
        level: 1,
        exp: 0,
        skillPoints: 0,
        prestigePoints: 0,
        learnedSkills: []
    };
    let particleCtx = particleCanvas.getContext('2d');
    let particles = [];
    let currentParticleColor = 'rgba(77, 171, 247, 0.7)';
    let colorChangeTimeout;
    
    // Pan & Zoom State
    let scale = 1;
    let panX = 0;
    let panY = 0;
    let isPanning = false;
    let startPanX = 0;
    let startPanY = 0;

    // --- Initialization ---
    const init = async () => {
        setupEventListeners();
        loadSimState();
        await loadSkillTrees();
        initParticles();
        animateParticles();
        updateTransform();
    };

    // --- API Communication ---
    const apiCall = async (action, data = {}) => {
        try {
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action, ...data }),
            });

            const text = await response.text();
            if (!response.ok) {
                throw new Error(`Server responded with ${response.status}: ${text}`);
            }

            try {
                const json = JSON.parse(text);
                if (json.success === false) {
                    throw new Error(json.message);
                }
                return json;
            } catch (e) {
                console.error("Invalid JSON received:", text);
                throw new Error(`Invalid JSON response from server.`);
            }

        } catch (error) {
            console.error(`API call failed for action "${action}":`, error);
            showToast(error.message, 'error');
            throw error;
        }
    };
    
    // --- Data Loading & Saving ---
    const loadSkillTrees = async () => {
        try {
            const data = await apiCall('get_trees');
            skillTrees = data.trees || [];
            updateTreeSelector();
            const lastSelectedId = localStorage.getItem('lastSelectedTreeId');
            const treeToSelect = skillTrees.find(t => t.id == lastSelectedId) || skillTrees[0];
            if (treeToSelect) {
                treeSelector.value = treeToSelect.id;
                await selectTree(treeToSelect.id);
            } else {
                nodeContainer.innerHTML = '';
                svg.innerHTML = '';
            }
        } catch (error) {
            // Error is already logged by apiCall
        }
    };

    const selectTree = async (treeId) => {
        currentTree = skillTrees.find(t => t.id == treeId);
        if (!currentTree) {
            skills = [];
            renderTree();
            return;
        };
        
        localStorage.setItem('lastSelectedTreeId', treeId);
        treeColorPicker.value = currentTree.color;
        updateThemeColor(currentTree.color);
        expModifierInput.value = (parseFloat(currentTree.exp_modifier) - 1) * 100;

        try {
            const data = await apiCall('get_skills', { tree_id: treeId });
            skills = data.skills || [];
            loadSimState(); // Load the sim state for this specific tree
            renderTree();
        } catch (error) {
            skills = [];
            renderTree();
        }
    };

    // --- Particle Animation ---
    const initParticles = () => {
        const resizeCanvas = () => {
            particleCanvas.width = window.innerWidth;
            particleCanvas.height = window.innerHeight;
            particles = [];
            const particleCount = Math.floor((particleCanvas.width * particleCanvas.height) / 10000); 
            for (let i = 0; i < particleCount; i++) {
                particles.push({
                    x: Math.random() * particleCanvas.width,
                    y: Math.random() * particleCanvas.height,
                    vx: (Math.random() - 0.5) * 0.3,
                    vy: (Math.random() - 0.5) * 0.3,
                    radius: Math.random() * 1.5 + 0.5
                });
            }
        };
        resizeCanvas();
        let resizeTimeout;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(resizeCanvas, 100);
        });
    };

    const animateParticles = () => {
        particleCtx.clearRect(0, 0, particleCanvas.width, particleCanvas.height);
        
        particles.forEach(p => {
            p.x += p.vx;
            p.y += p.vy;

            if (p.x < 0 || p.x > particleCanvas.width) p.vx *= -1;
            if (p.y < 0 || p.y > particleCanvas.height) p.vy *= -1;

            particleCtx.beginPath();
            particleCtx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            particleCtx.fillStyle = currentParticleColor;
            particleCtx.fill();
        });

        const connectionDistance = 120;
        for (let i = 0; i < particles.length; i++) {
            for (let j = i + 1; j < particles.length; j++) {
                const p1 = particles[i];
                const p2 = particles[j];
                const dx = p1.x - p2.x;
                const dy = p1.y - p2.y;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < connectionDistance) {
                    const opacity = 1 - (distance / connectionDistance);
                    const rgb = currentParticleColor.match(/\d+/g);
                    if (rgb) {
                        particleCtx.strokeStyle = `rgba(${rgb[0]}, ${rgb[1]}, ${rgb[2]}, ${opacity * 0.5})`;
                        particleCtx.lineWidth = 0.5;
                        particleCtx.beginPath();
                        particleCtx.moveTo(p1.x, p1.y);
                        particleCtx.lineTo(p2.x, p2.y);
                        particleCtx.stroke();
                    }
                }
            }
        }

        requestAnimationFrame(animateParticles);
    };

    // --- Rendering ---
    const renderTree = () => {
        nodeContainer.innerHTML = '';
        skills.forEach(skill => {
            const wrapper = document.createElement('div');
            wrapper.className = 'skill-node-wrapper';
            wrapper.id = `skill-${skill.id}`;
            wrapper.dataset.id = skill.id;
            wrapper.style.left = `${skill.pos_x}px`;
            wrapper.style.top = `${skill.pos_y}px`;
            
            wrapper.innerHTML = `
                <div class="skill-name">${skill.name}</div>
                <div class="skill-node">
                    <img src="${skill.icon_url || 'https://placehold.co/80x80/21252e/a0a9b8?text=N/A'}" class="skill-icon" onerror="this.src='https://placehold.co/80x80/21252e/a0a9b8?text=N/A'; this.onerror=null;"/>
                    <span class="skill-level-req">Lvl ${skill.level_req}</span>
                </div>
            `;
            
            nodeContainer.appendChild(wrapper);
            
            $(wrapper).draggable({
                containment: "parent",
                distance: 0,
                start: () => {
                    svg.classList.add('is-dragging');
                },
                drag: (event, ui) => {
                    const id = ui.helper.data('id');
                    const { left, top } = ui.position;
                    const skill = skills.find(s => s.id == id);
                    if (skill) {
                        skill.pos_x = Math.round(left);
                        skill.pos_y = Math.round(top);
                        drawConnectors();
                        updateSkillStates();
                    }
                },
                stop: (event, ui) => {
                    svg.classList.remove('is-dragging');
                    const id = ui.helper.data('id');
                    const skill = skills.find(s => s.id == id);
                    if (skill) {
                        apiCall('update_skill_position', { skill_id: id, pos_x: skill.pos_x, pos_y: skill.pos_y })
                            .catch(err => showToast('Failed to save position.', 'error'));
                    }
                }
            });
        });

        drawConnectors();
        updateSkillStates();
    };

    const drawConnectors = () => {
        svg.innerHTML = '';
        skills.forEach(skill => {
            (skill.prerequisites || []).forEach(prereqId => {
                const prereqSkill = skills.find(s => s.id == prereqId);
                if (prereqSkill) {
                    const line = createCurvedPath(prereqSkill, skill);
                    svg.appendChild(line);
                }
            });
        });
    };
    
    const createCurvedPath = (startSkill, endSkill) => {
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        const nodeSize = 80;
        const nameHeight = 25;
        const offset = nodeSize / 2;
        
        const startX = startSkill.pos_x + offset;
        const startY = startSkill.pos_y + nameHeight + offset;
        const endX = endSkill.pos_x + offset;
        const endY = endSkill.pos_y + nameHeight + offset;

        const dx = endX - startX;
        const dy = endY - startY;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist === 0) return path;

        // Perpendicular vector
        let pVecX = -dy / dist;
        let pVecY = dx / dist;
        
        // If start node is visually above the end node, flip the curve direction
        if (startY < endY) {
            pVecX *= -1;
            pVecY *= -1;
        }

        // Greatly increased the curve intensity for a more dramatic S-shape
        const curveIntensity = 45 + (18000 / (dist + 100));

        const cp1x = startX + dx * 0.25 + pVecX * curveIntensity;
        const cp1y = startY + dy * 0.25 + pVecY * curveIntensity;
        
        const cp2x = endX - dx * 0.25 - pVecX * curveIntensity;
        const cp2y = endY - dy * 0.25 - pVecY * curveIntensity;
        
        const d = `M ${startX} ${startY} C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${endX} ${endY}`;
        
        path.setAttribute('d', d);
        path.setAttribute('stroke', 'var(--border-color)');
        path.setAttribute('stroke-width', '2');
        path.setAttribute('fill', 'none');
        path.dataset.startId = startSkill.id;
        path.dataset.endId = endSkill.id;
        return path;
    };
    
    const updateThemeColor = (color) => {
        document.documentElement.style.setProperty('--tree-color-primary', color);
        document.documentElement.style.setProperty('--tree-color-secondary', `${color}26`);
        document.documentElement.style.setProperty('--tree-glow-color', `${color}40`);

        const hexToRgb = (hex) => {
            const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
            return result ? { r: parseInt(result[1], 16), g: parseInt(result[2], 16), b: parseInt(result[3], 16) } : null;
        };
        const rgb = hexToRgb(color);
        if (rgb) {
            currentParticleColor = `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.7)`;
        }
        updateSkillStates();
    };
    
    const setupEventListeners = () => {
        treeSelector.addEventListener('change', () => selectTree(treeSelector.value));

        treeColorPicker.addEventListener('input', (e) => {
            if (!currentTree) return;
            const newColor = e.target.value;
            currentTree.color = newColor;
            updateThemeColor(newColor);
            
            clearTimeout(colorChangeTimeout);
            colorChangeTimeout = setTimeout(() => {
                apiCall('update_tree_settings', { tree_id: currentTree.id, color: newColor })
                    .then(() => showToast('Color saved!', 'success'))
                    .catch(() => showToast('Failed to save color.', 'error'));
            }, 500);
        });

        pushToServerBtn.addEventListener('click', async () => {
            if (!currentTree) { showToast('No tree selected to push.', 'error'); return; }
            try {
                await apiCall('push_tree', { tree: currentTree, skills: skills });
                showToast('Tree successfully pushed to server!', 'success');
            } catch (error) {}
        });
        
        saveExpModifierBtn.addEventListener('click', () => {
             const newModifierValue = 1 + (parseFloat(expModifierInput.value) / 100);
             currentTree.exp_modifier = newModifierValue;
             apiCall('update_tree_settings', { tree_id: currentTree.id, exp_modifier: currentTree.exp_modifier })
                 .then(() => showToast('EXP Modifier saved!', 'success'))
                 .catch(() => {});
        });

        importBtn.addEventListener('click', () => importFileInput.click());
        exportBtn.addEventListener('click', exportTree);
        importFileInput.addEventListener('change', importTree);

        document.querySelectorAll('.close-modal-btn').forEach(btn => {
            btn.addEventListener('click', () => document.getElementById(btn.dataset.modal).classList.remove('active'));
        });

        addSkillBtn.addEventListener('click', () => openSkillEditor());
        newTreeBtn.addEventListener('click', () => treeCreationModal.classList.add('active'));
        deleteTreeBtn.addEventListener('click', deleteTree);

        document.getElementById('create-tree-confirm-btn').addEventListener('click', createNewTree);

        nodeContainer.addEventListener('contextmenu', e => {
            e.preventDefault();
            const wrapper = e.target.closest('.skill-node-wrapper');
            if (wrapper) {
                const skillId = wrapper.dataset.id;
                const skill = skills.find(s => s.id == skillId);
                showSkillDetails(skill);
            }
        });
        
        nodeContainer.addEventListener('dblclick', e => {
            const wrapper = e.target.closest('.skill-node-wrapper');
            if (wrapper) {
                 const skillId = wrapper.dataset.id;
                 const skill = skills.find(s => s.id == skillId);
                 openSkillEditor(skill);
            }
        });
        
        document.getElementById('editor-save-btn').addEventListener('click', saveSkill);
        document.getElementById('editor-delete-btn').addEventListener('click', deleteSkill);

        document.getElementById('add-prerequisite-btn').addEventListener('click', () => addDependency('prerequisite'));
        document.getElementById('add-lockout-btn').addEventListener('click', () => addDependency('lockout'));

        addExpBtn.addEventListener('click', () => addExperience(parseInt(addExpInput.value, 10) || 0));
        resetTreeBtn.addEventListener('click', prestigeReset);
        
        // Pan and Zoom listeners
        canvas.addEventListener('wheel', handleZoom);
        canvas.addEventListener('mousedown', startPan);
        canvas.addEventListener('mousemove', pan);
        canvas.addEventListener('mouseup', endPan);
        canvas.addEventListener('mouseleave', endPan);
    };

    // --- Pan & Zoom ---
    function updateTransform() {
        skillTreeContent.style.transform = `translate(${panX}px, ${panY}px) scale(${scale})`;
    }

    function handleZoom(e) {
        e.preventDefault();
        const zoomIntensity = 0.1;
        const rect = canvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;

        const oldScale = scale;
        if (e.deltaY < 0) {
            scale = Math.min(2, scale * (1 + zoomIntensity));
        } else {
            scale = Math.max(0.2, scale * (1 - zoomIntensity));
        }

        panX = mouseX - (mouseX - panX) * (scale / oldScale);
        panY = mouseY - (mouseY - panY) * (scale / oldScale);
        
        updateTransform();
    }

    function startPan(e) {
        // Prevent panning if the drag starts on a skill node wrapper.
        // This allows the node's draggable event to take priority.
        if (e.target.closest('.skill-node-wrapper')) {
            return;
        }
        if (e.button !== 0) return; // Only pan with left click
        isPanning = true;
        startPanX = e.clientX - panX;
        startPanY = e.clientY - panY;
    }

    function pan(e) {
        if (!isPanning) return;
        panX = e.clientX - startPanX;
        panY = e.clientY - startPanY;
        updateTransform();
    }

    function endPan() {
        isPanning = false;
    }
    
    // --- Simulation Logic ---
    function updateSkillStates() {
        skills.forEach(skill => {
            const wrapper = document.getElementById(`skill-${skill.id}`);
            if (!wrapper) return;
            const node = wrapper.querySelector('.skill-node');
            if (!node) return;

            node.classList.remove('learned', 'available', 'locked');

            const skillId = parseInt(skill.id, 10);

            if (simState.learnedSkills.includes(skillId)) {
                node.classList.add('learned');
            } else if (isSkillLockedOut(skill)) {
                node.classList.add('locked');
            } else if (isSkillUnlockable(skill)) {
                node.classList.add('available');
            } else {
                node.classList.add('locked');
            }
        });

        document.querySelectorAll('#skill-tree-svg path').forEach(path => {
            const startId = parseInt(path.dataset.startId, 10);
            const endId = parseInt(path.dataset.endId, 10);

            path.classList.remove('learned-path');
            // A line is colored only if BOTH connected skills are learned.
            if (simState.learnedSkills.includes(startId) && simState.learnedSkills.includes(endId)) {
                 path.setAttribute('stroke', 'var(--tree-color-primary)');
                 path.classList.add('learned-path');
            } else {
                path.setAttribute('stroke', 'var(--border-color)');
            }
        });
    }

    function isSkillUnlockable(skill) {
        const skillId = parseInt(skill.id, 10);
        if (simState.level < skill.level_req || simState.learnedSkills.includes(skillId)) {
            return false;
        }
        if (isSkillLockedOut(skill)) {
            return false;
        }
        const prereqs = skill.prerequisites || [];
        if (prereqs.length === 0) {
            return true; // Root skill
        }
        return prereqs.some(prereqId => simState.learnedSkills.includes(parseInt(prereqId, 10)));
    }

    function isSkillLockedOut(skill) {
        const skillId = parseInt(skill.id, 10);
        return skills.some(s => 
            simState.learnedSkills.includes(parseInt(s.id, 10)) && 
            (s.lockouts || []).map(l => parseInt(l, 10)).includes(skillId)
        );
    }
    
    function learnSkill(skill) {
        if (simState.skillPoints > 0 && isSkillUnlockable(skill)) {
            simState.skillPoints--;
            simState.learnedSkills.push(parseInt(skill.id, 10));
            updateSimUI();
            updateSkillStates();
            saveSimState();
        }
    }
    
    function addExperience(amount) {
        if (amount <= 0) return;
        simState.exp += amount;
        
        let expForNextLevel = calculateExpForLevel(simState.level);
        while (simState.exp >= expForNextLevel && expForNextLevel > 0) {
            simState.exp -= expForNextLevel;
            simState.level++;
            simState.skillPoints++;
            expForNextLevel = calculateExpForLevel(simState.level);
        }
        
        updateSimUI();
        updateSkillStates();
        saveSimState();
    }

    const calculateExpForLevel = (level) => {
        if (level <= 1) return 75;
        const l = level - 1;
        const baseExp = Math.floor((50 / 3) * (Math.pow(l, 3) - 6 * Math.pow(l, 2) + 17 * l - 12));
        const modifier = (currentTree && currentTree.exp_modifier) ? parseFloat(currentTree.exp_modifier) : 1.0;
        const finalExp = Math.floor(baseExp * modifier);
        return Math.max(1, finalExp);
    };

    function prestigeReset() {
        if (!confirm('Are you sure you want to reset this tree? You will gain one Prestige Point.')) return;
        simState.prestigePoints++;
        resetSimulation();
    }

    function resetSimulation() {
        simState.level = 1;
        simState.exp = 0;
        simState.skillPoints = simState.prestigePoints;
        simState.learnedSkills = [];
        updateSimUI();
        updateSkillStates();
        saveSimState();
    }

    function saveSimState() {
        if (currentTree) {
            localStorage.setItem(`simState_${currentTree.id}`, JSON.stringify(simState));
        }
    }

    function loadSimState() {
        const defaultState = { level: 1, exp: 0, skillPoints: 0, prestigePoints: 0, learnedSkills: [] };
        if (currentTree) {
            const saved = localStorage.getItem(`simState_${currentTree.id}`);
            simState = saved ? JSON.parse(saved) : defaultState;
        } else {
            simState = defaultState;
        }
        updateSimUI();
        updateSkillStates();
    }
    
    function updateSimUI() {
        skillPointsDisplay.textContent = simState.skillPoints;
        prestigePointsDisplay.textContent = simState.prestigePoints;
        levelDisplay.textContent = `LEVEL: ${simState.level}`;
        
        const expForNextLevel = calculateExpForLevel(simState.level);
        const progress = expForNextLevel > 0 ? (simState.exp / expForNextLevel) * 100 : 100;
        
        expBarProgress.style.width = `${progress}%`;
        expBarText.textContent = `${simState.exp} / ${expForNextLevel} EXP`;
    }

    // --- Import / Export ---
    function exportTree() {
        if (!currentTree) {
            showToast('No tree selected to export.', 'error');
            return;
        }
        const dataToExport = {
            tree: currentTree,
            skills: skills
        };
        const jsonString = JSON.stringify(dataToExport, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${currentTree.name.replace(/\s+/g, '_')}_skill_tree.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showToast('Tree exported successfully!', 'success');
    }

    function importTree(e) {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = async (event) => {
            try {
                const importedData = JSON.parse(event.target.result);
                if (!importedData.tree || !importedData.skills) {
                    throw new Error('Invalid JSON format for skill tree.');
                }
                
                // We'll create a new tree with the imported data
                const newName = `${importedData.tree.name} (Imported)`;
                const createResponse = await apiCall('create_tree', { name: newName, color: importedData.tree.color });
                const newTreeId = createResponse.new_id;

                if (!newTreeId) {
                    throw new Error('Failed to create new tree on server.');
                }

                // Prepare skills for pushing. Server will re-assign IDs.
                const skillsToPush = importedData.skills.map(skill => {
                    // Remove original IDs, server will generate new ones
                    const { id, tree_id, ...rest } = skill;
                    return rest;
                });
                
                // Create a temporary tree object for the push call
                const tempTree = {
                    id: newTreeId,
                    name: newName,
                    color: importedData.tree.color,
                    exp_modifier: importedData.tree.exp_modifier
                };

                await apiCall('push_tree', { tree: tempTree, skills: skillsToPush });

                showToast(`Tree "${newName}" imported successfully!`, 'success');
                await loadSkillTrees();
                treeSelector.value = newTreeId;
                await selectTree(newTreeId);

            } catch (error) {
                showToast(`Import failed: ${error.message}`, 'error');
            } finally {
                // Reset file input to allow importing the same file again
                importFileInput.value = '';
            }
        };
        reader.readAsText(file);
    }


    // --- Editor Logic ---
    function openSkillEditor(skill = null) {
        const isNew = !skill;
        skillEditorModal.dataset.currentSkillId = isNew ? '' : skill.id;

        document.getElementById('editor-modal-title').textContent = isNew ? 'Create New Skill' : `Edit: ${skill.name}`;
        document.getElementById('editor-save-btn').textContent = isNew ? 'Create Skill' : 'Save Changes';

        document.getElementById('skill-name-input').value = isNew ? '' : skill.name;
        document.getElementById('skill-level-req-input').value = isNew ? 1 : skill.level_req;
        document.getElementById('skill-icon-url-input').value = isNew ? '' : skill.icon_url || '';
        document.getElementById('skill-description-input').value = isNew ? '' : skill.description || '';
        document.getElementById('skill-effects-input').value = isNew ? '' : skill.effects || '';
        document.getElementById('editor-delete-btn').style.display = isNew ? 'none' : 'flex';

        populateDependencyControls(skill);
        skillEditorModal.classList.add('active');
    }

    function saveSkill() {
        const skillId = skillEditorModal.dataset.currentSkillId;
        const isNew = !skillId;

        const skillData = {
            id: skillId ? parseInt(skillId, 10) : null,
            tree_id: currentTree.id,
            name: document.getElementById('skill-name-input').value,
            level_req: parseInt(document.getElementById('skill-level-req-input').value, 10),
            icon_url: document.getElementById('skill-icon-url-input').value,
            description: document.getElementById('skill-description-input').value,
            effects: document.getElementById('skill-effects-input').value,
            prerequisites: Array.from(document.querySelectorAll('#prerequisites-container .dependency-item')).map(el => parseInt(el.dataset.id, 10)),
            lockouts: Array.from(document.querySelectorAll('#lockouts-container .dependency-item')).map(el => parseInt(el.dataset.id, 10)),
        };

        if (isNew) {
            skillData.pos_x = 100;
            skillData.pos_y = 100;
        } else {
            const existingSkill = skills.find(s => s.id == skillId);
            skillData.pos_x = existingSkill.pos_x;
            skillData.pos_y = existingSkill.pos_y;
        }

        apiCall('save_skill', { skill: skillData })
            .then(async () => {
                showToast(isNew ? 'Skill created!' : 'Skill saved!', 'success');
                skillEditorModal.classList.remove('active');
                await selectTree(currentTree.id);
            });
    }

    function deleteSkill() {
         const skillId = skillEditorModal.dataset.currentSkillId;
         if (!skillId) return;

         if (confirm('Are you sure you want to permanently delete this skill?')) {
             apiCall('delete_skill', { id: skillId })
                 .then(async () => {
                     showToast('Skill deleted!', 'success');
                     skillEditorModal.classList.remove('active');
                     await selectTree(currentTree.id);
                 });
         }
    }

    function populateDependencyControls(skill) {
        const prereqContainer = document.getElementById('prerequisites-container');
        const lockoutContainer = document.getElementById('lockouts-container');
        const prereqSelect = document.getElementById('prerequisite-select');
        const lockoutSelect = document.getElementById('lockout-select');
        
        prereqContainer.innerHTML = '';
        lockoutContainer.innerHTML = '';
        prereqSelect.innerHTML = '<option value="">Add prerequisite...</option>';
        lockoutSelect.innerHTML = '<option value="">Add lockout...</option>';

        const currentSkillId = skill ? parseInt(skill.id) : null;

        skills.forEach(s => {
            if (parseInt(s.id) !== currentSkillId) {
                const option = `<option value="${s.id}">${s.name}</option>`;
                prereqSelect.innerHTML += option;
                lockoutSelect.innerHTML += option;
            }
        });

        if (skill) {
            (skill.prerequisites || []).forEach(id => addDependencyItem(id, 'prerequisite'));
            (skill.lockouts || []).forEach(id => addDependencyItem(id, 'lockout'));
        }
    }

    function addDependency(type) {
        const select = document.getElementById(`${type}-select`);
        const skillId = parseInt(select.value, 10);
        if (!skillId) return;
        
        const container = document.getElementById(`${type}s-container`);
        if (container.querySelector(`.dependency-item[data-id="${skillId}"]`)) return;

        addDependencyItem(skillId, type);
        select.value = '';
    }

    function addDependencyItem(skillId, type) {
        const skill = skills.find(s => s.id == skillId);
        if (!skill) return;

        const container = document.getElementById(`${type}s-container`);
        const item = document.createElement('div');
        item.className = 'dependency-item';
        item.dataset.id = skillId;
        item.innerHTML = `<span>${skill.name}</span><button>x</button>`;
        item.querySelector('button').onclick = () => item.remove();
        container.appendChild(item);
    }
    
    // --- UI Helpers ---
    function updateTreeSelector() {
        const lastSelectedId = treeSelector.value;
        treeSelector.innerHTML = '';
        skillTrees.forEach(tree => {
            const option = document.createElement('option');
            option.value = tree.id;
            option.textContent = tree.name;
            treeSelector.appendChild(option);
        });
        if (skillTrees.some(t => t.id == lastSelectedId)) {
            treeSelector.value = lastSelectedId;
        }
    }

    function showSkillDetails(skill) {
        document.getElementById('details-modal-title').textContent = skill.name;
        document.getElementById('details-modal-description').textContent = skill.description || 'No description provided.';
        document.getElementById('details-modal-effects').textContent = skill.effects || 'No effects listed.';
        document.getElementById('details-modal-level').textContent = skill.level_req;
        
        const unlockBtn = document.getElementById('details-unlock-btn');
        const editBtn = document.getElementById('details-edit-btn');
        
        const canUnlock = isSkillUnlockable(skill) && simState.skillPoints > 0;
        unlockBtn.disabled = !canUnlock;
        
        const newUnlockBtn = unlockBtn.cloneNode(true);
        unlockBtn.parentNode.replaceChild(newUnlockBtn, unlockBtn);
        newUnlockBtn.addEventListener('click', () => {
            learnSkill(skill);
            skillDetailsModal.classList.remove('active');
        });
        
        const newEditBtn = editBtn.cloneNode(true);
        editBtn.parentNode.replaceChild(newEditBtn, editBtn);
        newEditBtn.addEventListener('click', () => {
            skillDetailsModal.classList.remove('active');
            openSkillEditor(skill);
        });

        skillDetailsModal.classList.add('active');
    }

    function createNewTree() {
        const name = document.getElementById('new-tree-name-input').value;
        const color = document.getElementById('new-tree-color-input').value;
        if (!name) {
            showToast('Tree name cannot be empty.', 'error');
            return;
        }
        apiCall('create_tree', { name, color }).then(async (data) => {
            showToast('Tree created!', 'success');
            document.getElementById('new-tree-name-input').value = '';
            treeCreationModal.classList.remove('active');
            await loadSkillTrees();
            if (data.new_id) {
                treeSelector.value = data.new_id;
                await selectTree(data.new_id);
            }
        });
    }

    function deleteTree() {
        if (!currentTree) {
            showToast('No tree selected to delete.', 'error');
            return;
        }
        if (confirm(`Are you sure you want to permanently delete the "${currentTree.name}" tree and all its skills?`)) {
            apiCall('delete_tree', { id: currentTree.id }).then(async () => {
                showToast('Tree deleted!', 'success');
                localStorage.removeItem(`simState_${currentTree.id}`);
                await loadSkillTrees();
            });
        }
    }
    
    function showToast(message, type = 'success') {
        const toast = document.getElementById('toast-notification');
        toast.textContent = message;
        toast.className = 'toast';
        toast.classList.add(type, 'show');
        setTimeout(() => toast.classList.remove('show'), 3000);
    }

    init();
});

