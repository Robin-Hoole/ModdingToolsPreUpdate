//
// --- App Configuration ---
//
const API_URL = 'food_budget.php'; // The path to your PHP API file
const CALORIES_PER_LB = 4000; // Calories to cut per pound of weight loss
const FASTING_DAY_DEFICIT = 2000; // Assumed calorie deficit for a fasting day

// --- App State ---
let userId;
let settings = {
    totalIncome: 1000,
    householdSize: 4,
    calorieGoal: 2000,
    dailyBudget: 30
};
// NEW: Weight Loss State
let weightLossSettings = {
    goalLbs: 0,
    startWeight: 0,
    goalWeight: 0
};
let foodItems = []; // This will hold { id, ...data }
let calendarData = []; // Holds daily plan overrides { plan_date, excluded_item_ids, is_fasting_day }
let currentCalendarDate = new Date(); // For calendar modal
let saveSettingsTimer;
let saveItemTimer;
let saveWeightLossTimer; // NEW timer for weight loss settings

// --- DOM Elements ---
const settingsForm = document.getElementById('settings-form');
const totalIncomeInput = document.getElementById('total-income');
const householdSizeInput = document.getElementById('household-size');
const calorieGoalInput = document.getElementById('calorie-goal');
const dailyBudgetInput = document.getElementById('daily-budget');
const monthlyBudgetDisplay = document.getElementById('monthly-budget-display');

// NEW: Weight Loss DOM Elements
const weightLossForm = document.getElementById('weight-loss-form');
const weightLossGoalLbsInput = document.getElementById('weight-loss-goal-lbs');
const startWeightInput = document.getElementById('start-weight');
const goalWeightInput = document.getElementById('goal-weight');
const fastingDaysDisplay = document.getElementById('fasting-days-display');

const addItemForm = document.getElementById('add-item-form');
const addExpenseForm = document.getElementById('add-expense-form');
const foodItemList = document.getElementById('food-item-list');
const sessionIdInput = document.getElementById('session-id-input');
const loadSessionBtn = document.getElementById('load-session');
const copyShareLinkBtn = document.getElementById('copy-share-link');

// Dashboard Elements
const expenseProgressText = document.getElementById('expense-progress-text');
const expenseProgressBar = document.getElementById('expense-progress-bar');
const budgetProgressText = document.getElementById('budget-progress-text');
const budgetProgressBar = document.getElementById('budget-progress-bar');
const calorieProgressText = document.getElementById('calorie-progress-text');
const calorieProgressBar = document.getElementById('calorie-progress-bar');
const longevityProgressText = document.getElementById('longevity-progress-text');
const longevityProgressBar = document.getElementById('longevity-progress-bar');
// NEW: Weight Loss Dashboard Elements
const weightLossProgressText = document.getElementById('weight-loss-progress-text');
const weightLossProgressBar = document.getElementById('weight-loss-progress-bar');
const weightLossTooltip = document.getElementById('weight-loss-tooltip');

const totalListCostEl = document.getElementById('total-list-cost');
const totalDailyCostEl = document.getElementById('total-daily-cost');
const totalDailyCaloriesEl = document.getElementById('total-daily-calories');
const costPerPersonEl = document.getElementById('cost-per-person');

// Data Management Buttons
const exportBtn = document.getElementById('export-json');
const importInput = document.getElementById('import-json');
const exportShoppingListBtn = document.getElementById('export-shopping-list');
const clearAllBtn = document.getElementById('clear-all');

// Custom Alert Elements
const alertOverlay = document.getElementById('custom-alert-overlay');
const alertMessage = document.getElementById('custom-alert-message');
const alertButton = document.getElementById('custom-alert-button');

// Edit Modal Elements
const editModalOverlay = document.getElementById('edit-modal-overlay');
const editItemForm = document.getElementById('edit-item-form');
const editModalCancel = document.getElementById('edit-modal-cancel');
const editItemId = document.getElementById('edit-item-id');
const editFieldServings = document.getElementById('edit-field-servings');
const editFieldFoodStats = document.getElementById('edit-field-food-stats');

// Daily Meal & Full Names Modal Elements
const dailyMealList = document.getElementById('daily-meal-list');
const dailyMealTotalCalories = document.getElementById('daily-meal-total-calories');
const viewFullNamesBtn = document.getElementById('view-full-names-btn');
const fullNamesModalOverlay = document.getElementById('full-names-modal-overlay');
const fullNamesModalList = document.getElementById('full-names-modal-list');
const fullNamesModalClose = document.getElementById('full-names-modal-close');

// Calendar Elements
const miniCalendar = document.getElementById('mini-calendar');
const miniCalendarMonthYear = document.getElementById('mini-calendar-month-year');
const openCalendarBtn = document.getElementById('open-calendar-btn');
const calendarModalOverlay = document.getElementById('calendar-modal-overlay');
const calendarViewContainer = document.getElementById('calendar-view-container');
const calendarDayEditContainer = document.getElementById('calendar-day-edit-container');
const calendarPrevMonthBtn = document.getElementById('calendar-prev-month');
const calendarNextMonthBtn = document.getElementById('calendar-next-month');
const calendarMonthYear = document.getElementById('calendar-month-year');
const calendarGridLarge = document.querySelector('.calendar-grid-large');
const calendarBackBtn = document.getElementById('calendar-back-btn');
const calendarEditDayTitle = document.getElementById('calendar-edit-day-title');
const calendarDayFastingBtn = document.getElementById('calendar-day-fasting-btn');
const calendarDayEditList = document.getElementById('calendar-day-edit-list');
const calendarDayTotalCalories = document.getElementById('calendar-day-total-calories');


//
// --- Utility Functions ---
//

// Helper to get ISO date string (yyyy-mm-dd) using UTC
function getISODate(date) {
    if (date instanceof Date && !isNaN(date)) {
        const year = date.getUTCFullYear();
        const month = (date.getUTCMonth() + 1).toString().padStart(2, '0');
        const day = date.getUTCDate().toString().padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    console.error("Invalid date passed to getISODate:", date);
    return null;
}

// Helper to get all food items (used for default plan)
function getAllFoodItems() {
    return foodItems.filter(item =>
        item.calories !== null && item.servings_per_unit !== null && // Ensure it's a food item
        ((item.calories && parseInt(item.calories, 10) > 0) ||
        (item.servings_per_unit && parseInt(item.servings_per_unit, 10) > 0))
    );
}

// Helper to get default daily plan (all items with consumption > 0)
function getDefaultDailyPlan() {
    const allFood = getAllFoodItems();
    return allFood.filter(item => (parseFloat(item.consumption) || 0) > 0);
}

// Helper to get the meal plan for a specific date
function getPlanForDate(dateString) {
    if (!dateString) return { items: [], totalCalories: 0, isFasting: false };

    const dayData = calendarData.find(d => d.plan_date === dateString);

    if (dayData?.is_fasting_day) {
        return { items: [], totalCalories: 0, isFasting: true };
    }

    const defaultPlanItems = getDefaultDailyPlan();

    let finalItems = [];
    if (dayData) {
        const excludedIds = new Set(dayData.excluded_item_ids || []);
        finalItems = defaultPlanItems.filter(item => !excludedIds.has(item.id));
    } else {
        // If no specific data for the day, use the default plan
        finalItems = defaultPlanItems;
    }

    let totalCalories = 0;
    finalItems.forEach(item => {
        const consumption = parseFloat(item.consumption) || 0;
        const calories = parseInt(item.calories, 10) || 0;
        // Calculate based on household size and weekly consumption
        const servingsNeededPerWeek = (settings.householdSize * consumption);
        const servingsNeededPerDay = servingsNeededPerWeek / 7;
        totalCalories += servingsNeededPerDay * calories;
    });

    return { items: finalItems, totalCalories: Math.round(totalCalories), isFasting: false };
}


function showAlert(message) {
    alertMessage.textContent = message;
    alertOverlay.style.display = 'flex';
}

function showConfirm(message) {
    return new Promise((resolve) => {
        const modalBox = alertOverlay.querySelector('.modal-box');
        alertMessage.textContent = message;
        alertButton.style.display = 'none';
        const oldButtons = modalBox.querySelector('.confirm-buttons');
        if (oldButtons) oldButtons.remove();

        const buttonContainer = document.createElement('div');
        buttonContainer.className = 'confirm-buttons flex justify-center gap-4 mt-6';
        const confirmBtn = document.createElement('button');
        confirmBtn.textContent = 'Confirm';
        confirmBtn.className = 'bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg';
        const cancelBtn = document.createElement('button');
        cancelBtn.textContent = 'Cancel';
        cancelBtn.className = 'bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded-lg';
        buttonContainer.appendChild(cancelBtn);
        buttonContainer.appendChild(confirmBtn);
        modalBox.appendChild(buttonContainer);
        alertOverlay.style.display = 'flex';

        function closeConfirm(value) {
            buttonContainer.remove();
            alertButton.style.display = 'block';
            alertOverlay.style.display = 'none';
            resolve(value);
        }
        confirmBtn.onclick = () => closeConfirm(true);
        cancelBtn.onclick = () => closeConfirm(false);
    });
}

/** Debounce function */
function debounce(func, delay, timerStore) {
    return function(...args) {
        clearTimeout(timerStore.timer);
        timerStore.timer = setTimeout(() => {
            func.apply(this, args);
        }, delay);
    };
}

/** API request handler */
async function apiRequest(url, options = {}) {
    console.log("Making API request:", url, options.method || 'GET', options.body ? JSON.parse(options.body).action : ''); // Log API call details
    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            const errorText = await response.text();
            let errorJson;
            try { errorJson = JSON.parse(errorText); }
            // Added more detail to the error thrown if JSON parsing fails
            catch(e) { throw new Error(`HTTP error ${response.status}: ${errorText || response.statusText}`); }
            // Ensure message exists before throwing
            throw new Error(errorJson?.message || `HTTP error ${response.status}`);
        }
        const data = await response.json();
        console.log("API Response:", data); // Log successful API response
        // Check for explicit success: false from the backend
        if (data.success === false) {
            // Throw the specific message from the backend if available
            throw new Error(data.message || 'An unknown API error occurred from backend.');
        }
        return data;
    } catch (error) {
        console.error('API Request Failed:', url, options, error); // Log more context
        // Avoid duplicate alerts if showAlert is called elsewhere for the same error
        if (!alertOverlay || alertOverlay.style.display !== 'flex') {
           showAlert(`API Error: ${error.message}. Check console (F12) for more details.`);
        }
        throw error; // Re-throw to be caught by calling function if needed (like loadData)
    }
}

//
// --- Initialization ---
//
function initializeApp() {
    console.log("Initializing app...");
    const urlParams = new URLSearchParams(window.location.search);
    const urlId = urlParams.get('user_id');

    if (urlId) {
        console.log("User ID found in URL:", urlId);
        userId = urlId;
        localStorage.setItem('foodCalcUserId', userId);
    } else {
        userId = localStorage.getItem('foodCalcUserId');
        if (!userId) {
            console.log("No User ID found, generating new one.");
            userId = crypto.randomUUID();
            localStorage.setItem('foodCalcUserId', userId);
        } else {
            console.log("User ID found in localStorage:", userId);
        }
    }
    console.log("Final userId for this session:", userId);
    sessionIdInput.value = userId;

    // NEW: Load weight loss settings
    loadWeightLossSettings();
    updateWeightLossUI(); // Initial UI update for weight loss section

    loadData(); // Attempt to load data for this userId
}

//
// --- Data Loading ---
//
async function loadData() {
    if (!userId) {
        console.error("loadData called without userId.");
        return;
    }
    console.log(`Attempting to load data for userId: ${userId}`);
    try {
        const data = await apiRequest(`${API_URL}?action=get_data&user_id=${userId}`);
        console.log("Data successfully loaded:", data);
        settings = data.settings;
        foodItems = data.items;
        calendarData = data.calendar;
        updateSettingsUI();
        renderFoodList();
        updateDashboard(); // This will now also update weight loss bar
        renderMiniCalendar();
        console.log("UI updated with loaded data.");
    } catch (error) {
        // Log the detailed error from apiRequest
        console.error(`Detailed error during loadData for userId ${userId}:`, error);
        // Alert the user about the failure
        showAlert(`Failed to load session data for ID: ${userId}. The session might not exist or there was a server error. Please check the console (F12) for details and verify the session ID.`);
        // Keep the entered/current session ID in the input field for clarity
        // sessionIdInput.value = userId; // Ensure the input reflects the ID that failed
    }
}

// --- NEW: Weight Loss Settings Persistence ---
function loadWeightLossSettings() {
    const savedSettings = localStorage.getItem('weightLossSettings');
    if (savedSettings) {
        try {
            weightLossSettings = JSON.parse(savedSettings);
            // Ensure numeric types
            weightLossSettings.goalLbs = Number(weightLossSettings.goalLbs) || 0;
            weightLossSettings.startWeight = Number(weightLossSettings.startWeight) || 0;
            weightLossSettings.goalWeight = Number(weightLossSettings.goalWeight) || 0;
            console.log("Loaded weight loss settings:", weightLossSettings);
        } catch (e) {
            console.error("Failed to parse weight loss settings from localStorage:", e);
            // Reset to default if parsing fails
             weightLossSettings = { goalLbs: 0, startWeight: 0, goalWeight: 0 };
        }
    } else {
        console.log("No weight loss settings found in localStorage, using defaults.");
        // Initialize with defaults if nothing saved
        weightLossSettings = { goalLbs: 0, startWeight: 0, goalWeight: 0 };
    }
}

function saveWeightLossSettings() {
    try {
        localStorage.setItem('weightLossSettings', JSON.stringify(weightLossSettings));
        console.log("Saved weight loss settings:", weightLossSettings);
    } catch (e) {
        console.error("Failed to save weight loss settings to localStorage:", e);
        showAlert("Error saving weight loss settings. Check console (F12).");
    }
}
// Debounced version for saving
const debouncedSaveWeightLossSettings = debounce(saveWeightLossSettings, 1000, { timer: saveWeightLossTimer });


//
// --- UI Rendering & Calculations ---
//

function updateSettingsUI() {
    totalIncomeInput.value = settings.totalIncome;
    householdSizeInput.value = settings.householdSize;
    calorieGoalInput.value = settings.calorieGoal;
    dailyBudgetInput.value = settings.dailyBudget;
    monthlyBudgetDisplay.textContent = `$${(settings.dailyBudget * 30).toFixed(2)}`;
}

// NEW: Update Weight Loss UI
function updateWeightLossUI() {
    weightLossGoalLbsInput.value = weightLossSettings.goalLbs;
    startWeightInput.value = weightLossSettings.startWeight;
    goalWeightInput.value = weightLossSettings.goalWeight;
    const fastingDaysNeeded = weightLossSettings.goalLbs * 2; // 0.5 lbs per day
    fastingDaysDisplay.textContent = `${fastingDaysNeeded} days`;
}

function renderFoodList() {
    foodItemList.innerHTML = '';
    if (foodItems.length === 0) {
        foodItemList.innerHTML = `<p class="text-gray-400 md:col-span-2 text-center">No items added yet. Use a form to get started.</p>`;
        return;
    }
    // Sort items, potentially separating food and expenses visually if desired later
    foodItems.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

    foodItems.forEach(item => {
        const price = parseFloat(item.price);
        const quantity = parseInt(item.quantity, 10);
        // Check if it's a food item (has food-specific properties, not null)
        const isFoodItem = item.servings_per_unit !== null && item.calories !== null && item.consumption !== null;
        const itemCard = document.createElement('div');
        // Apply different border based on type
        itemCard.className = `group bg-gray-950/60 backdrop-blur-sm border ${isFoodItem ? 'border-gray-800' : 'border-teal-700'} rounded-lg overflow-hidden flex flex-col relative glowing-card`;
        let statsHtml = '';
        let totalItemCost = price * quantity;

        if (isFoodItem && parseInt(item.servings_per_unit, 10) > 0) { // Add check for servings > 0
            const servingsPerUnit = parseInt(item.servings_per_unit, 10);
            const consumption = parseFloat(item.consumption) || 0; // Default to 0 if null/undefined
            const calories = parseInt(item.calories, 10) || 0;
            const pricePerServing = (price / servingsPerUnit) || 0;
            const servingsNeededPerWeek = (settings.householdSize * consumption) || 0;
            const daysItemWillLast = (servingsPerUnit > 0 && servingsNeededPerWeek > 0)
                                      ? ((servingsPerUnit * quantity) / servingsNeededPerWeek * 7)
                                      : 0;
            statsHtml = `
                <div class="mt-4 grid grid-cols-3 gap-2 text-center">
                    <div class="relative has-tooltip"><p class="text-xs text-gray-400">Price/Serving</p><p class="text-sm font-medium text-white">$${pricePerServing.toFixed(2)}</p><span class="tooltip">Unit Price / Servings per Unit</span></div>
                    <div class="relative has-tooltip"><p class="text-xs text-gray-400">Cals/Serving</p><p class="text-sm font-medium text-white">${calories} kcal</p><span class="tooltip">Calories per single serving.</span></div>
                    <div class="relative has-tooltip"><p class="text-xs text-gray-400">Lasts (Total)</p><p class="text-sm font-medium text-white">${daysItemWillLast.toFixed(0)} days</p><span class="tooltip">How long your total quantity will last.</span></div>
                </div>`;
        } else {
             // Handle non-food items or food items with 0 servings (display total cost)
             statsHtml = `<div class="mt-4 text-center"><p class="text-xs text-gray-400">Total Item Cost</p><p class="text-sm font-medium text-white">$${totalItemCost.toFixed(2)}</p></div>`;
        }

        itemCard.innerHTML = `
            <div class="absolute top-2 right-2 z-10 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <div class="relative has-tooltip"><button data-id="${item.id}" class="edit-btn bg-blue-600 hover:bg-blue-500 text-white p-2 rounded-full shadow-lg"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" /></svg></button><span class="tooltip">Edit Item</span></div>
                <div class="relative has-tooltip"><button data-id="${item.id}" class="delete-btn bg-red-700 hover:bg-red-600 text-white p-2 rounded-full shadow-lg"><svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clip-rule="evenodd" /></svg></button><span class="tooltip">Delete Item</span></div>
            </div>
            <img src="${item.image_url || 'https://placehold.co/600x400/1a1a1a/333333?text=No+Image'}" onerror="this.src='https://placehold.co/600x400/1a1a1a/333333?text=Image+Error'" alt="${item.name}" class="w-full h-40 object-cover">
            <div class="p-4 flex-grow">
                <h3 class="text-lg font-semibold ${isFoodItem ? 'text-white' : 'text-teal-300'} truncate pr-16">${item.name}</h3>
                <p class="text-2xl font-bold ${isFoodItem ? 'text-blue-300' : 'text-teal-300'}">$${price.toFixed(2)} <span class="text-sm font-normal text-gray-400">/ unit</span></p>
                ${statsHtml}
            </div>
            <div class="p-4 bg-gray-900/50 flex gap-4 items-center justify-between">
                <div class="relative has-tooltip"><label class="text-xs text-gray-400">Quantity</label><div class="custom-number-input w-28"><button type="button" class="decrement-btn" data-target="quantity-input-${item.id}">-</button><input type="number" min="1" value="${quantity}" data-id="${item.id}" id="quantity-input-${item.id}" class="quantity-input w-full text-sm"><button type="button" class="increment-btn" data-target="quantity-input-${item.id}">+</button></div><span class="tooltip">How many units of this item you have.</span></div>
                <div class="relative has-tooltip mt-4"><a href="${item.store_url || '#'}" target="_blank" rel="noopener noreferrer" class="text-center bg-gray-600 hover:bg-gray-500 text-white text-sm font-bold py-2 px-3 rounded-md transition duration-200 ${!item.store_url ? 'opacity-50 cursor-not-allowed' : ''}">Store Link</a><span class="tooltip">Go to the store page (if provided).</span></div>
            </div>`;
        foodItemList.appendChild(itemCard);
    });
}

// Renders today's plan based on calendar data
function renderDailyMealPlan() {
    let dailyMealHtml = '';
    let fullNamesHtml = '';
    const today = new Date(); // Use local time for "today"
    const todayString = getISODate(today);
    const plan = getPlanForDate(todayString);

    if (plan.isFasting) {
        dailyMealHtml = '<p class="text-gray-400 text-sm">Today is a fasting day.</p>';
        fullNamesHtml = '<p class="text-gray-400 text-sm">Today is a fasting day.</p>';
    } else if (plan.items.length === 0) {
        dailyMealHtml = '<p class="text-gray-400 text-sm">No items planned for today.</p>';
        fullNamesHtml = '<p class="text-gray-400 text-sm">No items planned for today.</p>';
    } else {
        plan.items.forEach(item => {
            const servingsPerUnit = parseInt(item.servings_per_unit, 10) || 1; // Avoid division by zero
            const consumption = parseFloat(item.consumption) || 0;
            const quantity = parseInt(item.quantity, 10) || 1;
            const servingsNeededPerWeek = (settings.householdSize * consumption) || 0;
            const servingsNeededPerDay = servingsNeededPerWeek / 7;
            const daysItemWillLast = (servingsPerUnit > 0 && servingsNeededPerWeek > 0)
                                      ? ((servingsPerUnit * quantity) / servingsNeededPerWeek * 7)
                                      : 0;
            dailyMealHtml += `<div class="flex justify-between items-center text-sm"><span class="text-white truncate pr-2">${item.name}</span><span class="text-gray-400 text-xs text-right flex-shrink-0">${servingsNeededPerDay.toFixed(1)} srv <span class="text-blue-400 ml-1">(${daysItemWillLast.toFixed(0)}d)</span></span></div>`;
            fullNamesHtml += `<div class="flex justify-between items-center py-2 border-b border-gray-700"><div><p class="text-white font-medium">${item.name}</p><p class="text-sm text-blue-400">${servingsNeededPerDay.toFixed(1)} servings / day</p></div><span class="text-gray-300 text-sm text-right flex-shrink-0">Lasts: ${daysItemWillLast.toFixed(0)} days</span></div>`;
        });
    }
    dailyMealList.innerHTML = dailyMealHtml;
    fullNamesModalList.innerHTML = fullNamesHtml; // Update full names modal content too
    dailyMealTotalCalories.textContent = `${plan.totalCalories.toFixed(0)} kcal`;
}

// NEW: Calculate current month's deficit for weight loss
function calculateCurrentMonthDeficit() {
    let currentMonthDeficit = 0;
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth(); // 0-indexed
    const todayDate = today.getDate(); // Day of the month (1-31)

    // Calculate household daily calorie goal once
    const householdDailyCalorieGoal = settings.calorieGoal * settings.householdSize;

    // Iterate from the 1st of the month up to today
    for (let day = 1; day <= todayDate; day++) {
        const date = new Date(Date.UTC(currentYear, currentMonth, day)); // Use UTC
        const dateString = getISODate(date);
        const dayData = calendarData.find(d => d.plan_date === dateString);

        if (dayData?.is_fasting_day) {
            currentMonthDeficit += FASTING_DAY_DEFICIT;
        } else {
            // Get planned calories for the day (even if no specific dayData exists, it uses default)
            const plan = getPlanForDate(dateString);
            const actualCaloriesForDay = plan.totalCalories;

            // Calculate deficit only if goal is positive and actual is less than goal
            if (householdDailyCalorieGoal > 0 && actualCaloriesForDay < householdDailyCalorieGoal) {
                const deficit = householdDailyCalorieGoal - actualCaloriesForDay;
                currentMonthDeficit += deficit;
            }
        }
    }
    return currentMonthDeficit;
}


// Updated dashboard calculation
function updateDashboard() {
    let totalDailyCost = 0, totalDailyCalories = 0, totalLongevityDays = 0, totalListCost = 0, totalOneTimeExpenses = 0, totalMonthlyFoodCost = 0;
    const totalHouseholdCalorieGoal = settings.calorieGoal * settings.householdSize;
    const onlyFoodItems = getAllFoodItems();

    foodItems.forEach(item => {
        const price = parseFloat(item.price);
        const quantity = parseInt(item.quantity, 10);
        totalListCost += price * quantity;

        // Check if it's a food item (properties are not null)
        const isFoodItem = item.servings_per_unit !== null && item.calories !== null && item.consumption !== null;

        if (isFoodItem) {
            const servingsPerUnit = parseInt(item.servings_per_unit, 10) || 1; // Avoid div by zero
            const consumption = parseFloat(item.consumption) || 0;
            const calories = parseInt(item.calories, 10) || 0;
            const servingsNeededPerWeek = (settings.householdSize * consumption) || 0;

            if (servingsNeededPerWeek > 0 && servingsPerUnit > 0) {
                const servingsNeededPerDay = servingsNeededPerWeek / 7;
                const pricePerServing = price / servingsPerUnit;
                totalDailyCost += servingsNeededPerDay * pricePerServing;
                totalDailyCalories += servingsNeededPerDay * calories;
                const daysItemWillLast = ((servingsPerUnit * quantity) / servingsNeededPerWeek * 7) || 0;
                totalLongevityDays += daysItemWillLast;
            }
        } else {
            // It's an expense item
            totalOneTimeExpenses += price * quantity;
        }
    });

    // --- Standard Dashboard Calculations ---
    totalMonthlyFoodCost = totalDailyCost * 30;
    const totalMonthlyExpenses = totalMonthlyFoodCost + totalOneTimeExpenses;
    const costPerPerson = (settings.householdSize > 0) ? (totalDailyCost / settings.householdSize) : 0;
    const avgLongevity = onlyFoodItems.length > 0 ? totalLongevityDays / onlyFoodItems.length : 0;

    totalListCostEl.textContent = `$${totalListCost.toFixed(2)}`;
    totalDailyCostEl.textContent = `$${totalDailyCost.toFixed(2)}`;
    totalDailyCaloriesEl.textContent = `${Math.round(totalDailyCalories)}`; // Use Math.round
    costPerPersonEl.textContent = `$${costPerPerson.toFixed(2)}`;

    // Expense Bar
    const totalIncome = settings.totalIncome || 0;
    const expensePercent = (totalIncome > 0) ? Math.min(100, (totalMonthlyExpenses / totalIncome) * 100) : 0;
    expenseProgressText.textContent = `$${totalMonthlyExpenses.toFixed(2)} / $${Number(totalIncome).toFixed(2)}`;
    expenseProgressBar.style.width = `${expensePercent}%`;
    expenseProgressBar.className = `progress-bar-inner h-2.5 rounded-full ${expensePercent > 100 ? 'bg-red-500' : (expensePercent > 80 ? 'bg-yellow-500' : 'bg-purple-500')}`;

    // Budget Bar
    const budgetPercent = (settings.dailyBudget > 0) ? Math.min(100, (totalDailyCost / settings.dailyBudget) * 100) : 0;
    budgetProgressText.textContent = `$${totalDailyCost.toFixed(2)} / $${Number(settings.dailyBudget).toFixed(2)}`;
    budgetProgressBar.style.width = `${budgetPercent}%`;
    budgetProgressBar.className = `progress-bar-inner h-2.5 rounded-full ${budgetPercent > 100 ? 'bg-red-500' : (budgetPercent > 80 ? 'bg-yellow-500' : 'bg-green-500')}`;

    // Calorie Bar (Default Daily Consumption vs Goal)
    const caloriePercent = (totalHouseholdCalorieGoal > 0) ? Math.min(100, (totalDailyCalories / totalHouseholdCalorieGoal) * 100) : 0;
    calorieProgressText.textContent = `${Math.round(totalDailyCalories)} / ${totalHouseholdCalorieGoal.toFixed(0)} kcal`;
    calorieProgressBar.style.width = `${caloriePercent}%`;
    // Note: Calorie bar color logic seems inverted (red is low). Corrected:
    calorieProgressBar.className = `progress-bar-inner h-2.5 rounded-full ${caloriePercent < 80 ? 'bg-red-500' : (caloriePercent < 100 ? 'bg-yellow-500' : 'bg-green-500')}`;


    // Longevity Bar
    const longevityPercent = Math.min(100, (avgLongevity / 30) * 100) || 0;
    longevityProgressText.textContent = `${avgLongevity.toFixed(0)} days (avg)`;
    longevityProgressBar.style.width = `${longevityPercent}%`;
    longevityProgressBar.className = 'progress-bar-inner bg-blue-500 h-2.5 rounded-full';

    // --- NEW: Weight Loss Bar Calculation & Update ---
    const totalDeficitGoal = weightLossSettings.goalLbs * CALORIES_PER_LB;
    let currentMonthDeficit = 0;
    let weightLossPercent = 0;
    let tooltipDateRange = "N/A";

    if (totalDeficitGoal > 0) {
        currentMonthDeficit = calculateCurrentMonthDeficit();
        weightLossPercent = Math.min(100, (currentMonthDeficit / totalDeficitGoal) * 100);

        // Update tooltip date range
        const today = new Date();
        const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        const startDateStr = startOfMonth.toLocaleDateString('en-US', { month: 'numeric', day: 'numeric'});
        const todayDateStr = today.toLocaleDateString('en-US', { month: 'numeric', day: 'numeric'});
        tooltipDateRange = `${startDateStr} to ${todayDateStr}`;

    } else {
        // Reset if no goal is set
        currentMonthDeficit = 0;
        weightLossPercent = 0;
    }

    weightLossProgressText.textContent = `${Math.round(currentMonthDeficit)} / ${totalDeficitGoal} kcal`;
    weightLossProgressBar.style.width = `${weightLossPercent}%`;
    weightLossTooltip.textContent = `Calories cut from ${tooltipDateRange} vs. total goal.`;


    // --- Update daily meal plan display ---
    renderDailyMealPlan();
}


// --- Calendar Rendering Functions ---

function renderMiniCalendar() {
    miniCalendar.innerHTML = ''; // Clear existing
    const today = new Date(); // Use local time for "today"
    const year = today.getFullYear();
    const month = today.getMonth();
    const todayString = getISODate(today); // Use helper function for UTC yyyy-mm-dd
    const firstDayOfMonth = new Date(Date.UTC(year, month, 1)); // Use UTC for consistency
    const startDayOfWeek = firstDayOfMonth.getUTCDay(); // 0 = Sunday
    const daysInMonth = new Date(Date.UTC(year, month + 1, 0)).getUTCDate(); // Use UTC

    // Update mini calendar month/year display
    if (miniCalendarMonthYear) {
         miniCalendarMonthYear.textContent = today.toLocaleString('default', { month: 'short', year: 'numeric' });
    }

    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    dayNames.forEach(name => {
        const dayNameEl = document.createElement('div');
        dayNameEl.className = 'day-name';
        dayNameEl.textContent = name;
        miniCalendar.appendChild(dayNameEl);
    });

    let dayCounter = 1;
    // Render enough cells for 6 weeks (42 cells) max
    for (let i = 0; i < 42; i++) {
        const cell = document.createElement('div');
        cell.className = 'day-cell';

        if (i >= startDayOfWeek && dayCounter <= daysInMonth) {
            cell.textContent = dayCounter;
            // Use UTC methods when creating date for consistent string generation
            const date = new Date(Date.UTC(year, month, dayCounter));
            const dateString = getISODate(date); // Use helper function

            // Highlight today
            if (dateString === todayString) {
                cell.classList.add('current-day');
            }

            // Add indicator dot
            const plan = getPlanForDate(dateString);
            const dot = document.createElement('div');
            dot.className = 'indicator-dot';
            if (plan.isFasting) {
                dot.classList.add('fasting');
            } else { // Only show eating dot if not fasting AND items are planned
                 const dayData = calendarData.find(d => d.plan_date === dateString);
                 // Check if there's specific data OR if the default plan has items
                 if ((dayData && dayData.excluded_item_ids.length < getDefaultDailyPlan().length) || (!dayData && getDefaultDailyPlan().length > 0)) {
                      dot.classList.add('eating');
                 }
            }
             // Only append dot if eating or fasting was explicitly set or implied
             if (dot.classList.contains('fasting') || dot.classList.contains('eating')) {
                cell.appendChild(dot);
             }
            dayCounter++;
        } else {
            cell.classList.add('other-month'); // Keep cell for grid structure
        }
        miniCalendar.appendChild(cell);
    }
}


function renderFullCalendar() {
    // Clear ALL children (headers and days) before re-rendering
    calendarGridLarge.innerHTML = '';

    // Add day headers first
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    dayNames.forEach(name => {
        const dayNameEl = document.createElement('div');
        dayNameEl.className = 'calendar-header';
        dayNameEl.textContent = name;
        calendarGridLarge.appendChild(dayNameEl);
    });


    calendarMonthYear.textContent = currentCalendarDate.toLocaleString('default', { month: 'long', year: 'numeric' });
    const year = currentCalendarDate.getFullYear();
    const month = currentCalendarDate.getMonth();
    // Use UTC for calculations to avoid timezone issues affecting month boundaries/day numbers
    const firstDayOfMonth = new Date(Date.UTC(year, month, 1));
    const lastDayOfMonth = new Date(Date.UTC(year, month + 1, 0));
    const startDayOfWeek = firstDayOfMonth.getUTCDay(); // 0 = Sunday
    const totalDays = lastDayOfMonth.getUTCDate();
    const today = new Date(); // Use local for "today" highlight comparison
    const todayString = getISODate(today); // Use helper

    // Add previous month's trailing days
    const prevMonthLastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
    for (let i = startDayOfWeek - 1; i >= 0; i--) {
        const cell = document.createElement('div');
        cell.className = 'calendar-day-large other-month';
        // Display the day number from the previous month
        cell.innerHTML = `<span class="calendar-day-label">${prevMonthLastDay - i}</span>`;
        calendarGridLarge.appendChild(cell);
    }

    // Add current month's days
    for (let i = 1; i <= totalDays; i++) {
        const cell = document.createElement('div');
        cell.className = 'calendar-day-large';
        // Use UTC date for consistent string generation
        const date = new Date(Date.UTC(year, month, i));
        const dateString = getISODate(date); // Use helper
        cell.dataset.date = dateString;

        // Highlight today
        if (dateString === todayString) {
            cell.classList.add('current-day');
        }

        const plan = getPlanForDate(dateString);
        let calorieText = 'Default'; // Show 'Default' if no specific plan and default has items
        let calorieClass = 'eating'; // Assume eating default unless specified

        const dayData = calendarData.find(d => d.plan_date === dateString);

        if (dayData?.is_fasting_day) {
            calorieText = 'Fasting';
            calorieClass = 'fasting';
        } else if (dayData) { // Specific plan exists (not fasting)
             calorieText = `${plan.totalCalories.toFixed(0)} kcal`;
             calorieClass = 'eating';
        } else if (getDefaultDailyPlan().length === 0) { // No specific plan, default is empty
             calorieText = '0 kcal';
             calorieClass = 'fasting'; // Style like fasting if 0 cal default
        } else { // No specific plan, using non-empty default
             calorieText = `${plan.totalCalories.toFixed(0)} kcal`; // Show calculated default calories
             calorieClass = 'eating';
             // Optionally add a visual indicator that it's the default plan
             // calorieText += ' (D)';
        }


        cell.innerHTML = `
            <span class="calendar-day-label">${i}</span>
            <span class="calendar-day-calories ${calorieClass}">${calorieText}</span>`;

        // Make cell clickable
        cell.addEventListener('click', () => showDayEditView(dateString));
        calendarGridLarge.appendChild(cell);
    }

     // Add next month's leading days
     const totalGridCellsRendered = startDayOfWeek + totalDays;
     // Calculate how many cells needed to fill up to 6 weeks (42 cells total)
     const remainingCells = 42 - totalGridCellsRendered;

     for (let i = 1; i <= remainingCells; i++) {
        const cell = document.createElement('div');
        cell.className = 'calendar-day-large other-month';
        // Display the day number from the next month
        cell.innerHTML = `<span class="calendar-day-label">${i}</span>`;
        calendarGridLarge.appendChild(cell);
     }
}


// --- Calendar Modal View Switching ---

/**
 * Recalculates the total calories in the "Edit Day" view based on checked items.
 */
function recalculateDayEditTotalCalories() {
    let currentDayTotalCalories = 0;
    const allDefaultItems = getDefaultDailyPlan();
    const checkboxes = calendarDayEditList.querySelectorAll('.day-item-toggle');

    checkboxes.forEach(cb => {
        if (cb.checked) {
            const itemId = Number(cb.dataset.itemId);
            const item = allDefaultItems.find(i => i.id === itemId);
            if (item) {
                const consumption = parseFloat(item.consumption) || 0;
                const calories = parseInt(item.calories, 10) || 0;
                const servingsNeededPerWeek = (settings.householdSize * consumption);
                const servingsNeededPerDay = servingsNeededPerWeek / 7;
                const caloriesForDay = servingsNeededPerDay * calories;
                currentDayTotalCalories += caloriesForDay;
            }
        }
    });

    calendarDayTotalCalories.textContent = `${Math.round(currentDayTotalCalories)} kcal`;
}


function showCalendarView() {
    calendarDayEditContainer.classList.add('hidden');
    calendarViewContainer.classList.remove('hidden');
    renderFullCalendar(); // Re-render to show any updates made in edit view
    renderMiniCalendar(); // Also update mini calendar dots
}

function showDayEditView(dateString) {

    calendarViewContainer.classList.add('hidden');
    calendarDayEditContainer.classList.remove('hidden');

    // Use UTC date for calculations, but display in local format
    const date = new Date(dateString + 'T00:00:00Z'); // Treat dateString as UTC
    calendarEditDayTitle.textContent = date.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', timeZone: 'UTC' }); // Display as UTC date
    calendarDayEditList.innerHTML = ''; // Clear previous list
    calendarDayEditList.dataset.date = dateString; // Store date for saving

    const allDefaultItems = getDefaultDailyPlan();
    // Get existing data or create default placeholder
    const dayData = calendarData.find(d => d.plan_date === dateString) || { plan_date: dateString, excluded_item_ids: [], is_fasting_day: false };
    const excludedIds = new Set(dayData.excluded_item_ids);
    let currentDayTotalCalories = 0;

    if (dayData.is_fasting_day) {
        calendarDayFastingBtn.textContent = 'Mark as Eating';
        calendarDayFastingBtn.classList.replace('bg-red-600', 'bg-green-600');
        calendarDayFastingBtn.classList.replace('hover:bg-red-500', 'hover:bg-green-500');
        calendarDayEditList.innerHTML = '<p class="text-gray-400 text-center p-4">This day is marked as a fasting day. No items will be consumed.</p>';
        currentDayTotalCalories = 0; // Explicitly set to 0
    } else {
        calendarDayFastingBtn.textContent = 'Mark as Fasting';
        calendarDayFastingBtn.classList.replace('bg-green-600', 'bg-red-600');
        calendarDayFastingBtn.classList.replace('hover:bg-green-500', 'hover:bg-red-500');

        if (allDefaultItems.length === 0) {
             calendarDayEditList.innerHTML = '<p class="text-gray-400 text-center p-4">You have no food items with consumption &gt; 0 in your list.</p>';
        } else {
            allDefaultItems.forEach(item => {
                const isChecked = !excludedIds.has(item.id);
                const consumption = parseFloat(item.consumption) || 0;
                const calories = parseInt(item.calories, 10) || 0;
                const servingsNeededPerWeek = (settings.householdSize * consumption);
                const servingsNeededPerDay = servingsNeededPerWeek / 7;
                const caloriesForDay = servingsNeededPerDay * calories;

                if (isChecked) {
                    currentDayTotalCalories += caloriesForDay;
                }

                const label = document.createElement('label');
                label.innerHTML = `
                    <input type="checkbox" class="day-item-toggle" data-item-id="${item.id}" ${isChecked ? 'checked' : ''}>
                    <div class="item-info">
                        <span class="item-name">${item.name}</span>
                        <span class="item-details">${servingsNeededPerDay.toFixed(1)} srv / ${Math.round(caloriesForDay)} kcal</span>
                    </div>`;
                calendarDayEditList.appendChild(label);
            });
        }
    }
    calendarDayTotalCalories.textContent = `${Math.round(currentDayTotalCalories)} kcal`;
}


// --- Calendar Save Logic ---
async function saveCalendarDay(dateString) {
    // Find or create day data in local state
    let dayData = calendarData.find(d => d.plan_date === dateString);
    if (!dayData) {
        dayData = { plan_date: dateString, excluded_item_ids: [], is_fasting_day: false };
        calendarData.push(dayData); // Add to local state if new
    }

    // Update data based on current state of edit view (if it matches the date being saved)
    if (calendarDayEditList.dataset.date === dateString) {
        const excluded_item_ids = [];
        const checkboxes = calendarDayEditList.querySelectorAll('.day-item-toggle');
        // Only update excluded items if NOT fasting
        if (!dayData.is_fasting_day) {
             checkboxes.forEach(cb => {
                if (!cb.checked) {
                    excluded_item_ids.push(Number(cb.dataset.itemId));
                }
             });
        } else {
            // If fasting, clear excluded items (they don't apply)
            excluded_item_ids.length = 0;
        }
        dayData.excluded_item_ids = excluded_item_ids;
        // is_fasting_day is updated directly by its button handler and saved here
    }
    // No 'else' needed, if not editing this date, we save its current state from calendarData


    try {
        const data = await apiRequest(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'save_calendar_day',
                user_id: userId,
                plan_date: dayData.plan_date,
                excluded_item_ids: dayData.excluded_item_ids,
                is_fasting_day: dayData.is_fasting_day
            })
        });

        // Update local calendar data with confirmed saved state from response
        const index = calendarData.findIndex(d => d.plan_date === data.saved_day.plan_date);
        if (index !== -1) {
            calendarData[index] = data.saved_day; // Make sure local state matches saved state
        } else {
             // This case should technically be covered by the push earlier, but as a fallback:
             calendarData.push(data.saved_day);
        }


        // Refresh necessary UI parts
        updateDashboard(); // Recalculate dashboard including weight loss bar
        renderMiniCalendar(); // Update indicator dots

        // If the large calendar is currently visible (in calendar view mode), update it too
        if (calendarModalOverlay.style.display === 'flex' && calendarDayEditContainer.classList.contains('hidden')) {
             renderFullCalendar();
        }
        // If the day edit view is visible FOR THIS DATE, ensure it reflects the latest saved state
        else if (calendarModalOverlay.style.display === 'flex' && !calendarDayEditContainer.classList.contains('hidden') && calendarDayEditList.dataset.date === dateString) {
            // Re-render the edit view to ensure consistency, especially if fasting state changed
             showDayEditView(dateString);
        }


    } catch (error) {
        console.error("Failed to save calendar day:", error);
        showAlert(`Error saving calendar for ${dateString}. Check console.`);
        // Optionally revert local changes or show error to user
    }
}


//
// --- Event Handlers ---
//

const debouncedSaveSettings = debounce(async () => {
    try { await apiRequest(API_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'save_settings', user_id: userId, ...settings }) }); }
    catch (error) { /* Handled by apiRequest */ }
}, 1000, { timer: saveSettingsTimer });

function handleSettingsChange() {
    settings = {
        totalIncome: Number(totalIncomeInput.value) || 0,
        householdSize: Number(householdSizeInput.value) || 1,
        calorieGoal: Number(calorieGoalInput.value) || 0,
        dailyBudget: Number(dailyBudgetInput.value) || 0
    };
    if (settings.householdSize < 1) { // Basic validation
        settings.householdSize = 1;
        householdSizeInput.value = 1;
    }
    updateSettingsUI();
    updateDashboard(); // Recalculates everything including weight loss
    renderMiniCalendar();
    debouncedSaveSettings();
}

// NEW: Handle Weight Loss Settings Change
function handleWeightLossSettingsChange() {
     weightLossSettings = {
         goalLbs: Number(weightLossGoalLbsInput.value) || 0,
         startWeight: Number(startWeightInput.value) || 0,
         goalWeight: Number(goalWeightInput.value) || 0,
     };
     // Basic validation/syncing
     if (weightLossSettings.goalLbs < 0) weightLossSettings.goalLbs = 0;
     if (weightLossSettings.startWeight < 0) weightLossSettings.startWeight = 0;
     if (weightLossSettings.goalWeight < 0) weightLossSettings.goalWeight = 0;

     // Optionally auto-calculate goal lbs if start/goal weights are entered
     if (weightLossSettings.startWeight > 0 && weightLossSettings.goalWeight > 0 && weightLossSettings.startWeight > weightLossSettings.goalWeight) {
         const calculatedGoal = weightLossSettings.startWeight - weightLossSettings.goalWeight;
         // Only update if the goal input wasn't the one just changed
         if (document.activeElement !== weightLossGoalLbsInput) {
            weightLossSettings.goalLbs = calculatedGoal;
         }
     } else if (weightLossSettings.goalLbs > 0 && weightLossSettings.startWeight > 0) {
         // Optionally auto-calculate goal weight
         const calculatedTarget = weightLossSettings.startWeight - weightLossSettings.goalLbs;
         if (document.activeElement !== goalWeightInput) {
            weightLossSettings.goalWeight = Math.max(0, calculatedTarget); // Ensure not negative
         }
     }

     updateWeightLossUI(); // Update fasting days display etc.
     updateDashboard(); // Recalculate weight loss bar
     debouncedSaveWeightLossSettings(); // Save to localStorage
}


async function handleAddItem(e) {
    e.preventDefault();
    const newItem = {
        name: document.getElementById('item-name').value.trim(), // Trim whitespace
        price: Number(document.getElementById('item-price').value),
        servingsPerUnit: Number(document.getElementById('item-servings').value),
        quantity: Number(document.getElementById('item-quantity').value),
        calories: Number(document.getElementById('item-calories').value),
        consumption: Number(document.getElementById('item-consumption').value),
        imageUrl: document.getElementById('item-image-url').value.trim(),
        storeUrl: document.getElementById('item-store-url').value.trim(),
    };
    // Updated validation
    if (!newItem.name || newItem.price < 0 || newItem.servingsPerUnit < 1 || newItem.quantity < 1 || newItem.calories < 0 || newItem.consumption < 0) {
         showAlert("Please fill in Name and ensure all numeric values (Price, Servings, Qty, Cals, Consumption) are valid (>= 0, Servings/Qty >= 1).");
         return;
     }
    try {
        const data = await apiRequest(API_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'add_item', user_id: userId, name: newItem.name, price: newItem.price, servings_per_unit: newItem.servingsPerUnit, quantity: newItem.quantity, calories: newItem.calories, consumption: newItem.consumption, image_url: newItem.imageUrl, store_url: newItem.storeUrl }) });
        foodItems.push(data.item);
        renderFoodList(); updateDashboard(); renderMiniCalendar(); addItemForm.reset(); document.getElementById('item-quantity').value = 1; // Reset quantity to 1
    } catch (error) { console.error('Failed to add item:', error); }
}

async function handleAddExpense(e) {
    e.preventDefault();
    const newExpense = {
        name: document.getElementById('expense-name').value.trim(), // Trim whitespace
        price: Number(document.getElementById('expense-price').value),
        quantity: Number(document.getElementById('expense-quantity').value),
        imageUrl: document.getElementById('expense-image-url').value.trim(),
        storeUrl: document.getElementById('expense-store-url').value.trim(),
    };
     // Updated validation
     if (!newExpense.name || newExpense.price < 0 || newExpense.quantity < 1) {
         showAlert("Please fill in Name and ensure Price (>=0) and Quantity (>=1) are valid.");
         return;
     }
    try {
        const data = await apiRequest(API_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'add_expense_item', user_id: userId, name: newExpense.name, price: newExpense.price, quantity: newExpense.quantity, image_url: newExpense.imageUrl, store_url: newExpense.storeUrl }) });
        // Add item returned from backend (it has the ID and created_at)
        foodItems.push(data.item);
        renderFoodList(); updateDashboard(); addExpenseForm.reset(); document.getElementById('expense-quantity').value = 1; // Reset quantity to 1
    } catch (error) { console.error('Failed to add expense:', error); }
}

const debouncedUpdateItem = debounce(async (itemId) => {
    const item = foodItems.find(i => i.id === itemId); if (!item) return;
    try {
        // Determine action based on whether it currently has food properties
        const isCurrentlyFood = item.servings_per_unit !== null && item.calories !== null && item.consumption !== null;
        const action = isCurrentlyFood ? 'update_item' : 'update_expense_item';

        const data = await apiRequest(API_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: action, user_id: userId, ...item }) });
        // Update local state ONLY with the confirmed data from the server
        handleItemUpdateInState(data.item); // Updates state, then calls render functions
    } catch (error) {
        console.error('Failed to update item:', error);
        // Consider reverting optimistic UI update or notifying user
        showAlert(`Error saving item ${item.name}. Check console.`);
        // Simple revert: reload all data
        // loadData();
    }
}, 1000, { timer: saveItemTimer });

function handleNumberInput(e) {
    const btn = e.target.closest('.decrement-btn, .increment-btn'); if (!btn) return;
    const targetInput = document.getElementById(btn.dataset.target); if (!targetInput) return;
    const step = Number(targetInput.step) || Number(btn.dataset.step) || 1;
    const min = targetInput.min !== '' ? Number(targetInput.min) : -Infinity;
    const max = targetInput.max !== '' ? Number(targetInput.max) : Infinity;
    let value = Number(targetInput.value) || 0;
    if (btn.classList.contains('increment-btn')) { value = Math.min(value + step, max); }
    else { value = Math.max(value - step, min); }
    if (String(step).includes('.')) { const decimals = String(step).split('.')[1].length; targetInput.value = value.toFixed(decimals); }
    else { targetInput.value = value; }
    // Manually trigger change event on the input to ensure listeners fire
    targetInput.dispatchEvent(new Event('change', { bubbles: true }));
}

function handleListClick(e) {
    const target = e.target;
    const deleteBtn = target.closest('.delete-btn'); const editBtn = target.closest('.edit-btn'); const quantityInput = target.closest('.quantity-input');
    if (deleteBtn) { const itemId = Number(deleteBtn.dataset.id); handleDeleteItem(itemId); return; }
    if (editBtn) { const itemId = Number(editBtn.dataset.id); openEditModal(itemId); return; }
    // Handle change event specifically for quantity inputs
    if (quantityInput && e.type === 'change') {
        const itemId = Number(quantityInput.dataset.id); let newQuantity = Number(quantityInput.value);
        if (newQuantity < 1 || isNaN(newQuantity)) { // Add NaN check
             newQuantity = 1;
             quantityInput.value = 1; // Correct the input field visually
         }
        const item = foodItems.find(i => i.id === itemId);
        if (item && item.quantity !== newQuantity) { // Only update if value actually changed
             item.quantity = newQuantity;
             // Optimistic UI updates - these happen immediately
             renderFoodList(); // Re-render the specific card might be better for perf later
             updateDashboard(); // Recalculate totals
             renderMiniCalendar(); // Update potentially affected longevity dots
             // Debounce the actual save operation
             debouncedUpdateItem(itemId);
        }
    }
}

async function handleDeleteItem(itemId) {
    const itemToDelete = foodItems.find(i => i.id === itemId);
    if (!itemToDelete) return;

    const confirmed = await showConfirm(`Are you sure you want to delete "${itemToDelete.name}"?`);
    if (!confirmed) return;

    try {
        const data = await apiRequest(API_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'delete_item', user_id: userId, item_id: itemId }) });
        // Remove item from local state only after successful deletion
        foodItems = foodItems.filter(item => item.id !== data.deleted_id);
        renderFoodList(); updateDashboard(); renderMiniCalendar();
    } catch (error) { /* API request handler already showed alert */ }
}

function openEditModal(itemId) {
    const item = foodItems.find(i => i.id === itemId); if (!item) return;
    // Check if it's currently considered a food item based on non-null values
    const isFoodItem = item.servings_per_unit !== null && item.calories !== null && item.consumption !== null;

    editItemId.value = item.id;
    document.getElementById('edit-item-name').value = item.name || '';
    document.getElementById('edit-item-price').value = item.price || 0;
    document.getElementById('edit-item-quantity').value = item.quantity || 1;
    document.getElementById('edit-item-image-url').value = item.image_url || '';
    document.getElementById('edit-item-store-url').value = item.store_url || '';

    if (isFoodItem) {
        editFieldServings.style.display = 'block';
        editFieldFoodStats.style.display = 'grid';
        document.getElementById('edit-item-servings').value = item.servings_per_unit || 1;
        document.getElementById('edit-item-calories').value = item.calories || 0;
        document.getElementById('edit-item-consumption').value = item.consumption || 0;
    } else {
        // Hide food fields and reset their values for non-food items
        editFieldServings.style.display = 'none';
        editFieldFoodStats.style.display = 'none';
        document.getElementById('edit-item-servings').value = ''; // Use empty string or 0 as appropriate
        document.getElementById('edit-item-calories').value = '';
        document.getElementById('edit-item-consumption').value = '';
    }
    editModalOverlay.style.display = 'flex';
}

function closeEditModal() { editModalOverlay.style.display = 'none'; editItemForm.reset(); }

async function handleEditFormSubmit(e) {
    e.preventDefault();
    const itemId = Number(editItemId.value);
    const originalItem = foodItems.find(i => i.id === itemId);
    if (!originalItem) {
        showAlert("Error: Could not find item to update.");
        return;
    }

    // Determine if it *should* be a food item based on whether servings is filled > 0
    const servingsValue = Number(document.getElementById('edit-item-servings').value);
    const isFoodItem = servingsValue > 0;

    const updatedData = {
        id: itemId,
        name: document.getElementById('edit-item-name').value.trim(),
        price: Number(document.getElementById('edit-item-price').value),
        quantity: Number(document.getElementById('edit-item-quantity').value),
        image_url: document.getElementById('edit-item-image-url').value.trim(),
        store_url: document.getElementById('edit-item-store-url').value.trim(),
        // Conditionally add food properties OR explicitly set them to null
        servings_per_unit: isFoodItem ? servingsValue : null,
        calories: isFoodItem ? Number(document.getElementById('edit-item-calories').value) : null,
        consumption: isFoodItem ? Number(document.getElementById('edit-item-consumption').value) : null,
    };

    // --- Validation before sending ---
    if (!updatedData.name || updatedData.price < 0 || updatedData.quantity < 1) {
         showAlert("Please ensure Name, Price (>=0), and Quantity (>=1) are valid.");
         return;
     }
     if (isFoodItem && (updatedData.calories < 0 || updatedData.consumption < 0)) {
         showAlert("For food items, Calories and Consumption must be 0 or greater.");
         return;
     }
    // --- End Validation ---


    const action = isFoodItem ? 'update_item' : 'update_expense_item';

    try {
        const data = await apiRequest(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: action, user_id: userId, ...updatedData })
        });
        // Update local state with the confirmed data from the server
        handleItemUpdateInState(data.item);
        closeEditModal();
    } catch (error) {
        console.error("Failed to save item changes:", error);
        // Alert is shown by apiRequest
    }
}

// Updated handler to re-render everything needed after state change
function handleItemUpdateInState(updatedItemFromServer) {
    const index = foodItems.findIndex(i => i.id === updatedItemFromServer.id);
    if (index !== -1) {
        // Ensure numeric types are correct coming from server
        updatedItemFromServer.price = parseFloat(updatedItemFromServer.price);
        updatedItemFromServer.quantity = parseInt(updatedItemFromServer.quantity, 10);
         if (updatedItemFromServer.servings_per_unit !== null) {
            updatedItemFromServer.servings_per_unit = parseInt(updatedItemFromServer.servings_per_unit, 10);
         }
         if (updatedItemFromServer.calories !== null) {
            updatedItemFromServer.calories = parseInt(updatedItemFromServer.calories, 10);
         }
         if (updatedItemFromServer.consumption !== null) {
             updatedItemFromServer.consumption = parseFloat(updatedItemFromServer.consumption);
         }

        foodItems[index] = updatedItemFromServer; // Update local state
        renderFoodList();      // Re-render item list
        updateDashboard();      // Recalculate dashboard & today's plan
        renderMiniCalendar();  // Update mini calendar dots

        // If calendar modal is open and in edit view for a specific day, refresh that view
        if (calendarModalOverlay.style.display === 'flex' && !calendarDayEditContainer.classList.contains('hidden')) {
             const editedDate = calendarDayEditList.dataset.date;
             if(editedDate) {
                 console.log("Refreshing edit day view after item update:", editedDate);
                 showDayEditView(editedDate);
             }
        }
        // If calendar modal is open and in calendar grid view, refresh that view
        else if (calendarModalOverlay.style.display === 'flex' && !calendarViewContainer.classList.contains('hidden')) {
             console.log("Refreshing full calendar view after item update.");
            renderFullCalendar();
        }
    } else {
        console.warn("Received update for an item not found locally:", updatedItemFromServer);
        // Optionally add the item if it was missing? Or just log.
    }
}


function handleExport() {
    const dataToExport = {
        settings: settings,
        weightLossSettings: weightLossSettings, // NEW: Include weight loss settings
        items: foodItems.map(item => {
            // Only include relevant properties
            const isFood = item.servings_per_unit !== null;
            const exportItem = {
                name: item.name,
                price: item.price,
                quantity: item.quantity,
                image_url: item.image_url,
                store_url: item.store_url
            };
            if (isFood) {
                exportItem.servings_per_unit = item.servings_per_unit;
                exportItem.calories = item.calories;
                exportItem.consumption = item.consumption;
            }
            return exportItem;
        }),
        calendar: calendarData
    };
    const dataStr = JSON.stringify(dataToExport, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'food_calculator_backup.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function handleExportShoppingList() {
    let content = 'Your Shopping List\n========================\n\n'; let totalCost = 0;
    if (foodItems.length === 0) { content = 'Your shopping list is empty.'; }
    else { foodItems.forEach(item => { const price = parseFloat(item.price); const quantity = parseInt(item.quantity, 10); const itemTotal = price * quantity; content += `${item.name}\n  Quantity: ${quantity}\n  Price: $${price.toFixed(2)} (x${quantity})\n  Subtotal: $${itemTotal.toFixed(2)}\n\n`; totalCost += itemTotal; }); content += `----------------------\nTOTAL COST: $${totalCost.toFixed(2)}\n`; }
    const dataBlob = new Blob([content], { type: 'text/plain' }); const url = URL.createObjectURL(dataBlob); const a = document.createElement('a'); a.href = url; a.download = 'shopping_list.txt'; document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
}

function handleImport(e) {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
        try {
            const data = JSON.parse(event.target.result);
            if (!data.settings || !data.items) {
                 throw new Error("Invalid JSON format. Expected 'settings' and 'items' keys.");
            }

            // NEW: Handle imported weight loss settings (optional in older files)
            if (data.weightLossSettings) {
                weightLossSettings = {
                    goalLbs: Number(data.weightLossSettings.goalLbs) || 0,
                    startWeight: Number(data.weightLossSettings.startWeight) || 0,
                    goalWeight: Number(data.weightLossSettings.goalWeight) || 0,
                };
                saveWeightLossSettings(); // Save imported settings to localStorage
                updateWeightLossUI();
            } else {
                 // Reset if not present in import file
                 weightLossSettings = { goalLbs: 0, startWeight: 0, goalWeight: 0 };
                 saveWeightLossSettings();
                 updateWeightLossUI();
            }


            // Prepare items for backend import, handling potential legacy keys
            const itemsToImport = data.items.map(item => ({
                 name: item.name,
                 price: item.price,
                 // Handle both potential keys for servings, default to null if neither exists
                 servings_per_unit: item.servings_per_unit ?? item.servingsPerUnit ?? null,
                 calories: item.calories ?? null, // Default to null if missing
                 consumption: item.consumption ?? null, // Default to null if missing
                 quantity: item.quantity || 1, // Default quantity to 1
                 image_url: item.image_url ?? item.imageUrl ?? null, // Handle both keys
                 store_url: item.store_url ?? item.storeUrl ?? null // Handle both keys
             }));


            // Call backend to replace data
            await apiRequest(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'import_data',
                    user_id: userId,
                    settings: data.settings, // Send general settings
                    items: itemsToImport, // Send formatted items
                    calendar: data.calendar || [] // Send calendar data or empty array
                })
             });

            // Reload data from backend to ensure consistency
            await loadData();
            e.target.value = null; // Reset file input
            showAlert("Data imported successfully!");

        } catch (err) {
            console.error("Import error:", err);
            showAlert(`Error importing file: ${err.message}`);
             e.target.value = null; // Reset file input even on error
        }
    };
    reader.readAsText(file);
}

async function clearAllData() {
    const confirmed = await showConfirm("Are you sure you want to delete ALL settings, items, and calendar data? This cannot be undone.");
    if (!confirmed) return;

    try {
        await apiRequest(API_URL, {
             method: 'POST',
             headers: { 'Content-Type': 'application/json' },
             body: JSON.stringify({ action: 'clear_all', user_id: userId })
        });
        // Clear local weight loss settings too
        weightLossSettings = { goalLbs: 0, startWeight: 0, goalWeight: 0 };
        saveWeightLossSettings();
        updateWeightLossUI();

        // Reload data (which will fetch default settings from backend)
        await loadData();
        showAlert("All data cleared.");
    } catch (error) { /* API handler shows alert */ }
}


function handleCopyLink() {
    const shareUrl = `${window.location.origin}${window.location.pathname}?user_id=${userId}`; const tempInput = document.createElement('input'); tempInput.style.position = 'absolute'; tempInput.style.left = '-9999px'; tempInput.value = shareUrl; document.body.appendChild(tempInput); tempInput.select();
    try { document.execCommand('copy'); showAlert('Share Link copied to clipboard!'); }
    catch (err) { console.error('Failed to copy link:', err); showAlert('Failed to copy link. Please copy it manually from the Session card.'); }
    document.body.removeChild(tempInput);
}

function handleLoadSession() {
    const newUserId = sessionIdInput.value.trim();
    if (!newUserId) {
        showAlert("Please enter a Session ID to load.");
        return;
    }
    // Only proceed if the ID is different from the current one
    if (newUserId === userId) {
        showAlert("You are already viewing this session.");
        return;
     }

    console.log(`Attempting to load session for new userId: ${newUserId}`); // Log intent
    localStorage.setItem('foodCalcUserId', newUserId); // Store the *new* ID
    const newUrl = `${window.location.origin}${window.location.pathname}?user_id=${newUserId}`;
    console.log(`Redirecting to: ${newUrl}`); // Log redirection URL
    window.location.href = newUrl; // Redirects to trigger reload with new user_id
}


document.addEventListener('DOMContentLoaded', () => {
    initializeApp(); // This now loads weight settings too
    document.body.addEventListener('click', handleNumberInput); // Handles +/- buttons globally
    settingsForm.addEventListener('change', handleSettingsChange); // Handles general settings
    weightLossForm.addEventListener('change', handleWeightLossSettingsChange); // NEW: Handles weight loss settings
    addItemForm.addEventListener('submit', handleAddItem);
    addExpenseForm.addEventListener('submit', handleAddExpense);
    exportBtn.addEventListener('click', handleExport);
    importInput.addEventListener('change', handleImport);
    exportShoppingListBtn.addEventListener('click', handleExportShoppingList);
    clearAllBtn.addEventListener('click', clearAllData);
    copyShareLinkBtn.addEventListener('click', handleCopyLink);
    loadSessionBtn.addEventListener('click', handleLoadSession);
    // Listen for clicks and changes on the item list container
    foodItemList.addEventListener('click', handleListClick);
    foodItemList.addEventListener('change', handleListClick); // Catches changes in quantity input

    alertButton.addEventListener('click', () => { alertOverlay.style.display = 'none'; });
    editModalCancel.addEventListener('click', closeEditModal);
    editItemForm.addEventListener('submit', handleEditFormSubmit);

    // Full names modal listeners
    if (viewFullNamesBtn) { viewFullNamesBtn.addEventListener('click', () => { fullNamesModalOverlay.style.display = 'flex'; }); }
    if (fullNamesModalClose) { fullNamesModalClose.addEventListener('click', () => { fullNamesModalOverlay.style.display = 'none'; }); }

    // Calendar modal listeners
    openCalendarBtn.addEventListener('click', () => { currentCalendarDate = new Date(); renderFullCalendar(); showCalendarView(); calendarModalOverlay.style.display = 'flex'; });
    calendarModalOverlay.addEventListener('click', (e) => { if (e.target === calendarModalOverlay) { calendarModalOverlay.style.display = 'none'; } }); // Close on overlay click
    calendarPrevMonthBtn.addEventListener('click', () => { currentCalendarDate.setMonth(currentCalendarDate.getMonth() - 1); renderFullCalendar(); });
    calendarNextMonthBtn.addEventListener('click', () => { currentCalendarDate.setMonth(currentCalendarDate.getMonth() + 1); renderFullCalendar(); });
    calendarBackBtn.addEventListener('click', showCalendarView);

    // Event delegation for checkboxes inside the dynamically populated day edit list
    calendarDayEditList.addEventListener('change', (e) => {
        if (e.target.classList.contains('day-item-toggle')) {
            const dateString = calendarDayEditList.dataset.date;
            if (!dateString) return;

            // 1. Recalculate total calories displayed in the modal immediately
            recalculateDayEditTotalCalories();

            // 2. Save the changes asynchronously (this function reads the checkbox states)
            saveCalendarDay(dateString);
        }
    });

    // Fasting button listener
    calendarDayFastingBtn.addEventListener('click', () => {
        const dateString = calendarDayEditList.dataset.date;
        if (!dateString) return;

        let dayData = calendarData.find(d => d.plan_date === dateString);
         // Find or create if not exists before toggling
         if (!dayData) {
            dayData = { plan_date: dateString, excluded_item_ids: [], is_fasting_day: false };
            calendarData.push(dayData);
         }
        dayData.is_fasting_day = !dayData.is_fasting_day; // Toggle state locally first

        // Save the toggled state asynchronously
        saveCalendarDay(dateString);

        // Refresh the edit view immediately to reflect the change visually
        showDayEditView(dateString);
    });
});

