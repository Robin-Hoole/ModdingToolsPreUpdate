// TM_Core.js - Event listeners, Key bindings, and Initialization

function handleKeyboardScroll(currentIndex, currentList, direction) {
    let nextIndex = currentIndex;
    if (direction === 'down') {
        nextIndex = Math.min(currentIndex + 1, currentList.length - 1);
    } else if (direction === 'up') {
        nextIndex = Math.max(currentIndex - 1, 0);
    }
    
    if (nextIndex !== currentIndex) {
        const newId = currentList[nextIndex].id;
        focusEntryUI(newId, true);
        showNavPopup(`ENTRY #${nextIndex + 1} FOCUSED`);
    }
    return nextIndex;
}

function setupKeyboard() {
    document.addEventListener('keydown', (e) => {
        const tag = e.target.tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

        const search = document.getElementById('search').value.toLowerCase();
        const currentList = state.entries.filter(entry => {
            if (entry.tab !== state.activeTab) return false;
            if (!search) return true;
            return entry.name.toLowerCase().includes(search) || 
                   entry.id.toLowerCase().includes(search) || 
                   entry.desc.toLowerCase().includes(search) || 
                   (entry.chainName && entry.chainName.toLowerCase().includes(search)) ||
                   (entry.tags && entry.tags.some(t => t.toLowerCase().includes(search)));
        });
        
        if (currentList.length === 0) return;

        let currentIndex = currentList.findIndex(entry => entry.id === state.focusedEntryId);
        if (currentIndex === -1) currentIndex = 0;

        let changedTab = false;

        switch(e.key) {
            case 'ArrowRight':
                const nextTabIndex = (state.tabs.indexOf(state.activeTab) + 1) % state.tabs.length;
                state.activeTab = state.tabs[nextTabIndex];
                changedTab = true;
                showNavPopup(`TAB: ${state.activeTab}`);
                break;
            case 'ArrowLeft':
                const prevTabIndex = (state.tabs.indexOf(state.activeTab) - 1 + state.tabs.length) % state.tabs.length;
                state.activeTab = state.tabs[prevTabIndex];
                changedTab = true;
                showNavPopup(`TAB: ${state.activeTab}`);
                break;
            case 'ArrowDown':
                e.preventDefault();
                if (!isHoldingKey) {
                    isHoldingKey = true;
                    setScrollBlock();
                    currentIndex = handleKeyboardScroll(currentIndex, currentList, 'down');
                    keyRepeatTimer = setInterval(() => {
                        currentIndex = currentList.findIndex(entry => entry.id === state.focusedEntryId);
                        currentIndex = handleKeyboardScroll(currentIndex, currentList, 'down');
                    }, 100);
                }
                break;
            case 'ArrowUp':
                e.preventDefault();
                if (!isHoldingKey) {
                    isHoldingKey = true;
                    setScrollBlock();
                    currentIndex = handleKeyboardScroll(currentIndex, currentList, 'up');
                    keyRepeatTimer = setInterval(() => {
                        currentIndex = currentList.findIndex(entry => entry.id === state.focusedEntryId);
                        currentIndex = handleKeyboardScroll(currentIndex, currentList, 'up');
                    }, 100);
                }
                break;
            case 'Home':
                e.preventDefault();
                setScrollBlock();
                focusEntryUI(currentList[0].id, true);
                showNavPopup(`ENTRY #1 FOCUSED`);
                break;
            case 'End':
                e.preventDefault();
                setScrollBlock();
                focusEntryUI(currentList[currentList.length - 1].id, true);
                showNavPopup(`ENTRY #${currentList.length} FOCUSED`);
                break;
            case 'PageDown':
                e.preventDefault();
                setScrollBlock();
                const curEntryDown = currentList[currentIndex];
                if(curEntryDown && curEntryDown.chainName) {
                    const chainEntries = currentList.filter(x => x.chainName === curEntryDown.chainName);
                    const targetId = chainEntries[chainEntries.length - 1].id;
                    focusEntryUI(targetId, true);
                    const newIdx = currentList.findIndex(x => x.id === targetId);
                    showNavPopup(`ENTRY #${newIdx + 1} FOCUSED`);
                } else {
                    currentIndex = Math.min(currentIndex + 10, currentList.length - 1);
                    focusEntryUI(currentList[currentIndex].id, true);
                    showNavPopup(`ENTRY #${currentIndex + 1} FOCUSED`);
                }
                break;
            case 'PageUp':
                e.preventDefault();
                setScrollBlock();
                const curEntryUp = currentList[currentIndex];
                if(curEntryUp && curEntryUp.chainName) {
                    const chainEntries = currentList.filter(x => x.chainName === curEntryUp.chainName);
                    const targetId = chainEntries[0].id;
                    focusEntryUI(targetId, true);
                    const newIdx = currentList.findIndex(x => x.id === targetId);
                    showNavPopup(`ENTRY #${newIdx + 1} FOCUSED`);
                } else {
                    currentIndex = Math.max(currentIndex - 10, 0);
                    focusEntryUI(currentList[currentIndex].id, true);
                    showNavPopup(`ENTRY #${currentIndex + 1} FOCUSED`);
                }
                break;
        }

        if (changedTab) {
            e.preventDefault();
            document.getElementById('search').value = ''; 
            syncFocus();
            fullRender();
        }
    });

    document.addEventListener('keyup', (e) => {
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            isHoldingKey = false;
            clearInterval(keyRepeatTimer);
        }
    });
}

function init() {
    populateEmojiSelect();
    populateTaskIconSelect();
    
    // Setup form submission handler
    const form = document.getElementById('taskForm');
    if (form) {
        form.onsubmit = (e) => {
            e.preventDefault();
            const id = document.getElementById('taskId').value;
            
            // Gather Identity
            const name = document.getElementById('taskName').value;
            const displayId = document.getElementById('taskDisplayId').value;
            const displayName = document.getElementById('taskDisplayName').value;
            const namespace = document.getElementById('taskNamespace').value;

            // Gather Presentation
            const desc = document.getElementById('taskDesc').value;
            const completionText = document.getElementById('taskCompletionText').value;
            const failureText = document.getElementById('taskFailureText').value;
            const color = document.getElementById('taskColor').value;
            const chainEmoji = document.getElementById('taskIconSelect').value;

            // Gather Lifecycle
            const tab = document.getElementById('registrySelect').value;
            const taskType = document.getElementById('taskType').value;
            const initialState = document.getElementById('taskInitialState').value;
            const autoUnlock = document.getElementById('cbAutoUnlock').checked;
            const autoStart = document.getElementById('cbAutoStart').checked;
            const autoComplete = document.getElementById('cbAutoComplete').checked;
            const repeatable = document.getElementById('cbRepeatable').checked;
            const resettable = document.getElementById('cbResettable').checked;
            const branchExclusive = document.getElementById('cbBranchExclusive').checked;

            // Gather Branch & Story
            const branchRule = document.getElementById('taskBranchRule').value;
            const storyBeatType = document.getElementById('taskStoryBeatType').value;

            // Gather Time Rules
            const timeAvail = document.getElementById('taskTimeAvail').value;
            const timeExpire = document.getElementById('taskTimeExpire').value;
            const cooldown = document.getElementById('taskCooldown').value;
            const repeatInterval = document.getElementById('taskRepeatInterval').value;

            // Chain logic
            const chainDesc = document.getElementById('chainDescInput').value;
            const chainColor = document.getElementById('chainColor').value;
            
            let chainName = '';
            if (taskType === 'root') {
                chainName = document.getElementById('chainNameInput').value;
            } else if (taskType === 'node' || taskType === 'endpoint') {
                chainName = document.getElementById('chainNameSelect').value;
            }

            const existingTask = state.entries.find(t => t.id === id);

            const getCond = (prefix) => ({
                key: document.getElementById(`${prefix}Key`).value,
                op: document.getElementById(`${prefix}Op`).value,
                val: document.getElementById(`${prefix}Val`).value,
                hideVisual: existingTask?.[prefix + 'Condition']?.hideVisual || false
            });

            const newTask = createBaseEntry({
                id: id || crypto.randomUUID(),
                tab, name, displayId, displayName, namespace, tags: existingTask ? existingTask.tags : [], desc, completionText, failureText, color,
                chainColor: (taskType === 'root' || taskType === 'node' || taskType === 'endpoint') ? chainColor : '',
                chainDesc: (taskType === 'root' || taskType === 'node' || taskType === 'endpoint') ? chainDesc : '',
                chainEmoji: chainEmoji || '🔮',
                taskType, chainName, initialState, autoUnlock, autoStart, autoComplete, repeatable, resettable, branchExclusive,
                branchRule, storyBeatType, timeAvail, timeExpire, cooldown, repeatInterval,
                objectives: existingTask ? existingTask.objectives : [],
                dependencies: existingTask ? existingTask.dependencies : [],
                showDeps: existingTask ? existingTask.showDeps : false,
                showChain: existingTask ? existingTask.showChain : false,
                calledExternally: existingTask ? existingTask.calledExternally : false,
                makeExternalCall: existingTask ? existingTask.makeExternalCall : false,
                conditions: existingTask ? existingTask.conditions : [],
                stateChanges: existingTask ? existingTask.stateChanges : [],
                customGameplayValues: existingTask ? existingTask.customGameplayValues : [],
                unlockCondition: getCond('unlock'),
                completeCondition: getCond('complete'),
                failCondition: getCond('fail'),
                rewardCondition: getCond('reward'),
                collapsed: existingTask ? existingTask.collapsed : false,
                subCategoriesCollapsed: existingTask ? existingTask.subCategoriesCollapsed : { conditions:false, stateChanges:false, summary:false, dependencies:false, tags:false, objectives:false, branch:false, time:false },
                lastModified: new Date().toISOString()
            });

            if (typeof tmEnsureTaskTranslationContainers === 'function') {
                if (existingTask) {
                    newTask.translations = existingTask.translations || {};
                    newTask.textFormats = existingTask.textFormats || {};
                    const activeLang = (typeof tmEnsureValues === 'function' ? (tmEnsureValues().currentLanguage || 'ENG') : 'ENG');
                    if (activeLang !== 'ENG') {
                        ['name','displayName','desc','completionText','failureText','chainName','chainDesc'].forEach(field => {
                            if (Object.prototype.hasOwnProperty.call(existingTask, field)) newTask[field] = existingTask[field];
                        });
                    }
                }
                tmEnsureTaskTranslationContainers(newTask);
                if (typeof tmSetLocalizedTaskText === 'function') {
                    tmSetLocalizedTaskText(newTask, 'name', name);
                    tmSetLocalizedTaskText(newTask, 'displayName', displayName);
                    tmSetLocalizedTaskText(newTask, 'desc', desc);
                    tmSetLocalizedTaskText(newTask, 'completionText', completionText);
                    tmSetLocalizedTaskText(newTask, 'failureText', failureText);
                    if (taskType === 'root') tmSetLocalizedTaskText(newTask, 'chainName', chainName);
                    tmSetLocalizedTaskText(newTask, 'chainDesc', chainDesc);
                }
            }

            state.globalCustomFields.forEach(gcf => {
                if(!newTask.customGameplayValues.find(c => c.fieldId === gcf.id)) {
                    newTask.customGameplayValues.push({ fieldId: gcf.id, key: gcf.key, op: gcf.op, val: gcf.val, hideVisual: false });
                }
            });

            if ((taskType === 'root' || taskType === 'node' || taskType === 'endpoint') && chainName) {
                state.entries.forEach(t => {
                    if (t.chainName === chainName && t.id !== newTask.id) {
                        t.chainColor = chainColor;
                        t.chainDesc = chainDesc;
                        t.chainEmoji = chainEmoji;
                    }
                });
            }

            if (id) {
                state.entries = state.entries.map(t => t.id === id ? newTask : t);
                markEdited(id);
                showNotification("Node Logic Updated");
                if (typeof tmMarkAppDirty === 'function') tmMarkAppDirty();
            } else {
                state.entries.push(newTask);
                markEdited(newTask.id);
                showNotification("New Node Initialized");
                if (typeof tmMarkAppDirty === 'function') tmMarkAppDirty();
            }

            state.activeTab = tab;
            resetForm();
            recalculateTags();
            fullRender();
        };
    }

    localStorage.setItem('hideDummyPrompt', 'true');
    localStorage.setItem('useDummyData', 'false');
    state.entries = Array.isArray(state.entries) ? state.entries : [];
    const promptOverlay = document.getElementById('prompt-overlay');
    if (promptOverlay) promptOverlay.remove();
    finishInit();
}

window.onload = init;
// Server/auth/value UI boot hook. Runs after the original Task Manager initializes.
(function(){
    const originalFinishInit = finishInit;
    let tmBooted = false;
    finishInit = function() {
        originalFinishInit();
        if (tmBooted) return;
        tmBooted = true;
        if (typeof tmInjectBaseUi === 'function') tmInjectBaseUi();
        if (typeof tmEnsureValues === 'function') tmEnsureValues();
        if (typeof tmRenderValuesTab === 'function') tmRenderValuesTab();
        if (typeof tmAccountStatus === 'function') tmAccountStatus(true);
        if (typeof tmRefreshTaskGiverControls === 'function') tmRefreshTaskGiverControls();
    };
})();
