/**
 * NF_Data.js
 * Data processing, logic registry mapping, and parsing logic.
 */

function updateProjectLogic(shouldRender = true) {
    projectLogic = Object.create(null);
    const register = (key, op, val, type, source) => {
        const stmt = normalizeStatement(key, op, val);
        if(!stmt) return;
        if(!projectLogic[stmt]) projectLogic[stmt] = { condition: false, stateChange: false, sources: new Set(), count: 0 };
        if(type === 'condition') projectLogic[stmt].condition = true;
        if(type === 'stateChange') projectLogic[stmt].stateChange = true;
        projectLogic[stmt].sources.add(source);
        projectLogic[stmt].count++;
    };

    storyNodes.forEach(node => {
        const sourceStr = `Canvas Node: ${node.title}`;
        (node.unlockConditions||[]).forEach(c => register(c.variable, c.operator, c.value, 'condition', sourceStr));
        (node.onComplete||[]).forEach(c => register(c.variable, c.operator, c.value, 'stateChange', sourceStr));
        if(node.isTaskQuest) {
            if(node.taskUnlock?.key) register(node.taskUnlock.key, node.taskUnlock.op, node.taskUnlock.val, 'condition', sourceStr);
            if(node.taskComplete?.key) register(node.taskComplete.key, node.taskComplete.op, node.taskComplete.val, 'condition', sourceStr);
            if(node.taskFail?.key) register(node.taskFail.key, node.taskFail.op, node.taskFail.val, 'condition', sourceStr);
            if(node.taskReward?.key) register(node.taskReward.key, node.taskReward.op, node.taskReward.val, 'stateChange', sourceStr);
        }
    });

    const scanSource = (arr, nameField) => {
        arr.forEach(item => {
            const sourceStr = `Import: ${item._sourceFile} (${item[nameField] || item.title || item.name || item.text || 'Unknown'})`;
            if(item.conditions) item.conditions.forEach(c => register(c.key||c.variable, c.op||c.operator, c.val||c.value, 'condition', sourceStr));
            if(item.availabilityConditions) item.availabilityConditions.forEach(c => register(c.key||c.variable, c.op||c.operator, c.val||c.value, 'condition', sourceStr));
            if(item.gameStateChanges) item.gameStateChanges.forEach(c => register(c.key||c.variable, c.op||c.operator, c.val||c.value, 'stateChange', sourceStr));
            if(item.stateChanges) item.stateChanges.forEach(c => register(c.key||c.variable, c.op||c.operator, c.val||c.value, 'stateChange', sourceStr));
            if(item.onPressResults) item.onPressResults.forEach(c => register(c.key||c.variable, c.op||c.operator, c.val||c.value, 'stateChange', sourceStr));
            
            if(item.unlockCondition?.key) register(item.unlockCondition.key, item.unlockCondition.op, item.unlockCondition.val, 'condition', sourceStr);
            if(item.completeCondition?.key) register(item.completeCondition.key, item.completeCondition.op, item.completeCondition.val, 'condition', sourceStr);
            if(item.rewardCondition?.key) register(item.rewardCondition.key, item.rewardCondition.op, item.rewardCondition.val, 'stateChange', sourceStr);
            
            if(item.nodes) {
                item.nodes.forEach(n => {
                    if(n.conditions) n.conditions.forEach(c => register(c.key||c.variable, c.op||c.operator, c.val||c.value, 'condition', sourceStr));
                    if(n.gameStateChanges) n.gameStateChanges.forEach(c => register(c.key||c.variable, c.op||c.operator, c.val||c.value, 'stateChange', sourceStr));
                    if(n.responses) n.responses.forEach(r => {
                        if(r.conditions) r.conditions.forEach(c => register(c.key||c.variable, c.op||c.operator, c.val||c.value, 'condition', sourceStr));
                        if(r.gameStateChanges) r.gameStateChanges.forEach(c => register(c.key||c.variable, c.op||c.operator, c.val||c.value, 'stateChange', sourceStr));
                    });
                });
            }
            if(item.buttons) {
                item.buttons.forEach(b => {
                    if(b.conditions) b.conditions.forEach(c => register(c.key||c.variable, c.op||c.operator, c.val||c.value, 'condition', sourceStr));
                    if(b.stateChanges) b.stateChanges.forEach(c => register(c.key||c.variable, c.op||c.operator, c.val||c.value, 'stateChange', sourceStr));
                });
            }
        });
    };

    scanSource(sourceData.dialogues, 'title'); scanSource(sourceData.sequences, 'title'); scanSource(sourceData.tasks, 'name');
    scanSource(sourceData.menus, 'text'); scanSource(sourceData.prompts, 'title');

    // Tooling Logic scanning
    toolingData.transitions.forEach(n => {
        const srcStr = `Tool Node: ${n.title}`;
        (n.conditions||[]).forEach(c => register(c.key, c.op, c.val, 'condition', srcStr));
        (n.stateChanges||[]).forEach(c => register(c.key, c.op, c.val, 'stateChange', srcStr));
    });
    toolingData.imageNodes.forEach(n => {
        const srcStr = `Tool Node: ${n.title}`;
        (n.conditions||[]).forEach(c => register(c.key, c.op, c.val, 'condition', srcStr));
        (n.stateChanges||[]).forEach(c => register(c.key, c.op, c.val, 'stateChange', srcStr));
    });

    if (sourceData.importedLogic) sourceData.importedLogic.forEach(c => register(c.key, c.operator, c.value, c.usageClassification === 'Condition Only' ? 'condition' : (c.usageClassification === 'State Change Only' ? 'stateChange' : 'mixed'), `Imported Logic: ${c._sourceFile}`));
    if (sourceData.importedGameplayValues) sourceData.importedGameplayValues.forEach(val => { const stmt = normalizeStatement(val.key, val.operator, val.value); if (stmt && gameplayValues[stmt] === undefined) gameplayValues[stmt] = "#ffffff"; });

    for(let stmt in projectLogic) {
        let p = projectLogic[stmt];
        if(p.condition && p.stateChange) p.usage = 'mixed';
        else if(p.condition) p.usage = 'condition';
        else if(p.stateChange) p.usage = 'stateChange';
        else p.usage = 'unknown';
    }
    
    if (shouldRender) {
        if(activeOverTab === 'nodes' && rightTab === 'logic') renderLogicPanel();
        if(activeOverTab === 'tools' && activeToolLogicTab !== 'author') renderToolLogicPanel();
        if(activeOverTab === 'nodes') renderNodes();
    }
}

function addToolSection(type) {
    const input = document.getElementById('new-tool-section-name-' + type);
    const name = input.value.trim();
    if(!name) return;
    
    try {
        let arr = getToolArrays(type).sec;
        arr.push({ id: generateUUID(), name: name, path: "Assets/Resources/" });
        
        input.value = '';
        updateProjectLogic(false);
        renderToolLibrary();
        renderToolEditor();
    } catch (err) {
        console.error("Tool Section Creation Failed:", err);
        showNotification("Failed to add section.", true);
    }
}

function addToolNode(type) {
    const titleInp = document.getElementById('new-tool-title-' + type);
    const secSel = document.getElementById('new-tool-section-id-' + type);
    const colInp = document.getElementById('new-tool-color-' + type);
    
    const title = titleInp.value.trim();
    const secId = secSel.value;
    if(!title || !secId) return;

    let newItem = {
        id: generateUUID(),
        title: title, name: title,
        sectionId: secId,
        color: colInp.value,
        isExternallyCalled: false,
        makeExternalCall: false,
        conditions: [],
        stateChanges: []
    };

    if(type === 'trans') {
        newItem = {
            ...newItem,
            pauseTime: 5,
            bodyText: "",
            useImage: false,
            imageId: "",
            isCollapsed: false,
            titleTextFormat: { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'left', alignV: 'top' },
            bodyTextFormat: { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'left', alignV: 'top' },
            translations: { ENG: { title: title, bodyText: "" } }
        };
        toolingData.transitions.push(newItem);
    } else if (type === 'imgnode') {
        newItem = {
            ...newItem,
            imageId: "",
            shownFor: 5,
            useTitle: false,
            useBody: false,
            bodyText: "",
            isCollapsed: false,
            titleTextFormat: { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'left', alignV: 'top' },
            bodyTextFormat: { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'left', alignV: 'top' },
            translations: { ENG: { title: title, bodyText: "" } }
        };
        toolingData.imageNodes.push(newItem);
    } else if (type === 'imgdb') {
        toolingData.imageDbItems.push(newItem);
    } else if (type === 'convseq') {
        toolingData.convSeqs.push(newItem);
    } else if (type === 'puppetseq') {
        toolingData.puppetSeqs.push(newItem);
    }

    titleInp.value = '';
    colInp.value = getRandomHex();
    activeToolItemId = newItem.id;
    updateProjectLogic();
    renderToolLibrary();
    renderToolEditor();
    setTimeout(() => scrollToToolCard(newItem.id), 100);
}

function updateSectionPath(type, secId, val) {
    let arr = getToolArrays(type).sec;
    let sec = arr.find(s => s.id === secId);
    if(sec) {
        sec.path = val;
        renderToolLibrary(); 
    }
}

function reorderToolItem(type, itemId, newIndex) {
    let arr = getToolArrays(type).items;
    let oldIndex = arr.findIndex(i => i.id === itemId);
    if(oldIndex === -1) return;
    let item = arr.splice(oldIndex, 1)[0];
    
    let secItems = arr.filter(i => i.sectionId === item.sectionId);
    secItems.splice(newIndex, 0, item);
    
    let otherItems = arr.filter(i => i.sectionId !== item.sectionId);
    let finalArr = [...otherItems, ...secItems];
    
    if(type === 'trans') toolingData.transitions = finalArr;
    if(type === 'imgnode') toolingData.imageNodes = finalArr;
    if(type === 'imgdb') toolingData.imageDbItems = finalArr;
    if(type === 'convseq') toolingData.convSeqs = finalArr;
    if(type === 'puppetseq') toolingData.puppetSeqs = finalArr;
    
    renderToolLibrary();
    renderToolEditor();
    setTimeout(() => scrollToToolCard(itemId), 100);
}

// Logic interactions
function addStartupValue() { startupValues.push({key:'', op:'==', val:''}); renderLogicPanel(); updateProjectLogic(); }
function addGameEndValue() { gameEndValues.push({key:'', op:'==', val:''}); renderLogicPanel(); updateProjectLogic(); }
function updateLogicArray(type, i, field, val) { 
    (type === 'start' ? startupValues : gameEndValues)[i][field] = val; 
    updateProjectLogic();
}
function removeLogicArray(type, i) { 
    (type === 'start' ? startupValues : gameEndValues).splice(i, 1); 
    renderLogicPanel(); updateProjectLogic();
}

function addGameplayValue() {
    let val = document.getElementById('new-gp-val').value.trim();
    const color = document.getElementById('new-gp-color').value;
    if (val) {
        const match = val.match(/^(.+?)\s*(==|>=|<=|>|<|=)\s*(.+)$/);
        if (match) val = normalizeStatement(match[1], match[2], match[3]);
        else val = normalizeStatement(val, '==', '');
        gameplayValues[val] = color;
        document.getElementById('new-gp-val').value = '';
        updateProjectLogic();
    }
}

function startEditGameplayValue(key) { editingGpKey = key; renderLogicPanel(); }
function cancelEditGameplayValue() { editingGpKey = null; renderLogicPanel(); }
function saveEditGameplayValue(oldKey) {
    let newVal = document.getElementById('edit-gp-val').value.trim();
    const newColor = document.getElementById('edit-gp-color').value;
    if (newVal) {
        const match = newVal.match(/^(.+?)\s*(==|>=|<=|>|<|=)\s*(.+)$/);
        if (match) newVal = normalizeStatement(match[1], match[2], match[3]);
        else newVal = normalizeStatement(newVal, '==', '');
        
        if (newVal !== oldKey) {
            gameplayValues[newVal] = newColor;
            delete gameplayValues[oldKey];
        } else {
            gameplayValues[oldKey] = newColor;
        }
    }
    editingGpKey = null;
    updateProjectLogic();
}
function deleteGameplayValue(key) { delete gameplayValues[key]; updateProjectLogic(); }

function generateNodeData(source, type) {
    let colorMap = { 'task': '#b026ff', 'sequence': '#3b82f6', 'menu': '#00ff88', 'prompt': '#ff007b', 'conversation': '#00f2ff', 'trans': '#ff8c00', 'imgnode': '#ff0055' };
    let color = source.color || colorMap[type];
    let prefix = type === 'conversation' ? 'conv' : (type === 'sequence' ? 'seq' : (type === 'task' ? 'task' : (type === 'menu' ? 'menu' : (type === 'prompt' ? 'prmpt' : type))));
    
    let unlockConditions = [];
    let onComplete = [];

    // Safely extract deeply nested structures to native Canvas Tags
    if (source.conditions) unlockConditions.push(...source.conditions.map(c => ({variable: c.variable || c.key, operator: c.operator || c.op, value: c.value || c.val})));
    if (source.availabilityConditions) unlockConditions.push(...source.availabilityConditions.map(c => ({variable: c.key, operator: c.op, value: c.val})));
    if (source.unlockCondition && source.unlockCondition.key) unlockConditions.push({variable: source.unlockCondition.key, operator: source.unlockCondition.op, value: source.unlockCondition.val});
    
    if (source.gameStateChanges) onComplete.push(...source.gameStateChanges.map(c => ({variable: c.variable || c.key, operator: c.operator || c.op, value: c.value || c.val})));
    if (source.stateChanges) onComplete.push(...source.stateChanges.map(c => ({variable: c.key, operator: c.op, value: c.val})));
    if (source.onPressResults) onComplete.push(...source.onPressResults.map(c => ({variable: c.key, operator: c.op, value: c.val})));
    if (source.rewardCondition && source.rewardCondition.key) onComplete.push({variable: source.rewardCondition.key, operator: source.rewardCondition.op, value: source.rewardCondition.val});

    // Extract deep components from prompt/menu buttons if applicable
    if (source.buttons) {
        source.buttons.forEach(b => {
            if (b.conditions) unlockConditions.push(...b.conditions.map(c => ({variable: c.variable || c.key, operator: c.operator || c.op, value: c.value || c.val})));
            if (b.stateChanges) onComplete.push(...b.stateChanges.map(c => ({variable: c.variable || c.key, operator: c.operator || c.op, value: c.value || c.val})));
        });
    }

    // Extract deep components from Dialogues and Sequences
    if (source.nodes && Array.isArray(source.nodes)) {
        source.nodes.forEach(n => {
            if (n.conditions) unlockConditions.push(...n.conditions.map(c => ({variable: c.variable || c.key, operator: c.operator || c.op, value: c.value || c.val})));
            if (n.gameStateChanges) onComplete.push(...n.gameStateChanges.map(c => ({variable: c.variable || c.key, operator: c.operator || c.op, value: c.value || c.val})));
            if (n.stateChanges) onComplete.push(...n.stateChanges.map(c => ({variable: c.key, operator: c.op, value: c.val})));
            if (n.responses) {
                n.responses.forEach(r => {
                    if (r.conditions) unlockConditions.push(...r.conditions.map(c => ({variable: c.variable || c.key, operator: c.operator || c.op, value: c.value || c.val})));
                    if (r.gameStateChanges) onComplete.push(...r.gameStateChanges.map(c => ({variable: c.variable || c.key, operator: c.operator || c.op, value: c.value || c.val})));
                });
            }
        });
    }

    // Filter empties safely
    unlockConditions = unlockConditions.filter(c => c.variable && c.variable.trim() !== "");
    onComplete = onComplete.filter(c => c.variable && c.variable.trim() !== "");

    // Deduplicate to prevent Canvas tag spam
    const uniqueConditions = []; const seenCond = new Set();
    for(let c of unlockConditions) {
        let str = c.variable + c.operator + c.value;
        if(!seenCond.has(str)) { seenCond.add(str); uniqueConditions.push(c); }
    }
    const uniqueCompletes = []; const seenComp = new Set();
    for(let c of onComplete) {
        let str = c.variable + c.operator + c.value;
        if(!seenComp.has(str)) { seenComp.add(str); uniqueCompletes.push(c); }
    }
    unlockConditions = uniqueConditions;
    onComplete = uniqueCompletes;

    return {
        id: `${prefix}_${String(idCounter++).padStart(4, '0')}`, canvasId: currentCanvasId, type: type,
        title: String(source.title || source.name || source.text || "Unnamed").replace(/\s+/g, ''),
        sourceRef: String(source.title || source.name || source.text || "Unnamed"),
        x: (-panX + container.clientWidth/2) / scale - 120, y: (-panY + container.clientHeight/2) / scale - 50,
        color: color, chainName: source.chainName || "", chainDesc: source.chainDesc || "", chainColor: source.chainColor || getRandomColor(),
        taskType: source.taskType || 'standalone', 
        unlockConditions: unlockConditions, 
        onComplete: onComplete, 
        nextConversations: source.nextConversations || [], savePoint: source.savePoint || "",
        isRepeatable: source.isRepeatable || false, repeatVariable: source.repeatVariable || "",
        isTaskQuest: type === 'task', 
        taskUnlock: source.taskUnlock || source.unlockCondition || {key:'', op:'==', val:''}, 
        taskComplete: source.taskComplete || source.completeCondition || {key:'', op:'==', val:''},
        taskFail: source.taskFail || source.failCondition || {key:'', op:'==', val:''}, 
        taskReward: source.taskReward || source.rewardCondition || {key:'', op:'==', val:''},
        snapParent: null, snapChild: null, contextTitle: source.groupName ? `${source.groupName} > ${source.characterName || 'General'} :` : "",
        buttonLabel: source.text || source.title || source.name || "Option"
    };
}

function createNodeFromSource(source, type) {
    const node = generateNodeData(source, type);
    node.x += spawnOffset; node.y += spawnOffset; spawnOffset += 30; 
    storyNodes.push(node); selectedNodeIds = [node.id];
    updateProjectLogic(); setRightTab('inspector');
}

function updateStackPositions(rootId) {
    let currentId = rootId; let current = storyNodes.find(n => n.id === currentId);
    while (current && current.snapChild) {
        let child = storyNodes.find(n => n.id === current.snapChild);
        if (child) {
            child.x = current.x;
            let currEl = document.querySelector(`.story-node[data-id="${current.id}"]`);
            let childEl = document.querySelector(`.story-node[data-id="${child.id}"]`);
            if (currEl && childEl) {
                child.y = current.y + currEl.offsetHeight - 1; 
                childEl.style.left = `${child.x}px`; childEl.style.top = `${child.y}px`;
                child.width = childEl.offsetWidth; child.height = childEl.offsetHeight;
            }
            currentId = child.id; current = child;
        } else break;
    }
}

function detachNode(id) {
    const node = storyNodes.find(n => n.id === id);
    if (!node) return;
    if (node.snapParent) { const p = storyNodes.find(n => n.id === node.snapParent); if (p) p.snapChild = node.snapChild; }
    if (node.snapChild) { const c = storyNodes.find(n => n.id === node.snapChild); if (c) c.snapParent = node.snapParent; }
    node.snapParent = null; node.snapChild = null; node.x += 50; node.y += 50;
    renderNodes();
}