// TM_Data.js - State and Shared Data Structures
// TASK_SHARED_VALUES_PATCH - default data shared with Dialogue Designer / Idle Manager
const TASK_DEFAULT_VALUES = {
    serverSessionId: '',
    dialogueSessionId: '',
    availableLanguages: ['ENG'],
    currentLanguage: 'ENG',
    globalTokens: [],
    globalCast: [],
    globalStates: [],
    globalMoods: [],
    globalSettings: [],
    globalTimesOfDay: [],
    globalDaysOfWeek: [],
    globalMenuOptions: [],
    globalImageSequences: []
};
function createDefaultTaskValues() {
    return JSON.parse(JSON.stringify(TASK_DEFAULT_VALUES));
}
function createDefaultTaskSprites() {
    return [];
}

let state = {
    tabs: ['Achievements', 'Tasks', 'Dev'],
    tabColors: {
        'Achievements': '#00f2ff',
        'Tasks': '#ff8c00',
        'Dev': '#ff007b'
    },
    activeTab: 'Tasks',
    entries: [],
    globalCustomFields: [], 
    globalTags: {}, 
    Values: createDefaultTaskValues(),
    Sprites: createDefaultTaskSprites(),
    leftSidebarMode: 'metadata',
    serverSessionId: '',
    phases: ['Single Phase', 'Phase 1', 'Phase 2', 'Phase 3', 'Phase 4'],
    modalTag: null,
    focusedEntryId: null,
    prevFocusedEntryId: null,
    editedNodes: new Set()
};

let lastTaskType = 'Task';
let titleClickTimers = {};

let isScrollingProgrammatically = false;
let scrollBlockTimer = null;
let navPopupTimer = null;

let isHoldingKey = false;
let keyRepeatTimer = null;

const OBJECTIVE_TYPES = {

  'Talk To NPC': { l1: 'NPC ID', l2: 'Dialogue Node', l3: 'Required Tone', l4: 'N/A' },
  'Interact With NPC': { l1: 'NPC ID', l2: 'Action', l3: 'Item Required', l4: 'N/A' },
  'Complete Conversation': { l1: 'Convo ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Conversation Seen': { l1: 'Convo ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Conversation Unseen': { l1: 'Convo ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Complete Statement': { l1: 'Statement ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Statement Seen': { l1: 'Statement ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Statement Unseen': { l1: 'Statement ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Receive Prompt': { l1: 'Prompt ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Complete Prompt': { l1: 'Prompt ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Prompt Seen': { l1: 'Prompt ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Prompt Unseen': { l1: 'Prompt ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Make Choice': { l1: 'Dialogue/Prompt ID', l2: 'Choice ID', l3: 'N/A', l4: 'N/A' },
  'Complete Sequence': { l1: 'Seq Name', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Sequence Seen': { l1: 'Seq Name', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Sequence Unseen': { l1: 'Seq Name', l2: 'N/A', l3: 'N/A', l4: 'N/A' },


  'Choice Between Two': { l1: 'Choice A Response ID', l2: 'N/A', l3: 'Choice B Response ID', l4: 'N/A' },    
  'Choice Between Three': { l1: 'Seq Name', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Choice Between Four': { l1: 'Seq Name', l2: 'N/A', l3: 'N/A', l4: 'N/A' },

  'Start Quest': { l1: 'Quest ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Complete Quest': { l1: 'Quest ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Fail Quest': { l1: 'Quest ID', l2: 'Reason ID', l3: 'N/A', l4: 'N/A' },
  'Reveal Quest': { l1: 'Quest ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Hide Quest': { l1: 'Quest ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Branch Quest': { l1: 'Quest ID', l2: 'Branch ID', l3: 'Condition Key', l4: 'N/A' },

  'Start Objective': { l1: 'Target Task', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Complete Objective': { l1: 'Target Task', l2: 'Target Obj', l3: 'N/A', l4: 'N/A' },
  'Fail Objective': { l1: 'Target Task', l2: 'Reason ID', l3: 'N/A', l4: 'N/A' },
  'Reveal Objective': { l1: 'Target Task', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Hide Objective': { l1: 'Target Task', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Repeat Objective': { l1: 'Target Task', l2: 'Repeat Count', l3: 'N/A', l4: 'N/A' },
  'Random Objective': { l1: 'Objective Pool ID', l2: 'Amount', l3: 'N/A', l4: 'N/A' },

  'Kill Target': { l1: 'Target ID / Name', l2: 'Amount', l3: 'Required Weapon', l4: 'Required Status' },
  'Damage Target': { l1: 'Target ID', l2: 'Damage Amount', l3: 'Damage Type', l4: 'Weapon Required' },
  'Destroy Object': { l1: 'Object ID', l2: 'Amount', l3: 'Weapon Required', l4: 'N/A' },
  'Clear Obstacle': { l1: 'Obstacle ID', l2: 'Amount', l3: 'Tool Required', l4: 'N/A' },
  'Survive Encounter': { l1: 'Encounter ID', l2: 'N/A', l3: 'Min Health %', l4: 'N/A' },
  'Survive Encounter For Time': { l1: 'Encounter ID', l2: 'Time (s)', l3: 'Min Health %', l4: 'N/A' },
  'Fail Encounter': { l1: 'Encounter ID', l2: 'Reason ID', l3: 'N/A', l4: 'N/A' },

  'Collect Item': { l1: 'Item ID', l2: 'Quantity', l3: 'Min Rarity', l4: 'N/A' },
  'Loot Item': { l1: 'Item ID', l2: 'Amount', l3: 'Container ID', l4: 'N/A' },
  'Own Item': { l1: 'Item ID', l2: 'Quantity', l3: 'N/A', l4: 'N/A' },
  'Equip Item': { l1: 'Item ID', l2: 'Slot', l3: 'N/A', l4: 'N/A' },
  'Use Item': { l1: 'Item ID', l2: 'Amount', l3: 'Target ID', l4: 'N/A' },
  'Purchase Item': { l1: 'Item ID', l2: 'Amount', l3: 'Shop ID', l4: 'N/A' },
  'Sell Item': { l1: 'Item ID', l2: 'Amount', l3: 'Shop ID', l4: 'N/A' },

  'Craft Item': { l1: 'Item ID', l2: 'Amount', l3: 'Station ID', l4: 'N/A' },
  'Unlock Crafting Recipe': { l1: 'Recipe ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },

  'Gain Currency': { l1: 'Currency ID', l2: 'Amount', l3: 'Source Filter', l4: 'N/A' },
  'Spend Currency': { l1: 'Currency ID', l2: 'Target Amount', l3: 'N/A', l4: 'N/A' },
  'Own Currency': { l1: 'Currency ID', l2: 'Target Amount', l3: 'Comparison', l4: 'N/A' },
  'Gain Resource': { l1: 'Resource ID', l2: 'Amount', l3: 'Source Filter', l4: 'N/A' },
  'Spend Resource': { l1: 'Resource ID', l2: 'Amount', l3: 'Target ID', l4: 'N/A' },
  'Own Resource': { l1: 'Resource ID', l2: 'Target Amount', l3: 'Comparison', l4: 'N/A' },
  'Spend Upgrade Point': { l1: 'Point Type', l2: 'Amount', l3: 'Target Node', l4: 'N/A' },

  'Reach Location': { l1: 'Zone ID', l2: 'Coordinates', l3: 'Radius', l4: 'N/A' },
  'Enter Scene': { l1: 'Scene ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Exit Scene': { l1: 'Scene ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Visit Room': { l1: 'Room ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Enter Room': { l1: 'Room ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Exit Room': { l1: 'Room ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Enter Mode': { l1: 'Mode ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Exit Mode': { l1: 'Mode ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },

  'View Scene': { l1: 'Scene ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Unlock Scene': { l1: 'Scene ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Complete Scene': { l1: 'Scene ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Replay Scene': { l1: 'Scene ID', l2: 'Amount', l3: 'N/A', l4: 'N/A' },
  'Scene Seen': { l1: 'Scene ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Scene Unseen': { l1: 'Scene ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },

  'Deliver Information': { l1: 'Info ID', l2: 'NPC ID', l3: 'N/A', l4: 'N/A' },
  'Deliver Character': { l1: 'Char ID', l2: 'Location/NPC ID', l3: 'Time Limit', l4: 'N/A' },
  'Protect Traveling Entity': { l1: 'Entity ID', l2: 'Destination ID', l3: 'Min Health %', l4: 'N/A' },
  'Protect Location For Time': { l1: 'Location ID', l2: 'Time (s)', l3: 'Min Health %', l4: 'N/A' },
  'Protect Location Until Event': { l1: 'Location ID', l2: 'Event ID', l3: 'Min Health %', l4: 'N/A' },

  'Wait For Time': { l1: 'Time Unit', l2: 'Amount', l3: 'N/A', l4: 'N/A' },
  'Reach Day': { l1: 'Day Number', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Reach Week': { l1: 'Week Number', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Reach Time Slot': { l1: 'Time Slot ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Schedule Activity': { l1: 'Activity ID', l2: 'Character ID', l3: 'Time Slot ID', l4: 'N/A' },
  'Complete Activity': { l1: 'Activity ID', l2: 'Character ID', l3: 'N/A', l4: 'N/A' },
  'Activity Scheduled': { l1: 'Activity ID', l2: 'Character ID', l3: 'Time Slot ID', l4: 'N/A' },
  'Activity Completed': { l1: 'Activity ID', l2: 'Character ID', l3: 'N/A', l4: 'N/A' },

  'Reach Stat Level': { l1: 'Stat Key', l2: 'Target Value', l3: 'N/A', l4: 'N/A' },
  'Reach Character Level': { l1: 'N/A', l2: 'Target Level', l3: 'N/A', l4: 'N/A' },
  'Reach Class Level': { l1: 'Class ID', l2: 'Target Level', l3: 'N/A', l4: 'N/A' },
  'Reach Profession Level': { l1: 'Profession ID', l2: 'Target Level', l3: 'N/A', l4: 'N/A' },
  'Unlock Class': { l1: 'Class ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Unlock Profession': { l1: 'Profession ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },

  'Gain Relationship Level': { l1: 'NPC ID', l2: 'Target Level', l3: 'N/A', l4: 'N/A' },
  'Reach Trust Level': { l1: 'Character ID', l2: 'Target Value', l3: 'N/A', l4: 'N/A' },
  'Reach Lust Level': { l1: 'Character ID', l2: 'Target Value', l3: 'N/A', l4: 'N/A' },
  'Reach Friendship Level': { l1: 'Character ID', l2: 'Target Value', l3: 'N/A', l4: 'N/A' },
  'Reach Suspicion Level': { l1: 'Character/Faction ID', l2: 'Target Value', l3: 'Comparison', l4: 'N/A' },
  'Lower Suspicion Level': { l1: 'Character/Faction ID', l2: 'Target Value', l3: 'N/A', l4: 'N/A' },
  'Relationship Above': { l1: 'Character ID', l2: 'Relationship Type', l3: 'Target Value', l4: 'N/A' },
  'Relationship Below': { l1: 'Character ID', l2: 'Relationship Type', l3: 'Target Value', l4: 'N/A' },
  'Suspicion Above': { l1: 'Character/Faction ID', l2: 'Target Value', l3: 'N/A', l4: 'N/A' },
  'Suspicion Below': { l1: 'Character/Faction ID', l2: 'Target Value', l3: 'N/A', l4: 'N/A' },

  'Assign Character State': { l1: 'Character ID', l2: 'State ID', l3: 'N/A', l4: 'N/A' },
  'Reach Character State': { l1: 'Character ID', l2: 'State ID', l3: 'N/A', l4: 'N/A' },
  'Character In State': { l1: 'Character ID', l2: 'State ID', l3: 'N/A', l4: 'N/A' },
  'Character Not In State': { l1: 'Character ID', l2: 'State ID', l3: 'N/A', l4: 'N/A' },
  'Character In Location': { l1: 'Character ID', l2: 'Location ID', l3: 'N/A', l4: 'N/A' },
  'Character Not In Location': { l1: 'Character ID', l2: 'Location ID', l3: 'N/A', l4: 'N/A' },
  'Character In Room': { l1: 'Character ID', l2: 'Room ID', l3: 'N/A', l4: 'N/A' },
  'Character Not In Room': { l1: 'Character ID', l2: 'Room ID', l3: 'N/A', l4: 'N/A' },
  'Character Present': { l1: 'Character ID', l2: 'Location/Room ID', l3: 'N/A', l4: 'N/A' },
  'Character Absent': { l1: 'Character ID', l2: 'Location/Room ID', l3: 'N/A', l4: 'N/A' },
  'Character Assigned Activity': { l1: 'Character ID', l2: 'Activity ID', l3: 'Time Slot ID', l4: 'N/A' },

  'Equip Outfit': { l1: 'Character ID', l2: 'Outfit ID', l3: 'Slot', l4: 'N/A' },
  'Equip Pose': { l1: 'Character ID', l2: 'Pose ID', l3: 'N/A', l4: 'N/A' },
  'Character Wearing Outfit': { l1: 'Character ID', l2: 'Outfit ID', l3: 'Slot', l4: 'N/A' },
  'Character Not Wearing Outfit': { l1: 'Character ID', l2: 'Outfit ID', l3: 'Slot', l4: 'N/A' },
  'Character Using Pose': { l1: 'Character ID', l2: 'Pose ID', l3: 'N/A', l4: 'N/A' },
  'Character Not Using Pose': { l1: 'Character ID', l2: 'Pose ID', l3: 'N/A', l4: 'N/A' },

  'Own Decoration': { l1: 'Decoration ID', l2: 'Room ID', l3: 'N/A', l4: 'N/A' },
  'Place Decoration': { l1: 'Decoration ID', l2: 'Room ID', l3: 'Slot ID', l4: 'N/A' },
  'Remove Decoration': { l1: 'Decoration ID', l2: 'Room ID', l3: 'Slot ID', l4: 'N/A' },
  'Room Decor Value': { l1: 'Room ID', l2: 'Target Value', l3: 'Comparison', l4: 'N/A' },
  'Room Mood Value': { l1: 'Room ID', l2: 'Mood Key', l3: 'Target Value', l4: 'Comparison' },

  'Use Ability': { l1: 'Ability ID', l2: 'Amount', l3: 'Target ID', l4: 'N/A' },
  'Unlock Ability': { l1: 'Ability ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Complete Minigame': { l1: 'Minigame ID', l2: 'Score', l3: 'Difficulty', l4: 'Time Limit' },
  'Fail Minigame': { l1: 'Minigame ID', l2: 'Reason ID', l3: 'Difficulty', l4: 'N/A' },
  'Reach Minigame Score': { l1: 'Minigame ID', l2: 'Target Score', l3: 'Difficulty', l4: 'N/A' },
  'Take Screenshot': { l1: 'Target ID', l2: 'Camera ID', l3: 'Required Tag', l4: 'N/A' },

  'Leaderboard Entry': { l1: 'Board ID', l2: 'Score/Rank', l3: 'N/A', l4: 'N/A' },
  'Achievement Entry': { l1: 'Achievement ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },

  'Reach Business Tier': { l1: 'Business ID', l2: 'Target Tier', l3: 'N/A', l4: 'N/A' },
  'Reach Reputation': { l1: 'Reputation ID', l2: 'Target Value', l3: 'Comparison', l4: 'N/A' },
  'Reach Faction Rank': { l1: 'Faction ID', l2: 'Target Rank', l3: 'N/A', l4: 'N/A' },
  'Reach Income Per Day': { l1: 'Currency ID', l2: 'Target Amount', l3: 'Source Filter', l4: 'N/A' },
  'Reach Net Worth': { l1: 'Currency ID', l2: 'Target Amount', l3: 'Comparison', l4: 'N/A' },
  'Reach Subscriber Count': { l1: 'Platform ID', l2: 'Target Count', l3: 'N/A', l4: 'N/A' },
  'Reach Follower Count': { l1: 'Platform ID', l2: 'Target Count', l3: 'N/A', l4: 'N/A' },
  'Reach Viewer Count': { l1: 'Platform ID', l2: 'Target Count', l3: 'N/A', l4: 'N/A' },
  'Reach Sales Count': { l1: 'Product/Platform ID', l2: 'Target Count', l3: 'N/A', l4: 'N/A' },

  'OnlySam Tier Reached': { l1: 'Tier ID', l2: 'Target Level', l3: 'N/A', l4: 'N/A' },
  'OnlySam Post Created': { l1: 'Post Type', l2: 'Amount', l3: 'Character ID', l4: 'N/A' },
  'OnlySam Post Viewed': { l1: 'Post ID', l2: 'Amount', l3: 'Viewer Type', l4: 'N/A' },
  'OnlySam Subscriber Count': { l1: 'Target Count', l2: 'Comparison', l3: 'N/A', l4: 'N/A' },
  'OnlySam Revenue Earned': { l1: 'Currency ID', l2: 'Amount', l3: 'Source Filter', l4: 'N/A' },

  'Trigger Event': { l1: 'Event ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Complete Event': { l1: 'Event ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Event Seen': { l1: 'Event ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Event Unseen': { l1: 'Event ID', l2: 'N/A', l3: 'N/A', l4: 'N/A' },

  'Set Game State': { l1: 'State Key', l2: 'Target Value', l3: 'N/A', l4: 'N/A' },
  'Check Game State': { l1: 'State Key', l2: 'Required Value', l3: 'N/A', l4: 'N/A' },
  'Change Game State Value': { l1: 'State Key', l2: 'Amount', l3: 'Operation', l4: 'N/A' },
  'Game State Equals': { l1: 'State Key', l2: 'Required Value', l3: 'N/A', l4: 'N/A' },
  'Game State Not Equal': { l1: 'State Key', l2: 'Blocked Value', l3: 'N/A', l4: 'N/A' },
  'Game State Greater Than': { l1: 'State Key', l2: 'Required Value', l3: 'N/A', l4: 'N/A' },
  'Game State Less Than': { l1: 'State Key', l2: 'Required Value', l3: 'N/A', l4: 'N/A' },
  'Game State Exists': { l1: 'State Key', l2: 'N/A', l3: 'N/A', l4: 'N/A' },
  'Game State Missing': { l1: 'State Key', l2: 'N/A', l3: 'N/A', l4: 'N/A' },

  'Unlock Content': { l1: 'Content ID', l2: 'Content Type', l3: 'N/A', l4: 'N/A' },
  'Lock Content': { l1: 'Content ID', l2: 'Content Type', l3: 'N/A', l4: 'N/A' },
  'View Content': { l1: 'Content ID', l2: 'Content Type', l3: 'N/A', l4: 'N/A' },
  'Content Seen': { l1: 'Content ID', l2: 'Content Type', l3: 'N/A', l4: 'N/A' },
  'Content Unseen': { l1: 'Content ID', l2: 'Content Type', l3: 'N/A', l4: 'N/A' },

  'Custom Condition': { l1: 'Left Value', l2: 'Operator', l3: 'Right Value', l4: 'Optional Context' },
  'Custom Counter': { l1: 'Counter Key', l2: 'Target Value', l3: 'Comparison', l4: 'Source Filter' },
  'Custom Flag': { l1: 'Flag Key', l2: 'Required Value', l3: 'N/A', l4: 'N/A' },
  'Custom Event': { l1: 'Event Key', l2: 'Payload Value', l3: 'Source ID', l4: 'N/A' }
};

function createBaseEntry(overrides = {}) {
    return {
        id: crypto.randomUUID(),
        tab: 'Tasks',
        name: '',
        displayId: '',
        displayName: '',
        namespace: '',
        questGiver: '',
        setting: '',
        turnIn: '',
        showGiver: false,
        showTurnIn: false,
        faction: '',
        tags: [],
        desc: '',
        completionText: '',
        failureText: '',
        color: getRandomColor(),
        chainColor: getRandomColor(),
        chainDesc: '',
        chainEmoji: '🔮',
        taskType: 'Task',
        chainName: '',
        initialState: 'Locked',
        autoUnlock: false,
        autoStart: false,
        autoComplete: false,
        repeatable: false,
        resettable: false,
        branchExclusive: false,
        branchRule: 'First Valid',
        storyBeatType: 'Visible Quest Progress',
        timeAvail: '',
        timeExpire: '',
        cooldown: '',
        repeatInterval: '',
        objectives: [],
        dependencies: [],
        showDeps: false,
        showChain: false,
        calledExternally: false,
        makeExternalCall: false,
        conditions: [],
        stateChanges: [],
        customGameplayValues: [], 
        unlockCondition: { key: '', op: '==', val: '' },
        completeCondition: { key: '', op: '==', val: '' },
        failCondition: { key: '', op: '==', val: '' },
        rewardCondition: { key: '', op: '==', val: '' },
        collapsed: false,
        subCategoriesCollapsed: {
            conditions: false,
            stateChanges: false,
            summary: false,
            dependencies: false,
            tags: false,
            objectives: false,
            branch: false,
            time: false,
            reward_vault: false,
            reward_arsenal: false,
            reward_ladder: false,
            reward_story: false,
            reward_hooks: false,
            rewards: false
        },
        lastModified: new Date().toISOString(),
        ...overrides
    };
}

function normalizeObjective(obj) {
    if (!obj.targets) {
        obj.targets = [{
            id: crypto.randomUUID(),
            type: obj.type || 'Collect Item',
            val1: obj.val1 || '',
            val2: obj.val2 || '',
            val3: '',
            val4: '',
            useDesc: obj.useDesc !== undefined ? obj.useDesc : true,
            desc: obj.desc || ''
        }];
        delete obj.type; delete obj.val1; delete obj.val2; delete obj.useDesc; delete obj.desc;
    } else {
        obj.targets = obj.targets.map(t => ({
            ...t,
            val3: t.val3 || '',
            val4: t.val4 || '',
            useDesc: t.useDesc !== undefined ? t.useDesc : true,
            desc: t.desc || ''
        }));
    }
    return obj;
}

function loadInitialData() {
    const sampleFieldId = crypto.randomUUID();
    state.globalCustomFields = [
        { id: sampleFieldId, title: 'Blow Jibber', key: 'bj', op: '==', val: '1', color: '#00f2ff' }
    ];

    const idT1 = crypto.randomUUID(); const idT2 = crypto.randomUUID(); const idT3 = crypto.randomUUID(); const idT4 = crypto.randomUUID();
    const idA1 = crypto.randomUUID(); const idA2 = crypto.randomUUID(); const idA3 = crypto.randomUUID(); const idA4 = crypto.randomUUID();
    const idD1 = crypto.randomUUID();

    const defCgv = () => [{ fieldId: sampleFieldId, key: 'bj', op: '==', val: '1', hideVisual: false }];
    
    const dummyObjBase = {
        id: crypto.randomUUID(), 
        calledExternally: false, 
        externallyCalled: false,
        isMandatory: true, 
        isRepeatable: false, 
        isAbandonable: false,
        isCollapsed: false,
        phase: 'Single Phase',
        repeatableCond: {key: '', op: '==', val: '1'}, 
        abandonableCond: {key: '', op: '==', val: '1'},
        conditions: [], 
        stateChanges: [], 
        subCollapsed: { conditions: true, stateChanges: true }
    };

    state.entries = [
        createBaseEntry({
            id: idT1, tab: "Tasks", name: "Job Application", displayId: "QST-001-A", displayName: "A New Beginning", namespace: "MainQuest",
            tags: ["tutorial", "stealth", "intro"], desc: "Apply for the security guard job at the nuclear facility.",
            completionText: "You got the job.", failureText: "You failed the background check.",
            color: "#89e7f8", chainColor: "#ba67cb", taskType: "root", chainName: "First Day On The Job", chainEmoji: "🎯",
            initialState: "Available",
            objectives: [normalizeObjective({ ...dummyObjBase, text: "Submit Resume", targets: [{id: crypto.randomUUID(), type: "Talk To NPC", val1: "npc_hr_manager", val2: "dial_hr_01", val3: "Friendly", val4: "", useDesc: true, desc: "Give your resume to the front desk HR manager in building B."}] })],
            conditions: [{ key: 'onGameStart', op: '==', val: '12', context: 'Standard' }, { key: 'completeVeteranIntroDuction', op: '==', val: '1', context: 'Standard' }],
            stateChanges: [{ key: 'CivilianCloths', op: '==', val: '1' }],
            completeCondition: { key: 'completeVeteranIntroDuction', op: '==', val: '1' },
            customGameplayValues: defCgv()
        }),
        createBaseEntry({
            id: idT2, tab: "Tasks", name: "Sam Introduction", namespace: "MainQuest", desc: "Meet Sam in disguise as a trapped rescue worker.",
            color: "#fce8ba", chainColor: "#ba67cb", taskType: "node", chainName: "First Day On The Job", chainEmoji: "🎯",
            conditions: [{ key: 'completeVeteranIntroDuction', op: '==', val: '1', context: 'Standard' }], stateChanges: [{ key: 'Trust', op: '==', val: '1' }],
            unlockCondition: { key: 'completeVeteranIntroDuction', op: '==', val: '1' }, rewardCondition: { key: 'Trust', op: '==', val: '1' },
            dependencies: [idT1], showChain: true, showDeps: true, customGameplayValues: defCgv()
        }),
        createBaseEntry({
            id: idT3, tab: "Tasks", name: "Facility Tour", namespace: "MainQuest", tags: ["exploration"], desc: "Take the standard security tour of the facility.",
            color: "#ff0088", chainColor: "#ba67cb", taskType: "node", chainName: "First Day On The Job", chainEmoji: "🎯",
            calledExternally: true, conditions: [{ key: 'samIntroDone', op: '==', val: '1', context: 'Standard' }], stateChanges: [{ key: 'tourComplete', op: '==', val: '1' }],
            unlockCondition: { key: 'samIntroDone', op: '==', val: '1' }, completeCondition: { key: 'tourComplete', op: '==', val: '1' },
            dependencies: [idT2], showChain: true, showDeps: true, customGameplayValues: defCgv()
        }),
        createBaseEntry({
            id: idT4, tab: "Tasks", name: "First Day Complete", namespace: "MainQuest", desc: "Conclude your first day successfully.",
            color: "#00ffcc", chainColor: "#ba67cb", taskType: "endpoint", chainName: "First Day On The Job", chainEmoji: "🎯",
            makeExternalCall: true, conditions: [{ key: 'tourComplete', op: '==', val: '1', context: 'Standard' }], stateChanges: [{ key: 'dayOneOver', op: '==', val: '1' }],
            unlockCondition: { key: 'tourComplete', op: '==', val: '1' }, completeCondition: { key: 'dayOneOver', op: '==', val: '1' },
            rewardCondition: { key: 'Friendship', op: '==', val: '1' }, dependencies: [idT3], showChain: true, showDeps: true, customGameplayValues: defCgv()
        }),
        createBaseEntry({
            id: idA1, tab: "Achievements", name: "Security Clearance Level 1", namespace: "Progression", desc: "Granted basic access to the public lobby and cafeteria.",
            color: "#00ff88", chainColor: "#00ff88", taskType: "root", chainName: "Clearance Protocol", chainEmoji: "🗝️",
            calledExternally: true, conditions: [{ key: 'onGameStart', op: '==', val: '1', context: 'Standard' }], unlockCondition: { key: 'onGameStart', op: '==', val: '1' },
            rewardCondition: { key: 'clearanceLvl', op: '==', val: '1' }, showChain: true, customGameplayValues: defCgv()
        }),
        createBaseEntry({
            id: idA2, tab: "Achievements", name: "Security Clearance Level 2", namespace: "Progression", desc: "Granted access to the lower maintenance levels.",
            color: "#00ff88", chainColor: "#00ff88", taskType: "node", chainName: "Clearance Protocol", chainEmoji: "🗝️",
            conditions: [{ key: 'clearanceLvl', op: '>=', val: '1', context: 'Standard' }], unlockCondition: { key: 'clearanceLvl', op: '>=', val: '1' },
            rewardCondition: { key: 'clearanceLvl', op: '==', val: '2' }, dependencies: [idA1], showChain: true, showDeps: true, customGameplayValues: defCgv()
        }),
        createBaseEntry({
            id: idA3, tab: "Achievements", name: "Security Clearance Level 3", namespace: "Progression", desc: "Granted access to the reactor core and secure labs.",
            color: "#00ff88", chainColor: "#00ff88", taskType: "node", chainName: "Clearance Protocol", chainEmoji: "🗝️",
            conditions: [{ key: 'clearanceLvl', op: '>=', val: '2', context: 'Standard' }], unlockCondition: { key: 'clearanceLvl', op: '>=', val: '2' },
            rewardCondition: { key: 'clearanceLvl', op: '==', val: '3' }, dependencies: [idA2], showChain: true, showDeps: true, customGameplayValues: defCgv()
        }),
        createBaseEntry({
            id: idA4, tab: "Achievements", name: "Director Clearance", namespace: "Progression", desc: "Full, unhindered facility access.",
            color: "#ffd700", chainColor: "#00ff88", taskType: "endpoint", chainName: "Clearance Protocol", chainEmoji: "🗝️",
            makeExternalCall: true, conditions: [{ key: 'clearanceLvl', op: '>=', val: '3', context: 'Standard' }], unlockCondition: { key: 'clearanceLvl', op: '>=', val: '3' },
            rewardCondition: { key: 'clearanceLvl', op: '==', val: '4' }, dependencies: [idA3], showChain: true, showDeps: true, customGameplayValues: defCgv()
        }),
        createBaseEntry({
            id: idD1, tab: "Dev", name: "Force Debug Variables", namespace: "Testing", tags: ["debug", "testing", "wip"], desc: "Allows dev testing of all relationship properties.",
            color: "#ff0022", taskType: "Debug/Test", chainEmoji: "🔮", calledExternally: true, makeExternalCall: true,
            unlockCondition: { key: 'Suspicion', op: '==', val: '0' }, failCondition: { key: 'Lust', op: '>=', val: '5' }, customGameplayValues: defCgv()
        })
    ];
}