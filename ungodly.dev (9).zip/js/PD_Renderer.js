/**
 * NF_Renderer.js
 * UI rendering operations, tabs, list generations, property inspector panels, HTML building for Tools.
 */

function setOverTab(tab) {
    activeOverTab = tab;
    document.getElementById('overtab-nodes').classList.toggle('active', tab === 'nodes');
    document.getElementById('overtab-tools').classList.toggle('active', tab === 'tools');
    
    // Explicitly toggle flex and hidden to ensure Tailwind doesn't break the layout bounding box computations
    const toggleFlexView = (id, show) => {
        const el = document.getElementById(id);
        if (!el) return;
        if (show) {
            el.classList.remove('hidden');
            el.classList.add('flex');
        } else {
            el.classList.add('hidden');
            el.classList.remove('flex');
        }
    };
    
    toggleFlexView('left-nodes-view', tab === 'nodes');
    toggleFlexView('left-tools-view', tab === 'tools');
    toggleFlexView('middle-nodes-view', tab === 'nodes');
    toggleFlexView('middle-tools-view', tab === 'tools');
    toggleFlexView('right-nodes-view', tab === 'nodes');
    toggleFlexView('right-tools-view', tab === 'tools');

    if(tab === 'nodes') {
        renderAvailableList();
        renderNodes();
        if(rightTab==='inspector') renderInspector(); else renderLogicPanel();
    } else {
        renderToolLibrary();
        renderToolEditor();
        renderToolLogicPanel();
    }
}

function setToolCategory(cat) {
    activeToolCategory = cat;
    document.getElementById('t-tab-trans').classList.toggle('active', cat === 'trans');
    document.getElementById('t-tab-imgnode').classList.toggle('active', cat === 'imgnode');
    document.getElementById('t-tab-imgdb').classList.toggle('active', cat === 'imgdb');
    document.getElementById('t-tab-imgdb').innerText = "Seq Settings";
    
    document.querySelectorAll('#tool-category-tabs .registry-btn').forEach(btn => {
        btn.classList.add('rounded-t-md');
    });

    let titleMap = { 'trans': 'Transition Database', 'imgnode': 'Image Node Database', 'imgdb': 'Sequence Settings' };
    document.getElementById('tool-search-title').innerText = titleMap[cat];
    
    renderToolLibrary();
    renderToolEditor();
}

function setToolLogicTab(tab) {
    activeToolLogicTab = tab;
    document.getElementById('t-tab-local').classList.toggle('active', tab === 'local');
    document.getElementById('t-tab-master').classList.toggle('active', tab === 'master');
    renderToolLogicPanel();
}

function setLeftTab(tab) {
    leftTab = tab;
    document.querySelectorAll('#left-tabs .registry-btn').forEach(b => b.classList.remove('active'));
    const targetBtn = document.getElementById(`tab-${tab}`);
    if (targetBtn) targetBtn.classList.add('active');
    renderAvailableList();
}

function setRightTab(tab) {
    rightTab = tab;
    document.getElementById('tab-inspector').classList.toggle('active', tab === 'inspector');
    document.getElementById('tab-logic').classList.toggle('active', tab === 'logic');
    document.getElementById('inspector-content').classList.toggle('hidden', tab !== 'inspector');
    document.getElementById('logic-content').classList.toggle('hidden', tab !== 'logic');
    if(tab === 'inspector') renderInspector();
    if(tab === 'logic') renderLogicPanel();
}

function toggleLeftGroup(id) {
    if (collapsedLeftGroups.has(id)) collapsedLeftGroups.delete(id); else collapsedLeftGroups.add(id);
    if(activeOverTab === 'nodes') renderAvailableList();
    if(activeOverTab === 'tools') renderToolLibrary();
}

function toggleMiddleSection(id) {
    if (collapsedMiddleGroups.has(id)) collapsedMiddleGroups.delete(id); else collapsedMiddleGroups.add(id);
    renderToolEditor();
}

function updateTaskTabColor(tabName, color) {
    globalTaskTabColors[tabName] = color;
    sourceData.tasks.forEach(t => { if ((t.tab || 'Uncategorized') === tabName) t.color = color; });
    storyNodes.forEach(n => {
        if (n.type === 'task') {
            const src = sourceData.tasks.find(s => s.name === n.sourceRef);
            if (src && (src.tab || 'Uncategorized') === tabName) n.color = color;
        }
    });
    renderAvailableList(); renderNodes();
}

function updatePromptTagColor(tagName, color) {
    globalPromptTagColors[tagName] = color;
    sourceData.prompts.forEach(p => { if ((p.tag || 'Uncategorized') === tagName) p.color = color; });
    storyNodes.forEach(n => {
        if (n.type === 'prompt') {
            const src = sourceData.prompts.find(s => s.title === n.sourceRef);
            if (src && (src.tag || 'Uncategorized') === tagName) n.color = color;
        }
    });
    renderAvailableList(); renderNodes();
}

function showNodeSourceContext(e, item, type) {
    e.preventDefault(); e.stopPropagation();
    let arr = null;
    if(type === 'conversation') arr = sourceData.dialogues;
    else if(type === 'sequence') arr = sourceData.sequences;
    else if(type === 'task') arr = sourceData.tasks;
    else if(type === 'menu') arr = sourceData.menus;
    else if(type === 'prompt') arr = sourceData.prompts;
    else if(type === 'trans') arr = toolingData.transitions;
    else if(type === 'imgnode') arr = toolingData.imageNodes;
    
    if(!arr) return;
    let index = arr.findIndex(i => i.id === item.id || (i.title||i.name||i.text) === (item.title||item.name||item.text));
    if(index === -1) return;
    
    contextTargetItem = { arr, index, type };
    const menu = document.getElementById('node-source-context-menu');
    menu.style.left = e.clientX + 'px';
    menu.style.top = e.clientY + 'px';
    menu.classList.remove('hidden');
}

function renameNodeSource() {
    if(!contextTargetItem) return;
    if (contextTargetItem.type !== 'trans' && contextTargetItem.type !== 'imgnode') {
        if(!confirm("WARNING: Modifying this externally generated node may cause NarrativeFlow to desync from the other JSON files. Proceed?")) {
            closeContextMenus(); return;
        }
    }
    const item = contextTargetItem.arr[contextTargetItem.index];
    const oldName = item.title || item.name || item.text;
    const newName = prompt("Rename item:", oldName);
    if(newName && newName !== oldName && newName.trim() !== '') {
        if(item.title !== undefined) item.title = newName;
        if(item.name !== undefined) item.name = newName;
        if(item.text !== undefined) item.text = newName;
        
        storyNodes.forEach(n => {
            if(n.sourceRef === oldName && n.type === contextTargetItem.type) {
                n.sourceRef = newName;
                if(n.title === oldName) n.title = newName;
            }
        });
        updateProjectLogic();
        renderAvailableList();
        renderNodes();
    }
    closeContextMenus();
}

function duplicateNodeSource() {
    if(!contextTargetItem) return;
    if (contextTargetItem.type !== 'trans' && contextTargetItem.type !== 'imgnode') {
        if(!confirm("WARNING: Modifying this externally generated node may cause NarrativeFlow to desync from the other JSON files. Proceed?")) {
            closeContextMenus(); return;
        }
    }
    const item = contextTargetItem.arr[contextTargetItem.index];
    let copy = JSON.parse(JSON.stringify(item));
    copy.id = generateUUID();
    let nameField = copy.title !== undefined ? 'title' : (copy.name !== undefined ? 'name' : 'text');
    copy[nameField] = copy[nameField] + " (Copy)";
    contextTargetItem.arr.push(copy);
    updateProjectLogic();
    renderAvailableList();
    closeContextMenus();
}

function deleteNodeSource() {
    if(!contextTargetItem) return;
    if (contextTargetItem.type !== 'trans' && contextTargetItem.type !== 'imgnode') {
        if(!confirm("WARNING: Modifying this externally generated node may cause NarrativeFlow to desync from the other JSON files. Proceed?")) {
            closeContextMenus(); return;
        }
    }
    contextTargetItem.arr.splice(contextTargetItem.index, 1);
    updateProjectLogic();
    renderAvailableList();
    closeContextMenus();
}

function renameContextNode() {
    if(contextTargetNodeId) {
        const node = storyNodes.find(n => n.id === contextTargetNodeId);
        if (node && node.type !== 'trans' && node.type !== 'imgnode') {
            if(!confirm("WARNING: Modifying this externally generated node may cause NarrativeFlow to desync from the other JSON files. Proceed?")) {
                closeContextMenus(); return;
            }
        }
        if(node) {
            const newName = prompt("Rename Canvas Node:", node.title);
            if(newName && newName.trim() !== '') {
                node.title = newName;
                renderNodes();
                if(rightTab === 'inspector') renderInspector();
            }
        }
    }
    closeContextMenus();
}

function duplicateContextNode() {
    if(contextTargetNodeId) {
        const node = storyNodes.find(n => n.id === contextTargetNodeId);
        if (node && node.type !== 'trans' && node.type !== 'imgnode') {
            if(!confirm("WARNING: Modifying this externally generated node may cause NarrativeFlow to desync from the other JSON files. Proceed?")) {
                closeContextMenus(); return;
            }
        }
        if(!selectedNodeIds.includes(contextTargetNodeId)) selectedNodeIds = [contextTargetNodeId];
        duplicateSelectedNodes();
    }
    closeContextMenus();
}

function triggerRenameToolSection() {
    if (contextMenuSectionTarget && contextMenuSectionType) {
        renameToolSection(contextMenuSectionType, contextMenuSectionTarget);
    }
    closeContextMenus();
}

// --- MAIN LEFT PANEL (NODES VIEW) ---
function renderAvailableList() {
    const list = document.getElementById('available-source-list');
    list.innerHTML = '';
    
    const renderItem = (item, type, colorOverride, containerElement = list) => {
        const el = document.createElement('div');
        el.className = 'source-item tool-left-item';
        const rawName = item.title || item.name || item.text || "Unnamed";
        let displayTitle = rawName; if (displayTitle.length > 20) displayTitle = displayTitle.substring(0, 20) + '...';
        let extraTag = '';
        if (item.isRepeatable) extraTag = `<span class="flex-shrink-0" style="color:var(--accent-pink); font-size:0.55rem; font-weight:800; margin-left:8px; padding:2px 4px; border:1px solid var(--accent-pink);">LOOP</span>`;
        if (item.taskType) extraTag = `<span class="flex-shrink-0" style="color:var(--accent-purple); font-size:0.55rem; font-weight:800; margin-left:8px; padding:2px 4px; border:1px solid var(--accent-purple);">${item.taskType.toUpperCase()}</span>`;
        let rawSubtext = item.desc || item.bodyText || (item.participants ? item.participants.join(', ') : '');
        let cleanSubtext = rawSubtext.replace(/<[^>]*>?/gm, ''); let displaySubtext = cleanSubtext;
        if (displaySubtext.length > 30) displaySubtext = displaySubtext.substring(0, 30) + '...';
        let actualColor = colorOverride || item.color || "var(--border-color)";

        el.innerHTML = `
            <div style="border-left: 3px solid ${actualColor}; padding-left: 8px; pointer-events: none;">
                <h4 class="text-sm font-bold text-white mb-1 flex items-center w-full overflow-hidden" title="${escapeHtml(rawName)}">
                    <span class="truncate flex-1 block">${escapeHtml(displayTitle)}</span>${extraTag}
                </h4>
                <p class="text-[10px] text-[var(--text-dim)] font-bold truncate w-full" title="${escapeHtml(cleanSubtext)}">${escapeHtml(displaySubtext)}</p>
            </div>`;
        el.onclick = () => { item.color = actualColor; createNodeFromSource(item, type); };
        el.oncontextmenu = (e) => showNodeSourceContext(e, item, type);
        containerElement.appendChild(el);
    };

    if (leftTab === 'convo') {
        if (sourceData.dialogues.length === 0 && sourceData.sequences.length === 0) { list.innerHTML = '<div class="empty-state">No Convos/Seqs Imported.</div>'; return; }
        if (sourceData.dialogues.length > 0) {
            const dId = 'group_dlgs'; const isCol = collapsedLeftGroups.has(dId);
            const header = document.createElement('div');
            header.className = "nested-header"; header.style.cssText = "color: var(--accent-teal); border-color: var(--accent-teal); cursor:pointer;";
            header.innerHTML = `<span>${isCol ? '▶' : '▼'} Conversations</span>`;
            header.onclick = () => toggleLeftGroup(dId);
            header.oncontextmenu = (e) => showSidebarContextMenu(e, { type: 'conversation' });
            list.appendChild(header);
            if (!isCol) sourceData.dialogues.forEach(c => renderItem(c, 'conversation', c.color || 'var(--accent-teal)', list));
        }
        if (sourceData.sequences.length > 0) {
            const sId = 'group_seqs'; const isCol = collapsedLeftGroups.has(sId);
            const header = document.createElement('div');
            header.className = "nested-header"; header.style.cssText = "color: var(--accent-blue); border-color: var(--accent-blue); margin-top: 25px; cursor:pointer;";
            header.innerHTML = `<span>${isCol ? '▶' : '▼'} Sequences</span>`;
            header.onclick = () => toggleLeftGroup(sId);
            header.oncontextmenu = (e) => showSidebarContextMenu(e, { type: 'sequence' });
            list.appendChild(header);
            if (!isCol) sourceData.sequences.forEach(s => renderItem(s, 'sequence', s.color || 'var(--accent-blue)', list));
        }
    } 
    else if (leftTab === 'task') {
        if (sourceData.tasks.length === 0) { list.innerHTML = '<div class="empty-state">No Tasks Imported.</div>'; return; }
        const tabs = [...new Set(sourceData.tasks.map(t => t.tab || 'Uncategorized'))];
        tabs.forEach(tab => {
            const tId = `task_${tab.replace(/[^a-zA-Z0-9]/g, '_')}`; const isCol = collapsedLeftGroups.has(tId);
            let color = globalTaskTabColors[tab] || '#ff8c00';
            const header = document.createElement('div');
            header.className = "nested-header"; header.style.cssText = `color: ${color}; border-color: ${color}; cursor:pointer;`;
            header.innerHTML = `<span>${isCol ? '▶' : '▼'} ${escapeHtml(tab)}</span><input type="color" value="${color}" style="height:20px; width:30px; padding:0; cursor:pointer; border-radius:0;" onchange="updateTaskTabColor('${escapeHtml(tab)}', this.value)" onclick="event.stopPropagation();">`;
            header.onclick = (e) => { if(e.target.tagName !== 'INPUT') toggleLeftGroup(tId); };
            header.oncontextmenu = (e) => showSidebarContextMenu(e, { type: 'task', tab: tab });
            list.appendChild(header);
            if (!isCol) {
                const itemsContainer = document.createElement('div');
                sourceData.tasks.filter(t => (t.tab || 'Uncategorized') === tab).forEach(t => renderItem(t, 'task', color, itemsContainer));
                list.appendChild(itemsContainer);
            }
        });
    }
    else if (leftTab === 'option') {
        if (sourceData.menus.length === 0) { list.innerHTML = '<div class="empty-state">No Options Imported.</div>'; return; }
        const groups = [...new Set(sourceData.menus.map(m => m.groupName || 'GLOBAL MENUS'))];
        groups.forEach(group => {
            const gId = `menu_${group.replace(/[^a-zA-Z0-9]/g, '_')}`; const isCol = collapsedLeftGroups.has(gId);
            let headerTitle = group === 'GLOBAL MENUS' ? 'GLOBAL MENUS' : `CONTEXT: ${group}`;
            const groupHeader = document.createElement('div');
            groupHeader.className = "nested-header"; groupHeader.style.cssText = "color: var(--accent-green); border-color: var(--accent-green); cursor:pointer; background: #0a0a0a; padding: 6px; margin: 8px 0 2px 0;";
            groupHeader.innerHTML = `<span>${isCol ? '▶' : '▼'} ${escapeHtml(headerTitle)}</span>`;
            groupHeader.onclick = () => toggleLeftGroup(gId);
            groupHeader.oncontextmenu = (e) => showSidebarContextMenu(e, { type: 'menu', group: group });
            list.appendChild(groupHeader);
            
            if (!isCol) {
                const groupMenus = sourceData.menus.filter(m => (m.groupName || 'GLOBAL MENUS') === group);
                const chars = [...new Set(groupMenus.map(m => m.characterName || 'General'))];
                chars.forEach(char => {
                    const cId = `${gId}_${char.replace(/[^a-zA-Z0-9]/g, '_')}`; const isCCol = collapsedLeftGroups.has(cId);
                    const charHeader = document.createElement('div');
                    charHeader.className = "nested-header"; charHeader.style.cssText = "font-size: 0.6rem; padding: 4px 6px 4px 15px; color: #ccc; margin: 2px 0; border-bottom: 1px dotted #444; border-top: none; background: #111; cursor:pointer;";
                    charHeader.innerHTML = `<span>${isCCol ? '▶' : '▼'} Char: ${escapeHtml(char)}</span>`;
                    charHeader.onclick = () => toggleLeftGroup(cId);
                    charHeader.oncontextmenu = (e) => showSidebarContextMenu(e, { type: 'menu', group: group, char: char });
                    list.appendChild(charHeader);
                    if (!isCCol) {
                        const itemsContainer = document.createElement('div'); itemsContainer.style.paddingLeft = "20px";
                        groupMenus.filter(m => (m.characterName || 'General') === char).forEach(m => renderItem(m, 'menu', 'var(--accent-green)', itemsContainer));
                        list.appendChild(itemsContainer);
                    }
                });
            }
        });
    }
    else if (leftTab === 'prompt') {
        if (sourceData.prompts.length === 0) { list.innerHTML = '<div class="empty-state">No Prompts Imported.</div>'; return; }
        const tags = [...new Set(sourceData.prompts.map(p => p.tag || 'Uncategorized'))];
        tags.forEach(tag => {
            const pId = `prompt_${tag.replace(/[^a-zA-Z0-9]/g, '_')}`; const isCol = collapsedLeftGroups.has(pId);
            let color = globalPromptTagColors[tag] || '#ff007b';
            const header = document.createElement('div');
            header.className = "nested-header"; header.style.cssText = `color: ${color}; border-color: ${color}; cursor:pointer;`;
            header.innerHTML = `<span>${isCol ? '▶' : '▼'} ${escapeHtml(tag)}</span><input type="color" value="${color}" style="height:20px; width:30px; padding:0; cursor:pointer; border-radius:0;" onchange="updatePromptTagColor('${escapeHtml(tag)}', this.value)" onclick="event.stopPropagation();">`;
            header.onclick = (e) => { if(e.target.tagName !== 'INPUT') toggleLeftGroup(pId); };
            header.oncontextmenu = (e) => showSidebarContextMenu(e, { type: 'prompt', tag: tag });
            list.appendChild(header);
            if (!isCol) {
                const itemsContainer = document.createElement('div');
                sourceData.prompts.filter(p => (p.tag || 'Uncategorized') === tag).forEach(p => renderItem(p, 'prompt', color, itemsContainer));
                list.appendChild(itemsContainer);
            }
        });
    }
    else if (leftTab === 'trans') {
        if (toolingData.transitions.length === 0 && toolingData.imageNodes.length === 0) { list.innerHTML = '<div class="empty-state">No Transitions/Image Nodes Authored.</div>'; return; }
        
        toolingData.transitionSections.forEach(sec => {
            const secItems = toolingData.transitions.filter(t => t.sectionId === sec.id);
            if(secItems.length === 0) return;
            const pId = `tsec_${sec.id}`; const isCol = collapsedLeftGroups.has(pId);
            const header = document.createElement('div');
            header.className = "nested-header"; header.style.cssText = `color: #ff8c00; border-color: #ff8c00; cursor:pointer;`;
            header.innerHTML = `<span>${isCol ? '▶' : '▼'} [TRANS] ${escapeHtml(sec.name)}</span>`;
            header.onclick = () => toggleLeftGroup(pId);
            header.oncontextmenu = (e) => { contextMenuSectionType = 'trans'; showSidebarContextMenu(e, { type: 'trans', section: sec.id }); };
            list.appendChild(header);
            if(!isCol) {
                const itemsContainer = document.createElement('div');
                secItems.forEach(t => renderItem(t, 'trans', t.color, itemsContainer));
                list.appendChild(itemsContainer);
            }
        });

        toolingData.imageNodeSections.forEach(sec => {
            const secItems = toolingData.imageNodes.filter(t => t.sectionId === sec.id);
            if(secItems.length === 0) return;
            const pId = `isec_${sec.id}`; const isCol = collapsedLeftGroups.has(pId);
            const header = document.createElement('div');
            header.className = "nested-header"; header.style.cssText = `color: #ff0055; border-color: #ff0055; cursor:pointer;`;
            header.innerHTML = `<span>${isCol ? '▶' : '▼'} [IMG] ${escapeHtml(sec.name)}</span>`;
            header.onclick = () => toggleLeftGroup(pId);
            header.oncontextmenu = (e) => { contextMenuSectionType = 'imgnode'; showSidebarContextMenu(e, { type: 'imgnode', section: sec.id }); };
            list.appendChild(header);
            if(!isCol) {
                const itemsContainer = document.createElement('div');
                secItems.forEach(t => renderItem(t, 'imgnode', t.color, itemsContainer));
                list.appendChild(itemsContainer);
            }
        });
    }
}

function renderNodes() {
    groupLayer.innerHTML = '';
    flowGroups.filter(g => g.canvasId === currentCanvasId).forEach(g => {
        const el = document.createElement('div'); el.className = 'flow-group-box';
        el.style.left = `${g.x}px`; el.style.top = `${g.y}px`; el.style.width = `${g.width}px`; el.style.height = `${g.height}px`; el.style.borderColor = g.color; el.style.backgroundColor = `${g.color}11`;
        el.innerHTML = `
            <div class="flow-group-header" style="border-color: ${g.color};" onmousedown="startGroupDrag(event, '${g.id}')">
                <input type="text" value="${escapeHtml(g.title)}" style="background:transparent; border:none; padding:0; color:#fff; font-weight:900; width:60%;" oninput="updateGroup('${g.id}', 'title', this.value)" onmousedown="event.stopPropagation()">
                <div style="display:flex; gap:5px; align-items:center;">
                    <input type="color" value="${g.color}" style="width:20px; height:20px; padding:0; border-radius:0;" onchange="updateGroup('${g.id}', 'color', this.value)" onmousedown="event.stopPropagation()">
                    <button class="btn-remove" style="font-size:1rem;" onclick="deleteGroup('${g.id}')" onmousedown="event.stopPropagation()">×</button>
                </div>
            </div>
            <div class="flow-group-resize" onmousedown="startGroupResize(event, '${g.id}')"></div>`;
        groupLayer.appendChild(el);
    });

    const stackRoots = storyNodes.filter(n => n.canvasId === currentCanvasId && !n.snapParent && n.snapChild);
    stackRoots.forEach(r => updateStackPositions(r.id));

    nodeLayer.innerHTML = '';
    storyNodes.filter(n => n.canvasId === currentCanvasId).forEach(node => {
        const el = document.createElement('div');
        let borderColor = node.color; let isSelected = selectedNodeIds.includes(node.id);
        el.className = `story-node ${node.snapParent ? 'snapped-child' : ''}`;
        
        let styleStr = `left: ${node.x}px; top: ${node.y}px; border-left-color: ${borderColor};`;
        if(isSelected) {
            let selectedColor = node.type === 'task' ? 'var(--accent-gold)' : (node.type === 'sequence' ? '#60a5fa' : (node.type==='trans'||node.type==='imgnode') ? 'var(--accent-orange)' : 'var(--accent-teal)');
            styleStr += `border-color: ${selectedColor}; border-left-color: ${selectedColor}; background: #1c1c1c; box-shadow: 0 0 20px ${selectedColor}88; z-index: 10;`;
        }
        el.style.cssText = styleStr; el.dataset.id = node.id;

        let detachBtn = node.snapParent ? `<button class="detach-btn" onclick="detachNode('${node.id}')" onmousedown="event.stopPropagation()">⏏</button>` : '';
        const repeatFlag = node.isRepeatable ? `<div style="position:absolute; top:-10px; right:10px; background:var(--accent-pink); color:#000; font-size:0.55rem; font-weight:900; padding:2px 6px;">LOOP ACTIVE</div>` : '';
        
        let typeFlag = '';
        if (!node.snapParent) {
            if (node.type === 'task') typeFlag = `<div style="position:absolute; top:-10px; left:10px; background:var(--accent-gold); color:#000; font-size:0.55rem; font-weight:900; padding:2px 6px;">TASK</div>`;
            else if (node.type === 'sequence') typeFlag = `<div style="position:absolute; top:-10px; left:10px; background:var(--accent-blue); color:#000; font-size:0.55rem; font-weight:900; padding:2px 6px;">SEQ</div>`;
            else if (node.type === 'menu') typeFlag = `<div style="position:absolute; top:-10px; left:10px; background:var(--accent-green); color:#000; font-size:0.55rem; font-weight:900; padding:2px 6px;">OPT</div>`;
            else if (node.type === 'prompt') typeFlag = `<div style="position:absolute; top:-10px; left:10px; background:var(--accent-pink); color:#000; font-size:0.55rem; font-weight:900; padding:2px 6px;">PRMPT</div>`;
            else if (node.type === 'trans') typeFlag = `<div style="position:absolute; top:-10px; left:10px; background:var(--accent-orange); color:#000; font-size:0.55rem; font-weight:900; padding:2px 6px;">TRANS</div>`;
            else if (node.type === 'imgnode') typeFlag = `<div style="position:absolute; top:-10px; left:10px; background:#ff0055; color:#000; font-size:0.55rem; font-weight:900; padding:2px 6px;">IMG</div>`;
            else typeFlag = `<div style="position:absolute; top:-10px; left:10px; background:var(--accent-teal); color:#000; font-size:0.55rem; font-weight:900; padding:2px 6px;">CONVO</div>`;
        }

        let headerHtml = '';
        if (node.type === 'menu') {
            if (!node.snapParent && node.contextTitle) headerHtml += `<div class="node-title" style="font-size:0.65rem; color:#aaa; margin-bottom:4px; border-bottom:1px solid #333; padding-bottom:2px;">${escapeHtml(node.contextTitle)}</div>`;
            headerHtml += `<div class="node-title" style="font-size:1rem; color:#fff;">${escapeHtml(node.buttonLabel)}</div>`;
        } else {
            let chainBadge = '';
            if (node.chainName && node.taskType && node.taskType !== 'standalone') {
                chainBadge = `<div class="inline-flex items-center gap-1.5 text-[8px] font-black uppercase tracking-widest border px-2 py-0.5 rounded-none w-max mb-2 hover:brightness-125 cursor-pointer transition-all" style="border-color: ${node.chainColor}; color: ${node.chainColor}; background-color: ${node.chainColor}15; box-shadow: 0 0 10px ${node.chainColor}33;" onmousedown="event.stopPropagation();" onclick="jumpToChainNode('${node.id}')"><span>${escapeHtml(node.chainName)} <span class="opacity-60 ml-1">[${escapeHtml(node.taskType)}]</span></span></div>`;
            }
            headerHtml = `${chainBadge}<div class="node-title">${escapeHtml(node.title)}</div><div class="node-source">SRC: ${escapeHtml(node.sourceRef)}</div>`;
        }

        let tagsHtml = ''; let vars = new Set();
        (node.unlockConditions||[]).forEach(c => c.variable && vars.add(normalizeStatement(c.variable, c.operator, c.value)));
        (node.onComplete||[]).forEach(c => c.variable && vars.add(normalizeStatement(c.variable, c.operator, c.value)));
        if(node.isTaskQuest) {
            if(node.taskUnlock?.key) vars.add(normalizeStatement(node.taskUnlock.key, node.taskUnlock.op, node.taskUnlock.val));
            if(node.taskComplete?.key) vars.add(normalizeStatement(node.taskComplete.key, node.taskComplete.op, node.taskComplete.val));
            if(node.taskFail?.key) vars.add(normalizeStatement(node.taskFail.key, node.taskFail.op, node.taskFail.val));
            if(node.taskReward?.key) vars.add(normalizeStatement(node.taskReward.key, node.taskReward.op, node.taskReward.val));
        }
        if(vars.size > 0) {
            tagsHtml = `<div class="mt-3 pt-3 border-t border-[#333] flex flex-wrap gap-1 pointer-events-none">${Array.from(vars).filter(Boolean).map(v => { const {cls, style} = getTagClassAndStyle(v); return `<span class="${cls} scale-75 origin-left" style="${style}">${escapeHtml(v)}</span>`; }).join('')}</div>`;
        }

        const outPortColor = node.type === 'task' ? 'var(--accent-gold)' : (node.type === 'sequence' ? 'var(--accent-blue)' : (node.type === 'menu' ? 'var(--accent-green)' : 'var(--accent-teal)'));

        el.innerHTML = `
            <div style="position:absolute; top:4px; right:8px; font-size:10px; color:#888; font-style:italic; user-select:text; pointer-events:auto; z-index:20;" onmousedown="event.stopPropagation()">${node.id}</div>
            ${repeatFlag}${typeFlag}${detachBtn}
            <div style="display:flex; flex-direction:column;">${headerHtml}</div>
            ${tagsHtml}
            <div class="port in" style="border-color: ${borderColor};" data-port="in" data-nodeid="${node.id}"></div>
            <div class="port out" style="border-color: ${outPortColor};" data-port="out" data-nodeid="${node.id}"></div>
        `;
        
        el.onmousedown = (e) => {
            const port = e.target.closest('.port');
            if (port && port.classList.contains('out')) { isLinking = true; linkSourceId = node.id; e.stopPropagation(); } 
            else if(!e.target.closest('.logic-tag') && !e.target.closest('.detach-btn')) { 
                let targetId = node.id;
                if (node.type === 'menu' && node.snapParent) { let r = node; while(r.snapParent) r = storyNodes.find(x => x.id === r.snapParent); targetId = r.id; }
                isDraggingNode = true; dragTarget = targetId;
                if (e.shiftKey) { if (isSelected) selectedNodeIds = selectedNodeIds.filter(id => id !== targetId); else selectedNodeIds.push(targetId); } 
                else { if (!selectedNodeIds.includes(targetId)) selectedNodeIds = [targetId]; }
                renderNodes(); if(rightTab === 'inspector') renderInspector(); e.stopPropagation();
            }
        };

        el.oncontextmenu = (e) => {
            e.preventDefault(); e.stopPropagation();
            showNodeContextMenu(e, node.id);
        };

        nodeLayer.appendChild(el);
        node.width = el.offsetWidth; node.height = el.offsetHeight;
    });
    
    stackRoots.forEach(r => updateStackPositions(r.id));
    requestAnimationFrame(() => drawConnections());
}

function renderInspector() {
    const cont = document.getElementById('inspector-content');
    if (selectedNodeIds.length === 0) { cont.innerHTML = '<div class="empty-state text-center text-[#888899] py-10 text-xs font-bold uppercase tracking-wider">Select a node to inspect.</div>'; return; }
    if (selectedNodeIds.length > 1) {
        cont.innerHTML = `<div style="font-size:1.2rem; font-weight:800; color:var(--accent-teal); margin-bottom:20px; text-transform:uppercase;">${selectedNodeIds.length} Nodes Selected</div><div style="display:flex; flex-direction:column; gap:10px;"><button class="btn btn-outline" onclick="duplicateSelectedNodes()">Duplicate Selected</button><button class="btn btn-pink" onclick="deleteSelectedNodes()">Delete Selected</button></div>`;
        return;
    }

    const node = storyNodes.find(n => n.id === selectedNodeIds[0]);
    if (!node) return;

    let taskQuestsUI = '';
    if (node.isTaskQuest) {
        taskQuestsUI = `
            <div class="task-cond-block" style="border-left-color: var(--accent-teal);"><label style="font-size:0.65rem; color:var(--accent-teal); margin-bottom:8px; display:block; font-weight:800; text-transform:uppercase;">Task Unlock Trigger</label><div class="task-cond-row"><input value="${escapeHtml(node.taskUnlock?.key||'')}" oninput="updateTaskCond('taskUnlock','key',this.value)" placeholder="KEY"><select onchange="updateTaskCond('taskUnlock','op',this.value)"><option ${node.taskUnlock?.op=='=='?'selected':''}>==</option><option ${node.taskUnlock?.op=='>='?'selected':''}>&gt;=</option><option ${node.taskUnlock?.op=='<='?'selected':''}>&lt;=</option><option ${node.taskUnlock?.op=='>'?'selected':''}>&gt;</option><option ${node.taskUnlock?.op=='<'?'selected':''}>&lt;</option></select><input value="${escapeHtml(node.taskUnlock?.val||'')}" oninput="updateTaskCond('taskUnlock','val',this.value)" placeholder="VAL"></div></div>
            <div class="task-cond-block" style="border-left-color: var(--accent-green);"><label style="font-size:0.65rem; color:var(--accent-green); margin-bottom:8px; display:block; font-weight:800; text-transform:uppercase;">Task Completion Logic</label><div class="task-cond-row"><input value="${escapeHtml(node.taskComplete?.key||'')}" oninput="updateTaskCond('taskComplete','key',this.value)" placeholder="KEY"><select onchange="updateTaskCond('taskComplete','op',this.value)"><option ${node.taskComplete?.op=='=='?'selected':''}>==</option><option ${node.taskComplete?.op=='>='?'selected':''}>&gt;=</option><option ${node.taskComplete?.op=='<='?'selected':''}>&lt;=</option><option ${node.taskComplete?.op=='>'?'selected':''}>&gt;</option><option ${node.taskComplete?.op=='<'?'selected':''}>&lt;</option></select><input value="${escapeHtml(node.taskComplete?.val||'')}" oninput="updateTaskCond('taskComplete','val',this.value)" placeholder="VAL"></div></div>
            <div class="task-cond-block" style="border-left-color: var(--accent-pink);"><label style="font-size:0.65rem; color:var(--accent-pink); margin-bottom:8px; display:block; font-weight:800; text-transform:uppercase;">Task Failure Logic</label><div class="task-cond-row"><input value="${escapeHtml(node.taskFail?.key||'')}" oninput="updateTaskCond('taskFail','key',this.value)" placeholder="KEY"><select onchange="updateTaskCond('taskFail','op',this.value)"><option ${node.taskFail?.op=='=='?'selected':''}>==</option><option ${node.taskFail?.op=='>='?'selected':''}>&gt;=</option><option ${node.taskFail?.op=='<='?'selected':''}>&lt;=</option><option ${node.taskFail?.op=='>'?'selected':''}>&gt;</option><option ${node.taskFail?.op=='<'?'selected':''}>&lt;</option></select><input value="${escapeHtml(node.taskFail?.val||'')}" oninput="updateTaskCond('taskFail','val',this.value)" placeholder="VAL"></div></div>
            <div class="task-cond-block" style="border-left-color: var(--accent-gold);"><label style="font-size:0.65rem; color:var(--accent-gold); margin-bottom:8px; display:block; font-weight:800; text-transform:uppercase;">Task Reward</label><div class="task-cond-row"><input value="${escapeHtml(node.taskReward?.key||'')}" oninput="updateTaskCond('taskReward','key',this.value)" placeholder="KEY"><select onchange="updateTaskCond('taskReward','op',this.value)"><option ${node.taskReward?.op=='=='?'selected':''}>==</option><option ${node.taskReward?.op=='>='?'selected':''}>&gt;=</option><option ${node.taskReward?.op=='<='?'selected':''}>&lt;=</option><option ${node.taskReward?.op=='>'?'selected':''}>&gt;</option><option ${node.taskReward?.op=='<'?'selected':''}>&lt;</option></select><input value="${escapeHtml(node.taskReward?.val||'')}" oninput="updateTaskCond('taskReward','val',this.value)" placeholder="VAL"></div></div>
        `;
    }

    cont.innerHTML = `
        <div class="form-group"><label>Unity Title / Ref</label><input value="${escapeHtml(node.title)}" oninput="updateNode('title', this.value)"></div>
        <div class="form-group"><label>Identity Color</label><div style="display:flex; align-items:center; gap:10px;"><input type="color" value="${node.color}" onchange="updateNode('color', this.value)"><span class="text-xs text-dim font-mono">${(node.color).toUpperCase()}</span></div></div>
        <div class="form-group"><label>Save Checkpoint String</label><input value="${escapeHtml(node.savePoint)}" placeholder="Leave blank if none..." oninput="updateNode('savePoint', this.value)"></div>
        <hr class="cyber-hr">
        <label style="color:var(--accent-gold); font-size:0.65rem; font-weight:800; letter-spacing:1px; margin-bottom:10px; display:block;">NARRATIVE / QUEST GROUPING</label>
        <div class="form-group"><label>Chain / Group Designation</label><input value="${escapeHtml(node.chainName || '')}" oninput="updateNode('chainName', this.value)" placeholder="e.g. MainQuest"></div>
        <div class="form-group"><label>Architecture Type</label><select onchange="updateNode('taskType', this.value)"><option value="standalone" ${node.taskType==='standalone'?'selected':''}>Standalone</option><option value="root" ${node.taskType==='root'?'selected':''}>Root</option><option value="node" ${node.taskType==='node'?'selected':''}>Node</option><option value="split" ${node.taskType==='split'?'selected':''}>Split</option><option value="endpoint" ${node.taskType==='endpoint'?'selected':''}>Endpoint</option></select></div>
        <div class="form-group"><label>Group Description</label><textarea rows="3" oninput="updateNode('chainDesc', this.value)" placeholder="Describe the group's objective...">${escapeHtml(node.chainDesc || '')}</textarea></div>
        <div class="form-group"><label>Group Color</label><div style="display:flex; align-items:center; gap:10px;"><input type="color" value="${node.chainColor || '#ffd700'}" onchange="updateNode('chainColor', this.value)"><span class="text-xs text-dim font-mono">${(node.chainColor || '#ffd700').toUpperCase()}</span></div></div>
        <hr class="cyber-hr">
        <label style="color:var(--accent-pink); font-size:0.65rem; font-weight:800; letter-spacing:1px; margin-bottom:10px; display:block;">REPEATABILITY STATUS</label>
        <div class="checkbox-row"><input type="checkbox" id="isRepeatableToggle" ${node.isRepeatable ? 'checked' : ''} onchange="updateNode('isRepeatable', this.checked)"><label for="isRepeatableToggle">Allow Node Loop</label></div>
        <div class="form-group"><label>Repeat Trigger Variable</label><input value="${escapeHtml(node.repeatVariable || '')}" oninput="updateNode('repeatVariable', this.value)" placeholder="e.g. repeatTutorial"></div>
        <hr class="cyber-hr">
        <label style="color:var(--accent-gold); font-size:0.65rem; font-weight:800; letter-spacing:1px; margin-bottom:10px; display:block;">TASK QUEST SYSTEM</label>
        <div class="checkbox-row"><input type="checkbox" id="isTaskQuestToggle" ${node.isTaskQuest ? 'checked' : ''} onchange="updateNode('isTaskQuest', this.checked)"><label for="isTaskQuestToggle">Expose Task Objectives</label></div>
        ${taskQuestsUI}
        <hr class="cyber-hr">
        <label style="color:var(--accent-teal); font-size:0.65rem; font-weight:800; letter-spacing:1px; margin-bottom:10px; display:block;">FLOW UNLOCK CONDITIONS</label>
        <div id="conds">${node.unlockConditions.map((c, i) => `<div class="condition-row"><input type="text" value="${escapeHtml(c.variable)}" placeholder="KEY" oninput="updateCond(${i}, 'variable', this.value)"><select onchange="updateCond(${i}, 'operator', this.value)"><option value="==" ${c.operator=='=='?'selected':''}>==</option><option value=">=" ${c.operator=='>='?'selected':''}>&gt;=</option><option value="<=" ${c.operator=='<='?'selected':''}>&lt;=</option><option value=">" ${c.operator=='>'?'selected':''}>&gt;</option><option value="<" ${c.operator=='<'?'selected':''}>&lt;</option></select><input type="text" value="${escapeHtml(c.value)}" placeholder="VAL" oninput="updateCond(${i}, 'value', this.value)"><button class="btn-remove" onclick="removeCond(${i})">×</button></div>`).join('')}</div>
        <button class="btn btn-outline" style="width:100%; border-style:dashed; margin-top:10px;" onclick="addCond()">+ Add Flow Requirement</button>
        <hr class="cyber-hr">
        <label style="color:var(--accent-blue); font-size:0.65rem; font-weight:800; letter-spacing:1px; margin-bottom:10px; display:block;">ON COMPLETE STATE CHANGES</label>
        <div id="states">${node.onComplete.map((c, i) => `<div class="condition-row"><input type="text" value="${escapeHtml(c.variable)}" placeholder="KEY" oninput="updateState(${i}, 'variable', this.value)"><select onchange="updateState(${i}, 'operator', this.value)"><option ${c.operator=='='?'selected':''}>=</option><option ${c.operator=='+='?'selected':''}>+=</option><option ${c.operator=='-='?'selected':''}>-=</option></select><input type="text" value="${escapeHtml(c.value)}" placeholder="VAL" oninput="updateState(${i}, 'value', this.value)"><button class="btn-remove" onclick="removeState(${i})">×</button></div>`).join('')}</div>
        <button class="btn btn-outline" style="width:100%; border-style:dashed; margin-top:10px;" onclick="addState()">+ Add State Change</button>
        <hr class="cyber-hr">
        <div style="display:flex; gap:10px;"><button class="btn btn-outline" style="flex:1;" onclick="duplicateSelectedNodes()">Duplicate Node</button><button class="btn btn-pink" style="flex:1;" onclick="deleteSelectedNodes()">Delete Node</button></div>
    `;
}

function updateNode(k, v) { 
    const n = storyNodes.find(i => i.id === selectedNodeIds[0]); 
    if (!n) return; n[k] = v; 
    if (['isTaskQuest', 'chainName', 'chainColor', 'taskType', 'color', 'title', 'isRepeatable'].includes(k)) renderNodes();
    if (k === 'isTaskQuest') renderInspector();
}

function updateTaskCond(block, f, v) {
    const n = storyNodes.find(i => i.id === selectedNodeIds[0]); 
    if (!n) return; if (!n[block]) n[block] = {key:'', op:'==', val:''};
    n[block][f] = v; updateProjectLogic(false); renderNodes();
}

function addCond() { const n = storyNodes.find(i => i.id === selectedNodeIds[0]); if(n) n.unlockConditions.push({variable:'', operator:'==', value:''}); renderInspector(); updateProjectLogic(); }
function updateCond(i, f, v) { const n = storyNodes.find(i => i.id === selectedNodeIds[0]); if(n) n.unlockConditions[i][f] = v; updateProjectLogic(false); renderNodes(); }
function removeCond(i) { const n = storyNodes.find(i => i.id === selectedNodeIds[0]); if(n) n.unlockConditions.splice(i,1); renderInspector(); updateProjectLogic(); }
function addState() { const n = storyNodes.find(i => i.id === selectedNodeIds[0]); if(n) n.onComplete.push({variable:'', operator:'=', value:''}); renderInspector(); updateProjectLogic(); }
function updateState(i, f, v) { const n = storyNodes.find(i => i.id === selectedNodeIds[0]); if(n) n.onComplete[i][f] = v; updateProjectLogic(false); renderNodes(); }
function removeState(i) { const n = storyNodes.find(i => i.id === selectedNodeIds[0]); if(n) n.onComplete.splice(i,1); renderInspector(); updateProjectLogic(); }

function renderLogicPanel() {
    const cont = document.getElementById('logic-content');
    if (!cont) return;

    // Assure full HTML framework exists so inner lists don't null-ref error
    if (!document.getElementById('startup-list')) {
        cont.innerHTML = `
            <div class="mb-6">
                <h3 class="text-[var(--accent-gold)] text-[10px] font-black uppercase tracking-widest mb-2">Startup Logic States</h3>
                <div id="startup-list" class="flex flex-col gap-1 mb-2"></div>
                <button class="btn btn-outline border-dashed w-full text-[9px] py-1" onclick="addStartupValue()">+ ADD STARTUP STATE</button>
            </div>
            <div class="mb-6">
                <h3 class="text-[var(--accent-gold)] text-[10px] font-black uppercase tracking-widest mb-2">Game End Logic States</h3>
                <div id="gameend-list" class="flex flex-col gap-1 mb-2"></div>
                <button class="btn btn-outline border-dashed w-full text-[9px] py-1" onclick="addGameEndValue()">+ ADD GAME END STATE</button>
            </div>
            <div class="mb-6">
                <h3 class="text-[var(--accent-pink)] text-[10px] font-black uppercase tracking-widest mb-2">Custom Gameplay Values</h3>
                <div class="flex gap-1 mb-2">
                    <input type="text" id="new-gp-val" class="flex-1 bg-black border border-[#333] text-white text-[10px] p-1 outline-none focus:border-[var(--accent-pink)]" placeholder="e.g. Trust >= 5">
                    <input type="color" id="new-gp-color" value="#ff007b" class="w-6 h-6 p-0 border border-[#333] cursor-pointer">
                    <button class="btn bg-[var(--accent-pink)] text-black px-2 py-1 font-bold text-[9px]" onclick="addGameplayValue()">+</button>
                </div>
                <div id="gameplay-values-list" class="flex flex-col gap-1"></div>
            </div>
            <div>
                <h3 class="text-[var(--accent-teal)] text-[10px] font-black uppercase tracking-widest mb-2">Active Project Logic Maps</h3>
                <div id="active-logic-list" class="tag-container pb-8"></div>
            </div>
        `;
    }

    const renderList = (arr, listId, isStart) => {
        const html = arr.map((item, i) => `
            <div class="kv-row">
                <input value="${escapeHtml(item.key)}" oninput="updateLogicArray('${isStart?'start':'end'}', ${i}, 'key', this.value)" placeholder="KEY">
                <select onchange="updateLogicArray('${isStart?'start':'end'}', ${i}, 'op', this.value)">
                    <option ${item.op=='=='?'selected':''}>==</option>
                    <option ${item.op=='>='?'selected':''}>&gt;=</option>
                    <option ${item.op=='<='?'selected':''}>&lt;=</option>
                </select>
                <input value="${escapeHtml(item.val)}" oninput="updateLogicArray('${isStart?'start':'end'}', ${i}, 'val', this.value)" placeholder="VAL">
                <button class="btn-remove" onclick="removeLogicArray('${isStart?'start':'end'}', ${i})">×</button>
            </div>
        `).join('');
        document.getElementById(listId).innerHTML = html;
    };

    renderList(startupValues, 'startup-list', true);
    renderList(gameEndValues, 'gameend-list', false);

    const gpHtml = Object.keys(gameplayValues).map(stmt => {
        const color = gameplayValues[stmt];
        const count = projectLogic[stmt] ? projectLogic[stmt].count : 0;
        
        if (editingGpKey === stmt) {
            return `
            <div class="flex items-center justify-between bg-[#111] p-2 border border-[var(--accent-purple)] rounded-none mb-2">
                <div class="flex items-center gap-2 flex-1">
                    <input type="color" id="edit-gp-color" value="${color}" class="w-6 h-6 p-0 border-0 cursor-pointer">
                    <input type="text" id="edit-gp-val" value="${escapeHtml(stmt)}" class="flex-1 text-[10px] p-1 border-b border-[var(--border-color)] bg-transparent text-white outline-none">
                </div>
                <div class="flex gap-1 ml-2">
                    <button class="btn btn-outline text-[9px] py-1 px-2 border-[var(--accent-green)] text-[var(--accent-green)]" onclick="saveEditGameplayValue('${escapeHtml(stmt)}')">✓</button>
                    <button class="btn btn-outline text-[9px] py-1 px-2 border-[var(--accent-pink)] text-[var(--accent-pink)]" onclick="cancelEditGameplayValue()">✖</button>
                </div>
            </div>`;
        }

        return `
        <div class="group flex items-center justify-between bg-[#111] p-2 border border-[#222] hover:border-[#444] transition-colors mb-2 cursor-pointer" ondblclick="startEditGameplayValue('${escapeHtml(stmt)}')">
            <div class="flex items-center gap-2">
                <div style="width:12px; height:12px; background:${color}; border:1px solid #000;"></div>
                <span class="text-xs font-bold" style="color:${color}">${escapeHtml(stmt)} <span class="opacity-50 text-[9px]">(${count})</span></span>
            </div>
            <div class="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button class="text-[var(--accent-teal)] hover:text-white text-xs" onclick="startEditGameplayValue('${escapeHtml(stmt)}')">✎</button>
                <button class="text-[var(--accent-pink)] hover:text-white text-xs" onclick="deleteGameplayValue('${escapeHtml(stmt)}')">✖</button>
            </div>
        </div>`;
    }).join('');
    document.getElementById('gameplay-values-list').innerHTML = gpHtml || "<div class='text-xs text-[#555] mb-2'>No gameplay values set.</div>";

    const activeKeys = Object.keys(projectLogic).filter(k => !startupValues.some(v=>normalizeStatement(v.key, v.op, v.val)===k) && !gameEndValues.some(v=>normalizeStatement(v.key, v.op, v.val)===k) && gameplayValues[k]===undefined);
    document.getElementById('active-logic-list').innerHTML = `<div class="tag-container pb-8">${activeKeys.map(k => renderTag(k)).join('')}</div>`;
}

function getTagClassAndStyle(stmt) {
    let inStart = startupValues.some(v => normalizeStatement(v.key, v.op, v.val) === stmt);
    let inEnd = gameEndValues.some(v => normalizeStatement(v.key, v.op, v.val) === stmt);
    let isGameplay = gameplayValues[stmt] !== undefined;
    let logic = projectLogic[stmt] || { usage: 'unknown' };

    if (inStart || inEnd) return { cls: 'logic-tag tag-golden', style: '' };
    if (isGameplay) return { cls: 'logic-tag tag-gameplay', style: `color:${gameplayValues[stmt]}; border-color:${gameplayValues[stmt]}88;` };
    if (logic.usage === 'mixed') return { cls: 'logic-tag tag-purple', style: '' };
    if (logic.usage === 'condition' || logic.usage === 'stateChange') return { cls: 'logic-tag tag-error', style: '' };
    return { cls: 'logic-tag', style: 'background:#333; color:#fff;' };
}

function renderTag(stmt) {
    const {cls, style} = getTagClassAndStyle(stmt);
    return `<div class="${cls}" style="${style}" data-key="${escapeHtml(stmt)}" onclick="openTagModal('${escapeHtml(stmt)}')">
        ${escapeHtml(stmt)} <span class="opacity-50 text-[9px] ml-1">(${projectLogic[stmt]?.count || 0})</span>
    </div>`;
}

function getTooltipDesc(key, logic) {
    let inStart = startupValues.some(v => normalizeStatement(v.key, v.op, v.val) === key);
    let inEnd = gameEndValues.some(v => normalizeStatement(v.key, v.op, v.val) === key);
    let isGameplay = gameplayValues[key] !== undefined;

    if (inStart || inEnd) return `<br><span style="color:var(--accent-gold)">Protected Status: Configured as a Core StartUp/GameEnd value.</span>`;
    if (isGameplay) return `<br><span style="color:#fff">Gameplay Metric: Configured manually in the authoring panel.</span>`;
    if (logic.usage === 'mixed') return `<br><span style="color:var(--accent-purple)">Mixed Usage: Properly declared and utilized dynamically.</span>`;
    if (logic.usage === 'condition') return `<br><span style="color:red">WARNING (Condition Only): You check this value, but never declare/change it.</span>`;
    if (logic.usage === 'stateChange') return `<br><span style="color:red">WARNING (State Change Only): You change this value, but never check it.</span>`;
    return "<br>Extracted Logic Tag";
}

function openTagModal(key, isLocal = false) {
    const modal = document.getElementById('logic-modal');
    const localLogMap = getLocalToolLogic();
    const logic = (isLocal ? localLogMap[key] : projectLogic[key]) || { usage: 'unknown', sources: new Set(), count: 0 };
    
    document.getElementById('modal-title').innerText = `${key} (Usages: ${logic.count})`;
    let classColor = "#fff", classText = "Unknown";
    
    let pLog = projectLogic[key] || {usage: 'unknown'};
    let displayUsage = logic.usage;
    if(isLocal) {
        if (pLog.usage === 'mixed' || (logic.condition && pLog.stateChange) || (logic.stateChange && pLog.condition)) displayUsage = 'mixed';
    }

    if(displayUsage === 'mixed') { classColor = "var(--accent-purple)"; classText = "Mixed Usage (Condition & State Change)"; }
    if(displayUsage === 'condition') { classColor = "var(--accent-green)"; classText = "Condition Only (Read Only)"; }
    if(displayUsage === 'stateChange') { classColor = "var(--accent-blue)"; classText = "State Change Only (Write Only)"; }
    
    document.getElementById('modal-classification').innerHTML = `<span style="color:${classColor}">${classText}</span>`;
    document.getElementById('modal-sources').innerHTML = Array.from(logic.sources).map(s => `<li>${escapeHtml(s)}</li>`).join('') || "<li>No origin documented</li>";
    
    let canvasInst = '';
    
    if (isLocal) {
        let toolNodes = [...toolingData.transitions, ...toolingData.imageNodes];
        toolNodes.forEach(n => {
            let uses = false;
            (n.conditions||[]).forEach(c => { if(normalizeStatement(c.key, c.op, c.val) === key) uses = true; });
            (n.stateChanges||[]).forEach(c => { if(normalizeStatement(c.key, c.op, c.val) === key) uses = true; });
            if(uses) {
                let cat = toolingData.transitions.includes(n) ? 'trans' : 'imgnode';
                canvasInst += `<div class="flex justify-between items-center bg-[#111] p-2 border border-[#222] rounded-none mb-1">
                    <span class="text-xs text-white truncate mr-2">[Tool DB] ${escapeHtml(n.title)}</span>
                    <button class="btn btn-outline border-[var(--accent-teal)] text-[var(--accent-teal)] text-[9px] py-1 px-3" onclick="setToolCategory('${cat}'); activeToolItemId='${n.id}'; renderToolLibrary(); renderToolEditor(); scrollToToolCard('${n.id}'); closeTagModal();">Jump</button>
                </div>`;
            }
        });
        document.getElementById('modal-logic-actions').classList.remove('hidden');
    } else {
        document.getElementById('modal-logic-actions').classList.add('hidden');
        storyNodes.forEach(n => {
            let uses = false;
            (n.unlockConditions||[]).forEach(c => { if(normalizeStatement(c.variable, c.operator, c.value) === key) uses = true; });
            (n.onComplete||[]).forEach(c => { if(normalizeStatement(c.variable, c.operator, c.value) === key) uses = true; });
            if(n.isTaskQuest) {
                if(normalizeStatement(n.taskUnlock?.key, n.taskUnlock?.op, n.taskUnlock?.val) === key || 
                   normalizeStatement(n.taskComplete?.key, n.taskComplete?.op, n.taskComplete?.val) === key || 
                   normalizeStatement(n.taskFail?.key, n.taskFail?.op, n.taskFail?.val) === key || 
                   normalizeStatement(n.taskReward?.key, n.taskReward?.op, n.taskReward?.val) === key) uses = true;
            }
            if(uses) {
                const canvasName = flowPages.find(p => p.id === n.canvasId)?.name || 'Unknown';
                canvasInst += `<div class="flex justify-between items-center bg-[#111] p-2 border border-[#222] rounded-none mb-1">
                    <span class="text-xs text-white truncate mr-2">[${escapeHtml(canvasName)}] ${escapeHtml(n.title)}</span>
                    <button class="btn btn-outline border-[var(--accent-teal)] text-[var(--accent-teal)] text-[9px] py-1 px-3" onclick="switchFlowPage('${n.canvasId}'); jumpToNode('${n.id}'); closeTagModal();">Jump</button>
                </div>`;
            }
        });
    }

    document.getElementById('modal-instances').innerHTML = canvasInst || "<div class='text-xs text-[#666]'>Not placed on any canvas yet.</div>";

    const btn = document.getElementById('modal-toggle-gameplay');
    if(gameplayValues[key] !== undefined) {
        btn.innerText = "Remove from Gameplay Values"; btn.className = "btn btn-outline border border-[#333] text-white hover:border-[#666] font-bold uppercase px-3 py-2 text-[10px]";
        btn.onclick = () => { delete gameplayValues[key]; updateProjectLogic(); closeTagModal(); };
    } else {
        btn.innerText = "Add to Gameplay Values"; btn.className = "btn btn-purple bg-[var(--accent-purple)] text-black font-bold uppercase px-3 py-2 text-[10px]";
        btn.onclick = () => { gameplayValues[key] = getRandomSaturatedHex(); updateProjectLogic(); closeTagModal(); };
    }
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function closeTagModal() { 
    const modal = document.getElementById('logic-modal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

function renderFlowPages() {
    const cont = document.getElementById('flow-pages-tabs');
    cont.innerHTML = flowPages.map(p => `
        <div class="page-tab ${p.id === currentCanvasId ? 'active' : ''}" onclick="switchFlowPage('${p.id}')">
            <span>${escapeHtml(p.emoji)} ${escapeHtml(p.name)}</span>
            <div class="page-actions" onclick="event.stopPropagation();">
                <button class="page-action-btn" onclick="openPageModal('${p.id}')">✎</button>
                ${flowPages.length > 1 ? `<button class="page-action-btn" onclick="deleteFlowPage('${p.id}')">✖</button>` : ''}
            </div>
        </div>
    `).join('');
    cont.innerHTML += `<div class="page-tab" style="color:#fff; border-color:var(--accent-teal);" onclick="openPageModal()">+ NEW</div>`;
}

function switchFlowPage(id) {
    currentCanvasId = id; selectedNodeIds = []; panX = 0; panY = 0; scale = 1;
    renderFlowPages(); renderNodes(); updateTransform();
    if(rightTab === 'inspector') renderInspector();
}

function setEmoji(val) { document.getElementById('page-modal-emoji').value = val; }

function openPageModal(id = null) {
    const modal = document.getElementById('page-modal');
    const page = id ? flowPages.find(p => p.id === id) : null;
    document.getElementById('page-modal-title').innerText = page ? "Edit Flow Canvas" : "Create Flow Canvas";
    document.getElementById('page-modal-id').value = page ? page.id : "";
    
    let defaultName = `New Flow`; let counter = 1;
    while(flowPages.some(p => p.name === (counter > 1 ? `${defaultName} ${counter}` : defaultName))) { counter++; }
    document.getElementById('page-modal-name').value = page ? page.name : (counter > 1 ? `${defaultName} ${counter}` : defaultName);
    document.getElementById('page-modal-emoji').value = page ? page.emoji : "🔮";
    document.getElementById('page-modal-desc').value = page ? page.desc : "";
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function closePageModal() { 
    const modal = document.getElementById('page-modal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

function saveFlowPage() {
    const id = document.getElementById('page-modal-id').value;
    const name = document.getElementById('page-modal-name').value || "Unnamed Flow";
    const emoji = document.getElementById('page-modal-emoji').value || "🔮";
    const desc = document.getElementById('page-modal-desc').value;
    
    if (id) {
        const page = flowPages.find(p => p.id === id);
        if (page) { page.name = name; page.emoji = emoji; page.desc = desc; }
    } else {
        const newId = `canvas_${Date.now()}`;
        flowPages.push({ id: newId, name, emoji, desc });
        currentCanvasId = newId; 
    }
    closePageModal(); renderFlowPages(); switchFlowPage(currentCanvasId);
}

function deleteFlowPage(id) {
    if (flowPages.length <= 1) return;
    if (confirm("Are you sure you want to delete this Flow Canvas? All nodes inside it will be permanently deleted. This is irreversible.")) {
        flowPages = flowPages.filter(p => p.id !== id);
        storyNodes = storyNodes.filter(n => n.canvasId !== id);
        flowGroups = flowGroups.filter(g => g.canvasId !== id);
        if (currentCanvasId === id) currentCanvasId = flowPages[0].id;
        renderFlowPages(); switchFlowPage(currentCanvasId); updateProjectLogic();
    }
}

function handleSearch(val) {
    val = val.toLowerCase();
    if (!val) { searchResults = []; updateSearchUI(); return; }
    searchResults = storyNodes.filter(n => n.canvasId === currentCanvasId && (n.title.toLowerCase().includes(val) || n.id.toLowerCase().includes(val)));
    searchIndex = searchResults.length > 0 ? 0 : -1;
    updateSearchUI(); focusSearchResult();
}

function cycleSearch(dir) {
    if (searchResults.length === 0) return;
    searchIndex += dir;
    if (searchIndex >= searchResults.length) searchIndex = 0;
    if (searchIndex < 0) searchIndex = searchResults.length - 1;
    updateSearchUI(); focusSearchResult();
}

function focusSearchResult() {
    if (searchIndex >= 0 && searchIndex < searchResults.length) {
        jumpToNode(searchResults[searchIndex].id);
        selectedNodeIds = [searchResults[searchIndex].id];
        renderNodes(); renderInspector();
    }
}

function updateSearchUI() {
    document.getElementById('search-results-count').innerText = searchResults.length > 0 ? `${searchIndex + 1} / ${searchResults.length}` : `0 / 0`;
}

// --- TOOLS LIBRARY (LEFT PANEL) ---
function generateLibraryBlock(type, titleLabel, itemLabel, accentColor) {
    const arrays = getToolArrays(type);
    let secOptions = arrays.sec.map(s => `<option value="${s.id}">${escapeHtml(s.name)}</option>`).join('');
    const colorHex = getRandomHex();
    
    let html = `
        <div class="mb-4">
            <h2 class="text-2xl font-black uppercase tracking-widest mb-4" style="color: ${accentColor}">${titleLabel}</h2>
            <label class="text-[10px] font-black uppercase tracking-widest mb-1 block" style="color: ${accentColor}">New Section Name</label>
            <div class="flex gap-1 mb-3">
                <input type="text" id="new-tool-section-name-${type}" class="flex-1 text-[10px] p-2 bg-black text-white border border-[#333] outline-none" style="border-bottom-color: ${accentColor}" placeholder="Section Name...">
                <button class="btn text-black px-3 py-1 font-bold" style="background-color: ${accentColor}" onclick="addToolSection('${type}')">+</button>
            </div>
            
            <label class="text-[10px] font-black uppercase tracking-widest mb-1 block" style="color: ${accentColor}">${itemLabel}</label>
            <div class="flex gap-1 mb-2">
                <input type="text" id="new-tool-title-${type}" class="flex-1 text-[10px] p-2 bg-black text-white border border-[#333] outline-none" style="border-bottom-color: ${accentColor}" placeholder="Title...">
                <button class="btn text-black px-3 py-1 font-bold" style="background-color: ${accentColor}" onclick="addToolNode('${type}')">+</button>
            </div>
            
            <div class="flex gap-2">
                <div class="flex items-center gap-2 border border-[#333] p-1 pr-2 bg-black flex-shrink-0">
                    <input type="color" id="new-tool-color-${type}" value="${colorHex}" class="w-6 h-6 border-none p-0 cursor-pointer">
                    <span class="text-[9px] text-dim uppercase font-bold tracking-widest">Color</span>
                </div>
                <select id="new-tool-section-id-${type}" class="text-[10px] flex-1 bg-[#050505] border border-[#333] text-white p-2 outline-none" style="border-bottom-color: ${accentColor}">${secOptions}</select>
            </div>
        </div>
    `;

    arrays.sec.forEach(sec => {
        const secItems = arrays.items.filter(i => i.sectionId === sec.id);
        const sId = `tsec_${type}_${sec.id}`; const isCol = collapsedLeftGroups.has(sId);
        
        html += `
            <div class="nested-header" style="color: #fff; border-color: #333; cursor:pointer; background:#111; padding: 10px; border-bottom: 1px solid #333;" oncontextmenu="contextMenuSectionType = '${type}'; showToolSectionContext(event, '${sec.id}')">
                <div class="flex-1 text-xs font-black tracking-widest uppercase" onclick="toggleLeftGroup('${sId}')">
                    <span class="mr-2" style="color: ${accentColor}">${isCol ? '▶' : '▼'}</span>${escapeHtml(sec.name)}
                </div>
            </div>
        `;
        
        if(!isCol) {
            html += `
                <div class="p-2 bg-black border-x border-b border-[#222]">
                    <div class="flex items-center gap-2 mb-2">
                        <span class="text-[9px] text-dim font-bold uppercase">Path:</span>
                        <input type="text" id="left-sec-path-${sec.id}" value="${escapeHtml(sec.path||'')}" oninput="updateSectionPath('${type}', '${sec.id}', this.value)" class="flex-1 bg-transparent border-b border-[#444] text-white text-[10px] outline-none">
                    </div>
                    <div class="flex gap-2">
                        ${['imgdb','convseq','puppetseq'].includes(type) ? `
                            <button class="btn btn-outline text-[9px] py-1 flex-1 font-bold tracking-widest" style="color: ${accentColor}; border-color: ${accentColor};" onclick="document.getElementById('import-images-${sec.id}').click()">Import Images</button>
                            <input type="file" multiple accept="image/*" class="hidden" id="import-images-${sec.id}" onchange="importImagesToSection(event, '${sec.id}', '${type}')">
                        ` : ''}
                        <button class="btn btn-outline text-[9px] py-1 flex-1 font-bold tracking-widest" onclick="sortToolSection('${type}', '${sec.id}')">Arrange A-Z</button>
                        <button class="btn btn-outline border-[var(--accent-pink)] text-[var(--accent-pink)] font-bold tracking-widest text-[9px] py-1 flex-1 hover:bg-[#ff007b22]" onclick="clearToolSection('${type}', '${sec.id}')">Delete All</button>
                    </div>
                </div>
                <div>
            `;

            secItems.forEach((item, idx) => {
                const isSelected = activeToolItemId === item.id;
                let bgStyle = isSelected ? `bg-[#1a1a1a] border-l-[4px] border-l-[${accentColor}]` : 'border-l-[4px]';
                
                html += `
                    <div id="left-item-${item.id}" class="tool-left-item flex justify-between items-center p-3 border-b border-[#222] cursor-pointer hover:bg-[#1a1a1a] transition-colors ${bgStyle}" style="border-left-color: ${isSelected ? accentColor : item.color};">
                        <div class="flex flex-col overflow-hidden w-full h-full justify-center" onclick="scrollToToolCard('${item.id}')">
                            <span id="left-title-${item.id}" class="text-[12px] font-bold text-white truncate w-full pr-4">${escapeHtml(item.title||item.name)}</span>
                            <span class="text-[9px] text-dim opacity-50 font-mono tracking-widest mt-1">#${idx+1}</span>
                        </div>
                        <button class="text-[var(--text-dim)] hover:text-[var(--accent-pink)] font-black px-2 py-1 text-lg leading-none" onclick="deleteToolItem('${type}', '${item.id}'); event.stopPropagation();">✕</button>
                    </div>
                `;
            });
            html += `</div>`;
        }
    });
    
    return html;
}

function renderToolLibrary() {
    const list = document.getElementById('tool-library-content');
    list.innerHTML = '';
    
    if (activeToolCategory === 'trans') {
        list.innerHTML = generateLibraryBlock('trans', 'Transition Database', 'Transition Title', 'var(--accent-orange)');
    } else if (activeToolCategory === 'imgnode') {
        list.innerHTML = generateLibraryBlock('imgnode', 'Image Node Database', 'Image Node Title', 'var(--accent-pink)');
    } else if (activeToolCategory === 'imgdb') {
        list.innerHTML = 
            generateLibraryBlock('imgdb', 'Image DB', 'Image Tag Name', 'var(--accent-teal)') +
            '<div class="my-8 border-b-2 border-[#333]"></div>' +
            generateLibraryBlock('convseq', 'Conversation Sequence', 'Sequence Name', '#aaff00') +
            '<div class="my-8 border-b-2 border-[#333]"></div>' +
            generateLibraryBlock('puppetseq', 'Puppet Sequence', 'Sequence Name', '#ff00aa');
    }
}

function importImagesToSection(event, secId, type) {
    const files = event.target.files;
    if(!files || files.length === 0) return;
    
    let itemArr = type === 'imgdb' ? toolingData.imageDbItems : (type === 'convseq' ? toolingData.convSeqs : toolingData.puppetSeqs);
    
    Array.from(files).forEach(file => {
        let name = file.name.replace(/\.[^/.]+$/, ""); 
        itemArr.push({
            id: generateUUID(),
            name: name, title: name,
            sectionId: secId,
            color: getRandomHex()
        });
    });
    
    updateProjectLogic(false);
    renderToolLibrary();
    renderToolEditor();
    showNotification(`Imported ${files.length} items to section.`);
}

function scrollToToolCard(itemId) {
    activeToolItemId = itemId;
    const card = document.getElementById('tool-card-' + itemId);
    if(card) {
        card.scrollIntoView({ behavior: 'smooth', block: 'center' });
        document.querySelectorAll('.tool-left-item').forEach(el => { el.style.backgroundColor = 'transparent'; el.style.borderLeftWidth = '0'; });
        const leftEl = document.getElementById('left-item-' + itemId);
        if(leftEl) {
            leftEl.style.backgroundColor = '#1a1a1a';
            leftEl.style.borderLeftWidth = '4px';
        }
    }
}

function deleteToolItem(type, id) {
    let arr = getToolArrays(type).items;
    let idx = arr.findIndex(i => i.id === id);
    if(idx !== -1) arr.splice(idx, 1);
    if(activeToolItemId === id) activeToolItemId = null;
    updateProjectLogic(false);
    renderToolLibrary();
    renderToolEditor();
}

function sortToolSection(type, secId) {
    let arr = getToolArrays(type).items;
    let secItems = arr.filter(i => i.sectionId === secId).sort((a,b) => (a.title||a.name).localeCompare((b.title||b.name)));
    let otherItems = arr.filter(i => i.sectionId !== secId);
    
    let finalArr = [...otherItems, ...secItems];
    if(type === 'trans') toolingData.transitions = finalArr;
    if(type === 'imgnode') toolingData.imageNodes = finalArr;
    if(type === 'imgdb') toolingData.imageDbItems = finalArr;
    if(type === 'convseq') toolingData.convSeqs = finalArr;
    if(type === 'puppetseq') toolingData.puppetSeqs = finalArr;
    
    renderToolLibrary();
    renderToolEditor();
}

function clearToolSection(type, secId) {
    if(confirm("Delete all items in this section? Irreversible.")) {
        let arr = getToolArrays(type).items;
        let otherItems = arr.filter(i => i.sectionId !== secId);
        if(type === 'trans') toolingData.transitions = otherItems;
        if(type === 'imgnode') toolingData.imageNodes = otherItems;
        if(type === 'imgdb') toolingData.imageDbItems = otherItems;
        if(type === 'convseq') toolingData.convSeqs = otherItems;
        if(type === 'puppetseq') toolingData.puppetSeqs = otherItems;
        
        updateProjectLogic(false);
        renderToolLibrary();
        renderToolEditor();
    }
}

function renameToolSection(type, secId) {
    let arr = getToolArrays(type).sec;
    let sec = arr.find(s => s.id === secId);
    if (sec) {
        let newName = prompt("Rename section:", sec.name);
        if (newName && newName.trim() !== '' && newName !== sec.name) {
            sec.name = newName;
            renderToolLibrary();
            renderToolEditor();
        }
    }
}

// --- TOOLS EDITOR (MIDDLE PANEL) ---
function updateSectionPath(type, secId, val) {
    let arr = getToolArrays(type).sec;
    let sec = arr.find(s => s.id === secId);
    if(sec) {
        sec.path = val;
        let lInp = document.getElementById('left-sec-path-' + secId);
        if (lInp && lInp.value !== val) lInp.value = val;
        let mInp = document.getElementById('mid-sec-path-' + secId);
        if (mInp && mInp.value !== val) mInp.value = val;
    }
}

function updateToolValueInline(itemId, field, val) {
    let arr = getArrayForItemId(itemId);
    let item = arr.find(i => i.id === itemId);
    if(item) {
        item[field] = val;
        if(field === 'title' || field === 'name') {
            let leftEl = document.getElementById('left-title-' + itemId);
            if(leftEl) leftEl.innerText = val;
        }
        if(field === 'color') {
            let leftEl = document.getElementById('left-item-' + itemId);
            if(leftEl) leftEl.style.borderLeftColor = val;
            let card = document.getElementById('tool-card-' + itemId);
            if(card) {
                card.style.borderLeftColor = val;
                let badge = card.querySelector('.color-badge');
                if(badge) badge.style.backgroundColor = val;
                let moveBadge = card.querySelector('.move-badge');
                if(moveBadge) { moveBadge.style.borderColor = val; moveBadge.style.color = val; }
            }
        }
        if (field === 'isExternallyCalled' || field === 'makeExternalCall' || field === 'useBody' || field === 'useImage') {
            renderToolEditor();
        } else {
            updateProjectLogic(false);
            updateCardGlow(itemId);
        }
    }
}

function addToolArrayItem(itemId, type) {
    let item = getArrayForItemId(itemId).find(i => i.id === itemId);
    if(item) {
        item[type].push({key: '', op: '==', val: ''});
        updateProjectLogic(false);
        renderToolEditor();
    }
}

function updateToolArrayItemInline(itemId, type, idx, field, val) {
    let item = getArrayForItemId(itemId).find(i => i.id === itemId);
    if(item) {
        item[type][idx][field] = val;
        updateProjectLogic(false);
        updateCardGlow(itemId);
        if(activeToolLogicTab === 'local') renderToolLogicPanel();
        if(rightTab === 'logic') renderLogicPanel();
    }
}

function removeToolArrayItem(itemId, type, idx) {
    let item = getArrayForItemId(itemId).find(i => i.id === itemId);
    if(item) {
        item[type].splice(idx, 1);
        updateProjectLogic(false);
        renderToolEditor();
        if(activeToolLogicTab === 'local') renderToolLogicPanel();
        if(rightTab === 'logic') renderLogicPanel();
    }
}

function updateCardGlow(itemId) {
    let item = getArrayForItemId(itemId).find(i => i.id === itemId);
    if(!item) return;
    let glowColor = getToolGlowState(item);
    let card = document.getElementById('tool-card-' + itemId);
    if(card) {
        card.classList.remove('tool-glow-red', 'tool-glow-blue', 'tool-glow-purple');
        if(glowColor === 'red') card.classList.add('tool-glow-red');
        if(glowColor === 'blue') card.classList.add('tool-glow-blue');
        if(glowColor === 'purple') card.classList.add('tool-glow-purple');
    }
}


function nfEscapeAttribute(value) {
    return escapeHtml(value == null ? '' : String(value));
}

function nfEscapeJsString(value) {
    return String(value == null ? '' : value)
        .replace(/\\/g, '\\\\')
        .replace(/'/g, "\\'")
        .replace(/\r/g, '\\r')
        .replace(/\n/g, '\\n')
        .replace(/</g, '\\x3C')
        .replace(/>/g, '\\x3E');
}

function nfDefaultTextFormat() {
    return {
        bold: false,
        italic: false,
        underline: false,
        strikethrough: false,
        listStyle: 'none',
        alignH: 'left',
        alignV: 'top'
    };
}

function nfEnsureToolTextFormat(item, formatKey) {
    if (!item || typeof item !== 'object') return nfDefaultTextFormat();
    if (!item[formatKey] || typeof item[formatKey] !== 'object') item[formatKey] = nfDefaultTextFormat();
    item[formatKey] = { ...nfDefaultTextFormat(), ...item[formatKey] };
    return item[formatKey];
}

function nfGetAllToolItems() {
    const td = toolingData || {};
    return [
        ...(Array.isArray(td.transitions) ? td.transitions : []),
        ...(Array.isArray(td.imageNodes) ? td.imageNodes : []),
        ...(Array.isArray(td.imageDbItems) ? td.imageDbItems : []),
        ...(Array.isArray(td.convSeqs) ? td.convSeqs : []),
        ...(Array.isArray(td.puppetSeqs) ? td.puppetSeqs : [])
    ];
}

function nfFindToolItemById(itemId) {
    const id = String(itemId || '');
    return nfGetAllToolItems().find(item => String(item.id || '') === id) || null;
}

function nfGetToolDisplayName(item) {
    return String((item && (item.title || item.name || item.id)) || 'Untitled');
}

function nfGetToolKindLabel(type) {
    if (type === 'trans') return 'Transition';
    if (type === 'imgnode') return 'Image Node';
    if (type === 'imgdb') return 'Image DB';
    if (type === 'convseq') return 'Conversation Sequence';
    if (type === 'puppetseq') return 'Puppet Sequence';
    return 'Tool Entry';
}

function nfToggleToolItemCollapseById(itemId, event) {
    if (event) {
        event.preventDefault();
        event.stopPropagation();
    }
    const item = nfFindToolItemById(itemId);
    if (!item) return false;
    const body = document.body;
    if (body) body.classList.remove('nf-tools-deep-collapsed');
    item.isCollapsed = !item.isCollapsed;
    renderToolEditor();
    return false;
}

function nfSetAllToolPanelsCollapsed(shouldCollapse) {
    nfGetAllToolItems().forEach(item => {
        item.isCollapsed = !!shouldCollapse;
    });
    const body = document.body;
    if (body) body.classList.toggle('nf-tools-deep-collapsed', !!shouldCollapse);
    renderToolEditor();
    return false;
}

function nfDeepCollapseAllFromButton(shouldCollapse, event) {
    if (event) {
        event.preventDefault();
        event.stopPropagation();
    }
    return nfSetAllToolPanelsCollapsed(shouldCollapse);
}

function nfCopyToolItemId(itemId, event) {
    if (event) {
        event.preventDefault();
        event.stopPropagation();
    }
    const text = String(itemId || '');
    const done = () => {
        const button = event && event.currentTarget ? event.currentTarget : null;
        if (button) {
            button.classList.add('copied');
            setTimeout(() => button.classList.remove('copied'), 650);
        }
        showNotification('Copied Tool ID');
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done).catch(() => {
            const temp = document.createElement('textarea');
            temp.value = text;
            document.body.appendChild(temp);
            temp.select();
            document.execCommand('copy');
            temp.remove();
            done();
        });
    } else {
        const temp = document.createElement('textarea');
        temp.value = text;
        document.body.appendChild(temp);
        temp.select();
        document.execCommand('copy');
        temp.remove();
        done();
    }
    return false;
}

function nfSetToolTextFormat(itemId, formatKey, property, value, event) {
    if (event) {
        event.preventDefault();
        event.stopPropagation();
    }
    const item = nfFindToolItemById(itemId);
    if (!item) return false;
    const fmt = nfEnsureToolTextFormat(item, formatKey);
    if (value === '__toggle__') fmt[property] = !fmt[property];
    else fmt[property] = value;
    renderToolEditor();
    setTimeout(() => scrollToToolCard(itemId), 0);
    return false;
}

function nfFormatButtonHTML(itemId, formatKey, property, value, label, title, extraClass, isActive) {
    const safeId = nfEscapeJsString(itemId);
    const safeFormatKey = nfEscapeJsString(formatKey);
    const safeProperty = nfEscapeJsString(property);
    const safeValue = nfEscapeJsString(value);
    const activeClass = isActive ? ' active' : '';
    const className = `nf-format-btn ${extraClass || ''}${activeClass}`.trim();
    return `<button type="button" class="${className}" title="${escapeHtml(title)}" onclick="return nfSetToolTextFormat('${safeId}', '${safeFormatKey}', '${safeProperty}', '${safeValue}', event)">${label}</button>`;
}

function nfRenderTextFormatToolbar(item, formatKey) {
    const fmt = nfEnsureToolTextFormat(item, formatKey);
    const itemId = String(item.id || '');
    return `
        <div class="nf-format-toolbar" data-nf-format-toolbar="${escapeHtml(formatKey)}">
            ${nfFormatButtonHTML(itemId, formatKey, 'bold', '__toggle__', 'B', 'Bold', '', !!fmt.bold)}
            ${nfFormatButtonHTML(itemId, formatKey, 'italic', '__toggle__', 'I', 'Italic', 'italic', !!fmt.italic)}
            ${nfFormatButtonHTML(itemId, formatKey, 'underline', '__toggle__', 'U', 'Underline', 'underline', !!fmt.underline)}
            ${nfFormatButtonHTML(itemId, formatKey, 'strikethrough', '__toggle__', 'S', 'Strikethrough', 'strike', !!fmt.strikethrough)}
            <span class="nf-format-divider"></span>
            ${nfFormatButtonHTML(itemId, formatKey, 'listStyle', 'bullet', '•', 'Bullet List', '', fmt.listStyle === 'bullet')}
            ${nfFormatButtonHTML(itemId, formatKey, 'listStyle', 'number', '1.', 'Numbered List', '', fmt.listStyle === 'number')}
            ${nfFormatButtonHTML(itemId, formatKey, 'listStyle', 'none', '—', 'No List', '', fmt.listStyle === 'none')}
            <span class="nf-format-divider"></span>
            ${nfFormatButtonHTML(itemId, formatKey, 'alignH', 'left', '≡', 'Align Left', '', fmt.alignH === 'left')}
            ${nfFormatButtonHTML(itemId, formatKey, 'alignH', 'center', '≣', 'Align Center', '', fmt.alignH === 'center')}
            ${nfFormatButtonHTML(itemId, formatKey, 'alignH', 'right', '☰', 'Align Right', '', fmt.alignH === 'right')}
            <span class="nf-format-divider"></span>
            ${nfFormatButtonHTML(itemId, formatKey, 'alignV', 'top', '↥', 'Align Top', '', fmt.alignV === 'top')}
            ${nfFormatButtonHTML(itemId, formatKey, 'alignV', 'middle', '↕', 'Align Middle', '', fmt.alignV === 'middle')}
            ${nfFormatButtonHTML(itemId, formatKey, 'alignV', 'bottom', '↧', 'Align Bottom', '', fmt.alignV === 'bottom')}
        </div>
    `;
}

function nfTextFormatInlineStyle(item, formatKey) {
    const fmt = nfEnsureToolTextFormat(item, formatKey);
    const decorations = [];
    if (fmt.underline) decorations.push('underline');
    if (fmt.strikethrough) decorations.push('line-through');
    const styleParts = [
        `font-weight:${fmt.bold ? '900' : 'inherit'}`,
        `font-style:${fmt.italic ? 'italic' : 'normal'}`,
        `text-align:${fmt.alignH || 'left'}`
    ];
    if (decorations.length) styleParts.push(`text-decoration:${decorations.join(' ')}`);
    return styleParts.join(';');
}

function generateToolCardHTML(item, type, localIdx, secItems) {
    if (!item || typeof item !== 'object') return '';
    if (!item.id) item.id = generateUUID();
    if (!item.color) item.color = getRandomHex();
    if (!item.conditions || !Array.isArray(item.conditions)) item.conditions = [];
    if (!item.stateChanges || !Array.isArray(item.stateChanges)) item.stateChanges = [];
    if (type === 'trans') {
        if (item.title === undefined || item.title === null) item.title = item.name || 'Untitled Transition';
        if (item.name === undefined || item.name === null) item.name = item.title;
        if (item.bodyText === undefined || item.bodyText === null) item.bodyText = '';
        if (item.pauseTime === undefined || item.pauseTime === null) item.pauseTime = 5;
        if (item.useImage === undefined || item.useImage === null) item.useImage = false;
        if (item.imageId === undefined || item.imageId === null) item.imageId = '';
        nfEnsureToolTextFormat(item, 'titleTextFormat');
        nfEnsureToolTextFormat(item, 'bodyTextFormat');
    }
    if (type === 'imgnode') {
        if (item.title === undefined || item.title === null) item.title = item.name || 'Untitled Image Node';
        if (item.name === undefined || item.name === null) item.name = item.title;
        if (item.bodyText === undefined || item.bodyText === null) item.bodyText = '';
        if (item.imageId === undefined || item.imageId === null) item.imageId = '';
        if (item.shownFor === undefined || item.shownFor === null) item.shownFor = 5;
        if (item.useTitle === undefined || item.useTitle === null) item.useTitle = false;
        if (item.useBody === undefined || item.useBody === null) item.useBody = false;
    }
    if (['imgdb', 'convseq', 'puppetseq'].includes(type)) {
        if (item.name === undefined || item.name === null) item.name = item.title || 'Untitled Item';
        if (item.title === undefined || item.title === null) item.title = item.name;
    }

    const itemId = String(item.id);
    const jsId = nfEscapeJsString(itemId);
    const safeId = escapeHtml(itemId);
    const itemColor = escapeHtml(item.color || '#ff8c00');
    const itemName = nfGetToolDisplayName(item);
    const kindLabel = nfGetToolKindLabel(type);
    let glowColor = getToolGlowState(item);
    let cardClass = "tool-card w-full max-w-[800px] bg-[#111] border border-[#2a2a35] p-6 relative transition-all duration-300 mb-8";
    if (item.isCollapsed) cardClass += " is-collapsed";
    if(glowColor === 'red') cardClass += " tool-glow-red";
    if(glowColor === 'blue') cardClass += " tool-glow-blue";
    if(glowColor === 'purple') cardClass += " tool-glow-purple";

    let moveOptions = secItems.map((opt, i) => `<option value="${i}" ${i === localIdx ? 'selected' : ''}>#${i+1} ${escapeHtml(opt.title||opt.name)}</option>`).join('');

    let html = `
        <div id="tool-card-${safeId}" data-nf-tool-card-id="${safeId}" class="${cardClass}" style="border-left: 5px solid ${itemColor}; border-top-right-radius: 4px; border-bottom-right-radius: 4px;">
            <div class="nf-tool-tab-strip absolute -top-7 left-[-5px] flex items-end z-10 h-[28px]">
                <button type="button" class="color-badge nf-tool-collapse-tab px-3 py-1 text-black font-black text-xs flex items-center justify-center h-[28px] rounded-tl-md mr-[2px]" data-nf-tool-collapse-id="${safeId}" onclick="return nfToggleToolItemCollapseById('${jsId}', event)" style="background-color: ${itemColor};" title="Collapse / expand this panel">#${localIdx + 1}</button>
                <div class="move-badge bg-black border border-b-0 text-[10px] flex items-center px-2 py-1 h-[28px] rounded-tr-md" style="border-color: ${itemColor}; color: ${itemColor};">
                    <span class="text-dim mr-2 font-bold tracking-widest uppercase">Move To</span>
                    <select class="bg-[#050505] font-bold outline-none p-1 cursor-pointer max-w-[200px] truncate" onchange="reorderToolItem('${type}', '${jsId}', this.value)">
                        ${moveOptions}
                    </select>
                </div>
            </div>
            <div class="nf-card-id-zone absolute top-4 right-4 flex items-center justify-end gap-2 z-10">
                <div class="nf-panel-id-text text-[10px] text-dim italic opacity-70 select-all font-mono">${safeId}</div>
                <button type="button" class="nf-panel-copy-button" onclick="return nfCopyToolItemId('${jsId}', event)" title="Copy panel ID" aria-label="Copy panel ID">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                </button>
            </div>
            <div class="nf-tool-card-summary" aria-hidden="${item.isCollapsed ? 'false' : 'true'}">
                <div class="nf-tool-card-summary-title" style="color:${itemColor};">${escapeHtml(kindLabel)} #${localIdx + 1}</div>
                <div class="nf-tool-card-summary-name">${escapeHtml(itemName)}</div>
                <div class="nf-tool-card-summary-id">${safeId}</div>
            </div>
            <div class="nf-tool-card-body">
    `;

    if (type === 'trans' || type === 'imgnode') {
        html += `
            <div class="flex justify-end gap-6 items-center bg-[#111] p-3 border-b border-[#333] w-full mt-2 mb-0">
                <label class="ml-auto flex items-center gap-2 cursor-pointer font-black text-[9px] uppercase tracking-widest text-white">
                    <input type="checkbox" class="w-3.5 h-3.5 bg-black border-[#555] checked:bg-[var(--accent-teal)]" ${item.isExternallyCalled ? 'checked' : ''} onchange="updateToolValueInline('${jsId}', 'isExternallyCalled', this.checked)">
                    Called Externally
                </label>
                <label class="flex items-center gap-2 cursor-pointer font-black text-[9px] uppercase tracking-widest text-white">
                    <input type="checkbox" class="w-3.5 h-3.5 bg-black border-[#555] checked:bg-[var(--accent-teal)]" ${item.makeExternalCall ? 'checked' : ''} onchange="updateToolValueInline('${jsId}', 'makeExternalCall', this.checked)">
                    Make External Call
                </label>
            </div>
        `;
    }

    if (type === 'trans' || type === 'imgnode') {
        html += `
            <div class="mb-6 pb-6 border-b border-dashed border-[#333]">
                <div class="bg-black/40 p-5 border-l-[3px] border-l-[var(--accent-green)] border-x border-b border-[#222]">
                    <div class="flex justify-between items-center mb-4">
                        <label class="text-[11px] font-black uppercase tracking-widest text-[var(--accent-green)] m-0">Conditions</label>
                        <button class="btn btn-outline border-[var(--accent-green)] text-[var(--accent-green)] hover:bg-[var(--accent-green)] hover:text-black py-1.5 px-3 text-[9px] font-black tracking-widest" onclick="addToolArrayItem('${jsId}', 'conditions')">+ ADD CONDITION</button>
                    </div>
                    <div class="flex flex-col gap-2">
                        ${item.conditions.length === 0 ? '<div class="text-[10px] text-[#666] font-bold uppercase tracking-wider py-2">No conditions configured.</div>' : ''}
                        ${item.conditions.map((c, i) => `
                            <div class="grid grid-cols-[1fr_60px_1fr_36px] gap-2 items-center">
                                <input type="text" class="text-xs p-2 bg-black border border-[#333] focus:border-[var(--accent-green)] text-white outline-none" placeholder="Variable" value="${escapeHtml(c.key)}" oninput="updateToolArrayItemInline('${jsId}', 'conditions', ${i}, 'key', this.value)">
                                <select class="text-xs p-2 font-bold bg-black border border-[#333] focus:border-[var(--accent-green)] text-white outline-none text-center" onchange="updateToolArrayItemInline('${jsId}', 'conditions', ${i}, 'op', this.value)">
                                    ${OPERATORS.map(o => `<option value="${o}" ${c.op === o ? 'selected' : ''}>${o}</option>`).join('')}
                                </select>
                                <input type="text" class="text-xs p-2 bg-black border border-[#333] focus:border-[var(--accent-green)] text-white outline-none" placeholder="Value" value="${escapeHtml(c.val)}" oninput="updateToolArrayItemInline('${jsId}', 'conditions', ${i}, 'val', this.value)">
                                <button class="btn btn-outline border-[#333] hover:border-[var(--accent-pink)] text-[var(--accent-pink)] font-black p-0 h-full w-full flex items-center justify-center text-lg" onclick="removeToolArrayItem('${jsId}', 'conditions', ${i})">×</button>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
    }

    html += `<div class="mb-6 pb-6 border-b border-dashed border-[#333]">`;

    if (type === 'trans') {
        let imgOptions = toolingData.imageDbItems.map(i => `<option value="${escapeHtml(i.id)}" ${item.imageId === i.id ? 'selected' : ''}>${escapeHtml(i.name)}</option>`).join('');
        html += `
            <div class="grid grid-cols-2 gap-6">
                <div class="nf-transition-title-editor col-span-2">
                    <label class="block text-[10px] uppercase font-bold text-[var(--accent-orange)] mb-2 tracking-widest">Transition Title</label>
                    ${nfRenderTextFormatToolbar(item, 'titleTextFormat')}
                    <input type="text" value="${escapeHtml(item.title)}" oninput="updateToolValueInline('${jsId}', 'title', this.value)" class="text-lg font-black bg-black border-[#333] text-white p-3 focus:border-[var(--accent-orange)] w-full" style="${nfTextFormatInlineStyle(item, 'titleTextFormat')}">
                </div>
                <div>
                    <label class="block text-[10px] uppercase font-bold text-dim mb-2 tracking-widest">Pause Time (Secs)</label>
                    <input type="number" value="${escapeHtml(item.pauseTime)}" oninput="updateToolValueInline('${jsId}', 'pauseTime', parseInt(this.value)||5)" class="bg-black text-white border-[#333] p-3 text-lg font-bold w-full max-w-[120px]">
                </div>
                <div>
                    <label class="flex justify-between items-center text-[10px] uppercase font-bold text-dim mb-2 tracking-widest">
                        <span>Associated Image</span>
                        <span class="flex gap-2 items-center text-white cursor-pointer"><input type="checkbox" class="w-3.5 h-3.5" ${item.useImage ? 'checked' : ''} onchange="updateToolValueInline('${jsId}', 'useImage', this.checked);"> Enable Image</span>
                    </label>
                    ${item.useImage ? `<select onchange="updateToolValueInline('${jsId}', 'imageId', this.value)" class="bg-black border-[#333] p-3 w-full outline-none focus:border-[var(--accent-orange)] text-sm font-bold text-white">
                        <option value="">-- Select Image DB Entry --</option>${imgOptions}</select>` : `<select disabled class="bg-black border-[#222] p-3 w-full opacity-30 cursor-not-allowed text-sm"><option>-- Image Disabled --</option></select>`}
                </div>
                <div class="nf-transition-body-editor col-span-2">
                    <label class="block text-[10px] uppercase font-bold text-dim mb-2 tracking-widest">Body Text</label>
                    ${nfRenderTextFormatToolbar(item, 'bodyTextFormat')}
                    <textarea rows="5" oninput="updateToolValueInline('${jsId}', 'bodyText', this.value)" class="bg-black text-white border-[#333] p-4 text-sm leading-relaxed outline-none focus:border-[var(--accent-orange)] w-full" style="${nfTextFormatInlineStyle(item, 'bodyTextFormat')}">${escapeHtml(item.bodyText)}</textarea>
                </div>
            </div>
        `;
    } else if (type === 'imgnode') {
        let imgOptions = toolingData.imageDbItems.map(i => `<option value="${escapeHtml(i.id)}" ${item.imageId === i.id ? 'selected' : ''}>${escapeHtml(i.name)}</option>`).join('');
        let selClass = !item.imageId ? 'border-[var(--accent-pink)] shadow-[0_0_10px_rgba(255,0,123,0.3)]' : 'border-[#333] focus:border-[var(--accent-pink)]';
        html += `
            <div class="grid grid-cols-2 gap-6">
                <div class="col-span-2">
                    <label class="block text-[10px] uppercase font-bold text-[var(--accent-pink)] mb-2 tracking-widest">Image Node Title</label>
                    <input type="text" value="${escapeHtml(item.title)}" oninput="updateToolValueInline('${jsId}', 'title', this.value)" class="text-lg font-black text-white bg-black border-[#333] p-3 focus:border-[var(--accent-pink)] w-full">
                </div>
                <div class="col-span-2">
                    <label class="block text-[10px] uppercase font-bold text-[var(--accent-orange)] mb-2 tracking-widest">Select Render Image</label>
                    <select onchange="updateToolValueInline('${jsId}', 'imageId', this.value)" class="bg-black p-3 w-full outline-none text-sm font-bold text-white ${selClass}">
                        <option value="">-- MUST SELECT IMAGE --</option>${imgOptions}
                    </select>
                </div>
                <div>
                    <label class="block text-[10px] uppercase font-bold text-dim mb-2 tracking-widest">Shown For (Secs)</label>
                    <input type="number" value="${escapeHtml(item.shownFor)}" oninput="updateToolValueInline('${jsId}', 'shownFor', parseInt(this.value)||5)" class="bg-black text-white border-[#333] p-3 text-lg font-bold w-full max-w-[120px]">
                </div>
                <div class="flex flex-col justify-center gap-3 bg-black/30 p-3 border border-[#222]">
                    <label class="flex gap-3 items-center text-[10px] font-black tracking-widest text-white uppercase cursor-pointer">
                        <input type="checkbox" class="w-4 h-4 bg-black border border-[#555] checked:bg-[var(--accent-pink)]" ${item.useTitle ? 'checked' : ''} onchange="updateToolValueInline('${jsId}', 'useTitle', this.checked)"> 
                        Overlay Title Text
                    </label>
                    <label class="flex gap-3 items-center text-[10px] font-black tracking-widest text-white uppercase cursor-pointer">
                        <input type="checkbox" class="w-4 h-4 bg-black border border-[#555] checked:bg-[var(--accent-pink)]" ${item.useBody ? 'checked' : ''} onchange="updateToolValueInline('${jsId}', 'useBody', this.checked);"> 
                        Overlay Body Text
                    </label>
                </div>
                ${item.useBody ? `<div class="col-span-2 mt-2"><label class="block text-[10px] uppercase font-bold text-dim mb-2 tracking-widest">Body Text</label><textarea rows="4" oninput="updateToolValueInline('${jsId}', 'bodyText', this.value)" class="bg-black text-white border-[#333] p-4 text-sm leading-relaxed outline-none focus:border-[var(--accent-pink)] w-full">${escapeHtml(item.bodyText)}</textarea></div>` : ''}
            </div>
        `;
    } else if (['imgdb', 'convseq', 'puppetseq'].includes(type)) {
        html += `
            <div class="flex flex-col gap-6">
                <div>
                    <label class="block text-[10px] uppercase font-bold text-[var(--accent-teal)] mb-2 tracking-widest">Item Name</label>
                    <input type="text" value="${escapeHtml(item.name)}" oninput="updateToolValueInline('${jsId}', 'name', this.value)" class="text-lg font-black bg-black border-[#333] text-white p-3 focus:border-[var(--accent-teal)] w-full">
                </div>
                <div>
                    <label class="block text-[10px] uppercase font-bold text-dim mb-2 tracking-widest">Identity Color</label>
                    <div class="flex items-center gap-4 bg-black border border-[#333] p-2 w-max">
                        <input type="color" value="${escapeHtml(item.color)}" oninput="updateToolValueInline('${jsId}', 'color', this.value)" class="w-10 h-10 border-none p-0 cursor-pointer bg-transparent">
                        <span class="text-xs font-mono font-bold tracking-widest pr-4 text-white">${escapeHtml(String(item.color).toUpperCase())}</span>
                    </div>
                </div>
            </div>
        `;
    }

    html += `</div>`;

    if (type === 'trans' || type === 'imgnode') {
        html += `
            <div>
                <div class="bg-black/40 p-5 border-l-[3px] border-l-[var(--accent-blue)] border-y border-r border-[#222]">
                    <div class="flex justify-between items-center mb-4">
                        <label class="text-[11px] font-black uppercase tracking-widest text-[var(--accent-blue)] m-0">Change Game State</label>
                        <button class="btn btn-outline border-[var(--accent-blue)] text-[var(--accent-blue)] hover:bg-[var(--accent-blue)] hover:text-black py-1.5 px-3 text-[9px] font-black tracking-widest" onclick="addToolArrayItem('${jsId}', 'stateChanges')">+ ADD STATE CHANGE</button>
                    </div>
                    <div class="flex flex-col gap-2">
                        ${item.stateChanges.length === 0 ? '<div class="text-[10px] text-[#666] font-bold uppercase tracking-wider py-2">No state changes configured.</div>' : ''}
                        ${item.stateChanges.map((c, i) => `
                            <div class="grid grid-cols-[1fr_60px_1fr_36px] gap-2 items-center">
                                <input type="text" class="text-xs p-2 bg-black border border-[#333] focus:border-[var(--accent-blue)] text-white outline-none" placeholder="Variable" value="${escapeHtml(c.key)}" oninput="updateToolArrayItemInline('${jsId}', 'stateChanges', ${i}, 'key', this.value)">
                                <select class="text-xs p-2 font-bold bg-black border border-[#333] focus:border-[var(--accent-blue)] text-white outline-none text-center" onchange="updateToolArrayItemInline('${jsId}', 'stateChanges', ${i}, 'op', this.value)">
                                    <option value="=" ${c.op === '=' ? 'selected' : ''}>=</option>
                                    <option value="+=" ${c.op === '+=' ? 'selected' : ''}>+=</option>
                                    <option value="-=" ${c.op === '-=' ? 'selected' : ''}>-=</option>
                                </select>
                                <input type="text" class="text-xs p-2 bg-black border border-[#333] focus:border-[var(--accent-blue)] text-white outline-none" placeholder="Value" value="${escapeHtml(c.val)}" oninput="updateToolArrayItemInline('${jsId}', 'stateChanges', ${i}, 'val', this.value)">
                                <button class="btn btn-outline border-[#333] hover:border-[var(--accent-pink)] text-[var(--accent-pink)] font-black p-0 h-full w-full flex items-center justify-center text-lg" onclick="removeToolArrayItem('${jsId}', 'stateChanges', ${i})">×</button>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
    }

    html += `</div></div>`;
    return html;
}

if (typeof window !== 'undefined') {
    window.nfToggleToolItemCollapseById = nfToggleToolItemCollapseById;
    window.nfDeepCollapseAllFromButton = nfDeepCollapseAllFromButton;
    window.nfCopyToolItemId = nfCopyToolItemId;
    window.nfSetToolTextFormat = nfSetToolTextFormat;
}

function renderToolEditor() {
    const cont = document.getElementById('tool-editor-content');
    
    let typesToRender = [];
    if(activeToolCategory === 'trans') typesToRender = ['trans'];
    else if(activeToolCategory === 'imgnode') typesToRender = ['imgnode'];
    else if(activeToolCategory === 'imgdb') typesToRender = ['imgdb', 'convseq', 'puppetseq'];

    let html = '';
    
    typesToRender.forEach(type => {
        const arrays = getToolArrays(type);
        arrays.sec.forEach(sec => {
            const isCol = collapsedMiddleGroups.has(sec.id);
            
            html += `
                <div class="w-full max-w-[800px] mt-16 mb-10 flex flex-col relative" id="section-container-${sec.id}">
                    <div class="flex justify-between items-center border-b border-[#444] pb-4 pt-4 mb-6 mt-6 bg-[#0a0a0a] px-4 rounded-md shadow-md">
                        <div class="flex items-center gap-3">
                            <button class="text-[#888] hover:text-white font-black text-xl w-6" onclick="toggleMiddleSection('${sec.id}')">${isCol ? '▶' : '▼'}</button>
                            <h2 class="text-xl font-black text-[#a1a1aa] uppercase tracking-widest cursor-pointer hover:text-[var(--accent-teal)]" ondblclick="renameToolSection('${type}', '${sec.id}')" title="Double click to rename">${escapeHtml(sec.name)}</h2>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="text-[10px] text-dim font-bold uppercase">Object Path:</span>
                            <input type="text" id="mid-sec-path-${sec.id}" value="${escapeHtml(sec.path||'')}" oninput="updateSectionPath('${type}', '${sec.id}', this.value)" class="bg-black border border-[#333] px-2 py-1 text-xs w-[200px] text-white outline-none">
                        </div>
                    </div>
            `;
            
            if (!isCol) {
                const secItems = arrays.items.filter(i => i.sectionId === sec.id);
                secItems.forEach((item, localIdx) => {
                    html += generateToolCardHTML(item, type, localIdx, secItems);
                });
                if(secItems.length === 0) {
                    html += `<div class="empty-state text-center text-[#555] py-4 text-[10px] font-bold uppercase tracking-wider mb-8">No items in ${escapeHtml(sec.name)}.</div>`;
                }
            }
            html += `</div>`;
        });
    });
    
    if(html === '') {
        html = '<div class="empty-state text-center text-[#888899] py-10 text-xs font-bold uppercase tracking-wider">No sections created yet. Use the left panel to begin.</div>';
    }
    
    cont.innerHTML = html;
}

function renderToolLogicPanel() {
    const cont = document.getElementById('tool-logic-content');
    cont.classList.remove('hidden');

    if (activeToolLogicTab === 'local') {
        const localLogic = getLocalToolLogic();
        let html = '<div class="tag-container pb-8">';
        for (let key of Object.keys(localLogic).sort()) {
            let log = localLogic[key];
            let cls = 'logic-tag ';
            const pLog = projectLogic[key];
            
            // Only tag Purple if the ProjectLogic validates that it's utilized as BOTH condition & statechange in the ENTIRE project scope.
            if (pLog && pLog.usage === 'mixed') {
                cls += 'tag-purple';
            } else {
                if (log.condition) cls += 'tag-green';
                else if (log.stateChange) cls += 'tag-blue';
            }
            
            html += `<div class="${cls}" data-key="${escapeHtml(key)}" onclick="openTagModal('${escapeHtml(key)}', true)">
                ${escapeHtml(key)} <span class="opacity-50 text-[9px] ml-1">(${log.count})</span>
            </div>`;
        }
        html += '</div>';
        if (Object.keys(localLogic).length === 0) html = '<div class="empty-state text-center text-[#888899] py-10 text-xs font-bold uppercase tracking-wider">No internal logic declared in these tools.</div>';
        cont.innerHTML = html;
    } else {
        const activeKeys = Object.keys(projectLogic).filter(k => !startupValues.some(v=>normalizeStatement(v.key, v.op, v.val)===k) && !gameEndValues.some(v=>normalizeStatement(v.key, v.op, v.val)===k) && gameplayValues[k]===undefined);
        if (activeKeys.length === 0) {
            cont.innerHTML = '<div class="empty-state text-center text-[#888899] py-10 text-xs font-bold uppercase tracking-wider">No Master Project Logic Found.</div>';
        } else {
            cont.innerHTML = `<div class="tag-container pb-8">${activeKeys.map(k => renderTag(k)).join('')}</div>`;
        }
    }
}