// ============================================================================
// DD_DATA.JS - Data Manipulation, Logic Models, and Project State
// ============================================================================

// --- SAFE GLOBAL DECLARATIONS FOR HOT RELOADING ---
// Bypassing var/let/const entirely at the root scope prevents "Identifier has already been declared" 
// errors when the environment hot-reloads the script.
if (typeof window.availableLanguages === 'undefined') {
    window.availableLanguages = ['ENG', 'SPN', 'RUS', 'IRI', 'SCO', 'FRE', 'POL', 'GER', 'ARA', 'JAP'];
}
if (typeof window.currentLanguage === 'undefined') {
    window.currentLanguage = 'ENG';
}
if (typeof window.isAddingLanguage === 'undefined') {
    window.isAddingLanguage = false;
}

// Safe utility fallback
if (typeof window.getRandomColor === 'undefined') {
    window.getRandomColor = function() {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) color += letters[Math.floor(Math.random() * 16)];
        return color;
    };
}

if (!Array.isArray(window.conversations)) window.conversations = [];
if (!Array.isArray(window.sequences)) window.sequences = [];
if (!Array.isArray(window.cast)) window.cast = [];
if (!Array.isArray(window.globalTokens)) window.globalTokens = [];
if (!Array.isArray(window.globalStates)) window.globalStates = [];
if (!Array.isArray(window.globalMoods)) window.globalMoods = [];
if (!Array.isArray(window.globalSettings)) window.globalSettings = [];
if (!Array.isArray(window.globalTimesOfDay)) window.globalTimesOfDay = [];
if (!Array.isArray(window.globalDaysOfWeek)) window.globalDaysOfWeek = [];
if (!Array.isArray(window.globalMenuOptions)) window.globalMenuOptions = [];
if (!Array.isArray(window.globalImageSequences)) window.globalImageSequences = [];
if (typeof window.activeIndex === 'undefined') window.activeIndex = null;
if (typeof window.activeType === 'undefined') window.activeType = 'conversation';


// --- LANGUAGE TEXT CONTAINER HELPERS ---
function getLanguageList() {
    if (!Array.isArray(window.availableLanguages)) window.availableLanguages = ['ENG'];
    if (!window.availableLanguages.includes('ENG')) window.availableLanguages.unshift('ENG');
    return window.availableLanguages;
}

function ensureTextTranslationsForEntry(entry) {
    if (!entry) return;
    if (!entry.translations || typeof entry.translations !== 'object' || Array.isArray(entry.translations)) {
        entry.translations = {};
    }

    const languages = getLanguageList();
    if (!Object.prototype.hasOwnProperty.call(entry.translations, 'ENG')) {
        entry.translations.ENG = entry.text || '';
    }

    languages.forEach(lang => {
        if (!Object.prototype.hasOwnProperty.call(entry.translations, lang)) {
            entry.translations[lang] = '';
        }
    });
}

function ensureProjectTranslationContainers(project) {
    if (!project || !Array.isArray(project.nodes)) return;
    project.nodes.forEach(node => {
        ensureTextTranslationsForEntry(node);
        (node.responses || []).forEach(response => ensureTextTranslationsForEntry(response));
    });
}

function ensureAllTranslationContainers() {
    [...(window.conversations || []), ...(window.sequences || [])].forEach(project => ensureProjectTranslationContainers(project));
}

function getLocalizedText(entry, lang = window.currentLanguage) {
    ensureTextTranslationsForEntry(entry);
    return Object.prototype.hasOwnProperty.call(entry.translations, lang) ? entry.translations[lang] : '';
}

function setLocalizedText(entry, value, lang = window.currentLanguage) {
    ensureTextTranslationsForEntry(entry);
    const normalized = String(lang || 'ENG').trim().toUpperCase();
    if (!getLanguageList().includes(normalized)) window.availableLanguages.push(normalized);
    entry.translations[normalized] = value;
    if (normalized === 'ENG') entry.text = value;
}

function setCurrentLanguage(lang) {
    const normalized = String(lang || 'ENG').trim().toUpperCase();
    if (!getLanguageList().includes(normalized)) window.availableLanguages.push(normalized);
    window.currentLanguage = normalized;
    ensureAllTranslationContainers();
    if (typeof renderNodes === 'function') renderNodes();
    if (typeof markWorkspaceDirty === 'function') markWorkspaceDirty();
}

function collectLanguagesFromProjects(projects) {
    const found = new Set(getLanguageList());
    (projects || []).forEach(project => {
        (project.nodes || []).forEach(node => {
            Object.keys(node.translations || {}).forEach(lang => found.add(lang));
            (node.responses || []).forEach(response => {
                Object.keys(response.translations || {}).forEach(lang => found.add(lang));
            });
        });
    });
    window.availableLanguages = Array.from(found).map(lang => String(lang).trim().toUpperCase()).filter(Boolean);
    if (!window.availableLanguages.includes('ENG')) window.availableLanguages.unshift('ENG');
}

// --- HELPERS ---

function getResponseAdvancedDefaults() {
    return {
        advancedOpen: false,
        resourcePath: 'Assets/Resources/Slides/',
        usePath: false,
        closeMainMenu: false,
        closeDialogueMenu: false,
        openPromptPanel: false,
        closePromptPanel: false,
        changeTimeOfDay: false,
        timeOfDayChanges: [{ time: '', value: '' }],
        changeDayOfWeek: false,
        dayOfWeekChanges: [{ day: '', value: '' }],
        changeMenuOption: false,
        menuOptionChanges: [{ menu: '', value: '' }],
        changeSetting: false,
        settingChanges: [{ setting: '', value: '' }],
        controlSequence: false,
        sequenceName: '',
        sequenceImage: '',
        controlPuppets: false,
        puppetUsePath: false,
        puppetUseTag: false,
        changePuppetState: false,
        changePuppetMood: false,
        changePuppetInvert: false,
        puppets: []
    };
}

function ensureResponseAdvancedDefaults(response) {
    if (!response || typeof response !== 'object') return response;
    const defaults = getResponseAdvancedDefaults();
    Object.keys(defaults).forEach(key => {
        if (response[key] === undefined || response[key] === null) {
            response[key] = Array.isArray(defaults[key]) ? JSON.parse(JSON.stringify(defaults[key])) : defaults[key];
        }
    });
    if (!response.resourcePath) response.resourcePath = 'Assets/Resources/Slides/';
    if (!response.timeOfDayChanges || response.timeOfDayChanges.length === 0) response.timeOfDayChanges = [{ time: '', value: '' }];
    if (!response.dayOfWeekChanges || response.dayOfWeekChanges.length === 0) response.dayOfWeekChanges = [{ day: '', value: '' }];
    if (!response.menuOptionChanges || response.menuOptionChanges.length === 0) response.menuOptionChanges = [{ menu: '', value: '' }];
    if (!response.settingChanges || response.settingChanges.length === 0) response.settingChanges = [{ setting: '', value: '' }];
    if (!response.textFormat) response.textFormat = { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
    if (!response.puppets) response.puppets = [];
    response.puppets.forEach(puppet => {
        if (puppet.name === undefined || puppet.name === null) puppet.name = '';
        if (puppet.enabled === undefined || puppet.enabled === null) puppet.enabled = true;
        if (puppet.position === undefined || puppet.position === null) puppet.position = '';
        if (!puppet.path) puppet.path = 'Assets/Resources/Puppets/';
        if (puppet.state === undefined || puppet.state === null) puppet.state = '';
        if (puppet.mood === undefined || puppet.mood === null) puppet.mood = '';
        if (puppet.invert === undefined || puppet.invert === null) puppet.invert = false;
    });
    return response;
}

function getEmptyNode(speaker = '') {
    return {
        id: crypto.randomUUID(), 
        isCollapsed: false,
        voiceLine: true,
        nodeColor: (typeof window.getRandomColor === 'function') ? window.getRandomColor() : '#ff007b',
        advancedOpen: false,
        conditionsOpen: true,
        statesOpen: true,
        responsesOpen: true,
        conditions: [], speaker: speaker, text: '',
        resourcePath: 'Assets/Resources/Slides/', usePath: false, closeMainMenu: false, closeDialogueMenu: false,
        openPromptPanel: false, closePromptPanel: false, changeTimeOfDay: false, timeOfDayChanges: [{ time: '', value: '' }],
        changeDayOfWeek: false, dayOfWeekChanges: [{ day: '', value: '' }], changeMenuOption: false, menuOptionChanges: [{ menu: '', value: '' }],
        gameStateChanges: [], changeSetting: false, settingChanges: [{ setting: '', value: '' }], controlSequence: false,
        sequenceName: '', sequenceImage: '', controlPuppets: false, puppetUsePath: false, puppetUseTag: false, 
        changePuppetState: false, changePuppetMood: false, changePuppetInvert: false, puppets: [], canPlayerRespond: false,
        externalCall: false, makeExternalCall: false, responses: [], parentResponseId: null, parentResponsePreview: null,
        textFormat: { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' },
        responseDraftFormat: { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' },
        translations: {} // Translation Map Support
    };
}

function getEmptyProject(title = 'Untitled Project', color = null, isStarterProject = false) {
    return {
        id: crypto.randomUUID(),
        title,
        color: color || ((typeof window.getRandomColor === 'function') ? window.getRandomColor() : '#00f2ff'),
        participants: [],
        nodes: [],
        isRepeatable: false,
        repeatVariable: '',
        __isStarterProject: isStarterProject
    };
}

function isStarterProject(project) {
    return !!project && project.__isStarterProject === true &&
        (project.nodes || []).length === 0 &&
        (project.participants || []).length === 0 &&
        (project.title === 'Untitled Project' || project.title === '');
}

function initializeDefaultWorkspace() {
    if (window.DD_SERVER_BOOTSTRAP_PENDING && !window.DD_SERVER_BOOTSTRAP_DONE) {
        const startedAt = Number(window.DD_SERVER_BOOTSTRAP_STARTED_AT || Date.now());
        if (Date.now() - startedAt < 7000) {
            setTimeout(initializeDefaultWorkspace, 150);
            return;
        }
        window.DD_SERVER_BOOTSTRAP_PENDING = false;
        window.DD_SERVER_BOOTSTRAP_DONE = true;
        console.warn('Dialogue Designer server bootstrap timed out; opening local starter workspace.');
    }

    if (!Array.isArray(window.conversations)) window.conversations = [];
    if (!Array.isArray(window.sequences)) window.sequences = [];

    const hasProjects = window.conversations.length > 0 || window.sequences.length > 0;
    if (!hasProjects) {
        window.conversations.push(getEmptyProject('Untitled Project', '#00f2ff', true));
        window.activeType = 'conversation';
        window.activeIndex = 0;
    } else if (window.activeIndex === null || window.activeIndex === undefined) {
        window.activeType = window.conversations.length > 0 ? 'conversation' : 'sequence';
        window.activeIndex = 0;
    }

    if (typeof renderConversations === 'function') renderConversations();
    if (typeof renderSequences === 'function') renderSequences();
    if (typeof openEditor === 'function' && window.activeIndex !== null && window.activeIndex !== undefined) {
        openEditor(window.activeIndex, window.activeType);
    }
}

function scheduleDefaultWorkspaceInitialization() {
    setTimeout(initializeDefaultWorkspace, 0);
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scheduleDefaultWorkspaceInitialization);
} else {
    scheduleDefaultWorkspaceInitialization();
}

// --- DRAG AND DROP HANDLING ---
function handleDragStart(ev, type, idx) {
    ev.dataTransfer.setData('text/plain', JSON.stringify({ type, index: idx }));
}

function handleProjectItemDrop(ev, targetType, targetIndex) {
    ev.preventDefault();
    ev.stopPropagation(); 
    try {
        const data = JSON.parse(ev.dataTransfer.getData('text/plain'));
        const sourceType = data.type;
        const sourceIndex = data.index;

        if ((sourceType === 'conversation' || sourceType === 'sequence') && (targetType === 'conversation' || targetType === 'sequence')) {
            const sourceList = sourceType === 'conversation' ? window.conversations : window.sequences;
            const targetList = targetType === 'conversation' ? window.conversations : window.sequences;

            if (sourceType === targetType) {
                if (sourceIndex === targetIndex) return;
                const item = sourceList.splice(sourceIndex, 1)[0];
                targetList.splice(targetIndex, 0, item);
                
                if (window.activeType === targetType) {
                    if (window.activeIndex === sourceIndex) window.activeIndex = targetIndex;
                    else if (window.activeIndex > sourceIndex && window.activeIndex <= targetIndex) window.activeIndex--;
                    else if (window.activeIndex < sourceIndex && window.activeIndex >= targetIndex) window.activeIndex++;
                }
            } else {
                const itemToMove = sourceList[sourceIndex];
                
                if (sourceType === 'sequence' && targetType === 'conversation') {
                    if (!confirm("Warning: Moving this project from Sequences to Conversations will unlink it from its associated Image Sequence. Proceed?")) return;
                    itemToMove.nodes.forEach(n => {
                        if (n.sequenceName === itemToMove.title || n.controlSequence) {
                            n.controlSequence = false;
                            n.sequenceName = '';
                            n.sequenceImage = '';
                        }
                    });
                    if (typeof renderImageSequences === 'function') renderImageSequences(); 
                }

                const item = sourceList.splice(sourceIndex, 1)[0];
                targetList.splice(targetIndex, 0, item); 

                if (sourceType === 'conversation' && targetType === 'sequence') {
                    if (!window.globalImageSequences.some(s => s.name === item.title)) {
                        window.globalImageSequences.push({ name: item.title, color: item.color || window.getRandomColor(), path: 'Assets/2D/Sequences/', images: [] });
                    }
                    if (item.nodes.length === 0) item.nodes.push(getEmptyNode());
                    item.nodes[0].controlSequence = true;
                    item.nodes[0].sequenceName = item.title;
                    const imgSeq = window.globalImageSequences.find(s => s.name === item.title);
                    if (imgSeq && imgSeq.images.length > 0) item.nodes[0].sequenceImage = imgSeq.images[0];
                    if (typeof renderImageSequences === 'function') renderImageSequences();
                }

                if (window.activeType === sourceType && window.activeIndex === sourceIndex) {
                    window.activeType = targetType;
                    window.activeIndex = targetIndex;
                } else if (window.activeType === sourceType && window.activeIndex > sourceIndex) {
                    window.activeIndex--;
                } else if (window.activeType === targetType && window.activeIndex >= targetIndex) {
                    window.activeIndex++;
                }
            }
            if (typeof renderConversations === 'function') renderConversations();
            if (typeof renderSequences === 'function') renderSequences();
        }
    } catch(e) { console.error("Drop handle error:", e); }
}

function handleDrop(ev, targetType) {
    ev.preventDefault();
    try {
        const data = JSON.parse(ev.dataTransfer.getData('text/plain'));
        
        if ((data.type === 'conversation' || data.type === 'sequence') && (targetType === 'conversation' || targetType === 'sequence')) {
            const sourceList = data.type === 'conversation' ? window.conversations : window.sequences;
            const targetList = targetType === 'conversation' ? window.conversations : window.sequences;
            
            if (data.type === targetType) {
                const item = sourceList.splice(data.index, 1)[0];
                targetList.push(item);
                if (window.activeType === targetType) {
                    if (window.activeIndex === data.index) window.activeIndex = targetList.length - 1;
                    else if (window.activeIndex > data.index) window.activeIndex--;
                }
            } else {
                const itemToMove = sourceList[data.index];

                if (data.type === 'sequence' && targetType === 'conversation') {
                    if (!confirm("Warning: Moving this project from Sequences to Conversations will unlink it from its associated Image Sequence. Proceed?")) return;
                    itemToMove.nodes.forEach(n => {
                        if (n.sequenceName === itemToMove.title || n.controlSequence) {
                            n.controlSequence = false;
                            n.sequenceName = '';
                            n.sequenceImage = '';
                        }
                    });
                    if (typeof renderImageSequences === 'function') renderImageSequences(); 
                }

                const item = sourceList.splice(data.index, 1)[0];
                targetList.push(item);
                
                if (data.type === 'conversation' && targetType === 'sequence') {
                    if (!window.globalImageSequences.some(s => s.name === item.title)) {
                        window.globalImageSequences.push({
                            name: item.title,
                            color: item.color || window.getRandomColor(),
                            path: 'Assets/2D/Sequences/',
                            images: []
                        });
                    }
                    
                    if (item.nodes.length === 0) item.nodes.push(getEmptyNode());
                    item.nodes[0].controlSequence = true;
                    item.nodes[0].sequenceName = item.title;
                    const imgSeq = window.globalImageSequences.find(s => s.name === item.title);
                    if (imgSeq && imgSeq.images.length > 0) item.nodes[0].sequenceImage = imgSeq.images[0];
                    if (typeof renderImageSequences === 'function') renderImageSequences();
                }
                
                if (window.activeType === data.type && window.activeIndex === data.index) {
                    window.activeType = targetType;
                    window.activeIndex = targetList.length - 1;
                } else if (window.activeType === data.type && window.activeIndex > data.index) {
                    window.activeIndex--;
                }
            }
            
            if (typeof renderConversations === 'function') renderConversations();
            if (typeof renderSequences === 'function') renderSequences();
        }
    } catch(err) {
        console.error("Drop handling error:", err);
    }
}

// --- PROJECT MANAGEMENT ---
function createNewConversation() {
    const title = document.getElementById('new-conv-name').value.trim();
    if (!title) return;
    
    window.conversations.push({ 
        id: crypto.randomUUID(),
        title, 
        color: window.getRandomColor(),
        participants: [], 
        nodes: [],
        isRepeatable: false,
        repeatVariable: ''
    });
    if (typeof renderConversations === 'function') renderConversations();
    if (typeof markWorkspaceDirty === 'function') markWorkspaceDirty();
    if (typeof openEditor === 'function') openEditor(window.conversations.length - 1, 'conversation');
    document.getElementById('new-conv-name').value = '';
}

function startProjectRename(type, idx) {
    window.renamingProject = { type, index: idx };
    if (type === 'conversation' && typeof renderConversations === 'function') renderConversations();
    if (type === 'sequence' && typeof renderSequences === 'function') renderSequences();
}

function cancelProjectRename() {
    const oldType = window.renamingProject.type;
    window.renamingProject = { type: null, index: null };
    if (oldType === 'conversation' && typeof renderConversations === 'function') renderConversations();
    if (oldType === 'sequence' && typeof renderSequences === 'function') renderSequences();
}

function saveProjectRename(type, idx) {
    const input = document.getElementById(`rename-${type}-${idx}`);
    if (input && input.value.trim()) {
        const targetList = type === 'conversation' ? window.conversations : window.sequences;
        const oldName = targetList[idx].title;
        const newName = input.value.trim();
        targetList[idx].title = newName;
        
        if (type === 'sequence' && oldName !== newName) {
            const imgSeq = window.globalImageSequences.find(s => s.name === oldName);
            if (imgSeq) {
                imgSeq.name = newName;
                propagateImageSeqRename(oldName, newName);
                if (typeof renderImageSequences === 'function') renderImageSequences();
            }
        }

        if (window.activeType === type && window.activeIndex === idx) {
            const editConvName = document.getElementById('edit-conv-name');
            if (editConvName) editConvName.value = newName;
        }
    }
    cancelProjectRename();
    if (typeof markWorkspaceDirty === 'function') markWorkspaceDirty();
}

function duplicateProject(type, idx) {
    if (typeof openCloneProjectModal === 'function') { openCloneProjectModal(type, idx); return; }
    const sourceList = type === 'conversation' ? window.conversations : window.sequences;
    const sourceProj = sourceList[idx];

    const newProj = JSON.parse(JSON.stringify(sourceProj));
    newProj.id = crypto.randomUUID();

    let copyNum = 1;
    let baseTitle = newProj.title;
    if (/\s\(\d+\)$/.test(baseTitle)) {
        baseTitle = baseTitle.replace(/\s\(\d+\)$/, '');
    }
    
    while(sourceList.some(p => p.title === `${baseTitle} (${copyNum})`)) { copyNum++; }
    newProj.title = `${baseTitle} (${copyNum})`;

    const idMap = {};
    newProj.nodes.forEach(n => {
        const oldId = n.id;
        const newId = crypto.randomUUID();
        n.id = newId;
        idMap[oldId] = newId;

        n.responses.forEach(r => {
            const oldRespId = r.id;
            const newRespId = crypto.randomUUID();
            r.id = newRespId;
            idMap[oldRespId] = newRespId;
        });
    });

    newProj.nodes.forEach(n => {
        if (n.parentResponseId && idMap[n.parentResponseId]) n.parentResponseId = idMap[n.parentResponseId];
        n.responses.forEach(r => {
            if (r.nextStatementId && idMap[r.nextStatementId]) r.nextStatementId = idMap[r.nextStatementId];
        });
    });

    sourceList.splice(idx + 1, 0, newProj);
    
    if (window.activeType === type && window.activeIndex > idx) window.activeIndex++;
    
    if (type === 'conversation' && typeof renderConversations === 'function') renderConversations();
    if (type === 'sequence' && typeof renderSequences === 'function') renderSequences();
    if (typeof showNotification === 'function') showNotification("Project Duplicated successfully");
}


function prepareClonedProject(sourceProj, newTitle) {
    const newProj = JSON.parse(JSON.stringify(sourceProj));
    newProj.id = crypto.randomUUID();
    newProj.title = newTitle;
    delete newProj.__isStarterProject;

    const idMap = {};
    (newProj.nodes || []).forEach(n => {
        const oldId = n.id;
        const newId = crypto.randomUUID();
        n.id = newId;
        idMap[oldId] = newId;
        (n.responses || []).forEach(r => {
            const oldRespId = r.id;
            const newRespId = crypto.randomUUID();
            r.id = newRespId;
            idMap[oldRespId] = newRespId;
            if (typeof ensureResponseAdvancedDefaults === 'function') ensureResponseAdvancedDefaults(r);
        });
    });

    (newProj.nodes || []).forEach(n => {
        if (n.parentResponseId && idMap[n.parentResponseId]) n.parentResponseId = idMap[n.parentResponseId];
        (n.responses || []).forEach(r => {
            if (r.nextStatementId && idMap[r.nextStatementId]) r.nextStatementId = idMap[r.nextStatementId];
        });
    });

    return newProj;
}

function openCloneProjectModal(type, idx, ev) {
    if (ev) ev.stopPropagation();
    window.cloneProjectTarget = { type, index: idx };
    const list = type === 'conversation' ? window.conversations : window.sequences;
    const project = list[idx];
    if (!project) return;

    const modal = document.getElementById('clone-project-modal');
    const input = document.getElementById('clone-project-name-input');
    const suggestions = document.getElementById('clone-project-title-suggestions');
    if (!modal || !input || !suggestions) return;

    input.value = `${project.title} (Clone)`;
    const allTitles = [
        ...(window.conversations || []).map(p => ({ type: 'Conversation', title: p.title })),
        ...(window.sequences || []).map(p => ({ type: 'Sequence', title: p.title }))
    ];

    suggestions.innerHTML = allTitles.map(item => `
        <button class="clone-title-option" type="button" onclick="document.getElementById('clone-project-name-input').value = this.dataset.title;" data-title="${escapeHtml(item.title)}">
            <span>${escapeHtml(item.title)}</span>
            <em>${item.type}</em>
        </button>
    `).join('');

    modal.style.display = 'flex';
    setTimeout(() => { input.focus(); input.select(); }, 0);
}

function closeCloneProjectModal() {
    const modal = document.getElementById('clone-project-modal');
    if (modal) modal.style.display = 'none';
    window.cloneProjectTarget = null;
}

function applyCloneProject() {
    if (!window.cloneProjectTarget) return;
    const { type, index } = window.cloneProjectTarget;
    const sourceList = type === 'conversation' ? window.conversations : window.sequences;
    const sourceProj = sourceList[index];
    const input = document.getElementById('clone-project-name-input');
    if (!sourceProj || !input) return;

    const newTitle = input.value.trim() || `${sourceProj.title} (Clone)`;
    const newProj = prepareClonedProject(sourceProj, newTitle);
    sourceList.splice(index + 1, 0, newProj);

    if (window.activeType === type && window.activeIndex > index) window.activeIndex++;
    closeCloneProjectModal();
    if (type === 'conversation' && typeof renderConversations === 'function') renderConversations();
    if (type === 'sequence' && typeof renderSequences === 'function') renderSequences();
    if (typeof markWorkspaceDirty === 'function') markWorkspaceDirty();
    if (typeof showNotification === 'function') showNotification('Project cloned successfully.');
}

function deleteProject(type, idx) {
    if (confirm("Are you sure you want to delete this? This action cannot be undone.")) {
        const targetList = type === 'conversation' ? window.conversations : window.sequences;
        targetList.splice(idx, 1);
        
        if (window.activeType === type && window.activeIndex === idx) {
            window.activeIndex = null;
            const editorContent = document.getElementById('active-editor-content');
            if(editorContent) editorContent.style.display = 'none';
            const placeholder = document.getElementById('editor-placeholder');
            if(placeholder) placeholder.style.display = 'block';
            const tagsSection = document.getElementById('active-project-tags-section');
            if(tagsSection) tagsSection.style.display = 'none';
        } else if (window.activeType === type && window.activeIndex > idx) {
            window.activeIndex--;
        }
        
        if (type === 'conversation' && typeof renderConversations === 'function') renderConversations();
        if (type === 'sequence' && typeof renderSequences === 'function') renderSequences();
    }
}

function updateConvTitle(val) {
    if (window.activeIndex === null) return;
    const proj = window.getActiveProject();
    const oldName = proj.title;
    proj.title = val;
    proj.__isStarterProject = false;
    
    if (window.activeType === 'sequence' && oldName !== val) {
        const imgSeq = window.globalImageSequences.find(s => s.name === oldName);
        if (imgSeq) {
            imgSeq.name = val;
            propagateImageSeqRename(oldName, val);
            if (typeof renderImageSequences === 'function') renderImageSequences();
        }
    }
    
    if (window.activeType === 'conversation' && typeof renderConversations === 'function') renderConversations();
    else if (typeof renderSequences === 'function') renderSequences();
    if (typeof markWorkspaceDirty === 'function') markWorkspaceDirty();
}

function updateConvColor(val) {
    if (window.activeIndex === null) return;
    const proj = window.getActiveProject();
    proj.color = val;
    proj.__isStarterProject = false;
    
    if (window.activeType === 'sequence') {
        const imgSeq = window.globalImageSequences.find(s => s.name === proj.title);
        if (imgSeq) {
            imgSeq.color = val;
            if (typeof renderImageSequences === 'function') renderImageSequences();
        }
        if (typeof renderSequences === 'function') renderSequences();
    } else {
        if (typeof renderConversations === 'function') renderConversations();
    }
    
    if (typeof renderNodes === 'function') renderNodes();
}

function updateRepeatStatus(checked) {
    if (window.activeIndex === null) return;
    window.getActiveProject().isRepeatable = checked;
    const container = document.getElementById('repeat-variable-container');
    if (container) container.style.display = checked ? 'flex' : 'none';
    if (window.activeType === 'conversation' && typeof renderConversations === 'function') renderConversations();
    else if (typeof renderSequences === 'function') renderSequences();
}

function updateRepeatVariable(val) {
    if (window.activeIndex === null) return;
    window.getActiveProject().repeatVariable = val;
}


function setActiveProjectKind(targetType) {
    if (targetType !== 'conversation' && targetType !== 'sequence') return;
    if (window.activeIndex === null || window.activeIndex === undefined) return;
    if (window.activeType === targetType) {
        if (typeof updateProjectKindSwitch === 'function') updateProjectKindSwitch();
        return;
    }

    const sourceType = window.activeType;
    const sourceList = sourceType === 'conversation' ? window.conversations : window.sequences;
    const targetList = targetType === 'conversation' ? window.conversations : window.sequences;
    const project = sourceList[window.activeIndex];
    if (!project) return;

    sourceList.splice(window.activeIndex, 1);

    if (sourceType === 'sequence' && targetType === 'conversation') {
        (project.nodes || []).forEach(n => {
            if (n.sequenceName === project.title || n.controlSequence) {
                n.controlSequence = false;
                n.sequenceName = '';
                n.sequenceImage = '';
            }
            (n.responses || []).forEach(r => {
                if (r.sequenceName === project.title || r.controlSequence) {
                    r.controlSequence = false;
                    r.sequenceName = '';
                    r.sequenceImage = '';
                }
            });
        });
    }

    if (sourceType === 'conversation' && targetType === 'sequence') {
        if (!window.globalImageSequences.some(s => s.name === project.title)) {
            window.globalImageSequences.push({
                name: project.title,
                color: project.color || window.getRandomColor(),
                path: 'Assets/2D/Sequences/',
                images: []
            });
        }
        if (!Array.isArray(project.nodes)) project.nodes = [];
        if (project.nodes.length === 0) project.nodes.push(getEmptyNode(project.participants[0] || ''));
        project.nodes[0].controlSequence = true;
        project.nodes[0].sequenceName = project.title;
        const imgSeq = window.globalImageSequences.find(s => s.name === project.title);
        if (imgSeq && Array.isArray(imgSeq.images) && imgSeq.images.length > 0) project.nodes[0].sequenceImage = imgSeq.images[0];
    }

    targetList.push(project);
    window.activeType = targetType;
    window.activeIndex = targetList.length - 1;

    if (typeof renderConversations === 'function') renderConversations();
    if (typeof renderSequences === 'function') renderSequences();
    if (typeof renderImageSequences === 'function') renderImageSequences();
    if (typeof openEditor === 'function') openEditor(window.activeIndex, window.activeType);
    if (typeof markWorkspaceDirty === 'function') markWorkspaceDirty();
    if (typeof showNotification === 'function') showNotification(`Moved project to ${targetType === 'sequence' ? 'Sequences' : 'Conversations'}.`);
}

// --- GLOBAL ASSET CREATION & DELETION ---

function addGlobalToken() {
    const input = document.getElementById('new-token-key');
    const key = input.value.trim().replace(/[^a-zA-Z0-9_]/g, '');
    if (!key) return;
    if (window.globalTokens.some(t => t.key === key)) {
        if (typeof showNotification === 'function') showNotification("Token key already exists.", true);
        return;
    }
    window.globalTokens.push({ key, value: "Sample Value" });
    input.value = '';
    if (typeof renderTokens === 'function') renderTokens();
    if (typeof renderNodes === 'function') renderNodes();
}

function removeToken(idx) {
    window.globalTokens.splice(idx, 1);
    if (typeof renderTokens === 'function') renderTokens();
    if (typeof renderNodes === 'function') renderNodes();
}

function updateTokenValue(idx, val) {
    window.globalTokens[idx].value = val;
}

function saveTokenEdit(index) {
    const input = document.getElementById(`edit-token-key-${index}`);
    if (!input) return window.cancelEdit();
    
    const newKey = input.value.trim().replace(/[^a-zA-Z0-9_]/g, '');
    if (!newKey) return window.cancelEdit();

    if (window.globalTokens[index].key !== newKey && window.globalTokens.some(t => t.key === newKey)) {
        if (typeof showNotification === 'function') showNotification("Token key already exists.", true);
        return window.cancelEdit();
    }

    const oldKey = window.globalTokens[index].key;
    if (oldKey !== newKey) propagateTokenRename(oldKey, newKey);

    window.globalTokens[index].key = newKey;
    if (typeof cancelEdit === 'function') cancelEdit();
    if (typeof renderNodes === 'function') renderNodes();
}

function addNewImageSequence() {
    const input = document.getElementById('custom-image-seq-name');
    const colorInput = document.getElementById('custom-image-seq-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : window.getRandomColor();

    if (!name || window.globalImageSequences.some(s => s.name === name)) return;
    window.globalImageSequences.push({ name, color, path: 'Assets/2D/Sequences/', images: [] });
    
    if (!window.sequences.some(s => s.title === name)) {
        window.sequences.push({
            id: crypto.randomUUID(), title: name, color: color, participants: [], nodes: [],
            isRepeatable: false, repeatVariable: ''
        });
        if (typeof renderSequences === 'function') renderSequences();
    }
    
    if (typeof renderImageSequences === 'function') renderImageSequences();
    if (typeof renderNodes === 'function') renderNodes();
    input.value = '';
    if (typeof randomizePickerColors === 'function') randomizePickerColors();
}

function regenerateSequenceProject(seqName) {
    if (window.sequences.some(s => s.title === seqName)) return; 
    const imgSeq = window.globalImageSequences.find(s => s.name === seqName);
    if (!imgSeq) return;
    
    const seqProj = {
        id: crypto.randomUUID(),
        title: seqName,
        color: imgSeq.color,
        participants: [],
        nodes: [],
        isRepeatable: false,
        repeatVariable: ''
    };
    seqProj.nodes.push(getEmptyNode());
    window.sequences.push(seqProj);
    
    seqProj.nodes[0].controlSequence = true;
    seqProj.nodes[0].sequenceName = seqName;
    if (imgSeq && imgSeq.images.length > 0) {
        seqProj.nodes[0].sequenceImage = imgSeq.images[0];
    }

    if (typeof renderSequences === 'function') renderSequences();
    if (typeof renderImageSequences === 'function') renderImageSequences(); 
    if (typeof showNotification === 'function') showNotification(`Generated Sequence Project for '${seqName}'`);
}

function saveImageSeqEdit(index) {
    const newName = document.getElementById(`edit-imgseq-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-imgseq-color-${index}`).value;
    if (!newName) return window.cancelEdit();
    if (window.globalImageSequences[index].name !== newName && window.globalImageSequences.some(s => s.name === newName)) return window.cancelEdit();

    const oldName = window.globalImageSequences[index].name;
    window.globalImageSequences[index].name = newName;
    window.globalImageSequences[index].color = newColor;

    if (oldName !== newName) {
        if (window.openImageSeqs.has(oldName)) {
            window.openImageSeqs.delete(oldName);
            window.openImageSeqs.add(newName);
        }
        propagateImageSeqRename(oldName, newName);
        const seq = window.sequences.find(s => s.title === oldName);
        if (seq) {
            seq.title = newName;
            seq.color = newColor;
            if (window.activeType === 'sequence' && window.sequences[window.activeIndex] === seq) {
                const editConvName = document.getElementById('edit-conv-name');
                const editConvColor = document.getElementById('edit-conv-color');
                if (editConvName) editConvName.value = newName;
                if (editConvColor) editConvColor.value = newColor;
            }
        }
    } else {
        const seq = window.sequences.find(s => s.title === oldName);
        if (seq) {
            seq.color = newColor;
            if (window.activeType === 'sequence' && window.sequences[window.activeIndex] === seq) {
                const editConvColor = document.getElementById('edit-conv-color');
                if (editConvColor) editConvColor.value = newColor;
            }
        }
    }
    
    if (typeof cancelEdit === 'function') cancelEdit();
    if (typeof renderSequences === 'function') renderSequences();
    if (typeof renderImageSequences === 'function') renderImageSequences();
    if (typeof renderNodes === 'function') renderNodes();
}

function updateImageSeqPath(index, val) {
    window.globalImageSequences[index].path = val;
}

function saveImageEdit(seqIndex, imgIndex) {
    const newName = document.getElementById(`edit-img-name-${seqIndex}-${imgIndex}`).value.trim();
    if (!newName) return window.cancelEdit();
    
    const seq = window.globalImageSequences[seqIndex];
    const oldName = seq.images[imgIndex];
    if (oldName !== newName && seq.images.includes(newName)) return window.cancelEdit();
    
    seq.images[imgIndex] = newName;
    if (oldName !== newName) propagateImageRename(seq.name, oldName, newName);
    
    if (typeof cancelEdit === 'function') cancelEdit();
    if (typeof renderImageSequences === 'function') renderImageSequences();
    if (typeof renderNodes === 'function') renderNodes();
}

function deleteImageSequence(idx) {
    if (confirm("Delete this entire Image Sequence?")) {
        const seqName = window.globalImageSequences[idx].name;
        window.openImageSeqs.delete(seqName);
        window.globalImageSequences.splice(idx, 1);
        if (typeof renderImageSequences === 'function') renderImageSequences();
        if (typeof renderNodes === 'function') renderNodes();
    }
}

function deleteImageFromSequence(seqIdx, imgIdx) {
    window.globalImageSequences[seqIdx].images.splice(imgIdx, 1);
    if (typeof renderImageSequences === 'function') renderImageSequences();
    if (typeof renderNodes === 'function') renderNodes();
}

function sortImageSequence(seqIndex) {
    window.globalImageSequences[seqIndex].images.sort(new Intl.Collator('en', { numeric: true, sensitivity: 'base' }).compare);
    if (typeof renderImageSequences === 'function') renderImageSequences();
    if (typeof renderNodes === 'function') renderNodes();
}

function clearImageSequence(seqIndex) {
    if (confirm("Clear all images from this sequence?")) {
        window.globalImageSequences[seqIndex].images = [];
        if (typeof renderImageSequences === 'function') renderImageSequences();
        if (typeof renderNodes === 'function') renderNodes();
    }
}

function addNewCustomParticipant() {
    const nameInput = document.getElementById('custom-participant-name');
    const colorInput = document.getElementById('custom-participant-color');
    const name = nameInput.value.trim();
    const color = colorInput ? colorInput.value : window.getRandomColor();

    if (!name || window.cast.some(c => c.name === name)) return;
    window.cast.push({ name, color });
    if (typeof renderCast === 'function') renderCast();
    if (typeof updateLocalAddDropdown === 'function') updateLocalAddDropdown();
    nameInput.value = '';
    if (typeof randomizePickerColors === 'function') randomizePickerColors();
}

function removeGlobalChar(index) {
    window.cast.splice(index, 1);
    if (typeof renderCast === 'function') renderCast();
    if (typeof updateLocalAddDropdown === 'function') updateLocalAddDropdown();
}

function saveCastEdit(index) {
    const newName = document.getElementById(`edit-cast-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-cast-color-${index}`).value;
    if (!newName) return window.cancelEdit();
    if (window.cast[index].name !== newName && window.cast.some(c => c.name === newName)) return window.cancelEdit();

    const oldName = window.cast[index].name;
    if (oldName !== newName) propagateCastRename(oldName, newName);
    
    window.cast[index].name = newName;
    window.cast[index].color = newColor;
    
    if (typeof cancelEdit === 'function') cancelEdit();
    if (typeof renderLocalCast === 'function') renderLocalCast();
    if (typeof updateLocalAddDropdown === 'function') updateLocalAddDropdown();
    if (typeof renderNodes === 'function') renderNodes();
    if (typeof renderConversations === 'function') renderConversations();
    if (typeof renderSequences === 'function') renderSequences();
}

function addNewState() {
    const input = document.getElementById('custom-state-name');
    const colorInput = document.getElementById('custom-state-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : window.getRandomColor();
    if (!name || window.globalStates.some(s => s.name === name)) return;
    window.globalStates.push({ name, color });
    if (typeof renderStates === 'function') renderStates();
    if (typeof renderNodes === 'function') renderNodes(); 
    input.value = '';
    if (typeof randomizePickerColors === 'function') randomizePickerColors();
}

function removeGlobalState(index) {
    window.globalStates.splice(index, 1);
    if (typeof renderStates === 'function') renderStates();
    if (typeof renderNodes === 'function') renderNodes();
}

function saveStateEdit(index) {
    const newName = document.getElementById(`edit-state-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-state-color-${index}`).value;
    if (!newName) return window.cancelEdit();
    if (window.globalStates[index].name !== newName && window.globalStates.some(s => s.name === newName)) return window.cancelEdit();
    const oldName = window.globalStates[index].name;
    if (oldName !== newName) propagateStateRename(oldName, newName);
    window.globalStates[index].name = newName;
    window.globalStates[index].color = newColor;
    if (typeof cancelEdit === 'function') cancelEdit();
    if (typeof renderNodes === 'function') renderNodes();
}

function addNewMood() {
    const input = document.getElementById('custom-mood-name');
    const colorInput = document.getElementById('custom-mood-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : window.getRandomColor();
    if (!name || window.globalMoods.some(m => m.name === name)) return;
    window.globalMoods.push({ name, color });
    if (typeof renderMoods === 'function') renderMoods();
    if (typeof renderNodes === 'function') renderNodes();
    input.value = '';
    if (typeof randomizePickerColors === 'function') randomizePickerColors();
}

function removeGlobalMood(index) {
    window.globalMoods.splice(index, 1);
    if (typeof renderMoods === 'function') renderMoods();
    if (typeof renderNodes === 'function') renderNodes();
}

function saveMoodEdit(index) {
    const newName = document.getElementById(`edit-mood-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-mood-color-${index}`).value;
    if (!newName) return window.cancelEdit();
    if (window.globalMoods[index].name !== newName && window.globalMoods.some(m => m.name === newName)) return window.cancelEdit();
    const oldName = window.globalMoods[index].name;
    if (oldName !== newName) propagateMoodRename(oldName, newName);
    window.globalMoods[index].name = newName;
    window.globalMoods[index].color = newColor;
    if (typeof cancelEdit === 'function') cancelEdit();
    if (typeof renderNodes === 'function') renderNodes();
}

function addNewSetting() {
    const input = document.getElementById('custom-setting-name');
    const colorInput = document.getElementById('custom-setting-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : window.getRandomColor();
    if (!name || window.globalSettings.some(s => s.name === name)) return;
    window.globalSettings.push({ name, color });
    if (typeof renderSettings === 'function') renderSettings();
    if (typeof renderNodes === 'function') renderNodes();
    input.value = '';
    if (typeof randomizePickerColors === 'function') randomizePickerColors();
}

function removeGlobalSetting(index) {
    window.globalSettings.splice(index, 1);
    if (typeof renderSettings === 'function') renderSettings();
    if (typeof renderNodes === 'function') renderNodes();
}

function saveSettingEdit(index) {
    const newName = document.getElementById(`edit-setting-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-setting-color-${index}`).value;
    if (!newName) return window.cancelEdit();
    if (window.globalSettings[index].name !== newName && window.globalSettings.some(s => s.name === newName)) return window.cancelEdit();
    const oldName = window.globalSettings[index].name;
    if (oldName !== newName) propagateSettingRename(oldName, newName);
    window.globalSettings[index].name = newName;
    window.globalSettings[index].color = newColor;
    if (typeof cancelEdit === 'function') cancelEdit();
    if (typeof renderNodes === 'function') renderNodes();
}

function addNewTimeOfDay() {
    const input = document.getElementById('custom-time-name');
    const colorInput = document.getElementById('custom-time-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : window.getRandomColor();
    if (!name || window.globalTimesOfDay.some(s => s.name === name)) return;
    window.globalTimesOfDay.push({ name, color });
    if (typeof renderTimesOfDay === 'function') renderTimesOfDay();
    if (typeof renderNodes === 'function') renderNodes();
    input.value = '';
    if (typeof randomizePickerColors === 'function') randomizePickerColors();
}

function removeGlobalTimeOfDay(index) {
    window.globalTimesOfDay.splice(index, 1);
    if (typeof renderTimesOfDay === 'function') renderTimesOfDay();
    if (typeof renderNodes === 'function') renderNodes();
}

function saveTimeOfDayEdit(index) {
    const newName = document.getElementById(`edit-time-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-time-color-${index}`).value;
    if (!newName) return window.cancelEdit();
    if (window.globalTimesOfDay[index].name !== newName && window.globalTimesOfDay.some(s => s.name === newName)) return window.cancelEdit();
    const oldName = window.globalTimesOfDay[index].name;
    if (oldName !== newName) propagateTimeOfDayRename(oldName, newName);
    window.globalTimesOfDay[index].name = newName;
    window.globalTimesOfDay[index].color = newColor;
    if (typeof cancelEdit === 'function') cancelEdit();
    if (typeof renderNodes === 'function') renderNodes();
}

function addNewDayOfWeek() {
    const input = document.getElementById('custom-day-name');
    const colorInput = document.getElementById('custom-day-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : window.getRandomColor();
    if (!name || window.globalDaysOfWeek.some(s => s.name === name)) return;
    window.globalDaysOfWeek.push({ name, color });
    if (typeof renderDaysOfWeek === 'function') renderDaysOfWeek();
    if (typeof renderNodes === 'function') renderNodes();
    input.value = '';
    if (typeof randomizePickerColors === 'function') randomizePickerColors();
}

function removeGlobalDayOfWeek(index) {
    window.globalDaysOfWeek.splice(index, 1);
    if (typeof renderDaysOfWeek === 'function') renderDaysOfWeek();
    if (typeof renderNodes === 'function') renderNodes();
}

function saveDayOfWeekEdit(index) {
    const newName = document.getElementById(`edit-day-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-day-color-${index}`).value;
    if (!newName) return window.cancelEdit();
    if (window.globalDaysOfWeek[index].name !== newName && window.globalDaysOfWeek.some(s => s.name === newName)) return window.cancelEdit();
    const oldName = window.globalDaysOfWeek[index].name;
    if (oldName !== newName) propagateDayOfWeekRename(oldName, newName);
    window.globalDaysOfWeek[index].name = newName;
    window.globalDaysOfWeek[index].color = newColor;
    if (typeof cancelEdit === 'function') cancelEdit();
    if (typeof renderNodes === 'function') renderNodes();
}

function addNewMenuOption() {
    const input = document.getElementById('custom-menu-name');
    const colorInput = document.getElementById('custom-menu-color');
    const name = input.value.trim();
    const color = colorInput ? colorInput.value : window.getRandomColor();
    if (!name || window.globalMenuOptions.some(s => s.name === name)) return;
    window.globalMenuOptions.push({ name, color });
    if (typeof renderMenuOptions === 'function') renderMenuOptions();
    if (typeof renderNodes === 'function') renderNodes();
    input.value = '';
    if (typeof randomizePickerColors === 'function') randomizePickerColors();
}

function removeGlobalMenuOption(index) {
    window.globalMenuOptions.splice(index, 1);
    if (typeof renderMenuOptions === 'function') renderMenuOptions();
    if (typeof renderNodes === 'function') renderNodes();
}

function saveMenuOptionEdit(index) {
    const newName = document.getElementById(`edit-menu-name-${index}`).value.trim();
    const newColor = document.getElementById(`edit-menu-color-${index}`).value;
    if (!newName) return window.cancelEdit();
    if (window.globalMenuOptions[index].name !== newName && window.globalMenuOptions.some(s => s.name === newName)) return window.cancelEdit();
    const oldName = window.globalMenuOptions[index].name;
    if (oldName !== newName) propagateMenuOptionRename(oldName, newName);
    window.globalMenuOptions[index].name = newName;
    window.globalMenuOptions[index].color = newColor;
    if (typeof cancelEdit === 'function') cancelEdit();
    if (typeof renderNodes === 'function') renderNodes();
}

// --- LINKING MODAL & LOGIC ---
function openLinkSequenceModal(seqName) {
    const modal = document.getElementById('link-sequence-modal');
    const select = document.getElementById('link-node-select');
    document.getElementById('linking-seq-name-display').textContent = seqName;
    document.getElementById('linking-seq-name').value = seqName;
    
    let optionsHtml = '<option value="">-- Select Target Project --</option>';
    
    const buildOptions = (projects, typeKey, sectionName) => {
        if (projects.length === 0) return '';
        let html = `<optgroup label="${sectionName}">`;
        projects.forEach((proj, pIdx) => {
            if(proj.nodes.length === 0) return;
            const nodeIdShort = proj.nodes[0].id.substring(proj.nodes[0].id.length - 6);
            const currentLink = proj.nodes.some(n => n.sequenceName === seqName) ? ' (LINKED IN PROJECT)' : '';
            html += `<option value="${typeKey}|${pIdx}">${escapeHtml(proj.title)} - [${nodeIdShort}]${currentLink}</option>`;
        });
        html += `</optgroup>`;
        return html;
    };

    optionsHtml += buildOptions(window.conversations, 'conv', 'Conversations');
    optionsHtml += buildOptions(window.sequences, 'seq', 'Sequences');
    
    select.innerHTML = optionsHtml;
    modal.style.display = 'flex';
}

function closeLinkSequenceModal() {
    document.getElementById('link-sequence-modal').style.display = 'none';
}

function applySequenceLink() {
    const seqName = document.getElementById('linking-seq-name').value;
    const val = document.getElementById('link-node-select').value;
    
    if (!val) {
        if (typeof showNotification === 'function') showNotification("No target project selected.", true);
        return;
    }

    const [typeKey, pIdxStr] = val.split('|');
    const pIdx = parseInt(pIdxStr);

    const targetList = typeKey === 'conv' ? window.conversations : window.sequences;
    const targetProj = targetList[pIdx];

    if (targetProj.nodes.length === 0) {
        targetProj.nodes.push(getEmptyNode());
    }
    const targetNode = targetProj.nodes[0];

    if (targetNode.controlSequence && targetNode.sequenceName && targetNode.sequenceName !== seqName) {
        if (!confirm(`This project is already linked to Image Sequence '${targetNode.sequenceName}'. Overwrite?`)) {
            return;
        }
    }

    [...window.conversations, ...window.sequences].forEach(proj => {
        proj.nodes.forEach((node, pNIdx) => {
            if (node.sequenceName === seqName) {
                node.controlSequence = false;
                node.sequenceName = '';
                node.sequenceImage = '';
                if (window.activeIndex !== null && window.getActiveProject() === proj) {
                    if (typeof markNodeEdited === 'function') markNodeEdited(pNIdx);
                }
            }
        });
    });

    targetNode.controlSequence = true;
    targetNode.sequenceName = seqName;
    const imgSeq = window.globalImageSequences.find(s => s.name === seqName);
    if (imgSeq && imgSeq.images.length > 0) {
        targetNode.sequenceImage = imgSeq.images[0];
    }

    closeLinkSequenceModal();
    if (typeof showNotification === 'function') showNotification(`Sequence successfully linked to ${targetProj.title}`);
    
    if (typeof renderImageSequences === 'function') renderImageSequences();
    if ((window.activeType === 'conversation' && typeKey === 'conv' && window.activeIndex === pIdx) ||
        (window.activeType === 'sequence' && typeKey === 'seq' && window.activeIndex === pIdx)) {
        if (typeof markNodeEdited === 'function') markNodeEdited(0);
        if (typeof renderNodes === 'function') renderNodes();
    }
}

function unlinkSequenceCompletely(passedSeqName = null) {
    const seqName = passedSeqName || document.getElementById('linking-seq-name').value;
    
    [...window.conversations, ...window.sequences].forEach(proj => {
        proj.nodes.forEach((node, nIdx) => {
            if (node.sequenceName === seqName) {
                node.controlSequence = false;
                node.sequenceName = '';
                node.sequenceImage = '';
                if (window.activeIndex !== null && window.getActiveProject() === proj) {
                    if (typeof markNodeEdited === 'function') markNodeEdited(nIdx);
                }
            }
        });
    });
    
    closeLinkSequenceModal();
    if (typeof showNotification === 'function') showNotification(`Unlinked all associations for ${seqName}`);
    if (typeof renderImageSequences === 'function') renderImageSequences();
    if (typeof renderNodes === 'function') renderNodes();
}

function propagateTokenRename(oldKey, newKey) {
    const oldTag = `{{${oldKey}}}`;
    const newTag = `{{${newKey}}}`;
    [...window.conversations, ...window.sequences].forEach(proj => {
        proj.nodes.forEach(node => {
            if (node.text && node.text.includes(oldTag)) node.text = node.text.split(oldTag).join(newTag);
            (node.responses || []).forEach(r => {
                if (r.text && r.text.includes(oldTag)) r.text = r.text.split(oldTag).join(newTag);
            });
        });
    });
}

function propagateCastRename(oldName, newName) {
    [...window.conversations, ...window.sequences].forEach(proj => {
        const pIdx = proj.participants.indexOf(oldName);
        if (pIdx !== -1) proj.participants[pIdx] = newName;
        proj.nodes.forEach(node => {
            if (node.speaker === oldName) node.speaker = newName;
            node.responses.forEach(r => { if (r.speaker === oldName) r.speaker = newName; });
            node.puppets.forEach(p => { if (p.name === oldName) p.name = newName; });
        });
    });
}

function propagateStateRename(oldName, newName) {
    [...window.conversations, ...window.sequences].forEach(proj => {
        proj.nodes.forEach(node => { node.puppets.forEach(p => { if (p.state === oldName) p.state = newName; }); });
    });
}

function propagateMoodRename(oldName, newName) {
    [...window.conversations, ...window.sequences].forEach(proj => {
        proj.nodes.forEach(node => { node.puppets.forEach(p => { if (p.mood === oldName) p.mood = newName; }); });
    });
}

function propagateSettingRename(oldName, newName) {
    [...window.conversations, ...window.sequences].forEach(proj => {
        proj.nodes.forEach(node => { (node.settingChanges || []).forEach(change => { if (change.setting === oldName) change.setting = newName; }); });
    });
}

function propagateTimeOfDayRename(oldName, newName) {
    [...window.conversations, ...window.sequences].forEach(proj => {
        proj.nodes.forEach(node => { (node.timeOfDayChanges || []).forEach(change => { if (change.time === oldName) change.time = newName; }); });
    });
}

function propagateDayOfWeekRename(oldName, newName) {
    [...window.conversations, ...window.sequences].forEach(proj => {
        proj.nodes.forEach(node => { (node.dayOfWeekChanges || []).forEach(change => { if (change.day === oldName) change.day = newName; }); });
    });
}

function propagateMenuOptionRename(oldName, newName) {
    [...window.conversations, ...window.sequences].forEach(proj => {
        proj.nodes.forEach(node => { (node.menuOptionChanges || []).forEach(change => { if (change.menu === oldName) change.menu = newName; }); });
    });
}

function propagateImageSeqRename(oldName, newName) {
    [...window.conversations, ...window.sequences].forEach(proj => {
        proj.nodes.forEach(node => { if (node.sequenceName === oldName) node.sequenceName = newName; });
    });
}

function propagateImageRename(seqName, oldImgName, newImgName) {
    [...window.conversations, ...window.sequences].forEach(proj => {
        proj.nodes.forEach(node => { if (node.sequenceName === seqName && node.sequenceImage === oldImgName) node.sequenceImage = newImgName; });
    });
}

// --- NODE MANAGEMENT ---
function addCharToLocal(name) {
    if (!name || window.activeIndex === null) return;
    const project = window.getActiveProject();
    project.__isStarterProject = false;
    project.participants.push(name);
    if (typeof renderLocalCast === 'function') renderLocalCast();
    if (typeof renderNodes === 'function') renderNodes();
    if (window.activeType === 'conversation' && typeof renderConversations === 'function') renderConversations();
    else if (typeof renderSequences === 'function') renderSequences();
    if (typeof markWorkspaceDirty === 'function') markWorkspaceDirty();
}

function removeCharFromLocal(name) {
    const project = window.getActiveProject();
    project.participants = project.participants.filter(p => p !== name);
    if (typeof renderLocalCast === 'function') renderLocalCast();
    if (typeof renderNodes === 'function') renderNodes();
    if (typeof markWorkspaceDirty === 'function') markWorkspaceDirty();
}

function handleNodeExclusivity(nIdx, checkedKey, uncheckedKey, isChecked) {
    const node = window.getActiveProject().nodes[nIdx];
    node[checkedKey] = isChecked;
    if (isChecked) node[uncheckedKey] = false;
    if (typeof markNodeEdited === 'function') markNodeEdited(nIdx);
    if (typeof renderNodes === 'function') renderNodes();
}

function addDialogueNode(sourceResponseId = null, previewText = null, insertIndex = null) {
    if (window.activeIndex === null) return;
    const project = window.getActiveProject();
    const newNode = getEmptyNode(project.participants[0] || '');
    newNode.parentResponseId = sourceResponseId;
    newNode.parentResponsePreview = previewText;
    
    project.__isStarterProject = false;
    if (insertIndex !== null) project.nodes.splice(insertIndex, 0, newNode);
    else project.nodes.push(newNode);
    ensureTextTranslationsForEntry(newNode);
    
    if (typeof renderNodes === 'function') renderNodes();
    return newNode.id;
}

function deleteNode(nodeIdx) {
    const project = window.getActiveProject();
    const nodeToDelete = project.nodes[nodeIdx];
    
    project.nodes.forEach(n => {
        n.responses.forEach(r => {
            if (r.nextStatementId === nodeToDelete.id || r.id === nodeToDelete.parentResponseId) r.nextStatementId = null;
        });
    });

    project.nodes.splice(nodeIdx, 1);
    if (typeof renderNodes === 'function') renderNodes();
}

function moveNode(fromIdx, toIdx) {
    if (window.activeIndex === null || fromIdx === toIdx) return;
    const project = window.getActiveProject();
    const nodeToMove = project.nodes.splice(fromIdx, 1)[0];
    project.nodes.splice(toIdx, 0, nodeToMove);
    if (typeof renderNodes === 'function') renderNodes();
    setTimeout(() => {
        if (typeof scrollToElement === 'function') scrollToElement(`node-${nodeToMove.id}`);
    }, 50);
}

// --- TRANSLATION SUPPORT API ---
function updateNodeText(nIdx, val) { 
    const p = window.getActiveProject();
    if (!p || !p.nodes || !p.nodes[nIdx]) return;
    setLocalizedText(p.nodes[nIdx], val, window.currentLanguage);
    if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); 
}

function updateResponseText(nIdx, rIdx, val) { 
    const p = window.getActiveProject();
    if (!p || !p.nodes || !p.nodes[nIdx] || !p.nodes[nIdx].responses || !p.nodes[nIdx].responses[rIdx]) return;
    setLocalizedText(p.nodes[nIdx].responses[rIdx], val, window.currentLanguage);
    if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); 
}

function toggleAddLanguage() {
    window.isAddingLanguage = !window.isAddingLanguage;
    if (typeof renderNodes === 'function') renderNodes();
}

function confirmAddLanguage() {
    const input = document.getElementById('new-lang-code');
    const val = input.value.trim().toUpperCase();
    if (val.length === 3 && !window.availableLanguages.includes(val)) {
        window.availableLanguages.push(val);
        window.currentLanguage = val;
        window.isAddingLanguage = false;
        ensureAllTranslationContainers();
        if (typeof renderNodes === 'function') renderNodes();
    } else {
        safeShowNotification("Invalid Language Code. Use exactly 3 characters.", true);
    }
}

// --- PUPPET & STATE MODIFIERS ---
function toggleControlPuppets(nIdx, isChecked) { window.getActiveProject().nodes[nIdx].controlPuppets = isChecked; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function addPuppetToNode(nIdx, charName) {
    if(!charName) return;
    const node = window.getActiveProject().nodes[nIdx];
    if (!node.puppets.some(p => p.name === charName)) {
        node.puppets.push({ name: charName, enabled: true, position: '', path: 'Assets/Resources/Puppets/', state: '', mood: '', invert: false });
        if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes();
    }
}
function removePuppetFromNode(nIdx, pIdx) { window.getActiveProject().nodes[nIdx].puppets.splice(pIdx, 1); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function togglePuppetEnabled(nIdx, pIdx, isChecked) { window.getActiveProject().nodes[nIdx].puppets[pIdx].enabled = isChecked; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function updatePuppetPosition(nIdx, pIdx, val) { window.getActiveProject().nodes[nIdx].puppets[pIdx].position = val; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); }
function toggleChangePuppetState(nIdx, isChecked) { window.getActiveProject().nodes[nIdx].changePuppetState = isChecked; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function togglePuppetUseTag(nIdx, isChecked) {
    const node = window.getActiveProject().nodes[nIdx];
    node.puppetUseTag = isChecked;
    if (isChecked) node.puppetUsePath = false;
    if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes();
}
function togglePuppetUsePath(nIdx, isChecked) {
    const node = window.getActiveProject().nodes[nIdx];
    node.puppetUsePath = isChecked;
    if (isChecked) node.puppetUseTag = false;
    if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes();
}
function toggleChangePuppetMood(nIdx, isChecked) { window.getActiveProject().nodes[nIdx].changePuppetMood = isChecked; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function toggleChangePuppetInvert(nIdx, isChecked) { window.getActiveProject().nodes[nIdx].changePuppetInvert = isChecked; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function updatePuppetPath(nIdx, pIdx, val) { window.getActiveProject().nodes[nIdx].puppets[pIdx].path = val; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); }
function updatePuppetState(nIdx, pIdx, val) { window.getActiveProject().nodes[nIdx].puppets[pIdx].state = val; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); }
function updatePuppetMood(nIdx, pIdx, val) { window.getActiveProject().nodes[nIdx].puppets[pIdx].mood = val; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); }
function updatePuppetInvert(nIdx, pIdx, isChecked) { window.getActiveProject().nodes[nIdx].puppets[pIdx].invert = isChecked; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); }

function addConditionRow(nIdx) { window.getActiveProject().nodes[nIdx].conditions.push({ variable: '', operator: '==', value: '' }); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function removeConditionRow(nIdx, cIdx) { window.getActiveProject().nodes[nIdx].conditions.splice(cIdx, 1); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function updateCondition(nIdx, cIdx, field, val) { window.getActiveProject().nodes[nIdx].conditions[cIdx][field] = val; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderProjectTags === 'function') renderProjectTags(); if (typeof updateNodeGlows === 'function') updateNodeGlows(); }
function addTimeChangeRow(nIdx) { window.getActiveProject().nodes[nIdx].timeOfDayChanges.push({ time: '', value: '' }); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function removeTimeChangeRow(nIdx, cIdx) { window.getActiveProject().nodes[nIdx].timeOfDayChanges.splice(cIdx, 1); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function updateTimeChange(nIdx, cIdx, field, val) { window.getActiveProject().nodes[nIdx].timeOfDayChanges[cIdx][field] = val; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); }
function addDayChangeRow(nIdx) { window.getActiveProject().nodes[nIdx].dayOfWeekChanges.push({ day: '', value: '' }); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function removeDayChangeRow(nIdx, cIdx) { window.getActiveProject().nodes[nIdx].dayOfWeekChanges.splice(cIdx, 1); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function updateDayChange(nIdx, cIdx, field, val) { window.getActiveProject().nodes[nIdx].dayOfWeekChanges[cIdx][field] = val; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); }
function addMenuChangeRow(nIdx) { window.getActiveProject().nodes[nIdx].menuOptionChanges.push({ menu: '', value: '' }); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function removeMenuChangeRow(nIdx, cIdx) { window.getActiveProject().nodes[nIdx].menuOptionChanges.splice(cIdx, 1); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function updateMenuChange(nIdx, cIdx, field, val) { window.getActiveProject().nodes[nIdx].menuOptionChanges[cIdx][field] = val; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); }
function addStateChangeRow(nIdx) { window.getActiveProject().nodes[nIdx].gameStateChanges.push({ variable: '', operator: '==', value: '' }); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function removeStateChangeRow(nIdx, cIdx) { window.getActiveProject().nodes[nIdx].gameStateChanges.splice(cIdx, 1); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function updateStateChange(nIdx, cIdx, field, val) { window.getActiveProject().nodes[nIdx].gameStateChanges[cIdx][field] = val; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderProjectTags === 'function') renderProjectTags(); if (typeof updateNodeGlows === 'function') updateNodeGlows(); }
function addSettingChangeRow(nIdx) { window.getActiveProject().nodes[nIdx].settingChanges.push({ setting: '', value: '' }); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function removeSettingChangeRow(nIdx, cIdx) { window.getActiveProject().nodes[nIdx].settingChanges.splice(cIdx, 1); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function updateSettingChange(nIdx, cIdx, field, val) { window.getActiveProject().nodes[nIdx].settingChanges[cIdx][field] = val; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); }

function linkExistingStatement(nodeIndex, responseIndex, targetNodeId) {
    if (!targetNodeId) return;
    const project = window.getActiveProject();
    const response = project.nodes[nodeIndex].responses[responseIndex];
    const targetNode = project.nodes.find(n => n.id === targetNodeId);
    if (targetNode) {
        response.nextStatementId = targetNodeId;
        if (typeof markNodeEdited === 'function') markNodeEdited(nodeIndex);
        if (typeof renderNodes === 'function') renderNodes();
    }
}

function establishReverseReply(nIdx) {
    const project = window.getActiveProject();
    const currentNode = project.nodes[nIdx];
    const selectEl = document.getElementById(`reverse-link-select-${nIdx}`);
    if (!selectEl) return;
    
    const parentNodeId = selectEl.value;
    if (!parentNodeId) return;

    const parentNode = project.nodes.find(n => n.id === parentNodeId);
    if (!parentNode) return;
    if ((parentNode.responses || []).length >= 4) {
        safeShowNotification("Target statement already has 4 responses.", true);
        return;
    }

    parentNode.canPlayerRespond = true;
    const newResponseId = crypto.randomUUID();
    const responseSpeaker = project.participants[0] || '';
    
    const reverseResponse = {
        id: newResponseId, speaker: responseSpeaker, text: 'Continue...', nextStatementId: currentNode.id,
        voiceLine: false, externalCall: false, makeExternalCall: false, conditions: [], gameStateChanges: [], conditionsOpen: true, statesOpen: true, autoIncrement: false,
        textFormat: { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' }, translations: {}
    };
    ensureResponseAdvancedDefaults(reverseResponse);
    parentNode.responses.push(reverseResponse);

    if (typeof markNodeEdited === 'function') {
        markNodeEdited(nIdx);
        markNodeEdited(project.nodes.indexOf(parentNode));
    }
    if (typeof renderNodes === 'function') renderNodes();
}

function unlinkResponse(nIdx, rIdx) {
    if (window.activeIndex === null) return;
    const project = window.getActiveProject();
    if (project.nodes[nIdx] && project.nodes[nIdx].responses[rIdx]) {
        project.nodes[nIdx].responses[rIdx].nextStatementId = null;
        if (typeof markNodeEdited === 'function') markNodeEdited(nIdx);
        if (typeof renderNodes === 'function') renderNodes();
    }
}

function unlinkSpecificReverseReply(childNIdx, parentNodeId, responseId) {
    const project = window.getActiveProject();
    const parentNode = project.nodes.find(n => n.id === parentNodeId);
    if (parentNode) {
        const resp = parentNode.responses.find(r => r.id === responseId);
        if (resp) resp.nextStatementId = null;
    }
    if (typeof markNodeEdited === 'function') markNodeEdited(childNIdx);
    if (typeof renderNodes === 'function') renderNodes();
}

function applyResp(nIdx) {
    const node = window.getActiveProject().nodes[nIdx];
    if ((node.responses || []).length >= 4) {
        safeShowNotification("Maximum 4 responses allowed.", true);
        return;
    }
    const textInput = document.getElementById(`resp-input-${nIdx}`);
    const speakerSelect = document.getElementById(`resp-speaker-${nIdx}`);
    if (!textInput || !textInput.value.trim()) return;
    const response = { 
        id: crypto.randomUUID(), speaker: speakerSelect.value, text: '',
        nextStatementId: null, voiceLine: false, externalCall: false, makeExternalCall: false, conditions: [], gameStateChanges: [], conditionsOpen: true, statesOpen: true, autoIncrement: false,
        textFormat: JSON.parse(JSON.stringify(node.responseDraftFormat || { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' })), translations: {}
    };
    ensureResponseAdvancedDefaults(response);
    setLocalizedText(response, textInput.value, window.currentLanguage);
    node.responses.push(response);
    node.responseDraftFormat = { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
    node.responseDraftText = '';
    if (typeof markNodeEdited === 'function') markNodeEdited(nIdx);
    if (typeof renderNodes === 'function') renderNodes();
    textInput.value = '';
}

function createReplyStatement(nodeIndex, responseIndex) {
    const project = window.getActiveProject();
    const response = project.nodes[nodeIndex].responses[responseIndex];
    if (response.nextStatementId && project.nodes.some(n => n.id === response.nextStatementId)) return;
    
    const nodeText = getLocalizedText(response, window.currentLanguage);
    const preview = `${response.speaker}: ${nodeText.substring(0, 30)}${nodeText.length > 30 ? '...' : ''}`;
    const newNodeId = addDialogueNode(response.id, preview, nodeIndex + 1);
    response.nextStatementId = newNodeId;
    
    if (typeof markNodeEdited === 'function') markNodeEdited(nodeIndex);
    if (typeof renderNodes === 'function') renderNodes();
    setTimeout(() => {
        if (typeof scrollToElement === 'function') scrollToElement(`node-${newNodeId}`);
    }, 50);
}

function removeResponse(nIdx, rIdx) {
    if (window.activeIndex === null) return;
    const project = window.getActiveProject();
    const response = project.nodes[nIdx].responses[rIdx];
    
    if (response.nextStatementId) {
        const targetNode = project.nodes.find(n => n.id === response.nextStatementId);
        if (targetNode && targetNode.parentResponseId === response.id) {
            targetNode.parentResponseId = null;
            targetNode.parentResponsePreview = null;
        }
    }
    
    project.nodes[nIdx].responses.splice(rIdx, 1);
    if (typeof markNodeEdited === 'function') markNodeEdited(nIdx);
    if (typeof renderNodes === 'function') renderNodes();
}

function saveEditedResponse(nIdx, rIdx) {
    const input = document.getElementById(`edit-input-${nIdx}-${rIdx}`);
    const speakerSelect = document.getElementById(`edit-speaker-${nIdx}-${rIdx}`);
    
    if (input && speakerSelect) {
        const project = window.getActiveProject();
        updateResponseText(nIdx, rIdx, input.value.trim());
        project.nodes[nIdx].responses[rIdx].speaker = speakerSelect.value;
        
        const response = project.nodes[nIdx].responses[rIdx];
        if (response.nextStatementId) {
            const targetNode = project.nodes.find(n => n.id === response.nextStatementId);
            if (targetNode) {
                const updatedText = getLocalizedText(response, window.currentLanguage);
                targetNode.parentResponsePreview = `${response.speaker}: ${updatedText.substring(0, 30)}${updatedText.length > 30 ? '...' : ''}`;
            }
        }
    }
    window.editingResponseRef = null;
    if (typeof markNodeEdited === 'function') markNodeEdited(nIdx);
    if (typeof renderNodes === 'function') renderNodes();
}

function moveResponseUp(nIdx, rIdx) {
    if (window.activeIndex === null || rIdx <= 0) return;
    const project = window.getActiveProject();
    const responses = project.nodes[nIdx].responses;
    const temp = responses[rIdx - 1];
    responses[rIdx - 1] = responses[rIdx];
    responses[rIdx] = temp;
    if (typeof markNodeEdited === 'function') markNodeEdited(nIdx);
    if (typeof renderNodes === 'function') renderNodes();
}

function moveResponseDown(nIdx, rIdx) {
    if (window.activeIndex === null) return;
    const project = window.getActiveProject();
    const responses = project.nodes[nIdx].responses;
    if (rIdx >= responses.length - 1) return;
    const temp = responses[rIdx + 1];
    responses[rIdx + 1] = responses[rIdx];
    responses[rIdx] = temp;
    if (typeof markNodeEdited === 'function') markNodeEdited(nIdx);
    if (typeof renderNodes === 'function') renderNodes();
}

function toggleResponseAutoIncrement(nIdx, rIdx, isChecked) { window.getActiveProject().nodes[nIdx].responses[rIdx].autoIncrement = isChecked; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof updateResponseGlow === 'function') updateResponseGlow(nIdx, rIdx); }
function addResponseConditionRow(nIdx, rIdx) { const response = window.getActiveProject().nodes[nIdx].responses[rIdx]; response.conditionsOpen = true; response.conditions.push({ variable: '', operator: '==', value: '' }); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function removeResponseConditionRow(nIdx, rIdx, cIdx) { window.getActiveProject().nodes[nIdx].responses[rIdx].conditions.splice(cIdx, 1); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function updateResponseConditionRow(nIdx, rIdx, cIdx, field, val) { window.getActiveProject().nodes[nIdx].responses[rIdx].conditions[cIdx][field] = val; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderProjectTags === 'function') renderProjectTags(); if (typeof updateNodeGlows === 'function') updateNodeGlows(); }
function addResponseStateChangeRow(nIdx, rIdx) { const response = window.getActiveProject().nodes[nIdx].responses[rIdx]; response.statesOpen = true; response.gameStateChanges.push({ variable: '', operator: '=', value: '' }); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function removeResponseStateChangeRow(nIdx, rIdx, cIdx) { window.getActiveProject().nodes[nIdx].responses[rIdx].gameStateChanges.splice(cIdx, 1); if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderNodes === 'function') renderNodes(); }
function updateResponseStateChangeRow(nIdx, rIdx, cIdx, field, val) { window.getActiveProject().nodes[nIdx].responses[rIdx].gameStateChanges[cIdx][field] = val; if (typeof markNodeEdited === 'function') markNodeEdited(nIdx); if (typeof renderProjectTags === 'function') renderProjectTags(); if (typeof updateNodeGlows === 'function') updateNodeGlows(); if (typeof updateResponseGlow === 'function') updateResponseGlow(nIdx, rIdx); }