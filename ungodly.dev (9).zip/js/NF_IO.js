/**
 * NF_IO.js
 * Import / Export data pipeline routines. 
 * Includes advanced collision detection for node merging and parsing logic from the user's master file.
 */

function parseImportData(data, type, filename) {
    const safeAdd = (arr, item) => {
        let exists = nfArrayHasDuplicate(arr, item, type);
        
        if (exists) {
            let nameField = item.title || item.name || item.text || "Unnamed";
            console.info('[NarrativeFlow Import] duplicate skipped during typed import', { type, filename, name: nameField, keys: nfItemMergeKeys(item, type) });
            if(false && confirm(`Collision detected for "${nameField}" (ID Match) in ${type}. Overwrite existing? (Cancel will Append New)`)) {
                let idx = arr.findIndex(x => nfItemsMatch(x, item, type));
                if (idx !== -1) arr[idx] = {...item, _sourceFile: filename};
            } else {
                return;
            }
        } else {
            arr.push({...item, _sourceFile: filename});
        }
    };

    try {
        if (type === 'dialogue') {
            const convos = data.conversations || [];
            const seqs = data.sequences || [];
            convos.forEach(c => safeAdd(sourceData.dialogues, c));
            seqs.forEach(s => safeAdd(sourceData.sequences, s));
            convos.forEach(c => {
                if(c.activeLogicVariables && Array.isArray(c.activeLogicVariables)) {
                    c.activeLogicVariables.forEach(v => { sourceData.importedLogic.push({ key: v, usageClassification: 'Mixed Usage', _sourceFile: filename }); });
                }
            });
        } else if (type === 'task') {
            if (data.tabColors) globalTaskTabColors = {...globalTaskTabColors, ...data.tabColors};
            const tasks = Array.isArray(data) ? data : (data.entries || []);
            tasks.forEach(t => safeAdd(sourceData.tasks, t));
        } else if (type === 'menu') {
            let menus = [];
            let menuSrc = data.menus || data.conversations;
            if (menuSrc && typeof menuSrc === 'object' && !Array.isArray(menuSrc)) {
                Object.entries(menuSrc).forEach(([groupName, characters]) => {
                    if (groupName === 'ROOT') groupName = 'GLOBAL MENUS';
                    if (typeof characters === 'object' && !Array.isArray(characters)) {
                        Object.entries(characters).forEach(([charName, options]) => {
                            if (Array.isArray(options)) {
                                options.forEach(opt => {
                                    menus.push({ ...opt, groupName, characterName: charName });
                                    if (opt.subMenuOptions && Array.isArray(opt.subMenuOptions)) opt.subMenuOptions.forEach(sub => menus.push({ ...sub, groupName: groupName + ' (Sub)', characterName: charName }));
                                });
                            }
                        });
                    } else if (Array.isArray(characters)) {
                        characters.forEach(opt => menus.push({ ...opt, groupName, characterName: 'General' }));
                    }
                });
            } else if (data.menus?.ROOT) {
                Object.entries(data.menus).forEach(([groupName, options]) => {
                    if (Array.isArray(options)) options.forEach(opt => menus.push({ ...opt, groupName: groupName === 'ROOT' ? 'GLOBAL MENUS' : groupName, characterName: 'General' }));
                });
            } else if (Array.isArray(data.options)) {
                 menus = data.options.map(opt => ({...opt, groupName: 'GLOBAL MENUS', characterName: 'General'}));
            } else if (Array.isArray(data)) {
                 menus = data.map(opt => ({...opt, groupName: 'GLOBAL MENUS', characterName: 'General'}));
            }
            menus.forEach(m => safeAdd(sourceData.menus, m));
        } else if (type === 'prompt') {
            if (data.tags) data.tags.forEach(t => globalPromptTagColors[t.name] = t.color);
            const prompts = data.prompts || [];
            prompts.forEach(p => safeAdd(sourceData.prompts, p));
        }
    } catch(err) { console.error("Error extracting array data:", err); }

    try {
        if (data["Active Project Logic"] && Array.isArray(data["Active Project Logic"])) {
            data["Active Project Logic"].forEach(item => sourceData.importedLogic.push({...item, _sourceFile: filename}));
        }
        if (data["Gameplay Values"] && Array.isArray(data["Gameplay Values"])) {
            data["Gameplay Values"].forEach(item => sourceData.importedGameplayValues.push({...item, _sourceFile: filename}));
        }
    } catch(err) { console.error("Error extracting logic registry:", err); }
}

function importFile(e, type) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
        try {
            const data = JSON.parse(evt.target.result);
            parseImportData(data, type, file.name);
            updateProjectLogic();
            
            if (type === 'dialogue') setLeftTab('convo');
            else setLeftTab(type);
            
            renderAvailableList();
            if(rightTab === 'logic') renderLogicPanel();
            showNotification(`Imported ${type} from ${file.name}`);
        } catch(err) {
            console.error("Import Error", err);
            showNotification("Error parsing JSON: " + err.message, true);
        }
    };
    reader.readAsText(file);
    e.target.value = '';
}

function importDialogueFile(e) { importFile(e, 'dialogue'); }
function importTaskFile(e) { importFile(e, 'task'); }
function importMenuFile(e) { importFile(e, 'menu'); }
function importPromptFile(e) { importFile(e, 'prompt'); }

function nfNormalizeMergeText(value) {
    return String(value || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

function nfItemMergeKeys(item, context = '') {
    if (!item) return [];
    if (typeof item !== 'object') {
        const text = nfNormalizeMergeText(item);
        return text ? [`value:${text}`] : [];
    }
    const keys = new Set();
    const add = (label, value) => {
        const text = nfNormalizeMergeText(value);
        if (text) keys.add(`${label}:${text}`);
    };
    add('id', item.id || item.uuid || item.project_uuid || item.node_uuid || item.response_uuid);
    add('title', item.title);
    add('name', item.name);
    add('text', item.text);
    add('sourceRef', item.sourceRef);
    add('buttonLabel', item.buttonLabel);
    if (context === 'menus' || context === 'menu' || item.groupName || item.characterName) {
        add('menuVisible', `${item.groupName || ''}|${item.characterName || ''}|${item.text || item.title || item.name || ''}`);
    }
    if (context === 'tasks' || context === 'task' || item.tab) {
        add('taskVisible', `${item.tab || ''}|${item.name || item.title || item.text || ''}`);
    }
    if (context === 'prompts' || context === 'prompt' || item.tag) {
        add('promptVisible', `${item.tag || ''}|${item.title || item.name || item.text || ''}`);
    }
    if (context === 'dialogues' || context === 'sequences' || context === 'dialogue') {
        add('projectVisible', `${item.title || item.name || ''}|${(item.participants || []).join('|')}`);
    }
    return Array.from(keys);
}

function nfItemsMatch(a, b, context = '') {
    const aKeys = new Set(nfItemMergeKeys(a, context));
    return nfItemMergeKeys(b, context).some(key => aKeys.has(key));
}

function nfArrayHasDuplicate(target, item, context = '') {
    return (Array.isArray(target) ? target : []).some(existing => nfItemsMatch(existing, item, context));
}

function nfMergeArrayByIdentity(target, incoming, context = 'generic') {
    const original = Array.isArray(target) ? target : [];
    const out = [];
    const seen = new Set();
    let removedExisting = 0;
    original.forEach(item => {
        const keys = nfItemMergeKeys(item, context);
        if (keys.some(key => seen.has(key))) {
            removedExisting++;
            console.info('[NarrativeFlow Import] existing duplicate removed before merge', {
                context,
                label: item && (item.title || item.name || item.text || item.sourceRef || item.id || ''),
                keys
            });
            return;
        }
        out.push(item);
        keys.forEach(key => seen.add(key));
    });
    let added = 0;
    let skipped = 0;
    (Array.isArray(incoming) ? incoming : []).forEach(item => {
        if (!item || typeof item !== 'object') return;
        const keys = nfItemMergeKeys(item, context);
        if (keys.some(key => seen.has(key))) {
            skipped++;
            console.info('[NarrativeFlow Import] duplicate skipped', {
                context,
                label: item.title || item.name || item.text || item.sourceRef || item.id || '',
                keys
            });
            return;
        }
        out.push(item);
        keys.forEach(key => seen.add(key));
        added++;
    });
    console.info('[NarrativeFlow Import] merge complete', {
        context,
        existingBefore: original.length,
        removedExisting,
        incoming: Array.isArray(incoming) ? incoming.length : 0,
        added,
        skipped,
        total: out.length
    });
    return out;
}

function nfMergeSourceImports(incoming) {
    if (!incoming || typeof incoming !== 'object') return;
    console.group('[NarrativeFlow Import] merging sourceImports');
    sourceData.dialogues = nfMergeArrayByIdentity(sourceData.dialogues, incoming.dialogues || [], 'dialogues');
    sourceData.sequences = nfMergeArrayByIdentity(sourceData.sequences, incoming.sequences || [], 'sequences');
    sourceData.tasks = nfMergeArrayByIdentity(sourceData.tasks, incoming.tasks || [], 'tasks');
    sourceData.menus = nfMergeArrayByIdentity(sourceData.menus, incoming.menus || [], 'menus');
    sourceData.prompts = nfMergeArrayByIdentity(sourceData.prompts, incoming.prompts || [], 'prompts');
    sourceData.importedLogic = nfMergeArrayByIdentity(sourceData.importedLogic, incoming.importedLogic || [], 'logic');
    sourceData.importedGameplayValues = nfMergeArrayByIdentity(sourceData.importedGameplayValues, incoming.importedGameplayValues || [], 'gameplayValues');
    console.groupEnd();
}

function nfMergeToolingSection(type, sectionArrName, itemArrName, incomingTooling) {
    if (!incomingTooling || typeof incomingTooling !== 'object') return;
    const incomingSections = incomingTooling[sectionArrName] || [];
    const incomingItems = incomingTooling[itemArrName] || [];
    toolingData[sectionArrName] = nfMergeArrayByIdentity(toolingData[sectionArrName], incomingSections, sectionArrName);
    toolingData[itemArrName] = nfMergeArrayByIdentity(toolingData[itemArrName], incomingItems, itemArrName);
}

function nfMergeToolingData(incomingTooling) {
    if (!incomingTooling || typeof incomingTooling !== 'object') return;
    const normalized = { ...incomingTooling };
    if (normalized.transitionLibrary && !normalized.transitions) normalized.transitions = normalized.transitionLibrary;
    nfMergeToolingSection('trans', 'transitionSections', 'transitions', normalized);
    nfMergeToolingSection('imgnode', 'imageNodeSections', 'imageNodes', normalized);
    nfMergeToolingSection('imgdb', 'imageDbSections', 'imageDbItems', normalized);
    nfMergeToolingSection('convseq', 'convSeqSections', 'convSeqs', normalized);
    nfMergeToolingSection('puppetseq', 'puppetSeqSections', 'puppetSeqs', normalized);
}

function nfMapImportedFlowNode(c) {
    return {
        id: c.id, type: c.type || 'conversation', title: c.title, sourceRef: c.sourceRef || c.title,
        x: c.graphPos ? c.graphPos.x : (c.x || 0), y: c.graphPos ? c.graphPos.y : (c.y || 0),
        color: c.color || getRandomColor(), chainName: c.chainName || "", chainDesc: c.chainDesc || "", chainColor: c.chainColor || "#ffd700",
        taskType: c.taskType || 'standalone', unlockConditions: c.unlockConditions || [], onComplete: c.onComplete || [], nextConversations: c.nextConversations || [],
        savePoint: c.savePoint || "", isRepeatable: c.isRepeatable || false, repeatVariable: c.repeatVariable || "",
        isTaskQuest: c.isTaskQuest !== undefined ? c.isTaskQuest : (c.type === 'task'),
        taskUnlock: c.taskUnlock || {key:'', op:'==', val:''}, taskComplete: c.taskComplete || {key:'', op:'==', val:''},
        taskFail: c.taskFail || {key:'', op:'==', val:''}, taskReward: c.taskReward || {key:'', op:'==', val:''},
        canvasId: c.canvasId || 'default', snapParent: c.snapParent || null, snapChild: c.snapChild || null,
        contextTitle: c.contextTitle || "", buttonLabel: c.buttonLabel || ""
    };
}

function importStoryFlowFile(event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            if (data.tabs && data.entries && !data.flowNodes && !data.conversations) return showNotification("This looks like a Task Manager export. Use 'Import Tasks' instead.", true);
            if (data.prompts && !data.flowNodes && !data.conversations) return showNotification("This looks like a Prompt export. Use 'Import Prompts' instead.", true);
            if (!data.flowNodes && !data.conversations) throw new Error("Missing flow node array");
            
            if (data.sourceImports) nfMergeSourceImports(data.sourceImports);
            if (data.logicRegistry) {
                startupValues = nfMergeArrayByIdentity(startupValues, data.logicRegistry.startupValues || []);
                gameEndValues = nfMergeArrayByIdentity(gameEndValues, data.logicRegistry.gameEndValues || []);
                if (data.logicRegistry.gameplayValues) gameplayValues = { ...gameplayValues, ...data.logicRegistry.gameplayValues };
            }
            if (data.metadata) {
                if (Array.isArray(data.metadata.availableLanguages)) nfAvailableLanguages = nfMergeArrayByIdentity(nfAvailableLanguages.map(lang => ({ id: lang, name: lang })), data.metadata.availableLanguages.map(lang => ({ id: lang, name: lang }))).map(lang => lang.name || lang.id);
                if (data.metadata.currentLanguage) nfCurrentLanguage = nfNormalizeLanguageCode(data.metadata.currentLanguage);
                if (data.metadata.taskTabColors) globalTaskTabColors = { ...globalTaskTabColors, ...data.metadata.taskTabColors };
                if (data.metadata.promptTagColors) globalPromptTagColors = { ...globalPromptTagColors, ...data.metadata.promptTagColors };
                if (data.metadata.flowPages && data.metadata.flowPages.length > 0) flowPages = nfMergeArrayByIdentity(flowPages, data.metadata.flowPages);
                if (data.metadata.flowGroups) flowGroups = nfMergeArrayByIdentity(flowGroups, data.metadata.flowGroups);
            }
            
            if (data.toolingData) nfMergeToolingData(data.toolingData);
            
            if (!flowPages.find(p => p.id === currentCanvasId)) currentCanvasId = flowPages[0].id;
            const srcNodes = data.flowNodes || data.conversations || [];
            storyNodes = nfMergeArrayByIdentity(storyNodes, srcNodes.map(nfMapImportedFlowNode));

            const maxId = storyNodes.reduce((acc, node) => {
                const num = parseInt(String(node.id || '').split('_').pop());
                return isNaN(num) ? acc : Math.max(acc, num);
            }, 0);
            idCounter = maxId + 1;
            selectedNodeIds = [];
            nfRenderLanguageControls(); renderFlowPages(); renderAvailableList(); renderToolLibrary(); renderToolEditor(); updateProjectLogic(); renderNodes();
            showNotification(`Merged Master Flow Data`);
        } catch (err) { showNotification("Load Error: " + err.message, true); }
    };
    reader.readAsText(file);
    event.target.value = '';
}

function exportStoryFlow() {
    if (typeof nfSaveCurrentLanguageFields === 'function') nfSaveCurrentLanguageFields();
    // Intercept toolingData to rename 'transitions' to 'transitionLibrary' for the exported JSON
    const exportToolingData = { ...toolingData };
    if (exportToolingData.transitions) {
        exportToolingData.transitionLibrary = exportToolingData.transitions;
        delete exportToolingData.transitions;
    }

    const data = {
        storyVersion: "3.0-ComplexTooling",
        sourceImports: {
            dialogues: sourceData.dialogues, sequences: sourceData.sequences, tasks: sourceData.tasks, menus: sourceData.menus,
            prompts: sourceData.prompts, importedLogic: sourceData.importedLogic, importedGameplayValues: sourceData.importedGameplayValues
        },
        logicRegistry: { startupValues, gameEndValues, gameplayValues },
        metadata: { taskTabColors: globalTaskTabColors, promptTagColors: globalPromptTagColors, flowPages: flowPages, flowGroups: flowGroups, availableLanguages: nfAvailableLanguages, currentLanguage: nfCurrentLanguage },
        toolingData: exportToolingData,
        flowNodes: storyNodes.map(n => ({
            id: n.id, type: n.type || 'conversation', title: n.title, sourceRef: n.sourceRef,
            color: n.color, chainName: n.chainName, chainDesc: n.chainDesc, chainColor: n.chainColor, taskType: n.taskType,
            unlockConditions: n.unlockConditions.filter(c => c.variable), onComplete: n.onComplete.filter(c => c.variable),
            isRepeatable: n.isRepeatable, repeatVariable: n.repeatVariable, isTaskQuest: n.isTaskQuest,
            taskUnlock: n.isTaskQuest ? n.taskUnlock : null, taskComplete: n.isTaskQuest ? n.taskComplete : null,
            taskFail: n.isTaskQuest ? n.taskFail : null, taskReward: n.isTaskQuest ? n.taskReward : null,
            nextConversations: n.nextConversations, savePoint: n.savePoint || null, canvasId: n.canvasId || 'default',
            snapParent: n.snapParent || null, snapChild: n.snapChild || null, contextTitle: n.contextTitle || "", buttonLabel: n.buttonLabel || "",
            graphPos: { x: Math.round(n.x), y: Math.round(n.y) } 
        }))
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], {type: "application/json"});
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    const now = new Date(); const pad = num => String(num).padStart(2, '0');
    a.download = `NarrativeFlow_Export_${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}.json`; 
    a.click(); showNotification("Master Flow Exported");
}

function renameToolLogic() {
    const val = document.getElementById('modal-rename-val').value.trim();
    if(!val) return;
    const oldKey = document.getElementById('modal-title').innerText.split(' (')[0];
    
    // Mutate only toolingData conditions and state changes
    toolingData.transitions.forEach(n => {
        n.conditions.forEach(c => { if(normalizeStatement(c.key, c.op, c.val) === oldKey) c.key = val; });
        n.stateChanges.forEach(c => { if(normalizeStatement(c.key, c.op, c.val) === oldKey) c.key = val; });
    });
    toolingData.imageNodes.forEach(n => {
        n.conditions.forEach(c => { if(normalizeStatement(c.key, c.op, c.val) === oldKey) c.key = val; });
        n.stateChanges.forEach(c => { if(normalizeStatement(c.key, c.op, c.val) === oldKey) c.key = val; });
    });
    
    closeTagModal();
    updateProjectLogic();
    if (activeOverTab === 'tools') renderToolEditor();
    showNotification("Renamed references locally");
}
