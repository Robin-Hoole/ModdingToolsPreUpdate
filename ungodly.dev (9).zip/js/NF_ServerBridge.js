/**
 * NF_ServerBridge.js
 * Shared auth/account modal + Narrative Flow server session save/load bridge.
 */

console.info('[NarrativeFlow Boot] NF_ServerBridge.js loaded', {
    href: window.location.href,
    script: 'NF_ServerBridge.js',
    time: new Date().toISOString()
});

const NF_SESSION_STORAGE_KEY = 'FSG_NF_serverSessionId';
const NF_LINKED_APP_STORAGE_KEY = 'FSG_NF_linkedSourceApp';
const NF_LINKED_SESSION_STORAGE_KEY = 'FSG_NF_linkedSessionId';
const NF_SHARED_AUTH_TOKEN_KEY = 'AuthShared_12h_token';
const NF_DD_AUTH_TOKEN_KEY = 'DD_sharedAuthBearerToken';
let nfAuthState = { loggedIn: false, user: null, sessions: [], authToken: '' };
let nfAccountMode = 'login';
let nfIsPushing = false;
let nfCurrentApiUrl = null;
let nfCurrentAuthUrl = null;

function nfNotify(message, isError = false) {
    if (typeof showNotification === 'function') showNotification(message, isError);
    else console[isError ? 'error' : 'log']('[NarrativeFlow]', message);
}

function nfStoredAuthToken() {
    try { return localStorage.getItem(NF_SHARED_AUTH_TOKEN_KEY) || localStorage.getItem(NF_DD_AUTH_TOKEN_KEY) || ''; }
    catch (err) { return ''; }
}

function nfSetStoredAuthToken(token) {
    try {
        const cleaned = token ? String(token).trim() : '';
        if (cleaned) {
            localStorage.setItem(NF_SHARED_AUTH_TOKEN_KEY, cleaned);
            localStorage.setItem(NF_DD_AUTH_TOKEN_KEY, cleaned);
        } else {
            localStorage.removeItem(NF_SHARED_AUTH_TOKEN_KEY);
            localStorage.removeItem(NF_DD_AUTH_TOKEN_KEY);
        }
    } catch (err) {}
}

function nfAuthHeaders(extra = {}) {
    const headers = new Headers(extra || {});
    if (!headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
    const token = nfStoredAuthToken();
    if (token) {
        if (!headers.has('Authorization')) headers.set('Authorization', `Bearer ${token}`);
        if (!headers.has('X-Auth-Token')) headers.set('X-Auth-Token', token);
    }
    return headers;
}

function nfUrlWithQuery(base, query = {}) {
    const url = new URL(base, window.location.href);
    Object.entries(query || {}).forEach(([k, v]) => {
        if (v !== undefined && v !== null && String(v) !== '') url.searchParams.set(k, String(v));
    });
    const token = nfStoredAuthToken();
    if (token && !url.searchParams.has('authToken')) url.searchParams.set('authToken', token);
    return url.toString();
}

async function nfParseJsonResponse(response, label) {
    const text = await response.text();
    const type = String(response.headers.get('content-type') || '').toLowerCase();
    const trimmed = text.trim();
    if (type.includes('text/css') || trimmed.startsWith(':root') || trimmed.startsWith('/*') || trimmed.includes('--accent-teal')) {
        throw new Error(`${label} returned CSS instead of JSON. Upload/route ${label} at the site root. Status=${response.status}.`);
    }
    let data = null;
    try { data = trimmed ? JSON.parse(trimmed) : {}; }
    catch (err) { throw new Error(`${label} returned non-JSON: ${trimmed.slice(0, 180)}`); }
    if (!response.ok || data.ok === false) throw new Error(data.error || data.message || `${label} request failed (${response.status})`);
    return data;
}

async function nfFetchApi(action, options = {}) {
    const candidates = nfCurrentApiUrl ? [nfCurrentApiUrl] : ['NarrativeFlow.php', '/NarrativeFlow.php'];
    let lastErr = null;
    for (const base of candidates) {
        try {
            const url = nfUrlWithQuery(base, Object.assign({}, options.query || {}, { action }));
            console.info('[NarrativeFlow API] request', { action, url, method: options.method || 'GET' });
            const fetchOptions = {
                method: options.method || 'GET',
                credentials: 'include',
                headers: nfAuthHeaders(options.headers || {})
            };
            if (options.body !== undefined) fetchOptions.body = JSON.stringify(options.body);
            const response = await fetch(url, fetchOptions);
            const data = await nfParseJsonResponse(response, 'NarrativeFlow.php');
            nfCurrentApiUrl = base;
            if (data.authToken) nfSetStoredAuthToken(data.authToken);
            console.info('[NarrativeFlow API] response', {
                action,
                ok: data.ok !== false,
                loggedIn: !!data.loggedIn,
                sessionId: data.sessionId || data.latestSessionId || '',
                payloadFound: data.payloadFound,
                source: data.latestSessionSource || data.linkedSourceApp || '',
                hasWorkspace: !!data.workspace,
                hasData: !!data.data,
                workspaceMetadataKeys: data.data && data.data.metadata ? Object.keys(data.data.metadata) : [],
                dialogueDesignerSqlImport: data.data && data.data.metadata ? data.data.metadata.dialogueDesignerSqlImport || null : null,
                menuDesignerSqlImport: data.data && data.data.metadata ? data.data.metadata.menuDesignerSqlImport || null : null,
                taskManagerSqlImport: data.data && data.data.metadata ? data.data.metadata.taskManagerSqlImport || null : null,
                promptDesignerSqlImport: data.data && data.data.metadata ? data.data.metadata.promptDesignerSqlImport || null : null
            });
            return data;
        } catch (err) {
            console.warn('[NarrativeFlow API] failed candidate', { action, base, message: err.message });
            lastErr = err;
        }
    }
    throw lastErr || new Error('NarrativeFlow API failed.');
}

async function nfFetchAuth(action, body = {}) {
    const candidates = nfCurrentAuthUrl ? [nfCurrentAuthUrl] : ['Auth.php', '/Auth.php'];
    let lastErr = null;
    for (const base of candidates) {
        try {
            const response = await fetch(nfUrlWithQuery(base, { action }), {
                method: 'POST',
                credentials: 'include',
                headers: nfAuthHeaders(),
                body: JSON.stringify(Object.assign({ action }, body || {}))
            });
            const data = await nfParseJsonResponse(response, 'Auth.php');
            nfCurrentAuthUrl = base;
            if (data.authToken) nfSetStoredAuthToken(data.authToken);
            return data;
        } catch (err) { lastErr = err; }
    }
    throw lastErr || new Error('Auth API failed.');
}

function nfGenerateLocalSessionId() {
    const partA = Math.random().toString(16).slice(2, 8).toUpperCase().padEnd(6, '0');
    const partB = Math.random().toString(16).slice(2, 12).toUpperCase().padEnd(10, '0');
    return `NF-${partA}-${partB}`;
}

function nfNormalizeSessionId(id) {
    return String(id || '').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '');
}

function nfGetCurrentSessionId() {
    const display = document.getElementById('nf-server-session-id-display');
    const current = nfNormalizeSessionId(display ? display.textContent : '');
    if (current && current !== 'NF-LOCAL') return current;
    try { return nfNormalizeSessionId(localStorage.getItem(NF_SESSION_STORAGE_KEY)) || ''; }
    catch (err) { return ''; }
}

function nfSetCurrentSessionId(sessionId, options = {}) {
    const normalized = nfNormalizeSessionId(sessionId) || nfGenerateLocalSessionId();
    try { localStorage.setItem(NF_SESSION_STORAGE_KEY, normalized); } catch (err) {}
    const display = document.getElementById('nf-server-session-id-display');
    const input = document.getElementById('nf-server-session-id-input');
    if (display) display.textContent = normalized;
    if (input) input.value = normalized;
    if (options.linkedSourceApp !== undefined) nfSetLinkedSession(options.linkedSourceApp, options.linkedSessionId || '');
    console.info('[NarrativeFlow Session] current session set', {
        sessionId: normalized,
        linkedSourceApp: options.linkedSourceApp,
        linkedSessionId: options.linkedSessionId
    });
    return normalized;
}

function nfEnsureSessionId() {
    return nfSetCurrentSessionId(nfGetCurrentSessionId() || nfGenerateLocalSessionId());
}

function nfSetLinkedSession(app, sessionId) {
    const source = String(app || '').trim();
    const linkedId = nfNormalizeSessionId(sessionId || '');
    try {
        localStorage.setItem(NF_LINKED_APP_STORAGE_KEY, source);
        localStorage.setItem(NF_LINKED_SESSION_STORAGE_KEY, linkedId);
    } catch (err) {}
    const el = document.getElementById('nf-server-session-linked');
    if (el) {
        if (source && linkedId) el.textContent = `Linked to ${source} Session ${linkedId}`;
        else el.textContent = 'Linked to Dialogue Designer Session --';
    }
}

function nfGetLinkedSourceApp() {
    try { return localStorage.getItem(NF_LINKED_APP_STORAGE_KEY) || ''; }
    catch (err) { return ''; }
}

function nfGetLinkedSessionId() {
    try { return localStorage.getItem(NF_LINKED_SESSION_STORAGE_KEY) || ''; }
    catch (err) { return ''; }
}

function nfUpdateAuthUi() {
    const accountBtn = document.getElementById('nf-account-btn');
    const pushBtn = document.getElementById('nf-push-to-server-btn');
    if (accountBtn) accountBtn.classList.toggle('is-logged-in', !!nfAuthState.loggedIn);
    if (pushBtn) pushBtn.classList.toggle('hidden', !nfAuthState.loggedIn);

    const status = document.getElementById('nf-account-status-line');
    if (status) status.textContent = nfAuthState.loggedIn && nfAuthState.user ? `Logged in as ${nfAuthState.user.username || nfAuthState.user.email || 'account'}` : 'Not logged in.';

    const forms = document.getElementById('nf-account-auth-forms');
    const profile = document.getElementById('nf-account-profile');
    if (forms) forms.classList.toggle('hidden', !!nfAuthState.loggedIn);
    if (profile) profile.classList.toggle('hidden', !nfAuthState.loggedIn);
    if (nfAuthState.user) {
        const userEl = document.getElementById('nf-account-username-display');
        const emailEl = document.getElementById('nf-account-email-display');
        const editUser = document.getElementById('nf-profile-edit-username');
        const editEmail = document.getElementById('nf-profile-edit-email');
        if (userEl) userEl.textContent = nfAuthState.user.username || '--';
        if (emailEl) emailEl.textContent = nfAuthState.user.email || '--';
        if (editUser && document.activeElement !== editUser) editUser.value = nfAuthState.user.username || '';
        if (editEmail && document.activeElement !== editEmail) editEmail.value = nfAuthState.user.email || '';
    }
    nfRenderRecentSessions(nfAuthState.sessions || []);
}

function nfRenderRecentSessions(sessions) {
    const list = document.getElementById('nf-recent-sessions-list');
    if (!list) return;
    const rows = Array.isArray(sessions) ? sessions : [];
    if (!rows.length) {
        list.innerHTML = '<div class="nf-session-empty">No recent sessions.</div>';
        return;
    }
    list.innerHTML = rows.map(row => {
        const sid = nfNormalizeSessionId(row.session_id || row.sessionId || '');
        const date = row.last_viewed_at || row.last_pushed_at || row.updated_at || '';
        const app = row.app_key || row.linked_app || 'NarrativeFlow';
        return `
            <div class="nf-session-row" ondblclick="nfLoadSessionById('${sid}')">
                <button type="button" class="nf-session-copy" title="Copy" onclick="event.stopPropagation(); nfCopyText('${sid}', this)">${nfCopySvg()}</button>
                <div class="nf-session-main">
                    <span class="nf-session-id">${sid}</span>
                    <span class="nf-session-meta">${app}${date ? ' · ' + date : ''}</span>
                </div>
                <button type="button" class="nf-session-load" onclick="event.stopPropagation(); nfLoadSessionById('${sid}')">LOAD</button>
            </div>`;
    }).join('');
}

function nfCopySvg() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>';
}

async function nfCopyText(text, btn) {
    try { await navigator.clipboard.writeText(text); }
    catch (err) {
        const input = document.createElement('textarea');
        input.value = text;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        input.remove();
    }
    if (btn) {
        const old = btn.innerHTML;
        btn.textContent = '✓';
        setTimeout(() => { btn.innerHTML = old; }, 800);
    }
}

function nfCopyServerSessionId(btn) { nfCopyText(nfGetCurrentSessionId(), btn); }

async function nfRegenerateServerSessionId() {
    if (nfAuthState.loggedIn) {
        try {
            const data = await nfFetchApi('generateSessionId');
            nfSetCurrentSessionId(data.sessionId || nfGenerateLocalSessionId());
            nfNotify('Generated new server session id.');
            return;
        } catch (err) { console.warn('[NarrativeFlow] server session generation failed, using local id:', err.message); }
    }
    nfSetCurrentSessionId(nfGenerateLocalSessionId());
    nfNotify('Generated local session id.');
}

async function nfPasteServerSessionId() {
    try {
        const text = await navigator.clipboard.readText();
        const input = document.getElementById('nf-server-session-id-input');
        if (input) input.value = nfNormalizeSessionId(text);
    } catch (err) { nfNotify('Clipboard paste failed.', true); }
}

function nfDownloadServerSessionJson() {
    const payload = {
        app: 'NarrativeFlow',
        sessionId: nfGetCurrentSessionId(),
        linkedSourceApp: nfGetLinkedSourceApp(),
        linkedSessionId: nfGetLinkedSessionId(),
        exportedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `NarrativeFlow_Session_${payload.sessionId || 'local'}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
}

function nfUploadServerSessionJson(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
        try {
            const data = JSON.parse(e.target.result);
            const id = data.sessionId || data.serverSessionId || data.id;
            if (!id) throw new Error('No session id found.');
            nfSetCurrentSessionId(id, { linkedSourceApp: data.linkedSourceApp || data.linked_app || '', linkedSessionId: data.linkedSessionId || data.linked_session_id || '' });
            nfNotify('Session JSON loaded.');
        } catch (err) { nfNotify('Session JSON failed: ' + err.message, true); }
        event.target.value = '';
    };
    reader.readAsText(file);
}

function nfLoadSessionFromInput() {
    const input = document.getElementById('nf-server-session-id-input');
    const id = nfNormalizeSessionId(input ? input.value : '');
    if (!id) return nfNotify('Enter a server session id first.', true);
    nfLoadSessionById(id);
}

async function nfLoadSessionById(sessionId) {
    const id = nfNormalizeSessionId(sessionId);
    if (!id) return;
    nfSetCurrentSessionId(id);
    if (!nfAuthState.loggedIn) {
        nfNotify('Login required to load server data. Session id was applied locally.', true);
        return;
    }
    try {
        const data = await nfFetchApi('loadSession', { query: { sessionId: id } });
        nfAuthState.sessions = data.sessions || nfAuthState.sessions || [];
        nfSetCurrentSessionId(data.sessionId || id);
        if (data.workspace) nfApplyWorkspacePayload(data.workspace);
        nfUpdateAuthUi();
        nfNotify(data.payloadFound ? 'Narrative Flow server session loaded.' : 'Session id loaded, but no Narrative Flow payload exists yet.');
    } catch (err) { nfNotify('Load failed: ' + err.message, true); }
}

async function nfPushToServer() {
    if (!nfAuthState.loggedIn) return;
    const btn = document.getElementById('nf-push-to-server-btn');
    const label = btn ? btn.querySelector('.nf-push-label') : null;
    if (nfIsPushing) return;
    nfIsPushing = true;
    if (btn) btn.classList.add('is-pushing');
    if (label) label.textContent = 'Pushing To Server...';
    try {
        const sessionId = nfEnsureSessionId();
        const workspace = typeof nfBuildWorkspacePayload === 'function' ? nfBuildWorkspacePayload() : {};
        const data = await nfFetchApi('saveSession', {
            method: 'POST',
            query: { sessionId },
            body: {
                sessionId,
                linkedSourceApp: nfGetLinkedSourceApp(),
                linkedSessionId: nfGetLinkedSessionId(),
                workspace
            }
        });
        nfSetCurrentSessionId(data.sessionId || sessionId);
        nfAuthState.sessions = data.sessions || nfAuthState.sessions || [];
        nfUpdateAuthUi();
        nfNotify('Narrative Flow pushed to server.');
    } catch (err) { nfNotify('Push failed: ' + err.message, true); }
    finally {
        nfIsPushing = false;
        if (btn) btn.classList.remove('is-pushing');
        if (label) label.textContent = 'Push To Server';
    }
}

function nfOpenAccountModal() {
    const modal = document.getElementById('nf-account-modal');
    if (modal) modal.style.display = 'flex';
    nfRefreshAccountStatus(false);
}

function nfCloseAccountModal() {
    const modal = document.getElementById('nf-account-modal');
    if (modal) modal.style.display = 'none';
}

function nfSetAccountMode(mode) {
    nfAccountMode = mode === 'register' ? 'register' : 'login';
    const loginTab = document.getElementById('nf-login-tab');
    const registerTab = document.getElementById('nf-register-tab');
    const checks = document.getElementById('nf-register-checks');
    const submit = document.getElementById('nf-account-submit');
    if (loginTab) loginTab.classList.toggle('active', nfAccountMode === 'login');
    if (registerTab) registerTab.classList.toggle('active', nfAccountMode === 'register');
    if (checks) checks.style.display = nfAccountMode === 'register' ? 'grid' : 'none';
    if (submit) submit.textContent = nfAccountMode === 'register' ? 'Register' : 'Login';
}

async function nfSubmitAccountForm() {
    const email = document.getElementById('nf-account-email')?.value.trim() || '';
    const username = document.getElementById('nf-account-username')?.value.trim() || '';
    const password = document.getElementById('nf-account-password')?.value || '';
    const passwordConfirm = document.getElementById('nf-account-password-confirm')?.value || '';
    try {
        let data;
        if (nfAccountMode === 'register') {
            data = await nfFetchAuth('register', {
                username,
                email,
                password,
                passwordConfirm,
                over18: !!document.getElementById('nf-over-18')?.checked,
                terms: !!document.getElementById('nf-agree-terms')?.checked,
                privacy: !!document.getElementById('nf-agree-privacy')?.checked,
                browserLabel: 'NarrativeFlow'
            });
        } else {
            data = await nfFetchAuth('login', { identity: email || username, password, browserLabel: 'NarrativeFlow' });
        }
        if (data.authToken) nfSetStoredAuthToken(data.authToken);
        await nfRefreshAccountStatus(true);
        nfNotify(nfAccountMode === 'register' ? 'Account registered.' : 'Logged in.');
    } catch (err) { nfNotify(err.message, true); }
}

function nfToggleAccountSection(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.toggle('is-closed');
}

async function nfUpdateAccountProfile() {
    const username = document.getElementById('nf-profile-edit-username')?.value.trim() || '';
    const email = document.getElementById('nf-profile-edit-email')?.value.trim() || '';
    if (!username || !email) { nfNotify('Username and email are required.', true); return; }
    try {
        const data = await nfFetchAuth('updateProfile', { username, email });
        nfAuthState.loggedIn = !!data.loggedIn;
        nfAuthState.user = data.user || nfAuthState.user;
        nfAuthState.sessions = data.sessions || nfAuthState.sessions || [];
        if (data.authToken) nfSetStoredAuthToken(data.authToken);
        nfUpdateAuthUi();
        nfNotify('Account settings updated.');
    } catch (err) { nfNotify('Account update failed: ' + err.message, true); }
}

async function nfChangeAccountPassword() {
    const password = document.getElementById('nf-password-new')?.value || '';
    const passwordConfirm = document.getElementById('nf-password-confirm')?.value || '';
    if (!password || !passwordConfirm) { nfNotify('Enter and confirm the new password.', true); return; }
    try {
        const data = await nfFetchAuth('changePassword', { password, passwordConfirm });
        nfAuthState.loggedIn = !!data.loggedIn;
        nfAuthState.user = data.user || nfAuthState.user;
        nfAuthState.sessions = data.sessions || nfAuthState.sessions || [];
        if (data.authToken) nfSetStoredAuthToken(data.authToken);
        const p1 = document.getElementById('nf-password-new');
        const p2 = document.getElementById('nf-password-confirm');
        if (p1) p1.value = '';
        if (p2) p2.value = '';
        nfUpdateAuthUi();
        nfNotify('Password changed.');
    } catch (err) { nfNotify('Password change failed: ' + err.message, true); }
}

window.nfToggleAccountSection = nfToggleAccountSection;
window.nfUpdateAccountProfile = nfUpdateAccountProfile;
window.nfChangeAccountPassword = nfChangeAccountPassword;

async function nfLogout() {
    try { await nfFetchAuth('logout', {}); } catch (err) {}
    nfSetStoredAuthToken('');
    nfAuthState = { loggedIn: false, user: null, sessions: [], authToken: '' };
    nfSetCurrentSessionId(nfGenerateLocalSessionId(), { linkedSourceApp: '', linkedSessionId: '' });
    nfUpdateAuthUi();
    nfNotify('Logged out.');
}

async function nfRefreshAccountStatus(loadLatestAfterLogin = false) {
    try {
        const data = await nfFetchApi('accountStatus');
        nfAuthState.loggedIn = !!data.loggedIn;
        nfAuthState.user = data.user || null;
        nfAuthState.sessions = data.sessions || [];
        if (data.authToken) nfSetStoredAuthToken(data.authToken);
        nfUpdateAuthUi();
        if (loadLatestAfterLogin && nfAuthState.loggedIn) await nfLoadLatest();
        if (!nfAuthState.loggedIn) nfEnsureSessionId();
        return data;
    } catch (err) {
        console.warn('[NarrativeFlow Check] account status failed:', err.message);
        nfAuthState.loggedIn = false;
        nfUpdateAuthUi();
        nfEnsureSessionId();
        return null;
    }
}

function nfNormalizeToolingDataForLoad(data) {
    const base = data && typeof data === 'object' ? data : {};
    if (!base.transitionSections) base.transitionSections = [];
    if (base.transitionLibrary && !base.transitions) {
        base.transitions = base.transitionLibrary;
        delete base.transitionLibrary;
    }
    if (!base.transitions) base.transitions = [];
    if (!base.imageNodeSections) base.imageNodeSections = [];
    if (!base.imageNodes) base.imageNodes = [];
    if (!base.imageDbSections) base.imageDbSections = [];
    if (!base.imageDbItems) base.imageDbItems = [];
    if (!base.convSeqSections) base.convSeqSections = [];
    if (!base.convSeqs) base.convSeqs = [];
    if (!base.puppetSeqSections) base.puppetSeqSections = [];
    if (!base.puppetSeqs) base.puppetSeqs = [];
    return base;
}

function nfMapFlowNodesForLoad(nodes) {
    const srcNodes = Array.isArray(nodes) ? nodes : [];
    return srcNodes.map(c => ({
        id: c.id,
        type: c.type || 'conversation',
        title: c.title,
        sourceRef: c.sourceRef || c.title,
        x: c.graphPos ? c.graphPos.x : (c.x || 0),
        y: c.graphPos ? c.graphPos.y : (c.y || 0),
        color: c.color || getRandomColor(),
        chainName: c.chainName || "",
        chainDesc: c.chainDesc || "",
        chainColor: c.chainColor || "#ffd700",
        taskType: c.taskType || 'standalone',
        unlockConditions: c.unlockConditions || [],
        onComplete: c.onComplete || [],
        nextConversations: c.nextConversations || [],
        savePoint: c.savePoint || "",
        isRepeatable: c.isRepeatable || false,
        repeatVariable: c.repeatVariable || "",
        isTaskQuest: c.isTaskQuest !== undefined ? c.isTaskQuest : (c.type === 'task'),
        taskUnlock: c.taskUnlock || {key:'', op:'==', val:''},
        taskComplete: c.taskComplete || {key:'', op:'==', val:''},
        taskFail: c.taskFail || {key:'', op:'==', val:''},
        taskReward: c.taskReward || {key:'', op:'==', val:''},
        canvasId: c.canvasId || 'default',
        snapParent: c.snapParent || null,
        snapChild: c.snapChild || null,
        contextTitle: c.contextTitle || "",
        buttonLabel: c.buttonLabel || ""
    }));
}

function nfApplyWorkspacePayload(data) {
    if (!data || typeof data !== 'object') return;
    const ddSql = data.metadata && data.metadata.dialogueDesignerSqlImport ? data.metadata.dialogueDesignerSqlImport : null;
    const mdSql = data.metadata && data.metadata.menuDesignerSqlImport ? data.metadata.menuDesignerSqlImport : null;
    const tmSql = data.metadata && data.metadata.taskManagerSqlImport ? data.metadata.taskManagerSqlImport : null;
    const pdSql = data.metadata && data.metadata.promptDesignerSqlImport ? data.metadata.promptDesignerSqlImport : null;
    console.info('[NarrativeFlow Workspace] applying payload', {
        hasSourceImports: !!data.sourceImports,
        dialogueCount: data.sourceImports && data.sourceImports.dialogues ? data.sourceImports.dialogues.length : 0,
        sequenceCount: data.sourceImports && data.sourceImports.sequences ? data.sourceImports.sequences.length : 0,
        taskCount: data.sourceImports && data.sourceImports.tasks ? data.sourceImports.tasks.length : 0,
        promptCount: data.sourceImports && data.sourceImports.prompts ? data.sourceImports.prompts.length : 0,
        menuCount: data.sourceImports && data.sourceImports.menus ? data.sourceImports.menus.length : 0,
        flowNodeCount: Array.isArray(data.flowNodes) ? data.flowNodes.length : 0,
        hasToolingData: !!data.toolingData,
        dialogueDesignerSqlImport: ddSql,
        menuDesignerSqlImport: mdSql,
        taskManagerSqlImport: tmSql,
        promptDesignerSqlImport: pdSql
    });
    if (ddSql) {
        const ddSummary = {
            status: ddSql.status,
            sessionId: ddSql.sessionId,
            databaseId: ddSql.dialogueDesignerDatabaseId,
            dialogueCount: ddSql.dialogueCount,
            sequenceCount: ddSql.sequenceCount,
            workspaceId: ddSql.debug && ddSql.debug.workspaceId,
            workspaceUserId: ddSql.debug && ddSql.debug.workspaceUserId,
            workspaceProjectCountHint: ddSql.debug && ddSql.debug.workspaceProjectCountHint,
            workspaceRawSequenceScoreHint: ddSql.debug && ddSql.debug.workspaceRawSequenceScoreHint,
            workspaceRawJsonBytesHint: ddSql.debug && ddSql.debug.workspaceRawJsonBytesHint,
            matchedBy: ddSql.debug && ddSql.debug.lookup && ddSql.debug.lookup.matchedBy,
            exactSessionRows: ddSql.debug && ddSql.debug.lookup && ddSql.debug.lookup.exactSessionRows,
            rawJsonSessionRows: ddSql.debug && ddSql.debug.lookup && ddSql.debug.lookup.rawJsonSessionRows,
            userRows: ddSql.debug && ddSql.debug.lookup && ddSql.debug.lookup.userRows,
            projectRowsForWorkspace: ddSql.debug && ddSql.debug.tableCounts && ddSql.debug.tableCounts.FSG_DD_Projects,
            structuredSequences: ddSql.debug && ddSql.debug.structuredSequenceCount,
            structuredConversations: ddSql.debug && ddSql.debug.structuredConversationCount,
            snapshotSequences: ddSql.debug && ddSql.debug.snapshotSequenceCount,
            snapshotSequenceUsed: ddSql.debug && ddSql.debug.snapshotSequenceUsed,
            rawJsonSequenceCount: ddSql.debug && ddSql.debug.rawJsonSequenceCount
        };
        console[ddSql.sequenceCount || ddSql.dialogueCount ? 'info' : 'warn']('[NarrativeFlow SQL Debug] DialogueDesigner summary', ddSummary);
        console.info('[NarrativeFlow SQL Debug] DialogueDesigner raw debug object', ddSql.debug || null);
        console.group('[NarrativeFlow SQL Debug] DialogueDesigner import detail');
        console.info('Import summary', ddSummary);
        console.info('Lookup and table debug', ddSql.debug || null);
        if (ddSql.debug && ddSql.debug.lookup) console.info('Workspace lookup detail', ddSql.debug.lookup);
        if (ddSql.debug && ddSql.debug.tableCounts) console.table(ddSql.debug.tableCounts);
        if (ddSql.debug && ddSql.debug.projectSamples) console.table(ddSql.debug.projectSamples);
        if (ddSql.debug && ddSql.debug.lookup && ddSql.debug.lookup.latestRowsForSession) console.table(ddSql.debug.lookup.latestRowsForSession);
        if (ddSql.debug && ddSql.debug.lookup && ddSql.debug.lookup.latestRowsForUser) console.table(ddSql.debug.lookup.latestRowsForUser);
        if (ddSql.debug && ddSql.debug.structuredSequenceTitles) console.info('Structured sequence titles', ddSql.debug.structuredSequenceTitles);
        if (ddSql.debug && ddSql.debug.structuredConversationTitles) console.info('Structured conversation titles', ddSql.debug.structuredConversationTitles);
        console.groupEnd();
    } else {
        console.warn('[NarrativeFlow SQL Debug] DialogueDesigner import metadata is missing from payload.');
    }
    if (mdSql) {
        console.info('[NarrativeFlow SQL Debug] MenuDesigner import summary', {
            status: mdSql.status || 'imported',
            sessionId: mdSql.sessionId,
            databaseId: mdSql.menuDesignerDatabaseId,
            menuCount: mdSql.menuCount,
            debug: mdSql.debug || null
        });
    }
    if (tmSql) {
        const tmSummary = {
            status: tmSql.status,
            sessionId: tmSql.sessionId,
            sourceTable: tmSql.sourceTable,
            taskCount: tmSql.taskCount,
            tabCount: tmSql.tabCount,
            tabColorCount: tmSql.tabColorCount,
            matchedBy: tmSql.debug && tmSql.debug.matchedBy,
            exactSessionRows: tmSql.debug && tmSql.debug.exactSessionRows,
            exactSessionUserRows: tmSql.debug && tmSql.debug.exactSessionUserRows,
            userRows: tmSql.debug && tmSql.debug.userRows,
            payloadJsonBytes: tmSql.debug && tmSql.debug.payloadJsonBytes,
            entryCount: tmSql.debug && tmSql.debug.entryCount,
            firstTaskNames: tmSql.debug && tmSql.debug.firstTaskNames
        };
        console[tmSql.taskCount ? 'info' : 'warn']('[NarrativeFlow SQL Debug] TaskManager summary', tmSummary);
        console.info('[NarrativeFlow SQL Debug] TaskManager raw debug object', tmSql.debug || null);
        console.group('[NarrativeFlow SQL Debug] TaskManager import detail');
        if (tmSql.debug && tmSql.debug.latestRowsForSession) console.table(tmSql.debug.latestRowsForSession);
        if (tmSql.debug && tmSql.debug.latestRowsForUser) console.table(tmSql.debug.latestRowsForUser);
        if (tmSql.debug && tmSql.debug.sharedServerSessionRows) console.table(tmSql.debug.sharedServerSessionRows);
        console.info('TaskManager full metadata', tmSql);
        console.groupEnd();
    } else {
        console.warn('[NarrativeFlow SQL Debug] TaskManager import metadata is missing from payload.');
    }
    if (pdSql) {
        const pdSummary = {
            status: pdSql.status,
            sessionId: pdSql.sessionId,
            dialogueSessionId: pdSql.dialogueSessionId,
            sourceTable: pdSql.sourceTable,
            promptCount: pdSql.promptCount,
            tagCount: pdSql.tagCount,
            matchedBy: pdSql.debug && pdSql.debug.matchedBy,
            exactSessionRows: pdSql.debug && pdSql.debug.exactSessionRows,
            exactSessionUserRows: pdSql.debug && pdSql.debug.exactSessionUserRows,
            dialogueSessionRows: pdSql.debug && pdSql.debug.dialogueSessionRows,
            promptRowsForSession: pdSql.debug && pdSql.debug.promptRowsForSession,
            tagRowsForSession: pdSql.debug && pdSql.debug.tagRowsForSession,
            payloadJsonBytes: pdSql.debug && pdSql.debug.payloadJsonBytes,
            firstPromptTitles: pdSql.debug && pdSql.debug.firstPromptTitles
        };
        console[pdSql.promptCount ? 'info' : 'warn']('[NarrativeFlow SQL Debug] PromptDesigner summary', pdSummary);
        console.info('[NarrativeFlow SQL Debug] PromptDesigner raw debug object', pdSql.debug || null);
        console.group('[NarrativeFlow SQL Debug] PromptDesigner import detail');
        if (pdSql.debug && pdSql.debug.latestRowsForSession) console.table(pdSql.debug.latestRowsForSession);
        if (pdSql.debug && pdSql.debug.latestRowsForDialogueSession) console.table(pdSql.debug.latestRowsForDialogueSession);
        if (pdSql.debug && pdSql.debug.latestRowsForUser) console.table(pdSql.debug.latestRowsForUser);
        if (pdSql.debug && pdSql.debug.sharedServerSessionRows) console.table(pdSql.debug.sharedServerSessionRows);
        console.info('PromptDesigner full metadata', pdSql);
        console.groupEnd();
    } else {
        console.warn('[NarrativeFlow SQL Debug] PromptDesigner import metadata is missing from payload.');
    }

    if (data.sourceImports) {
        sourceData = data.sourceImports;
        if (!sourceData.dialogues) sourceData.dialogues = [];
        if (!sourceData.sequences) sourceData.sequences = [];
        if (!sourceData.tasks) sourceData.tasks = [];
        if (!sourceData.menus) sourceData.menus = [];
        if (!sourceData.prompts) sourceData.prompts = [];
        if (!sourceData.importedLogic) sourceData.importedLogic = [];
        if (!sourceData.importedGameplayValues) sourceData.importedGameplayValues = [];
    }

    if (data.logicRegistry) {
        startupValues = data.logicRegistry.startupValues || [];
        gameEndValues = data.logicRegistry.gameEndValues || [];
        if (data.logicRegistry.gameplayValues) gameplayValues = Object.assign(Object.create(null), data.logicRegistry.gameplayValues);
    }

    if (data.metadata) {
        if (Array.isArray(data.metadata.availableLanguages)) nfAvailableLanguages = data.metadata.availableLanguages.map(nfNormalizeLanguageCode);
        if (data.metadata.currentLanguage) nfCurrentLanguage = nfNormalizeLanguageCode(data.metadata.currentLanguage);
        if (data.metadata.taskTabColors) globalTaskTabColors = data.metadata.taskTabColors;
        if (data.metadata.promptTagColors) globalPromptTagColors = data.metadata.promptTagColors;
        if (Array.isArray(data.metadata.flowPages) && data.metadata.flowPages.length > 0) flowPages = data.metadata.flowPages;
        if (data.metadata.flowGroups) flowGroups = data.metadata.flowGroups;
    }

    if (data.toolingData) toolingData = nfNormalizeToolingDataForLoad(data.toolingData);

    if (!flowPages.find(p => p.id === currentCanvasId)) currentCanvasId = flowPages[0] ? flowPages[0].id : 'default';
    storyNodes = nfMapFlowNodesForLoad(data.flowNodes || data.conversations || []);
    const maxId = storyNodes.reduce((acc, node) => {
        const num = parseInt(String(node.id || '').split('_').pop(), 10);
        return isNaN(num) ? acc : Math.max(acc, num);
    }, 0);
    idCounter = maxId + 1;
    selectedNodeIds = [];

    if (typeof renderFlowPages === 'function') renderFlowPages();
    if (typeof nfRenderLanguageControls === 'function') nfRenderLanguageControls();
    if (typeof renderAvailableList === 'function') renderAvailableList();
    if (typeof updateProjectLogic === 'function') updateProjectLogic();
    if (typeof renderNodes === 'function') renderNodes();
    if (rightTab === 'inspector' && typeof renderInspector === 'function') renderInspector();
    requestAnimationFrame(() => {
        if (typeof renderAvailableList === 'function') renderAvailableList();
        if (activeOverTab === 'nodes' && typeof setLeftTab === 'function') setLeftTab(leftTab || 'trans');
        if (typeof renderToolLibrary === 'function') renderToolLibrary();
        if (typeof renderToolEditor === 'function') renderToolEditor();
    });
    console.info('[NarrativeFlow Workspace] applied payload', {
        dialogues: sourceData.dialogues ? sourceData.dialogues.length : 0,
        sequences: sourceData.sequences ? sourceData.sequences.length : 0,
        tasks: sourceData.tasks ? sourceData.tasks.length : 0,
        prompts: sourceData.prompts ? sourceData.prompts.length : 0,
        menus: sourceData.menus ? sourceData.menus.length : 0,
        firstDialogueTitle: sourceData.dialogues && sourceData.dialogues[0] ? sourceData.dialogues[0].title || sourceData.dialogues[0].name || '' : '',
        firstSequenceTitle: sourceData.sequences && sourceData.sequences[0] ? sourceData.sequences[0].title || sourceData.sequences[0].name || '' : '',
        firstTaskTitle: sourceData.tasks && sourceData.tasks[0] ? sourceData.tasks[0].name || sourceData.tasks[0].title || '' : '',
        firstPromptTitle: sourceData.prompts && sourceData.prompts[0] ? sourceData.prompts[0].title || sourceData.prompts[0].name || '' : '',
        firstMenuTitle: sourceData.menus && sourceData.menus[0] ? sourceData.menus[0].text || sourceData.menus[0].title || sourceData.menus[0].name || '' : '',
        storyNodes: storyNodes.length,
        currentCanvasId
    });
}

function nfBuildWorkspacePayload() {
    if (typeof nfSaveCurrentLanguageFields === 'function') nfSaveCurrentLanguageFields();
    const exportToolingData = Object.assign({}, toolingData || {});
    if (exportToolingData.transitions) {
        exportToolingData.transitionLibrary = exportToolingData.transitions;
        delete exportToolingData.transitions;
    }
    return {
        storyVersion: "3.0-ComplexTooling",
        sourceImports: {
            dialogues: sourceData.dialogues || [],
            sequences: sourceData.sequences || [],
            tasks: sourceData.tasks || [],
            menus: sourceData.menus || [],
            prompts: sourceData.prompts || [],
            importedLogic: sourceData.importedLogic || [],
            importedGameplayValues: sourceData.importedGameplayValues || []
        },
        logicRegistry: { startupValues, gameEndValues, gameplayValues },
        metadata: { taskTabColors: globalTaskTabColors, promptTagColors: globalPromptTagColors, flowPages, flowGroups, availableLanguages: nfAvailableLanguages, currentLanguage: nfCurrentLanguage },
        toolingData: exportToolingData,
        flowNodes: storyNodes.map(n => ({
            id: n.id,
            type: n.type || 'conversation',
            title: n.title,
            sourceRef: n.sourceRef,
            color: n.color,
            chainName: n.chainName,
            chainDesc: n.chainDesc,
            chainColor: n.chainColor,
            taskType: n.taskType,
            unlockConditions: (n.unlockConditions || []).filter(c => c.variable),
            onComplete: (n.onComplete || []).filter(c => c.variable),
            isRepeatable: n.isRepeatable,
            repeatVariable: n.repeatVariable,
            isTaskQuest: n.isTaskQuest,
            taskUnlock: n.isTaskQuest ? n.taskUnlock : null,
            taskComplete: n.isTaskQuest ? n.taskComplete : null,
            taskFail: n.isTaskQuest ? n.taskFail : null,
            taskReward: n.isTaskQuest ? n.taskReward : null,
            nextConversations: n.nextConversations || [],
            savePoint: n.savePoint || null,
            canvasId: n.canvasId || 'default',
            snapParent: n.snapParent || null,
            snapChild: n.snapChild || null,
            contextTitle: n.contextTitle || "",
            buttonLabel: n.buttonLabel || "",
            graphPos: { x: Math.round(n.x || 0), y: Math.round(n.y || 0) }
        }))
    };
}

async function nfLoadLatest() {
    try {
        const data = await nfFetchApi('loadLatest');
        nfAuthState.loggedIn = !!data.loggedIn;
        nfAuthState.user = data.user || nfAuthState.user || null;
        nfAuthState.sessions = data.sessions || nfAuthState.sessions || [];
        if (data.authToken) nfSetStoredAuthToken(data.authToken);
        if (nfAuthState.loggedIn && data.sessionId) {
            nfSetCurrentSessionId(data.sessionId, { linkedSourceApp: data.linkedSourceApp || data.latestSessionSource || '', linkedSessionId: data.linkedSessionId || data.sessionId || '' });
            if (data.workspace) nfApplyWorkspacePayload(data.workspace);
            console.info(`[NarrativeFlow Check] did I load the latest server session into Narrative Flow? YES; sessionId=${data.sessionId}; source=${data.latestSessionSource || data.linkedSourceApp || ''}; payloadFound=${data.payloadFound ? 'YES' : 'NO'}`);
        } else {
            nfEnsureSessionId();
            console.info('[NarrativeFlow Check] no logged-in latest server session; using generated local id.');
        }
        nfUpdateAuthUi();
    } catch (err) {
        console.warn('[NarrativeFlow Check] auto auth/session load failed:', err.message);
        nfEnsureSessionId();
        nfUpdateAuthUi();
    }
}

window.addEventListener('DOMContentLoaded', () => {
    console.info('[NarrativeFlow Boot] DOMContentLoaded in NF_ServerBridge.js');
    nfSetAccountMode('login');
    const stored = (() => { try { return localStorage.getItem(NF_SESSION_STORAGE_KEY) || ''; } catch (err) { return ''; } })();
    nfSetCurrentSessionId(stored || nfGenerateLocalSessionId(), {
        linkedSourceApp: (() => { try { return localStorage.getItem(NF_LINKED_APP_STORAGE_KEY) || ''; } catch (err) { return ''; } })(),
        linkedSessionId: (() => { try { return localStorage.getItem(NF_LINKED_SESSION_STORAGE_KEY) || ''; } catch (err) { return ''; } })()
    });
    nfLoadLatest();
});
