// TM_Engine.js - Logic, State Mutations, and Event Handling

document.addEventListener("DOMContentLoaded", () => {
    const qcColor = document.getElementById('quickEntryColor');
    if(qcColor) qcColor.value = getRandomColor();
});

function createNewEntryUI() {
    const nameInput = document.getElementById('quickEntryName');
    const colorInput = document.getElementById('quickEntryColor');
    
    let entryName = nameInput ? nameInput.value.trim() : '';
    if(!entryName) entryName = 'UNTITLED ENTRY';
    
    let entryColor = colorInput ? colorInput.value : getRandomColor();

    const newEntry = createBaseEntry({ tab: state.activeTab, name: entryName, color: entryColor });
    state.globalCustomFields.forEach(gcf => {
        newEntry.customGameplayValues.push({ fieldId: gcf.id, key: gcf.key, op: gcf.op, val: gcf.val, hideVisual: false });
    });
    state.entries.push(newEntry);
    
    state.focusedEntryId = newEntry.id;
    markEdited(newEntry.id);
    if (typeof fullRender === 'function') fullRender();
    
    if(nameInput) nameInput.value = '';
    if(colorInput) colorInput.value = getRandomColor();

    setTimeout(() => {
        const card = document.getElementById(`task-card-${newEntry.id}`);
        if(card) {
            card.scrollIntoView({ behavior: 'smooth', block: 'center' });
            card.animate([
                { borderColor: '#555' },
                { borderColor: '#00ff88', boxShadow: '0 0 30px rgba(0,255,136,0.6)' },
                { borderColor: '#555', boxShadow: 'none' }
            ], { duration: 1500 });
        }
    }, 100);
    if (typeof showNotification === 'function') showNotification("New Entry Created");
}

function handleDummyChoice(wantsDummyData) {
    localStorage.setItem('hideDummyPrompt', 'true');
    if (wantsDummyData) {
        localStorage.setItem('useDummyData', 'true');
        if (typeof loadInitialData === 'function') loadInitialData();
    } else {
        localStorage.setItem('useDummyData', 'false');
        state.entries = [];
    }
    const overlay = document.getElementById('prompt-overlay');
    if (overlay) overlay.style.display = 'none';
    finishInit();
}

function finishInit() {
    if (!state.tabs.includes(state.activeTab)) {
        state.activeTab = state.tabs[0] || 'Tasks';
    }
    if (typeof renderTabs === 'function') renderTabs();
    handleTaskTypeChange();
    if (typeof renderSidebarCgvList === 'function') renderSidebarCgvList();
    syncFocus();
    if (typeof fullRender === 'function') fullRender();
    if (typeof setupKeyboard === 'function') setupKeyboard();
}

function setScrollBlock() {
    isScrollingProgrammatically = true;
    clearTimeout(scrollBlockTimer);
    scrollBlockTimer = setTimeout(() => { isScrollingProgrammatically = false; }, 800);
}

function markFocusedEdited() {
    if(state.focusedEntryId) {
        state.editedNodes.add(state.focusedEntryId);
        if (typeof tmMarkAppDirty === 'function') tmMarkAppDirty();
        if (typeof renderMinimap === 'function') renderMinimap();
    }
}

function markEdited(id) {
    if(id) {
        state.editedNodes.add(id);
        if (typeof tmMarkAppDirty === 'function') tmMarkAppDirty();
        if (typeof renderMinimap === 'function') renderMinimap();
    }
}

function toggleAuthorPanel(id) {
    const content = document.getElementById(`panel-${id}`);
    if(!content) return;
    const header = content.previousElementSibling;
    content.classList.toggle('hidden');
    header.classList.toggle('collapsed');
}

function promptClearTab() {
    document.getElementById('clear-tab-name').innerText = `[ ${state.activeTab} ]`;
    document.getElementById('clear-overlay').style.display = 'flex';
}

function closeClearPrompt() {
    document.getElementById('clear-overlay').style.display = 'none';
}

function confirmClearTab() {
    state.entries = state.entries.filter(e => e.tab !== state.activeTab);
    closeClearPrompt();
    if (typeof fullRender === 'function') fullRender();
    if (typeof showNotification === 'function') showNotification(`Cleared All Entries in ${state.activeTab}`);
}

function toggleCgvGenerator() {
    const gen = document.getElementById('cgvGenerator');
    gen.classList.toggle('hidden');
    if(!gen.classList.contains('hidden')) {
        document.getElementById('cgvGenTitle').innerText = 'Define Core Value';
        document.getElementById('cgvEditId').value = '';
        document.getElementById('cgvTitle').value = '';
        document.getElementById('cgvKey').value = '';
        document.getElementById('cgvVal').value = '1';
        document.getElementById('cgvOp').selectedIndex = 0;
        document.getElementById('cgvColor').value = typeof getRandomColor === 'function' ? getRandomColor() : '#00f2ff';
        document.getElementById('cgvSaveBtn').innerText = 'ADD VALUE';
        document.getElementById('cgvTitle').focus();
    }
}

function triggerQuickAddGlobalCgv() { toggleCgvGenerator(); }

function saveGlobalCgv() {
    const editId = document.getElementById('cgvEditId').value;
    const title = document.getElementById('cgvTitle').value.trim();
    const key = document.getElementById('cgvKey').value.trim();
    const op = document.getElementById('cgvOp').value;
    const val = document.getElementById('cgvVal').value.trim();
    const color = document.getElementById('cgvColor').value;

    if(!key || !title) return (typeof showNotification === 'function') ? showNotification("Key and Title required", true) : null;

    if (editId) {
        const schema = state.globalCustomFields.find(c => c.id === editId);
        if(schema) { schema.title = title; schema.key = key; schema.op = op; schema.val = val; schema.color = color; }
        state.entries.forEach(e => {
            if(!e.customGameplayValues) e.customGameplayValues = [];
            const cv = e.customGameplayValues.find(c => c.fieldId === editId);
            if(cv) { cv.key = key; cv.op = op; cv.val = val; }
        });
        if (typeof showNotification === 'function') showNotification("Global Core Value Updated");
    } else {
        const newId = crypto.randomUUID();
        state.globalCustomFields.push({ id: newId, title, key, op, val, color });
        state.entries.forEach(e => {
            if(!e.customGameplayValues) e.customGameplayValues = [];
            e.customGameplayValues.push({ fieldId: newId, key, op, val, hideVisual: false });
        });
        if (typeof showNotification === 'function') showNotification("Global Core Value Added");
    }
    document.getElementById('cgvGenerator').classList.add('hidden');
    if (typeof renderSidebarCgvList === 'function') renderSidebarCgvList();
    if (typeof fullRender === 'function') fullRender();
}

function editGlobalCgv(cgvId) {
    const schema = state.globalCustomFields.find(c => c.id === cgvId);
    if(!schema) return;
    document.getElementById('cgvGenerator').classList.remove('hidden');
    document.getElementById('cgvGenTitle').innerText = 'Edit Core Value';
    document.getElementById('cgvEditId').value = schema.id;
    document.getElementById('cgvTitle').value = schema.title;
    document.getElementById('cgvKey').value = schema.key;
    document.getElementById('cgvOp').value = schema.op;
    document.getElementById('cgvVal').value = schema.val;
    document.getElementById('cgvColor').value = schema.color;
    document.getElementById('cgvSaveBtn').innerText = 'APPLY EDIT';
    document.getElementById('cgvTitle').focus();
}

function deleteGlobalCgv(cgvId) {
    if(!confirm("Delete this Global Value? It will be removed from all entries.")) return;
    state.globalCustomFields = state.globalCustomFields.filter(c => c.id !== cgvId);
    state.entries.forEach(e => {
        if(e.customGameplayValues) {
            e.customGameplayValues = e.customGameplayValues.filter(c => c.fieldId !== cgvId);
        }
    });
    if (typeof renderSidebarCgvList === 'function') renderSidebarCgvList();
    if (typeof fullRender === 'function') fullRender();
    if (typeof showNotification === 'function') showNotification("Global Core Value Deleted");
}

function updateCgvOverride(taskId, fieldId, field, value) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry) {
        if(!entry.customGameplayValues) entry.customGameplayValues = [];
        let cv = entry.customGameplayValues.find(c => c.fieldId === fieldId);
        if(!cv) {
            const gcf = state.globalCustomFields.find(g => g.id === fieldId);
            cv = { fieldId, key: gcf.key, op: gcf.op, val: gcf.val, hideVisual: false };
            entry.customGameplayValues.push(cv);
        }
        cv[field] = value;
        markEdited(taskId);
        if (typeof tmMarkAppDirty === 'function') tmMarkAppDirty();
        if (typeof fullRender === 'function') fullRender();
    }
}

function toggleObjectiveCollapse(taskId, objIndex) {
    const task = state.entries.find(e => e.id === taskId);
    if(task && task.objectives && task.objectives[objIndex]) {
        task.objectives[objIndex].isCollapsed = !task.objectives[objIndex].isCollapsed;
        if(state.focusedEntryId === taskId && typeof renderAuthorObjectives === 'function') renderAuthorObjectives();
        if(typeof renderTasksSilently === 'function') renderTasksSilently();
    }
}

function toggleEntryCollapse(taskId) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry) { 
        entry.collapsed = !entry.collapsed; 
        if (typeof renderTasksSilently === 'function') renderTasksSilently(); 
    }
}

function toggleEntryCollapseOnly(taskId) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry) { 
        entry.collapsed = false; 
        if (typeof renderTasksSilently === 'function') renderTasksSilently(); 
    }
}

function setEntryCollapseDeep(taskId, isCollapsed) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry) {
        entry.collapsed = isCollapsed;
        if(!entry.subCategoriesCollapsed) entry.subCategoriesCollapsed = {};
        Object.keys(entry.subCategoriesCollapsed).forEach(k => entry.subCategoriesCollapsed[k] = isCollapsed);
        
        if (entry.objectives) {
            entry.objectives.forEach(obj => {
                obj.isCollapsed = isCollapsed;
                if(obj.subCollapsed) {
                    Object.keys(obj.subCollapsed).forEach(k => obj.subCollapsed[k] = isCollapsed);
                }
            });
        }

        if (state.focusedEntryId === taskId) {
            const headers = document.querySelectorAll('.editor-panel .panel-header');
            const contents = document.querySelectorAll('.editor-panel .panel-content');
            headers.forEach(h => isCollapsed ? h.classList.add('collapsed') : h.classList.remove('collapsed'));
            contents.forEach(c => isCollapsed ? c.classList.add('hidden') : c.classList.remove('hidden'));
            if (typeof renderAuthorObjectives === 'function') renderAuthorObjectives();
        }

        if (typeof renderTasksSilently === 'function') renderTasksSilently();
    }
}

function setGlobalCollapse(isCollapsed) {
    state.entries.forEach(entry => {
        entry.collapsed = isCollapsed;
        if(!entry.subCategoriesCollapsed) entry.subCategoriesCollapsed = {};
        Object.keys(entry.subCategoriesCollapsed).forEach(k => entry.subCategoriesCollapsed[k] = isCollapsed);
        if (entry.objectives) {
            entry.objectives.forEach(obj => {
                obj.isCollapsed = isCollapsed;
                if(obj.subCollapsed) {
                    Object.keys(obj.subCollapsed).forEach(k => obj.subCollapsed[k] = isCollapsed);
                }
            });
        }
    });

    const headers = document.querySelectorAll('.editor-panel .panel-header');
    const contents = document.querySelectorAll('.editor-panel .panel-content');
    headers.forEach(h => isCollapsed ? h.classList.add('collapsed') : h.classList.remove('collapsed'));
    contents.forEach(c => isCollapsed ? c.classList.add('hidden') : c.classList.remove('hidden'));

    if (typeof renderAuthorObjectives === 'function') renderAuthorObjectives();
    if (typeof renderTasksSilently === 'function') renderTasksSilently();
    if (typeof showNotification === 'function') showNotification(isCollapsed ? "Collapsed All Tabs" : "Expanded All Tabs");
}

function toggleSubCategory(taskId, catName) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry) {
        if(!entry.subCategoriesCollapsed) entry.subCategoriesCollapsed = {};
        entry.subCategoriesCollapsed[catName] = !entry.subCategoriesCollapsed[catName];
        if (typeof renderTasksSilently === 'function') renderTasksSilently();
    }
}

function hideGameplayValueVisual(taskId, fieldId, isCustom) {
    const task = state.entries.find(e => e.id === taskId);
    if(!task) return;
    if(isCustom) {
        const cv = task.customGameplayValues?.find(c => c.fieldId === fieldId);
        if(cv) cv.hideVisual = true;
    }
    markEdited(taskId);
    if (typeof fullRender === 'function') fullRender();
}

function createNewEntryWrapper(targetTab, defaultName = "") {
    const newEntry = typeof createBaseEntry === 'function' ? createBaseEntry({ tab: targetTab, name: defaultName }) : { id: crypto.randomUUID(), tab: targetTab, name: defaultName, customGameplayValues: [] };
    state.globalCustomFields.forEach(gcf => {
        newEntry.customGameplayValues.push({ fieldId: gcf.id, key: gcf.key, op: gcf.op, val: gcf.val, hideVisual: false });
    });
    state.entries.push(newEntry);
    return newEntry.id;
}

function addNewTabFromPanel() {
    const input = document.getElementById('newTabInput');
    const name = input.value;
    if(name && name.trim() !== '') {
        const cleanName = name.trim();
        if(!state.tabs.includes(cleanName)) {
            state.tabs.push(cleanName);
            state.tabColors[cleanName] = typeof getRandomColor === 'function' ? getRandomColor() : '#fff';
        }
        input.value = '';
        state.activeTab = cleanName;
        syncFocus();
        if (typeof fullRender === 'function') fullRender();
    }
}

function deleteTab(tabName) {
    if(confirm(`Delete Tab [${tabName}]? This will not delete the entries, but they will be orphaned.`)) {
        state.tabs = state.tabs.filter(t => t !== tabName);
        if(state.activeTab === tabName) state.activeTab = state.tabs[0] || '';
        syncFocus();
        if (typeof fullRender === 'function') fullRender();
    }
}

function switchTab(tabName) {
    state.activeTab = tabName;
    document.getElementById('search').value = '';
    syncFocus();
    if (typeof fullRender === 'function') fullRender();
}

function syncFocus() {
    const currentTabEntries = state.entries.filter(e => e.tab === state.activeTab);
    if (currentTabEntries.length === 0 && state.activeTab) {
        const newId = createNewEntryWrapper(state.activeTab);
        if (state.focusedEntryId !== newId) {
            state.prevFocusedEntryId = state.focusedEntryId;
            state.focusedEntryId = newId;
        }
    } else if (currentTabEntries.length > 0) {
        const exists = currentTabEntries.find(e => e.id === state.focusedEntryId);
        if (!exists) {
            if (state.focusedEntryId !== currentTabEntries[0].id) {
                state.prevFocusedEntryId = state.focusedEntryId;
                state.focusedEntryId = currentTabEntries[0].id;
            }
        }
    }
}

function moveEntryPosition(id, newIndexStr) {
    const newIndex = parseInt(newIndexStr);
    const entry = state.entries.find(e => e.id === id);
    if(!entry) return;
    state.entries = state.entries.filter(e => e.id !== id);
    const remainingTabEntries = state.entries.filter(e => e.tab === state.activeTab);
    remainingTabEntries.splice(newIndex, 0, entry);
    const otherEntries = state.entries.filter(e => e.tab !== state.activeTab);
    state.entries = [...otherEntries, ...remainingTabEntries];
    markEdited(id);
    if (typeof fullRender === 'function') fullRender();
}

function updateTaskBool(id, field, value) {
    const entry = state.entries.find(e => e.id === id);
    if(entry) {
        entry[field] = value;
        markEdited(id);
        recalculateTags();
        if (typeof renderTasksSilently === 'function') renderTasksSilently(); 
    }
}

function updateLogicArray(id, arrayName, index, field, value) {
    const entry = state.entries.find(e => e.id === id);
    if(entry && entry[arrayName] && entry[arrayName][index]) {
        entry[arrayName][index][field] = value;
        markEdited(id);
        recalculateTags();
        if (typeof renderSidebar === 'function') renderSidebar();
        if (typeof refreshAllGlows === 'function') refreshAllGlows();
    }
}

function addLogicRow(id, arrayName) {
    const entry = state.entries.find(e => e.id === id);
    if(entry) {
        if(!entry[arrayName]) entry[arrayName] = [];
        entry[arrayName].push({ key: '', op: '==', val: '1', context: 'Standard' });
        markEdited(id);
        recalculateTags();
        if (typeof fullRender === 'function') fullRender();
    }
}

function removeLogicRow(id, arrayName, index) {
    const entry = state.entries.find(e => e.id === id);
    if(entry) {
        entry[arrayName].splice(index, 1);
        markEdited(id);
        recalculateTags();
        if (typeof fullRender === 'function') fullRender();
    }
}

function formatTagsInput(inputEl) {
    let val = inputEl.value;
    let tags = val.split(',').map(t => t.trim()).filter(t => t);
    inputEl.value = tags.join(', ');
}

function openAddTagModal(taskId) {
    if(!taskId) return;
    document.getElementById('addTagTaskId').value = taskId;
    document.getElementById('addTagInput').value = '';
    const overlay = document.getElementById('add-tag-overlay');
    if(overlay) overlay.style.display = 'flex';
    setTimeout(() => {
        const input = document.getElementById('addTagInput');
        if(input) input.focus();
    }, 50);
}

function confirmAddTags() {
    const taskId = document.getElementById('addTagTaskId').value;
    const val = document.getElementById('addTagInput').value;
    const newTags = val.split(',').map(t => t.trim()).filter(t => t);
    const entry = state.entries.find(e => e.id === taskId);
    if(entry) {
        entry.tags = [...new Set([...(entry.tags || []), ...newTags])];
        markEdited(taskId);
        if(state.focusedEntryId === taskId) {
            const tagsInput = document.getElementById('taskTags');
            if(tagsInput) tagsInput.value = entry.tags.join(', ');
        }
        if (typeof fullRender === 'function') fullRender();
    }
    const overlay = document.getElementById('add-tag-overlay');
    if(overlay) overlay.style.display = 'none';
}

function removeTag(taskId, tagIndex) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.tags) {
        entry.tags.splice(tagIndex, 1);
        markEdited(taskId);
        if(state.focusedEntryId === taskId) {
            const tagsInput = document.getElementById('taskTags');
            if(tagsInput) tagsInput.value = entry.tags.join(', ');
        }
        if (typeof fullRender === 'function') fullRender();
    }
}

function getObjectiveLabel1(type) { 
    return typeof OBJECTIVE_TYPES !== 'undefined' && OBJECTIVE_TYPES[type] ? OBJECTIVE_TYPES[type].l1 : 'Key'; 
}

function getObjectiveLabel2(type) { 
    return typeof OBJECTIVE_TYPES !== 'undefined' && OBJECTIVE_TYPES[type] ? OBJECTIVE_TYPES[type].l2 : 'Value'; 
}

function addAuthorObjective() {
    const id = document.getElementById('taskId').value;
    addMiddleObjective(id);
}

function removeAuthorObjective(index) {
    const id = document.getElementById('taskId').value;
    removeMiddleObjective(id, index);
}

function addMiddleObjective(taskId) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry) {
        if(!entry.objectives) entry.objectives = [];
        
        let newObj = {
            id: crypto.randomUUID(),
            text: 'New Objective', 
            targets: [{
                id: crypto.randomUUID(), 
                type: 'Collect Item', 
                val1: '', 
                val2: '', 
                val3: '', 
                val4: '', 
                useDesc: true, 
                desc: ''
            }],
            calledExternally: false, externallyCalled: false,
            isMandatory: true,
            isRepeatable: false, repeatableCond: {key: '', op: '==', val: '1'},
            isAbandonable: false, abandonableCond: {key: '', op: '==', val: '1'},
            conditions: [], stateChanges: [],
            isCollapsed: false, phase: 'Single Phase',
            subCollapsed: { conditions: true, stateChanges: true }
        };
        
        if (typeof normalizeObjective === 'function') {
            newObj = normalizeObjective(newObj);
        }

        entry.objectives.push(newObj);
        markEdited(taskId);
        if (typeof fullRender === 'function') fullRender();
    }
}

function updateMiddleObjective(taskId, index, field, value) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.objectives[index]) {
        entry.objectives[index][field] = value;
        markEdited(taskId);
        
        if (typeof value === 'boolean' || field === 'phase') {
            if (typeof fullRender === 'function') fullRender();
        } else {
            recalculateTags();
            if (typeof renderSidebar === 'function') renderSidebar();
            if (typeof refreshAllGlows === 'function') refreshAllGlows();
            
            const obj = entry.objectives[index];
            const isInvalid = !obj.text || obj.text.toString().trim() === '' || obj.targets.some(t => {
                if (!t.val1 || t.val1.toString().trim() === '') return true;
                if (typeof OBJECTIVE_TYPES !== 'undefined' && OBJECTIVE_TYPES[t.type]) {
                    if (OBJECTIVE_TYPES[t.type].l2 !== 'N/A' && (!t.val2 || t.val2.toString().trim() === '')) return true;
                    if (OBJECTIVE_TYPES[t.type].l3 !== 'N/A' && (!t.val3 || t.val3.toString().trim() === '')) return true;
                    if (OBJECTIVE_TYPES[t.type].l4 !== 'N/A' && (!t.val4 || t.val4.toString().trim() === '')) return true;
                }
                if (t.useDesc === true && (!t.desc || t.desc.toString().trim() === '')) return true;
                return false;
            });
            
            ['middle', 'author'].forEach(prefix => {
                const card = document.getElementById(`objective-card-${prefix}-${taskId}-${index}`);
                if (card) {
                    if (isInvalid) card.classList.add('invalid-objective');
                    else card.classList.remove('invalid-objective');
                }
            });
        }
    }
}

function updateMiddleObjBool(taskId, index, value) {
    updateMiddleObjective(taskId, index, 'useDesc', value);
}

function removeMiddleObjective(taskId, index) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry) {
        entry.objectives.splice(index, 1);
        markEdited(taskId);
        if (typeof fullRender === 'function') fullRender();
    }
}

function addObjectiveTarget(taskId, objIndex) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.objectives[objIndex]) {
        if(!entry.objectives[objIndex].targets && typeof normalizeObjective === 'function') {
            entry.objectives[objIndex] = normalizeObjective(entry.objectives[objIndex]);
        }
        entry.objectives[objIndex].targets.push({ 
            id: crypto.randomUUID(), 
            type: 'Collect Item', 
            val1: '', 
            val2: '', 
            val3: '', 
            val4: '', 
            useDesc: true, 
            desc: '' 
        });
        markEdited(taskId);
        if (typeof fullRender === 'function') fullRender();
    }
}

function removeObjectiveTarget(taskId, objIndex, targetIndex) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.objectives[objIndex] && entry.objectives[objIndex].targets) {
        entry.objectives[objIndex].targets.splice(targetIndex, 1);
        markEdited(taskId);
        if (typeof fullRender === 'function') fullRender();
    }
}

function updateObjectiveTarget(taskId, objIndex, targetIndex, field, value) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.objectives[objIndex] && entry.objectives[objIndex].targets) {
        entry.objectives[objIndex].targets[targetIndex][field] = value;
        markEdited(taskId);
        
        if(field === 'type' || field === 'useDesc') {
            if(field === 'type') {
                entry.objectives[objIndex].targets[targetIndex].val1 = '';
                entry.objectives[objIndex].targets[targetIndex].val2 = '';
                entry.objectives[objIndex].targets[targetIndex].val3 = '';
                entry.objectives[objIndex].targets[targetIndex].val4 = '';
            }
            if (typeof fullRender === 'function') fullRender();
        } else {
            recalculateTags();
            if (typeof renderSidebar === 'function') renderSidebar();
            if (typeof refreshAllGlows === 'function') refreshAllGlows();
            
            const obj = entry.objectives[objIndex];
            const isInvalid = !obj.text || obj.text.toString().trim() === '' || obj.targets.some(t => {
                if (!t.val1 || t.val1.toString().trim() === '') return true;
                if (typeof OBJECTIVE_TYPES !== 'undefined' && OBJECTIVE_TYPES[t.type]) {
                    if (OBJECTIVE_TYPES[t.type].l2 !== 'N/A' && (!t.val2 || t.val2.toString().trim() === '')) return true;
                    if (OBJECTIVE_TYPES[t.type].l3 !== 'N/A' && (!t.val3 || t.val3.toString().trim() === '')) return true;
                    if (OBJECTIVE_TYPES[t.type].l4 !== 'N/A' && (!t.val4 || t.val4.toString().trim() === '')) return true;
                }
                if (t.useDesc === true && (!t.desc || t.desc.toString().trim() === '')) return true;
                return false;
            });
            
            ['middle', 'author'].forEach(prefix => {
                const card = document.getElementById(`objective-card-${prefix}-${taskId}-${objIndex}`);
                if (card) {
                    if (isInvalid) card.classList.add('invalid-objective');
                    else card.classList.remove('invalid-objective');
                }
            });
        }
    }
}

function updateAuthorTarget(objIndex, targetIndex, field, value) {
    updateObjectiveTarget(state.focusedEntryId, objIndex, targetIndex, field, value);
}

function jumpToObjective(taskId, objId) {
    const task = state.entries.find(e => e.id === taskId);
    if(task) {
        state.activeTab = task.tab;
        task.collapsed = false;
        if (typeof focusEntryUI === 'function') focusEntryUI(taskId);
        if (typeof fullRender === 'function') fullRender();
        
        setTimeout(() => {
            const objIndex = task.objectives.findIndex(o => o.id === objId);
            if(objIndex !== -1) {
                const card = document.getElementById(`objective-card-middle-${taskId}-${objIndex}`);
                if(card) {
                    card.scrollIntoView({behavior: 'smooth', block: 'center'});
                    card.animate([
                        { borderColor: '#333' },
                        { borderColor: '#00ff88', boxShadow: '0 0 30px rgba(0,255,136,0.6)' },
                        { borderColor: '#333', boxShadow: 'none' }
                    ], { duration: 1500 });
                }
            }
        }, 150);
    }
}

function updateObjCond(taskId, objIndex, condName, field, value) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.objectives[objIndex]) {
        if(!entry.objectives[objIndex][condName]) {
            entry.objectives[objIndex][condName] = {key: '', op: '==', val: '1'};
        }
        entry.objectives[objIndex][condName][field] = value;
        markEdited(taskId);
        recalculateTags();
        if (typeof renderSidebar === 'function') renderSidebar();
        if (typeof refreshAllGlows === 'function') refreshAllGlows();
    }
}

function toggleObjSub(taskId, objIndex, catName) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.objectives[objIndex]) {
        if(!entry.objectives[objIndex].subCollapsed) entry.objectives[objIndex].subCollapsed = {conditions: true, stateChanges: true};
        entry.objectives[objIndex].subCollapsed[catName] = !entry.objectives[objIndex].subCollapsed[catName];
        if (typeof fullRender === 'function') fullRender();
    }
}

function addObjLogicRow(taskId, objIndex, arrayName) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.objectives[objIndex]) {
        if(!entry.objectives[objIndex][arrayName]) entry.objectives[objIndex][arrayName] = [];
        entry.objectives[objIndex][arrayName].push({ key: '', op: '==', val: '1', context: 'Standard' });
        markEdited(taskId);
        recalculateTags();
        if (typeof fullRender === 'function') fullRender();
    }
}

function removeObjLogicRow(taskId, objIndex, arrayName, logicIndex) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.objectives[objIndex] && entry.objectives[objIndex][arrayName]) {
        entry.objectives[objIndex][arrayName].splice(logicIndex, 1);
        markEdited(taskId);
        recalculateTags();
        if (typeof fullRender === 'function') fullRender();
    }
}

function updateObjLogicArray(taskId, objIndex, arrayName, logicIndex, field, value) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.objectives[objIndex] && entry.objectives[objIndex][arrayName]) {
        entry.objectives[objIndex][arrayName][logicIndex][field] = value;
        markEdited(taskId);
        recalculateTags();
        if (typeof renderSidebar === 'function') renderSidebar();
        if (typeof refreshAllGlows === 'function') refreshAllGlows();
    }
}

function openPhaseModal(taskId, objIndex) {
    document.getElementById('addPhaseTaskId').value = taskId;
    document.getElementById('addPhaseObjIndex').value = objIndex;
    document.getElementById('addPhaseInput').value = '';

    const list = document.getElementById('existingPhasesList');
    if (list) {
        const phases = state.phases || ['Single Phase'];
        list.innerHTML = phases.map(p => `
            <div class="text-[10px] text-gray-300 hover:bg-[#222] hover:text-white cursor-pointer px-2 py-1 rounded transition-colors" onclick="document.getElementById('addPhaseInput').value = '${escapeHtml(p).replace(/'/g, "\\'")}'">${escapeHtml(p)}</div>
        `).join('');
    }

    const overlay = document.getElementById('phase-overlay');
    if (overlay) overlay.style.display = 'flex';
    setTimeout(() => {
        const input = document.getElementById('addPhaseInput');
        if (input) input.focus();
    }, 50);
}

function closePhaseModal() {
    const overlay = document.getElementById('phase-overlay');
    if (overlay) overlay.style.display = 'none';
}

function confirmAddPhase() {
    const inputEl = document.getElementById('addPhaseInput');
    const taskIdEl = document.getElementById('addPhaseTaskId');
    const objIndexEl = document.getElementById('addPhaseObjIndex');

    if (!inputEl || !taskIdEl || !objIndexEl) return;

    const input = inputEl.value.trim();
    const taskId = taskIdEl.value;
    const objIndex = parseInt(objIndexEl.value);

    if (!input) {
        if (typeof showNotification === 'function') showNotification("Phase name required.", true);
        return;
    }

    if (!state.phases) state.phases = ['Single Phase'];
    if (!state.phases.includes(input)) {
        state.phases.push(input);
    }

    updateMiddleObjective(taskId, objIndex, 'phase', input);
    closePhaseModal();
}

function updateRewardToggle(taskId, category, isEnabled) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.rewards && entry.rewards[category]) {
        entry.rewards[category].enabled = isEnabled;
        markEdited(taskId);
        if (typeof fullRender === 'function') fullRender();
    }
}

function addRewardItem(taskId, category, arrayName) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.rewards && entry.rewards[category]) {
        if(!entry.rewards[category][arrayName]) entry.rewards[category][arrayName] = [];
        
        let newObj = {};
        if (category === 'vault') newObj = { category: 'Standard', id: '', isVariable: false, fixed: 1, min: 1, max: 2 };
        if (category === 'arsenal') newObj = { method: 'Direct Item', id: '', qty: 1, autoEquip: false, tableId: '', pulls: 1 };
        if (category === 'ladder' && arrayName === 'points') newObj = { type: 'Global XP', target: '', amount: 100 };
        if (category === 'ladder' && arrayName === 'status') newObj = { type: 'Title', id: '' };
        if (category === 'story' && arrayName === 'relationships') newObj = { type: 'NPC', id: '', shift: 1 };
        if (category === 'story' && arrayName === 'world') newObj = { type: 'Codex Entry', id: '', isBool: true, stateBool: true, stateInt: 1 };
        if (category === 'hooks') newObj = { type: 'Gacha Ticket', target: '', isTimeBased: false, duration: 60, quantity: 1 };
        if (category === 'penalties') newObj = { trigger: 'On Quest Fail', type: 'Currency Loss', id: '', amount: 1 };

        entry.rewards[category][arrayName].push(newObj);
        markEdited(taskId);
        if (typeof fullRender === 'function') fullRender();
    }
}

function removeRewardItem(taskId, category, arrayName, index) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.rewards && entry.rewards[category] && entry.rewards[category][arrayName]) {
        entry.rewards[category][arrayName].splice(index, 1);
        markEdited(taskId);
        if (typeof fullRender === 'function') fullRender();
    }
}

function updateRewardItem(taskId, category, arrayName, index, field, value) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry && entry.rewards && entry.rewards[category] && entry.rewards[category][arrayName]) {
        entry.rewards[category][arrayName][index][field] = value;
        markEdited(taskId);
        if (typeof field === 'boolean' || field === 'isVariable' || field === 'method' || field === 'isBool' || field === 'isTimeBased' || field === 'type' || field === 'category' || field === 'trigger') {
            if (typeof fullRender === 'function') fullRender(); 
        }
    }
}

function addAuthorArrayItem(arrName) { 
    addLogicRow(state.focusedEntryId, arrName); 
    if(arrName === 'mapAnchors' && typeof renderAuthorMapAnchors === 'function') renderAuthorMapAnchors();
    if(arrName === 'mediaHooks' && typeof renderAuthorMediaHooks === 'function') renderAuthorMediaHooks();
}

function addAuthorDependency(depId) {
    if(depId && state.focusedEntryId) {
        addDependency(state.focusedEntryId, depId);
    }
}

function updateBranchData(taskId, field, value) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry) {
        entry[field] = value;
        markEdited(taskId);
        if(state.focusedEntryId === taskId) {
            const el = document.getElementById('task' + field.charAt(0).toUpperCase() + field.slice(1));
            if (el) el.value = value;
        }
        if (typeof renderTasksSilently === 'function') renderTasksSilently();
    }
}

function updateTimeData(taskId, field, value) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry) {
        entry[field] = value;
        markEdited(taskId);
        if(state.focusedEntryId === taskId) {
            const el = document.getElementById('task' + field.charAt(0).toUpperCase() + field.slice(1));
            if (el) el.value = value;
        }
        if (typeof renderTasksSilently === 'function') renderTasksSilently();
    }
}

function handleTaskTypeChange() {
    const type = document.getElementById('taskType').value;
    const chainProps = document.getElementById('chainPropertiesGroup');
    const input = document.getElementById('chainNameInput');
    const select = document.getElementById('chainNameSelect');
    
    const taskIdInput = document.getElementById('taskId');
    if (!taskIdInput || !taskIdInput.value) { lastTaskType = type; }

    if (type === 'root' || type === 'node' || type === 'endpoint') {
        if(chainProps) chainProps.style.display = 'block';
        if (type === 'root') {
            if(input) input.classList.remove('hidden');
            if(select) select.classList.add('hidden');
        } else {
            if(input) input.classList.add('hidden');
            if(select) select.classList.remove('hidden');
            if (typeof populateChainSelect === 'function') populateChainSelect();
            updateChainDetailsFromSelection();
        }
    } else {
        if(chainProps) chainProps.style.display = 'none';
        if(input) input.classList.add('hidden');
        if(select) select.classList.add('hidden');
    }
}

function updateChainDetailsFromSelection() {
    const select = document.getElementById('chainNameSelect');
    if(!select) return;
    const selectedChain = select.value;
    const chainTask = state.entries.find(t => t.chainName === selectedChain);
    if (chainTask) {
        if (chainTask.chainColor && typeof setChainColor === 'function') setChainColor(chainTask.chainColor);
        const descInput = document.getElementById('chainDescInput');
        if (chainTask.chainDesc !== undefined && descInput) descInput.value = chainTask.chainDesc;
    }
}

function resetForm() {
    const form = document.getElementById('taskForm');
    if(form) form.reset();
    const taskIdInput = document.getElementById('taskId');
    if(taskIdInput) taskIdInput.value = '';
    
    const editorTitle = document.getElementById('editorTitle');
    if(editorTitle) editorTitle.innerText = 'INITIALIZE NEW TASK';
    
    const submitBtn = document.getElementById('submitBtn');
    if(submitBtn) submitBtn.innerText = 'UPDATE NODE';
    
    const registrySelect = document.getElementById('registrySelect');
    if(registrySelect) registrySelect.value = state.activeTab;
    
    const taskType = document.getElementById('taskType');
    if(taskType) taskType.value = lastTaskType;
    handleTaskTypeChange();
    
    const chainDescInput = document.getElementById('chainDescInput');
    if(chainDescInput) chainDescInput.value = '';
    
    const taskIconSelect = document.getElementById('taskIconSelect');
    if(taskIconSelect) taskIconSelect.selectedIndex = 0;
    
    const cgvGen = document.getElementById('cgvGenerator');
    if(cgvGen) cgvGen.classList.add('hidden');
    
    ['authorObjectivesContainer', 'authorConditionsContainer', 'authorStateChangesContainer', 'authorCgvContainer', 'authorDependenciesContainer'].forEach(id => {
        const el = document.getElementById(id);
        if(el) el.innerHTML = '';
    });

    if (typeof setRandomColor === 'function') setRandomColor();
    if (typeof setChainColor === 'function') setChainColor(getRandomColor());
}

function recalculateTags() {
    state.globalTags = {};

    state.entries.forEach(entry => {
        const addTag = (type, key) => {
            if(!key || key === 'Null') return;
            if(!state.globalTags[key]) state.globalTags[key] = { conds: [], states: [], gameplay: [] };
            state.globalTags[key][type].push(entry.id);
        };

        if(entry.conditions) entry.conditions.forEach(c => addTag('conds', c.key?.trim()));
        if(entry.stateChanges) entry.stateChanges.forEach(s => addTag('states', s.key?.trim()));

        addTag('gameplay', entry.unlockCondition?.key?.trim());
        addTag('gameplay', entry.completeCondition?.key?.trim());
        addTag('gameplay', entry.failCondition?.key?.trim());
        addTag('gameplay', entry.rewardCondition?.key?.trim());
        
        if(entry.customGameplayValues) {
            entry.customGameplayValues.forEach(cv => addTag('gameplay', cv.key?.trim()));
        }

        if(entry.objectives) {
            entry.objectives.forEach(obj => {
                if(obj.conditions) obj.conditions.forEach(c => addTag('conds', c.key?.trim()));
                if(obj.stateChanges) obj.stateChanges.forEach(s => addTag('states', s.key?.trim()));
                if(obj.repeatableCond && obj.isRepeatable) addTag('gameplay', obj.repeatableCond.key?.trim());
                if(obj.abandonableCond && obj.isAbandonable) addTag('gameplay', obj.abandonableCond.key?.trim());
            });
        }
    });
}

function handleTitleClick(e, id) {
    if (e.detail === 1) {
        titleClickTimers[id] = setTimeout(() => {
            const entry = state.entries.find(x => x.id === id);
            if(entry && entry.collapsed) {
                toggleEntryCollapseOnly(id);
            } else {
                toggleEntryCollapse(id);
            }
        }, 200);
    } else if (e.detail === 2) {
        clearTimeout(titleClickTimers[id]);
        if (typeof startInlineEditEntry === 'function') startInlineEditEntry(id);
    }
}

function startInlineEditCond(taskId, condType, label, isCustom = false) {
    const wrapper = document.getElementById(`inline-wrapper-${taskId}-${condType}`);
    if (!wrapper) return;
    
    const task = state.entries.find(e => e.id === taskId);
    
    let currentKey = ''; let currentOp = '=='; let currentVal = '1';
    if(isCustom) {
        const cgv = task.customGameplayValues?.find(c => c.fieldId === condType);
        if(cgv) { currentKey = cgv.key; currentOp = cgv.op; currentVal = cgv.val; }
    } else {
        currentKey = task[condType]?.key || '';
        currentOp = task[condType]?.op || '==';
        currentVal = task[condType]?.val || '1';
    }

    const safeHtml = typeof escapeHtml === 'function' ? escapeHtml : (t) => t;

    wrapper.innerHTML = `
        <div class="flex flex-col gap-1 w-full relative z-30 inline-edit-box">
            <span class="text-[9px] font-black uppercase tracking-widest text-gray-400 mb-1">${safeHtml(label)}</span>
            <div class="flex items-center bg-[#111] border border-[var(--accent-teal)] rounded-lg px-2 py-1.5 w-full gap-2 shadow-inner">
                <input type="text" id="inline-key-${taskId}-${condType}" class="bg-transparent border-none text-white text-[10px] font-mono outline-none w-full" placeholder="Key..." value="${safeHtml(currentKey)}" onkeydown="if(event.key === 'Enter') confirmInlineEditCond('${taskId}', '${condType}', ${isCustom})">
                <select id="inline-op-${taskId}-${condType}" class="bg-transparent border-none text-gray-400 text-[10px] font-mono outline-none p-0 cursor-pointer w-auto custom-scrollbar">
                    <option ${currentOp==='=='?'selected':''}>==</option><option ${currentOp==='>='?'selected':''}>>=</option>
                    <option ${currentOp==='<='?'selected':''}><=</option><option ${currentOp==='>'?'selected':''}>></option>
                    <option ${currentOp==='<'?'selected':''}><</option><option ${currentOp==='='?'selected':''}>=</option>
                    <option ${currentOp==='+='?'selected':''}>+=</option><option ${currentOp==='-='?'selected':''}>-=</option>
                </select>
                <input type="text" id="inline-val-${taskId}-${condType}" class="bg-transparent border-none text-white text-[10px] font-mono outline-none w-10 text-center" placeholder="Val" value="${safeHtml(currentVal)}" onkeydown="if(event.key === 'Enter') confirmInlineEditCond('${taskId}', '${condType}', ${isCustom})">
                <button class="inline-btn confirm" onclick="confirmInlineEditCond('${taskId}', '${condType}', ${isCustom})" title="Confirm">✓</button>
                <button class="inline-btn cancel" onclick="typeof fullRender === 'function' ? fullRender() : null" title="Dismiss">✕</button>
            </div>
        </div>
    `;
    setTimeout(() => {
        const input = document.getElementById(`inline-key-${taskId}-${condType}`);
        if(input) input.focus();
    }, 10);
}

function confirmInlineEditCond(taskId, condType, isCustom = false) {
    const keyInput = document.getElementById(`inline-key-${taskId}-${condType}`);
    const opInput = document.getElementById(`inline-op-${taskId}-${condType}`);
    const valInput = document.getElementById(`inline-val-${taskId}-${condType}`);
    
    if (!keyInput) return;
    const key = keyInput.value.trim();
    const op = opInput ? opInput.value : '==';
    const val = valInput ? valInput.value.trim() : '1';
    
    const task = state.entries.find(e => e.id === taskId);
    if (task) {
        if(isCustom) {
            const cgv = task.customGameplayValues?.find(c => c.fieldId === condType);
            if(cgv) { cgv.key = key; cgv.op = op; cgv.val = val; }
        } else {
            if (key) {
                task[condType] = { key, op, val, hideVisual: task[condType]?.hideVisual || false };
            } else {
                task[condType] = { key: '', op: '==', val: '', hideVisual: task[condType]?.hideVisual || false };
            }
        }
        markEdited(taskId);
        recalculateTags();
        if (typeof fullRender === 'function') fullRender();
    }
}

function startInlineEditEntry(taskId) {
    const task = state.entries.find(e => e.id === taskId);
    const wrapper = document.getElementById(`entry-text-wrapper-${taskId}`);
    if(!wrapper || !task) return;
    
    wrapper.classList.remove('hidden');
    if(wrapper.previousElementSibling) wrapper.previousElementSibling.classList.add('hidden'); 

    const safeHtml = typeof escapeHtml === 'function' ? escapeHtml : (t) => t;

    const titleToolbar = (typeof tmRenderTextToolbar === 'function') ? tmRenderTextToolbar(task, 'name') : '';
    const descToolbar = (typeof tmRenderTextToolbar === 'function') ? tmRenderTextToolbar(task, 'desc') : '';
    const titleFormatStyle = (typeof tmGetTextFormatStyle === 'function' && typeof tmGetTaskTextFormat === 'function') ? tmGetTextFormatStyle(tmGetTaskTextFormat(task, 'name')) : '';
    const descFormatStyle = (typeof tmGetTextFormatStyle === 'function' && typeof tmGetTaskTextFormat === 'function') ? tmGetTextFormatStyle(tmGetTaskTextFormat(task, 'desc')) : '';

    wrapper.innerHTML = `
        <div class="flex flex-col gap-3 mb-4 inline-edit-box w-full">
            <div class="tm-inline-edit-toolbar-slot">${titleToolbar}</div>
            <input type="text" id="inline-entry-name-${taskId}" data-tm-text-target-for="name" class="text-xl font-bold bg-[#111] border border-[#333] rounded-lg text-white outline-none w-full px-3 py-2 focus:border-[var(--accent-teal)]" style="${titleFormatStyle}" value="${safeHtml(typeof tmLocalizedTaskText === 'function' ? tmLocalizedTaskText(task, 'name') : task.name)}" placeholder="Entry Title...">
            <div class="tm-inline-edit-toolbar-slot mt-2">${descToolbar}</div>
            <textarea id="inline-entry-desc-${taskId}" data-tm-text-target-for="desc" class="text-sm font-medium bg-[#111] border border-[#333] rounded-lg text-gray-300 outline-none w-full resize-y min-h-[60px] px-3 py-2 focus:border-[var(--accent-teal)]" style="${descFormatStyle}" placeholder="Description...">${safeHtml(typeof tmLocalizedTaskText === 'function' ? tmLocalizedTaskText(task, 'desc') : task.desc)}</textarea>
            <div class="flex justify-end gap-2 mt-2 pt-2 border-t border-[#333]">
                <button class="btn btn-outline border-red-500 text-red-500 py-1 px-4 text-[10px] hover:bg-red-500 hover:text-white rounded-md font-bold" onclick="typeof fullRender === 'function' ? fullRender() : null">CANCEL</button>
                <button class="btn btn-teal py-1 px-6 text-[10px] rounded-md font-black" onclick="confirmInlineEditEntry('${taskId}')">SAVE ✓</button>
            </div>
        </div>
    `;

    if (typeof tmApplyFormatToFieldElement === 'function' && typeof tmGetTaskTextFormat === 'function') {
        const titleInput = document.getElementById(`inline-entry-name-${taskId}`);
        const descInput = document.getElementById(`inline-entry-desc-${taskId}`);
        tmApplyFormatToFieldElement(titleInput, tmGetTaskTextFormat(task, 'name'));
        tmApplyFormatToFieldElement(descInput, tmGetTaskTextFormat(task, 'desc'));
    }
    setTimeout(() => {
        const input = document.getElementById(`inline-entry-name-${taskId}`);
        if(input) input.focus();
    }, 10);
}

function confirmInlineEditEntry(taskId) {
    const task = state.entries.find(e => e.id === taskId);
    if(task) {
        const nameInput = document.getElementById(`inline-entry-name-${taskId}`);
        const descInput = document.getElementById(`inline-entry-desc-${taskId}`);
        if (nameInput) { if (typeof tmSetLocalizedTaskText === 'function') tmSetLocalizedTaskText(task, 'name', nameInput.value); else task.name = nameInput.value; }
        if (descInput) { if (typeof tmSetLocalizedTaskText === 'function') tmSetLocalizedTaskText(task, 'desc', descInput.value); else task.desc = descInput.value; }
        markEdited(taskId);
        if (typeof fullRender === 'function') fullRender();
    }
}

function toggleChainView(id) {
    const task = state.entries.find(t => t.id === id);
    if(task) { task.showChain = !task.showChain; if (typeof renderTasks === 'function') renderTasks(); }
}

function toggleDepView(id, val) {
    const task = state.entries.find(t => t.id === id);
    if(task) { task.showDeps = val; if (typeof renderTasks === 'function') renderTasks(); }
}

function hasCycle(targetId, depId) {
    if (targetId === depId) return true;
    const task = state.entries.find(t => t.id === depId);
    if (!task) return false;
    if (task.dependencies) {
        for (let childId of task.dependencies) {
            if (hasCycle(targetId, childId)) return true;
        }
    }
    return false;
}

function addDependency(taskId, depId) {
    if(!depId) return;
    if(hasCycle(taskId, depId)) { 
        if (typeof showNotification === 'function') showNotification("Cannot add: Creates cyclical dependency!", true); 
        return; 
    }
    const task = state.entries.find(t => t.id === taskId);
    if(task && task.dependencies && !task.dependencies.includes(depId)) {
        task.dependencies.push(depId);
        markEdited(taskId);
        if (typeof fullRender === 'function') fullRender();
    }
}

function removeDependency(taskId, depId) {
    const task = state.entries.find(t => t.id === taskId);
    if(task && task.dependencies) {
        task.dependencies = task.dependencies.filter(d => d !== depId);
        markEdited(taskId);
        if (typeof fullRender === 'function') fullRender();
    }
}

function deleteTask(id) {
    if(confirm("Permanently delete this task sequence?")) {
        state.entries = state.entries.filter(t => t.id !== id);
        state.entries.forEach(t => { if(t.dependencies) t.dependencies = t.dependencies.filter(depId => depId !== id); });
        if(state.focusedEntryId === id) syncFocus();
        if (typeof fullRender === 'function') fullRender();
        if (typeof showNotification === 'function') showNotification("Node Sequence Deleted", true);
    }
}

function jumpToChainNode(taskId) {
    const currentTask = state.entries.find(t => t.id === taskId);
    if (!currentTask || !currentTask.chainName) return;

    let targetTask = null;
    if (currentTask.taskType !== 'root') {
        targetTask = state.entries.find(t => t.chainName === currentTask.chainName && t.taskType === 'root');
    } else {
        const chainNodes = state.entries.filter(t => t.chainName === currentTask.chainName && t.taskType !== 'root');
        if (chainNodes.length > 0) {
            chainNodes.sort((a, b) => new Date(b.lastModified) - new Date(a.lastModified));
            targetTask = chainNodes[0];
        }
    }

    if (targetTask) {
        state.activeTab = targetTask.tab;
        if (typeof fullRender === 'function') fullRender();
        setTimeout(() => {
            const card = document.getElementById(`task-card-${targetTask.id}`);
            if (card) card.scrollIntoView({behavior: 'smooth', block: 'center'});
        }, 100);
    } else {
        if (typeof showNotification === 'function') showNotification("No other nodes in this chain.", true);
    }
}

function openTagModal(tagKey) {
    state.modalTag = tagKey;
    const tagKeyInput = document.getElementById('modalTagKey');
    const newTagValInput = document.getElementById('modalTagNewValue');
    if (tagKeyInput) tagKeyInput.value = tagKey;
    if (newTagValInput) newTagValInput.value = tagKey;
    
    const data = state.globalTags[tagKey];
    const listContainer = document.getElementById('modalDependenciesList');
    if (!data || !listContainer) return;

    const safeHtml = typeof escapeHtml === 'function' ? escapeHtml : (t) => t;
    let html = '';
    
    const createDependencyRow = (entryId, type, labelPrefix) => {
        const entry = state.entries.find(e => e.id === entryId);
        if(!entry) return '';
        return `
        <div class="bg-[#111] p-4 border border-[var(--border-color)] flex justify-between items-center rounded-lg">
            <div class="flex flex-col">
                <span class="text-[9px] font-black uppercase text-[var(--accent-gold)] mb-1">${labelPrefix} IN [${safeHtml(entry.tab)}]</span>
                <span class="text-sm text-white italic">"${safeHtml(entry.name)}"</span>
            </div>
            <div class="flex gap-2">
                <button onclick="jumpToEntry('${entry.tab}', '${entry.id}')" class="btn btn-outline text-[var(--accent-teal)] border-[var(--accent-teal)] text-[9px] py-1 px-3">JUMP ↳</button>
                <button onclick="deleteDependencyInstance('${entryId}', '${type}', '${tagKey}')" class="btn btn-outline text-[var(--accent-pink)] border-[var(--accent-pink)] text-[9px] py-1 px-3">DELETE</button>
            </div>
        </div>
        `;
    };

    data.conds.forEach(id => html += createDependencyRow(id, 'conds_arr', 'Condition Array Requirement'));
    data.states.forEach(id => html += createDependencyRow(id, 'states_arr', 'State Change Array'));
    data.gameplay.forEach(id => {
        const entry = state.entries.find(e => e.id === id);
        if(entry) {
            if(entry.unlockCondition?.key === tagKey) html += createDependencyRow(id, 'unlock', 'Unlock Trigger');
            if(entry.completeCondition?.key === tagKey) html += createDependencyRow(id, 'complete', 'Completion Logic');
            if(entry.failCondition?.key === tagKey) html += createDependencyRow(id, 'fail', 'Failure Logic');
            if(entry.rewardCondition?.key === tagKey) html += createDependencyRow(id, 'reward', 'Task Reward');
            if(entry.customGameplayValues && entry.customGameplayValues.some(c=>c.key===tagKey)) html += createDependencyRow(id, 'custom', 'Custom Value');
        }
    });

    listContainer.innerHTML = html || '<div class="p-4 text-gray-500 italic text-xs">No active dependencies found.</div>';
    
    const overlay = document.getElementById('modal-overlay');
    if(overlay) overlay.style.display = 'flex';
}

function closeModal() {
    const overlay = document.getElementById('modal-overlay');
    if(overlay) overlay.style.display = 'none';
    state.modalTag = null;
}

function jumpToEntry(tabName, entryId) {
    closeModal();
    state.activeTab = tabName;
    state.focusedEntryId = entryId;
    if (typeof fullRender === 'function') fullRender();
    setTimeout(() => {
        const card = document.getElementById(`task-card-${entryId}`);
        if(card) card.scrollIntoView({behavior: 'smooth', block: 'center'});
    }, 100);
}

function deleteDependencyInstance(entryId, type, tagKey) {
    const entry = state.entries.find(e => e.id === entryId);
    if(!entry) return;
    
    if(type === 'conds_arr' && entry.conditions) {
        entry.conditions = entry.conditions.filter(c => c.key !== tagKey);
    } else if (type === 'states_arr' && entry.stateChanges) {
        entry.stateChanges = entry.stateChanges.filter(s => s.key !== tagKey);
    } else if(type === 'unlock') {
        if(entry.unlockCondition && entry.unlockCondition.key === tagKey) entry.unlockCondition = {key:'', op:'==', val:''};
    } else if(type === 'complete') {
        if(entry.completeCondition && entry.completeCondition.key === tagKey) entry.completeCondition = {key:'', op:'==', val:''};
    } else if(type === 'fail') {
        if(entry.failCondition && entry.failCondition.key === tagKey) entry.failCondition = {key:'', op:'==', val:''};
    } else if(type === 'reward') {
        if(entry.rewardCondition && entry.rewardCondition.key === tagKey) entry.rewardCondition = {key:'', op:'==', val:''};
    } else if(type === 'custom' && entry.customGameplayValues) {
        entry.customGameplayValues = entry.customGameplayValues.filter(c => c.key !== tagKey);
    }
    
    markEdited(entryId);
    recalculateTags();
    openTagModal(tagKey); 
    if (typeof fullRender === 'function') fullRender(); 
    
    if(!state.globalTags[tagKey]) {
        closeModal(); 
    }
}

function applyTagRename() {
    const oldKey = state.modalTag;
    const newValInput = document.getElementById('modalTagNewValue');
    if(!newValInput) return;
    const newKey = newValInput.value.trim();
    if(!newKey || newKey === oldKey) return;
    
    state.entries.forEach(entry => {
        let modified = false;
        if(entry.conditions) entry.conditions.forEach(c => { if(c.key === oldKey) { c.key = newKey; modified = true; } });
        if(entry.stateChanges) entry.stateChanges.forEach(s => { if(s.key === oldKey) { s.key = newKey; modified = true; } });

        if(entry.unlockCondition?.key === oldKey) { entry.unlockCondition.key = newKey; modified = true; }
        if(entry.completeCondition?.key === oldKey) { entry.completeCondition.key = newKey; modified = true; }
        if(entry.failCondition?.key === oldKey) { entry.failCondition.key = newKey; modified = true; }
        if(entry.rewardCondition?.key === oldKey) { entry.rewardCondition.key = newKey; modified = true; }
        if(entry.customGameplayValues) entry.customGameplayValues.forEach(c => { if(c.key === oldKey) { c.key = newKey; modified = true; } });
        
        if (modified) markEdited(entry.id);
    });
    
    recalculateTags();
    if (typeof fullRender === 'function') fullRender();
    closeModal();
}

function updateTaskString(taskId, field, value) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry) {
        if (typeof tmUpdateLocalizedTaskField === 'function' && tmUpdateLocalizedTaskField(taskId, field, value)) {
            if (field === 'chainName' && (typeof tmEnsureValues !== 'function' || (tmEnsureValues().currentLanguage || 'ENG') === 'ENG')) entry[field] = value;
        } else {
            entry[field] = value;
        }
        markEdited(taskId);
        if (typeof tmMarkAppDirty === 'function') tmMarkAppDirty();
        if (typeof renderTasksSilently === 'function') renderTasksSilently();
    }
}

function updateTaskTab(taskId, newTab) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry) {
        entry.tab = newTab;
        markEdited(taskId);
        syncFocus();
        if (typeof fullRender === 'function') fullRender();
    }
}

function updateTaskCondTop(taskId, condType, field, value) {
    const entry = state.entries.find(e => e.id === taskId);
    if(entry) {
        if(!entry[condType]) entry[condType] = {key: '', op: '==', val: '', hideVisual: false};
        entry[condType][field] = value;
        markEdited(taskId);
        if (typeof recalculateTags === 'function') recalculateTags();
        if (typeof renderSidebar === 'function') renderSidebar();
        if (typeof refreshAllGlows === 'function') refreshAllGlows();
        if (typeof renderTasksSilently === 'function') renderTasksSilently();
    }
}

function cloneTaskRecursively(task) {
    let clone = JSON.parse(JSON.stringify(task));
    clone.id = crypto.randomUUID();
    if (clone.objectives) {
        clone.objectives.forEach(obj => {
            obj.id = crypto.randomUUID();
            if (obj.targets) {
                obj.targets.forEach(t => t.id = crypto.randomUUID());
            }
        });
    }
    return clone;
}

function openDuplicateModal(taskId) {
    const task = state.entries.find(e => e.id === taskId);
    if (!task) return;

    document.getElementById('dupOriginalId').value = taskId;
    document.getElementById('dupColor').value = getRandomColor();
    document.getElementById('dupTitle').value = `${task.name} (Clone)`;
    document.getElementById('dupDesc').value = task.desc || '';

    const tabSelect = document.getElementById('dupTab');
    tabSelect.innerHTML = state.tabs.map(t => `<option value="${escapeHtml(t)}" ${t === task.tab ? 'selected' : ''}>${escapeHtml(t)}</option>`).join('');

    updateDupPositionSelect();

    const overlay = document.getElementById('duplicate-overlay');
    if (overlay) overlay.style.display = 'flex';
}

function updateDupPositionSelect() {
    const tabSelect = document.getElementById('dupTab');
    const posSelect = document.getElementById('dupPosition');
    if (!tabSelect || !posSelect) return;

    const selectedTab = tabSelect.value;
    const tabEntriesCount = state.entries.filter(e => e.tab === selectedTab).length;
    
    let html = '';
    for (let i = 0; i <= tabEntriesCount; i++) {
        html += `<option value="${i}" ${i === tabEntriesCount ? 'selected' : ''}>Position #${i + 1}</option>`;
    }
    posSelect.innerHTML = html;
}

function closeDuplicateModal() {
    const overlay = document.getElementById('duplicate-overlay');
    if (overlay) overlay.style.display = 'none';
}

function confirmDuplicate() {
    const originalId = document.getElementById('dupOriginalId').value;
    const originalTask = state.entries.find(e => e.id === originalId);
    if (!originalTask) return;

    const clone = cloneTaskRecursively(originalTask);
    
    clone.color = document.getElementById('dupColor').value;
    clone.name = document.getElementById('dupTitle').value;
    clone.desc = document.getElementById('dupDesc').value;
    clone.tab = document.getElementById('dupTab').value;
    clone.lastModified = new Date().toISOString();

    const position = parseInt(document.getElementById('dupPosition').value);

    const otherEntries = state.entries.filter(e => e.tab !== clone.tab);
    const tabEntries = state.entries.filter(e => e.tab === clone.tab);
    tabEntries.splice(position, 0, clone);
    
    state.entries = [...otherEntries, ...tabEntries];

    state.activeTab = clone.tab;
    state.focusedEntryId = clone.id;
    markEdited(clone.id);
    
    closeDuplicateModal();
    if (typeof fullRender === 'function') fullRender();
    if (typeof showNotification === 'function') showNotification("Node Successfully Duplicated");
}