// ============================================================================
// DD_IO.JS - Input/Output, File Handling, and Data Migration
// ============================================================================

// --- GLOBAL UI STATE GUARANTEES & POLYFILLS ---
// Prevents ReferenceErrors during imports if core UI states haven't been strictly declared in other scripts
function _ensureGlobal(name, def) {
    if (typeof window[name] === 'undefined') {
        window[name] = def;
    }
}

// Editor interaction trackers
_ensureGlobal('editTarget', { type: null, index: null, seqIndex: null, imgIndex: null });
_ensureGlobal('renamingProject', { type: null, index: null });
_ensureGlobal('editingResponseRef', null);
_ensureGlobal('currentLanguage', 'ENG');
_ensureGlobal('isAddingLanguage', false);
_ensureGlobal('openImageSeqs', new Set());
_ensureGlobal('editedNodes', new Set());

// Core engine logic trackers
_ensureGlobal('activeIndex', null);
_ensureGlobal('activeType', 'conversation');

// Data persistence arrays
_ensureGlobal('conversations', []);
_ensureGlobal('sequences', []);
_ensureGlobal('cast', []);
_ensureGlobal('globalTokens', []);
_ensureGlobal('globalStates', []);
_ensureGlobal('globalMoods', []);
_ensureGlobal('globalSettings', []);
_ensureGlobal('globalTimesOfDay', []);
_ensureGlobal('globalDaysOfWeek', []);
_ensureGlobal('globalMenuOptions', []);
_ensureGlobal('globalImageSequences', []);

if (typeof window.getActiveProject === 'undefined') {
    window.getActiveProject = function() {
        if (typeof window.activeIndex === 'undefined' || window.activeIndex === null) return null;
        return window.activeType === 'conversation' ? 
            (window.conversations ? window.conversations[window.activeIndex] : null) : 
            (window.sequences ? window.sequences[window.activeIndex] : null);
    };
}

// Polyfill missing core utility functions to guarantee the UI rendering never crashes during data ingestion
if (typeof window.escapeHtml === 'undefined') {
    window.escapeHtml = function(text) {
        if (text === null || text === undefined) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    };
}

if (typeof window.getRandomColor === 'undefined') {
    window.getRandomColor = function() {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) color += letters[Math.floor(Math.random() * 16)];
        return color;
    };
}


window.openAccountModal = window.openAccountModal || function() {
    const modal = document.getElementById('account-modal');
    if (modal) modal.style.display = 'flex';
};

// --- LOCAL SAFE FALLBACKS ---
function getSafeRandomColor() {
    if (typeof window.getRandomColor === 'function') return window.getRandomColor();
    if (typeof getRandomColor === 'function') return getRandomColor();
    return window.getRandomColor(); // Fallback to our polyfill above
}

function safeShowNotification(text, isError = false) {
    if (typeof window.showNotification === 'function') {
        window.showNotification(text, isError);
        return;
    }
    if (typeof showNotification === 'function') {
        showNotification(text, isError);
        return;
    }
    console.warn(`[Dialogue Designer Notification] ${isError ? 'ERROR:' : 'INFO:'} ${text}`);
}

let targetImportSeqIndex = null;

const DD_AUTH_TOKEN_KEY = 'DD_sharedAuthBearerToken';
const SHARED_AUTH_TOKEN_KEY = 'AuthShared_12h_token';
const SHARED_AUTH_EXPIRES_KEY = 'AuthShared_12h_expiresAt';

function getStoredAuthToken() {
    try {
        return localStorage.getItem(SHARED_AUTH_TOKEN_KEY) || localStorage.getItem(DD_AUTH_TOKEN_KEY) || '';
    } catch (err) {
        return '';
    }
}

function setStoredAuthToken(token) {
    try {
        const cleaned = token ? String(token).trim() : '';
        if (cleaned) {
            localStorage.setItem(DD_AUTH_TOKEN_KEY, cleaned);
            localStorage.setItem(SHARED_AUTH_TOKEN_KEY, cleaned);
        } else {
            localStorage.removeItem(DD_AUTH_TOKEN_KEY);
            localStorage.removeItem(SHARED_AUTH_TOKEN_KEY);
            localStorage.removeItem(SHARED_AUTH_EXPIRES_KEY);
        }
    } catch (err) {}
}

function applyAuthHeaders(fetchOptions) {
    const token = getStoredAuthToken();
    if (!token) return fetchOptions;
    const headers = new Headers(fetchOptions.headers || {});
    if (!headers.has('Authorization')) headers.set('Authorization', `Bearer ${token}`);
    if (!headers.has('X-Auth-Token')) headers.set('X-Auth-Token', token);
    fetchOptions.headers = headers;
    return fetchOptions;
}

function withSharedAuthQuery(query = {}) {
    const nextQuery = Object.assign({}, query || {});
    const token = getStoredAuthToken();
    if (token && !nextQuery.authToken) nextQuery.authToken = token;
    return nextQuery;
}


function applyImportedLanguageSettings(data) {
    if (!data || typeof data !== 'object') return;
    if (Array.isArray(data.availableLanguages) && data.availableLanguages.length > 0) {
        window.availableLanguages = data.availableLanguages.map(lang => String(lang).trim().toUpperCase()).filter(Boolean);
        if (!window.availableLanguages.includes('ENG')) window.availableLanguages.unshift('ENG');
    }
    if (data.currentLanguage) {
        window.currentLanguage = String(data.currentLanguage).trim().toUpperCase();
        if (!window.availableLanguages.includes(window.currentLanguage)) window.availableLanguages.push(window.currentLanguage);
    }
}


function cloneGlobalSidebarValue(value) {
    if (value === null || value === undefined) return value;
    try {
        return JSON.parse(JSON.stringify(value));
    } catch (err) {
        if (Array.isArray(value)) return value.slice();
        if (typeof value === 'object') return Object.assign({}, value);
        return value;
    }
}

function normalizeGlobalMergeKey(value) {
    return String(value === undefined || value === null ? '' : value).trim().toLowerCase();
}

function mergeGlobalSidebarObjects(existingEntry, importedEntry) {
    const output = cloneGlobalSidebarValue(existingEntry) || {};
    const incoming = cloneGlobalSidebarValue(importedEntry) || {};
    Object.keys(incoming).forEach(key => {
        const value = incoming[key];
        if (value === undefined || value === null) return;
        if (typeof value === 'string' && value.trim() === '' && output[key] !== undefined && output[key] !== null && String(output[key]).trim() !== '') return;
        if (Array.isArray(value) && value.length === 0 && Array.isArray(output[key]) && output[key].length > 0) return;
        output[key] = cloneGlobalSidebarValue(value);
    });
    return output;
}

function normalizeNamedGlobalEntry(entry) {
    if (entry === null || entry === undefined) return null;
    if (typeof entry === 'string') {
        const name = entry.trim();
        return name ? { name, color: getSafeRandomColor() } : null;
    }
    if (typeof entry !== 'object' || Array.isArray(entry)) return null;
    const cloned = cloneGlobalSidebarValue(entry);
    if (cloned.name === undefined || cloned.name === null) cloned.name = '';
    cloned.name = String(cloned.name).trim();
    if (!cloned.name) return null;
    if (!cloned.color) cloned.color = getSafeRandomColor();
    return cloned;
}

function normalizeTokenGlobalEntry(entry) {
    if (entry === null || entry === undefined) return null;
    if (typeof entry === 'string') {
        const key = entry.trim().replace(/[^a-zA-Z0-9_]/g, '');
        return key ? { key, value: '' } : null;
    }
    if (typeof entry !== 'object' || Array.isArray(entry)) return null;
    const cloned = cloneGlobalSidebarValue(entry);
    if (cloned.key === undefined || cloned.key === null) cloned.key = '';
    cloned.key = String(cloned.key).trim().replace(/[^a-zA-Z0-9_]/g, '');
    if (!cloned.key) return null;
    if (cloned.value === undefined || cloned.value === null) cloned.value = '';
    return cloned;
}

function normalizeImageSequenceGlobalEntry(entry) {
    if (entry === null || entry === undefined) return null;
    let cloned;
    if (typeof entry === 'string') {
        cloned = { name: entry.trim(), color: getSafeRandomColor(), path: 'Assets/2D/Sequences/', images: [] };
    } else if (typeof entry === 'object' && !Array.isArray(entry)) {
        cloned = cloneGlobalSidebarValue(entry);
    } else {
        return null;
    }
    if (cloned.name === undefined || cloned.name === null) cloned.name = '';
    cloned.name = String(cloned.name).trim();
    if (!cloned.name) return null;
    if (!cloned.color) cloned.color = getSafeRandomColor();
    if (!cloned.path) cloned.path = 'Assets/2D/Sequences/';
    if (!Array.isArray(cloned.images)) cloned.images = [];
    cloned.images = cloned.images.map(img => String(img === undefined || img === null ? '' : img).trim()).filter(Boolean);
    return cloned;
}

function mergeGlobalSidebarArray(existingItems, importedItems, normalizeEntry, keyProp, customMerge) {
    const result = [];
    const indexByKey = new Map();
    const addOrMerge = (entry, preferImported) => {
        const normalized = normalizeEntry(entry);
        if (!normalized) return;
        const mergeKey = normalizeGlobalMergeKey(normalized[keyProp]);
        if (!mergeKey) return;
        if (indexByKey.has(mergeKey)) {
            const existingIndex = indexByKey.get(mergeKey);
            result[existingIndex] = typeof customMerge === 'function'
                ? customMerge(result[existingIndex], normalized, preferImported)
                : mergeGlobalSidebarObjects(result[existingIndex], normalized);
            return;
        }
        indexByKey.set(mergeKey, result.length);
        result.push(normalized);
    };

    (Array.isArray(existingItems) ? existingItems : []).forEach(entry => addOrMerge(entry, false));
    (Array.isArray(importedItems) ? importedItems : []).forEach(entry => addOrMerge(entry, true));
    return result;
}

function mergeImageSequenceGlobalEntry(existingEntry, importedEntry) {
    const merged = mergeGlobalSidebarObjects(existingEntry, importedEntry);
    const images = [];
    const seen = new Set();
    const addImage = (img) => {
        const clean = String(img === undefined || img === null ? '' : img).trim();
        const key = clean.toLowerCase();
        if (!clean || seen.has(key)) return;
        seen.add(key);
        images.push(clean);
    };
    (Array.isArray(existingEntry.images) ? existingEntry.images : []).forEach(addImage);
    (Array.isArray(importedEntry.images) ? importedEntry.images : []).forEach(addImage);
    merged.images = images;
    if (!merged.path) merged.path = 'Assets/2D/Sequences/';
    if (!merged.color) merged.color = getSafeRandomColor();
    return merged;
}

function normalizeWorkspaceGlobalSidebarData(data, previousGlobals = null) {
    const existing = previousGlobals || {};
    return {
        cast: mergeGlobalSidebarArray(existing.cast, Array.isArray(data.cast) ? data.cast : [], normalizeNamedGlobalEntry, 'name'),
        globalTokens: mergeGlobalSidebarArray(existing.globalTokens, Array.isArray(data.globalTokens) ? data.globalTokens : [], normalizeTokenGlobalEntry, 'key'),
        globalStates: mergeGlobalSidebarArray(existing.globalStates, Array.isArray(data.globalStates) ? data.globalStates : [], normalizeNamedGlobalEntry, 'name'),
        globalMoods: mergeGlobalSidebarArray(existing.globalMoods, Array.isArray(data.globalMoods) ? data.globalMoods : [], normalizeNamedGlobalEntry, 'name'),
        globalSettings: mergeGlobalSidebarArray(existing.globalSettings, Array.isArray(data.globalSettings) ? data.globalSettings : [], normalizeNamedGlobalEntry, 'name'),
        globalTimesOfDay: mergeGlobalSidebarArray(existing.globalTimesOfDay, Array.isArray(data.globalTimesOfDay) ? data.globalTimesOfDay : [], normalizeNamedGlobalEntry, 'name'),
        globalDaysOfWeek: mergeGlobalSidebarArray(existing.globalDaysOfWeek, Array.isArray(data.globalDaysOfWeek) ? data.globalDaysOfWeek : [], normalizeNamedGlobalEntry, 'name'),
        globalMenuOptions: mergeGlobalSidebarArray(existing.globalMenuOptions, Array.isArray(data.globalMenuOptions) ? data.globalMenuOptions : [], normalizeNamedGlobalEntry, 'name'),
        globalImageSequences: mergeGlobalSidebarArray(existing.globalImageSequences, Array.isArray(data.globalImageSequences) ? data.globalImageSequences : [], normalizeImageSequenceGlobalEntry, 'name', mergeImageSequenceGlobalEntry)
    };
}

function captureCurrentGlobalSidebarData() {
    return {
        cast: cloneGlobalSidebarValue(window.cast || []),
        globalTokens: cloneGlobalSidebarValue(window.globalTokens || []),
        globalStates: cloneGlobalSidebarValue(window.globalStates || []),
        globalMoods: cloneGlobalSidebarValue(window.globalMoods || []),
        globalSettings: cloneGlobalSidebarValue(window.globalSettings || []),
        globalTimesOfDay: cloneGlobalSidebarValue(window.globalTimesOfDay || []),
        globalDaysOfWeek: cloneGlobalSidebarValue(window.globalDaysOfWeek || []),
        globalMenuOptions: cloneGlobalSidebarValue(window.globalMenuOptions || []),
        globalImageSequences: cloneGlobalSidebarValue(window.globalImageSequences || [])
    };
}

function shouldMergeGlobalSidebarOnApply(options) {
    return !!(options && (options.source === 'import' || options.mergeGlobals === true));
}

function applyNormalizedGlobalSidebarData(normalizedGlobals) {
    window.cast = normalizedGlobals.cast;
    window.globalTokens = normalizedGlobals.globalTokens;
    window.globalStates = normalizedGlobals.globalStates;
    window.globalMoods = normalizedGlobals.globalMoods;
    window.globalSettings = normalizedGlobals.globalSettings;
    window.globalTimesOfDay = normalizedGlobals.globalTimesOfDay;
    window.globalDaysOfWeek = normalizedGlobals.globalDaysOfWeek;
    window.globalMenuOptions = normalizedGlobals.globalMenuOptions;
    window.globalImageSequences = normalizedGlobals.globalImageSequences;
}

function mergeImportedGlobalSidebarData(data) {
    if (!data || typeof data !== 'object') return;
    const merged = normalizeWorkspaceGlobalSidebarData(data, captureCurrentGlobalSidebarData());
    applyNormalizedGlobalSidebarData(merged);
    if (typeof renderTokens === 'function') renderTokens();
    if (typeof renderCast === 'function') renderCast();
    if (typeof renderStates === 'function') renderStates();
    if (typeof renderMoods === 'function') renderMoods();
    if (typeof renderSettings === 'function') renderSettings();
    if (typeof renderTimesOfDay === 'function') renderTimesOfDay();
    if (typeof renderDaysOfWeek === 'function') renderDaysOfWeek();
    if (typeof renderMenuOptions === 'function') renderMenuOptions();
    if (typeof renderImageSequences === 'function') renderImageSequences();
    if (typeof updateLocalAddDropdown === 'function') updateLocalAddDropdown();
}

function extractProjectVariables(project) {
    const p = JSON.parse(JSON.stringify(project));
    const tagsMap = {};

    const addTag = (variable, operator, value, isCond, isState) => {
        const variableKey = (variable === undefined || variable === null) ? '' : String(variable).trim();
        const val = (value === undefined || value === null) ? '' : String(value);
        if (variableKey === '' && val.trim() === '') return;
        const key = `${variableKey}|||${val}`;
        
        if (!tagsMap[key]) {
            tagsMap[key] = {
                key: variableKey,
                operator: '==',
                value: val,
                format: `${variableKey} == ${val}`,
                totalReferences: 0,
                isCond: false,
                isState: false
            };
        }
        
        tagsMap[key].totalReferences++;
        if (isCond) tagsMap[key].isCond = true;
        if (isState) tagsMap[key].isState = true;
    };
    
    p.nodes.forEach(n => {
        (n.conditions || []).forEach(c => addTag(c.variable, c.operator, c.value, true, false));
        (n.gameStateChanges || []).forEach(c => addTag(c.variable, c.operator, c.value, false, true));
        (n.responses || []).forEach(r => {
            (r.conditions || []).forEach(c => addTag(c.variable, c.operator, c.value, true, false));
            (r.gameStateChanges || []).forEach(c => addTag(c.variable, c.operator, c.value, false, true));
        });
    });
    
    p["Active Project Logic"] = Object.values(tagsMap).map(tag => {
        let usage = "Mixed Usage";
        if (tag.isCond && !tag.isState) usage = "Condition Only";
        if (!tag.isCond && tag.isState) usage = "State Change Only";
        
        return {
            key: tag.key,
            operator: tag.operator,
            value: tag.value,
            format: tag.format,
            totalReferences: tag.totalReferences,
            usageClassification: usage
        };
    });
    
    delete p.activeLogicVariables;
    delete p.__isStarterProject;
    return p;
}

function exportSingleProject() {
    const project = getActiveProject();
    if (!project) return;
    if (typeof ensureProjectTranslationContainers === 'function') ensureProjectTranslationContainers(project);
    const projectData = extractProjectVariables(project);
    projectData.availableLanguages = window.availableLanguages || ['ENG'];
    projectData.currentLanguage = window.currentLanguage || 'ENG';
    triggerDownload(projectData, `${project.title.replace(/[^a-z0-9]/gi, '_')}_Export`);
    safeShowNotification("Single Project Exported");
}

function buildWorkspacePayload() {
    if (typeof ensureAllTranslationContainers === 'function') ensureAllTranslationContainers();
    const processedConversations = (window.conversations || []).map(c => extractProjectVariables(c));
    const processedSequences = (window.sequences || []).map(s => extractProjectVariables(s));

    return { 
        version: "2.21",
        exportedAt: new Date().toISOString(),
        serverSessionId: getServerSessionId(),
        availableLanguages: window.availableLanguages || ['ENG'],
        currentLanguage: window.currentLanguage || 'ENG',
        cast: window.cast || [],
        globalTokens: window.globalTokens || [],
        globalStates: window.globalStates || [],
        globalMoods: window.globalMoods || [],
        globalSettings: window.globalSettings || [],
        globalTimesOfDay: window.globalTimesOfDay || [],
        globalDaysOfWeek: window.globalDaysOfWeek || [],
        globalMenuOptions: window.globalMenuOptions || [],
        globalImageSequences: window.globalImageSequences || [],
        conversations: processedConversations,
        sequences: processedSequences
    };
}

function exportProjectJSON() {
    const projectData = buildWorkspacePayload();
    triggerDownload(projectData, "DialogueDesigner_Export");
    safeShowNotification("Full Workspace Exported");
}

function stableStringifyForServerState(value) {
    const seen = new WeakSet();
    const normalize = (entry) => {
        if (entry === null || typeof entry !== 'object') return entry;
        if (seen.has(entry)) return '[Circular]';
        seen.add(entry);
        if (Array.isArray(entry)) return entry.map(normalize);
        const output = {};
        Object.keys(entry).sort().forEach(key => {
            if (key === '__isStarterProject' || key === 'exportedAt') return;
            output[key] = normalize(entry[key]);
        });
        return output;
    };
    return JSON.stringify(normalize(value));
}

function hashWorkspacePayload(payload) {
    const text = stableStringifyForServerState(payload);
    let hash = 2166136261;
    for (let i = 0; i < text.length; i++) {
        hash ^= text.charCodeAt(i);
        hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
    }
    return (hash >>> 0).toString(16).padStart(8, '0') + ':' + text.length;
}

window.lastServerWorkspaceHash = window.lastServerWorkspaceHash || localStorage.getItem('DD_lastServerWorkspaceHash') || '';
window.workspaceHasServerDelta = window.workspaceHasServerDelta || false;
window.pushStateRefreshTimer = window.pushStateRefreshTimer || null;

function isDialogueDesignerAccountLoggedIn() {
    return !!(window.DD_ACCOUNT && window.DD_ACCOUNT.loggedIn);
}
window.isDialogueDesignerAccountLoggedIn = isDialogueDesignerAccountLoggedIn;

function updatePushToServerButton(stateText = null) {
    const button = document.getElementById('push-server-button');
    if (!button) return;
    const loggedIn = isDialogueDesignerAccountLoggedIn();
    button.style.display = loggedIn ? 'inline-flex' : 'none';
    button.disabled = !loggedIn || button.classList.contains('saving');
    const label = button.querySelector('span');
    button.classList.toggle('dirty', loggedIn && !!window.workspaceHasServerDelta);
    if (!loggedIn) {
        if (label) label.textContent = 'Push To Server';
        button.title = 'Log in to push this workspace to the server.';
        return;
    }
    if (!button.classList.contains('saving') && !button.classList.contains('error')) {
        if (label) label.textContent = stateText || 'Push To Server';
    }
    button.title = window.workspaceHasServerDelta ? 'Local workspace has changes that have not been pushed to the server.' : 'Server copy matches the latest pushed workspace snapshot.';
}

function refreshPushToServerState() {
    if (typeof buildWorkspacePayload !== 'function') return;
    try {
        const currentHash = hashWorkspacePayload(buildWorkspacePayload());
        window.currentWorkspaceHash = currentHash;
        window.workspaceHasServerDelta = currentHash !== window.lastServerWorkspaceHash;
        updatePushToServerButton();
    } catch (err) {
        console.warn('Unable to refresh push-to-server dirty state.', err);
    }
}

function schedulePushStateRefresh() {
    clearTimeout(window.pushStateRefreshTimer);
    window.pushStateRefreshTimer = setTimeout(refreshPushToServerState, 120);
}

function markWorkspaceDirty() {
    window.workspaceHasServerDelta = true;
    updatePushToServerButton();
    schedulePushStateRefresh();
}

const DD_SERVER_SESSION_STORAGE_KEY = 'FSG_DD_ServerSessionId';

function hashStringForSessionId(text) {
    let hash = 5381;
    for (let i = 0; i < text.length; i++) {
        hash = ((hash << 5) + hash) ^ text.charCodeAt(i);
    }
    return (hash >>> 0).toString(36).toUpperCase();
}

function createServerSessionId() {
    const fingerprint = [
        navigator.userAgent || '',
        navigator.language || '',
        Intl.DateTimeFormat().resolvedOptions().timeZone || '',
        `${screen.width || 0}x${screen.height || 0}x${screen.colorDepth || 0}`,
        `${new Date().getTimezoneOffset()}`
    ].join('|');
    const randomBytes = new Uint8Array(8);
    if (window.crypto && crypto.getRandomValues) {
        crypto.getRandomValues(randomBytes);
    } else {
        for (let i = 0; i < randomBytes.length; i++) randomBytes[i] = Math.floor(Math.random() * 256);
    }
    const randomPart = Array.from(randomBytes).map(v => v.toString(36).padStart(2, '0')).join('').toUpperCase().slice(0, 12);
    return `DD-${hashStringForSessionId(fingerprint).padStart(7, '0').slice(0, 7)}-${randomPart}`;
}

function getServerSessionId() {
    let sessionId = localStorage.getItem(DD_SERVER_SESSION_STORAGE_KEY);
    if (!sessionId || !sessionId.trim()) {
        sessionId = createServerSessionId();
        localStorage.setItem(DD_SERVER_SESSION_STORAGE_KEY, sessionId);
    }
    return sessionId;
}

function setServerSessionId(sessionId) {
    const cleanId = String(sessionId || '').trim();
    if (!cleanId) return getServerSessionId();
    localStorage.setItem(DD_SERVER_SESSION_STORAGE_KEY, cleanId);
    renderServerSessionPanel();
    schedulePushStateRefresh();
    return cleanId;
}

function renderServerSessionPanel() {
    const sessionId = getServerSessionId();
    const display = document.getElementById('server-session-id-display');
    const loadInput = document.getElementById('server-session-load-input');
    if (display) display.textContent = sessionId;
    if (loadInput && !loadInput.value.trim()) loadInput.value = sessionId;
}

function copyServerSessionId(button) {
    const sessionId = getServerSessionId();
    if (typeof copyToClipboard === 'function') {
        copyToClipboard(sessionId, button);
        return;
    }
    navigator.clipboard.writeText(sessionId);
}

async function regenerateServerSessionId() {
    let newId = createServerSessionId();
    try {
        const response = await fetchSharedAuthApi('generateSessionId', { method: 'GET', cache: 'no-store' });
        const result = await readDatabaseApiJson(response);
        if (response.ok && result.ok && result.sessionId) newId = result.sessionId;
    } catch (err) {
        console.warn('Server unique session generation unavailable, using local generated id.', err.message);
    }
    localStorage.setItem(DD_SERVER_SESSION_STORAGE_KEY, newId);
    window.lastServerWorkspaceHash = '';
    localStorage.removeItem('DD_lastServerWorkspaceHash');
    renderServerSessionPanel();
    markWorkspaceDirty();
    safeShowNotification(`New server session assigned: ${newId}`);
    if (typeof showFastScrollIndicator === 'function') showFastScrollIndicator('New Session', { timeout: 1100 });
}

async function pasteServerSessionIdIntoInput() {
    const input = document.getElementById('server-session-load-input');
    if (!input) return;

    try {
        if (!navigator.clipboard || typeof navigator.clipboard.readText !== 'function') {
            throw new Error('Clipboard read is not available in this browser context.');
        }
        const clipboardText = await navigator.clipboard.readText();
        input.value = String(clipboardText || '').trim();
        input.focus();
        input.select();
        if (input.value) {
            safeShowNotification('Session ID pasted into the load field.');
        }
    } catch (err) {
        safeShowNotification(`Paste failed: ${err.message}`, true);
    }
}

function downloadServerSessionIdJson() {
    const sessionId = getServerSessionId();
    const lastPart = String(sessionId).split('-').filter(Boolean).pop() || sessionId.replace(/[^a-z0-9]/gi, '').slice(-8) || 'Session';
    const payload = {
        type: 'DialogueDesignerServerSessionId',
        sessionId,
        exportedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `SessionId_${lastPart}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    safeShowNotification('Session ID JSON downloaded.');
    if (typeof showFastScrollIndicator === 'function') showFastScrollIndicator('Session ID Downloaded', { timeout: 1200 });
}

function uploadServerSessionIdJson(input) {
    const file = input && input.files && input.files[0] ? input.files[0] : null;
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
        try {
            const rawText = String(event.target.result || '').trim();
            const parsed = rawText.startsWith('{') ? JSON.parse(rawText) : { sessionId: rawText };
            const sessionId = String(parsed.sessionId || parsed.id || parsed.serverSessionId || '').trim();
            if (!sessionId) throw new Error('That JSON did not include a sessionId value.');
            const loadInput = document.getElementById('server-session-load-input');
            if (loadInput) loadInput.value = sessionId;
            const loaded = await loadLatestWorkspaceFromServer({ notify: true, sessionId, persistSessionId: true });
            if (!loaded) {
                setServerSessionId(sessionId);
                safeShowNotification(`Session ID imported, but no server workspace was found for ${sessionId}.`, true);
            }
        } catch (err) {
            safeShowNotification(`Session ID upload failed: ${err.message}`, true);
        } finally {
            input.value = '';
        }
    };
    reader.readAsText(file);
}

async function loadWorkspaceFromSessionInput() {
    const input = document.getElementById('server-session-load-input');
    const sessionId = input ? input.value.trim() : '';
    if (!sessionId) {
        safeShowNotification('Enter a session ID to load.', true);
        return;
    }
    const loaded = await loadLatestWorkspaceFromServer({ notify: true, sessionId, persistSessionId: true });
    if (!loaded) {
        safeShowNotification(`No server workspace was loaded for session ${sessionId}.`, true);
    }
}

window.getServerSessionId = getServerSessionId;
window.copyServerSessionId = copyServerSessionId;
window.downloadServerSessionIdJson = downloadServerSessionIdJson;
window.uploadServerSessionIdJson = uploadServerSessionIdJson;
window.pasteServerSessionIdIntoInput = pasteServerSessionIdIntoInput;
window.regenerateServerSessionId = regenerateServerSessionId;
window.loadWorkspaceFromSessionInput = loadWorkspaceFromSessionInput;

const DD_DATABASE_API_FILE = `${window.location.origin}/DialogueDesigner.php`;
const FSG_SHARED_AUTH_API_FILE = `${window.location.origin}/Auth.php`;
window.DD_RESOLVED_DATABASE_API_FILE = window.DD_RESOLVED_DATABASE_API_FILE || '';
window.DD_RESOLVED_AUTH_API_FILE = window.DD_RESOLVED_AUTH_API_FILE || '';

function uniqueStrings(values) {
    const seen = new Set();
    const out = [];
    values.forEach(value => {
        const text = String(value || '').trim();
        if (!text || seen.has(text)) return;
        seen.add(text);
        out.push(text);
    });
    return out;
}

function getApiCandidates(fileName) {
    return uniqueStrings([fileName]);
}

function getDatabaseApiCandidates() {
    return getApiCandidates(DD_DATABASE_API_FILE);
}

function getAuthApiCandidates() {
    return getApiCandidates(FSG_SHARED_AUTH_API_FILE);
}

function buildDatabaseApiUrl(apiFile, action, query = {}) {
    const params = new URLSearchParams();
    params.set('action', action);
    Object.entries(query || {}).forEach(([key, value]) => {
        if (value !== undefined && value !== null && String(value).trim() !== '') {
            params.set(key, String(value));
        }
    });
    return `${apiFile}?${params.toString()}`;
}

async function resolveApiFile(cacheKey, candidates, healthAction, expectedApiName) {
    if (window[cacheKey]) return window[cacheKey];

    const failures = [];
    for (const candidate of candidates) {
        try {
            const response = await fetch(buildDatabaseApiUrl(candidate, healthAction), {
                method: 'GET',
                cache: 'no-store',
                credentials: 'same-origin'
            });

            const contentType = (response.headers.get('content-type') || '').toLowerCase();
            if (response.ok && contentType.includes('application/json')) {
                const data = await response.clone().json().catch(() => null);
                if (!expectedApiName || !data || data.api === expectedApiName || data.ok === true) {
                    window[cacheKey] = candidate;
                    console.info(`Dialogue Designer API resolved at root path: ${candidate}`);
                    return candidate;
                }
            }

            failures.push(`${candidate} -> HTTP ${response.status}`);
        } catch (err) {
            failures.push(`${candidate} -> ${err.message}`);
        }
    }

    throw new Error(`Could not find ${expectedApiName || 'server API'} endpoint. Checked: ${failures.join(' | ')}`);
}

async function fetchDatabaseApi(action, options = {}) {
    const apiFile = await resolveApiFile('DD_RESOLVED_DATABASE_API_FILE', getDatabaseApiCandidates(), 'health', 'DialogueDesigner');
    const { query, ...fetchOptions } = options || {};
    if (!fetchOptions.credentials) fetchOptions.credentials = 'include';
    applyAuthHeaders(fetchOptions);
    try {
        const response = await fetch(buildDatabaseApiUrl(apiFile, action, withSharedAuthQuery(query || {})), fetchOptions);
        if (response.status === 404 && action !== 'health') {
            window.DD_RESOLVED_DATABASE_API_FILE = '';
        }
        return response;
    } catch (err) {
        window.DD_RESOLVED_DATABASE_API_FILE = '';
        throw new Error(`Could not reach ${apiFile}: ${err.message}`);
    }
}

async function fetchSharedAuthApi(action, options = {}) {
    const apiFile = await resolveApiFile('DD_RESOLVED_AUTH_API_FILE', getAuthApiCandidates(), 'health', 'Auth');
    const { query, ...fetchOptions } = options || {};
    if (!fetchOptions.credentials) fetchOptions.credentials = 'include';
    applyAuthHeaders(fetchOptions);
    try {
        const response = await fetch(buildDatabaseApiUrl(apiFile, action, withSharedAuthQuery(query || {})), fetchOptions);
        if (response.status === 404 && action !== 'health') {
            window.DD_RESOLVED_AUTH_API_FILE = '';
        }
        return response;
    } catch (err) {
        window.DD_RESOLVED_AUTH_API_FILE = '';
        throw new Error(`Could not reach ${apiFile}: ${err.message}`);
    }
}

async function readDatabaseApiJson(response) {
    const contentType = (response.headers.get('content-type') || '').toLowerCase();
    if (!contentType.includes('application/json')) {
        const text = await response.text();
        const preview = text.replace(/\s+/g, ' ').trim().slice(0, 180);
        throw new Error(`The database API did not return JSON. HTTP ${response.status}${preview ? `: ${preview}` : ''}`);
    }
    return await response.json();
}

function setPushButtonTemporaryLabel(text, isBusy = false) {
    const button = document.getElementById('push-server-button');
    if (!button) return;
    const label = button.querySelector('span');
    if (isBusy) {
        button.classList.remove('error');
        button.classList.add('saving');
        button.disabled = true;
    }
    if (label) label.textContent = text;
}

function clearPushButtonTemporaryLabel() {
    const button = document.getElementById('push-server-button');
    if (!button) return;
    button.classList.remove('saving');
    button.disabled = false;
    updatePushToServerButton();
}

function createBlankWorkspaceData() {
    return {
        version: "2.18",
        availableLanguages: ['ENG'],
        currentLanguage: 'ENG',
        cast: [],
        globalTokens: [],
        globalStates: [],
        globalMoods: [],
        globalSettings: [],
        globalTimesOfDay: [],
        globalDaysOfWeek: [],
        globalMenuOptions: [],
        globalImageSequences: [],
        conversations: [],
        sequences: []
    };
}


function resetProjectContextUI(options = {}) {
    window.activeIndex = null;
    window.activeType = window.activeType || 'conversation';
    window.activeNavIndex = -1;
    window.currentlyVisibleIndex = -1;
    window.lastTraversedIndex = -1;
    window.editingResponseRef = null;
    window.editTarget = { type: null, index: null, seqIndex: null, imgIndex: null };
    window.renamingProject = { type: null, index: null };
    window.contextMenuTarget = null;
    window.activeProjectTagCache = [];

    const setValue = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.value = value;
    };
    const setChecked = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.checked = value;
    };
    const setHtml = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = value;
    };
    const setText = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    };
    const setDisplay = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.style.display = value;
    };

    setValue('edit-conv-name', '');
    setValue('edit-conv-color', '#00f2ff');
    setChecked('repeatable-toggle', false);
    setValue('repeat-variable-input', '');
    setDisplay('repeat-variable-container', 'none');
    setHtml('project-id-row', '');
    setHtml('dynamic-lang-row', '');
    setHtml('local-cast-tags', '');
    setHtml('add-to-local-cast', '<option value="">+ Add Character to Scene</option>');
    setHtml('node-container', '');
    setHtml('project-tags-list', '');
    setValue('search-tags', '');
    setDisplay('active-project-tags-section', 'none');
    setDisplay('active-editor-content', 'none');
    setDisplay('editor-placeholder', 'block');

    const downloadButton = document.getElementById('download-single-project');
    if (downloadButton) downloadButton.disabled = true;

    const pushButton = document.getElementById('push-server-button');
    if (pushButton) {
        pushButton.classList.remove('dirty', 'saving', 'error');
        pushButton.disabled = false;
        const label = pushButton.querySelector('span');
        if (label) label.textContent = 'Push To Server';
    }

    const kindConversation = document.getElementById('project-kind-conversation');
    const kindSequence = document.getElementById('project-kind-sequence');
    if (kindConversation) {
        kindConversation.classList.remove('active');
        kindConversation.setAttribute('aria-checked', 'false');
    }
    if (kindSequence) {
        kindSequence.classList.remove('active');
        kindSequence.setAttribute('aria-checked', 'false');
    }

    if (options.clearDraftInputs) {
        [
            'new-token-key', 'custom-participant-name', 'custom-state-name', 'custom-mood-name',
            'custom-setting-name', 'custom-time-name', 'custom-day-name', 'custom-menu-name',
            'custom-image-seq-name', 'new-conv-name', 'search-statements', 'search-conversations',
            'search-sequences'
        ].forEach(id => setValue(id, ''));
        ['custom-participant-color', 'custom-state-color', 'custom-mood-color', 'custom-setting-color',
         'custom-time-color', 'custom-day-color', 'custom-menu-color', 'custom-image-seq-color'
        ].forEach(id => setValue(id, '#00f2ff'));
    }

    if (typeof updateProjectKindSwitch === 'function') updateProjectKindSwitch();
    if (typeof updateProjectTitleEditorLabel === 'function') updateProjectTitleEditorLabel();
    if (typeof updatePushToServerButton === 'function') updatePushToServerButton();
}

window.resetProjectContextUI = resetProjectContextUI;

function isEmptyWorkspacePayload(data) {
    if (data === null || data === undefined) return true;
    if (typeof data !== 'object') return false;
    const meaningfulKeys = Object.keys(data).filter(key => !['version', 'availableLanguages', 'currentLanguage', 'serverSessionId', 'exportedAt'].includes(key));
    if (meaningfulKeys.length === 0) return true;
    return meaningfulKeys.every(key => {
        const value = data[key];
        if (value === null || value === undefined) return true;
        if (Array.isArray(value)) return value.length === 0;
        if (typeof value === 'object') return Object.keys(value).length === 0;
        if (typeof value === 'string') return value.trim() === '';
        return false;
    });
}

function applyWorkspaceData(data, options = {}) {
    const mergeGlobalSidebar = shouldMergeGlobalSidebarOnApply(options);
    const previousGlobalSidebarData = mergeGlobalSidebar ? captureCurrentGlobalSidebarData() : null;

    if (data === null || data === undefined || isEmptyWorkspacePayload(data)) {
        data = createBlankWorkspaceData();
    }
    if (typeof data !== 'object') {
        throw new Error('Workspace data was invalid.');
    }

    window.editingResponseRef = null;
    window.editTarget = { type: null, index: null, seqIndex: null, imgIndex: null };
    window.renamingProject = { type: null, index: null };
    window.isAddingLanguage = false;
    window.openImageSeqs = new Set();
    window.editedNodes = new Set();
    window.currentLanguage = 'ENG';
    window.availableLanguages = ['ENG'];

    const normalizedGlobalSidebarData = normalizeWorkspaceGlobalSidebarData(data, previousGlobalSidebarData);
    applyNormalizedGlobalSidebarData(normalizedGlobalSidebarData);
    applyImportedLanguageSettings(data);

    window.conversations = Array.isArray(data.conversations) ? data.conversations : [];
    window.sequences = Array.isArray(data.sequences) ? data.sequences : [];

    let autoOpenType = null;

    if (data.nodes && window.conversations.length === 0 && window.sequences.length === 0) {
        const legacyProj = {
            id: data.id || crypto.randomUUID(),
            title: data.title || (data.sequenceName ? data.sequenceName : 'Migrated V1 Project'),
            color: data.color || getSafeRandomColor(),
            participants: data.participants || (data.cast ? data.cast.map(c => typeof c === 'object' ? c.name : c) : []),
            nodes: data.nodes || [],
            isRepeatable: data.isRepeatable || false,
            repeatVariable: data.repeatVariable || ''
        };

        if (legacyProj.participants.length === 0) {
            const uniqueSpeakers = new Set();
            legacyProj.nodes.forEach(n => {
                if (n.speaker) uniqueSpeakers.add(n.speaker);
                (n.responses || []).forEach(r => {
                    if (r.speaker) uniqueSpeakers.add(r.speaker);
                });
            });
            legacyProj.participants = Array.from(uniqueSpeakers);
        }

        if (legacyProj.nodes.length > 0 && (legacyProj.nodes[0].controlSequence || legacyProj.nodes[0].sequenceName || data.sequenceName)) {
            if (data.sequenceName) legacyProj.title = data.sequenceName;
            window.sequences.push(legacyProj);
            autoOpenType = 'sequence';
        } else {
            window.conversations.push(legacyProj);
            autoOpenType = 'conversation';
        }
    }

    window.conversations.forEach(normalizeProject);
    window.sequences.forEach(normalizeProject);

    window.sequences.forEach(seq => {
        if (!window.globalImageSequences.some(s => s.name === seq.title)) {
            window.globalImageSequences.push({ name: seq.title, color: seq.color || getSafeRandomColor(), path: 'Assets/2D/Sequences/', images: [] });
        }
    });

    if (typeof collectLanguagesFromProjects === 'function') collectLanguagesFromProjects([...window.conversations, ...window.sequences]);
    if (typeof ensureAllTranslationContainers === 'function') ensureAllTranslationContainers();

    if (typeof renderTokens === 'function') renderTokens();
    if (typeof renderCast === 'function') renderCast();
    if (typeof renderStates === 'function') renderStates();
    if (typeof renderMoods === 'function') renderMoods();
    if (typeof renderSettings === 'function') renderSettings();
    if (typeof renderTimesOfDay === 'function') renderTimesOfDay();
    if (typeof renderDaysOfWeek === 'function') renderDaysOfWeek();
    if (typeof renderMenuOptions === 'function') renderMenuOptions();
    if (typeof renderImageSequences === 'function') renderImageSequences();
    if (typeof renderConversations === 'function') renderConversations();
    if (typeof renderSequences === 'function') renderSequences();

    if (autoOpenType === 'conversation' && typeof openEditor === 'function') {
        openEditor(0, 'conversation');
    } else if (autoOpenType === 'sequence' && typeof openEditor === 'function') {
        openEditor(0, 'sequence');
    } else if (window.conversations.length > 0 && typeof openEditor === 'function') {
        openEditor(0, 'conversation');
    } else if (window.sequences.length > 0 && typeof openEditor === 'function') {
        openEditor(0, 'sequence');
    } else {
        resetProjectContextUI({ clearDraftInputs: true });
    }

    if (typeof renderProjectTags === 'function') renderProjectTags();
    else if (typeof renderActiveProjectLogic === 'function') renderActiveProjectLogic();

    if (options.fromServer) {
        const serverHash = hashWorkspacePayload(data);
        window.lastServerWorkspaceHash = serverHash;
        localStorage.setItem('DD_lastServerWorkspaceHash', serverHash);
        window.workspaceHasServerDelta = false;
        updatePushToServerButton();
    }
}

async function loadLatestWorkspaceFromServer(options = {}) {
    const notify = !!options.notify;
    const requestedSessionId = String(options.sessionId || getServerSessionId()).trim();
    try {
        setPushButtonTemporaryLabel('Pulling...', true);
        const response = await fetchDatabaseApi('loadLatestSuite', { method: 'GET', cache: 'no-store', query: { sessionId: requestedSessionId } });
        const result = await readDatabaseApiJson(response);

        if (!response.ok || !result.ok) {
            const message = (result && result.error) ? result.error : `Server load failed with HTTP ${response.status}.`;
            throw new Error(message);
        }

        if (result.hasWorkspace === false || result.data === null) {
            if (options.persistSessionId || notify) {
                setServerSessionId(requestedSessionId);
                applyWorkspaceData(createBlankWorkspaceData(), { fromServer: true });
                if (notify) safeShowNotification(`No server workspace exists for ${requestedSessionId}; local editor was cleared for that session.`);
                return true;
            }
            schedulePushStateRefresh();
            return false;
        }

        let workspaceData = result.data || result.workspace || null;
        if ((workspaceData === null || workspaceData === undefined) && typeof result.raw_json === 'string') {
            const raw = result.raw_json.trim();
            workspaceData = raw ? JSON.parse(raw) : createBlankWorkspaceData();
        }
        if (workspaceData === null || workspaceData === undefined || isEmptyWorkspacePayload(workspaceData)) {
            workspaceData = createBlankWorkspaceData();
        }

        if (options.persistSessionId) {
            setServerSessionId(requestedSessionId);
        }

        window.DD_LAST_SERVER_PULL = {
            loadedAt: new Date().toISOString(),
            workspaceId: result.workspaceId || '',
            sessionId: result.sessionId || requestedSessionId,
            createdAt: result.createdAt || '',
            conversationCount: Array.isArray(workspaceData.conversations) ? workspaceData.conversations.length : 0,
            sequenceCount: Array.isArray(workspaceData.sequences) ? workspaceData.sequences.length : 0
        };
        console.info('Dialogue Designer loaded workspace from server:', window.DD_LAST_SERVER_PULL);
        applyWorkspaceData(workspaceData, { fromServer: true });
        if (notify) {
            safeShowNotification('Pulled latest workspace from server.');
            if (typeof showFastScrollIndicator === 'function') showFastScrollIndicator('Session Loaded', { timeout: 1200 });
        }
        return true;
    } catch (err) {
        console.warn('Server workspace pull skipped:', err.message);
        if (notify) safeShowNotification(`Server pull failed: ${err.message}`, true);
        schedulePushStateRefresh();
        return false;
    } finally {
        clearPushButtonTemporaryLabel();
        schedulePushStateRefresh();
    }
}

async function refreshServerBaselineFromLatest() {
    try {
        const response = await fetchDatabaseApi('loadLatestSuite', { method: 'GET', cache: 'no-store', query: { sessionId: getServerSessionId() } });
        const result = await readDatabaseApiJson(response);
        if (response.ok && result && result.ok && result.data) {
            window.lastServerWorkspaceHash = hashWorkspacePayload(result.data);
            localStorage.setItem('DD_lastServerWorkspaceHash', window.lastServerWorkspaceHash);
        }
    } catch (err) {
        console.warn('Server baseline check skipped:', err.message);
    }
    schedulePushStateRefresh();
}

window.createBlankWorkspaceData = createBlankWorkspaceData;
window.applyWorkspaceData = applyWorkspaceData;
window.loadLatestWorkspaceFromServer = loadLatestWorkspaceFromServer;

function finishServerBootstrap(workspaceLoaded) {
    window.DD_SERVER_BOOTSTRAP_PENDING = false;
    window.DD_SERVER_BOOTSTRAP_DONE = true;
    if (!workspaceLoaded && typeof initializeDefaultWorkspace === 'function') {
        initializeDefaultWorkspace();
    }
}

async function bootDialogueDesignerFromServer() {
    updatePushToServerButton();
    const loaded = await loadLatestWorkspaceFromServer({ notify: false, bootstrap: true });
    finishServerBootstrap(loaded);
}

function scheduleDialogueDesignerServerBoot() {
    if (window.DD_SERVER_BOOTSTRAP_STARTED) return;
    window.DD_SERVER_BOOTSTRAP_STARTED = true;
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootDialogueDesignerFromServer, { once: true });
    } else {
        setTimeout(bootDialogueDesignerFromServer, 0);
    }
}


const originalMarkNodeEditedForServerPush = window.markNodeEdited;
window.markNodeEdited = function(nIdx) {
    if (typeof originalMarkNodeEditedForServerPush === 'function') originalMarkNodeEditedForServerPush(nIdx);
    markWorkspaceDirty();
};

async function saveProjectToDatabase() {
    if (!isDialogueDesignerAccountLoggedIn()) {
        safeShowNotification('Log in before pushing this workspace to the server.', true);
        if (typeof openAccountModal === 'function') openAccountModal();
        updatePushToServerButton();
        return;
    }
    const projectData = buildWorkspacePayload();
    const button = document.getElementById('push-server-button');
    const label = button ? button.querySelector('span') : null;
    const oldLabel = label ? label.textContent : '';

    try {
        if (button) {
            button.classList.remove('dirty', 'error');
            button.classList.add('saving');
            button.disabled = true;
        }
        if (label) label.textContent = 'Pushing...';
        safeShowNotification('Pushing workspace to server...');

        const response = await fetchDatabaseApi('saveSuite', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(projectData)
        });

        const result = await readDatabaseApiJson(response);

        if (!response.ok || !result.ok) {
            throw new Error((result && result.error) ? result.error : `Database save failed with HTTP ${response.status}.`);
        }

        window.lastServerWorkspaceHash = hashWorkspacePayload(projectData);
        localStorage.setItem('DD_lastServerWorkspaceHash', window.lastServerWorkspaceHash);
        window.workspaceHasServerDelta = false;

        if (button) {
            button.classList.remove('saving', 'error', 'dirty');
            button.disabled = false;
        }
        if (label) label.textContent = 'Push To Server';
        updatePushToServerButton();
        safeShowNotification(`Server push complete: ${result.workspaceId || 'workspace stored'}`);
        if (typeof showFastScrollIndicator === 'function') showFastScrollIndicator('Server Pushed', { timeout: 1200 });
        if (result && result.account && typeof setCurrentAccountState === 'function') {
            setCurrentAccountState(result.account, true);
            renderAccountModal();
            updatePushToServerButton();
        } else if (result && Array.isArray(result.sessions) && window.DD_ACCOUNT && window.DD_ACCOUNT.loggedIn && typeof setCurrentAccountState === 'function') {
            setCurrentAccountState({ loggedIn: true, user: window.DD_ACCOUNT.user, sessions: result.sessions }, true);
            renderAccountModal();
            updatePushToServerButton();
        }
        if (typeof refreshAccountStatus === 'function') {
            await refreshAccountStatus(false, { keepCachedOnFailure: true, preserveCurrentOnLoggedOut: true });
        }
    } catch (err) {
        console.error('Database save failed', err);
        if (button) {
            button.classList.remove('saving', 'dirty');
            button.classList.add('error');
            button.disabled = false;
        }
        if (label) label.textContent = 'Push Failed';
        setTimeout(() => {
            if (button) button.classList.remove('error');
            if (label) label.textContent = oldLabel || 'Push To Server';
            updatePushToServerButton();
        }, 1800);
        safeShowNotification(`Server push failed: ${err.message}`, true);
    }
}



// --- ACCOUNT MANAGEMENT ---
window.DD_ACCOUNT = window.DD_ACCOUNT || { loggedIn: false, user: null, sessions: [] };
window.pendingAccountSessionToLoad = '';
window.DD_ACCOUNT_STATUS_LOADING = false;

const DD_ACCOUNT_CACHE_KEY = 'DD_cachedSharedAuthAccount';

function normalizeSharedAuthAccountPayload(payload) {
    const source = payload && typeof payload === 'object' ? payload : {};
    const loggedIn = !!source.loggedIn;
    const user = loggedIn && source.user && typeof source.user === 'object' ? source.user : null;
    const sessions = Array.isArray(source.sessions) ? source.sessions : [];
    const incomingToken = source.authToken || source.token || source.bearerToken || '';
    const authToken = loggedIn ? (String(incomingToken || getStoredAuthToken() || '').trim()) : '';
    return { loggedIn, user, sessions, authToken };
}

function loadCachedAccountStatus() {
    try {
        const raw = localStorage.getItem(DD_ACCOUNT_CACHE_KEY);
        if (!raw) return null;
        const parsed = JSON.parse(raw);
        if (!parsed || parsed.loggedIn !== true || !parsed.user) return null;
        return normalizeSharedAuthAccountPayload(parsed);
    } catch (err) {
        return null;
    }
}

function saveCachedAccountStatus(account) {
    try {
        const normalized = normalizeSharedAuthAccountPayload(account);
        if (normalized && normalized.loggedIn && normalized.user) {
            if (normalized.authToken) setStoredAuthToken(normalized.authToken);
            localStorage.setItem(DD_ACCOUNT_CACHE_KEY, JSON.stringify(normalized));
        } else {
            localStorage.removeItem(DD_ACCOUNT_CACHE_KEY);
            setStoredAuthToken('');
        }
    } catch (err) {}
}

function setCurrentAccountState(account, cache = true) {
    window.DD_ACCOUNT = normalizeSharedAuthAccountPayload(account);
    if (cache) saveCachedAccountStatus(window.DD_ACCOUNT);
    if (typeof updatePushToServerButton === 'function') updatePushToServerButton();
    return window.DD_ACCOUNT;
}


function accountPasswordIsValid(password) {
    return /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z0-9]).{8,}/.test(String(password || ''));
}

function showAccountMessage(message, isError = false) {
    const box = document.getElementById('account-status-message');
    if (!box) return;
    box.textContent = message || '';
    box.style.display = message ? 'block' : 'none';
    box.classList.toggle('error', !!isError);
}


function ensureAccountModalMarkup() {
    let modal = document.getElementById('account-modal');
    if (modal) return modal;

    const wrap = document.createElement('div');
    wrap.innerHTML = `
    <div id="account-modal" class="modal-overlay account-modal-overlay" role="dialog" aria-modal="true" aria-labelledby="account-modal-title">
        <div class="modal-content account-modal-content">
            <div class="modal-title-row">
                <h3 id="account-modal-title">Manage Account</h3>
                <button class="modal-x-button" type="button" onclick="closeAccountModal()">×</button>
            </div>
            <div id="account-status-message" class="account-status-message" style="display:none;"></div>
            <div id="account-auth-view">
                <div class="account-auth-tabs">
                    <button id="account-login-tab" type="button" onclick="switchAccountAuthTab('login')">Login</button>
                    <button id="account-register-tab" type="button" onclick="switchAccountAuthTab('register')">Register</button>
                </div>
                <form id="account-login-form" class="account-form" onsubmit="submitAccountLogin(event)">
                    <label>Username or Email</label>
                    <input id="account-login-identity" type="text" autocomplete="username" required>
                    <label>Password</label>
                    <input id="account-login-password" type="password" autocomplete="current-password" required>
                    <button class="btn btn-teal account-primary-action" type="submit">Login</button>
                </form>
                <form id="account-register-form" class="account-form" onsubmit="submitAccountRegister(event)" style="display:none;">
                    <label>Email</label>
                    <input id="account-register-email" type="email" autocomplete="email" required>
                    <label>Username</label>
                    <input id="account-register-username" type="text" autocomplete="username" required>
                    <label>Password</label>
                    <input id="account-register-password-1" type="password" autocomplete="new-password" required>
                    <label>Confirm Password</label>
                    <input id="account-register-password-2" type="password" autocomplete="new-password" required>
                    <p class="account-password-rule">Password must be 8+ characters and include uppercase, lowercase, number, and special character.</p>
                    <label class="account-checkbox-line"><input id="account-register-over18" type="checkbox"> <span>I confirm I am 18+.</span></label>
                    <label class="account-checkbox-line"><input id="account-register-terms" type="checkbox"> <span>I agree to the <a href="about:blank" target="_blank" rel="noopener noreferrer">Terms of Service</a>.</span></label>
                    <label class="account-checkbox-line"><input id="account-register-privacy" type="checkbox"> <span>I agree to the <a href="about:blank" target="_blank" rel="noopener noreferrer">Privacy Policy</a>.</span></label>
                    <button class="btn btn-teal account-primary-action" type="submit">Register</button>
                </form>
            </div>
            <div id="account-profile-view" style="display:none;">
                <div class="account-profile-header">
                    <div>
                        <div class="account-profile-username" id="account-profile-username-display">Username</div>
                        <div class="account-profile-email" id="account-profile-email-display">email@example.com</div>
                    </div>
                    <button class="btn btn-outline account-logout-button" type="button" onclick="submitAccountLogout()">Logout</button>
                </div>
                <details class="account-profile-section" open>
                    <summary>Profile</summary>
                    <form class="account-form" onsubmit="submitAccountProfileUpdate(event)">
                        <label>Username</label>
                        <input id="account-profile-username-input" type="text" required>
                        <label>Email</label>
                        <input id="account-profile-email-input" type="email" required>
                        <button class="btn btn-teal account-primary-action" type="submit">Update Profile</button>
                    </form>
                </details>
                <details class="account-profile-section">
                    <summary>Password Reset</summary>
                    <form class="account-form" onsubmit="submitAccountPasswordChange(event)">
                        <label>New Password</label>
                        <input id="account-profile-password-1" type="password" autocomplete="new-password" required>
                        <label>Confirm New Password</label>
                        <input id="account-profile-password-2" type="password" autocomplete="new-password" required>
                        <p class="account-password-rule">Password must be 8+ characters and include uppercase, lowercase, number, and special character.</p>
                        <button class="btn btn-teal account-primary-action" type="submit">Reset Password</button>
                    </form>
                </details>
                <div class="account-sessions-wrap">
                    <h3>Saved Server Sessions</h3>
                    <div id="account-session-list" class="account-session-list scrollable"></div>
                </div>
            </div>
        </div>
    </div>`;
    modal = wrap.firstElementChild;
    document.body.appendChild(modal);
    return modal;
}

async function openAccountModal() {
    const modal = ensureAccountModalMarkup();
    if (modal) {
        modal.style.display = 'flex';
        modal.classList.add('account-modal-open');
    }

    showAccountMessage('');

    const cached = loadCachedAccountStatus();
    if ((!window.DD_ACCOUNT || !window.DD_ACCOUNT.loggedIn) && cached && cached.loggedIn) {
        setCurrentAccountState(cached, false);
    }

    renderAccountModal();
    if (!window.DD_ACCOUNT || !window.DD_ACCOUNT.loggedIn) {
        showAccountMessage('Checking shared login...');
    }

    await refreshAccountStatus(false, { keepCachedOnFailure: true, preserveCurrentOnLoggedOut: true, fromModalOpen: true });
    showAccountMessage('');
}

function closeAccountModal() {
    const modal = document.getElementById('account-modal');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('account-modal-open');
    }
}

function switchAccountAuthTab(tab) {
    const loginForm = document.getElementById('account-login-form');
    const registerForm = document.getElementById('account-register-form');
    const loginTab = document.getElementById('account-login-tab');
    const registerTab = document.getElementById('account-register-tab');
    if (loginForm) loginForm.style.display = tab === 'register' ? 'none' : 'flex';
    if (registerForm) registerForm.style.display = tab === 'register' ? 'flex' : 'none';
    if (loginTab) loginTab.classList.toggle('active', tab !== 'register');
    if (registerTab) registerTab.classList.toggle('active', tab === 'register');
}

function renderAccountModal() {
    const authView = document.getElementById('account-auth-view');
    const profileView = document.getElementById('account-profile-view');
    const title = document.getElementById('account-modal-title');
    const account = window.DD_ACCOUNT || { loggedIn: false };
    const loggedIn = !!account.loggedIn;
    if (authView) authView.style.display = loggedIn ? 'none' : 'block';
    if (profileView) profileView.style.display = loggedIn ? 'block' : 'none';
    if (title) {
        const usernameForTitle = account && account.user && account.user.username ? account.user.username : 'Manage Account';
        title.textContent = loggedIn ? usernameForTitle : 'Login / Register';
    }

    const button = document.getElementById('account-management-button');
    if (button) button.classList.toggle('logged-in', loggedIn);
    if (typeof updatePushToServerButton === 'function') updatePushToServerButton();

    if (!loggedIn) {
        switchAccountAuthTab('login');
        return;
    }

    const user = account.user || {};
    const username = user.username || '';
    const email = user.email || '';
    const usernameDisplay = document.getElementById('account-profile-username-display');
    const emailDisplay = document.getElementById('account-profile-email-display');
    const usernameInput = document.getElementById('account-profile-username-input');
    const emailInput = document.getElementById('account-profile-email-input');
    if (usernameDisplay) usernameDisplay.textContent = username;
    if (emailDisplay) emailDisplay.textContent = email;
    if (usernameInput) usernameInput.value = username;
    if (emailInput) emailInput.value = email;

    const sessionList = document.getElementById('account-session-list');
    if (sessionList) {
        const sessions = Array.isArray(account.sessions) ? account.sessions : [];
        sessionList.innerHTML = sessions.length ? sessions.map(session => {
            const sid = String(session.session_id || session.sessionId || '');
            const viewed = String(session.last_viewed_at || session.lastViewedAt || session.last_pushed_at || '');
            return `<div class="account-session-row" ondblclick="openAccountSessionConfirmModal('${escapeHtml(sid)}')">
                <div class="account-session-main"><code>${escapeHtml(sid)}</code><span>${escapeHtml(viewed)}</span></div>
                <button type="button" title="Copy Session ID" onclick="copyToClipboard('${escapeHtml(sid)}', this); event.stopPropagation();">${typeof getCopyIcon === 'function' ? getCopyIcon() : '⧉'}</button>
            </div>`;
        }).join('') : '<div class="account-empty-sessions">No pushed sessions yet.</div>';
    }
}

async function refreshAccountStatus(autoLoadMostRecent = false, options = {}) {
    const keepCachedOnFailure = !!(options && options.keepCachedOnFailure);
    window.DD_ACCOUNT_STATUS_LOADING = true;
    try {
        const response = await fetchSharedAuthApi('authStatus', { method: 'GET', cache: 'no-store' });
        const result = await readDatabaseApiJson(response);
        if (response.ok && result.ok) {
            if (options && options.preserveCurrentOnLoggedOut && result.loggedIn !== true && window.DD_ACCOUNT && window.DD_ACCOUNT.loggedIn) {
                renderAccountModal();
                updatePushToServerButton();
                return window.DD_ACCOUNT;
            }
            const account = setCurrentAccountState(result, true);
            renderAccountModal();
            updatePushToServerButton();
            if (autoLoadMostRecent && account.loggedIn && account.sessions && account.sessions.length > 0) {
                const mostRecent = String(account.sessions[0].session_id || account.sessions[0].sessionId || '').trim();
                if (mostRecent && mostRecent !== getServerSessionId()) {
                    setServerSessionId(mostRecent);
                    applyWorkspaceData(createBlankWorkspaceData(), { fromServer: true });
                    await loadLatestWorkspaceFromServer({ notify: true, sessionId: mostRecent, persistSessionId: true });
                }
            }
            return account;
        }
        throw new Error((result && result.error) ? result.error : 'Shared auth status failed.');
    } catch (err) {
        console.warn('Account status unavailable:', err.message);
        const cached = loadCachedAccountStatus();
        if (keepCachedOnFailure && cached && cached.loggedIn) {
            setCurrentAccountState(cached, false);
            renderAccountModal();
            return window.DD_ACCOUNT;
        }
        if (!keepCachedOnFailure) {
            if (options && options.preserveCurrentOnLoggedOut && window.DD_ACCOUNT && window.DD_ACCOUNT.loggedIn) {
                renderAccountModal();
                updatePushToServerButton();
                return window.DD_ACCOUNT;
            }
            setCurrentAccountState({ loggedIn: false, user: null, sessions: [] }, true);
            renderAccountModal();
            updatePushToServerButton();
        }
        return window.DD_ACCOUNT || { loggedIn: false, user: null, sessions: [] };
    } finally {
        window.DD_ACCOUNT_STATUS_LOADING = false;
    }
}

async function submitAccountLogin(event) {
    event.preventDefault();
    showAccountMessage('Logging in...');
    const identity = document.getElementById('account-login-identity').value.trim();
    const password = document.getElementById('account-login-password').value;
    try {
        const response = await fetchSharedAuthApi('login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ identity, password }) });
        const result = await readDatabaseApiJson(response);
        if (!response.ok || !result.ok) throw new Error(result.error || 'Login failed.');
        setCurrentAccountState(result, true);
        renderAccountModal();
        updatePushToServerButton();
        closeAccountModal();
        if (typeof showFastScrollIndicator === 'function') showFastScrollIndicator(`Logged In: ${(result.user && result.user.username) || identity}`, { timeout: 1500 });
        await refreshAccountStatus(true, { keepCachedOnFailure: true, preserveCurrentOnLoggedOut: true });
    } catch (err) {
        showAccountMessage(err.message, true);
    }
}

async function submitAccountRegister(event) {
    event.preventDefault();
    showAccountMessage('Registering...');
    const email = document.getElementById('account-register-email').value.trim();
    const username = document.getElementById('account-register-username').value.trim();
    const password1 = document.getElementById('account-register-password-1').value;
    const password2 = document.getElementById('account-register-password-2').value;
    const over18 = document.getElementById('account-register-over18').checked;
    const terms = document.getElementById('account-register-terms').checked;
    const privacy = document.getElementById('account-register-privacy').checked;
    if (password1 !== password2) { showAccountMessage('Passwords do not match.', true); return; }
    if (!accountPasswordIsValid(password1)) { showAccountMessage('Password must be 8+ characters with uppercase, lowercase, number, and special character.', true); return; }
    if (!over18 || !terms || !privacy) { showAccountMessage('You must confirm 18+ and agree to the Terms of Service and Privacy Policy.', true); return; }
    try {
        const response = await fetchSharedAuthApi('register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, username, password: password1, passwordConfirm: password2, over18, terms, privacy }) });
        const result = await readDatabaseApiJson(response);
        if (!response.ok || !result.ok) throw new Error(result.error || 'Registration failed.');
        setCurrentAccountState(result, true);
        renderAccountModal();
        updatePushToServerButton();
        closeAccountModal();
        if (typeof showFastScrollIndicator === 'function') showFastScrollIndicator(`Logged In: ${username}`, { timeout: 1500 });
        await refreshAccountStatus(true, { keepCachedOnFailure: true, preserveCurrentOnLoggedOut: true });
    } catch (err) {
        showAccountMessage(err.message, true);
    }
}

async function submitAccountProfileUpdate(event) {
    event.preventDefault();
    showAccountMessage('Updating profile...');
    const username = document.getElementById('account-profile-username-input').value.trim();
    const email = document.getElementById('account-profile-email-input').value.trim();
    try {
        const response = await fetchSharedAuthApi('updateProfile', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username, email }) });
        const result = await readDatabaseApiJson(response);
        if (!response.ok || !result.ok) throw new Error(result.error || 'Profile update failed.');
        setCurrentAccountState(result, true);
        renderAccountModal();
        showAccountMessage('Profile updated.');
        if (typeof showFastScrollIndicator === 'function') showFastScrollIndicator('Profile Updated', { timeout: 1200 });
    } catch (err) {
        showAccountMessage(err.message, true);
    }
}

async function submitAccountPasswordChange(event) {
    event.preventDefault();
    showAccountMessage('Updating password...');
    const password = document.getElementById('account-profile-password-1').value;
    const passwordConfirm = document.getElementById('account-profile-password-2').value;
    if (password !== passwordConfirm) { showAccountMessage('Passwords do not match.', true); return; }
    if (!accountPasswordIsValid(password)) { showAccountMessage('Password must be 8+ characters with uppercase, lowercase, number, and special character.', true); return; }
    try {
        const response = await fetchSharedAuthApi('changePassword', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password, passwordConfirm }) });
        const result = await readDatabaseApiJson(response);
        if (!response.ok || !result.ok) throw new Error(result.error || 'Password update failed.');
        document.getElementById('account-profile-password-1').value = '';
        document.getElementById('account-profile-password-2').value = '';
        showAccountMessage('Password updated.');
        if (typeof showFastScrollIndicator === 'function') showFastScrollIndicator('Password Updated', { timeout: 1200 });
    } catch (err) {
        showAccountMessage(err.message, true);
    }
}

async function submitAccountLogout() {
    try {
        await fetchSharedAuthApi('logout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) });
    } catch (err) {
        console.warn('Logout request failed:', err.message);
    }
    setCurrentAccountState({ loggedIn: false, user: null, sessions: [] }, true);
    applyWorkspaceData(createBlankWorkspaceData(), { fromServer: true });
    await regenerateServerSessionId();
    renderAccountModal();
    closeAccountModal();
    if (typeof showFastScrollIndicator === 'function') showFastScrollIndicator('Logged Out', { timeout: 1200 });
}

function openAccountSessionConfirmModal(sessionId) {
    window.pendingAccountSessionToLoad = String(sessionId || '').trim();
    const modal = document.getElementById('account-session-confirm-modal');
    const text = document.getElementById('account-session-confirm-text');
    if (text) text.textContent = `Load server session ${window.pendingAccountSessionToLoad}? Current browser data will be replaced.`;
    if (modal) modal.style.display = 'flex';
}

function closeAccountSessionConfirmModal() {
    window.pendingAccountSessionToLoad = '';
    const modal = document.getElementById('account-session-confirm-modal');
    if (modal) modal.style.display = 'none';
}

async function confirmAccountSessionLoad() {
    const sessionId = window.pendingAccountSessionToLoad;
    closeAccountSessionConfirmModal();
    if (!sessionId) return;
    applyWorkspaceData(createBlankWorkspaceData(), { fromServer: true });
    setServerSessionId(sessionId);
    await loadLatestWorkspaceFromServer({ notify: true, sessionId, persistSessionId: true });
    await refreshAccountStatus(false, { keepCachedOnFailure: true, preserveCurrentOnLoggedOut: true });
}

window.ensureAccountModalMarkup = ensureAccountModalMarkup;
window.openAccountModal = openAccountModal;
window.closeAccountModal = closeAccountModal;
window.switchAccountAuthTab = switchAccountAuthTab;
window.submitAccountLogin = submitAccountLogin;
window.submitAccountRegister = submitAccountRegister;
window.submitAccountProfileUpdate = submitAccountProfileUpdate;
window.submitAccountPasswordChange = submitAccountPasswordChange;
window.submitAccountLogout = submitAccountLogout;
window.openAccountSessionConfirmModal = openAccountSessionConfirmModal;
window.closeAccountSessionConfirmModal = closeAccountSessionConfirmModal;
window.confirmAccountSessionLoad = confirmAccountSessionLoad;
window.refreshAccountStatus = refreshAccountStatus;

document.addEventListener('DOMContentLoaded', () => {
    renderServerSessionPanel();
    refreshAccountStatus(false, { keepCachedOnFailure: true, preserveCurrentOnLoggedOut: true });
    if (!window.DD_SHARED_AUTH_STATUS_TIMER) {
        window.DD_SHARED_AUTH_STATUS_TIMER = setInterval(() => {
            if (!document.hidden && typeof refreshAccountStatus === 'function') refreshAccountStatus(false, { keepCachedOnFailure: true, preserveCurrentOnLoggedOut: true });
        }, 120000);
    }
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden && typeof refreshAccountStatus === 'function') refreshAccountStatus(false, { keepCachedOnFailure: true, preserveCurrentOnLoggedOut: true });
    });
    document.addEventListener('input', schedulePushStateRefresh, true);
    document.addEventListener('change', schedulePushStateRefresh, true);
    document.addEventListener('click', () => setTimeout(schedulePushStateRefresh, 0), true);
});

scheduleDialogueDesignerServerBoot();


function getVoiceLineExportLanguages(projectLists) {
    const languageSet = new Set();
    const baseLanguages = Array.isArray(window.availableLanguages) ? window.availableLanguages : ['ENG'];
    baseLanguages.forEach(lang => {
        const normalized = normalizeCSVLanguageHeader(lang);
        if (normalized) languageSet.add(normalized);
    });
    languageSet.add('ENG');

    projectLists.forEach(projectList => {
        (projectList || []).forEach(project => {
            (project.nodes || []).forEach(node => {
                Object.keys(node.translations || {}).forEach(lang => {
                    const normalized = normalizeCSVLanguageHeader(lang);
                    if (normalized) languageSet.add(normalized);
                });
                (node.responses || []).forEach(response => {
                    Object.keys(response.translations || {}).forEach(lang => {
                        const normalized = normalizeCSVLanguageHeader(lang);
                        if (normalized) languageSet.add(normalized);
                    });
                });
            });
        });
    });

    return Array.from(languageSet).sort((a, b) => {
        if (a === 'ENG') return -1;
        if (b === 'ENG') return 1;
        return a.localeCompare(b);
    });
}

function normalizeCSVLanguageHeader(value) {
    const normalized = String(value || '').trim().toUpperCase();
    if (!normalized) return '';
    return normalized.replace(/[^A-Z0-9_-]/g, '');
}

function getEntryTextForVoiceLineCSV(entry, language) {
    if (!entry) return '';
    const normalizedLanguage = normalizeCSVLanguageHeader(language) || 'ENG';
    if (entry.translations && Object.prototype.hasOwnProperty.call(entry.translations, normalizedLanguage)) {
        return entry.translations[normalizedLanguage] ?? '';
    }
    if (normalizedLanguage === 'ENG') return entry.text ?? '';
    return '';
}

function escapeVoiceLineCSVCell(value) {
    const text = value === null || value === undefined ? '' : String(value);
    return `"${text.replace(/"/g, '""')}"`;
}

function downloadCSVFile(csvText, prefix) {
    const blob = new Blob([`\uFEFF${csvText}`], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const dl = document.createElement('a');
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10);
    const timeStr = now.toISOString().slice(11, 19).replace(/:/g, '-');
    dl.href = url;
    dl.download = `${prefix}_${dateStr}_${timeStr}.csv`;
    document.body.appendChild(dl);
    dl.click();
    dl.remove();
    URL.revokeObjectURL(url);
}

function exportVoiceLinesCSV() {
    const conversationsList = Array.isArray(window.conversations) ? window.conversations : [];
    const sequencesList = Array.isArray(window.sequences) ? window.sequences : [];
    const projectLists = [conversationsList, sequencesList];
    const languages = getVoiceLineExportLanguages(projectLists);

    const header = [
        'Project Type',
        'Project Title',
        'Project ID',
        'Entry Type',
        'Statement ID',
        'Response ID',
        'Voice Line',
        ...languages
    ];

    const rows = [header];

    const addProjectRows = (projects, projectType) => {
        (projects || []).forEach(project => {
            const projectTitle = project && project.title ? project.title : '';
            const projectId = project && (project.projectId || project.id) ? (project.projectId || project.id) : '';
            (project.nodes || []).forEach(node => {
                rows.push([
                    projectType,
                    projectTitle,
                    projectId,
                    'Statement',
                    node.id || '',
                    '',
                    node.voiceLine === true ? 'true' : 'false',
                    ...languages.map(lang => getEntryTextForVoiceLineCSV(node, lang) || '')
                ]);

                (node.responses || []).forEach(response => {
                    rows.push([
                        projectType,
                        projectTitle,
                        projectId,
                        'Response',
                        node.id || '',
                        response.id || '',
                        response.voiceLine === true ? 'true' : 'false',
                        ...languages.map(lang => getEntryTextForVoiceLineCSV(response, lang) || '')
                    ]);
                });
            });
        });
    };

    addProjectRows(conversationsList, 'Conversation');
    addProjectRows(sequencesList, 'Sequence');

    if (rows.length === 1) {
        safeShowNotification('No statement or response main text found to export.', true);
        return;
    }

    const csvText = rows.map(row => row.map(escapeVoiceLineCSVCell).join(',')).join('\r\n');
    downloadCSVFile(csvText, 'DialogueDesigner_MainText');
    safeShowNotification('Main text CSV exported.');
    if (typeof showFastScrollIndicator === 'function') showFastScrollIndicator('Main Text CSV Exported', { timeout: 1200 });
}

function parseDialogueDesignerCSV(text) {
    const rows = [];
    let row = [];
    let cell = '';
    let inQuotes = false;
    const source = String(text || '').replace(/^\uFEFF/, '');

    for (let i = 0; i < source.length; i++) {
        const ch = source[i];
        const next = source[i + 1];

        if (inQuotes) {
            if (ch === '"') {
                if (next === '"') {
                    cell += '"';
                    i++;
                } else {
                    inQuotes = false;
                }
            } else {
                cell += ch;
            }
            continue;
        }

        if (ch === '"') {
            inQuotes = true;
        } else if (ch === ',') {
            row.push(cell);
            cell = '';
        } else if (ch === '\r') {
            if (next === '\n') i++;
            row.push(cell);
            rows.push(row);
            row = [];
            cell = '';
        } else if (ch === '\n') {
            row.push(cell);
            rows.push(row);
            row = [];
            cell = '';
        } else {
            cell += ch;
        }
    }

    row.push(cell);
    rows.push(row);

    return rows.filter(r => r.some(c => String(c || '').trim() !== ''));
}

function normalizeCSVMetadataHeader(value) {
    return String(value || '').trim().toLowerCase().replace(/[\s_\-]+/g, ' ');
}

function getCSVRowValue(rowMap, names) {
    for (const name of names) {
        const normalizedName = normalizeCSVMetadataHeader(name);
        if (Object.prototype.hasOwnProperty.call(rowMap, normalizedName)) return rowMap[normalizedName];
    }
    return '';
}

function parseCSVBooleanValue(value) {
    const text = String(value === null || value === undefined ? '' : value).trim().toLowerCase();
    if (!text) return null;
    if (['true', '1', 'yes', 'y', 'on'].includes(text)) return true;
    if (['false', '0', 'no', 'n', 'off'].includes(text)) return false;
    return null;
}

function isCSVLanguageColumn(header) {
    const normalizedMeta = normalizeCSVMetadataHeader(header);
    const metadataHeaders = new Set([
        'project type',
        'project title',
        'project id',
        'entry type',
        'statement id',
        'response id',
        'voice line'
    ]);
    if (metadataHeaders.has(normalizedMeta)) return false;

    const lang = normalizeCSVLanguageHeader(header);
    return /^[A-Z0-9_-]{2,8}$/.test(lang);
}

function findCSVProject(projectType, projectId, projectTitle) {
    const type = String(projectType || '').trim().toLowerCase();
    const lists = [];
    if (type.startsWith('conv')) lists.push(window.conversations || []);
    else if (type.startsWith('seq')) lists.push(window.sequences || []);
    else lists.push(window.conversations || [], window.sequences || []);

    const wantedId = String(projectId || '').trim();
    const wantedTitle = String(projectTitle || '').trim();

    if (wantedId) {
        for (const list of lists) {
            const found = (list || []).find(project => String((project && (project.projectId || project.id)) || '').trim() === wantedId);
            if (found) return found;
        }
    }

    if (wantedTitle) {
        for (const list of lists) {
            const found = (list || []).find(project => String((project && project.title) || '').trim() === wantedTitle);
            if (found) return found;
        }
    }

    return null;
}

function importVoiceLinesCSV(input) {
    const file = input && input.files && input.files[0] ? input.files[0] : null;
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(event) {
        try {
            const rows = parseDialogueDesignerCSV(event.target.result || '');
            if (rows.length < 2) {
                safeShowNotification('CSV import failed: no data rows found.', true);
                return;
            }

            const headers = rows[0].map(h => String(h || '').trim());
            const headerMetaNames = headers.map(normalizeCSVMetadataHeader);
            const languageColumns = [];

            headers.forEach((header, index) => {
                if (isCSVLanguageColumn(header)) {
                    languageColumns.push({ index, language: normalizeCSVLanguageHeader(header) });
                }
            });

            if (languageColumns.length === 0) {
                safeShowNotification('CSV import failed: no language columns were found.', true);
                return;
            }

            languageColumns.forEach(col => {
                if (!Array.isArray(window.availableLanguages)) window.availableLanguages = ['ENG'];
                if (!window.availableLanguages.includes(col.language)) window.availableLanguages.push(col.language);
            });

            let updatedRows = 0;
            let updatedCells = 0;
            let skippedRows = 0;

            for (let r = 1; r < rows.length; r++) {
                const row = rows[r];
                const rowMap = {};
                headerMetaNames.forEach((name, index) => {
                    rowMap[name] = row[index] ?? '';
                });

                const project = findCSVProject(
                    getCSVRowValue(rowMap, ['Project Type']),
                    getCSVRowValue(rowMap, ['Project ID']),
                    getCSVRowValue(rowMap, ['Project Title'])
                );

                const statementId = String(getCSVRowValue(rowMap, ['Statement ID']) || '').trim();
                const responseId = String(getCSVRowValue(rowMap, ['Response ID']) || '').trim();
                const entryType = String(getCSVRowValue(rowMap, ['Entry Type']) || '').trim().toLowerCase();

                if (!project || !statementId) {
                    skippedRows++;
                    continue;
                }

                const node = (project.nodes || []).find(n => String((n && n.id) || '').trim() === statementId);
                if (!node) {
                    skippedRows++;
                    continue;
                }

                let entry = node;
                if (responseId || entryType.startsWith('resp')) {
                    entry = (node.responses || []).find(response => String((response && response.id) || '').trim() === responseId);
                    if (!entry) {
                        skippedRows++;
                        continue;
                    }
                }

                const importedVoiceLine = parseCSVBooleanValue(getCSVRowValue(rowMap, ['Voice Line', 'VoiceLine', 'Voice Line Bool', 'VoiceLine Bool']));
                if (importedVoiceLine !== null) entry.voiceLine = importedVoiceLine;

                if (typeof ensureTextTranslationsForEntry === 'function') ensureTextTranslationsForEntry(entry);

                languageColumns.forEach(col => {
                    const value = row[col.index] ?? '';
                    if (typeof setLocalizedText === 'function') setLocalizedText(entry, value, col.language);
                    else {
                        if (!entry.translations || typeof entry.translations !== 'object' || Array.isArray(entry.translations)) entry.translations = {};
                        entry.translations[col.language] = value;
                        if (col.language === 'ENG') entry.text = value;
                    }
                    updatedCells++;
                });
                updatedRows++;
            }

            if (typeof collectLanguagesFromProjects === 'function') collectLanguagesFromProjects([...(window.conversations || []), ...(window.sequences || [])]);
            if (typeof ensureAllTranslationContainers === 'function') ensureAllTranslationContainers();
            if (typeof renderNodes === 'function') renderNodes();
            if (typeof renderConversations === 'function') renderConversations();
            if (typeof renderSequences === 'function') renderSequences();
            if (typeof markWorkspaceDirty === 'function') markWorkspaceDirty();
            if (typeof schedulePushStateRefresh === 'function') schedulePushStateRefresh();

            safeShowNotification(`Main text CSV imported: ${updatedRows} rows, ${updatedCells} cells updated${skippedRows ? `, ${skippedRows} rows skipped` : ''}.`, skippedRows > 0 && updatedRows === 0);
            if (typeof showFastScrollIndicator === 'function') showFastScrollIndicator('Main Text CSV Imported', { timeout: 1400 });
        } catch (err) {
            console.error('CSV import failed', err);
            safeShowNotification(`CSV import failed: ${err.message || err}`, true);
        } finally {
            if (input) input.value = '';
        }
    };
    reader.readAsText(file);
}

window.exportVoiceLinesCSV = exportVoiceLinesCSV;
window.importVoiceLinesCSV = importVoiceLinesCSV;

function triggerDownload(data, prefix) {
    const blob = new Blob([JSON.stringify(data, null, 2)], {type: "application/json"});
    const url = URL.createObjectURL(blob);
    const dl = document.createElement('a');
    
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10);
    const timeStr = now.toISOString().slice(11, 19).replace(/:/g, '-');

    dl.href = url;
    dl.download = `${prefix}_${dateStr}_${timeStr}.json`;
    dl.click();
    URL.revokeObjectURL(url);
}

function handleProjectImport(newProject, targetList, typeStr) {
    const existingStarterIdx = targetList.findIndex(p => {
        if (typeof isStarterProject === 'function') return isStarterProject(p);
        return !!p && p.__isStarterProject === true && (p.nodes || []).length === 0 && (p.participants || []).length === 0;
    });

    if (existingStarterIdx !== -1) {
        targetList[existingStarterIdx] = newProject;
        return existingStarterIdx;
    }

    let existingIdx = targetList.findIndex(p => p.title === newProject.title);
    if (existingIdx !== -1) {
        if (confirm(`A ${typeStr} named "${newProject.title}" already exists.\n\nClick OK to OVERWRITE.\nClick Cancel to APPEND as a new project.`)) {
            targetList[existingIdx] = newProject;
            return existingIdx;
        } else {
            let copyNum = 1;
            let baseTitle = newProject.title;
            while(targetList.some(p => p.title === `${baseTitle} (${copyNum})`)) { copyNum++; }
            newProject.title = `${baseTitle} (${copyNum})`;
            targetList.push(newProject);
            return targetList.length - 1;
        }
    } else {
        targetList.push(newProject);
        return targetList.length - 1;
    }
}


function importConversationJSON(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            applyImportedLanguageSettings(data);
            mergeImportedGlobalSidebarData(data);
            let newConv;
            
            // Auto-heal if a Legacy V1 Workspace file was explicitly dropped onto the Single Project import
            if (data.nodes && !data.title) {
                newConv = {
                    id: crypto.randomUUID(),
                    title: "Imported Legacy Data",
                    color: data.color || getSafeRandomColor(),
                    participants: data.participants || (data.cast ? data.cast.map(c => typeof c === 'object' ? c.name : c) : []),
                    nodes: data.nodes,
                    isRepeatable: data.isRepeatable || false,
                    repeatVariable: data.repeatVariable || ''
                };
            } else if (data.title && data.nodes) {
                newConv = data;
            } else {
                safeShowNotification("Invalid Conversation JSON", true); 
                return; 
            }
            
            if (typeof collectLanguagesFromProjects === 'function') collectLanguagesFromProjects([newConv]);
            normalizeProject(newConv);
            const importedIndex = handleProjectImport(newConv, conversations, 'conversation');
            if (typeof renderConversations === 'function') renderConversations();
            if (typeof openEditor === 'function') openEditor(importedIndex, 'conversation');
            safeShowNotification("Conversation Imported Successfully");
        } catch (err) { console.error(err); safeShowNotification("Error parsing Conversation JSON", true); }
    };
    reader.readAsText(file);
    input.value = '';
}

function importSequenceJSON(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            applyImportedLanguageSettings(data);
            mergeImportedGlobalSidebarData(data);
            let newSeq;

            if (data.title && data.nodes) {
                newSeq = data;
                normalizeProject(newSeq);
            } else if (data.sequenceName && data.elements) {
                // Self-Healing Migration from V0 JSON sequence structures
                newSeq = { 
                    id: crypto.randomUUID(), title: data.sequenceName, color: getSafeRandomColor(), participants: [], nodes: [], isRepeatable: false, repeatVariable: ''
                };
                let lastMainNodeId = null, currentBranchKey = null, lastBranchNodeId = null;

                data.elements.forEach((el) => {
                    const nodeId = crypto.randomUUID();
                    const node = {
                        id: nodeId, isCollapsed: false, voiceLine: true, nodeColor: getSafeRandomColor(), conditions: [], speaker: '', text: '',
                        advancedOpen: false, conditionsOpen: true, statesOpen: true, responsesOpen: true, translations: {},
                        resourcePath: 'Assets/Resources/Slides/' + el.imageName,
                        usePath: false, closeMainMenu: false, closeDialogueMenu: false, openPromptPanel: false, closePromptPanel: false,
                        changeTimeOfDay: false, timeOfDayChanges: [{ time: '', value: '' }], changeDayOfWeek: false, dayOfWeekChanges: [{ day: '', value: '' }],
                        changeMenuOption: false, menuOptionChanges: [{ menu: '', value: '' }], gameStateChanges: [], changeSetting: false,
                        settingChanges: [{ setting: '', value: '' }], controlSequence: false, sequenceName: '', sequenceImage: '', controlPuppets: false,         
                        puppetUsePath: false, puppetUseTag: false, changePuppetState: false, changePuppetMood: false, changePuppetInvert: false,
                        puppets: [], canPlayerRespond: false, externalCall: false, makeExternalCall: false, responses: [], parentResponseId: null, parentResponsePreview: null,
                        textFormat: { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' }
                    };

                    if (el.optionalBranch && el.optionKey) {
                        node.conditions.push({ variable: el.optionKey, operator: '==', value: el.optionValue.toString() });
                        if (el.optionValue == 1 || currentBranchKey !== el.optionKey) {
                            currentBranchKey = el.optionKey; lastBranchNodeId = nodeId;
                        } else {
                            if (lastBranchNodeId) {
                                const lastNode = newSeq.nodes.find(n => n.id === lastBranchNodeId);
                                if (lastNode) {
                                    lastNode.responses.push({ id: crypto.randomUUID(), speaker: '', text: 'Continue...', translations: {}, nextStatementId: nodeId, voiceLine: false, conditions: [], gameStateChanges: [], conditionsOpen: true, statesOpen: true, autoIncrement: false });
                                    lastNode.canPlayerRespond = true;
                                }
                            }
                            lastBranchNodeId = nodeId;
                        }
                    } else {
                        currentBranchKey = null; 
                        if (lastMainNodeId) {
                            const lastNode = newSeq.nodes.find(n => n.id === lastMainNodeId);
                            if (lastNode) {
                                lastNode.responses.push({ id: crypto.randomUUID(), speaker: '', text: 'Continue...', translations: {}, nextStatementId: nodeId, voiceLine: false, conditions: [], gameStateChanges: [], conditionsOpen: true, statesOpen: true, autoIncrement: false });
                                lastNode.canPlayerRespond = true;
                            }
                        }
                        lastMainNodeId = nodeId;
                    }
                    newSeq.nodes.push(node);
                });
            } else { safeShowNotification("Invalid Sequence JSON Format", true); return; }

            if (typeof collectLanguagesFromProjects === 'function') collectLanguagesFromProjects([newSeq]);
            normalizeProject(newSeq);
            const importedIndex = handleProjectImport(newSeq, sequences, 'sequence');
            if (!globalImageSequences.some(s => s.name === newSeq.title)) {
                globalImageSequences.push({ name: newSeq.title, color: newSeq.color || getSafeRandomColor(), path: 'Assets/2D/Sequences/', images: [] });
                if (typeof renderImageSequences === 'function') renderImageSequences();
            }
            if (typeof renderSequences === 'function') renderSequences();
            if (typeof openEditor === 'function') openEditor(importedIndex, 'sequence');
            safeShowNotification("Sequence Imported Successfully");
        } catch (err) { console.error(err); safeShowNotification("Error parsing Sequence JSON", true); }
    };
    reader.readAsText(file);
    input.value = '';
}

function importProjectJSON(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            applyWorkspaceData(data, { source: 'import' });
            window.lastServerWorkspaceHash = localStorage.getItem('DD_lastServerWorkspaceHash') || window.lastServerWorkspaceHash || '';
            schedulePushStateRefresh();
            safeShowNotification('Project Imported Successfully');
        } catch (err) {
            console.error('Import failed', err);
            safeShowNotification('Failed to import JSON', true);
        }
    };
    reader.readAsText(file);
    input.value = '';
}

// Deep heals arrays and structures on load. Injects new fields missing from old exports.
function normalizeProject(c) {
    if (!c.id) c.id = crypto.randomUUID();
    delete c.__isStarterProject;
    if (!c.title) c.title = "Imported Project";
    if (!c.participants) c.participants = [];
    if (!c.nodes) c.nodes = [];
    if (c.isRepeatable === undefined || c.isRepeatable === null) c.isRepeatable = false;
    if (c.repeatVariable === undefined || c.repeatVariable === null) c.repeatVariable = '';
    if (!c.color) c.color = getSafeRandomColor();

    c.nodes.forEach(n => {
        // Deep Property Auto-Heal for V2.18
        if (!n.id) n.id = crypto.randomUUID();
        if (n.text === undefined || n.text === null) n.text = ''; 
        if (n.isCollapsed === undefined || n.isCollapsed === null) n.isCollapsed = false; 
        if (n.voiceLine === undefined || n.voiceLine === null) n.voiceLine = true;
        if (!n.nodeColor) n.nodeColor = getSafeRandomColor();
        if (!n.translations || typeof n.translations !== 'object' || Array.isArray(n.translations)) n.translations = {};
        
        if (n.advancedOpen === undefined || n.advancedOpen === null) n.advancedOpen = false;
        if (n.conditionsOpen === undefined || n.conditionsOpen === null) n.conditionsOpen = true;
        if (n.statesOpen === undefined || n.statesOpen === null) n.statesOpen = true;
        if (n.responsesOpen === undefined || n.responsesOpen === null) n.responsesOpen = true;

        // Healing null arrays that C# serializers naturally produce
        if (!n.conditions) n.conditions = [];
        if (!n.gameStateChanges) n.gameStateChanges = [];
        
        // Deep self-healing / array migrations for logic mappings
        if (n.changeGameState !== undefined && n.changeGameState !== null || n.gameStateVar) {
             const v = n.gameStateVar;
             if (v && v.trim() !== '' && !n.gameStateChanges.some(gsc => gsc.variable === v)) {
                 n.gameStateChanges.push({ variable: v, operator: '==', value: n.gameStateVal || '' });
             }
        }
        
        if (n.speaker === undefined || n.speaker === null) n.speaker = '';
        if (n.externalCall === undefined || n.externalCall === null) n.externalCall = false;
        if (n.makeExternalCall === undefined || n.makeExternalCall === null) n.makeExternalCall = false;
        if (!n.resourcePath) n.resourcePath = 'Assets/Resources/Slides/';
        if (n.usePath === undefined || n.usePath === null) n.usePath = false;
        if (n.closeMainMenu === undefined || n.closeMainMenu === null) n.closeMainMenu = false;
        if (n.closePromptPanel === undefined || n.closePromptPanel === null) n.closePromptPanel = false;
        if (n.openPromptPanel === undefined || n.openPromptPanel === null) n.openPromptPanel = false;
        if (n.closeDialogueMenu === undefined || n.closeDialogueMenu === null) n.closeDialogueMenu = false;
        if (n.changeTimeOfDay === undefined || n.changeTimeOfDay === null) n.changeTimeOfDay = false;
        if (!n.timeOfDayChanges || n.timeOfDayChanges.length === 0) n.timeOfDayChanges = [{ time: '', value: '' }];
        if (n.changeDayOfWeek === undefined || n.changeDayOfWeek === null) n.changeDayOfWeek = false;
        if (!n.dayOfWeekChanges || n.dayOfWeekChanges.length === 0) n.dayOfWeekChanges = [{ day: '', value: '' }];
        if (n.changeMenuOption === undefined || n.changeMenuOption === null) n.changeMenuOption = false;
        if (!n.menuOptionChanges || n.menuOptionChanges.length === 0) n.menuOptionChanges = [{ menu: '', value: '' }];
        
        n.gameStateChanges.forEach(gsc => { if(!gsc.operator) gsc.operator = '=='; });
        delete n.changeGameState; delete n.gameStateVar; delete n.gameStateVal;

        if (n.changeSetting === undefined || n.changeSetting === null) n.changeSetting = false;
        if (!n.settingChanges || n.settingChanges.length === 0) n.settingChanges = [{ setting: '', value: '' }];
        if (n.controlSequence === undefined || n.controlSequence === null) n.controlSequence = false;
        if (n.sequenceName === undefined || n.sequenceName === null) n.sequenceName = '';
        if (n.sequenceImage === undefined || n.sequenceImage === null) n.sequenceImage = '';
        if (n.controlPuppets === undefined || n.controlPuppets === null) n.controlPuppets = false;
        
        if (n.changePuppets !== undefined && n.changePuppets !== null) { n.puppetUsePath = n.changePuppets; delete n.changePuppets; } 
        else if (n.puppetUsePath === undefined || n.puppetUsePath === null) { n.puppetUsePath = false; }
        
        if (n.puppetUseTag === undefined || n.puppetUseTag === null) n.puppetUseTag = false;
        if (n.changePuppetState === undefined || n.changePuppetState === null) n.changePuppetState = false;
        if (n.changePuppetMood === undefined || n.changePuppetMood === null) n.changePuppetMood = false;
        if (n.changePuppetInvert === undefined || n.changePuppetInvert === null) n.changePuppetInvert = false;
        if (!n.puppets) n.puppets = [];

        n.puppets.forEach(p => {
            if (p.name === undefined || p.name === null) p.name = '';
            if (p.enabled === undefined || p.enabled === null) p.enabled = true;
            if (p.position === undefined || p.position === null) p.position = '';
            if (!p.path) p.path = 'Assets/Resources/Puppets/';
            if (p.state === undefined || p.state === null) p.state = '';
            if (p.mood === undefined || p.mood === null) p.mood = '';
            if (p.invert === undefined || p.invert === null) p.invert = false;
        });
        
        if (!n.textFormat) n.textFormat = { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
        if (!n.responseDraftFormat) n.responseDraftFormat = { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
        if (n.canPlayerRespond === undefined || n.canPlayerRespond === null) n.canPlayerRespond = false;
        if (!n.responses) n.responses = [];
        if (n.parentResponseId === undefined) n.parentResponseId = null;
        if (n.parentResponsePreview === undefined) n.parentResponsePreview = null;
        
        n.responses.forEach(r => {
            if (!r.id) r.id = crypto.randomUUID();
            if (r.voiceLine === undefined || r.voiceLine === null) r.voiceLine = false;
            if (!r.translations || typeof r.translations !== 'object' || Array.isArray(r.translations)) r.translations = {};
            if (r.speaker === undefined || r.speaker === null) r.speaker = '';
            if (r.text === undefined || r.text === null) r.text = '';
            if (r.nextStatementId === undefined) r.nextStatementId = null;
            if (r.autoIncrement === undefined || r.autoIncrement === null) r.autoIncrement = false;
            if (r.conditionsOpen === undefined || r.conditionsOpen === null) r.conditionsOpen = true;
            if (r.statesOpen === undefined || r.statesOpen === null) r.statesOpen = true;
            if (typeof ensureResponseAdvancedDefaults === 'function') ensureResponseAdvancedDefaults(r);
            if (!r.textFormat) r.textFormat = { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
            
            // Legacy Logic Multi-Array Translations
            if (!r.conditions) r.conditions = [];
            if (r.requiresCondition && r.conditionKey) {
                if (!r.conditions.some(cond => cond.variable === r.conditionKey)) r.conditions.push({ variable: r.conditionKey, operator: r.conditionOp || '==', value: r.conditionVal || '' });
            }
            if (!r.gameStateChanges) r.gameStateChanges = [];
            if (r.changesGameState && r.gameStateKey) {
                if (!r.gameStateChanges.some(gsc => gsc.variable === r.gameStateKey)) r.gameStateChanges.push({ variable: r.gameStateKey, operator: r.gameStateOp || '=', value: r.gameStateVal || '' });
            }

            delete r.requiresCondition; delete r.conditionKey; delete r.conditionOp; delete r.conditionVal;
            delete r.changesGameState; delete r.gameStateKey; delete r.gameStateOp; delete r.gameStateVal;
        });
    });
    if (typeof ensureProjectTranslationContainers === 'function') ensureProjectTranslationContainers(c);
}

function triggerSequenceImageImport(seqIndex) {
    targetImportSeqIndex = seqIndex;
    document.getElementById('direct-image-import-trigger').click();
}

function handleDirectImageImport(input) {
    const files = input.files;
    if (!files || files.length === 0 || targetImportSeqIndex === null) return;
    
    let seq = globalImageSequences[targetImportSeqIndex];
    
    Array.from(files).forEach(file => {
        const nameWithoutExt = file.name.replace(/\.[^/.]+$/, "");
        if (!seq.images.includes(nameWithoutExt)) seq.images.push(nameWithoutExt);
    });
    
    if (typeof renderImageSequences === 'function') renderImageSequences(); 
    if (typeof renderNodes === 'function') renderNodes(); 
    input.value = '';
    safeShowNotification(`Imported ${files.length} images to ${seq.name}`);
    targetImportSeqIndex = null;
}

// Ensure globally mapped HTML bindings are accessible
window.exportJSON = exportProjectJSON;
window.importJSON = importProjectJSON;

(function installProjectContextClearWrappers() {
    if (window.__DD_PROJECT_CONTEXT_CLEAR_WRAPPED) return;
    window.__DD_PROJECT_CONTEXT_CLEAR_WRAPPED = true;

    const originalDeleteProject = window.deleteProject;
    if (typeof originalDeleteProject === 'function') {
        window.deleteProject = function(type, idx) {
            const result = originalDeleteProject.apply(this, arguments);
            const activeProject = (typeof window.getActiveProject === 'function') ? window.getActiveProject() : null;
            if (!activeProject && typeof window.resetProjectContextUI === 'function') {
                window.resetProjectContextUI({ clearDraftInputs: false });
            }
            if (typeof renderProjectTags === 'function') renderProjectTags();
            return result;
        };
    }
})();
