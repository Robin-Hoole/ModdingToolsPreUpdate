// ============================================================================
// DD_ENGINE.JS - Tag Logic, Event Navigation, and Minimap Handling
// ============================================================================

// --- KEYBOARD & SCROLL NAVIGATION ---
window.scrollIndicatorTimeout = window.scrollIndicatorTimeout || null;
function setupKeyboardNavigation() {
    const middlePanel = document.querySelector('.middle-panel') || window;
    middlePanel.addEventListener('wheel', () => { activeNavIndex = -1; }, { passive: true });
    middlePanel.addEventListener('touchmove', () => { activeNavIndex = -1; }, { passive: true });

    document.addEventListener('keydown', (e) => {
        if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName) || e.target.isContentEditable) return;

        if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
            e.preventDefault();
            moveActiveProjectSelection(e.key === 'ArrowRight' ? 1 : -1);
            return;
        }

        const project = getActiveProject();
        if (!project || !project.nodes || project.nodes.length === 0) return;

        const acts = { 'ArrowUp': -1, 'ArrowDown': 1, 'PageUp': -10, 'PageDown': 10, 'Home': 'start', 'End': 'end' };
        if (acts[e.key] !== undefined) {
            e.preventDefault(); 
            if (activeNavIndex === -1) activeNavIndex = getCurrentlyVisibleNodeIndex();

            if (acts[e.key] === 'start') activeNavIndex = 0;
            else if (acts[e.key] === 'end') activeNavIndex = project.nodes.length - 1;
            else activeNavIndex = Math.max(0, Math.min(project.nodes.length - 1, activeNavIndex + acts[e.key]));

            const el = document.getElementById(`node-${project.nodes[activeNavIndex].id}`);
            if (el) {
                const behavior = (e.repeat || Math.abs(acts[e.key]) > 1) ? 'auto' : 'smooth';
                el.scrollIntoView({ behavior: behavior, block: 'center' });
                // We purposefully do NOT set lastTraversedIndex here, so arrow keys don't trigger the Teal tag.
                showFastScrollIndicator(activeNavIndex + 1);
            }
        }
    });
}

function getCurrentlyVisibleNodeIndex() {
    const project = getActiveProject();
    if (!project || !project.nodes || project.nodes.length === 0) return -1;
    
    let closestIdx = 0, minDiff = Infinity;
    const scrollable = document.querySelector('.middle-panel');
    if (!scrollable) return 0;
    const centerY = scrollable.getBoundingClientRect().top + (scrollable.getBoundingClientRect().height / 2);

    project.nodes.forEach((node, idx) => {
        const el = document.getElementById(`node-${node.id}`);
        // Ensure collapsed nodes are also tracked flawlessly by the white indicator
        if (el && el.style.display !== 'none') {
            const rect = el.getBoundingClientRect();
            const diff = Math.abs((rect.top + rect.height / 2) - centerY);
            if (diff < minDiff) { minDiff = diff; closestIdx = idx; }
        }
    });
    return closestIdx;
}

function moveActiveProjectSelection(delta) {
    const type = window.activeType === 'sequence' ? 'sequence' : 'conversation';
    const list = type === 'sequence' ? (window.sequences || []) : (window.conversations || []);
    if (!list.length) return;

    let currentIndex = Number.isInteger(window.activeIndex) ? window.activeIndex : 0;
    currentIndex = Math.max(0, Math.min(list.length - 1, currentIndex));
    const nextIndex = Math.max(0, Math.min(list.length - 1, currentIndex + delta));
    if (nextIndex === currentIndex && window.activeIndex !== null) return;

    if (typeof openEditor === 'function') {
        openEditor(nextIndex, type);
        const selectedProject = list[nextIndex];
        if (selectedProject && typeof showFastScrollIndicator === 'function') {
            showFastScrollIndicator(selectedProject.title || `${type} ${nextIndex + 1}`, { timeout: 1200 });
        }
        const listId = type === 'sequence' ? 'sequence-master-list' : 'conversation-master-list';
        const activeItem = document.querySelector(`#${listId} .project-item.active`);
        if (activeItem) activeItem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
}

function showFastScrollIndicator(value, options = {}) {
    const indicator = document.getElementById('fast-scroll-indicator');
    if (!indicator) return;
    const text = (typeof value === 'number' || /^\d+$/.test(String(value))) ? `#${value}` : String(value || '');
    indicator.textContent = text;
    indicator.classList.toggle('text-mode', !text.startsWith('#'));
    indicator.style.display = 'block';
    window.clearTimeout(window.scrollIndicatorTimeout);
    const timeout = Number(options.timeout || (text.startsWith('#') ? 300 : 1150));
    window.scrollIndicatorTimeout = window.setTimeout(() => { indicator.style.display = 'none'; indicator.classList.remove('text-mode'); }, timeout); 
}

function filterStatements() {
    const input = document.getElementById('search-statements');
    if (!input) return;
    const term = input.value.toLowerCase().trim();
    const project = getActiveProject();
    if (!project) return;
    
    project.nodes.forEach((node, nIdx) => {
        const el = document.getElementById(`node-${node.id}`);
        if (!el) return;
        if (!term) { el.style.display = ''; return; }
        
        let isMatch = `${node.speaker || ''} ${node.text || ''} ${node.id}`.toLowerCase().includes(term);
        if (!isMatch && node.responses) {
            isMatch = node.responses.some(r => `${r.speaker || ''} ${r.text || ''}`.toLowerCase().includes(term));
        }
        el.style.display = isMatch ? '' : 'none';
    });
    updateMinimap();
}

function scrollToNode(nodeId) {
    if (!nodeId) return;
    const el = document.getElementById(`node-${nodeId}`);
    if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        const oldBorder = el.style.borderColor;
        const oldBoxShadow = el.style.boxShadow;
        el.style.borderColor = 'var(--accent-orange)';
        el.style.boxShadow = '0 0 20px var(--accent-orange)';
        setTimeout(() => { el.style.borderColor = oldBorder; el.style.boxShadow = oldBoxShadow; }, 1000);
    }
}


function jumpToResponseFromIncoming(nIdx, rIdx) {
    const project = getActiveProject();
    if (!project || !project.nodes || !project.nodes[nIdx]) return;
    const node = project.nodes[nIdx];
    node.isCollapsed = false;
    node.responsesOpen = true;
    if (node.responses && node.responses[rIdx]) {
        node.responses[rIdx].isCollapsed = false;
    }
    renderNodes();
    setTimeout(() => {
        const el = document.getElementById(`response-item-${nIdx}-${rIdx}`) || document.getElementById(`node-${node.id}`);
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            const oldOutline = el.style.outline;
            const oldBoxShadow = el.style.boxShadow;
            el.style.outline = '2px solid var(--accent-orange)';
            el.style.boxShadow = '0 0 22px var(--accent-orange)';
            setTimeout(() => {
                el.style.outline = oldOutline;
                el.style.boxShadow = oldBoxShadow;
            }, 1600);
        }
    }, 60);
}

function scrollToElement(elId) {
    const el = document.getElementById(elId);
    if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        const oldOutline = el.style.outline;
        const oldBoxShadow = el.style.boxShadow;
        el.style.outline = '2px solid var(--accent-orange)';
        el.style.boxShadow = '0 0 20px var(--accent-orange)';
        setTimeout(() => { el.style.outline = oldOutline; el.style.boxShadow = oldBoxShadow; }, 1500);
    }
}

function findNodeIdByResponseId(respId) {
    const project = getActiveProject();
    if (!project) return null;
    for (let n of project.nodes) {
        if (n.responses.some(r => r.id === respId)) return n.id;
    }
    return null;
}

// --- MINIMAP LOGIC ---
function setupMinimap() {
    // Target .middle-panel if available; fallback to .canvas-area to ensure scroll attaches
    const middlePanel = document.querySelector('.middle-panel') || document.querySelector('.canvas-area');
    if (middlePanel) {
        let scrollTimeout;
        middlePanel.addEventListener('scroll', () => {
            if (scrollTimeout) clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(() => {
                currentlyVisibleIndex = getCurrentlyVisibleNodeIndex();
                updateMinimap();
            }, 50);
        }, { passive: true }); // Ensure passive rendering
    }
}

function markNodeEdited(nIdx) {
    const proj = getActiveProject();
    if (proj && proj.nodes[nIdx]) {
        editedNodes.add(proj.nodes[nIdx].id);
        updateMinimap();
    }
}

// Ensures Teal tag updates when user interacts within a panel field
function setTraversedNode(nIdx) {
    if (lastTraversedIndex !== nIdx) {
        lastTraversedIndex = nIdx;
        updateMinimap();
    }
}

function updateMinimap() {
    let track = document.getElementById('minimap-track');
    
    // Auto-inject missing minimap track HTML if it does not exist
    if (!track) {
        track = document.createElement('div');
        track.id = 'minimap-track';
        track.style.position = 'fixed';
        track.style.right = '330px'; 
        track.style.top = '90px';
        track.style.bottom = '30px';
        track.style.width = '45px';
        track.style.pointerEvents = 'none';
        track.style.zIndex = '150';
        document.body.appendChild(track);
    }

    const scrollable = document.querySelector('.middle-panel') || document.querySelector('.canvas-area');
    if (!scrollable) return;
    
    track.innerHTML = '';
    const proj = getActiveProject();
    if (!proj) return;
    
    const scrollHeight = scrollable.scrollHeight;
    if (scrollHeight === 0) return;
    
    let html = '';
    const scrollableRect = scrollable.getBoundingClientRect();
    
    proj.nodes.forEach((node, nIdx) => {
        const el = document.getElementById(`node-${node.id}`);
        if (!el || el.style.display === 'none') return;
        
        const topPercent = (((el.getBoundingClientRect().top - scrollableRect.top) + scrollable.scrollTop) / scrollHeight) * 100;
        const isVisible = (nIdx === currentlyVisibleIndex);
        const isTraversed = (nIdx === lastTraversedIndex);
        const isEdited = typeof editedNodes !== 'undefined' && editedNodes.has(node.id);
        
        if (!isVisible && !isTraversed && !isEdited) return;
        
        let marker = '';
        const baseStyle = "pointer-events: auto; cursor: pointer; font-size:0.55rem; font-weight:900; padding:2px 4px; border-radius:2px; text-align:center; width: 100%; transition: 0.1s;";
        
        if (isVisible) marker = `<div onclick="scrollToNode('${node.id}'); event.stopPropagation();" style="${baseStyle} background:#fff; color:#000; box-shadow: 0 0 5px rgba(255,255,255,0.8);" title="Currently Viewing">#${nIdx+1}</div>`;
        else if (isTraversed) marker = `<div onclick="scrollToNode('${node.id}'); event.stopPropagation();" style="${baseStyle} background:var(--accent-teal); color:#000; box-shadow: 0 0 5px var(--accent-teal);" title="Last Traversed">#${nIdx+1}</div>`;
        else if (isEdited) marker = `<div onclick="scrollToNode('${node.id}'); event.stopPropagation();" style="${baseStyle} background:var(--accent-orange); color:#000; box-shadow: 0 0 5px var(--accent-orange);" title="Edited">#${nIdx+1}</div>`;
        
        if (marker !== '') html += `<div style="position:absolute; top:${topPercent}%; right:0; transform:translateY(-50%); display:flex; flex-direction:column; gap:2px; align-items:flex-end; width: 35px;">${marker}</div>`;
    });
    track.innerHTML = html;
}

// --- PROJECT TAG LOGIC ENGINE ---
function getLogicTagCollection(project) {
    const tags = {};
    if (!project || !Array.isArray(project.nodes)) return [];

    const addTag = (variableRaw, valueRaw, isCond, sourceInfo) => {
        const variable = (variableRaw === undefined || variableRaw === null) ? '' : String(variableRaw).trim();
        const value = (valueRaw === undefined || valueRaw === null) ? '' : String(valueRaw);
        if (variable === '' && value.trim() === '') return;
        const key = `${variable}|||${value}`;
        if (!tags[key]) {
            tags[key] = {
                key,
                variable,
                value,
                condCount: 0,
                stateCount: 0,
                references: []
            };
        }
        if (isCond) tags[key].condCount++;
        else tags[key].stateCount++;
        tags[key].references.push(sourceInfo);
    };

    const previewText = (entry) => {
        const raw = typeof getLocalizedText === 'function' ? getLocalizedText(entry, window.currentLanguage) : (entry.text || '');
        const clean = String(raw || '').replace(/<[^>]*>?/gm, '').replace(/\s+/g, ' ').trim();
        return clean.length > 48 ? `${clean.substring(0, 48)}...` : (clean || 'Empty Text');
    };

    project.nodes.forEach((node, nIdx) => {
        const statementLabel = `Statement #${nIdx + 1} (${node.speaker || '?'})`;
        (node.conditions || []).forEach((c, cIdx) => addTag(c.variable, c.value, true, {
            nodeId: node.id,
            nIdx,
            rIdx: null,
            cIdx,
            rowId: `node-condition-row-${nIdx}-${cIdx}`,
            displayType: 'STATEMENT CONDITION',
            type: 'node_condition',
            text: `${statementLabel}: ${previewText(node)}`
        }));
        (node.gameStateChanges || []).forEach((c, cIdx) => addTag(c.variable, c.value, false, {
            nodeId: node.id,
            nIdx,
            rIdx: null,
            cIdx,
            rowId: `node-state-row-${nIdx}-${cIdx}`,
            displayType: 'STATEMENT CHANGE GAME STATE',
            type: 'node_state',
            text: `${statementLabel}: ${previewText(node)}`
        }));

        (node.responses || []).forEach((r, rIdx) => {
            const responseLabel = `Response #${rIdx + 1} on Statement #${nIdx + 1} (${r.speaker || '?'})`;
            (r.conditions || []).forEach((c, cIdx) => addTag(c.variable, c.value, true, {
                nodeId: node.id,
                responseId: r.id,
                nIdx,
                rIdx,
                cIdx,
                rowId: `response-condition-row-${nIdx}-${rIdx}-${cIdx}`,
                displayType: 'RESPONSE CONDITION',
                type: 'response_condition',
                text: `${responseLabel}: ${previewText(r)}`
            }));
            (r.gameStateChanges || []).forEach((c, cIdx) => addTag(c.variable, c.value, false, {
                nodeId: node.id,
                responseId: r.id,
                nIdx,
                rIdx,
                cIdx,
                rowId: `response-state-row-${nIdx}-${rIdx}-${cIdx}`,
                displayType: 'RESPONSE CHANGE GAME STATE',
                type: 'response_state',
                text: `${responseLabel}: ${previewText(r)}`
            }));
        });
    });

    return Object.values(tags).sort((a, b) => a.variable.localeCompare(b.variable) || a.value.localeCompare(b.value));
}

function renderProjectTags() {
    const section = document.getElementById('active-project-tags-section');
    const list = document.getElementById('project-tags-list');
    const searchInput = document.getElementById('search-tags');
    const project = getActiveProject();

    if (!section || !list || !project) {
        if (section) section.style.display = 'none';
        if (list) list.innerHTML = '';
        if (searchInput) searchInput.value = '';
        window.activeProjectTagCache = [];
        return;
    }

    section.style.display = 'block';
    const filterTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';
    window.activeProjectTagCache = getLogicTagCollection(project);

    list.innerHTML = window.activeProjectTagCache.map((tag, tagIdx) => {
        const tagTextMatch = `${tag.variable} ${tag.value}`.toLowerCase();
        if (filterTerm && !tagTextMatch.includes(filterTerm)) return '';

        const hasConditions = tag.condCount > 0;
        const hasStates = tag.stateCount > 0;
        let tagClass = 'logic-tag-condition-only';
        let colorHex = '#00ff88';
        if (!hasConditions && hasStates) { tagClass = 'logic-tag-state-only'; colorHex = '#00f2ff'; }
        if (hasConditions && hasStates) { tagClass = 'logic-tag-matched'; colorHex = '#b026ff'; }

        return `
            <div class="logic-tag-item ${tagClass}" onclick="openTagModalByKey(${tagIdx})">
                <span class="logic-tag-main"><strong>${escapeHtml(tag.variable || '[empty key]')}</strong><span>==</span>${escapeHtml(tag.value)}</span>
                <span class="logic-tag-count" style="color:${colorHex};">[${tag.references.length}]</span>
            </div>
        `;
    }).join('');
}

function openTagModalByKey(tagIdx) {
    const tag = (window.activeProjectTagCache || [])[tagIdx];
    if (!tag) return;
    openTagModal(tag.variable, tag.value);
}

function openTagModal(variable, value) {
    currentEditingTag = { variable, value };
    const modal = document.getElementById('tag-editor-modal');
    const variableInput = document.getElementById('tag-edit-var');
    const valueInput = document.getElementById('tag-edit-val');
    const referenceList = document.getElementById('tag-references-list');
    if (!modal || !variableInput || !valueInput || !referenceList) return;

    variableInput.value = variable;
    valueInput.value = value;

    const tag = getLogicTagCollection(getActiveProject()).find(t => t.variable === variable && t.value === value);
    const refs = tag ? tag.references : [];

    referenceList.innerHTML = refs.map((ref, refIdx) => `
        <div class="tag-reference-card">
            <div>
                <div class="tag-reference-type">${ref.displayType}</div>
                <div class="tag-reference-text">${escapeHtml(ref.text)}</div>
            </div>
            <div class="tag-reference-actions">
                <button class="btn btn-outline" onclick="jumpFromTagModal(${ref.nIdx}, ${ref.rIdx === null ? 'null' : ref.rIdx}, '${ref.rowId}', '${ref.type}')">Jump</button>
                <button class="btn btn-outline tag-reference-delete" onclick="deleteTagReferenceByIndex(${refIdx})">Delete</button>
            </div>
        </div>
    `).join('');

    modal.style.display = 'flex';
}

function closeTagModal() {
    const modal = document.getElementById('tag-editor-modal');
    if (modal) modal.style.display = 'none';
    currentEditingTag = null;
}

function jumpFromTagModal(nIdx, rIdx, rowId, refType) {
    closeTagModal();
    const project = getActiveProject();
    if (!project || !project.nodes[nIdx]) return;

    const node = project.nodes[nIdx];
    node.isCollapsed = false;
    node.responsesOpen = true;

    if (refType === 'node_condition') node.conditionsOpen = true;
    if (refType === 'node_state') node.statesOpen = true;

    if (rIdx !== null && node.responses && node.responses[rIdx]) {
        const response = node.responses[rIdx];
        response.isCollapsed = false;
        if (refType === 'response_condition') response.conditionsOpen = true;
        if (refType === 'response_state') response.statesOpen = true;
    }

    renderNodes();
    setTimeout(() => {
        const target = document.getElementById(rowId) || (rIdx !== null ? document.getElementById(`response-item-${nIdx}-${rIdx}`) : document.getElementById(`node-${node.id}`));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth', block: 'center' });
            const oldOutline = target.style.outline;
            const oldBoxShadow = target.style.boxShadow;
            target.style.outline = '2px solid var(--accent-orange)';
            target.style.boxShadow = '0 0 22px var(--accent-orange)';
            setTimeout(() => {
                target.style.outline = oldOutline;
                target.style.boxShadow = oldBoxShadow;
            }, 1600);
        }
    }, 60);
}

function deleteTagReferenceByIndex(refIdx) {
    if (!currentEditingTag || !confirm('Remove this logic tag from this specific location?')) return;
    const tag = getLogicTagCollection(getActiveProject()).find(t => t.variable === currentEditingTag.variable && t.value === currentEditingTag.value);
    const ref = tag && tag.references ? tag.references[refIdx] : null;
    if (!ref) return;
    deleteTagReference(ref.nodeId, ref.responseId || null, ref.type);
}

function deleteTagReference(nodeId, responseId, type) {
    if (!currentEditingTag) return;
    const project = getActiveProject();
    if (!project) return;

    const node = project.nodes.find(n => n.id === nodeId);
    if (!node) return;

    const { variable, value } = currentEditingTag;
    let targetArray = null;

    if (type === 'node_condition') targetArray = node.conditions;
    if (type === 'node_state') targetArray = node.gameStateChanges;

    if (responseId && responseId !== 'null') {
        const response = node.responses.find(r => r.id === responseId);
        if (response) {
            if (type === 'response_condition') targetArray = response.conditions;
            if (type === 'response_state') targetArray = response.gameStateChanges;
        }
    }

    if (targetArray) {
        const idx = targetArray.findIndex(c => String(c.variable || '').trim() === variable && String(c.value || '') === value);
        if (idx !== -1) {
            targetArray.splice(idx, 1);
            markNodeEdited(project.nodes.indexOf(node));
            renderNodes();
            renderProjectTags();
            const stillExists = getLogicTagCollection(project).some(t => t.variable === variable && t.value === value);
            if (stillExists) openTagModal(variable, value);
            else closeTagModal();
        }
    }
}

function applyTagChange() {
    if (!currentEditingTag) return;
    const newVar = document.getElementById('tag-edit-var').value.trim();
    const newVal = document.getElementById('tag-edit-val').value;
    if (!newVar) { showNotification('Variable Key cannot be empty.', true); return; }

    const project = getActiveProject();
    const match = (c) => String(c.variable || '').trim() === currentEditingTag.variable && String(c.value || '') === currentEditingTag.value;
    const update = (c, nIdx) => {
        if (match(c)) {
            c.variable = newVar;
            c.value = newVal;
            markNodeEdited(nIdx);
        }
    };

    project.nodes.forEach((node, nIdx) => {
        (node.conditions || []).forEach(c => update(c, nIdx));
        (node.gameStateChanges || []).forEach(c => update(c, nIdx));
        (node.responses || []).forEach(r => {
            (r.conditions || []).forEach(c => update(c, nIdx));
            (r.gameStateChanges || []).forEach(c => update(c, nIdx));
        });
    });

    renderNodes();
    renderProjectTags();
    closeTagModal();
    showNotification('Logic tag updated throughout active project.');
}

// --- TEXT FORMATTING ---
function applyTextFormat(nIdx, tagType, tagParam = '') {
    const project = getActiveProject();
    if (!project || !project.nodes[nIdx]) return;
    const node = project.nodes[nIdx];
    
    if (!node.textFormat) {
        node.textFormat = { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
    }

    const textarea = document.getElementById(`node-text-${nIdx}`);
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = textarea.value.substring(start, end);

    if (selectedText.length > 0) {
        if (['top', 'middle', 'bottom'].includes(tagType)) {
            showNotification("Vertical alignment must be applied globally (select no text).", true);
            return;
        }

        let newText = '';
        let offsetCursor = 0;

        if (tagType === 'align') {
            newText = textarea.value.substring(0, start) + `<align="${tagParam}">` + selectedText + `</align>` + textarea.value.substring(end);
            offsetCursor = 17 + tagParam.length; 
        } else if (tagType === 'bullet') {
            const lines = selectedText.split('\n').map(l => `• ${l}`).join('\n');
            newText = textarea.value.substring(0, start) + lines + textarea.value.substring(end);
            offsetCursor = newText.length - selectedText.length;
        } else if (tagType === 'number') {
            const lines = selectedText.split('\n').map((l, i) => `${i+1}. ${l}`).join('\n');
            newText = textarea.value.substring(0, start) + lines + textarea.value.substring(end);
            offsetCursor = newText.length - selectedText.length;
        } else {
            const tagMap = { 'b': 'b', 'i': 'i', 'u': 'u', 's': 's' };
            const tag = tagMap[tagType] || tagType;
            newText = textarea.value.substring(0, start) + `<${tag}>` + selectedText + `</${tag}>` + textarea.value.substring(end);
            offsetCursor = 5 + (tag.length * 2); 
        }

        textarea.value = newText;
        node.text = newText;
        markNodeEdited(nIdx);

        textarea.focus();
        textarea.setSelectionRange(start, end + offsetCursor);
    } else {
        if (tagType === 'align') node.textFormat.alignH = tagParam;
        else if (['top', 'middle', 'bottom'].includes(tagType)) node.textFormat.alignV = tagType;
        else if (tagType === 'bullet') node.textFormat.listStyle = node.textFormat.listStyle === 'bullet' ? 'none' : 'bullet';
        else if (tagType === 'number') node.textFormat.listStyle = node.textFormat.listStyle === 'number' ? 'none' : 'number';
        else {
            const keyMap = { 'b': 'bold', 'i': 'italic', 'u': 'underline', 's': 'strikethrough' };
            const key = keyMap[tagType];
            if (key) node.textFormat[key] = !node.textFormat[key];
        }
        markNodeEdited(nIdx);
        renderNodes();
    }
}


function applyResponseTextFormat(nIdx, rIdx, tagType, tagParam = '') {
    const project = getActiveProject();
    if (!project || !project.nodes[nIdx] || !project.nodes[nIdx].responses || !project.nodes[nIdx].responses[rIdx]) return;
    const response = project.nodes[nIdx].responses[rIdx];
    if (!response.textFormat) {
        response.textFormat = { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
    }
    const textarea = document.getElementById(`edit-input-${nIdx}-${rIdx}`);
    applyTextFormatToTarget(response, textarea, tagType, tagParam, () => markNodeEdited(nIdx), () => renderNodes());
}

function applyResponseDraftTextFormat(nIdx, tagType, tagParam = '') {
    const project = getActiveProject();
    if (!project || !project.nodes[nIdx]) return;
    const node = project.nodes[nIdx];
    if (!node.responseDraftFormat) {
        node.responseDraftFormat = { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
    }
    const textarea = document.getElementById(`resp-input-${nIdx}`);
    applyTextFormatToTarget({ textFormat: node.responseDraftFormat }, textarea, tagType, tagParam, () => markNodeEdited(nIdx), () => renderNodes());
}

function applyTextFormatToTarget(target, textarea, tagType, tagParam, markFn, renderFn) {
    if (!target.textFormat) {
        target.textFormat = { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'center', alignV: 'middle' };
    }
    if (!textarea) return;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = textarea.value.substring(start, end);

    if (selectedText.length > 0) {
        if (['top', 'middle', 'bottom'].includes(tagType)) {
            showNotification("Vertical alignment must be applied globally (select no text).", true);
            return;
        }
        let newText = '';
        let offsetCursor = 0;
        if (tagType === 'align') {
            newText = textarea.value.substring(0, start) + `<align="${tagParam}">` + selectedText + `</align>` + textarea.value.substring(end);
            offsetCursor = 17 + tagParam.length;
        } else if (tagType === 'bullet') {
            const lines = selectedText.split('\n').map(l => `• ${l}`).join('\n');
            newText = textarea.value.substring(0, start) + lines + textarea.value.substring(end);
            offsetCursor = newText.length - selectedText.length;
        } else if (tagType === 'number') {
            const lines = selectedText.split('\n').map((l, i) => `${i + 1}. ${l}`).join('\n');
            newText = textarea.value.substring(0, start) + lines + textarea.value.substring(end);
            offsetCursor = newText.length - selectedText.length;
        } else {
            const tagMap = { 'b': 'b', 'i': 'i', 'u': 'u', 's': 's' };
            const tag = tagMap[tagType] || tagType;
            newText = textarea.value.substring(0, start) + `<${tag}>` + selectedText + `</${tag}>` + textarea.value.substring(end);
            offsetCursor = 5 + (tag.length * 2);
        }
        textarea.value = newText;
        if (textarea.id.startsWith('edit-input-')) {
            const parts = textarea.id.split('-');
            updateResponseText(parseInt(parts[2], 10), parseInt(parts[3], 10), newText);
        }
        if (textarea.id.startsWith('resp-input-')) {
            const parts = textarea.id.split('-');
            const project = getActiveProject();
            if (project && project.nodes[parseInt(parts[2], 10)]) project.nodes[parseInt(parts[2], 10)].responseDraftText = newText;
        }
        if (typeof markFn === 'function') markFn();
        textarea.focus();
        textarea.setSelectionRange(start, end + offsetCursor);
    } else {
        if (textarea.id.startsWith('edit-input-')) {
            const parts = textarea.id.split('-');
            updateResponseText(parseInt(parts[2], 10), parseInt(parts[3], 10), textarea.value);
        }
        if (textarea.id.startsWith('resp-input-')) {
            const parts = textarea.id.split('-');
            const project = getActiveProject();
            if (project && project.nodes[parseInt(parts[2], 10)]) project.nodes[parseInt(parts[2], 10)].responseDraftText = textarea.value;
        }
        if (tagType === 'align') target.textFormat.alignH = tagParam;
        else if (['top', 'middle', 'bottom'].includes(tagType)) target.textFormat.alignV = tagType;
        else if (tagType === 'bullet') target.textFormat.listStyle = target.textFormat.listStyle === 'bullet' ? 'none' : 'bullet';
        else if (tagType === 'number') target.textFormat.listStyle = target.textFormat.listStyle === 'number' ? 'none' : 'number';
        else {
            const keyMap = { 'b': 'bold', 'i': 'italic', 'u': 'underline', 's': 'strikethrough' };
            const key = keyMap[tagType];
            if (key) target.textFormat[key] = !target.textFormat[key];
        }
        if (typeof markFn === 'function') markFn();
        if (typeof renderFn === 'function') renderFn();
    }
}

// Inject on boot
document.addEventListener('DOMContentLoaded', setupKeyboardNavigation);
document.addEventListener('DOMContentLoaded', setupMinimap);

window.renderActiveProjectLogic = function() {
    if (typeof renderProjectTags === 'function') renderProjectTags();
};
