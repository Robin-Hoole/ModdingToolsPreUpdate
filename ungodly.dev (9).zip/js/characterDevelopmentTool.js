document.addEventListener('DOMContentLoaded', () => {

    const API_URL = 'api2.php';
    
    // Global Data Stores
    let toolData = {
        types: [],
        orgTypes: [],
        pantheons: [],
        worlds: [],
        characters: []
    };
    
    let currentCharacter = null;
    let currentCharacterId = null;
    let currentTypeIdFilter = null; // Track selected tab
    
    let editingRelationshipIndex = null; // Tracks index for editing a relationship
    let editingQuoteIndex = null; // Tracks index for editing a quote

    // DOM Element Cache
    const saveCharBtn = document.getElementById('save-char-btn');
    const exportBtn = document.getElementById('export-char-btn');
    const importFileInput = document.getElementById('import-file-input');
    const colorPicker = document.getElementById('char-color-picker');
    const colorText = document.getElementById('char-color-text');
    const sidebarList = document.getElementById('characterList');
    const filterContainer = document.getElementById('character-type-filter');
    const searchInput = document.getElementById('character-search-input'); 

    // --- API Helper ---
    const apiCall = async (action, method = 'GET', body = null) => {
        let url = `${API_URL}?action=${action}`;
        if (method === 'GET' && body) {
            url += `&${new URLSearchParams(body)}`;
        }
        const options = { method, headers: { 'Content-Type': 'application/json' } };
        if (body && method !== 'GET') options.body = JSON.stringify(body);
        try {
            const response = await fetch(url, options);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const data = await response.json();
            if (!data.success) throw new Error(data.message);
            return data;
        } catch (error) {
            console.error(`API Error for '${action}':`, error);
            alert(`An error occurred: ${error.message}`);
            return null;
        }
    };

    // --- Init ---
    const init = async () => {
        setupEventListeners();
        initInspectorSliders();
        saveCharBtn.disabled = true;
        exportBtn.disabled = true;
        await loadToolData();
    };

    // --- Main Data Loader ---
    const loadToolData = async () => {
        const data = await apiCall('getToolData');
        if (data?.success) {
            toolData.types = data.types;
            toolData.orgTypes = data.orgTypes || [];
            toolData.pantheons = data.pantheons;
            toolData.worlds = data.worlds;
            toolData.characters = data.characters;
            
            // Default filter to first type if not set
            if (currentTypeIdFilter === null && toolData.types.length > 0) {
                currentTypeIdFilter = toolData.types[0].id;
            }
            
            renderTypeTabs();
            renderSidebar();
        }
    };

    // --- Render Type Tabs ---
    const renderTypeTabs = () => {
        filterContainer.innerHTML = '';
        toolData.types.forEach(type => {
            const btn = document.createElement('button');
            btn.className = 'btn type-filter-btn';
            btn.textContent = type.name;
            btn.dataset.typeId = type.id;
            if (parseInt(type.id) === parseInt(currentTypeIdFilter)) {
                btn.classList.add('active');
            }
            btn.addEventListener('click', () => {
                currentTypeIdFilter = parseInt(type.id);
                // Clear search when switching tabs to avoid confusion
                searchInput.value = ''; 
                updateSearchClearButton(); // Hide clear button
                renderTypeTabs(); // Re-render to update active class
                renderSidebar();
            });
            filterContainer.appendChild(btn);
        });
    };

    // --- Sidebar Rendering ---
    const renderSidebar = () => {
        sidebarList.innerHTML = '';
        const searchQuery = searchInput.value.trim().toLowerCase();

        // 1. SEARCH MODE (Flat List)
        if (searchQuery.length > 0) {
            document.getElementById('character-list-title').textContent = "Search Results";
            
            const filteredChars = toolData.characters.filter(c => 
                c.name.toLowerCase().includes(searchQuery)
            );

            if (filteredChars.length === 0) {
                sidebarList.innerHTML = '<li style="padding:10px; color:#666;">No matches found.</li>';
                return;
            }

            filteredChars.sort((a,b) => a.name.localeCompare(b.name)).forEach(c => {
                const typeName = toolData.types.find(t => t.id == c.character_type_id)?.name || 'Unknown';
                const li = createCharacterLi(c);
                const badge = document.createElement('span');
                badge.style.cssText = "font-size: 10px; color: #666; margin-right: 5px; text-transform:uppercase;";
                badge.textContent = `[${typeName}]`;
                li.prepend(badge);
                sidebarList.appendChild(li);
            });
            
            updateActiveCharacterInList(currentCharacterId);
            return;
        }

        // 2. STANDARD CATEGORIZED MODE
        const currentType = toolData.types.find(t => t.id == currentTypeIdFilter);
        
        if (!currentType) {
            sidebarList.innerHTML = '<li style="padding:10px; color:#666;">No type selected.</li>';
            return;
        }

        document.getElementById('character-list-title').textContent = `${currentType.name}s`;

        const relevantChars = toolData.characters.filter(c => c.character_type_id === parseInt(currentTypeIdFilter));
        
        let usesOrgs = false;
        let orgList = [];
        
        // Hardcoded or Dynamic Logic for Org Mapping
        if (currentType.id == 1) { usesOrgs = true; orgList = toolData.pantheons; } // God
        else if (currentType.id == 2) { usesOrgs = true; orgList = toolData.worlds; } // Villager
        
        if (usesOrgs) {
            // Group By Org
            const groups = {};
            orgList.forEach(org => groups[org.id] = { id: org.id, name: org.name, chars: [] });
            groups['unassigned'] = { id: 'unassigned', name: 'Unassigned', chars: [] };

            relevantChars.forEach(c => {
                const oid = c.organization_id || 'unassigned';
                if(groups[oid]) groups[oid].chars.push(c);
                else groups['unassigned'].chars.push(c);
            });

            // Render Groups
            Object.values(groups).forEach(group => {
                if (group.chars.length === 0 && group.id === 'unassigned') return; 

                // Header
                const header = document.createElement('div');
                header.className = 'org-header collapsible-header';
                header.innerHTML = `<span class="arrow">▼</span> ${group.name} <span style="font-weight:normal; opacity:0.7;">(${group.chars.length})</span>`;
                
                // List Container
                const listContainer = document.createElement('ul');
                listContainer.className = 'org-char-list';
                
                // Toggle Logic
                header.addEventListener('click', () => {
                    const arrow = header.querySelector('.arrow');
                    if (listContainer.style.display === 'none') {
                        listContainer.style.display = 'block';
                        arrow.textContent = '▼';
                    } else {
                        listContainer.style.display = 'none';
                        arrow.textContent = '▶';
                    }
                });

                group.chars.sort((a,b) => a.name.localeCompare(b.name)).forEach(c => {
                    listContainer.appendChild(createCharacterLi(c));
                });

                sidebarList.appendChild(header);
                sidebarList.appendChild(listContainer);
            });
        } else {
            // Flat List (Consciences)
            relevantChars.sort((a,b) => a.name.localeCompare(b.name)).forEach(c => {
                sidebarList.appendChild(createCharacterLi(c));
            });
        }
        
        updateActiveCharacterInList(currentCharacterId);
    };

    const createCharacterLi = (char) => {
        const li = document.createElement('li');
        li.dataset.id = char.id;
        li.innerHTML = `<span style="border-left: 3px solid ${char.color || 'var(--accent-primary)'}; padding-left: 8px; flex-grow: 1;">${char.name}</span> <button class="btn btn-delete delete-char-btn" data-id="${char.id}">X</button>`;
        return li;
    };

    const loadCharacterDetails = async (id) => {
        const data = await apiCall(`getCharacterDetails`, 'GET', {id: id});
        if (data?.success) {
            currentCharacterId = id;
            currentCharacter = data.details;
            if (!currentCharacter.quotes) currentCharacter.quotes = [];
            if (!currentCharacter.relationships) currentCharacter.relationships = [];
            renderCharacterDetails();
            updateActiveCharacterInList(id);
            saveCharBtn.disabled = false;
            exportBtn.disabled = false;
        }
    };

    const updateActiveCharacterInList = (id) => {
        document.getElementById('characterList').querySelectorAll('li').forEach(li => li.classList.toggle('active', li.dataset.id == id));
    };

    const deselectCharacter = () => {
        currentCharacterId = null;
        currentCharacter = null;
        document.getElementById('no-character-selected').classList.remove('hidden');
        document.getElementById('character-editor').classList.add('hidden');
        saveCharBtn.disabled = true;
        exportBtn.disabled = true;
        updateActiveCharacterInList(null);
    };

    // --- Editor Rendering ---
    const renderCharacterDetails = async () => {
        if (!currentCharacter) { deselectCharacter(); return; }
        document.getElementById('no-character-selected').classList.add('hidden');
        document.getElementById('character-editor').classList.remove('hidden');

        // Populate Fields
        document.getElementById('character-editor').querySelectorAll('[data-field]').forEach(el => {
            const table = el.dataset.table;
            const field = el.dataset.field;
            let val = '';

            if (table && field && currentCharacter[table] && typeof currentCharacter[table][field] !== 'undefined') {
                val = currentCharacter[table][field];
            }

            if (el.type === 'checkbox') {
                el.checked = (val == 1 || val === true);
            } else if (el.tagName === 'SELECT' && val === '') {
                // Handled specifically below for Type/Org
            } else {
                el.value = val !== '' ? val : '';
            }
            
            // Slider display update
            if(el.type === 'range') {
                const display = el.nextElementSibling;
                if(display) display.textContent = el.value || 0;
            }
        });

        // Set Hard Rules default if empty
        const hrText = document.getElementById('llm_hard_rules_text');
        if (!hrText.value) hrText.value = "HARD RULES:\n- Never say you are an AI, model, or assistant.\n- Speak only as the character in first-person.\n- Keep replies to 1-2 short sentences.";

        // Populate Dropdowns
        populateCharacterTypeDropdown(currentCharacter.core.character_type_id);
        renderOrganizationDropdown(currentCharacter.core.character_type_id, currentCharacter.core.organization_id);

        colorPicker.value = currentCharacter.core.color || '#ff4444';
        colorText.value = currentCharacter.core.color || '#ff4444';

        renderRelationships();
        renderQuotes();
    };

    const populateCharacterTypeDropdown = (selectedId) => {
        const select = document.getElementById('char-type-select');
        select.innerHTML = '';
        toolData.types.forEach(type => {
            const option = document.createElement('option');
            option.value = type.id;
            option.textContent = type.name;
            option.selected = type.id == selectedId;
            select.appendChild(option);
        });
    };

    const renderOrganizationDropdown = (typeId, selectedOrgId) => {
        const select = document.getElementById('char-organization');
        const orgGroup = document.getElementById('organization-group');
        const typeInfo = toolData.types.find(t => t.id == typeId);
        // Map hardcoded names for safety if DB fields missing
        const label = typeInfo?.organization_label || (typeId == 1 ? 'Pantheon' : (typeId == 2 ? 'World' : null));

        if (label) {
            orgGroup.style.display = 'block';
            document.getElementById('organization-label').textContent = label;
            document.getElementById('new-organization-btn').textContent = `New ${label}`;
            
            select.innerHTML = `<option value="">Select ${label}...</option>`;
            
            let orgList = [];
            if (typeId == 1) orgList = toolData.pantheons;
            else if (typeId == 2) orgList = toolData.worlds;
            
            orgList.forEach(org => {
                const option = document.createElement('option');
                option.value = org.id;
                option.textContent = org.name;
                option.selected = org.id === selectedOrgId;
                select.appendChild(option);
            });
        } else {
            orgGroup.style.display = 'none';
        }
    };

    const handleCharacterTypeChange = (e) => {
        const newTypeId = parseInt(e.target.value);
        renderOrganizationDropdown(newTypeId, null);
    };

    // --- Save Logic ---
    const handleSaveCharacter = async () => {
        if (!currentCharacterId) return;
        const payload = collectDataFromForm();
        if (!payload.core.name.trim()) { alert("Name required."); return; }
        
        const result = await apiCall('saveCharacter', 'POST', { data: payload });
        if (result?.success) {
            await loadToolData();
            await loadCharacterDetails(currentCharacterId);
            alert('Saved.');
        }
    };

    const handleCreateCharacter = async () => {
        const input = document.getElementById('new-char-name-input');
        const name = input.value.trim();
        if (!name) { alert("Name required"); return; }
        
        // Use currently selected filter type as default
        const typeId = currentTypeIdFilter || 1; 

        const payload = {
            core: { name: name, character_type_id: typeId, color: '#ff4444' },
            profiles: {}, arc: {}, voice: {}, llm: {}, quotes: [], relationships: []
        };
        
        const result = await apiCall('saveCharacter', 'POST', { data: payload });
        if (result?.success && result.newId) {
            input.value = '';
            document.getElementById('newCharacterModal').classList.remove('active');
            await loadToolData();
            await loadCharacterDetails(result.newId);
        }
    };

    const handleSaveOrganization = async () => {
        const input = document.getElementById('organization-name-input');
        const name = input.value.trim();
        const typeId = document.getElementById('char-type-select').value;
        if (!name) return alert('Name required');
        
        const result = await apiCall('createOrganization', 'POST', { name: name, type_id: typeId });
        if (result?.success) {
            await loadToolData(); // Refresh org lists
            renderOrganizationDropdown(typeId, result.newOrganization.id);
            input.value = '';
            document.getElementById('organizationModal').classList.remove('active');
        }
    };
    
    // --- Management Modal Logic ---
    const openTypesManagementModal = async () => {
        await loadToolData(); // Refresh data
        renderCharacterTypesList();
        renderOrgTypesList();
        populateOrgTypeDropdown();
        prepareTypeModalForCreate();
        document.getElementById('typesManagementModal').classList.add('active');
    };

    const renderCharacterTypesList = () => {
        const listEl = document.getElementById('character-types-list');
        listEl.innerHTML = '';
        toolData.types.forEach(type => {
            const item = document.createElement('div');
            item.className = 'list-item';
            item.innerHTML = `
                <span>${type.name}</span>
                <div class="list-item-actions">
                    <button class="btn" data-action="edit-type" data-id="${type.id}">Edit</button>
                    <button class="btn btn-delete" data-action="delete-type" data-id="${type.id}">Del</button>
                </div>`;
            listEl.appendChild(item);
        });
        const listEventHandler = (e) => {
            const action = e.target.dataset.action;
            const id = e.target.dataset.id;
            if (action === 'edit-type') prepareTypeModalForEdit(id);
            if (action === 'delete-type') deleteCharacterType(id);
        };
        listEl.removeEventListener('click', listEventHandler);
        listEl.addEventListener('click', listEventHandler);
    };

    const renderOrgTypesList = () => {
        const listEl = document.getElementById('org-types-list');
        listEl.innerHTML = '';
        toolData.orgTypes.forEach(type => {
            const item = document.createElement('div');
            item.className = 'list-item';
            item.innerHTML = `
                <span>${type.label}</span>
                <div class="list-item-actions">
                    <button class="btn btn-delete" data-action="delete-org-type" data-id="${type.id}">Del</button>
                </div>`;
            listEl.appendChild(item);
        });
        const listEventHandler = (e) => {
            const action = e.target.dataset.action;
            const id = e.target.dataset.id;
            if (action === 'delete-org-type') deleteOrganizationType(id);
        };
        listEl.removeEventListener('click', listEventHandler);
        listEl.addEventListener('click', listEventHandler);
    };

    const populateOrgTypeDropdown = (selectedId = '') => {
        const select = document.getElementById('type-org-type-select');
        select.innerHTML = '<option value="">None</option>';
        toolData.orgTypes.forEach(orgType => {
            const option = document.createElement('option');
            option.value = orgType.id;
            option.textContent = orgType.label;
            option.selected = orgType.id == selectedId;
            select.appendChild(option);
        });
    };

    const prepareTypeModalForCreate = () => {
        document.getElementById('editing-type-id').value = '';
        document.getElementById('type-name-input').value = '';
        document.getElementById('type-org-type-select').value = '';
        document.getElementById('type-name-input').focus();
    };

    const prepareTypeModalForEdit = (id) => {
        const type = toolData.types.find(t => t.id == id);
        if (!type) return;
        document.getElementById('editing-type-id').value = type.id;
        document.getElementById('type-name-input').value = type.name;
        populateOrgTypeDropdown(type.organization_type_id);
    };

    const saveCharacterType = async () => {
        const id = document.getElementById('editing-type-id').value;
        const name = document.getElementById('type-name-input').value.trim();
        const org_type_id = document.getElementById('type-org-type-select').value;
        if (!name) { alert("Type name is required."); return; }

        const action = id ? 'updateCharacterType' : 'createCharacterType';
        const payload = { id, name, organization_type_id: org_type_id };
        const result = await apiCall(action, 'POST', payload);

        if (result?.success) {
            await loadToolData();
            renderCharacterTypesList();
            prepareTypeModalForCreate();
            renderTypeTabs(); // Refresh sidebar tabs too
        }
    };

    const deleteCharacterType = async (id) => {
        const type = toolData.types.find(t => t.id == id);
        if (confirm(`Delete type "${type.name}"?`)) {
            const result = await apiCall('deleteCharacterType', 'POST', { id });
            if (result?.success) {
                await loadToolData();
                renderCharacterTypesList();
                renderTypeTabs();
                // If current filter deleted, switch to first available
                if (currentTypeIdFilter == id) {
                    currentTypeIdFilter = toolData.types.length > 0 ? toolData.types[0].id : null;
                    renderSidebar();
                }
            }
        }
    };

    const saveOrganizationType = async () => {
        const input = document.getElementById('org-type-label-input');
        const label = input.value.trim();
        if (!label) return;
        const result = await apiCall('createOrganizationType', 'POST', { label });
        if (result?.success) {
            await loadToolData();
            renderOrgTypesList();
            populateOrgTypeDropdown();
            input.value = '';
        }
    };

    const deleteOrganizationType = async (id) => {
        if (confirm(`Delete org type?`)) {
            const result = await apiCall('deleteOrganizationType', 'POST', { id });
            if (result?.success) {
                await loadToolData();
                renderOrgTypesList();
                populateOrgTypeDropdown();
            }
        }
    };

    // --- Dropdown Builder Helper for Modals ---
    const populateRelationshipDropdown = () => {
        const relSel = document.getElementById('rel-character-select');
        relSel.innerHTML = '<option value="">Select Character...</option>';
        toolData.characters.forEach(c => {
            if(c.id !== currentCharacterId) {
                const opt = document.createElement('option');
                opt.value = c.id;
                opt.textContent = c.name;
                relSel.appendChild(opt);
            }
        });
    };

    // --- Utils & Event Listeners ---

    const collectDataFromForm = () => {
        const payload = {
            id: currentCharacterId,
            core: { id: currentCharacterId },
            profiles: {}, arc: {}, voice: {}, llm: {}, '3act': {}, // Added 3act
            quotes: currentCharacter.quotes || [],
            relationships: currentCharacter.relationships || []
        };
        document.getElementById('character-editor').querySelectorAll('[data-field]').forEach(el => {
            const table = el.dataset.table;
            const field = el.dataset.field;
            if (!payload[table]) payload[table] = {};

            if(el.type === 'checkbox') {
                payload[table][field] = el.checked ? 1 : 0;
            } else if (el.type === 'range' || el.type === 'number') {
                const val = parseFloat(el.value);
                payload[table][field] = isNaN(val) ? 0 : val;
            } else {
                payload[table][field] = el.value;
            }
        });
        return payload;
    };

    const handleFileImport = (event) => {
        const file = event.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = async (e) => {
            try {
                const importedData = JSON.parse(e.target.result);
                if (!importedData.core) throw new Error('Invalid format');
                
                // --- Fix LLM Floats ---
                if (importedData.llm) {
                    ['affinity', 'sarcasm', 'trust', 'empathy', 'formality', 'curiosity', 'playfulness', 'confidence', 'cautiousness', 'flirtatiousness', 'admiration', 'adoration', 'anger', 'devotion', 'fear', 'honor', 'malice', 'seduction', 'suspicion', 'sympathy', 'valor'].forEach(field => {
                        if (typeof importedData.llm[field] !== 'undefined') {
                            let val = parseFloat(importedData.llm[field]);
                            if (val > 0 && val <= 1.0) importedData.llm[field] = Math.round(val * 100);
                            else importedData.llm[field] = Math.round(val);
                        }
                    });
                }

                if (confirm(`Import ${importedData.core.name}? Overwrites if exists.`)) {
                    const existingChar = toolData.characters.find(c => c.name.toLowerCase() === importedData.core.name.toLowerCase() || c.id === importedData.core.id);
                    
                    if (existingChar) {
                        importedData.core.id = existingChar.id;
                        if(importedData.id) importedData.id = existingChar.id;
                    } else {
                        delete importedData.core.id; 
                        delete importedData.id;
                    }

                    const result = await apiCall('saveCharacter', 'POST', { data: importedData });
                    if (result?.success) {
                        alert('Imported.');
                        await loadToolData();
                        const id = result.newId || existingChar?.id;
                        if (id) await loadCharacterDetails(id);
                    }
                }
            } catch (err) { alert(err.message); }
            importFileInput.value = '';
        };
        reader.readAsText(file);
    };

    const handleDeleteCharacter = async (id) => {
        if(confirm('Delete character?')) {
            await apiCall('deleteCharacter', 'POST', {id});
            await loadToolData();
            if(currentCharacterId === id) deselectCharacter();
        }
    };
    
    // --- Setup Listeners ---
    function setupEventListeners() {
        // Search Input Listener
        searchInput.addEventListener('input', () => {
            renderSidebar();
            updateSearchClearButton();
        });

        // Add Search Clear Button Functionality
        const clearBtn = document.createElement('button');
        clearBtn.id = 'search-clear-btn';
        clearBtn.innerHTML = '×';
        clearBtn.style.cssText = `
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #999;
            font-size: 18px;
            cursor: pointer;
            display: none;
            z-index: 10;
        `;
        
        // Wrap search input to position clear button
        const searchWrapper = searchInput.parentElement;
        if(searchWrapper) {
            searchWrapper.style.position = 'relative';
            searchWrapper.appendChild(clearBtn);
        }

        clearBtn.addEventListener('click', () => {
            searchInput.value = '';
            renderSidebar();
            updateSearchClearButton();
            searchInput.focus();
        });

        document.getElementById('characterList').addEventListener('click', e => {
            const li = e.target.closest('li');
            if (e.target.matches('.delete-char-btn')) {
                e.stopPropagation();
                handleDeleteCharacter(e.target.dataset.id);
            } else if (li?.dataset.id) {
                loadCharacterDetails(li.dataset.id);
            }
        });

        saveCharBtn.addEventListener('click', handleSaveCharacter);
        document.getElementById('new-char-btn').addEventListener('click', () => document.getElementById('newCharacterModal').classList.add('active'));
        document.getElementById('create-char-btn').addEventListener('click', handleCreateCharacter);

        document.getElementById('new-organization-btn').addEventListener('click', () => {
            const typeId = document.getElementById('char-type-select').value;
            const typeInfo = toolData.types.find(t => t.id == typeId);
            const label = typeInfo?.organization_label || (typeId == 1 ? 'Pantheon' : (typeId == 2 ? 'World' : 'Group'));
            document.getElementById('organization-modal-title').textContent = `New ${label}`;
            document.getElementById('organization-name-input').value = '';
            document.getElementById('organizationModal').classList.add('active');
        });
        document.getElementById('save-organization-btn').addEventListener('click', handleSaveOrganization);

        document.getElementById('char-type-select').addEventListener('change', handleCharacterTypeChange);

        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', (e) => e.target.closest('.modal-overlay').classList.remove('active'));
        });

        document.getElementById('character-editor').querySelector('.tab-nav').addEventListener('click', e => {
            if (e.target.matches('.tab-btn')) switchTab(e.target.dataset.tab);
        });

        document.getElementById('import-char-btn').addEventListener('click', () => importFileInput.click());
        importFileInput.addEventListener('change', handleFileImport);
        
        document.getElementById('export-char-btn').addEventListener('click', () => {
             if(!currentCharacter) return;
             const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(collectDataFromForm(), null, 2));
             const dl = document.createElement('a');
             dl.href = dataStr;
             dl.download = `${currentCharacter.core.name}_export.json`;
             dl.click();
        });

        // En Masse
        document.getElementById('en-masse-btn').addEventListener('click', async () => {
             const sel = document.getElementById('en-masse-org-select');
             sel.innerHTML = '<option value="">Select World...</option>';
             toolData.worlds.forEach(w => {
                 sel.innerHTML += `<option value="${w.id}">${w.name}</option>`;
             });
             document.getElementById('enMasseModal').classList.add('active');
        });
        
        document.getElementById('create-en-masse-btn').addEventListener('click', async () => {
            const names = document.getElementById('en-masse-names-input').value.split(',').map(n=>n.trim()).filter(n=>n);
            const org = document.getElementById('en-masse-org-select').value;
            if(!names.length || !org) return alert('Invalid input');
            await apiCall('createCharactersEnMasse', 'POST', { names, organization_id: org });
            document.getElementById('enMasseModal').classList.remove('active');
            await loadToolData();
        });

        // Sub-items (Relationships & Quotes Buttons)
        document.getElementById('add-relationship-btn').addEventListener('click', () => {
            editingRelationshipIndex = null;
            populateRelationshipDropdown();
            document.getElementById('rel-character-select').value = '';
            document.getElementById('rel-type-select').value = 'Ally';
            document.getElementById('rel-desc-text').value = '';
            document.getElementById('relationship-modal-title').textContent = 'Add Relationship';
            document.getElementById('relationshipModal').classList.add('active');
        });

        document.getElementById('add-quote-btn').addEventListener('click', () => {
            editingQuoteIndex = null;
            document.getElementById('quote-text').value = '';
            document.getElementById('quote-context').value = '';
            document.getElementById('quote-modal-title').textContent = 'Add Quote';
            document.getElementById('quoteModal').classList.add('active');
        });

        // Save Modals
        document.getElementById('save-quote-btn').addEventListener('click', () => {
             const q = document.getElementById('quote-text').value;
             const c = document.getElementById('quote-context').value;
             if(q) {
                 if(!currentCharacter.quotes) currentCharacter.quotes = [];
                 const newQuote = {quote: q, context: c};
                 
                 if (editingQuoteIndex !== null) {
                     currentCharacter.quotes[editingQuoteIndex] = newQuote;
                 } else {
                     currentCharacter.quotes.push(newQuote);
                 }
                 renderQuotes();
             }
             document.getElementById('quoteModal').classList.remove('active');
        });
        
        document.getElementById('save-relationship-btn').addEventListener('click', () => {
             const sel = document.getElementById('rel-character-select');
             if(sel.value) {
                 if(!currentCharacter.relationships) currentCharacter.relationships = [];
                 
                 const relData = {
                     related_character_id: sel.value,
                     related_character_name: sel.options[sel.selectedIndex].text,
                     relationship_type: document.getElementById('rel-type-select').value,
                     dynamic_history: document.getElementById('rel-desc-text').value
                 };

                 if (editingRelationshipIndex !== null) {
                     currentCharacter.relationships[editingRelationshipIndex] = relData;
                 } else {
                     currentCharacter.relationships.push(relData);
                 }
                 renderRelationships();
             }
             document.getElementById('relationshipModal').classList.remove('active');
        });
        
        // Handle Card Actions (Edit/Delete)
        const handleCardAction = (e) => {
            const btn = e.target.closest('.btn');
            if(!btn) return;
            
            const idx = parseInt(btn.dataset.index);
            const type = btn.dataset.type;

            if (btn.classList.contains('delete-btn')) {
                if (type === 'quote') {
                    currentCharacter.quotes.splice(idx, 1);
                    renderQuotes();
                } else if (type === 'relationship') {
                    currentCharacter.relationships.splice(idx, 1);
                    renderRelationships();
                }
            } else if (btn.classList.contains('edit-btn')) {
                if (type === 'quote') {
                    editingQuoteIndex = idx;
                    const q = currentCharacter.quotes[idx];
                    document.getElementById('quote-text').value = q.quote;
                    document.getElementById('quote-context').value = q.context;
                    document.getElementById('quote-modal-title').textContent = 'Edit Quote';
                    document.getElementById('quoteModal').classList.add('active');
                } else if (type === 'relationship') {
                    editingRelationshipIndex = idx;
                    const rel = currentCharacter.relationships[idx];
                    populateRelationshipDropdown();
                    document.getElementById('rel-character-select').value = rel.related_character_id;
                    document.getElementById('rel-type-select').value = rel.relationship_type;
                    document.getElementById('rel-desc-text').value = rel.dynamic_history;
                    document.getElementById('relationship-modal-title').textContent = 'Edit Relationship';
                    document.getElementById('relationshipModal').classList.add('active');
                }
            }
        };

        document.getElementById('quotesGrid').addEventListener('click', handleCardAction);
        document.getElementById('relationshipGrid').addEventListener('click', handleCardAction);

        // Manage Types Button
        document.getElementById('manage-types-btn').addEventListener('click', openTypesManagementModal);
        
        // Modal Save Buttons
        document.getElementById('save-type-btn').addEventListener('click', saveCharacterType);
        document.getElementById('add-new-type-btn').addEventListener('click', prepareTypeModalForCreate);
        document.getElementById('add-org-type-btn').addEventListener('click', saveOrganizationType);

        colorPicker.addEventListener('input', () => colorText.value = colorPicker.value);
        colorText.addEventListener('input', () => colorPicker.value = colorText.value);
    }

    // --- Search Helper ---
    function updateSearchClearButton() {
        const btn = document.getElementById('search-clear-btn');
        if(btn) {
            btn.style.display = searchInput.value.length > 0 ? 'block' : 'none';
        }
    }
    
    // --- Inspector Sliders ---
    function initInspectorSliders() {
        document.querySelectorAll('.unity-inspector-panel input[type="range"]').forEach(range => {
            const updateVal = () => {
                const display = range.nextElementSibling;
                if(display && display.classList.contains('val-display')) {
                    display.textContent = range.value;
                }
            };
            range.addEventListener('input', updateVal);
            updateVal();
        });
    }

    const switchTab = (tabId) => {
        document.getElementById('character-editor').querySelectorAll('.tab-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tabId));
        document.getElementById('character-editor').querySelectorAll('.tab-content').forEach(content => content.classList.toggle('active', content.id === `${tabId}-tab`));
    };

    const renderRelationships = () => {
        const grid = document.getElementById('relationshipGrid');
        grid.innerHTML = '';
        if (!currentCharacter?.relationships) return;
        currentCharacter.relationships.forEach((rel, index) => {
            const card = document.createElement('div');
            card.className = 'card';
            card.innerHTML = `
                <div class="card-actions">
                    <button class="btn edit-btn" data-type="relationship" data-index="${index}">Edit</button>
                    <button class="btn btn-delete delete-btn" data-type="relationship" data-index="${index}">Delete</button>
                </div>
                <h4>${rel.related_character_name}</h4>
                <span class="relationship-type">${rel.relationship_type}</span>
                <p>${rel.dynamic_history || 'No description.'}</p>`;
            grid.appendChild(card);
        });
    };

    const renderQuotes = () => {
        const grid = document.getElementById('quotesGrid');
        grid.innerHTML = '';
        if (!currentCharacter?.quotes) return;
        currentCharacter.quotes.forEach((quote, index) => {
            const card = document.createElement('div');
            card.className = 'quote-card';
            card.innerHTML = `
                <div class="card-actions">
                    <button class="btn edit-btn" data-type="quote" data-index="${index}">Edit</button>
                    <button class="btn btn-delete delete-btn" data-type="quote" data-index="${index}">Delete</button>
                </div>
                <p>"${quote.quote}"</p>${quote.context ? `<small>— ${quote.context}</small>` : ''}`;
            grid.appendChild(card);
        });
    };

    init();
});