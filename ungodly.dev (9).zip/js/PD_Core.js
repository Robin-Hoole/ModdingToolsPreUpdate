const OPERATORS = ["==", ">=", "<=", "+", "-", "!="];
const TRIGGER_EVENTS = ["OnGameAwake", "OnDayStart", "OnRoomEnter", "OnTaskComplete", "RandomInterrupt", "Custom"];

// UI Definition for dynamic left-panel sections
const GLOBAL_SECTIONS = [
    { key: 'globalCast', title: 'Global Cast', placeholder: 'Character Name...', btnText: 'Create Character' },
    { key: 'globalStates', title: 'Global States', placeholder: 'State Name (e.g. Idle)...', btnText: 'Create State' },
    { key: 'globalMoods', title: 'Global Moods', placeholder: 'Mood (e.g. Happy)...', btnText: 'Create Mood' },
    { key: 'globalSettings', title: 'Global Settings', placeholder: 'Setting Name...', btnText: 'Create Setting' },
    { key: 'timesOfDay', title: 'Times of Day', placeholder: 'Time (e.g. Morning)...', btnText: 'Create Time' },
    { key: 'daysOfWeek', title: 'Days of the Week', placeholder: 'Day (e.g. Monday)...', btnText: 'Create Day' },
    { key: 'menuOptions', title: 'Menu Options', placeholder: 'Option Name...', btnText: 'Create Option' },
    { key: 'imageSequences', title: 'Image Sequences', placeholder: 'Sequence Name...', btnText: 'Create Sequence' },
    { key: 'globalFrames', title: 'Global Frames', placeholder: 'Frame Name...', btnText: 'Create Frame' }
];

let projectData = {
    tokens: [
        { key: "userName", value: "Player One" },
        { key: "location", value: "Cyber City" }
    ],
    tags: [
        { name: "News Alert", color: "#00f2ff" },
        { name: "Advertisement", color: "#ff8c00" },
        { name: "Dev Message", color: "#ff007b" }
    ],
    positionTypes: [], // New structure for Global Positions
    prompts: []
};

// Initialize empty arrays for dynamic sections
GLOBAL_SECTIONS.forEach(sec => {
    if(!projectData[sec.key]) projectData[sec.key] = [];
});

let activeTag = "News Alert";
let activePromptId = null;
let editingTagIdx = null;
let editingTokenIdx = null;
let lastSelectedPosTypeId = null; // Remembers previously selected Position dropdown

// Sticky Tab & Inline Edit Tracking
let lastActivePerCategory = {};
let editingPromptTitleId = null;

let editingGlobalItem = { section: null, id: null };
let logicSearchQuery = "";
let currentLogicEdit = null;

// Position specific edit states
let editingPosTypeId = null;
let editingPosTagId = null;
let contextMenuTargetId = null;

// Click anywhere closes context menu
document.addEventListener('click', closeContextMenus);
document.addEventListener('contextmenu', closeContextMenus);

// Keyboard Navigation Events
document.addEventListener('keydown', (e) => {
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) return;

    if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
        e.preventDefault();
        const currentIndex = projectData.tags.findIndex(t => t.name === activeTag);
        if (currentIndex === -1) return;
        let newIndex = e.key === 'ArrowRight' ? currentIndex + 1 : currentIndex - 1;
        if (newIndex >= 0 && newIndex < projectData.tags.length) {
            selectCategory(projectData.tags[newIndex].name);
            const tabElement = document.querySelector(`.char-tab:nth-child(${newIndex + 1})`);
            if (tabElement) tabElement.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        }
    } else if (['ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End'].includes(e.key)) {
        e.preventDefault();
        const promptsInTab = projectData.prompts.filter(p => p.tag === activeTag);
        if (promptsInTab.length === 0) return;
        
        const promptSearchInput = document.getElementById('prompt-search');
        const searchQ = promptSearchInput ? promptSearchInput.value.toLowerCase() : "";
        const filteredPrompts = promptsInTab.filter(p => {
            if (!searchQ) return true;
            return p.title.toLowerCase().includes(searchQ) || p.id.toLowerCase().includes(searchQ) || p.bodyText.toLowerCase().includes(searchQ);
        });

        if (filteredPrompts.length === 0) return;

        const currentIndex = filteredPrompts.findIndex(p => p.id === activePromptId);
        let newIndex = currentIndex;

        if (e.key === 'ArrowDown') newIndex = currentIndex + 1;
        if (e.key === 'ArrowUp') newIndex = currentIndex - 1;
        if (e.key === 'PageDown') newIndex = currentIndex + 10;
        if (e.key === 'PageUp') newIndex = currentIndex - 10;
        if (e.key === 'Home') newIndex = 0;
        if (e.key === 'End') newIndex = filteredPrompts.length - 1;
        
        newIndex = Math.max(0, Math.min(newIndex, filteredPrompts.length - 1));

        if (newIndex !== currentIndex) {
            selectPrompt(filteredPrompts[newIndex].id);
            document.getElementById('active-prompt-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
});

function getRandomHex() {
    return '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
}

function showNotification(msg) {
    const n = document.getElementById('notification');
    n.innerText = msg;
    n.classList.add('show');
    setTimeout(() => n.classList.remove('show'), 2500);
}

function closeContextMenus(e) {
    if (e && e.type === 'contextmenu') return; // let right click logic handle itself
    document.getElementById('pos-type-context-menu').classList.add('hidden');
    contextMenuTargetId = null;
}

// --- OPTGROUP HELPER ---
function getPositionOptionsHTML(selectedValue) {
    let html = `<option value="">-- Select Position --</option>`;
    projectData.positionTypes.forEach(pt => {
        if (pt.tags.length > 0) {
            html += `<optgroup label="${pt.name}">`;
            pt.tags.forEach(tag => {
                const selected = (tag.id === selectedValue) ? 'selected' : '';
                html += `<option value="${tag.id}" ${selected}>${tag.name}</option>`;
            });
            html += `</optgroup>`;
        }
    });
    return html;
}

window.onload = () => {
    renderLists();
    renderLogicPanel();
};