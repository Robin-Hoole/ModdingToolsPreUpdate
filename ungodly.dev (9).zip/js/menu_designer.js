// --- Global State ---
let projects = {};
let activeProjectId = null;
let selectedComponentId = null;
let htmlEditor, cssEditor, jsEditor;
let dragState = {
    isDragging: false,
    isResizing: false,
    target: null,
    componentId: null,
    handle: null,
    startX: 0,
    startY: 0,
    startWidth: 0,
    startHeight: 0,
    startLeft: 0,
    startTop: 0
};

// --- DOM Elements ---
const dom = {
    app: null,
    leftPanel: null,
    mainCanvasArea: null,
    resizerV: null,
    resizerH: null,
    controlCenter: null,
    codeRepository: null,
    projectTabsContainer: null,
    addProjectTab: null,
    renderArea: null,
    dynamicStyles: null,
    codeTabs: null,
    htmlCodeOutput: null,
    cssCodeOutput: null,
    jsCodeOutput: null,
    copyCodeBtn: null,
    applyCodeBtn: null,
    cloneSettingsBtn: null,
    newFromClipboardBtn: null,
    exportPngBtn: null,
    randomizeBtn: null,
    addTextBtn: null,
    addButtonBtn: null,
    addInputBtn: null,
    addOverflowBtn: null,
    compControlsWrapper: null,
    textControls: null,
    buttonControls: null,
    inputControls: null,
};

// --- Default State Factories ---
const getDefaultProjectState = (id, name, components = []) => ({
    id: id,
    name: name,
    canvas: {
        width: 400,
        widthUnit: 'px',
        height: 500,
        heightUnit: 'px',
        bgColor: '#1a1a22',
        bgType: 'solid',
        bgGradientType: 'linear-gradient',
        bgGradientDirection: 'to bottom right',
        bgGradientStop1: '#ff00ff',
        bgGradientStop2: '#00ffff',
        borderWidth: 1,
        borderStyle: 'solid',
        borderColor: '#00ffff',
        radiusMaster: 12,
        radiusTL: '',
        radiusTR: '',
        radiusBR: '',
        radiusBL: '',
        filterBlur: 10,
        filterBrightness: 100,
        glowColor: '#00ffff',
        glowBlur: 20,
        glowSpread: 0,
        strobe: false,
        strobeColor: '#ff00ff',
        strobeSpeed: 1000,
        insetShadowColor: '#000000',
        insetShadowBlur: 10,
        scrollbarTrackColor: '#101018',
        scrollbarThumbColor: '#00ffff',
        scrollbarThumbRadius: 10,
    },
    components: components
});

const getDefaultComponent = (type) => {
    const base = {
        id: `comp-${Date.now()}`,
        type: type,
        x: 50,
        y: 100,
        w: 150,
        h: 40,
        style: {}
    };
    switch (type) {
        case 'text':
            base.content = 'New Text';
            base.style = { color: '#e0e0e0', fontSize: '16px', fontFamily: "'Inter', sans-serif", glowColor: '#000000', glowBlur: '0px' };
            break;
        case 'button':
            base.content = 'Click Me';
            base.style = { background: 'transparent', border: '1px solid #00ffff', color: '#00ffff', borderRadius: '8px' };
            base.w = 120;
            break;
        case 'input':
            base.content = 'Enter text...'; // Placeholder
            base.style = { background: '#101018', border: '1px solid #333', color: '#e0e0e0', borderRadius: '6px', padding: '8px' };
            base.w = 200;
            break;
        case 'overflow':
            base.content = 'Overflow Test Content. This box is intentionally tall to demonstrate the internal scrollbar styling. Add more content or make it taller to ensure the scrollbar appears.';
            base.style = { background: '#ffffff11', color: 'white', padding: '10px' };
            base.w = 300;
            base.h = 200; // Shorter than before
            base.y = 80;
            break;
    }
    return base;
};

// --- Main Initialization ---
document.addEventListener('DOMContentLoaded', () => {
    // 1. Cache all DOM elements
    for (const key in dom) {
        // This is a simple way to cache all elements by their ID
        const kebabKey = key.replace(/[A-Z]/g, m => "-" + m.toLowerCase());
        dom[key] = document.getElementById(kebabKey) || document.querySelector(`.${kebabKey}`);
    }
    // Manual query for specific elements
    dom.htmlCodeOutput = document.getElementById('html-code-output');
    dom.cssCodeOutput = document.getElementById('css-code-output');
    dom.jsCodeOutput = document.getElementById('js-code-output');
    dom.textControls = document.getElementById('text-component-controls');
    dom.buttonControls = document.getElementById('button-component-controls');
    dom.inputControls = document.getElementById('input-component-controls');
    dom.projectTabsContainer = document.getElementById('project-tabs-container');
    
    // 2. Initialize CodeMirror Editors
    htmlEditor = CodeMirror(document.getElementById('html-editor-container'), {
        value: '<!-- HTML will appear here -->',
        mode: "xml",
        theme: "material-darker",
        lineNumbers: true,
        autoCloseTags: true
    });
    cssEditor = CodeMirror(document.getElementById('css-editor-container'), {
        value: '/* CSS will appear here */',
        mode: "css",
        theme: "material-darker",
        lineNumbers: true,
        autoCloseBrackets: true
    });
    jsEditor = CodeMirror(document.getElementById('js-editor-container'), {
        value: '// JS will appear here',
        mode: "javascript",
        theme: "material-darker",
        lineNumbers: true,
        autoCloseBrackets: true
    });

    // 3. Initialize Color Pickers
    initializeColorPickers();

    // 4. Load the default project template
    loadTemplate('cyber-luxe-default');

    // 5. Render everything based on the loaded state
    renderAll();

    // 6. Setup all event listeners
    setupEventListeners();

    // 7. Enable panel resizing
    initResizing();
});

// --- STATE & RENDER FUNCTIONS ---
function createNewProject() {
    const newId = `project-${Date.now()}`;
    const newName = `Menu ${Object.keys(projects).length + 1}`;
    projects[newId] = getDefaultProjectState(newId, newName);
    setActiveProject(newId);
}

function setActiveProject(id) {
    activeProjectId = id;
    selectedComponentId = null;
    renderAll();
}

function renderAll() {
    if (!activeProjectId) return;
    renderProjectTabs();
    updateControlsFromState();
    renderCanvasFromState();
    renderCodeEditorsFromState();
    updateComponentControlsVisibility();
}

function renderProjectTabs() {
    if (!dom.projectTabsContainer) return;
    dom.projectTabsContainer.innerHTML = ''; // Clear existing
    Object.values(projects).forEach(proj => {
        const tab = document.createElement('button');
        tab.className = `project-tab ${proj.id === activeProjectId ? 'active' : ''}`;
        tab.textContent = proj.name;
        tab.dataset.id = proj.id;
        tab.addEventListener('click', () => setActiveProject(proj.id));
        dom.projectTabsContainer.appendChild(tab);
    });
}

function updateControlsFromState() {
    const state = projects[activeProjectId].canvas;

    // Canvas
    setValue('canvas-width-slider', state.width);
    setValue('canvas-width-input', state.width);
    setValue('canvas-width-unit', state.widthUnit);
    setValue('canvas-height-slider', state.height);
    setValue('canvas-height-input', state.height);
    setValue('canvas-height-unit', state.heightUnit);

    // Background
    setValue('bg-type', state.bgType);
    setValue('bg-color-picker', state.bgColor);
    setValue('bg-gradient-type', state.bgGradientType);
    setValue('bg-gradient-direction', state.bgGradientDirection);
    setValue('bg-gradient-stop1', state.bgGradientStop1);
    setValue('bg-gradient-stop2', state.bgGradientStop2);
    toggleBgControls(state.bgType);

    // Border
    setValue('border-width-slider', state.borderWidth);
    setValue('border-width-input', state.borderWidth);
    setValue('border-style', state.borderStyle);
    setValue('border-color', state.borderColor);
    
    // Radius
    setValue('radius-master-slider', state.radiusMaster);
    setValue('radius-master-input', state.radiusMaster);
    setValue('radius-tl', state.radiusTL);
    setValue('radius-tr', state.radiusTR);
    setValue('radius-br', state.radiusBR);
    setValue('radius-bl', state.radiusBL);

    // Shadow & Glow
    setValue('glow-color', state.glowColor);
    setValue('glow-blur', state.glowBlur);
    setValue('glow-spread', state.glowSpread);
    setChecked('strobe-toggle', state.strobe);
    setValue('strobe-color', state.strobeColor);
    setValue('strobe-speed', state.strobeSpeed);
    
    // Filters
    setValue('filter-blur', state.filterBlur);
    setValue('filter-blur-input', state.filterBlur);
    setValue('filter-brightness', state.filterBrightness);
    setValue('filter-brightness-input', state.filterBrightness);
    setValue('inset-shadow-color', state.insetShadowColor);
    setValue('inset-shadow-blur', state.insetShadowBlur);
    
    // Scrollbar
    setValue('scrollbar-track-color', state.scrollbarTrackColor);
    setValue('scrollbar-thumb-color', state.scrollbarThumbColor);
    setValue('scrollbar-thumb-radius-slider', state.scrollbarThumbRadius);
    setValue('scrollbar-thumb-radius-input', state.scrollbarThumbRadius);
}

function updateComponentControlsFromState() {
    if (!selectedComponentId) return;
    const state = projects[activeProjectId];
    const comp = state.components.find(c => c.id === selectedComponentId);
    if (!comp) return;

    switch(comp.type) {
        case 'text':
            setValue('text-content-input', comp.content);
            setValue('text-color-input', comp.style.color);
            setValue('text-size-input', parseInt(comp.style.fontSize));
            setValue('text-font-input', comp.style.fontFamily);
            setValue('text-glow-color', comp.style.glowColor);
            setValue('text-glow-blur', parseInt(comp.style.glowBlur));
            document.getElementById('selected-comp-name-text').textContent = comp.id;
            break;
        case 'button':
            setValue('button-text-input', comp.content);
            document.getElementById('selected-comp-name-button').textContent = comp.id;
            break;
        case 'input':
             setValue('input-placeholder-input', comp.content);
             document.getElementById('selected-comp-name-input').textContent = comp.id;
            break;
        // No controls for 'overflow' component
    }
}

function renderCanvasFromState() {
    const state = projects[activeProjectId];
    const { css, animationCss } = generateCSS(state);
    
    // Inject styles
    dom.dynamicStyles.textContent = css + '\n' + animationCss;
    
    // Generate HTML
    const html = generateHTML(state);
    dom.renderArea.innerHTML = html;
    
    // Re-bind listeners
    dom.renderArea.querySelectorAll('.draggable-component').forEach(el => {
        el.addEventListener('mousedown', onComponentMouseDown);
    });
}

function renderCodeEditorsFromState() {
    const state = projects[activeProjectId];
    const { css, animationCss } = generateCSS(state);
    const html = generateHTML(state, true); // True for clean export
    const js = `// JavaScript for interactions (e.g., close button)\ndocument.addEventListener('DOMContentLoaded', () => {\n  // Add menu interaction logic here\n});`;

    htmlEditor.setValue(html);
    cssEditor.setValue(css + '\n' + animationCss);
    jsEditor.setValue(js);
}

// --- HTML/CSS GENERATORS ---
function generateCSS(state) {
    const canvas = state.canvas;
    const canvasId = `#${state.id}`;
    let css = '';
    let animationCss = '';

    // Canvas Styling
    css += `${canvasId} {\n`;
    css += `  position: relative;\n`; // Needed for absolute components
    css += `  width: ${canvas.width}${canvas.widthUnit};\n`;
    css += `  height: ${canvas.height}${canvas.heightUnit};\n`;
    css += `  overflow: auto;\n`;
    
    // Background
    if (canvas.bgType === 'solid') {
        css += `  background-color: ${canvas.bgColor};\n`;
    } else {
        css += `  background-image: ${canvas.bgGradientType}(${canvas.bgGradientType === 'linear-gradient' ? canvas.bgGradientDirection + ', ' : ''}${canvas.bgGradientStop1}, ${canvas.bgGradientStop2});\n`;
    }
    
    // Border
    css += `  border: ${canvas.borderWidth}px ${canvas.borderStyle} ${canvas.borderColor};\n`;
    
    // Radius
    if (canvas.radiusTL || canvas.radiusTR || canvas.radiusBR || canvas.radiusBL) {
        css += `  border-radius: ${canvas.radiusTL || canvas.radiusMaster}px ${canvas.radiusTR || canvas.radiusMaster}px ${canvas.radiusBR || canvas.radiusMaster}px ${canvas.radiusBL || canvas.radiusMaster}px;\n`;
    } else {
        css += `  border-radius: ${canvas.radiusMaster}px;\n`;
    }
    
    // Filters
    css += `  backdrop-filter: blur(${canvas.filterBlur}px) brightness(${canvas.filterBrightness}%);\n`;
    css += `  -webkit-backdrop-filter: blur(${canvas.filterBlur}px) brightness(${canvas.filterBrightness}%);\n`;
    
    // Shadow & Glow
    let boxShadows = [];
    boxShadows.push(`0 0 ${canvas.glowBlur}px ${canvas.glowSpread}px ${canvas.glowColor}`);
    boxShadows.push(`inset 0 0 ${canvas.insetShadowBlur}px ${canvas.insetShadowColor}`);
    css += `  box-shadow: ${boxShadows.join(', ')};\n`;
    
    // Strobe
    if (canvas.strobe) {
        css += `  animation: strobe-effect ${canvas.strobeSpeed}ms infinite alternate;\n`;
        animationCss = `
@keyframes strobe-effect {
  from {
    box-shadow: 0 0 ${canvas.glowBlur}px ${canvas.glowSpread}px ${canvas.glowColor},
                inset 0 0 ${canvas.insetShadowBlur}px ${canvas.insetShadowColor};
  }
  to {
    box-shadow: 0 0 ${canvas.glowBlur * 1.5}px ${canvas.glowSpread + 2}px ${canvas.strobeColor},
                inset 0 0 ${canvas.insetShadowBlur}px ${canvas.insetShadowColor};
  }
}`;
    }
    css += `}\n\n`;

    // Scrollbar Styling
    css += `
${canvasId}::-webkit-scrollbar {
  width: 10px;
}
${canvasId}::-webkit-scrollbar-track {
  background: ${canvas.scrollbarTrackColor};
  border-radius: ${canvas.scrollbarThumbRadius}px;
}
${canvasId}::-webkit-scrollbar-thumb {
  background-color: ${canvas.scrollbarThumbColor};
  border-radius: ${canvas.scrollbarThumbRadius}px;
  border: 2px solid ${canvas.scrollbarTrackColor};
}
${canvasId}::-webkit-scrollbar-thumb:hover {
  background-color: ${varyColor(canvas.scrollbarThumbColor, 20)};
}
\n`;
    
    // Component Styling
    state.components.forEach(comp => {
        const compId = `#${comp.id}`;
        css += `${compId} {\n`;
        css += `  position: absolute;\n`;
        css += `  box-sizing: border-box;\n`;
        css += `  left: ${comp.x}px;\n`;
        css += `  top: ${comp.y}px;\n`;
        css += `  width: ${comp.w}px;\n`;
        css += `  height: ${comp.h}px;\n`;
        
        switch(comp.type) {
            case 'text':
                css += `  color: ${comp.style.color};\n`;
                css += `  font-size: ${comp.style.fontSize};\n`;
                css += `  font-family: ${comp.style.fontFamily};\n`;
                css += `  text-shadow: 0 0 ${comp.style.glowBlur} ${comp.style.glowColor};\n`;
                break;
            case 'button':
                css += `  background: ${comp.style.background};\n`;
                css += `  border: ${comp.style.border};\n`;
                css += `  color: ${comp.style.color};\n`;
                css += `  border-radius: ${comp.style.borderRadius};\n`;
                css += `  cursor: pointer;\n`;
                break;
            case 'input':
                css += `  background: ${comp.style.background};\n`;
                css += `  border: ${comp.style.border};\n`;
                css += `  color: ${comp.style.color};\n`;
                css += `  border-radius: ${comp.style.borderRadius};\n`;
                css += `  padding: ${comp.style.padding};\n`;
                break;
            case 'overflow':
                css += `  background: ${comp.style.background};\n`;
                css += `  color: ${comp.style.color};\n`;
                css += `  padding: ${comp.style.padding};\n`;
                css += `  overflow: auto; \n`; // Make this component scrollable
                break;
        }
        css += `}\n\n`;
    });
    
    return { css, animationCss };
}

function generateHTML(state, forExport = false) {
    let html = `<div id="${state.id}" class="rendered-menu-canvas">\n`;
    
    state.components.forEach(comp => {
        let compHtml = '';
        const baseAttrs = `id="${comp.id}" class="draggable-component ${!forExport && comp.id === selectedComponentId ? 'selected-component' : ''}" data-id="${comp.id}" data-type="${comp.type}"`;
        
        switch(comp.type) {
            case 'text':
                compHtml = `  <div ${baseAttrs}>${comp.content}</div>`;
                break;
            case 'button':
                compHtml = `  <button ${baseAttrs}>${comp.content}</button>`;
                break;
            case 'input':
                compHtml = `  <input type="text" ${baseAttrs} placeholder="${comp.content}">`;
                break;
            case 'overflow':
                compHtml = `  <div ${baseAttrs}>${comp.content}</div>`;
                break;
        }
        
        if (!forExport && comp.id === selectedComponentId) {
            compHtml += `
    <div class="resize-handle tl" data-handle="tl"></div>
    <div class="resize-handle tr" data-handle="tr"></div>
    <div class="resize-handle bl" data-handle="bl"></div>
    <div class="resize-handle br" data-handle="br"></div>
  `;
        }
        html += `  ${compHtml}\n`;
    });
    
    html += `</div>`;
    return html;
}

// --- EVENT HANDLERS ---
function setupEventListeners() {
    // Main Controls
    dom.controlCenter.addEventListener('input', handleControlChange);
    dom.controlCenter.addEventListener('change', handleControlChange);
    
    // Add Project
    dom.addProjectTab.addEventListener('click', createNewProject);

    // Add Components
    dom.addTextBtn.addEventListener('click', () => addComponent('text'));
    dom.addButtonBtn.addEventListener('click', () => addComponent('button'));
    dom.addInputBtn.addEventListener('click', () => addComponent('input'));
    dom.addOverflowBtn.addEventListener('click', () => addComponent('overflow'));

    // Code Editor Tabs
    dom.codeTabs.addEventListener('click', (e) => {
        if (e.target.tagName !== 'BUTTON') return;
        const tabName = e.target.dataset.tab;
        
        dom.codeTabs.querySelectorAll('.code-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === tabName);
        });
        
        document.querySelectorAll('.code-block').forEach(block => {
            block.classList.toggle('active', block.id.startsWith(tabName));
        });
    });

    // Utility Buttons
    dom.copyCodeBtn.addEventListener('click', () => {
        const activeTab = dom.codeTabs.querySelector('.active').dataset.tab;
        let code;
        if (activeTab === 'html') code = htmlEditor.getValue();
        if (activeTab === 'css') code = cssEditor.getValue();
        if (activeTab === 'js') code = jsEditor.getValue();
        
        navigator.clipboard.writeText(code).then(() => {
            showToast('Code copied to clipboard!');
        });
    });
    
    dom.applyCodeBtn.addEventListener('click', () => {
         showToast('Live code application is a premium feature. Use controls for real-time updates.');
    });
    
    dom.cloneSettingsBtn.addEventListener('click', () => {
        const state = projects[activeProjectId];
        navigator.clipboard.writeText(JSON.stringify(state, null, 2)).then(() => {
            showToast('Menu JSON settings copied!');
        });
    });
    
    dom.newFromClipboardBtn.addEventListener('click', async () => {
        try {
            const text = await navigator.clipboard.readText();
            const state = JSON.parse(text);
            
            const newId = `project-${Date.now()}`;
            const newName = state.name ? `${state.name} (Copy)` : `Menu ${Object.keys(projects).length + 1}`;
            
            state.id = newId;
            state.name = newName;
            
            projects[newId] = state;
            setActiveProject(newId);
            showToast('New menu created from clipboard!');
        } catch (err) {
            console.error('Failed to parse clipboard:', err);
            showToast('Error: Clipboard does not contain valid menu JSON.', 'error');
        }
    });
    
    dom.exportPngBtn.addEventListener('click', () => {
        const menuElement = document.getElementById(activeProjectId);
        if (!menuElement) return;
        
        showToast('Generating PNG...');
        
        html2canvas(menuElement, {
            backgroundColor: null,
            logging: false,
            useCORS: true
        }).then(canvas => {
            const imgData = canvas.toDataURL('image/png');
            const link = document.createElement('a');
            link.download = `${projects[activeProjectId].name}.png`;
            link.href = imgData;
            link.click();
        });
    });
    
    dom.randomizeBtn.addEventListener('click', () => {
        randomizeState();
        showToast('Design Randomized!');
    });
    
    // Deselect component
    dom.mainCanvasArea.addEventListener('click', (e) => {
        if (e.target === dom.renderArea || e.target === dom.mainCanvasArea) {
            selectedComponentId = null;
            renderCanvasFromState();
            updateComponentControlsVisibility();
        }
    });
}

function handleControlChange(e) {
    if (!activeProjectId) return;
    const state = projects[activeProjectId].canvas;
    const compState = projects[activeProjectId].components.find(c => c.id === selectedComponentId);
    
    const id = e.target.id;
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    const numValue = parseFloat(value);
    
    // Canvas Controls
    switch (id) {
        case 'canvas-width-slider':
        case 'canvas-width-input':
            state.width = numValue;
            setValue('canvas-width-slider', numValue);
            setValue('canvas-width-input', numValue);
            break;
        case 'canvas-width-unit': state.widthUnit = value; break;
        case 'canvas-height-slider':
        case 'canvas-height-input':
            state.height = numValue;
            setValue('canvas-height-slider', numValue);
            setValue('canvas-height-input', numValue);
            break;
        case 'canvas-height-unit': state.heightUnit = value; break;
        
        case 'bg-type':
            state.bgType = value;
            toggleBgControls(value);
            break;
        case 'bg-color-picker': state.bgColor = value; break;
        case 'bg-gradient-type': state.bgGradientType = value; break;
        case 'bg-gradient-direction': state.bgGradientDirection = value; break;
        case 'bg-gradient-stop1': state.bgGradientStop1 = value; break;
        case 'bg-gradient-stop2': state.bgGradientStop2 = value; break;

        case 'border-width-slider':
        case 'border-width-input':
            state.borderWidth = numValue;
            setValue('border-width-slider', numValue);
            setValue('border-width-input', numValue);
            break;
        case 'border-style': state.borderStyle = value; break;
        case 'border-color': state.borderColor = value; break;

        case 'radius-master-slider':
        case 'radius-master-input':
            state.radiusMaster = numValue;
            setValue('radius-master-slider', numValue);
            setValue('radius-master-input', numValue);
            break;
        case 'radius-tl': state.radiusTL = value; break;
        case 'radius-tr': state.radiusTR = value; break;
        case 'radius-br': state.radiusBR = value; break;
        case 'radius-bl': state.radiusBL = value; break;

        case 'glow-color': state.glowColor = value; break;
        case 'glow-blur': state.glowBlur = numValue; break;
        case 'glow-spread': state.glowSpread = numValue; break;
        case 'strobe-toggle': state.strobe = value; break;
        case 'strobe-color': state.strobeColor = value; break;
        case 'strobe-speed': state.strobeSpeed = numValue; break;

        case 'filter-blur':
        case 'filter-blur-input':
            state.filterBlur = numValue;
            setValue('filter-blur', numValue);
            setValue('filter-blur-input', numValue);
            break;
        case 'filter-brightness':
        case 'filter-brightness-input':
            state.filterBrightness = numValue;
            setValue('filter-brightness', numValue);
            setValue('filter-brightness-input', numValue);
            break;
        case 'inset-shadow-color': state.insetShadowColor = value; break;
        case 'inset-shadow-blur': state.insetShadowBlur = numValue; break;
        
        // Scrollbar
        case 'scrollbar-track-color': state.scrollbarTrackColor = value; break;
        case 'scrollbar-thumb-color': state.scrollbarThumbColor = value; break;
        case 'scrollbar-thumb-radius-slider':
        case 'scrollbar-thumb-radius-input':
            state.scrollbarThumbRadius = numValue;
            setValue('scrollbar-thumb-radius-slider', numValue);
            setValue('scrollbar-thumb-radius-input', numValue);
            break;
    }
    
    // Component Controls
    if (compState) {
        switch(id) {
            case 'text-content-input': compState.content = value; break;
            case 'text-color-input': compState.style.color = value; break;
            case 'text-size-input': compState.style.fontSize = `${numValue}px`; break;
            case 'text-font-input': compState.style.fontFamily = value; break;
            case 'text-glow-color': compState.style.glowColor = value; break;
            case 'text-glow-blur': compState.style.glowBlur = `${numValue}px`; break;
            
            case 'button-text-input': compState.content = value; break;
            case 'input-placeholder-input': compState.content = value; break;
        }
    }

    renderCanvasFromState();
    renderCodeEditorsFromState();
}

function addComponent(type) {
    if (!activeProjectId) return;
    const newComp = getDefaultComponent(type);
    projects[activeProjectId].components.push(newComp);
    selectedComponentId = newComp.id;
    renderAll();
}

function onComponentMouseDown(e) {
    e.stopPropagation();
    const target = e.target.closest('.draggable-component');
    if (!target) return;
    
    const id = target.dataset.id;
    const handle = e.target.dataset.handle;
    
    if (selectedComponentId !== id) {
        selectedComponentId = id;
        renderCanvasFromState();
        updateComponentControlsVisibility();
    }

    const rect = target.getBoundingClientRect();
    
    dragState = {
        target: target,
        componentId: id,
        startX: e.clientX,
        startY: e.clientY,
        startLeft: target.offsetLeft,
        startTop: target.offsetTop,
        startWidth: rect.width,
        startHeight: rect.height,
    };
    
    if (handle) {
        dragState.isResizing = true;
        dragState.handle = handle;
    } else {
        dragState.isDragging = true;
    }

    document.addEventListener('mousemove', onComponentMouseMove);
    document.addEventListener('mouseup', onComponentMouseUp);
}

function onComponentMouseMove(e) {
    if (!dragState.isDragging && !dragState.isResizing) return;
    e.preventDefault();

    const dx = e.clientX - dragState.startX;
    const dy = e.clientY - dragState.startY;
    
    const comp = projects[activeProjectId].components.find(c => c.id === dragState.componentId);
    
    if (dragState.isDragging) {
        comp.x = dragState.startLeft + dx;
        comp.y = dragState.startTop + dy;
        dragState.target.style.left = `${comp.x}px`;
        dragState.target.style.top = `${comp.y}px`;
        
    } else if (dragState.isResizing) {
        if (dragState.handle.includes('r')) comp.w = dragState.startWidth + dx;
        if (dragState.handle.includes('l')) {
            comp.w = dragState.startWidth - dx;
            comp.x = dragState.startLeft + dx;
        }
        if (dragState.handle.includes('b')) comp.h = dragState.startHeight + dy;
        if (dragState.handle.includes('t')) {
            comp.h = dragState.startHeight - dy;
            comp.y = dragState.startTop + dy;
        }
        dragState.target.style.width = `${comp.w}px`;
        dragState.target.style.height = `${comp.h}px`;
        dragState.target.style.left = `${comp.x}px`;
        dragState.target.style.top = `${comp.y}px`;
    }
}

function onComponentMouseUp(e) {
    if (dragState.isDragging || dragState.isResizing) {
        const comp = projects[activeProjectId].components.find(c => c.id === dragState.componentId);
        comp.x = parseInt(dragState.target.style.left);
        comp.y = parseInt(dragState.target.style.top);
        comp.w = parseInt(dragState.target.style.width);
        comp.h = parseInt(dragState.target.style.height);
        
        renderCodeEditorsFromState();
    }
    
    dragState = { isDragging: false, isResizing: false };
    document.removeEventListener('mousemove', onComponentMouseMove);
    document.removeEventListener('mouseup', onComponentMouseUp);
}

function updateComponentControlsVisibility() {
    dom.textControls.classList.add('hidden-controls');
    dom.buttonControls.classList.add('hidden-controls');
    dom.inputControls.classList.add('hidden-controls');
    
    if (!selectedComponentId) return;
    
    const comp = projects[activeProjectId].components.find(c => c.id === selectedComponentId);
    if (!comp) return;
    
    switch (comp.type) {
        case 'text':
            dom.textControls.classList.remove('hidden-controls');
            break;
        case 'button':
            dom.buttonControls.classList.remove('hidden-controls');
            break;
        case 'input':
            dom.inputControls.classList.remove('hidden-controls');
            break;
    }
    updateComponentControlsFromState();
}

function toggleBgControls(bgType) {
    if (bgType === 'solid') {
        document.getElementById('bg-solid-controls').classList.remove('hidden-controls');
        document.getElementById('bg-gradient-controls').classList.add('hidden-controls');
    } else {
        document.getElementById('bg-solid-controls').classList.add('hidden-controls');
        document.getElementById('bg-gradient-controls').classList.remove('hidden-controls');
    }
}

// --- Panel Resizing ---
function initResizing() {
    dom.resizerH.addEventListener('mousedown', (e) => {
        e.preventDefault();
        document.addEventListener('mousemove', resizeH);
        document.addEventListener('mouseup', stopResizeH);
    });
    
    dom.resizerV.addEventListener('mousedown', (e) => {
        e.preventDefault();
        document.addEventListener('mousemove', resizeV);
        document.addEventListener('mouseup', stopResizeV);
    });

    function resizeH(e) {
        const newLeftWidth = e.clientX;
        if (newLeftWidth > 300 && newLeftWidth < 800) {
            dom.app.style.gridTemplateColumns = `${newLeftWidth}px 1fr`;
        }
    }
    function stopResizeH() {
        document.removeEventListener('mousemove', resizeH);
        document.removeEventListener('mouseup', stopResizeH);
    }
    
    function resizeV(e) {
        const newTopHeight = e.clientY - dom.leftPanel.offsetTop;
         if (newTopHeight > 200 && newTopHeight < dom.leftPanel.clientHeight - 200) {
            dom.controlCenter.style.height = `${newTopHeight}px`;
            dom.controlCenter.style.flexBasis = `${newTopHeight}px`;
            dom.codeRepository.style.height = `calc(100% - ${newTopHeight}px - 8px)`;
            dom.codeRepository.style.flexBasis = `calc(100% - ${newTopHeight}px - 8px)`;
        }
    }
    function stopResizeV() {
        document.removeEventListener('mousemove', resizeV);
        document.removeEventListener('mouseup', stopResizeV);
    }
}

// --- UTILITY FUNCTIONS ---
function loadTemplate(templateName) {
    let id, name, components;
    id = `project-${Date.now()}`;
    
    if (templateName === 'cyber-luxe-default') {
        name = 'Cyber-Luxe Menu';
        components = [
            {
                id: `comp-${Date.now()}`,
                type: 'text',
                x: 20,
                y: 20,
                w: 360,
                h: 40,
                content: 'Cyber-Luxe Menu',
                style: {
                    color: '#00ffff',
                    fontSize: '24px',
                    fontFamily: "'Orbitron', sans-serif",
                    glowColor: '#00ffff',
                    glowBlur: '8px'
                }
            },
            {
                id: `comp-${Date.now()+1}`,
                type: 'button',
                x: 140,
                y: 440,
                w: 120,
                h: 40,
                content: 'Login',
                style: { background: 'transparent', border: '1px solid #00ffff', color: '#00ffff', borderRadius: '8px' }
            }
        ];
    } else {
        name = 'New Menu';
        components = [];
    }
    
    projects[id] = getDefaultProjectState(id, name, components);
    setActiveProject(id);
}

function initializeColorPickers() {
    // This assumes vanilla-picker and tinycolor are loaded
    const inputs = document.querySelectorAll('.color-picker-input');
    inputs.forEach(input => {
        const picker = new Picker({
            parent: input.parentElement,
            popup: 'right',
            color: input.value,
            alpha: true,
            editor: false,
            onChange: (color) => {
                const newColor = color.rgbaString;
                input.value = newColor;
                input.style.setProperty('--color-preview', newColor);
                // Manually trigger the input event
                input.dispatchEvent(new Event('input', { bubbles: true }));
            }
        });
        input.style.setProperty('--color-preview', input.value);
    });
}

function setValue(id, value) {
    const el = document.getElementById(id);
    if (el) {
        el.value = value;
        if (el.type === 'color') {
             el.style.setProperty('--color-preview', value);
        }
    }
}

function getValue(id) {
    const el = document.getElementById(id);
    return el ? el.value : null;
}

function setChecked(id, checked) {
    const el = document.getElementById(id);
    if (el) el.checked = checked;
}

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}

function varyColor(hex, amount) {
    // This assumes tinycolor.js is loaded
    if (typeof tinycolor === 'undefined') return hex;
    return tinycolor(hex).lighten(amount).toString();
}

function getRandom(min, max, int = false) {
    const val = Math.random() * (max - min) + min;
    return int ? Math.floor(val) : val;
}

function getRandomColor(alpha = false) {
    const r = getRandom(0, 255, true);
    const g = getRandom(0, 255, true);
    const b = getRandom(0, 255, true);
    if (alpha) {
        return `rgba(${r}, ${g}, ${b}, ${getRandom(0.5, 1).toFixed(2)})`;
    }
    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
}

function getRandomFont() {
    const fonts = ["'Orbitron', sans-serif", "'Rajdhani', sans-serif", "'Inter', sans-serif", "'Courier New', monospace", "Arial, sans-serif"];
    return fonts[getRandom(0, fonts.length, true)];
}

function randomizeState() {
    if (!activeProjectId) return;
    const state = projects[activeProjectId].canvas;
    
    state.bgType = getRandom(0, 1) > 0.5 ? 'solid' : 'gradient';
    state.bgColor = getRandomColor();
    state.bgGradientStop1 = getRandomColor();
    state.bgGradientStop2 = getRandomColor();
    state.borderWidth = getRandom(0, 5, true);
    state.borderColor = getRandomColor(true);
    state.radiusMaster = getRandom(0, 40, true);
    state.glowColor = getRandomColor(true);
    state.glowBlur = getRandom(5, 50, true);
    state.glowSpread = getRandom(0, 10, true);
    state.strobe = getRandom(0, 1) > 0.7;
    state.strobeColor = getRandomColor(true);
    state.strobeSpeed = getRandom(200, 1500, true);
    state.filterBlur = getRandom(0, 20, true);
    state.filterBrightness = getRandom(80, 120, true);
    state.scrollbarThumbColor = getRandomColor(true);
    state.scrollbarTrackColor = getRandomColor(true);

    projects[activeProjectId].components.forEach(comp => {
        if (comp.type === 'text') {
            comp.style.color = getRandomColor();
            comp.style.fontFamily = getRandomFont();
            comp.style.fontSize = `${getRandom(14, 32, true)}px`;
            comp.style.glowColor = getRandomColor(true);
            comp.style.glowBlur = `${getRandom(0, 15, true)}px`;
        }
    });

    renderAll();
}

