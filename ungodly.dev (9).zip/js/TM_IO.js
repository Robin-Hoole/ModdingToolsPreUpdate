/**
 * NF_IO.js
 * Import / Export data pipeline routines. 
 * Includes advanced collision detection for node merging and parsing logic from the user's master file.
 */

function parseImportData(data, type, filename) {
    const safeAdd = (arr, item) => {
        let exists = false;
        
        // Ensure ID exists before comparing. Default generated arrays might not have them natively until saved.
        if (item.id) {
            exists = arr.some(x => x.id === item.id);
        } else {
            // Only fallback to name matching if NO UUID exists (Legacy files)
            let nameField = item.title || item.name || item.text || "Unnamed";
            exists = arr.some(x => (x.title || x.name || x.text) === nameField);
        }
        
        if (exists) {
            let nameField = item.title || item.name || item.text || "Unnamed";
            if(confirm(`Collision detected for "${nameField}" (ID Match) in ${type}. Overwrite existing? (Cancel will Append New)`)) {
                let idx = item.id ? arr.findIndex(x => x.id === item.id) : arr.findIndex(x => (x.title || x.name || x.text) === nameField);
                if (idx !== -1) arr[idx] = {...item, _sourceFile: filename};
            } else {
                // If Cancel, generate a fresh ID to ensure it doesn't immediately collide internally
                let newItem = {...item, _sourceFile: filename};
                newItem.id = generateUUID();
                arr.push(newItem);
            }
        } else {
            arr.push({...item, _sourceFile: filename});
        }
    };

    try {
        if (type === 'dialogue') {
            const convos = data.conversations || [];
            const seqs = data.sequences || [];
            convos.forEach(c => safeAdd(sourceData.dialogues, c));
            seqs.forEach(s => safeAdd(sourceData.sequences, s));
            convos.forEach(c => {
                if(c.activeLogicVariables && Array.isArray(c.activeLogicVariables)) {
                    c.activeLogicVariables.forEach(v => { sourceData.importedLogic.push({ key: v, usageClassification: 'Mixed Usage', _sourceFile: filename }); });
                }
            });
        } else if (type === 'task') {
            if (data.tabColors) globalTaskTabColors = {...globalTaskTabColors, ...data.tabColors};
            const tasks = Array.isArray(data) ? data : (data.entries || []);
            tasks.forEach(t => safeAdd(sourceData.tasks, t));
        } else if (type === 'menu') {
            let menus = [];
            let menuSrc = data.menus || data.conversations;
            if (menuSrc && typeof menuSrc === 'object' && !Array.isArray(menuSrc)) {
                Object.entries(menuSrc).forEach(([groupName, characters]) => {
                    if (groupName === 'ROOT') groupName = 'GLOBAL MENUS';
                    if (typeof characters === 'object' && !Array.isArray(characters)) {
                        Object.entries(characters).forEach(([charName, options]) => {
                            if (Array.isArray(options)) {
                                options.forEach(opt => {
                                    menus.push({ ...opt, groupName, characterName: charName });
                                    if (opt.subMenuOptions && Array.isArray(opt.subMenuOptions)) opt.subMenuOptions.forEach(sub => menus.push({ ...sub, groupName: groupName + ' (Sub)', characterName: charName }));
                                });
                            }
                        });
                    } else if (Array.isArray(characters)) {
                        characters.forEach(opt => menus.push({ ...opt, groupName, characterName: 'General' }));
                    }
                });
            } else if (data.menus?.ROOT) {
                Object.entries(data.menus).forEach(([groupName, options]) => {
                    if (Array.isArray(options)) options.forEach(opt => menus.push({ ...opt, groupName: groupName === 'ROOT' ? 'GLOBAL MENUS' : groupName, characterName: 'General' }));
                });
            } else if (Array.isArray(data.options)) {
                 menus = data.options.map(opt => ({...opt, groupName: 'GLOBAL MENUS', characterName: 'General'}));
            } else if (Array.isArray(data)) {
                 menus = data.map(opt => ({...opt, groupName: 'GLOBAL MENUS', characterName: 'General'}));
            }
            menus.forEach(m => safeAdd(sourceData.menus, m));
        } else if (type === 'prompt') {
            if (data.tags) data.tags.forEach(t => globalPromptTagColors[t.name] = t.color);
            const prompts = data.prompts || [];
            prompts.forEach(p => safeAdd(sourceData.prompts, p));
        }
    } catch(err) { console.error("Error extracting array data:", err); }

    try {
        if (data["Active Project Logic"] && Array.isArray(data["Active Project Logic"])) {
            data["Active Project Logic"].forEach(item => sourceData.importedLogic.push({...item, _sourceFile: filename}));
        }
        if (data["Gameplay Values"] && Array.isArray(data["Gameplay Values"])) {
            data["Gameplay Values"].forEach(item => sourceData.importedGameplayValues.push({...item, _sourceFile: filename}));
        }
    } catch(err) { console.error("Error extracting logic registry:", err); }
}

function importFile(e, type) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
        try {
            const data = JSON.parse(evt.target.result);
            parseImportData(data, type, file.name);
            updateProjectLogic();
            
            if (type === 'dialogue') setLeftTab('convo');
            else setLeftTab(type);
            
            renderAvailableList();
            if(rightTab === 'logic') renderLogicPanel();
            showNotification(`Imported ${type} from ${file.name}`);
        } catch(err) {
            console.error("Import Error", err);
            showNotification("Error parsing JSON: " + err.message, true);
        }
    };
    reader.readAsText(file);
    e.target.value = '';
}

function importDialogueFile(e) { importFile(e, 'dialogue'); }
function importTaskFile(e) { importFile(e, 'task'); }
function importMenuFile(e) { importFile(e, 'menu'); }
function importPromptFile(e) { importFile(e, 'prompt'); }


function nfEnsureArray(value) {
    return Array.isArray(value) ? value : [];
}

function nfNormalizeToolLogicArray(value) {
    return nfEnsureArray(value).map(entry => ({
        key: entry && (entry.key ?? entry.variable) !== undefined ? String(entry.key ?? entry.variable) : '',
        op: entry && (entry.op ?? entry.operator) !== undefined ? String(entry.op ?? entry.operator) : '==',
        val: entry && (entry.val ?? entry.value) !== undefined ? String(entry.val ?? entry.value) : ''
    }));
}

function nfNormalizeToolingData(rawToolingData) {
    const raw = rawToolingData && typeof rawToolingData === 'object' ? rawToolingData : {};
    if (raw.transitionLibrary && !raw.transitions) raw.transitions = raw.transitionLibrary;
    const normalized = {
        transitionSections: nfEnsureArray(raw.transitionSections),
        transitions: nfEnsureArray(raw.transitions),
        imageNodeSections: nfEnsureArray(raw.imageNodeSections),
        imageNodes: nfEnsureArray(raw.imageNodes),
        imageDbSections: nfEnsureArray(raw.imageDbSections),
        imageDbItems: nfEnsureArray(raw.imageDbItems),
        convSeqSections: nfEnsureArray(raw.convSeqSections),
        convSeqs: nfEnsureArray(raw.convSeqs),
        puppetSeqSections: nfEnsureArray(raw.puppetSeqSections),
        puppetSeqs: nfEnsureArray(raw.puppetSeqs)
    };

    const normalizeSection = (section, prefix) => ({
        id: section && section.id ? String(section.id) : `${prefix}-section-${generateUUID()}`,
        name: section && section.name ? String(section.name) : 'Uncategorized',
        path: section && section.path ? String(section.path) : 'Assets/Resources/'
    });

    normalized.transitionSections = normalized.transitionSections.map(s => normalizeSection(s, 'trans'));
    normalized.imageNodeSections = normalized.imageNodeSections.map(s => normalizeSection(s, 'imgnode'));
    normalized.imageDbSections = normalized.imageDbSections.map(s => normalizeSection(s, 'imgdb'));
    normalized.convSeqSections = normalized.convSeqSections.map(s => normalizeSection(s, 'convseq'));
    normalized.puppetSeqSections = normalized.puppetSeqSections.map(s => normalizeSection(s, 'puppetseq'));

    const ensureSection = (sectionArray, prefix, displayName) => {
        if (sectionArray.length === 0) sectionArray.push({ id: `${prefix}-default-${generateUUID()}`, name: displayName, path: 'Assets/Resources/' });
        return sectionArray[0].id;
    };

    const defaultTransSection = ensureSection(normalized.transitionSections, 'trans', 'Transitions');
    const defaultImageNodeSection = ensureSection(normalized.imageNodeSections, 'imgnode', 'Image Nodes');
    const defaultImageDbSection = ensureSection(normalized.imageDbSections, 'imgdb', 'Image Database');
    const defaultConvSeqSection = ensureSection(normalized.convSeqSections, 'convseq', 'Conversation Sequences');
    const defaultPuppetSeqSection = ensureSection(normalized.puppetSeqSections, 'puppetseq', 'Puppet Sequences');

    const normalizeTextFormat = (format) => ({
        bold: !!(format && format.bold),
        italic: !!(format && format.italic),
        underline: !!(format && format.underline),
        strikethrough: !!(format && format.strikethrough),
        listStyle: format && ['none', 'bullet', 'number'].includes(format.listStyle) ? format.listStyle : 'none',
        alignH: format && ['left', 'center', 'right'].includes(format.alignH) ? format.alignH : 'left',
        alignV: format && ['top', 'middle', 'bottom'].includes(format.alignV) ? format.alignV : 'top'
    });

    const normalizeCommonItem = (item, prefix, defaultSectionId) => {
        const src = item && typeof item === 'object' ? item : {};
        const title = src.title ?? src.name ?? 'Untitled';
        return {
            ...src,
            id: src.id ? String(src.id) : `${prefix}-${generateUUID()}`,
            title: String(title),
            name: String(src.name ?? title),
            sectionId: src.sectionId ? String(src.sectionId) : defaultSectionId,
            color: src.color || getRandomHex(),
            isCollapsed: !!src.isCollapsed,
            conditions: nfNormalizeToolLogicArray(src.conditions),
            stateChanges: nfNormalizeToolLogicArray(src.stateChanges),
            isExternallyCalled: !!src.isExternallyCalled,
            makeExternalCall: !!src.makeExternalCall
        };
    };

    normalized.transitions = normalized.transitions.map(item => {
        const common = normalizeCommonItem(item, 'trans', defaultTransSection);
        return {
            ...common,
            pauseTime: Number.isFinite(Number(common.pauseTime)) ? Number(common.pauseTime) : 5,
            bodyText: common.bodyText !== undefined && common.bodyText !== null ? String(common.bodyText) : '',
            useImage: !!common.useImage,
            imageId: common.imageId ? String(common.imageId) : '',
            titleTextFormat: normalizeTextFormat(common.titleTextFormat),
            bodyTextFormat: normalizeTextFormat(common.bodyTextFormat),
            translations: common.translations && typeof common.translations === 'object' ? common.translations : { ENG: { title: common.title, bodyText: common.bodyText || '' } }
        };
    });

    normalized.imageNodes = normalized.imageNodes.map(item => {
        const common = normalizeCommonItem(item, 'imgnode', defaultImageNodeSection);
        return {
            ...common,
            imageId: common.imageId ? String(common.imageId) : '',
            shownFor: Number.isFinite(Number(common.shownFor)) ? Number(common.shownFor) : 5,
            useTitle: !!common.useTitle,
            useBody: !!common.useBody,
            bodyText: common.bodyText !== undefined && common.bodyText !== null ? String(common.bodyText) : '',
            titleTextFormat: normalizeTextFormat(common.titleTextFormat),
            bodyTextFormat: normalizeTextFormat(common.bodyTextFormat),
            translations: common.translations && typeof common.translations === 'object' ? common.translations : { ENG: { title: common.title, bodyText: common.bodyText || '' } }
        };
    });

    const normalizeSimpleItem = (item, prefix, defaultSectionId) => {
        const common = normalizeCommonItem(item, prefix, defaultSectionId);
        return { ...common, name: String(common.name || common.title), title: String(common.title || common.name) };
    };

    normalized.imageDbItems = normalized.imageDbItems.map(item => normalizeSimpleItem(item, 'imgdb', defaultImageDbSection));
    normalized.convSeqs = normalized.convSeqs.map(item => normalizeSimpleItem(item, 'convseq', defaultConvSeqSection));
    normalized.puppetSeqs = normalized.puppetSeqs.map(item => normalizeSimpleItem(item, 'puppetseq', defaultPuppetSeqSection));

    return normalized;
}

function nfNormalizeSourceImports(rawSourceImports) {
    const raw = rawSourceImports && typeof rawSourceImports === 'object' ? rawSourceImports : {};
    return {
        dialogues: nfEnsureArray(raw.dialogues),
        sequences: nfEnsureArray(raw.sequences),
        tasks: nfEnsureArray(raw.tasks),
        menus: nfEnsureArray(raw.menus),
        prompts: nfEnsureArray(raw.prompts),
        importedLogic: nfEnsureArray(raw.importedLogic),
        importedGameplayValues: nfEnsureArray(raw.importedGameplayValues)
    };
}

function importStoryFlowFile(event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            const hasFlowNodes = Array.isArray(data.flowNodes) || Array.isArray(data.conversations);
            const hasToolingData = data.toolingData && typeof data.toolingData === 'object';

            if (data.tabs && data.entries && !hasFlowNodes && !hasToolingData) return showNotification("This looks like a Task Manager export. Use 'Import Tasks' instead.", true);
            if (data.prompts && !hasFlowNodes && !hasToolingData) return showNotification("This looks like a Prompt export. Use 'Import Prompts' instead.", true);
            if (!hasFlowNodes && !hasToolingData) throw new Error("Missing flow node array or toolingData");

            if (data.sourceImports) sourceData = nfNormalizeSourceImports(data.sourceImports);
            else sourceData = nfNormalizeSourceImports(sourceData);

            if (data.logicRegistry) {
                startupValues = nfEnsureArray(data.logicRegistry.startupValues);
                gameEndValues = nfEnsureArray(data.logicRegistry.gameEndValues);
                if (data.logicRegistry.gameplayValues && typeof data.logicRegistry.gameplayValues === 'object') gameplayValues = { ...gameplayValues, ...data.logicRegistry.gameplayValues };
            }

            if (data.metadata && typeof data.metadata === 'object') {
                if (data.metadata.taskTabColors) globalTaskTabColors = data.metadata.taskTabColors;
                if (data.metadata.promptTagColors) globalPromptTagColors = data.metadata.promptTagColors;
                if (Array.isArray(data.metadata.flowPages) && data.metadata.flowPages.length > 0) flowPages = data.metadata.flowPages;
                if (Array.isArray(data.metadata.flowGroups)) flowGroups = data.metadata.flowGroups;
            }

            if (!Array.isArray(flowPages) || flowPages.length === 0) flowPages = [{ id: 'default', name: 'Main Flow', emoji: '🔮', desc: 'Default flow canvas.' }];
            if (!currentCanvasId || !flowPages.find(p => p.id === currentCanvasId)) currentCanvasId = flowPages[0].id || 'default';

            if (hasToolingData) toolingData = nfNormalizeToolingData(data.toolingData);
            else toolingData = nfNormalizeToolingData(toolingData);

            const srcNodes = Array.isArray(data.flowNodes) ? data.flowNodes : (Array.isArray(data.conversations) ? data.conversations : []);
            storyNodes = srcNodes.map((c, index) => {
                const safeId = c && c.id ? String(c.id) : `node_${index + 1}`;
                return {
                    id: safeId, type: c.type || 'conversation', title: c.title || c.name || safeId, sourceRef: c.sourceRef || c.title || c.name || safeId,
                    x: c.graphPos ? c.graphPos.x : (c.x || 0), y: c.graphPos ? c.graphPos.y : (c.y || 0),
                    color: c.color || getRandomColor(), chainName: c.chainName || "", chainDesc: c.chainDesc || "", chainColor: c.chainColor || "#ffd700",
                    taskType: c.taskType || 'standalone', unlockConditions: nfEnsureArray(c.unlockConditions), onComplete: nfEnsureArray(c.onComplete), nextConversations: nfEnsureArray(c.nextConversations),
                    savePoint: c.savePoint || "", isRepeatable: c.isRepeatable || false, repeatVariable: c.repeatVariable || "",
                    isTaskQuest: c.isTaskQuest !== undefined ? c.isTaskQuest : (c.type === 'task'),
                    taskUnlock: c.taskUnlock || {key:'', op:'==', val:''}, taskComplete: c.taskComplete || {key:'', op:'==', val:''},
                    taskFail: c.taskFail || {key:'', op:'==', val:''}, taskReward: c.taskReward || {key:'', op:'==', val:''},
                    canvasId: c.canvasId || 'default', snapParent: c.snapParent || null, snapChild: c.snapChild || null,
                    contextTitle: c.contextTitle || "", buttonLabel: c.buttonLabel || ""
                };
            });

            const maxId = storyNodes.reduce((acc, node) => {
                const idText = node && node.id !== undefined && node.id !== null ? String(node.id) : '';
                const num = parseInt(idText.split('_').pop(), 10);
                return isNaN(num) ? acc : Math.max(acc, num);
            }, 0);
            idCounter = maxId + 1;
            selectedNodeIds = [];
            renderFlowPages();
            renderAvailableList();
            renderToolLibrary();
            renderToolEditor();
            updateProjectLogic();
            showNotification(hasFlowNodes ? `Loaded Master Flow Data` : `Loaded Tooling Data`);
        } catch (err) {
            console.error('Story Flow Load Error', err);
            showNotification("Load Error: " + err.message, true);
        }
    };
    reader.readAsText(file);
    event.target.value = '';
}

function exportStoryFlow() {
    // Intercept toolingData to rename 'transitions' to 'transitionLibrary' for the exported JSON
    const exportToolingData = { ...toolingData };
    if (exportToolingData.transitions) {
        exportToolingData.transitionLibrary = exportToolingData.transitions;
        delete exportToolingData.transitions;
    }

    const data = {
        storyVersion: "3.0-ComplexTooling",
        sourceImports: {
            dialogues: sourceData.dialogues, sequences: sourceData.sequences, tasks: sourceData.tasks, menus: sourceData.menus,
            prompts: sourceData.prompts, importedLogic: sourceData.importedLogic, importedGameplayValues: sourceData.importedGameplayValues
        },
        logicRegistry: { startupValues, gameEndValues, gameplayValues },
        metadata: { taskTabColors: globalTaskTabColors, promptTagColors: globalPromptTagColors, flowPages: flowPages, flowGroups: flowGroups },
        toolingData: exportToolingData,
        flowNodes: storyNodes.map(n => ({
            id: n.id, type: n.type || 'conversation', title: n.title, sourceRef: n.sourceRef,
            color: n.color, chainName: n.chainName, chainDesc: n.chainDesc, chainColor: n.chainColor, taskType: n.taskType,
            unlockConditions: n.unlockConditions.filter(c => c.variable), onComplete: n.onComplete.filter(c => c.variable),
            isRepeatable: n.isRepeatable, repeatVariable: n.repeatVariable, isTaskQuest: n.isTaskQuest,
            taskUnlock: n.isTaskQuest ? n.taskUnlock : null, taskComplete: n.isTaskQuest ? n.taskComplete : null,
            taskFail: n.isTaskQuest ? n.taskFail : null, taskReward: n.isTaskQuest ? n.taskReward : null,
            nextConversations: n.nextConversations, savePoint: n.savePoint || null, canvasId: n.canvasId || 'default',
            snapParent: n.snapParent || null, snapChild: n.snapChild || null, contextTitle: n.contextTitle || "", buttonLabel: n.buttonLabel || "",
            graphPos: { x: Math.round(n.x), y: Math.round(n.y) } 
        }))
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], {type: "application/json"});
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    const now = new Date(); const pad = num => String(num).padStart(2, '0');
    a.download = `NarrativeFlow_Export_${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}.json`; 
    a.click(); showNotification("Master Flow Exported");
}

function renameToolLogic() {
    const val = document.getElementById('modal-rename-val').value.trim();
    if(!val) return;
    const oldKey = document.getElementById('modal-title').innerText.split(' (')[0];
    
    // Mutate only toolingData conditions and state changes
    toolingData.transitions.forEach(n => {
        n.conditions.forEach(c => { if(normalizeStatement(c.key, c.op, c.val) === oldKey) c.key = val; });
        n.stateChanges.forEach(c => { if(normalizeStatement(c.key, c.op, c.val) === oldKey) c.key = val; });
    });
    toolingData.imageNodes.forEach(n => {
        n.conditions.forEach(c => { if(normalizeStatement(c.key, c.op, c.val) === oldKey) c.key = val; });
        n.stateChanges.forEach(c => { if(normalizeStatement(c.key, c.op, c.val) === oldKey) c.key = val; });
    });
    
    closeTagModal();
    updateProjectLogic();
    if (activeOverTab === 'tools') renderToolEditor();
    showNotification("Renamed references locally");
}