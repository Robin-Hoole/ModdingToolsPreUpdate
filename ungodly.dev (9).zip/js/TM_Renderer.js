// TM_Renderer.js - DOM Manipulation and Rendering

let savedFocusId = null;
let savedSelectionStart = null;
let savedSelectionEnd = null;

function saveFocus() {
    const el = document.activeElement;
    if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT')) {
        savedFocusId = el.id;
        try {
            savedSelectionStart = el.selectionStart;
            savedSelectionEnd = el.selectionEnd;
        } catch(e) {}
    } else {
        savedFocusId = null;
    }
}

function restoreFocus() {
    if (savedFocusId) {
        setTimeout(() => {
            const el = document.getElementById(savedFocusId);
            if (el) {
                el.focus();
                try { el.setSelectionRange(savedSelectionStart, savedSelectionEnd); } catch(e) {}
            }
        }, 0);
    }
}

function showNotification(text, isError = false) {
    const notif = document.getElementById('notification');
    notif.innerText = text;
    if (isError) notif.classList.add('error'); else notif.classList.remove('error');
    notif.classList.add('show');
    setTimeout(() => notif.classList.remove('show'), 3000);
}

function showNavPopup(text) {
    const popup = document.getElementById('nav-popup');
    popup.innerText = text;
    popup.style.opacity = '1';
    clearTimeout(navPopupTimer);
    navPopupTimer = setTimeout(() => {
        popup.style.opacity = '0';
    }, 800);
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

const getRandomColor = () => {
    const letters = '6789ABCDEF'; let color = '#';
    for (let i = 0; i < 6; i++) color += letters[Math.floor(Math.random() * letters.length)];
    return color;
};

function setRandomColor() {
    const color = getRandomColor();
    const taskColorInput = document.getElementById('taskColor');
    const taskColorDisplay = document.getElementById('taskColorDisplay');
    if (taskColorInput && taskColorDisplay) {
        taskColorInput.value = color;
        taskColorDisplay.innerText = color;
        taskColorDisplay.style.color = color;
    }
}

function setChainColor(color) {
    const hex = color || '#FFD700';
    const chainColorInput = document.getElementById('chainColor');
    if (chainColorInput) chainColorInput.value = hex;
}

function populateEmojiSelect() {
    const select = document.getElementById('chainIconSelect');
}

function populateTaskIconSelect() {
    const select = document.getElementById('taskIconSelect');
    if (!select) return;
    const EMOJIS = ['🔮','⚔️','🛡️','👑','🗝️','📜','🗺️','💎','🏆','💀','🐉','🚀','⚙️','🧪','🌿','⚡','🔥','💧','❄️','☀️','🌙','👁️','🧩','🎲','🎯'];
    EMOJIS.forEach(emoji => {
        const opt = document.createElement('option');
        opt.value = emoji; opt.innerText = emoji; select.appendChild(opt);
    });
}

function populateTabSelect() {
    const select = document.getElementById('registrySelect');
    if (!select) return;
    select.innerHTML = state.tabs.map(t => `<option value="${escapeHtml(t)}">${escapeHtml(t)}</option>`).join('');
    select.value = state.activeTab;
    document.getElementById('tabColorPicker').value = state.tabColors[state.activeTab] || '#ffffff';
}

function updateTabColor(tab, color) {
    state.tabColors[tab] = color;
    renderTabs();
}

function populateChainSelect() {
    const select = document.getElementById('chainNameSelect');
    if (!select) return;
    const chains = [...new Set(state.entries.filter(t => t.taskType === 'root' && t.chainName).map(t => t.chainName))];
    select.innerHTML = chains.length 
        ? chains.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('')
        : `<option value="">-- NO CHAINS DEFINED --</option>`;
}

function getAllLogicStrings() {
    const getStr = (k, v) => `${(k||'').trim()}:${(v||'').trim()}`;
    let states = [];
    let conds = [];
    state.entries.forEach(e => {
        if(e.stateChanges) states.push(...e.stateChanges.map(s => getStr(s.key, s.val)));
        if(e.conditions) conds.push(...e.conditions.map(c => getStr(c.key, c.val)));
        
        if(e.objectives) {
            e.objectives.forEach(obj => {
                if(obj.stateChanges) states.push(...obj.stateChanges.map(s => getStr(s.key, s.val)));
                if(obj.conditions) conds.push(...obj.conditions.map(c => getStr(c.key, c.val)));
            });
        }
    });
    return {
        states: states.filter(x => x !== ':'),
        conds: conds.filter(x => x !== ':')
    };
}

// Parent Glow isolated specifically to Parent Level Variables
function getEntryGlowClass(entry) {
    let hasRed = false; let hasBlue = false;
    const globalLogic = getAllLogicStrings();
    const getStr = (k, v) => `${(k||'').trim()}:${(v||'').trim()}`;

    let entryConds = (entry.conditions || []).map(c => getStr(c.key, c.val)).filter(x => x !== ':');
    let entryStates = (entry.stateChanges || []).map(s => getStr(s.key, s.val)).filter(x => x !== ':');

    if (entryConds.some(c => !globalLogic.states.includes(c))) hasRed = true;
    if (entryStates.some(s => !globalLogic.conds.includes(s))) hasBlue = true;

    if (entry.calledExternally) hasRed = false;
    if (entry.makeExternalCall) hasBlue = false;

    if (hasRed && hasBlue) return 'glow-purple';
    if (hasRed) return 'glow-red';
    if (hasBlue) return 'glow-blue';
    return 'glow-none';
}

function getObjectiveGlowClass(obj) {
    let hasRed = false; let hasBlue = false;
    const globalLogic = getAllLogicStrings();
    const getStr = (k, v) => `${(k||'').trim()}:${(v||'').trim()}`;

    const objConds = (obj.conditions || []).map(c => getStr(c.key, c.val)).filter(x => x !== ':');
    const objStates = (obj.stateChanges || []).map(s => getStr(s.key, s.val)).filter(x => x !== ':');

    // Conditions declared locally that lack an origin state anywhere in the ecosystem
    if (objConds.some(c => !globalLogic.states.includes(c))) hasRed = true;
    
    // State changes declared locally that are not checked/used by any condition anywhere in the ecosystem
    if (objStates.some(s => !globalLogic.conds.includes(s))) hasBlue = true;

    // Direct user-driven overrides to explicitly suppress steady glow logical alerts
    if (obj.calledExternally) hasRed = false;
    if (obj.externallyCalled) hasBlue = false;

    if (hasRed && hasBlue) return 'glow-purple';
    if (hasRed) return 'glow-red';
    if (hasBlue) return 'glow-blue';
    return 'glow-none';
}

function updateElementGlow(el, glowClass) {
    if (!el) return;
    el.classList.remove('glow-none', 'glow-red', 'glow-blue', 'glow-purple');
    if (glowClass) el.classList.add(glowClass);
}

function refreshAllGlows() {
    state.entries.forEach(entry => {
        const card = document.getElementById(`task-card-${entry.id}`);
        if (card) updateElementGlow(card, getEntryGlowClass(entry));
        
        if (entry.objectives) {
            entry.objectives.forEach((obj, i) => {
                const middleCard = document.getElementById(`objective-card-middle-${entry.id}-${i}`);
                const authorCard = document.getElementById(`objective-card-author-${entry.id}-${i}`);
                const glow = getObjectiveGlowClass(obj);
                if (middleCard) updateElementGlow(middleCard, glow);
                if (authorCard) updateElementGlow(authorCard, glow);
            });
        }
    });
}

function fullRender() {
    saveFocus();
    populateTabSelect();
    renderTabs();
    renderTasksSilently();
    recalculateTags();
    renderSidebar();
    renderMinimap();

    const entry = state.entries.find(e => e.id === state.focusedEntryId);
    if(entry) populateFormForTask(entry);
    restoreFocus();
}

function renderTabs() {
    const container = document.getElementById('tabsContainer');
    if (!container) return;
    let html = '';
    state.tabs.forEach(tab => {
        const isActive = tab === state.activeTab;
        const cColor = state.tabColors[tab] || '#555';
        html += `<div class="tab-btn ${isActive ? 'active' : ''}" style="${isActive ? `border-top-color: ${cColor}; color: ${cColor}` : ''}">
            <span class="cursor-pointer flex items-center" onclick="switchTab('${escapeHtml(tab)}')">${escapeHtml(tab)}</span>
            <button class="tab-delete-btn" onclick="deleteTab('${escapeHtml(tab)}')">✕</button>
        </div>`;
    });
    container.innerHTML = html;
}

// -----------------------------------------------------------------------------
// CORE HTML GENERATORS (HOISTED FOR SCOPE SAFETY)
// -----------------------------------------------------------------------------

function getObjectiveLabel1(type) { 
    return typeof OBJECTIVE_TYPES !== 'undefined' && OBJECTIVE_TYPES[type] ? OBJECTIVE_TYPES[type].l1 : 'Key'; 
}

function getObjectiveLabel2(type) { 
    return typeof OBJECTIVE_TYPES !== 'undefined' && OBJECTIVE_TYPES[type] ? OBJECTIVE_TYPES[type].l2 : 'N/A'; 
}

function getObjectiveLabel3(type) { 
    return typeof OBJECTIVE_TYPES !== 'undefined' && OBJECTIVE_TYPES[type] ? OBJECTIVE_TYPES[type].l3 : 'N/A'; 
}

function getObjectiveLabel4(type) { 
    return typeof OBJECTIVE_TYPES !== 'undefined' && OBJECTIVE_TYPES[type] ? OBJECTIVE_TYPES[type].l4 : 'N/A'; 
}

function renderObjectiveInputs(t, taskId, objIndex, targetIndex, isAuthor) {
    const updateFn1 = `updateObjectiveTarget('${taskId}', ${objIndex}, ${targetIndex}, 'val1', this.value)`;
    const updateFn2 = `updateObjectiveTarget('${taskId}', ${objIndex}, ${targetIndex}, 'val2', this.value)`;
    const updateFn3 = `updateObjectiveTarget('${taskId}', ${objIndex}, ${targetIndex}, 'val3', this.value)`;
    const updateFn4 = `updateObjectiveTarget('${taskId}', ${objIndex}, ${targetIndex}, 'val4', this.value)`;
    const updateDescBool = `updateObjectiveTarget('${taskId}', ${objIndex}, ${targetIndex}, 'useDesc', this.checked)`;
    const updateDescStr = `updateObjectiveTarget('${taskId}', ${objIndex}, ${targetIndex}, 'desc', this.value)`;

    const l1 = getObjectiveLabel1(t.type);
    const l2 = getObjectiveLabel2(t.type);
    const l3 = getObjectiveLabel3(t.type);
    const l4 = getObjectiveLabel4(t.type);

    const hasL2 = l2 !== 'N/A';
    const hasL3 = l3 !== 'N/A';
    const hasL4 = l4 !== 'N/A';

    let html = '';
    
    // Row 1: Val1 and Val2
    html += `<div class="flex gap-2 w-full">`;
    if (t.type === 'Complete Objective') {
        let options = '<option value="|">-- Select Target --</option>';
        state.tabs.forEach(tab => {
            const tabEntries = state.entries.filter(e => e.tab === tab && e.objectives && e.objectives.length > 0);
            if(tabEntries.length > 0) {
                tabEntries.forEach(entry => {
                    options += `<optgroup label="[${tab.toUpperCase()}] ${escapeHtml(entry.name)}">`;
                    entry.objectives.forEach(o => {
                        const valStr = `${entry.id}|${o.id}`;
                        const sel = (t.val1 === entry.id && t.val2 === o.id) ? 'selected' : '';
                        options += `<option value="${valStr}" ${sel}>${escapeHtml(o.text)}</option>`;
                    });
                    options += `</optgroup>`;
                });
            }
        });
        html += `<select id="obj-val1-${taskId}-${objIndex}-${targetIndex}" class="text-[10px] w-full bg-[#111] rounded border-[#444] text-white outline-none p-1.5 custom-scrollbar" onchange="const [tId, oId] = this.value.split('|'); if(typeof updateObjectiveTarget === 'function') { updateObjectiveTarget('${taskId}', ${objIndex}, ${targetIndex}, 'val1', tId); updateObjectiveTarget('${taskId}', ${objIndex}, ${targetIndex}, 'val2', oId); }">${options}</select>`;
    } else if (t.type === 'Complete Quest') {
        let options = '<option value="">Select Quest...</option>';
        state.tabs.forEach(tab => {
            const tabEntries = state.entries.filter(e => e.tab === tab);
            if(tabEntries.length > 0) {
                options += `<optgroup label="[ ${tab.toUpperCase()} ]">`;
                tabEntries.forEach(e => {
                    const sel = t.val1 === e.id ? 'selected' : '';
                    options += `<option value="${e.id}" ${sel}>${escapeHtml(e.name)}</option>`;
                });
                options += `</optgroup>`;
            }
        });
        html += `<select id="obj-val1-${taskId}-${objIndex}-${targetIndex}" class="text-[10px] w-full bg-[#111] rounded border-[#444] text-white outline-none p-1.5 custom-scrollbar" onchange="${updateFn1}">${options}</select>`;
        if(hasL2) {
            html += `<input type="text" id="obj-val2-${taskId}-${objIndex}-${targetIndex}" class="text-[10px] w-1/2 bg-[#111] rounded border-[#444] text-white outline-none p-1.5" value="${escapeHtml(t.val2)}" placeholder="${l2}" oninput="${updateFn2}">`;
        }
    } else {
        const w1 = hasL2 ? 'w-1/2' : 'w-full';
        html += `<input type="text" id="obj-val1-${taskId}-${objIndex}-${targetIndex}" class="text-[10px] ${w1} bg-[#111] rounded border-[#444] text-white outline-none p-1.5" value="${escapeHtml(t.val1)}" placeholder="${l1}" oninput="${updateFn1}">`;
        
        if (hasL2) {
            html += `<input type="text" id="obj-val2-${taskId}-${objIndex}-${targetIndex}" class="text-[10px] w-1/2 bg-[#111] rounded border-[#444] text-white outline-none p-1.5" value="${escapeHtml(t.val2)}" placeholder="${l2}" oninput="${updateFn2}">`;
        }
    }
    html += `</div>`;

    // Row 2: Val3 and Val4
    if (hasL3 || hasL4) {
        html += `<div class="flex gap-2 w-full mt-1">`;
        if (hasL3 && !hasL4) {
            html += `<input type="text" id="obj-val3-${taskId}-${objIndex}-${targetIndex}" class="text-[10px] w-full bg-[#111] rounded border-[#444] text-white outline-none p-1.5" value="${escapeHtml(t.val3)}" placeholder="${l3}" oninput="${updateFn3}">`;
        } else if (hasL3 && hasL4) {
            html += `<input type="text" id="obj-val3-${taskId}-${objIndex}-${targetIndex}" class="text-[10px] w-1/2 bg-[#111] rounded border-[#444] text-white outline-none p-1.5" value="${escapeHtml(t.val3)}" placeholder="${l3}" oninput="${updateFn3}">`;
            html += `<input type="text" id="obj-val4-${taskId}-${objIndex}-${targetIndex}" class="text-[10px] w-1/2 bg-[#111] rounded border-[#444] text-white outline-none p-1.5" value="${escapeHtml(t.val4)}" placeholder="${l4}" oninput="${updateFn4}">`;
        } else if (!hasL3 && hasL4) {
            html += `<div class="w-1/2"></div>`;
            html += `<input type="text" id="obj-val4-${taskId}-${objIndex}-${targetIndex}" class="text-[10px] w-1/2 bg-[#111] rounded border-[#444] text-white outline-none p-1.5" value="${escapeHtml(t.val4)}" placeholder="${l4}" oninput="${updateFn4}">`;
        }
        html += `</div>`;
    }

    // Row 3: Description Toggle & Field
    html += `<div class="flex items-center gap-2 mt-1 w-full">`;
    html += `<label class="checkbox-label-small flex-shrink-0 text-[9px] text-[var(--accent-teal)]"><input type="checkbox" ${t.useDesc ? 'checked' : ''} onchange="${updateDescBool}"> USE DESCRIPTION?</label>`;
    if (t.useDesc) {
        html += `<input type="text" id="obj-desc-${taskId}-${objIndex}-${targetIndex}" class="text-[10px] flex-1 bg-[#0a0a0a] rounded border-[#444] text-white outline-none p-1.5 focus:border-[var(--accent-teal)]" value="${escapeHtml(t.desc||'')}" placeholder="Task Description..." oninput="${updateDescStr}">`;
    }
    html += `</div>`;

    return html;
}

function tmIsObjectiveSoftInvalid(c) {
    if (!c) return false;
    if (!c.text || c.text.toString().trim() === '') return true;
    const targets = Array.isArray(c.targets) ? c.targets : [];
    if (targets.length === 0) return true;
    return targets.some(t => {
        if (!t.val1 || t.val1.toString().trim() === '') return true;
        if (typeof OBJECTIVE_TYPES !== 'undefined' && OBJECTIVE_TYPES[t.type]) {
            if (OBJECTIVE_TYPES[t.type].l2 !== 'N/A' && (!t.val2 || t.val2.toString().trim() === '')) return true;
            if (OBJECTIVE_TYPES[t.type].l3 !== 'N/A' && (!t.val3 || t.val3.toString().trim() === '')) return true;
            if (OBJECTIVE_TYPES[t.type].l4 !== 'N/A' && (!t.val4 || t.val4.toString().trim() === '')) return true;
        }
        if (t.useDesc === true && (!t.desc || t.desc.toString().trim() === '')) return true;
        return false;
    });
}

function tmLogicKeyValue(row) {
    return `${(row && row.key ? row.key : '').trim()}:${(row && row.val ? row.val : '').trim()}`;
}

function tmCountUnmatchedEntryLogic(entry) {
    const globalLogic = getAllLogicStrings();
    let count = 0;
    (entry.conditions || []).forEach(cond => {
        const key = tmLogicKeyValue(cond);
        if (key !== ':' && !globalLogic.states.includes(key) && !entry.calledExternally) count++;
    });
    (entry.stateChanges || []).forEach(change => {
        const key = tmLogicKeyValue(change);
        if (key !== ':' && !globalLogic.conds.includes(key) && !entry.makeExternalCall) count++;
    });
    return count;
}

function tmObjectiveHasWarning(obj) {
    if (!obj) return false;
    return tmIsObjectiveSoftInvalid(obj) || getObjectiveGlowClass(obj) !== 'glow-none';
}

function tmTaskHasInvalidChildObjective(task) {
    return !!(task && Array.isArray(task.objectives) && task.objectives.some(obj => tmIsObjectiveSoftInvalid(obj)));
}

function tmGetTaskWarningCount(task) {
    if (!task) return 0;
    let count = tmCountUnmatchedEntryLogic(task);
    (task.objectives || []).forEach(obj => {
        if (tmObjectiveHasWarning(obj)) count++;
    });
    return count;
}

function getWarningIconSvg() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.35" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`;
}

function tmGetTaskGiverOptions(selected) {
    const cast = (state.Values && Array.isArray(state.Values.globalCast)) ? state.Values.globalCast : [];
    const current = String(selected || '');
    let html = `<option value="">Select Quest Giver...</option>`;
    cast.forEach(item => {
        const name = String(item.name || '').trim();
        if (!name) return;
        html += `<option value="${escapeHtml(name)}" ${current === name ? 'selected' : ''}>${escapeHtml(name)}</option>`;
    });
    if (current && !cast.some(item => String(item.name || '').trim() === current)) {
        html += `<option value="${escapeHtml(current)}" selected>${escapeHtml(current)}</option>`;
    }
    return html;
}

function tmGetTaskSettingOptions(selected) {
    const settings = (state.Values && Array.isArray(state.Values.globalSettings)) ? state.Values.globalSettings : [];
    const current = String(selected || '');
    let html = `<option value="">Select Setting...</option>`;
    settings.forEach(item => {
        const name = String(item.name || item.setting || item.key || '').trim();
        if (!name) return;
        html += `<option value="${escapeHtml(name)}" ${current === name ? 'selected' : ''}>${escapeHtml(name)}</option>`;
    });
    if (current && !settings.some(item => String(item.name || item.setting || item.key || '').trim() === current)) {
        html += `<option value="${escapeHtml(current)}" selected>${escapeHtml(current)}</option>`;
    }
    return html;
}

function generateObjectiveHTML(c, taskId, i, isAuthor) {
    if(!c.id) c.id = crypto.randomUUID();
    if(c.isMandatory === undefined) c.isMandatory = true;
    if(c.calledExternally === undefined) c.calledExternally = false;
    if(c.externallyCalled === undefined) c.externallyCalled = false;
    if(c.isCollapsed === undefined) c.isCollapsed = false;
    if(c.phase === undefined) c.phase = 'Single Phase';
    if(!c.targets || c.targets.length === 0) c.targets = [{id: crypto.randomUUID(), type: 'Collect Item', val1: '', val2: '', val3: '', val4: '', useDesc: true, desc: ''}];
    if(!c.subCollapsed) c.subCollapsed = {conditions: true, stateChanges: true};

    const isInvalid = tmIsObjectiveSoftInvalid(c);

    const pulseClass = isInvalid ? 'invalid-objective' : '';
    const glowClass = getObjectiveGlowClass(c);
    const wrapperId = `objective-card-${isAuthor ? 'author' : 'middle'}-${taskId}-${i}`;

    if (c.isCollapsed) {
        return `
        <div id="${wrapperId}" class="bg-[#111] p-3 border border-[#333] rounded-xl flex justify-between items-center shadow-inner ${pulseClass} ${glowClass} relative transition-all duration-300 ${!isAuthor ? 'mb-3' : ''}">
            <div class="flex items-center gap-3">
                <div class="cursor-pointer bg-[#222] border border-[var(--accent-pink)] text-[var(--accent-pink)] px-2 py-1 rounded-sm text-[9px] font-black uppercase tracking-widest hover:bg-[var(--accent-pink)] hover:text-black transition-colors" onclick="typeof toggleObjectiveCollapse === 'function' ? toggleObjectiveCollapse('${taskId}', ${i}) : null" title="Click to expand">OBJ #${i+1}</div>
                <span class="text-sm font-bold text-white truncate max-w-[200px]">${escapeHtml(c.text)}</span>
            </div>
            <div class="flex flex-col items-end gap-1">
                <div class="flex items-center gap-2">
                    <span class="text-[8px] uppercase font-bold text-gray-500">${escapeHtml(c.phase || 'Single Phase')}</span>
                    <span class="text-[9px] text-gray-500 italic select-text">${c.id}</span><button class="tm-inline-copy-id" onclick="event.stopPropagation(); tmCopyText('${c.id}')" title="Copy Objective ID">${tmSvgCopy()}</button>
                </div>
                <span class="text-[9px] text-[var(--accent-teal)] font-black uppercase tracking-widest">${c.targets.length} REQUIREMENT${c.targets.length !== 1 ? 'S' : ''}</span>
            </div>
        </div>
        `;
    }

    let parentUI = '';
    let childUI = '';

    let childTargets = [];
    c.targets.forEach(t => {
        if (t.type === 'Complete Objective' && t.val2) {
            const childTask = state.entries.find(e => e.objectives && e.objectives.some(o => o.id === t.val2));
            if(childTask) {
                const childObj = childTask.objectives.find(o => o.id === t.val2);
                childTargets.push({ taskId: childTask.id, objId: childObj.id, name: childObj.text });
            }
        }
    });
    
    if(childTargets.length > 0) {
        parentUI = `
            <div class="mt-2 flex flex-col gap-1 w-full max-w-[150px]">
                <span class="text-[8px] font-black uppercase text-[var(--accent-teal)]">PARENT OBJ</span>
                ${childTargets.map(ct => `
                    <button type="button" class="btn btn-outline py-0.5 px-2 text-[8px] w-full text-left truncate border-[var(--accent-teal)] hover:bg-[var(--accent-teal)] hover:text-black transition-colors" onclick="jumpToObjective('${ct.taskId}', '${ct.objId}')">Child: ${escapeHtml(ct.name)}</button>
                `).join('')}
            </div>
        `;
    }

    let parentTargets = [];
    state.entries.forEach(ptask => {
        if(ptask.objectives) {
            ptask.objectives.forEach(pobj => {
                if (pobj.targets && pobj.targets.some(t => t.type === 'Complete Objective' && t.val2 === c.id)) {
                    parentTargets.push({ taskId: ptask.id, objId: pobj.id, name: pobj.text });
                }
            });
        }
    });

    if(parentTargets.length > 0) {
        childUI = `
            <div class="mt-2 flex flex-col gap-1 w-full max-w-[150px]">
                <span class="text-[8px] font-black uppercase text-[var(--accent-purple)]">CHILD OBJ</span>
                ${parentTargets.map(pt => `
                    <button type="button" class="btn btn-outline py-0.5 px-2 text-[8px] w-full text-left truncate border-[var(--accent-purple)] hover:bg-[var(--accent-purple)] hover:text-black transition-colors" onclick="jumpToObjective('${pt.taskId}', '${pt.objId}')">Parent: ${escapeHtml(pt.name)}</button>
                `).join('')}
            </div>
        `;
    }

    return `
    <div id="${wrapperId}" class="bg-[#111] p-3 border border-[#333] rounded-xl flex flex-col gap-2 shadow-inner ${pulseClass} ${glowClass} relative transition-all duration-300 ${!isAuthor ? 'mb-3' : ''}">
        <div class="flex justify-between items-start mb-2 border-b border-[#222] pb-2">
            
            <div class="flex flex-col items-start gap-1">
                <div class="cursor-pointer bg-[var(--accent-pink)] text-black px-2 py-1 rounded-sm text-[9px] font-black uppercase tracking-widest hover:brightness-125 inline-block shadow-[0_0_8px_rgba(255,0,123,0.4)]" onclick="typeof toggleObjectiveCollapse === 'function' ? toggleObjectiveCollapse('${taskId}', ${i}) : null" title="Toggle Collapse">OBJ #${i+1}</div>
                
                ${parentUI}
                ${childUI}

                <div class="flex items-center gap-1 mt-1">
                    <select class="text-[9px] bg-[#0a0a0a] rounded border-[#444] text-white custom-scrollbar px-1 py-0.5" onchange="updateMiddleObjective('${taskId}', ${i}, 'phase', this.value)">
                        ${(state.phases || ['Single Phase', 'Phase 1', 'Phase 2', 'Phase 3', 'Phase 4']).map(p => `<option value="${escapeHtml(p)}" ${c.phase === p ? 'selected' : ''}>${escapeHtml(p)}</option>`).join('')}
                    </select>
                    <button type="button" class="btn btn-outline border-[var(--accent-teal)] text-[var(--accent-teal)] text-[10px] w-5 h-5 flex items-center justify-center p-0 rounded hover:bg-[var(--accent-teal)] hover:text-black" onclick="typeof openPhaseModal === 'function' ? openPhaseModal('${taskId}', ${i}) : null">+</button>
                </div>
            </div>
            
            <div class="flex flex-col items-end gap-2 text-right w-full">
                <div class="flex items-center gap-3">
                    <span class="text-[9px] text-gray-500 italic select-text ml-2">${c.id}</span><button class="tm-inline-copy-id" onclick="event.stopPropagation(); tmCopyText('${c.id}')" title="Copy Objective ID">${tmSvgCopy()}</button>
                    <button type="button" class="text-red-500 hover:text-white text-xs font-bold leading-none ml-1" onclick="removeMiddleObjective('${taskId}', ${i})">✕</button>
                </div>
                
                <!-- External Flow Control Bools -->
                <div class="flex items-center justify-end gap-3 w-full">
                    <label class="checkbox-label-small text-[9px] text-gray-400 font-bold uppercase flex items-center gap-1 cursor-pointer">
                        <input type="checkbox" ${c.calledExternally ? 'checked' : ''} onchange="updateMiddleObjective('${taskId}', ${i}, 'calledExternally', this.checked)"> CALLED EXTERNALLY
                    </label>
                    <label class="checkbox-label-small text-[9px] text-gray-400 font-bold uppercase flex items-center gap-1 cursor-pointer">
                        <input type="checkbox" ${c.externallyCalled ? 'checked' : ''} onchange="updateMiddleObjective('${taskId}', ${i}, 'externallyCalled', this.checked)"> EXTERNALLY CALLED
                    </label>
                </div>

                <!-- Radials -->
                <div class="flex items-center justify-end gap-3 w-full">
                    <label class="text-[9px] text-gray-400 font-bold uppercase flex items-center gap-1 cursor-pointer">
                        <input type="radio" name="req_${c.id}_${isAuthor?'A':'M'}" value="mandatory" style="accent-color: #00f2ff; width: 12px; height: 12px;" ${c.isMandatory ? 'checked' : ''} onchange="updateMiddleObjective('${taskId}', ${i}, 'isMandatory', true)"> MANDATORY
                    </label>
                    <label class="text-[9px] text-gray-400 font-bold uppercase flex items-center gap-1 cursor-pointer">
                        <input type="radio" name="req_${c.id}_${isAuthor?'A':'M'}" value="optional" style="accent-color: #00f2ff; width: 12px; height: 12px;" ${!c.isMandatory ? 'checked' : ''} onchange="updateMiddleObjective('${taskId}', ${i}, 'isMandatory', false)"> OPTIONAL
                    </label>
                </div>

                <!-- Repeatable & Abandonable -->
                <div class="flex flex-row items-start justify-end gap-4 mt-1 w-full">
                    <div class="flex flex-col items-end gap-1">
                        <label class="checkbox-label-small text-[9px]">
                            <input type="checkbox" ${c.isRepeatable ? 'checked' : ''} onchange="updateMiddleObjective('${taskId}', ${i}, 'isRepeatable', this.checked)">
                            <span class="text-gray-400">REPEATABLE</span>
                        </label>
                        ${c.isRepeatable ? `
                        <div class="flex items-center gap-1 mt-1">
                            <input type="text" class="text-[9px] w-16 bg-[#0a0a0a] rounded border-[#444] text-white px-1" value="${escapeHtml(c.repeatableCond?.key)}" placeholder="Rep Key" oninput="updateObjCond('${taskId}', ${i}, 'repeatableCond', 'key', this.value)">
                            <select class="text-[9px] bg-[#0a0a0a] rounded border-[#444] text-white px-0 custom-scrollbar" onchange="updateObjCond('${taskId}', ${i}, 'repeatableCond', 'op', this.value)">
                                <option ${c.repeatableCond?.op==='=='?'selected':''}>==</option>
                                <option ${c.repeatableCond?.op==='>='?'selected':''}>>=</option>
                                <option ${c.repeatableCond?.op==='<='?'selected':''}><=</option>
                                <option ${c.repeatableCond?.op==='>'?'selected':''}>></option>
                                <option ${c.repeatableCond?.op==='<'?'selected':''}><</option>
                            </select>
                            <input type="text" class="text-[9px] w-12 bg-[#0a0a0a] rounded border-[#444] text-white px-1 text-center" value="${escapeHtml(c.repeatableCond?.val)}" placeholder="Val" oninput="updateObjCond('${taskId}', ${i}, 'repeatableCond', 'val', this.value)">
                        </div>
                        ` : ''}
                    </div>

                    <div class="flex flex-col items-end gap-1">
                        <label class="checkbox-label-small text-[9px]">
                            <input type="checkbox" ${c.isAbandonable ? 'checked' : ''} onchange="updateMiddleObjective('${taskId}', ${i}, 'isAbandonable', this.checked)">
                            <span class="text-gray-400">ABANDONABLE</span>
                        </label>
                        ${c.isAbandonable ? `
                        <div class="flex items-center gap-1 mt-1">
                            <input type="text" class="text-[9px] w-16 bg-[#0a0a0a] rounded border-[#444] text-white px-1" value="${escapeHtml(c.abandonableCond?.key)}" placeholder="Abn Key" oninput="updateObjCond('${taskId}', ${i}, 'abandonableCond', 'key', this.value)">
                            <select class="text-[9px] bg-[#0a0a0a] rounded border-[#444] text-white px-0 custom-scrollbar" onchange="updateObjCond('${taskId}', ${i}, 'abandonableCond', 'op', this.value)">
                                <option ${c.abandonableCond?.op==='=='?'selected':''}>==</option>
                                <option ${c.abandonableCond?.op==='>='?'selected':''}>>=</option>
                                <option ${c.abandonableCond?.op==='<='?'selected':''}><=</option>
                                <option ${c.abandonableCond?.op==='>'?'selected':''}>></option>
                                <option ${c.abandonableCond?.op==='<'?'selected':''}><</option>
                            </select>
                            <input type="text" class="text-[9px] w-12 bg-[#0a0a0a] rounded border-[#444] text-white px-1 text-center" value="${escapeHtml(c.abandonableCond?.val)}" placeholder="Val" oninput="updateObjCond('${taskId}', ${i}, 'abandonableCond', 'val', this.value)">
                        </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        </div>

        <!-- Objective Conditions -->
        <div class="rounded-panel darker-panel shadow-lg mt-1 mb-2">
            <div class="array-header ${c.subCollapsed?.conditions ? 'collapsed' : ''} py-2 px-3" onclick="toggleObjSub('${taskId}', ${i}, 'conditions')">
                <span class="array-title text-[10px]">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="6 9 12 15 18 9"></polyline></svg> 
                    CONDITIONS
                </span>
                <button type="button" class="btn-add-array py-1 px-2 text-[8px]" onclick="event.stopPropagation(); addObjLogicRow('${taskId}', ${i}, 'conditions')">+ ADD</button>
            </div>
            <div class="p-2 ${c.subCollapsed?.conditions ? 'hidden' : 'block'} bg-transparent">
                ${c.conditions && c.conditions.length > 0 ? c.conditions.map((cond, ci) => `
                    <div class="array-row gap-1 mb-1">
                        <select class="text-[9px] p-1 cursor-pointer bg-[#0a0a0a] border-[#444] rounded text-white w-1/4 custom-scrollbar" onchange="updateObjLogicArray('${taskId}', ${i}, 'conditions', ${ci}, 'context', this.value)">
                            <option value="Standard" ${cond.context==='Standard'||!cond.context?'selected':''}>Standard</option>
                            <option value="Visibility" ${cond.context==='Visibility'?'selected':''}>Visibility</option>
                            <option value="Eligibility" ${cond.context==='Eligibility'?'selected':''}>Eligibility</option>
                            <option value="Auto-Fail" ${cond.context==='Auto-Fail'?'selected':''}>Auto-Fail</option>
                        </select>
                        <input type="text" value="${escapeHtml(cond.key)}" oninput="updateObjLogicArray('${taskId}', ${i}, 'conditions', ${ci}, 'key', this.value)" class="text-[9px] p-1.5 w-1/3 bg-[#111] border-[#444] rounded text-white" placeholder="Key">
                        <select class="text-[9px] p-1 cursor-pointer bg-[#111] border-[#444] rounded text-white w-12 custom-scrollbar" onchange="updateObjLogicArray('${taskId}', ${i}, 'conditions', ${ci}, 'op', this.value)">
                            <option ${cond.op==='=='?'selected':''}>==</option><option ${cond.op==='!='?'selected':''}>!=</option>
                            <option ${cond.op==='>'?'selected':''}>></option><option ${cond.op==='<'?'selected':''}>&lt;</option>
                            <option ${cond.op==='>='?'selected':''}>>=</option><option ${cond.op==='<='?'selected':''}>&lt;=</option>
                        </select>
                        <input type="text" value="${escapeHtml(cond.val)}" oninput="updateObjLogicArray('${taskId}', ${i}, 'conditions', ${ci}, 'val', this.value)" class="text-[9px] p-1.5 w-16 bg-[#111] border-[#444] rounded text-white" placeholder="Val">
                        <button class="btn-array-del py-1 px-1.5 text-[8px] min-w-[20px]" onclick="removeObjLogicRow('${taskId}', ${i}, 'conditions', ${ci})">✕</button>
                    </div>
                `).join('') : '<div class="text-[8px] text-gray-500 text-center italic font-bold py-1">No conditions defined.</div>'}
            </div>
        </div>

        <input type="text" id="obj-title-${taskId}-${i}" class="text-xs w-full bg-[#0a0a0a] rounded-lg border-[#444] text-white outline-none focus:border-[var(--accent-teal)] px-3 py-2" value="${escapeHtml(c.text)}" placeholder="Objective Title" oninput="updateMiddleObjective('${taskId}', ${i}, 'text', this.value)">

        <div class="flex flex-col gap-2 w-full mt-2 border-t border-[#222] pt-2">
            <div class="flex justify-between items-center mb-1">
                <span class="text-[9px] font-black uppercase text-gray-500 tracking-widest">Requirements</span>
                <button type="button" class="bg-[var(--accent-green)] text-black font-black text-[9px] px-2 py-0.5 rounded cursor-pointer hover:brightness-110" onclick="addObjectiveTarget('${taskId}', ${i})" title="Add Requirement">+</button>
            </div>
            ${c.targets.map((t, ti) => {
                return `
                <div class="flex flex-col gap-1 w-full bg-[#0a0a0a] p-2 rounded-lg border border-[#333]">
                    <div class="flex items-start gap-2">
                        <select id="obj-type-${taskId}-${i}-${ti}" class="text-[10px] w-1/3 bg-[#111] border border-[#444] rounded text-white cursor-pointer outline-none custom-scrollbar p-1.5" onchange="updateObjectiveTarget('${taskId}', ${i}, ${ti}, 'type', this.value)">
                            ${typeof OBJECTIVE_TYPES !== 'undefined' ? Object.keys(OBJECTIVE_TYPES).map(type => `<option value="${type}" ${t.type === type ? 'selected' : ''}>${type}</option>`).join('') : ''}
                        </select>
                        <div class="flex flex-col gap-1 w-2/3">
                            ${renderObjectiveInputs(t, taskId, i, ti, isAuthor)}
                        </div>
                        <button type="button" class="text-red-500 font-black text-xs hover:text-white px-1 mt-1" onclick="removeObjectiveTarget('${taskId}', ${i}, ${ti})">✕</button>
                    </div>
                </div>
                `;
            }).join('')}
        </div>
        
        <!-- Objective State Changes -->
        <div class="rounded-panel darker-panel shadow-lg mt-2 mb-0">
            <div class="array-header ${c.subCollapsed?.stateChanges ? 'collapsed' : ''} py-2 px-3" onclick="toggleObjSub('${taskId}', ${i}, 'stateChanges')">
                <span class="array-title text-[10px]">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="6 9 12 15 18 9"></polyline></svg> 
                    CHANGE GAME STATE
                </span>
                <button type="button" class="btn-add-array py-1 px-2 text-[8px]" onclick="event.stopPropagation(); addObjLogicRow('${taskId}', ${i}, 'stateChanges')">+ ADD</button>
            </div>
            <div class="p-2 ${c.subCollapsed?.stateChanges ? 'hidden' : 'block'} bg-transparent">
                ${c.stateChanges && c.stateChanges.length > 0 ? c.stateChanges.map((sc, si) => `
                    <div class="array-row gap-1 mb-1">
                        <input type="text" value="${escapeHtml(sc.key)}" oninput="updateObjLogicArray('${taskId}', ${i}, 'stateChanges', ${si}, 'key', this.value)" class="text-[9px] p-1.5 bg-[#111] border-[#444] rounded text-white" placeholder="Key">
                        <select class="text-[9px] p-1 cursor-pointer bg-[#111] border-[#444] rounded text-white w-12 custom-scrollbar" onchange="updateObjLogicArray('${taskId}', ${i}, 'stateChanges', ${si}, 'op', this.value)">
                            <option ${sc.op==='=='?'selected':''}>==</option><option ${sc.op==='='?'selected':''}>=</option>
                            <option ${sc.op==='+='?'selected':''}>+=</option><option ${sc.op==='-='?'selected':''}>-=</option>
                        </select>
                        <input type="text" value="${escapeHtml(sc.val)}" oninput="updateObjLogicArray('${taskId}', ${i}, 'stateChanges', ${si}, 'val', this.value)" class="text-[9px] p-1.5 w-16 bg-[#111] border-[#444] rounded text-white" placeholder="Val">
                        <button class="btn-array-del py-1 px-1.5 text-[8px] min-w-[20px]" onclick="removeObjLogicRow('${taskId}', ${i}, 'stateChanges', ${si})">✕</button>
                    </div>
                `).join('') : '<div class="text-[8px] text-gray-500 text-center italic font-bold py-1">No state changes defined.</div>'}
            </div>
        </div>
    </div>
    `;
}

function generateRewardsHTML(task, subs, isAuthor) {
    if (!task.rewards) task.rewards = {
        vault: { enabled: false, items: [] },
        arsenal: { enabled: false, items: [] },
        ladder: { enabled: false, points: [], status: [] },
        story: { enabled: false, relationships: [], world: [] },
        hooks: { enabled: false, items: [] },
        penalties: { enabled: false, items: [] }
    };
    
    if(!task.rewards.penalties) task.rewards.penalties = { enabled: false, items: [] };

    const r = task.rewards;
    const chevron = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="6 9 12 15 18 9"></polyline></svg>`;
    
    const buildHeader = (id, title, enabled) => `
        <div class="array-header py-2 px-3 flex justify-between items-center ${subs['reward_'+id] ? 'collapsed' : ''}" onclick="toggleSubCategory('${task.id}', 'reward_${id}')">
            <span class="array-title text-[10px] text-[var(--accent-gold)]">${chevron} ${title}</span>
            <label class="flex items-center gap-2 cursor-pointer" onclick="event.stopPropagation()">
                <span class="text-[8px] font-black uppercase text-gray-400">Grant?</span>
                <input type="checkbox" ${enabled ? 'checked' : ''} onchange="updateRewardToggle('${task.id}', '${id}', this.checked)" class="accent-[var(--accent-gold)] w-3 h-3">
            </label>
        </div>
    `;

    // 1. Vault
    let vaultHtml = `
        <div class="rounded-panel mb-2 shadow-lg w-full bg-[#0a0a0a]">
            ${buildHeader('vault', 'Currencies & Resources', r.vault.enabled)}
            <div class="p-3 ${subs.reward_vault ? 'hidden' : 'block'} bg-[#1e1e1e] border-t border-[#222]">
                ${!r.vault.enabled ? '<div class="text-[9px] text-gray-500 italic text-center">Enable to configure Vault rewards.</div>' : `
                    <div class="flex justify-end mb-2"><button type="button" class="btn-add-array text-[8px] py-1 px-2 border-[var(--accent-gold)] text-[var(--accent-gold)]" onclick="addRewardItem('${task.id}', 'vault', 'items')">+ ADD RESOURCE</button></div>
                    ${r.vault.items.map((item, idx) => `
                        <div class="flex flex-col gap-1 bg-[#111] p-2 rounded border border-[#333] mb-2">
                            <div class="flex items-center gap-2">
                                <select class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-1/3 custom-scrollbar" onchange="updateRewardItem('${task.id}', 'vault', 'items', ${idx}, 'category', this.value)">
                                    <option ${item.category==='Standard'?'selected':''}>Standard</option><option ${item.category==='Premium'?'selected':''}>Premium</option>
                                    <option ${item.category==='Material'?'selected':''}>Material</option><option ${item.category==='Energy'?'selected':''}>Energy</option>
                                </select>
                                <input type="text" class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-2/3" placeholder="Resource ID" value="${escapeHtml(item.id)}" oninput="updateRewardItem('${task.id}', 'vault', 'items', ${idx}, 'id', this.value)">
                                <button class="btn-array-del py-1 px-1.5 text-[8px] min-w-[20px]" onclick="removeRewardItem('${task.id}', 'vault', 'items', ${idx})">✕</button>
                            </div>
                            <div class="flex items-center justify-between gap-2 mt-1">
                                <label class="checkbox-label-small text-[8px] text-gray-400 font-bold uppercase"><input type="checkbox" ${item.isVariable ? 'checked' : ''} onchange="updateRewardItem('${task.id}', 'vault', 'items', ${idx}, 'isVariable', this.checked)"> Variable Amount?</label>
                                ${item.isVariable ? `
                                    <div class="flex items-center gap-1"><input type="number" class="text-[9px] p-1 w-12 bg-[#0a0a0a] rounded border-[#444] text-white text-center" placeholder="Min" value="${item.min}" oninput="updateRewardItem('${task.id}', 'vault', 'items', ${idx}, 'min', Number(this.value))"><span class="text-gray-500">-</span><input type="number" class="text-[9px] p-1 w-12 bg-[#0a0a0a] rounded border-[#444] text-white text-center" placeholder="Max" value="${item.max}" oninput="updateRewardItem('${task.id}', 'vault', 'items', ${idx}, 'max', Number(this.value))"></div>
                                ` : `
                                    <input type="number" class="text-[9px] p-1 w-20 bg-[#0a0a0a] rounded border-[#444] text-white text-center" placeholder="Payout" value="${item.fixed}" oninput="updateRewardItem('${task.id}', 'vault', 'items', ${idx}, 'fixed', Number(this.value))">
                                `}
                            </div>
                        </div>
                    `).join('')}
                `}
            </div>
        </div>
    `;

    // 2. Arsenal
    let arsenalHtml = `
        <div class="rounded-panel mb-2 shadow-lg w-full bg-[#0a0a0a]">
            ${buildHeader('arsenal', 'Tangible Drops', r.arsenal.enabled)}
            <div class="p-3 ${subs.reward_arsenal ? 'hidden' : 'block'} bg-[#1e1e1e] border-t border-[#222]">
                ${!r.arsenal.enabled ? '<div class="text-[9px] text-gray-500 italic text-center">Enable to configure Arsenal rewards.</div>' : `
                    <div class="flex justify-end mb-2"><button type="button" class="btn-add-array text-[8px] py-1 px-2 border-[var(--accent-gold)] text-[var(--accent-gold)]" onclick="addRewardItem('${task.id}', 'arsenal', 'items')">+ ADD ITEM DROP</button></div>
                    ${r.arsenal.items.map((item, idx) => `
                        <div class="flex flex-col gap-1 bg-[#111] p-2 rounded border border-[#333] mb-2">
                            <div class="flex items-center gap-2">
                                <select class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-full custom-scrollbar" onchange="updateRewardItem('${task.id}', 'arsenal', 'items', ${idx}, 'method', this.value)">
                                    <option ${item.method==='Direct Item'?'selected':''}>Direct Item</option><option ${item.method==='Loot Table Roll'?'selected':''}>Loot Table Roll</option><option ${item.method==='Cosmetic'?'selected':''}>Cosmetic</option>
                                </select>
                                <button class="btn-array-del py-1 px-1.5 text-[8px] min-w-[20px]" onclick="removeRewardItem('${task.id}', 'arsenal', 'items', ${idx})">✕</button>
                            </div>
                            ${item.method === 'Loot Table Roll' ? `
                                <div class="flex items-center gap-2 mt-1">
                                    <input type="text" class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-2/3" placeholder="Table ID (e.g. Boss_Chest_01)" value="${escapeHtml(item.tableId)}" oninput="updateRewardItem('${task.id}', 'arsenal', 'items', ${idx}, 'tableId', this.value)">
                                    <input type="number" class="text-[9px] p-1 w-1/3 bg-[#0a0a0a] rounded border-[#444] text-white text-center" placeholder="Pulls" value="${item.pulls}" oninput="updateRewardItem('${task.id}', 'arsenal', 'items', ${idx}, 'pulls', Number(this.value))">
                                </div>
                            ` : `
                                <div class="flex items-center gap-2 mt-1">
                                    <input type="text" class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-full" placeholder="Item ID" value="${escapeHtml(item.id)}" oninput="updateRewardItem('${task.id}', 'arsenal', 'items', ${idx}, 'id', this.value)">
                                    <input type="number" class="text-[9px] p-1 w-16 bg-[#0a0a0a] rounded border-[#444] text-white text-center" placeholder="Qty" value="${item.qty}" oninput="updateRewardItem('${task.id}', 'arsenal', 'items', ${idx}, 'qty', Number(this.value))">
                                </div>
                                <label class="checkbox-label-small text-[8px] text-gray-400 font-bold uppercase mt-1"><input type="checkbox" ${item.autoEquip ? 'checked' : ''} onchange="updateRewardItem('${task.id}', 'arsenal', 'items', ${idx}, 'autoEquip', this.checked)"> Auto-Equip</label>
                            `}
                        </div>
                    `).join('')}
                `}
            </div>
        </div>
    `;

    // 3. Ladder
    let ladderHtml = `
        <div class="rounded-panel mb-2 shadow-lg w-full bg-[#0a0a0a]">
            ${buildHeader('ladder', 'Progression & Status', r.ladder.enabled)}
            <div class="p-3 ${subs.reward_ladder ? 'hidden' : 'block'} bg-[#1e1e1e] border-t border-[#222]">
                ${!r.ladder.enabled ? '<div class="text-[9px] text-gray-500 italic text-center">Enable to configure Ladder rewards.</div>' : `
                    <div class="flex justify-between items-center mb-2 border-b border-[#333] pb-1">
                        <span class="text-[8px] font-black uppercase text-[var(--accent-teal)]">Points Progression</span>
                        <button type="button" class="btn-add-array text-[8px] py-1 px-2 border-[var(--accent-teal)] text-[var(--accent-teal)]" onclick="addRewardItem('${task.id}', 'ladder', 'points')">+ ADD</button>
                    </div>
                    ${r.ladder.points.map((pt, idx) => `
                        <div class="flex items-center gap-1 bg-[#111] p-1.5 rounded border border-[#333] mb-2">
                            <select class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-1/3 custom-scrollbar" onchange="updateRewardItem('${task.id}', 'ladder', 'points', ${idx}, 'type', this.value)">
                                <option ${pt.type==='Global XP'?'selected':''}>Global XP</option><option ${pt.type==='Class XP'?'selected':''}>Class XP</option><option ${pt.type==='Skill XP'?'selected':''}>Skill XP</option><option ${pt.type==='Season Pass'?'selected':''}>Season Pass</option>
                            </select>
                            ${pt.type === 'Global XP' ? '<div class="w-1/3"></div>' : `<input type="text" class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-1/3" placeholder="Target ID" value="${escapeHtml(pt.target)}" oninput="updateRewardItem('${task.id}', 'ladder', 'points', ${idx}, 'target', this.value)">`}
                            <input type="number" class="text-[9px] p-1 w-1/4 bg-[#0a0a0a] rounded border-[#444] text-white text-center" placeholder="Points" value="${pt.amount}" oninput="updateRewardItem('${task.id}', 'ladder', 'points', ${idx}, 'amount', Number(this.value))">
                            <button class="btn-array-del py-1 px-1.5 text-[8px] min-w-[20px]" onclick="removeRewardItem('${task.id}', 'ladder', 'points', ${idx})">✕</button>
                        </div>
                    `).join('')}
                    
                    <div class="flex justify-between items-center mb-2 mt-3 border-b border-[#333] pb-1">
                        <span class="text-[8px] font-black uppercase text-[var(--accent-purple)]">Status Unlocks</span>
                        <button type="button" class="btn-add-array text-[8px] py-1 px-2 border-[var(--accent-purple)] text-[var(--accent-purple)]" onclick="addRewardItem('${task.id}', 'ladder', 'status')">+ ADD</button>
                    </div>
                    ${r.ladder.status.map((st, idx) => `
                        <div class="flex items-center gap-1 bg-[#111] p-1.5 rounded border border-[#333] mb-2">
                            <select class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-1/3 custom-scrollbar" onchange="updateRewardItem('${task.id}', 'ladder', 'status', ${idx}, 'type', this.value)">
                                <option ${st.type==='Title'?'selected':''}>Title</option><option ${st.type==='Badge'?'selected':''}>Badge</option><option ${st.type==='Profile Theme'?'selected':''}>Profile Theme</option>
                            </select>
                            <input type="text" class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-full" placeholder="Unlock ID" value="${escapeHtml(st.id)}" oninput="updateRewardItem('${task.id}', 'ladder', 'status', ${idx}, 'id', this.value)">
                            <button class="btn-array-del py-1 px-1.5 text-[8px] min-w-[20px]" onclick="removeRewardItem('${task.id}', 'ladder', 'status', ${idx})">✕</button>
                        </div>
                    `).join('')}
                `}
            </div>
        </div>
    `;

    // 4. Story
    let storyHtml = `
        <div class="rounded-panel mb-2 shadow-lg w-full bg-[#0a0a0a]">
            ${buildHeader('story', 'Narrative & Relational', r.story.enabled)}
            <div class="p-3 ${subs.reward_story ? 'hidden' : 'block'} bg-[#1e1e1e] border-t border-[#222]">
                ${!r.story.enabled ? '<div class="text-[9px] text-gray-500 italic text-center">Enable to configure Story rewards.</div>' : `
                    <div class="flex justify-between items-center mb-2 border-b border-[#333] pb-1">
                        <span class="text-[8px] font-black uppercase text-[var(--accent-pink)]">Relationships</span>
                        <button type="button" class="btn-add-array text-[8px] py-1 px-2 border-[var(--accent-pink)] text-[var(--accent-pink)]" onclick="addRewardItem('${task.id}', 'story', 'relationships')">+ ADD</button>
                    </div>
                    ${r.story.relationships.map((rel, idx) => `
                        <div class="flex items-center gap-1 bg-[#111] p-1.5 rounded border border-[#333] mb-2">
                            <select class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-1/4 custom-scrollbar" onchange="updateRewardItem('${task.id}', 'story', 'relationships', ${idx}, 'type', this.value)">
                                <option ${rel.type==='NPC'?'selected':''}>NPC</option><option ${rel.type==='Faction'?'selected':''}>Faction</option>
                            </select>
                            <input type="text" class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-1/2" placeholder="Entity ID" value="${escapeHtml(rel.id)}" oninput="updateRewardItem('${task.id}', 'story', 'relationships', ${idx}, 'id', this.value)">
                            <input type="number" class="text-[9px] p-1 w-1/4 bg-[#0a0a0a] rounded border-[#444] text-white text-center" placeholder="Shift" value="${rel.shift}" oninput="updateRewardItem('${task.id}', 'story', 'relationships', ${idx}, 'shift', Number(this.value))">
                            <button class="btn-array-del py-1 px-1.5 text-[8px] min-w-[20px]" onclick="removeRewardItem('${task.id}', 'story', 'relationships', ${idx})">✕</button>
                        </div>
                    `).join('')}

                    <div class="flex justify-between items-center mb-2 mt-3 border-b border-[#333] pb-1">
                        <span class="text-[8px] font-black uppercase text-[#00ff88]">World State</span>
                        <button type="button" class="btn-add-array text-[8px] py-1 px-2 border-[#00ff88] text-[#00ff88]" onclick="addRewardItem('${task.id}', 'story', 'world')">+ ADD</button>
                    </div>
                    ${r.story.world.map((ws, idx) => `
                        <div class="flex flex-col gap-1 bg-[#111] p-2 rounded border border-[#333] mb-2">
                            <div class="flex items-center gap-2">
                                <select class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-1/3 custom-scrollbar" onchange="updateRewardItem('${task.id}', 'story', 'world', ${idx}, 'type', this.value)">
                                    <option ${ws.type==='Codex Entry'?'selected':''}>Codex Entry</option><option ${ws.type==='World Flag'?'selected':''}>World Flag</option>
                                </select>
                                <input type="text" class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-2/3" placeholder="Target ID" value="${escapeHtml(ws.id)}" oninput="updateRewardItem('${task.id}', 'story', 'world', ${idx}, 'id', this.value)">
                                <button class="btn-array-del py-1 px-1.5 text-[8px] min-w-[20px]" onclick="removeRewardItem('${task.id}', 'story', 'world', ${idx})">✕</button>
                            </div>
                            <div class="flex items-center justify-between gap-2 mt-1">
                                <label class="checkbox-label-small text-[8px] text-gray-400 font-bold uppercase"><input type="checkbox" ${ws.isBool ? 'checked' : ''} onchange="updateRewardItem('${task.id}', 'story', 'world', ${idx}, 'isBool', this.checked)"> Is Bool Flag?</label>
                                ${ws.isBool ? `
                                    <label class="checkbox-label-small text-[8px] text-white font-bold uppercase"><input type="checkbox" ${ws.stateBool ? 'checked' : ''} onchange="updateRewardItem('${task.id}', 'story', 'world', ${idx}, 'stateBool', this.checked)"> State: ${ws.stateBool ? 'TRUE' : 'FALSE'}</label>
                                ` : `
                                    <input type="number" class="text-[9px] p-1 w-20 bg-[#0a0a0a] rounded border-[#444] text-white text-center" placeholder="New Int" value="${ws.stateInt}" oninput="updateRewardItem('${task.id}', 'story', 'world', ${idx}, 'stateInt', Number(this.value))">
                                `}
                            </div>
                        </div>
                    `).join('')}
                `}
            </div>
        </div>
    `;

    // 5. Hooks
    let hooksHtml = `
        <div class="rounded-panel mb-2 shadow-lg w-full bg-[#0a0a0a]">
            ${buildHeader('hooks', 'Live-Service & QoL', r.hooks.enabled)}
            <div class="p-3 ${subs.reward_hooks ? 'hidden' : 'block'} bg-[#1e1e1e] border-t border-[#222]">
                ${!r.hooks.enabled ? '<div class="text-[9px] text-gray-500 italic text-center">Enable to configure Hook rewards.</div>' : `
                    <div class="flex justify-end mb-2"><button type="button" class="btn-add-array text-[8px] py-1 px-2 border-[var(--accent-gold)] text-[var(--accent-gold)]" onclick="addRewardItem('${task.id}', 'hooks', 'items')">+ ADD HOOK</button></div>
                    ${r.hooks.items.map((hk, idx) => `
                        <div class="flex flex-col gap-1 bg-[#111] p-2 rounded border border-[#333] mb-2">
                            <div class="flex items-center gap-2">
                                <select class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-1/3 custom-scrollbar" onchange="updateRewardItem('${task.id}', 'hooks', 'items', ${idx}, 'type', this.value)">
                                    <option ${hk.type==='Gacha Ticket'?'selected':''}>Gacha Ticket</option><option ${hk.type==='Time Skip'?'selected':''}>Time Skip</option><option ${hk.type==='Booster'?'selected':''}>Booster</option><option ${hk.type==='QoL Upgrade'?'selected':''}>QoL Upgrade</option>
                                </select>
                                <input type="text" class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-2/3" placeholder="Target ID" value="${escapeHtml(hk.target)}" oninput="updateRewardItem('${task.id}', 'hooks', 'items', ${idx}, 'target', this.value)">
                                <button class="btn-array-del py-1 px-1.5 text-[8px] min-w-[20px]" onclick="removeRewardItem('${task.id}', 'hooks', 'items', ${idx})">✕</button>
                            </div>
                            <div class="flex items-center justify-between gap-2 mt-1">
                                <label class="checkbox-label-small text-[8px] text-gray-400 font-bold uppercase"><input type="checkbox" ${hk.isTimeBased ? 'checked' : ''} onchange="updateRewardItem('${task.id}', 'hooks', 'items', ${idx}, 'isTimeBased', this.checked)"> Time Based?</label>
                                ${hk.isTimeBased ? `
                                    <input type="number" class="text-[9px] p-1 w-20 bg-[#0a0a0a] rounded border-[#444] text-white text-center" placeholder="Minutes" value="${hk.duration}" oninput="updateRewardItem('${task.id}', 'hooks', 'items', ${idx}, 'duration', Number(this.value))">
                                ` : `
                                    <input type="number" class="text-[9px] p-1 w-20 bg-[#0a0a0a] rounded border-[#444] text-white text-center" placeholder="Qty" value="${hk.quantity}" oninput="updateRewardItem('${task.id}', 'hooks', 'items', ${idx}, 'quantity', Number(this.value))">
                                `}
                            </div>
                        </div>
                    `).join('')}
                `}
            </div>
        </div>
    `;
    
    // 6. Penalties (The Toll)
    let penaltiesHtml = `
        <div class="rounded-panel mb-0 shadow-lg w-full bg-[#0a0a0a]">
            ${buildHeader('penalties', 'The Toll (Penalties)', r.penalties.enabled)}
            <div class="p-3 ${subs.reward_penalties ? 'hidden' : 'block'} bg-[#1e1e1e] border-t border-[#222]">
                ${!r.penalties.enabled ? '<div class="text-[9px] text-gray-500 italic text-center">Enable to configure Penalties.</div>' : `
                    <div class="flex justify-end mb-2"><button type="button" class="btn-add-array text-[8px] py-1 px-2 border-[var(--accent-pink)] text-[var(--accent-pink)]" onclick="addRewardItem('${task.id}', 'penalties', 'items')">+ ADD PENALTY</button></div>
                    ${r.penalties.items.map((item, idx) => `
                        <div class="flex flex-col gap-1 bg-[#111] p-2 rounded border border-[#333] mb-2">
                            <div class="flex items-center gap-2">
                                <select class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-1/3 custom-scrollbar" onchange="updateRewardItem('${task.id}', 'penalties', 'items', ${idx}, 'trigger', this.value)">
                                    <option ${item.trigger==='On Quest Fail'?'selected':''}>On Quest Fail</option><option ${item.trigger==='On Quest Abandon'?'selected':''}>On Quest Abandon</option><option ${item.trigger==='On Timer Expire'?'selected':''}>On Timer Expire</option>
                                </select>
                                <select class="text-[9px] p-1 bg-[#0a0a0a] rounded border-[#444] text-white w-2/3 custom-scrollbar" onchange="updateRewardItem('${task.id}', 'penalties', 'items', ${idx}, 'type', this.value)">
                                    <option ${item.type==='Currency Loss'?'selected':''}>Currency Loss</option><option ${item.type==='Reputation Drop'?'selected':''}>Reputation Drop</option><option ${item.type==='Item Confiscation'?'selected':''}>Item Confiscation</option><option ${item.type==='Apply Debuff'?'selected':''}>Apply Debuff</option>
                                </select>
                                <button class="btn-array-del py-1 px-1.5 text-[8px] min-w-[20px]" onclick="removeRewardItem('${task.id}', 'penalties', 'items', ${idx})">✕</button>
                            </div>
                            <div class="flex items-center gap-2 mt-1">
                                <input type="text" class="text-[9px] p-1 w-2/3 bg-[#0a0a0a] rounded border-[#444] text-white" placeholder="Target ID" value="${escapeHtml(item.id)}" oninput="updateRewardItem('${task.id}', 'penalties', 'items', ${idx}, 'id', this.value)">
                                <input type="number" class="text-[9px] p-1 w-1/3 bg-[#0a0a0a] rounded border-[#444] text-white text-center" placeholder="Deduction" value="${item.amount}" oninput="updateRewardItem('${task.id}', 'penalties', 'items', ${idx}, 'amount', Number(this.value))">
                            </div>
                        </div>
                    `).join('')}
                `}
            </div>
        </div>
    `;

    return `
    <div class="rounded-panel mb-0 shadow-lg w-full mt-4">
        <div class="array-header ${subs.rewards ? 'collapsed' : ''}" onclick="toggleSubCategory('${task.id}', 'rewards')">
            <span class="array-title text-[var(--accent-gold)]">${chevron} REWARD SETTINGS</span>
        </div>
        <div class="p-3 ${subs.rewards ? 'hidden' : 'flex'} flex-col gap-0 bg-[#1e1e1e]">
            ${vaultHtml}${arsenalHtml}${ladderHtml}${storyHtml}${hooksHtml}${penaltiesHtml}
        </div>
    </div>
    `;
}

function renderTasksSilently() {
    saveFocus();
    const container = document.getElementById('taskList');
    if (!container) return;
    const search = document.getElementById('search').value.toLowerCase();
    
    const list = state.entries.filter(e => {
        if (e.tab !== state.activeTab) return false;
        if (!search) return true;
        
        const matchesText = e.name.toLowerCase().includes(search) || 
                            e.id.toLowerCase().includes(search) || 
                            e.desc.toLowerCase().includes(search) || 
                            (e.chainName && e.chainName.toLowerCase().includes(search));
        const matchesTag = (e.tags || []).some(t => t.toLowerCase().includes(search));
        
        return matchesText || matchesTag;
    });
    
    if (list.length === 0) {
        container.innerHTML = `
            <div class="py-32 text-center text-dim text-xs font-black uppercase tracking-[0.3em] opacity-20">No Tasks Detected In ${state.activeTab}</div>
            <div class="mt-6 mb-20 flex justify-center w-full"><button class="btn btn-teal px-8 py-3 font-black tracking-widest rounded-xl text-xs shadow-[0_0_15px_rgba(0,242,255,0.3)]" onclick="createNewEntryUI()">+ ADD NEW ENTRY</button></div>
        `;
        restoreFocus();
        return;
    }

    let outHtml = list.map((task, idx) => {
        const glow = getEntryGlowClass(task);
        const availableDeps = state.entries.filter(t => t.id !== task.id && !task.dependencies.includes(t.id));
        const children = state.entries.filter(t => t.dependencies.includes(task.id));
        const parents = task.dependencies.map(depId => state.entries.find(t => t.id === depId)).filter(Boolean);
        const listCount = list.length;
        const taskWarningCount = tmGetTaskWarningCount(task);
        const hasInvalidChildObjective = tmTaskHasInvalidChildObjective(task);
        const subs = task.subCategoriesCollapsed || { conditions:false, stateChanges:false, summary:false, dependencies:false, tags:false, objectives:false, branch:false, time:false };
        const taskCollapsedInvalidObjectiveClass = (task.collapsed && hasInvalidChildObjective) ? 'has-invalid-child-objective' : '';
        const objectivePanelPulseClass = (subs.objectives && hasInvalidChildObjective) ? 'has-invalid-child-objective' : '';

        let moveOptions = '';
        for(let i=0; i<listCount; i++) moveOptions += `<option value="${i}" ${i === idx ? 'selected' : ''}>#${i + 1}</option>`;
        
        const chevron = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="6 9 12 15 18 9"></polyline></svg>`;

        return `
        <div id="task-card-${task.id}" class="editor-wrapper flex flex-col ${glow} ${taskCollapsedInvalidObjectiveClass} ${state.focusedEntryId === task.id ? 'focused' : ''} ${task.collapsed ? 'is-collapsed' : ''}" style="border-left: 4px solid ${task.color};" onclick="if(!event.target.closest('button') && !event.target.closest('input') && !event.target.closest('select') && !event.target.closest('.dep-checkbox') && !event.target.closest('.inline-edit-wrapper') && !event.target.closest('.inline-edit-entry') && !event.target.closest('.unified-tab') && !event.target.closest('.remove-tag-btn')) { focusEntryUI('${task.id}'); }">
            
            <div class="unified-tab">
                <div class="unified-tab-num" style="background: ${task.color};" onclick="toggleEntryCollapse('${task.id}')" title="Toggle Main Collapse">#${idx + 1}</div>
                <div class="unified-tab-controls" style="border-color: ${task.color}; color: ${task.color};">
                    <span class="move-to-label"><span>Move</span><span>To:</span></span> 
                    <select class="move-to-select" onchange="moveEntryPosition('${task.id}', this.value)" style="border-color: ${task.color}; color: ${task.color};">
                        ${moveOptions}
                    </select>
                    <div class="deep-toggle-stack">
                        <button onclick="typeof setEntryCollapseDeep === 'function' ? setEntryCollapseDeep('${task.id}', false) : null" title="Deep Expand">+</button>
                        <button class="minus" onclick="typeof setEntryCollapseDeep === 'function' ? setEntryCollapseDeep('${task.id}', true) : null" title="Deep Collapse">-</button>
                    </div>
                </div>
            </div>

            <!-- Top Right Booleans & Action Row -->
            <div class="flex justify-between items-start px-5 pt-4 pb-2">
                <div class="flex flex-col items-start tm-task-upper-left-stack">
                    ${task.collapsed && taskWarningCount > 0 ? `
                        <div class="tm-task-warning-badge" title="${taskWarningCount} warning${taskWarningCount === 1 ? '' : 's'}">
                            ${getWarningIconSvg()}
                            <span>${taskWarningCount}</span>
                        </div>
                    ` : ''}
                    <div class="text-[10px] text-[var(--accent-teal)] font-black uppercase tracking-widest mb-1">${escapeHtml(task.displayId || 'NO-ID')}</div>
                </div>
                <div class="flex flex-col items-end gap-1 tm-task-upper-right-stack">
                    <div class="tm-task-id-copy-row"><span class="text-[8px] text-gray-600 font-mono italic tracking-widest select-text">${task.id}</span><button class="tm-inline-copy-id" onclick="event.stopPropagation(); tmCopyText('${task.id}')" title="Copy Task ID">${tmSvgCopy()}</button></div>
                    <div class="${task.collapsed ? 'hidden' : 'flex'} items-center gap-3 mt-1">
                        <label class="checkbox-label checkbox-label-small">
                            <input type="checkbox" onchange="updateTaskBool('${task.id}', 'calledExternally', this.checked)" ${task.calledExternally ? 'checked':''}>
                            <span>EXTERNALLY CALLED</span>
                        </label>
                        <label class="checkbox-label checkbox-label-small">
                            <input type="checkbox" onchange="updateTaskBool('${task.id}', 'makeExternalCall', this.checked)" ${task.makeExternalCall ? 'checked':''}>
                            <span>CALL EXTERNALLY</span>
                        </label>
                    </div>
                </div>
            </div>

            <!-- CONDITIONS ARRAY (DARKER) -->
            <div class="${task.collapsed ? 'hidden' : 'block'} px-5 mb-4">
                <div class="rounded-panel darker-panel mb-0 shadow-lg">
                    <div class="array-header ${subs.conditions ? 'collapsed' : ''}" onclick="toggleSubCategory('${task.id}', 'conditions')">
                        <span class="array-title">${chevron} CONDITIONS</span>
                        <button type="button" class="btn-add-array" onclick="event.stopPropagation(); addLogicRow('${task.id}', 'conditions')">+ ADD CONDITION</button>
                    </div>
                    <div class="p-4 ${subs.conditions ? 'hidden' : 'block'} bg-transparent">
                        ${task.conditions && task.conditions.length > 0 ? task.conditions.map((c, i) => `
                            <div class="array-row">
                                <select class="text-[9px] p-1 cursor-pointer bg-[#111] border-[#444] rounded text-white w-24 custom-scrollbar" onchange="updateLogicArray('${task.id}', 'conditions', ${i}, 'context', this.value)">
                                    <option value="Standard" ${c.context==='Standard'||!c.context?'selected':''}>Standard</option>
                                    <option value="Visibility" ${c.context==='Visibility'?'selected':''}>Visibility</option>
                                    <option value="Eligibility" ${c.context==='Eligibility'?'selected':''}>Eligibility</option>
                                    <option value="Auto-Fail" ${c.context==='Auto-Fail'?'selected':''}>Auto-Fail</option>
                                </select>
                                <input type="text" value="${escapeHtml(c.key)}" oninput="updateLogicArray('${task.id}', 'conditions', ${i}, 'key', this.value)" class="bg-[#111] border-[#444] rounded-lg text-white">
                                <select class="cursor-pointer bg-[#111] border-[#444] rounded-lg text-white w-20 custom-scrollbar" onchange="updateLogicArray('${task.id}', 'conditions', ${i}, 'op', this.value)">
                                    <option ${c.op==='=='?'selected':''}>==</option><option ${c.op==='!='?'selected':''}>!=</option>
                                    <option ${c.op==='>'?'selected':''}>></option><option ${c.op==='<'?'selected':''}>&lt;</option>
                                    <option ${c.op==='>='?'selected':''}>>=</option><option ${c.op==='<='?'selected':''}>&lt;=</option>
                                </select>
                                <input type="text" value="${escapeHtml(c.val)}" oninput="updateLogicArray('${task.id}', 'conditions', ${i}, 'val', this.value)" class="bg-[#111] border-[#444] rounded-lg text-white">
                                <button class="btn-array-del" onclick="removeLogicRow('${task.id}', 'conditions', ${i})">✕</button>
                            </div>
                        `).join('') : '<div class="text-[10px] text-gray-500 text-center italic font-bold py-2">No conditions defined.</div>'}
                    </div>
                </div>
            </div>

            <!-- QUEST GIVER / SETTING -->
            <div class="${task.collapsed ? 'hidden' : 'block'} px-5 mb-4">
                <div class="tm-task-meta-dropdown-row">
                    <div class="tm-task-giver-row">
                        <label for="tm-task-giver-${task.id}">Quest Giver</label>
                        <select id="tm-task-giver-${task.id}" class="tm-task-giver-select custom-scrollbar" onchange="updateTaskString('${task.id}', 'questGiver', this.value)">
                            ${tmGetTaskGiverOptions(task.questGiver)}
                        </select>
                    </div>
                    <div class="tm-task-giver-row tm-task-setting-row">
                        <label for="tm-task-setting-${task.id}">Setting</label>
                        <select id="tm-task-setting-${task.id}" class="tm-task-giver-select custom-scrollbar" onchange="updateTaskString('${task.id}', 'setting', this.value)">
                            ${tmGetTaskSettingOptions(task.setting)}
                        </select>
                    </div>
                </div>
            </div>

            <!-- TITLE & BASIC INFO -->
            <div class="px-5 relative z-10 ${task.collapsed ? 'pb-2' : 'mb-4'}">
                ${task.namespace ? `<div class="text-[9px] text-[var(--accent-teal)] font-black uppercase tracking-widest mb-1">${escapeHtml(task.namespace)}</div>` : ''}
                <div class="flex items-center justify-between w-full mb-2">
                    <div class="flex items-center gap-3">
                        <h4 class="text-2xl font-bold transition-all inline-edit-trigger ${task.collapsed ? 'cursor-pointer hover:brightness-125' : ''}"
                            style="color: ${task.color}; ${tmGetTextFormatStyle(tmGetTaskTextFormat(task, 'name'))}"
                            onclick="handleTitleClick(event, '${task.id}')" title="Single click expand, Double click edit">
                            ${escapeHtml(tmLocalizedTaskText(task, 'name')) || 'UNTITLED ENTRY'}
                        </h4>
                    </div>

                    <div class="flex flex-col items-end gap-1">
                        ${task.collapsed && (task.taskType === 'root' || task.taskType === 'node' || task.taskType === 'endpoint') ? `
                            <div class="inline-flex items-center gap-1.5 text-[8px] font-black uppercase tracking-widest border px-2 py-0.5 rounded-md" style="border-color: ${task.chainColor || 'var(--accent-gold)'}; color: ${task.chainColor || 'var(--accent-gold)'}; background-color: ${task.chainColor || 'var(--accent-gold)'}15;">
                                <span class="text-sm leading-none pt-0.5">${task.chainEmoji || '🔮'}</span>
                                <span>${escapeHtml(task.chainName)}</span>
                            </div>
                        ` : ''}
                        
                        ${task.collapsed && task.objectives && task.objectives.length > 0 ? `
                            <div class="flex flex-col items-end gap-1 mt-0.5">
                                <div class="inline-flex items-center gap-1.5 bg-[#1a1a1a] border border-[#333] px-2 py-0.5 rounded-md text-[9px] font-bold text-gray-300 shadow-sm">
                                    <span class="text-[var(--accent-pink)]">❖</span> ${task.objectives.length} Objective${task.objectives.length !== 1 ? 's' : ''}
                                </div>
                            </div>
                        ` : ''}
                    </div>
                </div>

                <!-- Description & Expanded Chain Display -->
                <div class="${task.collapsed ? 'hidden' : 'block'}">
                    <p class="text-sm text-gray-300 font-medium mb-4 transition-all inline-edit-trigger inline-block w-full" style="${tmGetTextFormatStyle(tmGetTaskTextFormat(task, 'desc'))}" ondblclick="startInlineEditEntry('${task.id}')" title="Double click to edit">${escapeHtml(tmLocalizedTaskText(task, 'desc'))}</p>

                    <div class="flex justify-between items-start mb-3">
                        <div>
                            ${(task.taskType === 'root' || task.taskType === 'node' || task.taskType === 'endpoint') ? `
                                <div class="flex flex-col mb-3">
                                    <div onclick="jumpToChainNode('${task.id}')" class="cursor-pointer hover:brightness-125 transition-all inline-flex items-center gap-1.5 text-[8px] font-black uppercase tracking-widest border px-2 py-0.5 rounded-lg w-max" style="border-color: ${task.chainColor || 'var(--accent-gold)'}; color: ${task.chainColor || 'var(--accent-gold)'}; background-color: ${task.chainColor || 'var(--accent-gold)'}15; box-shadow: 0 0 10px ${task.chainColor || 'var(--accent-gold)'}33;">
                                        <span class="text-sm leading-none pt-0.5">${task.chainEmoji || '🔮'}</span>
                                        <span>CHAIN: ${escapeHtml(task.chainName)} <span class="opacity-60 ml-1"> [${task.taskType}]</span></span>
                                    </div>
                                    <div class="text-[9px] text-dim font-medium italic mt-1.5 ml-1 max-w-lg border-l-2 pl-2" style="border-left-color: ${task.chainColor || 'var(--accent-gold)'}80">${escapeHtml(tmLocalizedTaskText(task, 'chainDesc') || '')}</div>
                                </div>
                            ` : ''}
                            <div class="flex items-center gap-2 mt-1 mb-2">
                                <div class="w-2 h-2 rounded-full" style="background-color: ${task.color}; box-shadow: 0 0 8px ${task.color};"></div>
                                <div class="text-[9px] font-black uppercase tracking-wider text-gray-500">POS #${idx + 1} • ${escapeHtml(task.tab)} REGISTRY [${task.taskType}]</div>
                            </div>
                        </div>
                        <div class="flex gap-2">
                            <button onclick="typeof openDuplicateModal === 'function' ? openDuplicateModal('${task.id}') : null" class="btn btn-outline py-1 px-2 text-[10px] border-[#333] hover:bg-[#111] hover:text-[var(--accent-teal)]" title="Duplicate Entry">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                            </button>
                            <button onclick="toggleChainView('${task.id}')" class="btn btn-outline py-1 px-3 text-[10px] flex items-center gap-1 border-[#333] hover:bg-[#111] hover:text-[${task.color}]" style="border-color: ${task.showChain ? task.color : '#333'}; color: ${task.showChain ? task.color : ''}">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg>
                                ${task.showChain ? 'HIDE MAP' : 'SHOW MAP'}
                            </button>
                            <button onclick="focusEntryUI('${task.id}', true)" class="btn btn-outline py-1 px-3 text-[10px] border-[#333] hover:bg-[#111] hover:border-[var(--accent-teal)] hover:text-[var(--accent-teal)]">EDIT</button>
                            <button onclick="deleteTask('${task.id}')" class="btn btn-outline py-1 px-3 text-[10px] border-[#333] hover:bg-[#111] hover:border-pink-500 hover:text-pink-500">DEL</button>
                        </div>
                    </div>
                    
                    ${task.showChain ? `
                    <div class="chain-visualizer p-4 rounded-xl mb-5 flex items-center justify-center gap-4 shadow-inner relative z-10">
                        ${parents.length > 0 ? `
                        <div class="flex flex-col gap-2 min-w-[120px]">
                            ${parents.map(p => `<div onclick="document.getElementById('task-card-${p.id}').scrollIntoView({behavior:'smooth'})" class="cursor-pointer text-[10px] font-bold border border-[${p.color}] bg-[${p.color}11] text-white px-3 py-1.5 rounded-lg text-center whitespace-nowrap truncate hover:bg-[${p.color}33] transition-colors"><span class="text-[${p.color}] mr-1">■</span> ${escapeHtml(tmLocalizedTaskText(p, 'name'))}</div>`).join('')}
                        </div>
                        <div class="connector-line"></div>
                        ` : `<div class="text-[9px] uppercase font-black text-dim tracking-widest text-center min-w-[80px]">Start Node</div><div class="connector-line"></div>`}
                        
                        <div class="node-pulse text-[12px] font-bold border-2 px-4 py-2 rounded-lg bg-black text-white whitespace-nowrap z-10 flex flex-col items-center gap-1" style="border-color: ${task.color};">
                            ${(task.taskType === 'root' || task.taskType === 'node' || task.taskType === 'endpoint') ? `<span class="text-[8px] uppercase tracking-widest text-[${task.color}]">${task.taskType}</span>` : ''}
                            <span>${escapeHtml(tmLocalizedTaskText(task, 'name'))}</span>
                        </div>

                        ${children.length > 0 ? `
                        <div class="connector-line"></div>
                        <div class="flex flex-col gap-2 min-w-[120px]">
                            ${children.map(c => `<div onclick="document.getElementById('task-card-${c.id}').scrollIntoView({behavior:'smooth'})" class="cursor-pointer text-[10px] font-bold border border-[${c.color}] bg-[${c.color}11] text-white px-3 py-1.5 rounded-lg text-center whitespace-nowrap truncate hover:bg-[${c.color}33] transition-colors"><span class="text-[${c.color}] mr-1">■</span> ${escapeHtml(tmLocalizedTaskText(c, 'name'))}</div>`).join('')}
                        </div>
                        ` : `<div class="connector-line"></div><div class="text-[9px] uppercase font-black text-dim tracking-widest text-center min-w-[80px]">End Node</div>`}
                    </div>
                    ` : ''}
                </div>

                <div id="entry-text-wrapper-${task.id}" class="hidden group inline-edit-entry w-full mb-4">
                    <!-- Inline edit populated here -->
                </div>
            </div>
            
            <!-- COLLAPSED SUMMARY VIEW -->
            <div class="${task.collapsed ? 'flex' : 'hidden'} justify-between items-end px-5 pb-5 pt-0">
                <div class="text-[10px] text-gray-500 italic truncate max-w-full flex-1 pr-4">${escapeHtml(tmLocalizedTaskText(task, 'desc'))}</div>
                ${task.rewardCondition && task.rewardCondition.key ? `
                    <div class="inline-flex flex-col gap-0.5 bg-[#111] border border-[var(--accent-gold)] px-2 py-1 rounded-md text-right flex-shrink-0">
                        <span class="text-[8px] font-black uppercase text-[var(--accent-gold)] tracking-widest">Reward</span>
                        <span class="text-[10px] text-white font-mono">${escapeHtml(task.rewardCondition.key)} ${escapeHtml(task.rewardCondition.op)} ${escapeHtml(task.rewardCondition.val)}</span>
                    </div>
                ` : ''}
            </div>

            <!-- COLLAPSIBLE REST OF ENTRY -->
            <div class="${task.collapsed ? 'hidden' : 'flex'} flex-col flex-1 px-5 gap-4 mb-4">
                
                <!-- OBJECTIVES ARRAY -->
                <div class="rounded-panel mb-0 shadow-lg w-full tm-objectives-panel ${objectivePanelPulseClass}">
                    <div class="array-header ${subs.objectives ? 'collapsed' : ''}" onclick="toggleSubCategory('${task.id}', 'objectives')">
                        <span class="array-title text-[var(--accent-pink)]">${chevron} OBJECTIVES</span>
                        <button type="button" class="btn-add-array text-pink-500 border-pink-500 hover:bg-pink-500 hover:text-black" onclick="event.stopPropagation(); addMiddleObjective('${task.id}')">+ ADD OBJECTIVE</button>
                    </div>
                    <div class="p-4 ${subs.objectives ? 'hidden' : 'block'} bg-[#1e1e1e]">
                        ${task.objectives && task.objectives.length > 0 ? task.objectives.map((c, i) => generateObjectiveHTML(c, task.id, i, false)).join('') : '<div class="text-[10px] text-gray-500 text-center italic font-bold py-2">No objectives defined.</div>'}
                    </div>
                </div>

                <!-- REWARD SETTINGS BLOCK -->
                ${generateRewardsHTML(task, subs, false)}

                <!-- CORE GAMEPLAY VALUES / SUMMARY -->
                <div class="relative z-10 subcat-container rounded-panel mb-0 shadow-lg w-full">
                    <div class="subcat-header text-[10px] font-black uppercase text-gray-400 tracking-widest mb-4 flex justify-between w-full pr-4 ${subs.summary ? 'collapsed' : ''}">
                        <div class="flex items-center gap-2" onclick="toggleSubCategory('${task.id}', 'summary')">
                            ${chevron} Core Gameplay Values
                        </div>
                        <button class="text-[var(--accent-green)] hover:text-white text-lg font-bold leading-none" onclick="event.stopPropagation(); triggerQuickAddGlobalCgv()" title="Add New Global Value Schema">+</button>
                    </div>
                    <div class="grid grid-cols-2 gap-6 ${subs.summary ? 'hidden' : 'grid'}">
                        ${renderSummaryCond(task.unlockCondition, 'Unlock', 'darkblue', task.id, 'unlockCondition')}
                        ${renderSummaryCond(task.completeCondition, 'Complete', 'green', task.id, 'completeCondition')}
                        ${renderSummaryCond(task.failCondition, 'Fail', 'pink', task.id, 'failCondition')}
                        ${renderSummaryCond(task.rewardCondition, 'Reward', 'gold', task.id, 'rewardCondition')}
                        
                        ${state.globalCustomFields.map(gcf => {
                            const cv = task.customGameplayValues?.find(c => c.fieldId === gcf.id) || { key: gcf.key, op: gcf.op, val: gcf.val, hideVisual: false };
                            return renderSummaryCond(cv, gcf.title, gcf.color, task.id, gcf.id, true);
                        }).join('')}
                    </div>
                </div>

                <!-- DEPENDENCIES & MAPPING -->
                <div class="relative z-10 subcat-container mb-0 rounded-panel w-full">
                    <div class="subcat-header text-[10px] font-black uppercase text-gray-400 tracking-widest mb-3 ${subs.dependencies ? 'collapsed' : ''}" onclick="toggleSubCategory('${task.id}', 'dependencies')">
                        ${chevron} Dependencies & Mapping
                    </div>
                    <div class="${subs.dependencies ? 'hidden' : 'block'}">
                        <label class="flex items-center gap-2 cursor-pointer w-max group">
                            <div class="relative flex items-center justify-center w-4 h-4 border border-gray-600 bg-black rounded group-hover:border-[var(--accent-teal)] transition-colors">
                                <input type="checkbox" class="dep-checkbox" onchange="toggleDepView('${task.id}', this.checked)" ${task.showDeps ? 'checked' : ''}>
                                <div class="absolute inset-0 rounded flex items-center justify-center pointer-events-none transition-colors">
                                    <svg class="hidden w-3 h-3 text-black font-bold pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path></svg>
                                </div>
                            </div>
                            <span class="uppercase font-bold tracking-widest text-[9px] text-dim group-hover:text-white transition-colors">Integrate Task Dependencies</span>
                        </label>

                        <div class="${task.showDeps ? 'block' : 'hidden'} mt-3 bg-[#111] p-3 border border-[#333] rounded-xl shadow-inner">
                            ${task.dependencies.length > 0 ? `
                            <div class="flex flex-wrap gap-2 mb-3">
                                ${task.dependencies.map(depId => {
                                    const dep = state.entries.find(t => t.id === depId);
                                    if(!dep) return '';
                                    return `
                                    <div class="flex items-center gap-2 bg-[#222] border px-2 py-1 rounded-full text-[10px] text-white shadow-sm transition-all hover:bg-[#333]" style="border-color: ${dep.color}60">
                                        <div class="w-2 h-2 rounded-full shadow-[0_0_5px_${dep.color}]" style="background:${dep.color}"></div>
                                        <span class="font-semibold">${escapeHtml(tmLocalizedTaskText(dep, 'name'))}</span>
                                        <button onclick="removeDependency('${task.id}', '${depId}')" class="w-4 h-4 rounded-full flex items-center justify-center bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition-colors ml-1">
                                            <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                        </button>
                                    </div>`
                                }).join('')}
                            </div>
                            ` : `<div class="text-[9px] text-dim font-bold uppercase tracking-widest mb-3 italic">No Dependencies Assigned</div>`}
                            
                            <div class="relative">
                                <select onchange="addDependency('${task.id}', this.value); this.value=''" class="appearance-none bg-[#0a0a0a] text-xs font-semibold p-3 border border-[#444] w-full rounded-lg outline-none focus:border-[var(--accent-teal)] text-slate-300 cursor-pointer custom-scrollbar">
                                    <option value="" class="text-dim">✚ Link Existing Task Node...</option>
                                    ${availableDeps.map(t => `<option value="${t.id}">[ ${t.tab.toUpperCase()} ] ${escapeHtml(t.name)}</option>`).join('')}
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- BRANCH & STORY ARRAY -->
                <div class="rounded-panel mb-0 w-full">
                    <div class="array-header ${subs.branch ? 'collapsed' : ''}" onclick="toggleSubCategory('${task.id}', 'branch')">
                        <span class="array-title text-gray-300">${chevron} BRANCH & STORY</span>
                    </div>
                    <div class="p-4 ${subs.branch ? 'hidden' : 'flex'} gap-4 bg-[#1e1e1e]">
                        <div class="w-1/2 flex flex-col">
                            <label class="text-[9px] font-black uppercase text-gray-500 mb-1 tracking-widest">Branching Rules</label>
                            <select class="cursor-pointer text-xs font-bold text-[var(--accent-teal)] bg-[#111] rounded-lg border-[#444] p-2 outline-none custom-scrollbar" onchange="updateBranchData('${task.id}', 'branchRule', this.value)">
                                <option value="First Valid" ${task.branchRule === 'First Valid' ? 'selected' : ''}>First Valid</option>
                                <option value="Random Valid" ${task.branchRule === 'Random Valid' ? 'selected' : ''}>Random Valid</option>
                                <option value="Best Score" ${task.branchRule === 'Best Score' ? 'selected' : ''}>Best Score</option>
                                <option value="Player Choice" ${task.branchRule === 'Player Choice' ? 'selected' : ''}>Player Choice</option>
                                <option value="All Valid" ${task.branchRule === 'All Valid' ? 'selected' : ''}>All Valid</option>
                            </select>
                        </div>
                        <div class="w-1/2 flex flex-col">
                            <label class="text-[9px] font-black uppercase text-gray-500 mb-1 tracking-widest">Story Beat Type</label>
                            <select class="cursor-pointer text-xs bg-[#111] rounded-lg border-[#444] p-2 outline-none text-white custom-scrollbar" onchange="updateBranchData('${task.id}', 'storyBeatType', this.value)">
                                <option value="Visible Quest Progress" ${task.storyBeatType === 'Visible Quest Progress' ? 'selected' : ''}>Visible Quest Progress</option>
                                <option value="Hidden Story Progress" ${task.storyBeatType === 'Hidden Story Progress' ? 'selected' : ''}>Hidden Story Progress</option>
                                <option value="Leaderboard Progress" ${task.storyBeatType === 'Leaderboard Progress' ? 'selected' : ''}>Leaderboard Progress</option>
                                <option value="Achievement Progress" ${task.storyBeatType === 'Achievement Progress' ? 'selected' : ''}>Achievement Progress</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- TIME RULES ARRAY -->
                <div class="rounded-panel mb-0 w-full">
                    <div class="array-header ${subs.time ? 'collapsed' : ''}" onclick="toggleSubCategory('${task.id}', 'time')">
                        <span class="array-title text-gray-300">${chevron} TIME RULES</span>
                    </div>
                    <div class="p-4 ${subs.time ? 'hidden' : 'grid'} grid-cols-2 gap-4 bg-[#1e1e1e]">
                        <div class="flex flex-col">
                            <label class="text-[9px] font-black uppercase text-gray-500 mb-1 tracking-widest">Day/Time Avail</label>
                            <input type="text" class="text-xs bg-[#111] rounded-lg border-[#444] text-white p-2 outline-none focus:border-[var(--accent-teal)]" value="${escapeHtml(task.timeAvail)}" placeholder="e.g. Day3 14:00" oninput="updateTimeData('${task.id}', 'timeAvail', this.value)">
                        </div>
                        <div class="flex flex-col">
                            <label class="text-[9px] font-black uppercase text-gray-500 mb-1 tracking-widest">Expiration Rule</label>
                            <input type="text" class="text-xs bg-[#111] rounded-lg border-[#444] text-white p-2 outline-none focus:border-[var(--accent-teal)]" value="${escapeHtml(task.timeExpire)}" placeholder="e.g. Day4 00:00" oninput="updateTimeData('${task.id}', 'timeExpire', this.value)">
                        </div>
                        <div class="flex flex-col">
                            <label class="text-[9px] font-black uppercase text-gray-500 mb-1 tracking-widest">Cooldown</label>
                            <input type="text" class="text-xs bg-[#111] rounded-lg border-[#444] text-white p-2 outline-none focus:border-[var(--accent-teal)]" value="${escapeHtml(task.cooldown)}" placeholder="ms/ticks" oninput="updateTimeData('${task.id}', 'cooldown', this.value)">
                        </div>
                        <div class="flex flex-col">
                            <label class="text-[9px] font-black uppercase text-gray-500 mb-1 tracking-widest">Repeat Interval</label>
                            <input type="text" class="text-xs bg-[#111] rounded-lg border-[#444] text-white p-2 outline-none focus:border-[var(--accent-teal)]" value="${escapeHtml(task.repeatInterval)}" placeholder="ms/ticks" oninput="updateTimeData('${task.id}', 'repeatInterval', this.value)">
                        </div>
                    </div>
                </div>

                <!-- TAGS ARRAY -->
                <div class="rounded-panel mb-0 w-full">
                    <div class="array-header ${subs.tags ? 'collapsed' : ''}" onclick="toggleSubCategory('${task.id}', 'tags')">
                        <span class="array-title text-gray-300">${chevron} TAGS</span>
                        <button type="button" class="btn-add-array" onclick="event.stopPropagation(); openAddTagModal('${task.id}')">+ ADD TAG</button>
                    </div>
                    <div class="p-4 ${subs.tags ? 'hidden' : 'flex'} flex-wrap gap-2 bg-[#1e1e1e]">
                        ${task.tags && task.tags.length > 0 ? task.tags.map((t, i) => `
                            <span class="bg-[#222] border border-[#444] text-gray-300 px-3 py-1.5 rounded-lg text-[10px] flex items-center gap-2 shadow-sm font-bold tracking-wider">
                                ${escapeHtml(t)}
                                <button onclick="removeTag('${task.id}', ${i})" class="text-red-500 hover:text-white remove-tag-btn font-black ml-1 text-xs">✕</button>
                            </span>
                        `).join('') : '<div class="text-[10px] text-gray-500 italic font-bold text-center w-full py-2">No tags appended. Use Left Panel to add.</div>'}
                    </div>
                </div>

                <!-- STATE CHANGES ARRAY (DARKER) -->
                <div class="rounded-panel darker-panel mb-0 shadow-lg w-full">
                    <div class="array-header ${subs.stateChanges ? 'collapsed' : ''}" onclick="toggleSubCategory('${task.id}', 'stateChanges')">
                        <span class="array-title">${chevron} CHANGE GAME STATE</span>
                        <button type="button" class="btn-add-array" onclick="event.stopPropagation(); addLogicRow('${task.id}', 'stateChanges')">+ ADD STATE CHANGE</button>
                    </div>
                    <div class="p-4 ${subs.stateChanges ? 'hidden' : 'block'} bg-transparent">
                        ${task.stateChanges && task.stateChanges.length > 0 ? task.stateChanges.map((c, i) => `
                            <div class="array-row">
                                <input type="text" value="${escapeHtml(c.key)}" oninput="updateLogicArray('${task.id}', 'stateChanges', ${i}, 'key', this.value)" class="bg-[#111] border-[#444] rounded-lg text-white">
                                <select class="cursor-pointer bg-[#111] border-[#444] rounded-lg text-white w-20 custom-scrollbar" onchange="updateLogicArray('${task.id}', 'stateChanges', ${i}, 'op', this.value)">
                                    <option ${c.op==='=='?'selected':''}>==</option><option ${c.op==='='?'selected':''}>=</option>
                                    <option ${c.op==='+='?'selected':''}>+=</option><option ${c.op==='-='?'selected':''}>-=</option>
                                </select>
                                <input type="text" value="${escapeHtml(c.val)}" oninput="updateLogicArray('${task.id}', 'stateChanges', ${i}, 'val', this.value)" class="bg-[#111] border-[#444] rounded-lg text-white">
                                <button class="btn-array-del" onclick="removeLogicRow('${task.id}', 'stateChanges', ${i})">✕</button>
                            </div>
                        `).join('') : '<div class="text-[10px] text-gray-500 text-center italic font-bold py-2">No state changes defined.</div>'}
                    </div>
                </div>

            </div>
        </div>
        `;
    }).join('');

    outHtml += `<div class="mt-6 mb-20 flex justify-center w-full"><button class="btn btn-teal px-8 py-3 font-black tracking-widest rounded-xl text-xs shadow-[0_0_15px_rgba(0,242,255,0.3)]" onclick="createNewEntryUI()">+ ADD NEW ENTRY</button></div>`;
    container.innerHTML = outHtml;

    restoreFocus();
}

function renderTasks() {
    renderTasksSilently();
}

function focusEntryUI(id, scrollToIt = false, isFromScroll = false) {
    if (state.focusedEntryId !== id) {
        if (!isFromScroll) {
            state.prevFocusedEntryId = state.focusedEntryId;
        }
        state.focusedEntryId = id;
    }
    
    document.querySelectorAll('.editor-wrapper').forEach(el => el.classList.remove('focused'));
    const card = document.getElementById(`task-card-${id}`);
    if(card) {
        card.classList.add('focused');
        if (scrollToIt) {
            setScrollBlock(); 
            card.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
    
    const entry = state.entries.find(e => e.id === id);
    if(entry) populateFormForTask(entry);
    
    renderMinimap();
}

function syncMinimap() {
    if (isScrollingProgrammatically) return;
    
    const container = document.getElementById('mainScrollArea');
    const cards = Array.from(container.querySelectorAll('.editor-wrapper'));
    if(cards.length === 0) return;

    let closest = cards[0];
    let minDistance = Infinity;
    
    const containerRect = container.getBoundingClientRect();
    const targetY = containerRect.top + 150; 

    cards.forEach(card => {
        const rect = card.getBoundingClientRect();
        const distance = Math.abs(rect.top - targetY);
        if(distance < minDistance) {
            minDistance = distance;
            closest = card;
        }
    });

    const newId = closest.id.replace('task-card-', '');
    if(newId !== state.focusedEntryId) {
        focusEntryUI(newId, false, true);
    }
}

function renderMinimap() {
    const mm = document.getElementById('minimap-container');
    if (!mm) return;
    const currentList = state.entries.filter(e => {
        if (e.tab !== state.activeTab) return false;
        const search = document.getElementById('search').value.toLowerCase();
        if (!search) return true;
        return e.name.toLowerCase().includes(search) || 
               e.id.toLowerCase().includes(search) || 
               e.desc.toLowerCase().includes(search) || 
               (e.chainName && e.chainName.toLowerCase().includes(search)) ||
               (e.tags && e.tags.some(t => t.toLowerCase().includes(search)));
    });

    if (currentList.length === 0) { mm.innerHTML = ''; return; }
    
    let html = '';
    currentList.forEach((entry, idx) => {
        let isFocused = entry.id === state.focusedEntryId;
        let isPrev = entry.id === state.prevFocusedEntryId && !isFocused;
        let isEdited = state.editedNodes.has(entry.id) && !isFocused && !isPrev;
        
        if (!isFocused && !isPrev && !isEdited) return;
        
        let bg = isFocused ? 'bg-white text-black z-50' : 
                 isPrev ? 'bg-[var(--accent-teal)] text-black z-40' : 
                 'bg-[var(--accent-orange)] text-black z-30';
        
        let topPercent = currentList.length > 1 ? (idx / (currentList.length - 1)) * 100 : 0;
        let offset = topPercent === 100 ? 20 : topPercent === 0 ? 0 : 10;
        
        html += `<div class="absolute left-1 w-6 h-5 flex items-center justify-center text-[9px] font-black rounded-sm shadow-md cursor-pointer transition-all border border-[#000] ${bg}" style="top: calc(${topPercent}% - ${offset}px);" onclick="focusEntryUI('${entry.id}', true)">${idx + 1}</div>`;
    });
    mm.innerHTML = html;
}

function renderSidebarCgvList() {
    const container = document.getElementById('sidebarCgvList');
    if (!container) return;
    if (!state.globalCustomFields || state.globalCustomFields.length === 0) {
        container.innerHTML = '<div class="text-[9px] text-gray-600 italic">No global values defined.</div>';
        return;
    }
    
    const safeHtml = typeof escapeHtml === 'function' ? escapeHtml : (t) => t;
    
    container.innerHTML = state.globalCustomFields.map(c => `
        <div class="condition-block group/cgv mt-0 mb-2 relative rounded-lg border-[#333]" style="border-left: 3px solid ${c.color};">
            <div class="absolute top-1 right-1 flex gap-1 opacity-0 group-hover/cgv:opacity-100 transition-opacity z-10">
                <button type="button" onclick="editGlobalCgv('${c.id}')" class="text-gray-500 hover:text-green-500 text-[10px] bg-[#111] border border-[#333] p-1 rounded" title="Edit Schema">✏️</button>
                <button type="button" onclick="deleteGlobalCgv('${c.id}')" class="text-gray-500 hover:text-red-500 text-[10px] bg-[#111] border border-[#333] p-1 rounded" title="Delete Schema">🗑</button>
            </div>
            <label class="text-[9px] font-black uppercase block mb-2 w-[85%] truncate" style="color: ${c.color};">${safeHtml(c.title)}</label>
            <div class="condition-row-static opacity-80 pointer-events-none">
                <input type="text" value="${safeHtml(c.key)}" readonly class="p-2 text-[10px] placeholder="KEY" rounded bg-black>
                <div class="flex items-center justify-center text-[10px] font-mono text-gray-500">${c.op}</div>
                <input type="text" value="${safeHtml(c.val)}" readonly class="p-2 text-[10px] placeholder="VAL" rounded bg-black>
            </div>
        </div>
    `).join('');
}

function renderAuthorObjectives() {
    saveFocus();
    const container = document.getElementById('authorObjectivesContainer');
    const id = document.getElementById('taskId').value;
    const entry = state.entries.find(e => e.id === id);
    if (!container) return;
    
    if(!entry || !entry.objectives || entry.objectives.length === 0) {
        container.innerHTML = '<div class="text-[10px] text-gray-500 italic text-center py-2">No Objectives Configured</div>';
        restoreFocus();
        return;
    }

    container.innerHTML = entry.objectives.map((obj, i) => generateObjectiveHTML(obj, id, i, true)).join('');
    restoreFocus();
}

function renderAuthorConditions() {
    const container = document.getElementById('authorConditionsContainer');
    if (!container) return;
    const entry = state.entries.find(e => e.id === state.focusedEntryId);
    if(!entry || !entry.conditions || entry.conditions.length === 0) {
        container.innerHTML = '<div class="text-[10px] text-gray-500 italic text-center py-2">No Conditions Defined</div>'; return;
    }
    container.innerHTML = entry.conditions.map((c, i) => `
        <div class="flex flex-col gap-1 p-2 bg-[#111] border border-[#333] rounded-xl shadow-inner">
            <div class="flex justify-between items-center mb-1">
                <span class="text-[8px] text-[var(--accent-teal)] font-black uppercase">Condition #${i+1}</span>
                <button type="button" class="text-pink-500 font-black text-xs" onclick="removeLogicRow('${entry.id}', 'conditions', ${i})">✕</button>
            </div>
            <div class="flex gap-1 mb-1">
                <select class="text-[9px] p-1 cursor-pointer bg-[#0a0a0a] border-[#444] rounded text-white w-1/3 custom-scrollbar" onchange="updateLogicArray('${entry.id}', 'conditions', ${i}, 'context', this.value)">
                    <option value="Standard" ${c.context==='Standard'||!c.context?'selected':''}>Standard</option>
                    <option value="Visibility" ${c.context==='Visibility'?'selected':''}>Visibility</option>
                    <option value="Eligibility" ${c.context==='Eligibility'?'selected':''}>Eligibility</option>
                    <option value="Auto-Fail" ${c.context==='Auto-Fail'?'selected':''}>Auto-Fail</option>
                </select>
                <input type="text" class="text-[9px] p-1.5 w-2/3 bg-[#0a0a0a] border-[#444] rounded text-white" value="${escapeHtml(c.key)}" oninput="updateLogicArray('${entry.id}', 'conditions', ${i}, 'key', this.value)" placeholder="Key">
            </div>
            <div class="flex gap-2">
                <select class="text-xs w-1/3 bg-[#0a0a0a] rounded border-[#444] text-white cursor-pointer custom-scrollbar" onchange="updateLogicArray('${entry.id}', 'conditions', ${i}, 'op', this.value)">
                    <option ${c.op==='=='?'selected':''}>==</option><option ${c.op==='!='?'selected':''}>!=</option>
                    <option ${c.op==='>'?'selected':''}>></option><option ${c.op==='<'?'selected':''}>&lt;</option>
                    <option ${c.op==='>='?'selected':''}>>=</option><option ${c.op==='<='?'selected':''}>&lt;=</option>
                </select>
                <input type="text" class="text-xs w-2/3 bg-[#0a0a0a] rounded border-[#444] text-white" value="${escapeHtml(c.val)}" oninput="updateLogicArray('${entry.id}', 'conditions', ${i}, 'val', this.value)" placeholder="Value">
            </div>
        </div>
    `).join('');
}

function renderAuthorStateChanges() {
    const container = document.getElementById('authorStateChangesContainer');
    if (!container) return;
    const entry = state.entries.find(e => e.id === state.focusedEntryId);
    if(!entry || !entry.stateChanges || entry.stateChanges.length === 0) {
        container.innerHTML = '<div class="text-[10px] text-gray-500 italic text-center py-2">No State Changes Defined</div>'; return;
    }
    container.innerHTML = entry.stateChanges.map((c, i) => `
        <div class="flex flex-col gap-1 p-2 bg-[#111] border border-[#333] rounded-xl shadow-inner">
            <div class="flex justify-between items-center mb-1">
                <span class="text-[8px] text-[var(--accent-orange)] font-black uppercase">State Change #${i+1}</span>
                <button type="button" class="text-pink-500 font-black text-xs" onclick="removeLogicRow('${entry.id}', 'stateChanges', ${i})">✕</button>
            </div>
            <input type="text" class="text-xs w-full bg-[#0a0a0a] rounded border-[#444] text-white" value="${escapeHtml(c.key)}" oninput="updateLogicArray('${entry.id}', 'stateChanges', ${i}, 'key', this.value)" placeholder="Key">
            <div class="flex gap-2">
                <select class="text-xs w-1/3 bg-[#0a0a0a] rounded border-[#444] text-white cursor-pointer custom-scrollbar" onchange="updateLogicArray('${entry.id}', 'stateChanges', ${i}, 'op', this.value)">
                    <option ${c.op==='=='?'selected':''}>==</option><option ${c.op==='='?'selected':''}>=</option>
                    <option ${c.op==='+='?'selected':''}>+=</option><option ${c.op==='-='?'selected':''}>-=</option>
                </select>
                <input type="text" class="text-xs w-2/3 bg-[#0a0a0a] rounded border-[#444] text-white" value="${escapeHtml(c.val)}" oninput="updateLogicArray('${entry.id}', 'stateChanges', ${i}, 'val', this.value)" placeholder="Value">
            </div>
        </div>
    `).join('');
}

function renderAuthorCgv() {
    const container = document.getElementById('authorCgvContainer');
    if (!container) return;
    const entry = state.entries.find(e => e.id === state.focusedEntryId);
    if(!entry || !state.globalCustomFields.length) {
        container.innerHTML = '<div class="text-[10px] text-gray-500 italic text-center py-2">No Core Values Initialized</div>'; return;
    }
    container.innerHTML = state.globalCustomFields.map(gcf => {
        const cv = entry.customGameplayValues?.find(c => c.fieldId === gcf.id) || { key: gcf.key, op: gcf.op, val: gcf.val, hideVisual: false };
        return `
            <div class="flex flex-col gap-1 p-2 bg-[#111] border border-[#333] rounded-xl border-l-4 shadow-inner" style="border-left-color: ${gcf.color}">
                <div class="text-[9px] font-black uppercase tracking-widest mb-1" style="color: ${gcf.color}">${escapeHtml(gcf.title)}</div>
                <input type="text" class="text-xs w-full bg-[#0a0a0a] rounded border-[#444] text-white" value="${escapeHtml(cv.key)}" oninput="updateCgvOverride('${entry.id}', '${gcf.id}', 'key', this.value)" placeholder="Key">
                <div class="flex gap-2">
                    <select class="text-xs w-1/3 bg-[#0a0a0a] rounded border-[#444] text-white cursor-pointer custom-scrollbar" onchange="updateCgvOverride('${entry.id}', '${gcf.id}', 'op', this.value)">
                        <option ${cv.op==='=='?'selected':''}>==</option><option ${cv.op==='>='?'selected':''}>>=</option>
                        <option ${cv.op==='<='?'selected':''}><=</option><option ${cv.op==='>'?'selected':''}>></option>
                        <option ${cv.op==='<'?'selected':''}><</option><option ${cv.op==='='?'selected':''}>=</option>
                        <option ${cv.op==='+='?'selected':''}>+=</option><option ${cv.op==='-='?'selected':''}>-=</option>
                    </select>
                    <input type="text" class="text-xs w-2/3 bg-[#0a0a0a] rounded border-[#444] text-white" value="${escapeHtml(cv.val)}" oninput="updateCgvOverride('${entry.id}', '${gcf.id}', 'val', this.value)" placeholder="Value">
                </div>
            </div>
        `;
    }).join('');
}

function renderAuthorDependencies() {
    const container = document.getElementById('authorDependenciesContainer');
    const select = document.getElementById('authorAddDepSelect');
    if (!container || !select) return;
    const entry = state.entries.find(e => e.id === state.focusedEntryId);
    
    if(!entry) return;

    if(entry.dependencies && entry.dependencies.length > 0) {
        container.innerHTML = entry.dependencies.map(depId => {
            const dep = state.entries.find(t => t.id === depId);
            if(!dep) return '';
            return `
            <div class="flex items-center justify-between bg-[#111] border border-[#333] px-2 py-2 rounded-xl" style="border-left: 3px solid ${dep.color}">
                <div class="flex flex-col">
                    <span class="text-[8px] font-black uppercase text-gray-500">[${escapeHtml(dep.tab)}]</span>
                    <span class="text-[10px] font-bold text-white leading-none mt-1 truncate max-w-[200px]">${escapeHtml(tmLocalizedTaskText(dep, 'name'))}</span>
                </div>
                <button type="button" onclick="removeDependency('${entry.id}', '${depId}')" class="text-pink-500 hover:text-white font-black text-xs px-2">✕</button>
            </div>`;
        }).join('');
    } else {
        container.innerHTML = '<div class="text-[10px] text-gray-500 italic text-center py-2">No Dependencies Assigned</div>';
    }

    const availableDeps = state.entries.filter(t => t.id !== entry.id && !(entry.dependencies||[]).includes(t.id));
    select.innerHTML = '<option value="">✚ Link New Node...</option>' + availableDeps.map(t => `<option value="${t.id}">[ ${t.tab.toUpperCase()} ] ${escapeHtml(t.name)}</option>`).join('');
}

function renderSidebar() {
    const container = document.getElementById('logicTagList');
    if (!container) return;
    const searchInput = document.getElementById('tagSearchInput');
    const search = searchInput ? searchInput.value.toLowerCase() : '';
    const keys = Object.keys(state.globalTags).sort();
    
    if (keys.length === 0) {
        container.innerHTML = `<div class="p-6 text-center text-xs text-gray-600 italic">No project data generated.</div>`;
        return;
    }

    let gameplayHtml = '';
    let logicHtml = '';
    
    const specificGameplayKeys = ['trust', 'lust', 'friendship', 'suspicion'];

    keys.forEach(key => {
        if(search && !key.toLowerCase().includes(search)) return;
        
        const data = state.globalTags[key];
        const condC = data.conds.length;
        const stateC = data.states.length;
        const gpC = data.gameplay.length;

        const total = condC + stateC + gpC;
        const lowerKey = key.toLowerCase();

        let isGameplay = false;
        let tagType = 'tag-mixed'; 
        
        if(specificGameplayKeys.includes(lowerKey)) {
            isGameplay = true;
            tagType = `tag-${lowerKey}`;
        } else if (gpC > 0 && condC === 0 && stateC === 0) {
            isGameplay = true;
            const entry = state.entries.find(e => 
                e.unlockCondition?.key === key || 
                e.completeCondition?.key === key || 
                e.failCondition?.key === key || 
                e.rewardCondition?.key === key ||
                (e.customGameplayValues && e.customGameplayValues.some(c => c.key === key))
            );
            if(entry) {
                if(entry.unlockCondition?.key === key) tagType = 'tag-unlock';
                else if(entry.completeCondition?.key === key) tagType = 'tag-complete';
                else if(entry.failCondition?.key === key) tagType = 'tag-fail';
                else if(entry.rewardCondition?.key === key) tagType = 'tag-reward';
            }
        } else {
            if (condC > 0 && stateC === 0) tagType = 'tag-green';
            else if (stateC > 0 && condC === 0) tagType = 'tag-blue';
            else tagType = 'tag-purple';
        }

        const itemHtml = `
        <div class="sidebar-tag ${tagType}" onclick="openTagModal('${escapeHtml(key)}')">
            <div class="flex items-center">
                <span class="text-white font-bold text-sm ml-2 tracking-wide">${escapeHtml(key)} <span class="text-gray-500 mx-1">==</span> 1</span>
            </div>
            <span class="text-[10px] text-gray-500 font-bold">[${total}]</span>
        </div>
        `;

        if(isGameplay) gameplayHtml += itemHtml;
        else logicHtml += itemHtml;
    });
    
    let finalHtml = '';

    if(logicHtml) {
        finalHtml += `
        <div class="py-2 px-5 bg-[#050505] border-y border-[var(--border-color)]">
            <h4 class="text-[10px] font-black uppercase text-gray-500 tracking-widest">Logic Variables</h4>
        </div>
        ${logicHtml}`;
    }

    if(gameplayHtml) {
        finalHtml += `
        <div class="py-2 px-5 bg-[#050505] border-y border-[var(--border-color)]">
            <h4 class="text-[10px] font-black uppercase text-gray-500 tracking-widest">Gameplay Values</h4>
        </div>
        ${gameplayHtml}`;
    }

    container.innerHTML = finalHtml || `<div class="p-6 text-center text-xs text-gray-600 italic">No matching tags.</div>`;
}

function renderSummaryCond(cond, label, color, taskId, condType, isCustom = false) {
    if (!cond || cond.hideVisual) return ''; 
    if (!isCustom && (!cond.key || cond.key === 'Null')) {
        return `
        <div class="flex flex-col gap-1 inline-edit-wrapper" id="inline-wrapper-${taskId}-${condType}">
            <span class="text-[9px] font-black uppercase tracking-widest text-[#444] cursor-pointer hover:text-gray-300 transition-colors w-max mt-[14px] inline-edit-trigger" ondblclick="startInlineEditCond('${taskId}', '${condType}', '${label}')" title="Double click to quick add">EMPTY ${label}</span>
        </div>`;
    }
    
    const colorStyle = color.startsWith('#') ? `color: ${color}` : `color: var(--accent-${color})`;

    return `
        <div class="flex flex-col gap-1 inline-edit-wrapper group/cgv relative" id="inline-wrapper-${taskId}-${condType}">
            <button class="hidden group-hover/cgv:flex absolute -top-2 -right-2 bg-[#111] border border-red-500 text-red-500 rounded-full w-5 h-5 items-center justify-center text-[10px] font-bold z-20 cursor-pointer shadow-lg hover:bg-red-500 hover:text-white transition-colors" onclick="event.stopPropagation(); hideGameplayValueVisual('${taskId}', '${condType}', ${isCustom})" title="Remove from visuals">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
            </button>
            <span class="text-[10px] font-black uppercase tracking-widest truncate" style="${colorStyle}">${escapeHtml(label)}</span>
            <span class="bg-[#111] px-3 py-2 text-[11px] font-mono text-slate-300 border border-[#333] rounded-lg flex flex-wrap items-center gap-x-2 gap-y-1 cursor-pointer hover:border-gray-500 transition-colors w-full break-all relative overflow-hidden inline-edit-trigger shadow-sm" ondblclick="startInlineEditCond('${taskId}', '${condType}', '${label}', ${isCustom})" title="Double click to edit">
                <span class="text-white flex-shrink break-all">${escapeHtml(cond.key)}</span> 
                <span style="${colorStyle}" class="flex-shrink-0 font-black">${cond.op}</span> 
                <span class="text-white flex-shrink break-all">${escapeHtml(cond.val)}</span>
            </span>
        </div>
    `;
}

function populateFormForTask(task) {
    if (!task) return;

    document.getElementById('taskId').value = task.id;
    
    // Identity
    document.getElementById('taskName').value = tmLocalizedTaskText(task, 'name');
    document.getElementById('taskDisplayId').value = task.displayId || '';
    document.getElementById('taskDisplayName').value = tmLocalizedTaskText(task, 'displayName');
    document.getElementById('taskNamespace').value = task.namespace || '';
    document.getElementById('taskTags').value = (task.tags || []).join(', ');

    // The Cast
    const giverInput = document.getElementById('taskGiver');
    if (giverInput) giverInput.value = task.questGiver || '';
    const turnInInput = document.getElementById('taskTurnIn');
    if (turnInInput) turnInInput.value = task.turnIn || '';
    const cbShowGiver = document.getElementById('cbShowGiver');
    if (cbShowGiver) cbShowGiver.checked = task.showGiver || false;
    const cbShowTurnIn = document.getElementById('cbShowTurnIn');
    if (cbShowTurnIn) cbShowTurnIn.checked = task.showTurnIn || false;
    const factionInput = document.getElementById('taskFaction');
    if (factionInput) factionInput.value = task.faction || '';

    // Presentation
    document.getElementById('taskDesc').value = tmLocalizedTaskText(task, 'desc');
    document.getElementById('taskCompletionText').value = tmLocalizedTaskText(task, 'completionText');
    document.getElementById('taskFailureText').value = tmLocalizedTaskText(task, 'failureText');
    document.getElementById('taskIconSelect').value = task.chainEmoji || '🔮';

    const taskColorInput = document.getElementById('taskColor');
    const taskColorDisplay = document.getElementById('taskColorDisplay');
    if (taskColorInput) {
        taskColorInput.value = task.color || getRandomColor();
        taskColorDisplay.innerText = taskColorInput.value.toUpperCase();
        taskColorDisplay.style.color = taskColorInput.value;
    }

    // Lifecycle
    document.getElementById('registrySelect').value = task.tab;
    document.getElementById('taskType').value = task.taskType || 'Task';
    document.getElementById('taskInitialState').value = task.initialState || 'Locked';
    document.getElementById('cbAutoUnlock').checked = task.autoUnlock || false;
    document.getElementById('cbAutoStart').checked = task.autoStart || false;
    document.getElementById('cbAutoComplete').checked = task.autoComplete || false;
    document.getElementById('cbRepeatable').checked = task.repeatable || false;
    document.getElementById('cbResettable').checked = task.resettable || false;
    document.getElementById('cbBranchExclusive').checked = task.branchExclusive || false;
    
    if(typeof handleTaskTypeChange === 'function') handleTaskTypeChange();

    // Branch & Story
    document.getElementById('taskBranchRule').value = task.branchRule || 'First Valid';
    document.getElementById('taskStoryBeatType').value = task.storyBeatType || 'Visible Quest Progress';

    // Time Rules
    document.getElementById('taskTimeAvail').value = task.timeAvail || '';
    document.getElementById('taskTimeExpire').value = task.timeExpire || '';
    document.getElementById('taskCooldown').value = task.cooldown || '';
    document.getElementById('taskRepeatInterval').value = task.repeatInterval || '';
    
    const cbIsTimed = document.getElementById('cbIsTimed');
    if (cbIsTimed) {
        cbIsTimed.checked = task.isTimed || false;
        const timedBlocks = document.getElementById('timedEventBlocks');
        if (timedBlocks) timedBlocks.classList.toggle('hidden', !cbIsTimed.checked);
    }
    const limitInput = document.getElementById('taskTimeLimit');
    if (limitInput) limitInput.value = task.timeLimit || '';
    const displayInput = document.getElementById('taskTimerDisplay');
    if (displayInput) displayInput.value = task.timerDisplay || 'Hidden (Background)';
    const expireInput = document.getElementById('taskOnExpire');
    if (expireInput) expireInput.value = task.onExpire || 'Auto-Fail Quest';

    // Chain Config
    if (task.chainColor && typeof setChainColor === 'function') setChainColor(task.chainColor);
    else if(typeof setChainColor === 'function') setChainColor(getRandomColor());
    document.getElementById('chainDescInput').value = tmLocalizedTaskText(task, 'chainDesc');
    
    if (task.taskType === 'root') {
        document.getElementById('chainNameInput').value = tmLocalizedTaskText(task, 'chainName');
    } else if (task.taskType === 'node' || task.taskType === 'endpoint') {
        document.getElementById('chainNameSelect').value = task.chainName || '';
    }

    const setCond = (prefix, data) => {
        document.getElementById(`${prefix}Key`).value = data?.key || '';
        document.getElementById(`${prefix}Op`).value = data?.op || '==';
        document.getElementById(`${prefix}Val`).value = data?.val || '';
    };

    setCond('unlock', task.unlockCondition);
    setCond('complete', task.completeCondition);
    setCond('fail', task.failCondition);
    setCond('reward', task.rewardCondition);

    // Populate Authors Dynamic Arrays
    renderAuthorObjectives();
    renderAuthorConditions();
    renderAuthorStateChanges();
    renderAuthorCgv();
    renderAuthorDependencies();
    if(typeof renderAuthorMapAnchors === 'function') renderAuthorMapAnchors();
    if(typeof renderAuthorMediaHooks === 'function') renderAuthorMediaHooks();

    const cgvGen = document.getElementById('cgvGenerator');
    if(cgvGen) cgvGen.classList.add('hidden');
    
    const editorTitle = document.getElementById('editorTitle');
    if(editorTitle) {
        editorTitle.innerHTML = `
            <div class="flex justify-between items-center w-full">
                <span>EDIT INITIALIZED DATA</span>
                <button type="button" onclick="typeof openDuplicateModal === 'function' ? openDuplicateModal('${task.id}') : null" class="btn btn-outline py-1 px-2 text-[10px] border-[var(--accent-teal)] text-[var(--accent-teal)] hover:bg-[var(--accent-teal)] hover:text-black shadow-[0_0_10px_rgba(0,242,255,0.15)] rounded" title="Duplicate Entry">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                </button>
            </div>
        `;
    }
    
    const submitBtn = document.getElementById('submitBtn');
    if(submitBtn) submitBtn.innerText = 'UPDATE NODE';
    if(typeof tmRenderFormTextToolbars === 'function') tmRenderFormTextToolbars();
}

const _tcInput = document.getElementById('taskColor');
const _tcDisplay = document.getElementById('taskColorDisplay');
if (_tcInput && _tcDisplay) {
    _tcInput.addEventListener('input', (e) => {
        _tcDisplay.innerText = e.target.value.toUpperCase();
        _tcDisplay.style.color = e.target.value;
    });
}
// -----------------------------------------------------------------------------
// ORIGINAL-STYLE VALUES / ACCOUNT UI INJECTION
// -----------------------------------------------------------------------------
function tmSvgCopy() { return '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>'; }
function tmCopyText(value) { navigator.clipboard?.writeText(String(value || '')); showNotification('Copied'); }
function tmSvgRefresh(){return '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10"></path><path d="M20.49 15a9 9 0 0 1-14.85 3.36L1 14"></path></svg>';}
function tmSvgDownload(){return '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>';}
function tmSvgPaste(){return '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path><rect x="8" y="2" width="8" height="4" rx="1"></rect><path d="M8 12h8"></path><path d="M8 16h5"></path></svg>';}
function tmSvgUpload(){return '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 16 12 12 8 16"></polyline><line x1="12" y1="12" x2="12" y2="21"></line><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"></path><polyline points="16 5 12 1 8 5"></polyline></svg>';}
function tmSvgApply(){return '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="8 17 12 21 16 17"></polyline><line x1="12" y1="12" x2="12" y2="21"></line><path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"></path></svg>';}

function tmInjectBaseUi() {
    const headerRight = document.querySelector('.header > .flex.gap-4.items-center');
    if (headerRight && !document.getElementById('tmAccountBtn')) {
        const importBtn = headerRight.querySelector('.btn-import');
        const exportBtn = headerRight.querySelector('.btn-export');
        if (importBtn) importBtn.classList.add('tm-header-action');
        if (exportBtn) exportBtn.classList.add('tm-header-action');
        const push = document.createElement('button');
        push.id = 'tmPushServerBtn';
        push.className = 'tm-push-server-btn';
        push.type = 'button';
        push.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5"></path><path d="M5 12l7-7 7 7"></path><path d="M5 19h14"></path></svg><span>Push To Server</span>';
        push.onclick = tmSaveSession;
        const acct = document.createElement('button');
        acct.id = 'tmAccountBtn';
        acct.className = 'account-management-button';
        acct.type = 'button';
        acct.title = 'Manage Account';
        acct.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/></svg>';
        acct.onclick = tmOpenAccountModal;
        const importBtnNode = headerRight.querySelector('.btn-import');
        const stack = headerRight.querySelector('.global-toggle-stack');
        headerRight.insertBefore(push, importBtnNode || stack || null);
        headerRight.insertBefore(acct, stack || null);
    }
    const editor = document.getElementById('editorContainer');
    if (editor && !document.getElementById('tmSidebarTabs')) {
        const tabs = document.createElement('div');
        tabs.id = 'tmSidebarTabs';
        tabs.className = 'tm-sidebar-tabs';
        tabs.innerHTML = '<button id="tmMetaTabBtn" class="tm-side-tab active" type="button" onclick="tmSetSidebarMode(\'metadata\')">Metadata</button><button id="tmValuesTabBtn" class="tm-side-tab" type="button" onclick="tmSetSidebarMode(\'values\')">Values</button>';
        editor.insertBefore(tabs, editor.firstChild);
        const values = document.createElement('div');
        values.id = 'tmValuesPanel';
        values.className = 'tm-values-panel hidden';
        editor.appendChild(values);
    }
    const db = document.querySelector('.database-search-section');
    if (db) {
        db.classList.add('tm-task-database-section');
        const title = document.getElementById('tmTaskDatabaseLabel') || db.querySelector('.text-\[var\(--accent-purple\)\]');
        if (title) title.textContent = 'TASK DATABASE';
        if (!document.getElementById('tmTaskLanguageSelect')) {
            const first = db.querySelector('.flex-1') || db;
            const oldTitle = first.querySelector('.text-\[var\(--accent-purple\)\]');
            if (oldTitle && oldTitle.id !== 'tmTaskDatabaseLabel') oldTitle.remove();
            const topLine = document.createElement('div');
            topLine.className = 'tm-task-db-topline';
            topLine.innerHTML = '<div id="tmTaskDatabaseLabel" class="text-[var(--accent-purple)] font-black text-sm uppercase tracking-widest">TASK DATABASE</div><div id="tmTaskLanguageBox" class="tm-db-language-box"><label for="tmTaskLanguageSelect">Language</label><select id="tmTaskLanguageSelect" class="custom-scrollbar" onchange="tmSetCurrentLanguage(this.value)"><option value="ENG">ENG</option></select><button type="button" onclick="tmShowAddLanguageInline()" title="Add Language">+</button><div id="tmTaskLanguageInline" class="tm-db-language-inline hidden"><input id="tmTaskLanguageInput" type="text" placeholder="CODE"><button type="button" onclick="tmConfirmAddLanguageInline()">✓</button><button type="button" onclick="tmCancelAddLanguageInline()">×</button></div></div>';
            first.insertBefore(topLine, first.firstChild);
        }
        const langBox = document.getElementById('tmTaskLanguageBox');
        if (langBox) {
            const addBtn = langBox.querySelector('button[title="Add Language"]');
            if (addBtn) addBtn.setAttribute('onclick', 'tmShowAddLanguageInline()');
            if (!document.getElementById('tmTaskLanguageInline')) {
                langBox.insertAdjacentHTML('beforeend', '<div id="tmTaskLanguageInline" class="tm-db-language-inline hidden"><input id="tmTaskLanguageInput" type="text" placeholder="CODE"><button type="button" onclick="tmConfirmAddLanguageInline()">✓</button><button type="button" onclick="tmCancelAddLanguageInline()">×</button></div>');
            }
        }
    }
    if (!document.getElementById('tmAccountModal')) {
        document.body.insertAdjacentHTML('beforeend', `<div id="tmAccountModal" class="modal-overlay account-modal-overlay" style="display:none;">
            <div class="modal-content account-modal-content select-text"><div class="flex justify-between items-center p-5 border-b border-[var(--border-color)]"><h2 class="text-sm font-black uppercase tracking-widest text-white">Manage Account</h2><button onclick="tmCloseAccountModal()" class="text-gray-500 hover:text-white font-bold text-xl">✕</button></div><div id="tmAccountBody" class="p-6"></div></div></div>`);
    }
    const accountButton = document.getElementById('tmAccountBtn');
    if (accountButton) accountButton.onclick = tmOpenAccountModal;
}
function tmSetSidebarMode(mode) {
    const meta = mode !== 'values';
    document.querySelectorAll('#editorContainer > .bg\\[\\#111\\], #editorContainer > .p-\\[15px\\]').forEach(el => el.classList.toggle('hidden', !meta));
    const vals = document.getElementById('tmValuesPanel');
    if (vals) vals.classList.toggle('hidden', meta);
    document.getElementById('tmMetaTabBtn')?.classList.toggle('active', meta);
    document.getElementById('tmValuesTabBtn')?.classList.toggle('active', !meta);
    if (!meta) tmRenderValuesTab();
}

function tmValueListSection(title, collection, placeholder, colorId, defaultColor, buttonLabel) {
    const values = tmEnsureValues();
    const items = values[collection] || [];
    const nameId = `tm-add-${collection}`;
    const label = buttonLabel || `Create ${title.replace(/^Global\s+/i, '').replace(/s$/,'')}`;
    return `
        <hr class="cyber-hr">
        <h3>${title} <span class="count-tag">${items.length}</span></h3>
        <div class="input-stack">
            <input type="text" id="${nameId}" placeholder="${escapeHtml(placeholder)}">
            <div class="color-picker-container">
                <span>Identity Color</span>
                <input type="color" id="${colorId}" value="${defaultColor}">
            </div>
            <button class="btn-primary py-2 rounded text-xs font-bold uppercase" onclick="tmAddValueItem('${collection}', '${nameId}', '${colorId}')">${escapeHtml(label)}</button>
        </div>
        <ul class="cast-list">
            ${items.map((item, i) => `
                <li style="border-left-color:${escapeHtml(item.color || defaultColor)}">
                    <span>${escapeHtml(item.name || '')}</span>
                    <span style="display:flex; align-items:center; gap:8px;">
                        <input type="color" value="${escapeHtml(item.color || defaultColor)}" style="width:28px;height:28px;padding:0;" onchange="tmUpdateValueItem('${collection}', ${i}, 'color', this.value)">
                        <span class="shared-delete" onclick="tmRemoveValueItem('${collection}', ${i})">×</span>
                    </span>
                </li>`).join('')}
        </ul>`;
}
function tmRenderServerState(values) {
    tmEnsureValues();
    const serverId = values.serverSessionId || state.Values.serverSessionId || tmGetOrCreateLocalSessionId();
    values.serverSessionId = serverId;
    state.Values.serverSessionId = serverId;
    try { localStorage.setItem(TM_SESSION_STORAGE_KEY, serverId); } catch (err) {}
    const linkedDialogueSessionId = values.dialogueSessionId || window.tmLastDialogueSessionId || '';
    const linkedText = linkedDialogueSessionId
        ? `LINKED TO DIALOGUE DESIGNER SESSION ${linkedDialogueSessionId}`
        : 'NO LINKED DIALOGUE DESIGNER SESSION LOADED';
    return `
        <section class="server-session-panel tm-values-server-session">
            <div class="tm-server-state-label">Assigned ID</div>
            <div class="tm-server-state-grid tm-server-state-main-row">
                <button class="server-session-icon-button" type="button" onclick="tmCopyText(tmEnsureValues().serverSessionId)" title="Copy Session ID">${tmSvgCopy()}</button>
                <code id="tmServerSessionIdDisplay" class="server-session-id-display" title="${escapeHtml(serverId)}">${escapeHtml(serverId)}</code>
                <button class="server-session-icon-button" type="button" onclick="tmRegenerateSessionId()" title="Regenerate Session ID">${tmSvgRefresh()}</button>
                <button class="server-session-icon-button" type="button" onclick="tmDownloadSessionJson()" title="Download Session JSON">${tmSvgDownload()}</button>
            </div>
            <div class="tm-server-state-grid tm-server-state-load-row">
                <button class="server-session-icon-button" type="button" onclick="tmPasteIntoSessionInput()" title="Paste Session ID">${tmSvgPaste()}</button>
                <input id="tmLoadSessionInput" type="text" value="${escapeHtml(serverId)}" placeholder="Session ID to load..." title="${escapeHtml(serverId)}">
                <button class="server-session-icon-button" type="button" onclick="tmUploadSessionClick()" title="Upload Session JSON">${tmSvgUpload()}</button>
                <button class="server-session-icon-button" type="button" onclick="tmLoadSessionById(document.getElementById('tmLoadSessionInput').value)" title="Apply / Load Session">${tmSvgApply()}</button>
                <input type="file" id="tmSessionUploadInput" accept=".json" class="hidden" onchange="tmUploadSessionJson(event)">
            </div>
            <div id="tmValuesSyncStatus" class="values-sync-status">${escapeHtml(linkedText)}</div>
        </section>`;
}

function tmRenderTokenValues(values) {
    if (typeof window.tmEditingTokenIndex === 'undefined') window.tmEditingTokenIndex = null;
    const tokens = values.globalTokens || [];
    return `
        <hr class="cyber-hr">
        <section class="tm-token-section">
            <h3>Global Tokens <span class="count-tag">${tokens.length}</span></h3>
            <p class="tm-token-help">Use in prompts via {{token}}</p>
            <div class="tm-token-add-row">
                <input type="text" id="tm-new-token-key" placeholder="Key (e.g. name)">
                <button class="tm-token-add-button" type="button" onclick="tmAddToken()">+</button>
            </div>
            <ul class="tm-token-list">
                ${tokens.map((token, i) => {
                    const key = tmNormalizeTokenKey(token.key || '');
                    token.key = key;
                    const isEditing = window.tmEditingTokenIndex === i;
                    const keyMarkup = isEditing
                        ? `<div class="tm-token-key-edit-wrap"><span class="tm-token-brace">{{</span><input id="tm-token-edit-${i}" type="text" value="${escapeHtml(key)}" class="tm-token-key-edit-input" onkeydown="if(event.key==='Enter'){tmConfirmTokenKeyEdit(${i});}else if(event.key==='Escape'){tmCancelTokenKeyEdit();}"><span class="tm-token-brace">}}</span><button type="button" class="tm-token-inline-confirm" onclick="tmConfirmTokenKeyEdit(${i})" title="Confirm key edit">✓</button><button type="button" class="tm-token-inline-cancel" onclick="tmCancelTokenKeyEdit()" title="Cancel key edit">×</button></div>`
                        : `<button type="button" class="tm-token-key-chip" ondblclick="tmBeginTokenKeyEdit(${i})" title="Double-click to edit token key">{{${escapeHtml(key)}}}</button><button type="button" class="shared-delete tm-token-delete" onclick="tmRemoveToken(${i})" title="Delete token">×</button>`;
                    return `
                    <li class="tm-token-card">
                        <div class="tm-token-card-top">${keyMarkup}</div>
                        <input type="text" value="${escapeHtml(token.value || '')}" class="tm-token-value-input" oninput="tmUpdateToken(${i}, 'value', this.value)" placeholder="Token Value...">
                    </li>`;
                }).join('')}
            </ul>
        </section>`;
}

function tmSequenceImageName(img) { return typeof img === 'string' ? img : String((img && (img.name || img.image_name || img.file)) || ''); }
function tmRenderImageSequenceValues(values) {
    return `
        <hr class="cyber-hr">
        <h3>Image Sequences <span class="count-tag">${(values.globalImageSequences || []).length}</span></h3>
        <div class="input-stack">
            <input type="text" id="tm-new-seq-name" placeholder="Sequence Name...">
            <div class="color-picker-container">
                <span>Identity Color</span>
                <input type="color" id="tm-new-seq-color" value="#00f2ff">
            </div>
            <button class="btn-primary py-2 rounded text-xs font-bold uppercase" onclick="tmAddImageSequence()">Add Image Sequence</button>
        </div>
        <div style="display:flex; flex-direction:column; gap:8px; margin-top: 15px;">
            ${(values.globalImageSequences || []).map((seq, i) => {
                const color = seq.color || '#00f2ff';
                const images = Array.isArray(seq.images) ? seq.images : [];
                return `
                    <details class="shared-imgseq-card" style="border-left-color:${escapeHtml(color)}">
                        <summary class="shared-imgseq-summary" style="color:${escapeHtml(color)}">
                            <span>${escapeHtml(seq.name || 'Unnamed Sequence')} (${images.length})</span>
                            <span class="shared-delete" onclick="tmRemoveImageSequence(${i}); event.preventDefault(); event.stopPropagation();">×</span>
                        </summary>
                        <div class="shared-imgseq-body">
                            <div style="display:flex; align-items:center; gap:8px;">
                                <label style="font-size:0.65rem; color:#94a3b8; text-transform:uppercase; font-weight:800;">Name:</label>
                                <input type="text" value="${escapeHtml(seq.name || '')}" oninput="tmUpdateImageSequence(${i}, 'name', this.value)" style="flex:1; padding:4px 8px; font-size:0.75rem; background:#000; border:1px solid #2a2a2a; color:#fff;">
                                <input type="color" value="${escapeHtml(color)}" onchange="tmUpdateImageSequence(${i}, 'color', this.value)" style="width:28px;height:28px;padding:0;">
                            </div>
                            <div style="display:flex; align-items:center; gap:8px;">
                                <label style="font-size:0.65rem; color:#94a3b8; text-transform:uppercase; font-weight:800;">Path:</label>
                                <input type="text" value="${escapeHtml(seq.path || seq.rootPath || 'Assets/2D/Sequences/')}" oninput="tmUpdateImageSequence(${i}, 'path', this.value)" style="flex:1; padding:4px 8px; font-size:0.75rem; background:#000; border:1px solid #2a2a2a; color:#fff;">
                            </div>
                            <div style="display:flex; gap:5px;">
                                <input id="tm-seq-img-${i}" type="text" placeholder="Image name..." style="flex:1; padding:5px 8px; font-size:0.72rem;">
                                <button class="btn-primary px-3 rounded text-xs font-bold" onclick="tmAddSequenceImage(${i})">+</button>
                                <button class="btn-primary px-3 rounded text-xs font-bold" onclick="tmSortSequenceImages(${i})">A-Z</button>
                                <button class="border border-red-500 text-red-300 px-3 rounded text-xs font-bold" onclick="tmClearSequenceImages(${i})">Clear</button>
                            </div>
                            <div style="display:flex; flex-direction:column; gap:5px;">
                                ${images.map((img, j) => `
                                    <div class="shared-image-row">
                                        <span style="display:flex; align-items:center; gap:6px; flex:1; min-width:0;">
                                            <span style="color:#94a3b8; font-size:0.8rem;">☰</span>
                                            <span style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis; flex:1;">${escapeHtml(tmSequenceImageName(img))}</span>
                                        </span>
                                        <span style="display:flex; gap:6px; align-items:center;">
                                            <button class="text-xs text-teal" onclick="tmMoveSequenceImage(${i}, ${j}, -1)">↑</button>
                                            <button class="text-xs text-teal" onclick="tmMoveSequenceImage(${i}, ${j}, 1)">↓</button>
                                            <span class="shared-delete" onclick="tmRemoveSequenceImage(${i}, ${j})">×</span>
                                        </span>
                                    </div>`).join('')}
                            </div>
                        </div>
                    </details>`;
            }).join('')}
        </div>`;
}
function tmRenderSpritesValuesSection() {
    const sprites = Array.isArray(state.Sprites) ? state.Sprites : [];
    const spriteCount = sprites.length;
    const totalSprites = sprites.reduce((sum, dir) => sum + (Array.isArray(dir.sprites) ? dir.sprites.length : 0), 0);
    const defaultRoot = spriteCount && sprites[0].rootPath ? sprites[0].rootPath : 'Assets/2D/MiniGames/OnlySam/';
    return `
        <hr class="cyber-hr">
        <h3>Sprites <span class="count-tag" id="values-sprites-count">${spriteCount} dirs / ${totalSprites} sprites</span></h3>
        <div class="values-sprites-shell border border-gray-800 rounded bg-[#121215] overflow-hidden">
            <div class="p-4 border-b border-gray-800 bg-[#0d0d11]">
                <label class="block text-xs text-gray-400 mb-1 uppercase tracking-wider">Default Root Path</label>
                <input type="text" id="tmSpriteRootPath" value="${escapeHtml(defaultRoot)}" class="text-sm">
            </div>
            <div class="p-4 flex flex-col">
                <input type="text" id="tmNewSpriteDirName" placeholder="Sequence Name..." class="w-full text-sm mb-2 bg-black border border-gray-800 focus:border-teal rounded px-2 py-1.5">
                <button onclick="tmAddSpriteDirectory()" class="w-full py-2 bg-teal text-black font-bold uppercase hover:bg-white transition-colors rounded text-sm shadow-[0_0_10px_rgba(0,240,255,0.4)] mb-4">ADD SPRITE DIRECTORY</button>
                <div id="tmSpriteDirectoriesList" class="space-y-4 pr-2">
                    ${sprites.map((dir, di) => `<details class="shared-imgseq-card" open style="border-left-color:#00f2ff"><summary class="shared-imgseq-summary"><span>${escapeHtml(dir.name || 'Sprite Directory')} (${(dir.sprites||[]).length})</span><span class="shared-delete" onclick="tmRemoveSpriteDirectory(${di});event.preventDefault();event.stopPropagation();">×</span></summary><div class="shared-imgseq-body"><input value="${escapeHtml(dir.name || '')}" oninput="tmUpdateSpriteDirectory(${di}, 'name', this.value)" placeholder="Directory Name"><input value="${escapeHtml(dir.rootPath || defaultRoot)}" oninput="tmUpdateSpriteDirectory(${di}, 'rootPath', this.value)" placeholder="Root Path"><div style="display:flex;gap:5px;"><input id="tmSpriteAdd-${di}" placeholder="Sprite name..."><button class="btn-primary px-3 rounded text-xs font-bold" onclick="tmAddSpriteToDirectory(${di})">+</button></div>${(dir.sprites||[]).map((spr, si)=>`<div class="shared-image-row"><span>${escapeHtml(spr.name || spr.file || '')}</span><span class="shared-delete" onclick="tmRemoveSpriteFromDirectory(${di},${si})">×</span></div>`).join('')}</div></details>`).join('')}
                </div>
            </div>
        </div>`;
}
function tmRenderValuesTab() {
    tmEnsureValues();
    const values = state.Values;
    const panel = document.getElementById('tmValuesPanel');
    if (!panel) return;
    panel.innerHTML = `
        <div class="tm-values-inner">
            <h3 class="tm-values-section-heading">Server Session</h3>
            ${tmRenderServerState(values)}
            ${tmRenderTokenValues(values)}
            ${tmValueListSection('Global Cast', 'globalCast', 'Character Name...', 'tm-custom-cast-color', '#00f2ff', 'Create Character')}
            ${tmValueListSection('Global Variables', 'globalStates', 'Variable Name (e.g. Awake)...', 'tm-custom-state-color', '#00ff88')}
            ${tmValueListSection('Global Moods', 'globalMoods', 'Mood Name (e.g. Angry)...', 'tm-custom-mood-color', '#ff007b')}
            ${tmValueListSection('Global Settings', 'globalSettings', 'Setting Name (e.g. Volume)...', 'tm-custom-setting-color', '#ffff00')}
            ${tmValueListSection('Times Of Day', 'globalTimesOfDay', 'Time Name (e.g. Morning)...', 'tm-custom-time-color', '#ff8c00')}
            ${tmValueListSection('Days Of The Week', 'globalDaysOfWeek', 'Day Name (e.g. Monday)...', 'tm-custom-day-color', '#b026ff')}
            ${tmValueListSection('Menu Options', 'globalMenuOptions', 'Menu Option (e.g. Trade)...', 'tm-custom-menu-color', '#00ff44')}
            ${tmRenderImageSequenceValues(values)}
            ${tmRenderSpritesValuesSection()}
        </div>`;
    tmRefreshLanguageDropdown();
}
function tmMarkValuesDirty() { tmRenderValuesTab(); tmRefreshTaskGiverControls(); tmMarkAppDirty(); tmScheduleSharedSave(); }
function tmUpdateValueItem(c,i,f,v){ tmEnsureValues()[c][i][f]=v; tmMarkValuesDirty(); }
function tmRemoveValueItem(c,i){ tmEnsureValues()[c].splice(i,1); tmMarkValuesDirty(); }
function tmAddValueItem(c, inputId, colorId){ const inp=document.getElementById(inputId || `tm-add-${c}`); const name=(inp?.value||'').trim(); if(!name)return; const color=(document.getElementById(colorId)?.value)||'#00f2ff'; tmEnsureValues()[c].push({name,color}); if(inp)inp.value=''; tmMarkValuesDirty(); }
function tmNormalizeTokenKey(raw){
    return String(raw || '')
        .trim()
        .replace(/^\{\{/, '')
        .replace(/\}\}$/, '')
        .replace(/[{}]/g, '')
        .replace(/[^a-zA-Z0-9_]/g, '');
}
function tmUpdateToken(i,f,v){
    const tokens = tmEnsureValues().globalTokens || [];
    if (!tokens[i]) return;
    tokens[i][f] = f === 'key' ? tmNormalizeTokenKey(v) : v;
    tmMarkAppDirty();
    tmScheduleSharedSave();
}
function tmRemoveToken(i){ tmEnsureValues().globalTokens.splice(i,1); if(window.tmEditingTokenIndex===i)window.tmEditingTokenIndex=null; tmMarkValuesDirty(); }
function tmAddToken(){ const inp=document.getElementById('tm-new-token-key'); const key=tmNormalizeTokenKey(inp?.value||''); if(!key)return; const v=tmEnsureValues(); if(v.globalTokens.some(t=>tmNormalizeTokenKey(t.key)===key)){showNotification('Token key already exists.', true); return;} v.globalTokens.push({key,value:'Sample Value'}); if(inp)inp.value=''; tmMarkValuesDirty(); }
function tmBeginTokenKeyEdit(i){
    const tokens = tmEnsureValues().globalTokens || [];
    if (!tokens[i]) return;
    window.tmEditingTokenIndex = i;
    window.tmEditingTokenOriginalKey = tmNormalizeTokenKey(tokens[i].key || '');
    tmRenderValuesTab();
    setTimeout(() => { const input = document.getElementById(`tm-token-edit-${i}`); if(input){ input.focus(); input.select(); } }, 0);
}
function tmConfirmTokenKeyEdit(i){
    const tokens = tmEnsureValues().globalTokens || [];
    const input = document.getElementById(`tm-token-edit-${i}`);
    if (!tokens[i] || !input) return;
    const key = tmNormalizeTokenKey(input.value);
    if (!key) { showNotification('Token key required.', true); return; }
    const duplicate = tokens.some((t, idx) => idx !== i && tmNormalizeTokenKey(t.key) === key);
    if (duplicate) { showNotification('Token key already exists.', true); return; }
    tokens[i].key = key;
    window.tmEditingTokenIndex = null;
    window.tmEditingTokenOriginalKey = '';
    tmMarkValuesDirty();
}
function tmCancelTokenKeyEdit(){
    window.tmEditingTokenIndex = null;
    window.tmEditingTokenOriginalKey = '';
    tmRenderValuesTab();
}
function tmAddImageSequence(){ const inp=document.getElementById('tm-new-seq-name'); const name=(inp?.value||'').trim(); if(!name)return; const color=document.getElementById('tm-new-seq-color')?.value||'#00f2ff'; tmEnsureValues().globalImageSequences.push({id:crypto.randomUUID(),name,color,path:'Assets/2D/Sequences/',rootPath:'Assets/2D/Sequences/',images:[]}); if(inp)inp.value=''; tmMarkValuesDirty(); }
function tmUpdateImageSequence(i,f,v){ const seq=tmEnsureValues().globalImageSequences[i]; seq[f]=v; if(f==='path')seq.rootPath=v; tmMarkAppDirty(); tmScheduleSharedSave(); }
function tmRemoveImageSequence(i){ tmEnsureValues().globalImageSequences.splice(i,1); tmMarkValuesDirty(); }
function tmAddSequenceImage(i){ const inp=document.getElementById(`tm-seq-img-${i}`); const name=(inp?.value||'').trim(); if(!name)return; tmEnsureValues().globalImageSequences[i].images.push({name}); tmMarkValuesDirty(); }
function tmUpdateSequenceImage(i,j,v){ tmEnsureValues().globalImageSequences[i].images[j].name=v; tmMarkAppDirty(); tmScheduleSharedSave(); }
function tmRemoveSequenceImage(i,j){ tmEnsureValues().globalImageSequences[i].images.splice(j,1); tmMarkValuesDirty(); }
function tmRegenerateSessionId(){ tmEnsureValues().serverSessionId=tmGenerateSessionId(); localStorage.setItem(TM_SESSION_STORAGE_KEY,state.Values.serverSessionId); tmRenderValuesTab(); tmMarkAppDirty(); }
function tmDownloadSessionJson(){ const blob=new Blob([JSON.stringify(tmBuildWorkspacePayload(),null,2)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=`${tmEnsureValues().serverSessionId}.json`; a.click(); URL.revokeObjectURL(a.href); }

function tmSortSequenceImages(i){ const seq=tmEnsureValues().globalImageSequences[i]; if(!seq||!Array.isArray(seq.images))return; seq.images.sort((a,b)=>tmSequenceImageName(a).localeCompare(tmSequenceImageName(b),undefined,{numeric:true,sensitivity:'base'})); tmMarkValuesDirty(); }
function tmClearSequenceImages(i){ const seq=tmEnsureValues().globalImageSequences[i]; if(!seq)return; seq.images=[]; tmMarkValuesDirty(); }
function tmMoveSequenceImage(i,j,d){ const seq=tmEnsureValues().globalImageSequences[i]; if(!seq||!Array.isArray(seq.images))return; const t=j+d; if(t<0||t>=seq.images.length)return; const [item]=seq.images.splice(j,1); seq.images.splice(t,0,item); tmMarkValuesDirty(); }
function tmAddSpriteDirectory(){ if(!Array.isArray(state.Sprites))state.Sprites=[]; const inp=document.getElementById('tmNewSpriteDirName'); const name=(inp?.value||'').trim(); if(!name)return; const root=document.getElementById('tmSpriteRootPath')?.value||'Assets/2D/MiniGames/OnlySam/'; state.Sprites.push({id:crypto.randomUUID(),name,rootPath:root,sprites:[]}); if(inp)inp.value=''; tmRenderValuesTab(); tmMarkAppDirty(); }
function tmUpdateSpriteDirectory(i,f,v){ if(!Array.isArray(state.Sprites)||!state.Sprites[i])return; state.Sprites[i][f]=v; tmMarkAppDirty(); }
function tmRemoveSpriteDirectory(i){ if(!Array.isArray(state.Sprites))return; state.Sprites.splice(i,1); tmRenderValuesTab(); tmMarkAppDirty(); }
function tmAddSpriteToDirectory(i){ if(!Array.isArray(state.Sprites)||!state.Sprites[i])return; const inp=document.getElementById(`tmSpriteAdd-${i}`); const name=(inp?.value||'').trim(); if(!name)return; if(!Array.isArray(state.Sprites[i].sprites))state.Sprites[i].sprites=[]; state.Sprites[i].sprites.push({name,file:name}); if(inp)inp.value=''; tmRenderValuesTab(); tmMarkAppDirty(); }
function tmRemoveSpriteFromDirectory(i,j){ if(!Array.isArray(state.Sprites)||!state.Sprites[i]||!Array.isArray(state.Sprites[i].sprites))return; state.Sprites[i].sprites.splice(j,1); tmRenderValuesTab(); tmMarkAppDirty(); }
function tmUploadSessionClick(){ document.getElementById('tmSessionUploadInput')?.click(); }
function tmUploadSessionJson(event){ const file=event.target.files?.[0]; if(!file)return; const r=new FileReader(); r.onload=e=>{try{tmApplyWorkspacePayload(JSON.parse(e.target.result));showNotification('Session JSON Loaded');}catch(err){showNotification('Invalid Session JSON',true);}}; r.readAsText(file); }
async function tmPasteIntoSessionInput(){ const t=await navigator.clipboard?.readText(); const i=document.getElementById('tmLoadSessionInput'); if(i)i.value=t||''; }
function tmRefreshLanguageDropdown(){ const s=document.getElementById('tmTaskLanguageSelect'); if(!s)return; const v=tmEnsureValues(); s.innerHTML=v.availableLanguages.map(l=>`<option value="${escapeHtml(l)}" ${l===v.currentLanguage?'selected':''}>${escapeHtml(l)}</option>`).join(''); }
function tmSetCurrentLanguage(lang){ const v=tmEnsureValues(); const code=tmNormalizeLanguageCode(lang||'ENG') || 'ENG'; v.currentLanguage=code; if(!v.availableLanguages.includes(code))v.availableLanguages.push(code); if(typeof tmRefreshLocalizedUi==='function')tmRefreshLocalizedUi(); tmMarkAppDirty(); tmScheduleSharedSave(); }
function tmNormalizeLanguageCode(lang){ return String(lang || '').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 8); }
function tmShowAddLanguageInline(){ const box=document.getElementById('tmTaskLanguageInline'); const input=document.getElementById('tmTaskLanguageInput'); if(box)box.classList.remove('hidden'); if(input){input.value=''; setTimeout(()=>input.focus(),0);} }
function tmCancelAddLanguageInline(){ const box=document.getElementById('tmTaskLanguageInline'); const input=document.getElementById('tmTaskLanguageInput'); if(input)input.value=''; if(box)box.classList.add('hidden'); }
function tmConfirmAddLanguageInline(){ const input=document.getElementById('tmTaskLanguageInput'); const code=tmNormalizeLanguageCode(input?.value||''); if(!code)return; const v=tmEnsureValues(); if(!v.availableLanguages.includes(code))v.availableLanguages.push(code); v.currentLanguage=code; if(typeof tmEnsureAllTaskTranslations==='function')tmEnsureAllTaskTranslations(); tmRefreshLanguageDropdown(); tmCancelAddLanguageInline(); if(typeof tmRefreshLocalizedUi==='function')tmRefreshLocalizedUi(); tmMarkAppDirty(); tmScheduleSharedSave(); }
function tmAddLanguageFromPrompt(){ tmShowAddLanguageInline(); }
function tmRefreshTaskGiverControls(){ const cast=tmEnsureValues().globalCast||[]; const options='<option value="">Select From Global Cast...</option>'+cast.map(c=>`<option value="${escapeHtml(c.name||'')}">${escapeHtml(c.name||'')}</option>`).join(''); const existing=document.getElementById('taskGiver'); if(existing && existing.tagName==='INPUT'){ const sel=document.createElement('select'); sel.id='taskGiver'; sel.className=existing.className+' custom-scrollbar'; sel.onchange=function(){updateTaskString(document.getElementById('taskId').value,'questGiver',this.value)}; existing.replaceWith(sel); } const sel=document.getElementById('taskGiver'); if(sel){ const val=sel.value; sel.innerHTML=options; if(val)sel.value=val; } const settings=tmEnsureValues().globalSettings||[]; const settingOptions='<option value="">Select Setting...</option>'+settings.map(x=>{const n=escapeHtml(x.name||x.setting||x.key||''); return n?`<option value="${n}">${n}</option>`:'';}).join(''); document.querySelectorAll('.tm-task-setting-row select').forEach(settingSel=>{const val=settingSel.value; settingSel.innerHTML=settingOptions; if(val)settingSel.value=val;}); }
function tmSetAccountButtonState(data){
    const b=document.getElementById('tmAccountBtn') || document.getElementById('account-management-button') || document.querySelector('.account-management-button');
    const p=document.getElementById('tmPushServerBtn');
    if(!b)return;
    b.classList.toggle('is-logged-in', !!data.loggedIn);
    b.classList.toggle('logged-in', !!data.loggedIn);
    if(p)p.style.display=data.loggedIn?'inline-flex':'none';
    b.title=data.loggedIn && data.user ? `Manage Account: ${data.user.username || data.user.email}` : 'Manage Account';
}
function tmEnsureAccountModalMarkup(){
    let modal = document.getElementById('account-modal') || document.getElementById('tmAccountModal');
    if (modal) return modal;
    const wrap = document.createElement('div');
    wrap.innerHTML = `
    <div id="account-modal" class="modal-overlay account-modal-overlay" role="dialog" aria-modal="true" aria-labelledby="account-modal-title" style="display:none;">
        <div class="modal-content account-modal-content">
            <div class="modal-title-row">
                <h3 id="account-modal-title">Manage Account</h3>
                <button class="modal-x-button" type="button" onclick="tmCloseAccountModal()">×</button>
            </div>
            <div id="account-status-message" class="account-status-message" style="display:none;"></div>
            <div id="tmAccountBody"></div>
        </div>
    </div>`;
    modal = wrap.firstElementChild;
    document.body.appendChild(modal);
    return modal;
}
function tmShowAccountMessage(message, isError=false){
    const box=document.getElementById('account-status-message');
    if(!box)return;
    box.textContent=message||'';
    box.style.display=message?'block':'none';
    box.classList.toggle('error', !!isError);
}
function tmOpenAccountModal(){
    if (typeof tmInjectBaseUi === 'function') tmInjectBaseUi();
    const modal = tmEnsureAccountModalMarkup();
    if (!modal) return showNotification('Account modal missing.', true);
    modal.style.display='flex';
    modal.classList.add('account-modal-open');
    tmShowAccountMessage('Checking shared login...');
    tmAccountStatus(false).then(()=>tmShowAccountMessage('')).catch(err=>tmShowAccountMessage(err.message, true));
}
function tmCloseAccountModal(){ const modal=document.getElementById('account-modal') || document.getElementById('tmAccountModal'); if(modal){modal.style.display='none'; modal.classList.remove('account-modal-open');} }
function tmRenderAccountModal(data){
    tmEnsureAccountModalMarkup();
    const body=document.getElementById('tmAccountBody');
    if(!body)return;
    const title=document.getElementById('account-modal-title');
    const sessions=Array.isArray(data.sessions)?data.sessions:[];
    if(data.loggedIn){
        if(title) title.textContent=data.user?.username || 'Manage Account';
        body.innerHTML=`
        <div id="account-profile-view">
            <div class="account-profile-header">
                <div>
                    <div class="account-profile-username" id="account-profile-username-display">${escapeHtml(data.user?.username||'Logged In')}</div>
                    <div class="account-profile-email" id="account-profile-email-display">${escapeHtml(data.user?.email||'')}</div>
                </div>
                <button class="btn btn-outline account-logout-button" type="button" onclick="tmAuthLogout()">Logout</button>
            </div>
            <details class="account-profile-section" open>
                <summary>Profile</summary>
                <form class="account-form" onsubmit="tmAuthUpdateProfile(event)">
                    <label>Username</label>
                    <input id="tmProfileUsername" type="text" required value="${escapeHtml(data.user?.username||'')}">
                    <label>Email</label>
                    <input id="tmProfileEmail" type="email" required value="${escapeHtml(data.user?.email||'')}">
                    <button class="btn btn-teal account-primary-action" type="submit">Update Profile</button>
                </form>
            </details>
            <details class="account-profile-section">
                <summary>Password Reset</summary>
                <form class="account-form" onsubmit="tmAuthChangePassword(event)">
                    <label>New Password</label>
                    <input id="tmNewPassword" type="password" autocomplete="new-password" required>
                    <label>Confirm New Password</label>
                    <input id="tmNewPasswordConfirm" type="password" autocomplete="new-password" required>
                    <p class="account-password-rule">Password must be 8+ characters and include uppercase, lowercase, number, and special character.</p>
                    <button class="btn btn-teal account-primary-action" type="submit">Reset Password</button>
                </form>
            </details>
            <div class="account-sessions-wrap">
                <h3>Saved Server Sessions</h3>
                <div id="account-session-list" class="account-session-list scrollable">${sessions.length ? sessions.map(session=>{ const sid=String(session.session_id||session.sessionId||''); const viewed=String(session.last_viewed_at||session.lastViewedAt||session.last_pushed_at||''); return `<div class="account-session-row" ondblclick="tmLoadSessionById('${escapeHtml(sid)}');tmCloseAccountModal();"><div class="account-session-main"><code>${escapeHtml(sid)}</code><span>${escapeHtml(viewed)}</span></div><button type="button" title="Copy Session ID" onclick="tmCopyText('${escapeHtml(sid)}'); event.stopPropagation();">${tmSvgCopy()}</button></div>`; }).join('') : '<div class="account-empty-sessions">No pushed sessions yet.</div>'}</div>
            </div>
        </div>`;
    } else {
        if(title) title.textContent='Login / Register';
        body.innerHTML=`
        <div id="account-auth-view">
            <div class="account-auth-tabs">
                <button id="account-login-tab" type="button" class="active" onclick="tmSwitchAuthTab('login')">Login</button>
                <button id="account-register-tab" type="button" onclick="tmSwitchAuthTab('register')">Register</button>
            </div>
            <form id="account-login-form" class="account-form" onsubmit="tmAuthLogin(event)">
                <label>Username or Email</label>
                <input id="tmLoginIdentity" type="text" autocomplete="username" required>
                <label>Password</label>
                <input id="tmLoginPassword" type="password" autocomplete="current-password" required>
                <button class="btn btn-teal account-primary-action" type="submit">Login</button>
            </form>
            <form id="account-register-form" class="account-form" onsubmit="tmAuthRegister(event)" style="display:none;">
                <label>Email</label>
                <input id="tmRegEmail" type="email" autocomplete="email" required>
                <label>Username</label>
                <input id="tmRegUser" type="text" autocomplete="username" required>
                <label>Password</label>
                <input id="tmRegPass1" type="password" autocomplete="new-password" required>
                <label>Confirm Password</label>
                <input id="tmRegPass2" type="password" autocomplete="new-password" required>
                <p class="account-password-rule">Password must be 8+ characters and include uppercase, lowercase, number, and special character.</p>
                <label class="account-checkbox-line"><input id="tmReg18" type="checkbox"> <span>I confirm I am 18+.</span></label>
                <label class="account-checkbox-line"><input id="tmRegTerms" type="checkbox"> <span>I agree to the <a href="about:blank" target="_blank" rel="noopener noreferrer">Terms of Service</a>.</span></label>
                <label class="account-checkbox-line"><input id="tmRegPrivacy" type="checkbox"> <span>I agree to the <a href="about:blank" target="_blank" rel="noopener noreferrer">Privacy Policy</a>.</span></label>
                <button class="btn btn-teal account-primary-action" type="submit">Register</button>
            </form>
        </div>`;
    }
}
function tmSwitchAuthTab(tab){
    const register=tab==='register';
    const loginForm=document.getElementById('account-login-form');
    const registerForm=document.getElementById('account-register-form');
    const loginTab=document.getElementById('account-login-tab');
    const registerTab=document.getElementById('account-register-tab');
    if(loginForm) loginForm.style.display=register?'none':'flex';
    if(registerForm) registerForm.style.display=register?'flex':'none';
    if(loginTab) loginTab.classList.toggle('active', !register);
    if(registerTab) registerTab.classList.toggle('active', register);
}
async function tmAuthUpdateProfile(event){
    if(event) event.preventDefault();
    try{
        tmShowAccountMessage('Updating profile...');
        const data=await tmFetchJson(tmUrl(TM_AUTH_FILE,{action:'updateProfile'}),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:document.getElementById('tmProfileUsername').value,email:document.getElementById('tmProfileEmail').value})});
        if(data.authToken)tmStoreAuthToken(data.authToken);
        tmShowAccountMessage('Profile updated.');
        showNotification('Account updated');
        await tmAccountStatus(false);
    }catch(e){tmShowAccountMessage(e.message,true); showNotification('Account Update Failed: '+e.message,true);}
}
async function tmAuthChangePassword(event){
    if(event) event.preventDefault();
    try{
        const password=document.getElementById('tmNewPassword').value;
        const passwordConfirm=document.getElementById('tmNewPasswordConfirm').value;
        if(password!==passwordConfirm){tmShowAccountMessage('Passwords do not match.',true);return;}
        await tmFetchJson(tmUrl(TM_AUTH_FILE,{action:'changePassword'}),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password,passwordConfirm,newPassword:password,newPasswordConfirm:passwordConfirm})});
        showNotification('Password changed');
        tmShowAccountMessage('Password updated.');
        document.getElementById('tmNewPassword').value='';
        document.getElementById('tmNewPasswordConfirm').value='';
    }catch(e){tmShowAccountMessage(e.message,true); showNotification('Password Change Failed: '+e.message,true);}
}
async function tmAuthLogin(event){
    if(event) event.preventDefault();
    try{
        tmShowAccountMessage('Logging in...');
        const d=await tmFetchJson(tmUrl(TM_AUTH_FILE,{action:'login'}),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({identity:document.getElementById('tmLoginIdentity').value,password:document.getElementById('tmLoginPassword').value})});
        if(d.authToken)tmStoreAuthToken(d.authToken);
        tmCloseAccountModal();
        await tmAccountStatus(true);
    }catch(e){tmShowAccountMessage(e.message,true); showNotification('Login Failed: '+e.message,true);}
}
async function tmAuthLogout(){ try{ await tmFetchJson(tmUrl(TM_AUTH_FILE,{action:'logout'}),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})});}catch(e){} tmStoreAuthToken(''); tmSetAccountButtonState({loggedIn:false}); tmRenderAccountModal({loggedIn:false}); tmCloseAccountModal(); }
async function tmAuthRegister(event){
    if(event) event.preventDefault();
    if(!document.getElementById('tmReg18').checked||!document.getElementById('tmRegTerms').checked||!document.getElementById('tmRegPrivacy').checked)return tmShowAccountMessage('Confirm age, Terms, and Privacy first.',true);
    try{
        tmShowAccountMessage('Registering...');
        const d=await tmFetchJson(tmUrl(TM_AUTH_FILE,{action:'register'}),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:document.getElementById('tmRegEmail').value,username:document.getElementById('tmRegUser').value,password:document.getElementById('tmRegPass1').value,passwordConfirm:document.getElementById('tmRegPass2').value,over18:true,terms:true,privacy:true})});
        if(d.authToken)tmStoreAuthToken(d.authToken);
        tmCloseAccountModal();
        await tmAccountStatus(true);
    }catch(e){tmShowAccountMessage(e.message,true); showNotification('Register Failed: '+e.message,true);}
}


// ============================================================================
// TASK MANAGER SHARED AUTH / SESSION / LANGUAGE / TEXT FORMAT PATCH
// ============================================================================
var TM_API_FILE = window.TM_API_FILE || 'TaskManager.php';
var TM_AUTH_FILE = window.TM_AUTH_FILE || TM_API_FILE;
var TM_SESSION_STORAGE_KEY = window.TM_SESSION_STORAGE_KEY || 'TM_serverSessionId';
var TM_SHARED_AUTH_TOKEN_KEY = 'AuthShared_12h_token';
var TM_SHARED_AUTH_EXPIRES_KEY = 'AuthShared_12h_expiresAt';
var TM_DD_AUTH_TOKEN_KEY = 'DD_sharedAuthBearerToken';
var TM_LOCAL_AUTH_TOKEN_KEY = 'TM_sharedAuthBearerToken';
var TM_DIRTY_STORAGE_KEY = 'TM_hasLocalServerDelta';
var TM_TRANSLATABLE_TASK_FIELDS = ['name','displayName','desc','completionText','failureText','chainName','chainDesc','managerName','managerDesc','upgradeName','upgradeDesc'];
var TM_TEXT_FORMAT_FIELDS = ['name','displayName','desc','completionText','failureText','chainName','chainDesc','managerName','managerDesc','upgradeName','upgradeDesc'];
var tmSharedSaveTimer = null;
var tmStatusBootLoadedSession = false;

function tmSafeJsonClone(value) {
    try { return JSON.parse(JSON.stringify(value)); } catch (err) { return value; }
}

function tmGenerateSessionId() {
    const bytes = new Uint8Array(8);
    if (window.crypto && crypto.getRandomValues) crypto.getRandomValues(bytes);
    else for (let i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
    const hex = Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
    return `TM-${hex.slice(0, 6)}-${hex.slice(6, 16)}`;
}

function tmGetStoredAuthToken() {
    try {
        const expires = localStorage.getItem(TM_SHARED_AUTH_EXPIRES_KEY) || '';
        if (expires) {
            const expiresAt = Date.parse(expires);
            if (Number.isFinite(expiresAt) && expiresAt <= Date.now()) {
                tmStoreAuthToken('');
                return '';
            }
        }
        return localStorage.getItem(TM_SHARED_AUTH_TOKEN_KEY) || localStorage.getItem(TM_DD_AUTH_TOKEN_KEY) || localStorage.getItem(TM_LOCAL_AUTH_TOKEN_KEY) || '';
    } catch (err) { return ''; }
}

function tmStoreAuthToken(token, expiresAt = '') {
    try {
        const cleaned = token ? String(token).trim() : '';
        if (cleaned) {
            localStorage.setItem(TM_SHARED_AUTH_TOKEN_KEY, cleaned);
            localStorage.setItem(TM_DD_AUTH_TOKEN_KEY, cleaned);
            localStorage.setItem(TM_LOCAL_AUTH_TOKEN_KEY, cleaned);
            const expiry = expiresAt || new Date(Date.now() + 43200 * 1000).toISOString();
            localStorage.setItem(TM_SHARED_AUTH_EXPIRES_KEY, expiry);
        } else {
            localStorage.removeItem(TM_SHARED_AUTH_TOKEN_KEY);
            localStorage.removeItem(TM_DD_AUTH_TOKEN_KEY);
            localStorage.removeItem(TM_LOCAL_AUTH_TOKEN_KEY);
            localStorage.removeItem(TM_SHARED_AUTH_EXPIRES_KEY);
        }
    } catch (err) {}
}

function tmApplyAuthToOptions(options = {}) {
    const next = Object.assign({ credentials: 'include' }, options || {});
    const headers = new Headers(next.headers || {});
    const token = tmGetStoredAuthToken();
    if (token) {
        if (!headers.has('Authorization')) headers.set('Authorization', `Bearer ${token}`);
        if (!headers.has('X-Auth-Token')) headers.set('X-Auth-Token', token);
    }
    next.headers = headers;
    return next;
}

function tmUrl(file = TM_API_FILE, params = {}) {
    const url = new URL(file || TM_API_FILE, window.location.href);
    Object.entries(params || {}).forEach(([key, value]) => {
        if (value !== undefined && value !== null && String(value) !== '') url.searchParams.set(key, String(value));
    });
    const token = tmGetStoredAuthToken();
    if (token && !url.searchParams.has('authToken')) url.searchParams.set('authToken', token);
    return url.toString();
}

async function tmFetchJson(url, options = {}) {
    const response = await fetch(url, tmApplyAuthToOptions(options));
    const headerToken = response.headers.get('X-Auth-Token') || '';
    const headerExpiry = response.headers.get('X-Auth-Expires-At') || '';
    if (headerToken) tmStoreAuthToken(headerToken, headerExpiry);
    const text = await response.text();
    let data = {};
    if (text) {
        try { data = JSON.parse(text); }
        catch (err) { throw new Error(`Server returned non-JSON response (${response.status}).`); }
    }
    if (data.authToken) tmStoreAuthToken(data.authToken, data.authExpiresAt || data.expiresAt || headerExpiry);
    if (!response.ok || data.ok === false || data.status === 'error') {
        throw new Error(data.error || data.message || `Request failed (${response.status}).`);
    }
    return data;
}

function tmEnsureValues() {
    if (!state.Values || typeof state.Values !== 'object' || Array.isArray(state.Values)) {
        state.Values = (typeof createDefaultTaskValues === 'function') ? createDefaultTaskValues() : { availableLanguages: ['ENG'], currentLanguage: 'ENG' };
    }
    const defaults = (typeof createDefaultTaskValues === 'function') ? createDefaultTaskValues() : { availableLanguages: ['ENG'], currentLanguage: 'ENG' };
    Object.keys(defaults).forEach(key => {
        if (state.Values[key] === undefined || state.Values[key] === null) state.Values[key] = tmSafeJsonClone(defaults[key]);
    });
    ['globalTokens','globalCast','globalStates','globalMoods','globalSettings','globalTimesOfDay','globalDaysOfWeek','globalMenuOptions','globalImageSequences'].forEach(key => {
        if (!Array.isArray(state.Values[key])) state.Values[key] = [];
    });
    if (!Array.isArray(state.Values.availableLanguages) || state.Values.availableLanguages.length === 0) state.Values.availableLanguages = ['ENG'];
    state.Values.availableLanguages = state.Values.availableLanguages.map(tmNormalizeLanguageCode).filter(Boolean);
    if (!state.Values.availableLanguages.includes('ENG')) state.Values.availableLanguages.unshift('ENG');
    state.Values.currentLanguage = tmNormalizeLanguageCode(state.Values.currentLanguage || 'ENG') || 'ENG';
    if (!state.Values.availableLanguages.includes(state.Values.currentLanguage)) state.Values.availableLanguages.push(state.Values.currentLanguage);
    if (!state.Values.serverSessionId) {
        try { state.Values.serverSessionId = localStorage.getItem(TM_SESSION_STORAGE_KEY) || ''; } catch (err) {}
    }
    if (!state.Values.serverSessionId) state.Values.serverSessionId = tmGenerateSessionId();
    state.serverSessionId = state.Values.serverSessionId;
    try { localStorage.setItem(TM_SESSION_STORAGE_KEY, state.Values.serverSessionId); } catch (err) {}
    if (!Array.isArray(state.Sprites)) state.Sprites = (typeof createDefaultTaskSprites === 'function') ? createDefaultTaskSprites() : [];
    return state.Values;
}

function tmDefaultTextFormat() {
    return { bold:false, italic:false, underline:false, strikethrough:false, listStyle:'none', alignH:'left', alignV:'top' };
}

function tmNormalizeTextFormat(format) {
    const next = Object.assign(tmDefaultTextFormat(), format || {});
    if (!['none','bullet','number'].includes(next.listStyle)) next.listStyle = 'none';
    if (!['left','center','right','justified'].includes(next.alignH)) next.alignH = 'left';
    if (!['top','middle','bottom'].includes(next.alignV)) next.alignV = 'top';
    return next;
}

function tmGetTextFormatStyle(format) {
    const f = tmNormalizeTextFormat(format);
    const decos = [];
    if (f.underline) decos.push('underline');
    if (f.strikethrough) decos.push('line-through');
    let style = '';
    style += `font-weight:${f.bold ? '800' : 'inherit'};`;
    style += `font-style:${f.italic ? 'italic' : 'inherit'};`;
    style += `text-decoration:${decos.length ? decos.join(' ') : 'none'};`;
    style += `text-align:${f.alignH === 'justified' ? 'justify' : f.alignH};`;
    if (f.listStyle !== 'none') style += 'padding-left:1.25rem;';
    return style;
}

function tmEnsureTaskTranslationContainers(task) {
    if (!task || typeof task !== 'object') return task;
    const values = tmEnsureValues();
    if (!task.translations || typeof task.translations !== 'object' || Array.isArray(task.translations)) task.translations = {};
    values.availableLanguages.forEach(lang => {
        if (!task.translations[lang] || typeof task.translations[lang] !== 'object' || Array.isArray(task.translations[lang])) task.translations[lang] = {};
    });
    if (!task.translations.ENG || typeof task.translations.ENG !== 'object') task.translations.ENG = {};
    TM_TRANSLATABLE_TASK_FIELDS.forEach(field => {
        if (!Object.prototype.hasOwnProperty.call(task.translations.ENG, field)) task.translations.ENG[field] = task[field] !== undefined && task[field] !== null ? String(task[field]) : '';
        values.availableLanguages.forEach(lang => {
            if (!Object.prototype.hasOwnProperty.call(task.translations[lang], field)) task.translations[lang][field] = lang === 'ENG' ? task.translations.ENG[field] : '';
        });
    });
    if (!task.textFormats || typeof task.textFormats !== 'object' || Array.isArray(task.textFormats)) task.textFormats = {};
    TM_TEXT_FORMAT_FIELDS.forEach(field => { task.textFormats[field] = tmNormalizeTextFormat(task.textFormats[field]); });
    return task;
}

function tmEnsureAllTaskTranslations() {
    if (!Array.isArray(state.entries)) state.entries = [];
    state.entries.forEach(entry => tmEnsureTaskTranslationContainers(entry));
}

function tmLocalizedTaskText(task, field) {
    if (!task) return '';
    tmEnsureTaskTranslationContainers(task);
    const values = tmEnsureValues();
    const lang = values.currentLanguage || 'ENG';
    const bucket = task.translations[lang] || {};
    if (Object.prototype.hasOwnProperty.call(bucket, field)) return bucket[field] || '';
    return lang === 'ENG' ? (task[field] || '') : '';
}

function tmSetLocalizedTaskText(task, field, value) {
    if (!task) return;
    tmEnsureTaskTranslationContainers(task);
    const values = tmEnsureValues();
    const lang = values.currentLanguage || 'ENG';
    task.translations[lang][field] = value;
    if (lang === 'ENG') task[field] = value;
}

function tmGetTaskTextFormat(task, field) {
    tmEnsureTaskTranslationContainers(task);
    return tmNormalizeTextFormat(task.textFormats ? task.textFormats[field] : null);
}

function tmSetTaskTextFormat(task, field, format) {
    if (!task) return;
    tmEnsureTaskTranslationContainers(task);
    task.textFormats[field] = tmNormalizeTextFormat(format);
}

function tmToggleTextFormat(taskId, field, command, value) {
    const task = state.entries.find(entry => entry.id === taskId) || state.entries.find(entry => entry.id === state.focusedEntryId);
    if (!task) return;
    const format = tmGetTaskTextFormat(task, field);
    if (command === 'bold') format.bold = !format.bold;
    if (command === 'italic') format.italic = !format.italic;
    if (command === 'underline') format.underline = !format.underline;
    if (command === 'strikethrough') format.strikethrough = !format.strikethrough;
    if (command === 'bullet') format.listStyle = format.listStyle === 'bullet' ? 'none' : 'bullet';
    if (command === 'number') format.listStyle = format.listStyle === 'number' ? 'none' : 'number';
    if (command === 'alignH') format.alignH = value || 'left';
    if (command === 'alignV') format.alignV = value || 'top';
    tmSetTaskTextFormat(task, field, format);
    markEdited(task.id);

    const activeInlineEdit = document.querySelector(`.inline-edit-entry:not(.hidden)`);
    const target = activeInlineEdit ? activeInlineEdit.querySelector(`[data-tm-text-target-for="${field}"]`) : null;
    if (target) {
        tmApplyFormatToFieldElement(target, format);
        const toolbar = activeInlineEdit.querySelector(`.tm-format-toolbar[data-tm-format-field="${field}"]`);
        if (toolbar) toolbar.outerHTML = tmRenderTextToolbar(task, field);
    } else if (typeof renderTasksSilently === 'function') {
        renderTasksSilently();
    }

    if (typeof tmMarkAppDirty === 'function') tmMarkAppDirty();
}

function tmRenderTextToolbar(task, field) {
    if (!task) return '';
    const f = tmGetTaskTextFormat(task, field);
    const active = cls => cls ? ' active' : '';
    const safeTaskId = escapeHtml(task.id || '');
    const safeField = escapeHtml(field || '');
    return `
        <div class="tm-format-toolbar" data-tm-format-field="${safeField}">
            <button type="button" class="tm-format-btn tm-font-bold${active(f.bold)}" onclick="tmToggleTextFormat('${safeTaskId}','${safeField}','bold')" title="Bold">B</button>
            <button type="button" class="tm-format-btn tm-italic${active(f.italic)}" onclick="tmToggleTextFormat('${safeTaskId}','${safeField}','italic')" title="Italic">I</button>
            <button type="button" class="tm-format-btn tm-underline${active(f.underline)}" onclick="tmToggleTextFormat('${safeTaskId}','${safeField}','underline')" title="Underline">U</button>
            <button type="button" class="tm-format-btn tm-line-through${active(f.strikethrough)}" onclick="tmToggleTextFormat('${safeTaskId}','${safeField}','strikethrough')" title="Strikethrough">S</button>
            <div class="tm-format-divider"></div>
            <button type="button" class="tm-format-btn${active(f.listStyle === 'bullet')}" onclick="tmToggleTextFormat('${safeTaskId}','${safeField}','bullet')" title="Bullet List"><svg viewBox="0 0 24 24"><path d="M4 6h2v2H4zm0 5h2v2H4zm0 5h2v2H4zm4-10h12v2H8zm0 5h12v2H8zm0 5h12v2H8z"></path></svg></button>
            <button type="button" class="tm-format-btn${active(f.listStyle === 'number')}" onclick="tmToggleTextFormat('${safeTaskId}','${safeField}','number')" title="Numbered List"><svg viewBox="0 0 24 24"><path d="M5 7h1v2H5zm0 4h1v2H5zm0 4h1v2H5zm3-8h12v2H8zm0 4h12v2H8zm0 4h12v2H8z"></path></svg></button>
            <div class="tm-format-divider"></div>
            <button type="button" class="tm-format-btn${active(f.alignH === 'left')}" onclick="tmToggleTextFormat('${safeTaskId}','${safeField}','alignH','left')" title="Align Left"><svg viewBox="0 0 24 24"><path d="M3 5h14v2H3V5zm0 6h8v2H3v-2zm0 6h14v2H3v-2z"></path></svg></button>
            <button type="button" class="tm-format-btn${active(f.alignH === 'center')}" onclick="tmToggleTextFormat('${safeTaskId}','${safeField}','alignH','center')" title="Align Center"><svg viewBox="0 0 24 24"><path d="M5 5h14v2H5V5zm3 6h8v2H8v-2zm-3 6h14v2H5v-2z"></path></svg></button>
            <button type="button" class="tm-format-btn${active(f.alignH === 'right')}" onclick="tmToggleTextFormat('${safeTaskId}','${safeField}','alignH','right')" title="Align Right"><svg viewBox="0 0 24 24"><path d="M7 5h14v2H7V5zm6 6h8v2h-8v-2zm-6 6h14v2H7v-2z"></path></svg></button>
            <button type="button" class="tm-format-btn${active(f.alignH === 'justified')}" onclick="tmToggleTextFormat('${safeTaskId}','${safeField}','alignH','justified')" title="Justified"><svg viewBox="0 0 24 24"><path d="M3 5h18v2H3V5zm0 6h18v2H3v-2zm0 6h18v2H3v-2z"></path></svg></button>
            <div class="tm-format-divider"></div>
            <button type="button" class="tm-format-btn${active(f.alignV === 'top')}" onclick="tmToggleTextFormat('${safeTaskId}','${safeField}','alignV','top')" title="Align Top"><svg viewBox="0 0 24 24"><path d="M5 3h14v2H5V3zm0 4h14v2H5V7zm0 4h8v2H5v-2z"></path></svg></button>
            <button type="button" class="tm-format-btn${active(f.alignV === 'middle')}" onclick="tmToggleTextFormat('${safeTaskId}','${safeField}','alignV','middle')" title="Align Middle"><svg viewBox="0 0 24 24"><path d="M5 9h14v2H5V9zm0 4h8v2H5v-2zm0 4h14v2H5v-2z"></path></svg></button>
            <button type="button" class="tm-format-btn${active(f.alignV === 'bottom')}" onclick="tmToggleTextFormat('${safeTaskId}','${safeField}','alignV','bottom')" title="Align Bottom"><svg viewBox="0 0 24 24"><path d="M5 11h8v2H5v-2zm0 4h14v2H5v-2zm0 4h14v2H5v-2z"></path></svg></button>
        </div>
    `;
}

function tmApplyFormatToFieldElement(fieldEl, format) {
    if (!fieldEl) return;
    const f = tmNormalizeTextFormat(format);
    fieldEl.style.fontWeight = f.bold ? '800' : '';
    fieldEl.style.fontStyle = f.italic ? 'italic' : '';
    const decos = [];
    if (f.underline) decos.push('underline');
    if (f.strikethrough) decos.push('line-through');
    fieldEl.style.textDecoration = decos.length ? decos.join(' ') : '';
    fieldEl.style.textAlign = f.alignH === 'justified' ? 'justify' : f.alignH;
    fieldEl.classList.toggle('tm-list-format-bullet', f.listStyle === 'bullet');
    fieldEl.classList.toggle('tm-list-format-number', f.listStyle === 'number');
    fieldEl.classList.toggle('tm-align-v-top', f.alignV === 'top');
    fieldEl.classList.toggle('tm-align-v-middle', f.alignV === 'middle');
    fieldEl.classList.toggle('tm-align-v-bottom', f.alignV === 'bottom');
}

function tmInferFormatFieldFromElement(el) {
    const inlineTarget = el && el.closest ? el.closest('.inline-edit-entry:not(.hidden)') : null;
    if (!inlineTarget) return '';
    const explicitField = el.dataset ? (el.dataset.tmTextTargetFor || '') : '';
    if (explicitField === 'name' || explicitField === 'desc') return explicitField;
    return '';
}

function tmAttachToolbarToInput(el, task) {
    if (!el || !task) return;
    if (el.closest && (el.closest('.left-panel') || el.closest('aside') || el.closest('.sidebar-section'))) return;
    const field = tmInferFormatFieldFromElement(el);
    if (!field) return;
    if (el.dataset.tmToolbarAttached === '1') {
        const previous = el.parentElement ? el.parentElement.querySelector(`.tm-format-toolbar[data-tm-format-field="${field}"]`) : null;
        if (previous) previous.outerHTML = tmRenderTextToolbar(task, field);
        tmApplyFormatToFieldElement(el, tmGetTaskTextFormat(task, field));
        return;
    }
    const wrap = document.createElement('div');
    wrap.className = 'tm-format-toolbar-host';
    wrap.innerHTML = tmRenderTextToolbar(task, field);
    el.parentNode.insertBefore(wrap, el);
    el.dataset.tmToolbarAttached = '1';
    el.dataset.tmTextTargetFor = field;
    tmApplyFormatToFieldElement(el, tmGetTaskTextFormat(task, field));
}

function tmRenderFormTextToolbars() {
    document.querySelectorAll('.tm-format-toolbar-host').forEach(host => host.remove());
    document.querySelectorAll('[data-tm-toolbar-attached="1"]').forEach(el => {
        delete el.dataset.tmToolbarAttached;
        if (!el.closest || !el.closest('.inline-edit-entry:not(.hidden)')) delete el.dataset.tmTextTargetFor;
    });

    const activeInlineEdit = document.querySelector('.inline-edit-entry:not(.hidden)');
    if (!activeInlineEdit) return;

    const taskId = (activeInlineEdit.id || '').replace(/^entry-text-wrapper-/, '') || state.focusedEntryId || '';
    const task = state.entries.find(entry => entry.id === taskId);
    if (!task) return;
    tmEnsureTaskTranslationContainers(task);

    ['name', 'desc'].forEach(field => {
        const toolbar = activeInlineEdit.querySelector(`.tm-format-toolbar[data-tm-format-field="${field}"]`);
        if (toolbar) toolbar.outerHTML = tmRenderTextToolbar(task, field);
        const target = activeInlineEdit.querySelector(`[data-tm-text-target-for="${field}"]`);
        if (target) tmApplyFormatToFieldElement(target, tmGetTaskTextFormat(task, field));
    });
}

function tmRefreshLocalizedUi() {
    tmEnsureAllTaskTranslations();
    tmRefreshLanguageDropdown();
    const taskId = document.getElementById('taskId')?.value || state.focusedEntryId || '';
    const task = state.entries.find(entry => entry.id === taskId);
    if (task && typeof populateFormForTask === 'function') populateFormForTask(task);
    if (typeof renderTasksSilently === 'function') renderTasksSilently();
    else if (typeof fullRender === 'function') fullRender();
    tmRenderFormTextToolbars();
}

function tmUpdateLocalizedTaskField(taskId, field, value) {
    const entry = state.entries.find(e => e.id === taskId);
    if (!entry) return false;
    if (!TM_TRANSLATABLE_TASK_FIELDS.includes(field)) return false;
    tmSetLocalizedTaskText(entry, field, value);
    return true;
}

function tmBuildWorkspacePayload() {
    const values = tmEnsureValues();
    tmEnsureAllTaskTranslations();
    return {
        version: 'TaskManager_2026_06_09_language_auth_patch',
        exportedAt: new Date().toISOString(),
        tabs: Array.isArray(state.tabs) ? state.tabs : [],
        tabColors: state.tabColors || {},
        activeTab: state.activeTab || '',
        entries: Array.isArray(state.entries) ? state.entries : [],
        globalCustomFields: Array.isArray(state.globalCustomFields) ? state.globalCustomFields : [],
        globalTags: state.globalTags || {},
        Values: values,
        Sprites: Array.isArray(state.Sprites) ? state.Sprites : [],
        phases: Array.isArray(state.phases) ? state.phases : []
    };
}

function tmNormalizeImportedValues(values) {
    const defaults = (typeof createDefaultTaskValues === 'function') ? createDefaultTaskValues() : { availableLanguages: ['ENG'], currentLanguage: 'ENG' };
    const src = values && typeof values === 'object' ? values : {};
    const out = Object.assign(defaults, src);
    ['globalTokens','globalCast','globalStates','globalMoods','globalSettings','globalTimesOfDay','globalDaysOfWeek','globalMenuOptions','globalImageSequences'].forEach(key => { if (!Array.isArray(out[key])) out[key] = []; });
    if (!Array.isArray(out.availableLanguages) || out.availableLanguages.length === 0) out.availableLanguages = ['ENG'];
    out.availableLanguages = out.availableLanguages.map(tmNormalizeLanguageCode).filter(Boolean);
    if (!out.availableLanguages.includes('ENG')) out.availableLanguages.unshift('ENG');
    out.currentLanguage = tmNormalizeLanguageCode(out.currentLanguage || 'ENG') || 'ENG';
    if (!out.availableLanguages.includes(out.currentLanguage)) out.availableLanguages.push(out.currentLanguage);
    return out;
}

function tmApplyWorkspacePayload(payload) {
    const data = payload && typeof payload === 'object' ? payload : {};
    const workspace = data.workspace && typeof data.workspace === 'object' ? data.workspace : data;
    if (Array.isArray(workspace.tabs)) state.tabs = workspace.tabs;
    if (workspace.tabColors && typeof workspace.tabColors === 'object') state.tabColors = workspace.tabColors;
    if (workspace.activeTab) state.activeTab = workspace.activeTab;
    if (Array.isArray(workspace.entries)) state.entries = workspace.entries.map(entry => {
        const normalized = (typeof createBaseEntry === 'function') ? createBaseEntry(entry) : entry;
        tmEnsureTaskTranslationContainers(normalized);
        return normalized;
    });
    if (Array.isArray(workspace.globalCustomFields)) state.globalCustomFields = workspace.globalCustomFields;
    if (workspace.globalTags && typeof workspace.globalTags === 'object') state.globalTags = workspace.globalTags;
    const importedValues = workspace.Values || workspace.values || data.Values || data.values || {};
    state.Values = tmNormalizeImportedValues(importedValues);
    if (Array.isArray(workspace.Sprites)) state.Sprites = workspace.Sprites;
    else if (Array.isArray(data.Sprites)) state.Sprites = data.Sprites;
    if (Array.isArray(workspace.phases)) state.phases = workspace.phases;
    const sessionId = data.sessionId || workspace.sessionId || state.Values.serverSessionId || '';
    if (sessionId) {
        state.Values.serverSessionId = sessionId;
        state.serverSessionId = sessionId;
        try { localStorage.setItem(TM_SESSION_STORAGE_KEY, sessionId); } catch (err) {}
    }
    tmEnsureAllTaskTranslations();
    if (typeof syncFocus === 'function') syncFocus();
    if (typeof recalculateTags === 'function') recalculateTags();
    if (typeof fullRender === 'function') fullRender();
    if (typeof tmRenderValuesTab === 'function') tmRenderValuesTab();
    if (typeof tmRefreshTaskGiverControls === 'function') tmRefreshTaskGiverControls();
    if (typeof tmRefreshLanguageDropdown === 'function') tmRefreshLanguageDropdown();
    tmSetPushDirty(false);
}

function exportData() {
    const blob = new Blob([JSON.stringify(tmBuildWorkspacePayload(), null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    a.download = `TaskManager_${stamp}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    if (typeof showNotification === 'function') showNotification('Task Manager JSON Exported');
}

function importData(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
        try {
            tmApplyWorkspacePayload(JSON.parse(e.target.result));
            if (typeof showNotification === 'function') showNotification(`Imported ${file.name}`);
        } catch (err) {
            console.error('Task Manager Import Error', err);
            if (typeof showNotification === 'function') showNotification('Import failed: ' + err.message, true);
        }
    };
    reader.readAsText(file);
    event.target.value = '';
}

function tmSetPushDirty(isDirty = true) {
    try { localStorage.setItem(TM_DIRTY_STORAGE_KEY, isDirty ? '1' : '0'); } catch (err) {}
    const btn = document.getElementById('tmPushServerBtn');
    if (btn) btn.classList.toggle('is-dirty', !!isDirty);
}

function tmMarkAppDirty() { tmSetPushDirty(true); }

function tmScheduleSharedSave() {
    clearTimeout(tmSharedSaveTimer);
    tmSharedSaveTimer = setTimeout(async () => {
        try {
            const values = tmEnsureValues();
            await tmFetchJson(tmUrl(TM_API_FILE, { action: 'saveSharedDialogueValues', sessionId: values.serverSessionId }), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ Values: values, Sprites: state.Sprites || [] })
            });
        } catch (err) {
            console.warn('Shared Values save skipped:', err.message);
        }
    }, 1200);
}

async function tmSaveSession() {
    const btn = document.getElementById('tmPushServerBtn');
    try {
        if (btn) btn.classList.add('is-pushing');
        const payload = tmBuildWorkspacePayload();
        const data = await tmFetchJson(tmUrl(TM_API_FILE, { action: 'saveSession', sessionId: payload.Values.serverSessionId }), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        if (data.sessionId) payload.Values.serverSessionId = data.sessionId;
        if (data.workspace) tmApplyWorkspacePayload(data.workspace);
        tmSetPushDirty(false);
        if (typeof showNotification === 'function') showNotification('Task Manager pushed to server.');
        await tmAccountStatus(false);
    } catch (err) {
        if (typeof showNotification === 'function') showNotification('Server push failed: ' + err.message, true);
    } finally {
        if (btn) btn.classList.remove('is-pushing');
    }
}

async function tmLoadSessionById(sessionId) {
    const clean = String(sessionId || '').trim();
    if (!clean) return;
    try {
        const data = await tmFetchJson(tmUrl(TM_API_FILE, { action: 'loadSession', sessionId: clean }));
        tmApplyWorkspacePayload(data.workspace || data);
        if (typeof showNotification === 'function') showNotification('Server session loaded.');
    } catch (err) {
        if (typeof showNotification === 'function') showNotification('Load Session Failed: ' + err.message, true);
    }
}

async function tmLoadLatestSession() {
    try {
        const values = tmEnsureValues();
        const data = await tmFetchJson(tmUrl(TM_API_FILE, { action: 'loadLatest', sessionId: values.serverSessionId || '' }));
        if (data && (data.workspace || data.Values || data.entries)) tmApplyWorkspacePayload(data.workspace || data);
    } catch (err) {
        console.warn('Task Manager latest session load skipped:', err.message);
    }
}

async function tmAccountStatus(loadLatest = false) {
    const data = await tmFetchJson(tmUrl(TM_AUTH_FILE, { action: 'accountStatus' }));
    tmSetAccountButtonState(data);
    const modal = document.getElementById('account-modal') || document.getElementById('tmAccountModal');
    if (modal && (modal.style.display === 'flex' || modal.classList.contains('account-modal-open'))) tmRenderAccountModal(data);
    if (data.loggedIn && loadLatest && !tmStatusBootLoadedSession) {
        tmStatusBootLoadedSession = true;
        await tmLoadLatestSession();
    }
    return data;
}

function tmInstallFormattingObserver() {
    const run = () => tmRenderFormTextToolbars();
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run, { once: true });
    else setTimeout(run, 0);
}

tmInstallFormattingObserver();

(function(){
    function bootTaskManagerChrome(){
        if (typeof tmInjectBaseUi === 'function') tmInjectBaseUi();
        if (typeof tmRefreshLanguageDropdown === 'function') tmRefreshLanguageDropdown();
        if (typeof tmAccountStatus === 'function') tmAccountStatus(true);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bootTaskManagerChrome, { once: true });
    else setTimeout(bootTaskManagerChrome, 0);
})();
