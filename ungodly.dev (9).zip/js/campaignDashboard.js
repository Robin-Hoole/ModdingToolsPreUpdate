// --- API CONFIGURATION ---
const API_URL = '../api3.php';

// --- SINGLE SOURCE OF TRUTH DATA MODEL ---
let appData = {
    consciences: [],
    pantheons: [],
    worlds: [],
    timeline: [],
    alignments: []
};

let activeCharacterView = 'god'; // 'god', 'villager', or 'conscience'

// --- RENDER FUNCTIONS ---
function renderAll() {
    renderTimeline();
    renderCharacterPanel();
    renderAlignmentsTool();
}

function renderCharacterPanel() {
    renderCharacterFilters();
    const container = document.getElementById('characters-container');
    container.innerHTML = '';

    if (activeCharacterView === 'god') {
        (appData.pantheons || []).forEach(pantheon => {
            container.insertAdjacentHTML('beforeend', createOrganizationCard(pantheon, 'pantheon', 'God'));
        });
    } else if (activeCharacterView === 'villager') {
        (appData.worlds || []).forEach(world => {
            container.insertAdjacentHTML('beforeend', createOrganizationCard(world, 'world', 'Villager'));
        });
    } else if (activeCharacterView === 'conscience') {
        const consciencesHTML = (appData.consciences || []).map(c => createCharacterCard(c, null, 'conscience')).join('');
        container.innerHTML = `<div class="p-3 space-y-2">${consciencesHTML || '<p class="text-xs text-zinc-500">No consciences found.</p>'}</div>`;
    }
    updateHeaderButtons();
}

function renderCharacterFilters() {
    const container = document.getElementById('character-type-filter');
    container.innerHTML = `
        <button class="btn type-filter-btn ${activeCharacterView === 'god' ? 'active' : ''}" onclick="switchCharacterView('god')">Gods</button>
        <button class="btn type-filter-btn ${activeCharacterView === 'villager' ? 'active' : ''}" onclick="switchCharacterView('villager')">Villagers</button>
        <button class="btn type-filter-btn ${activeCharacterView === 'conscience' ? 'active' : ''}" onclick="switchCharacterView('conscience')">Consciences</button>
    `;
}

function renderTimeline() {
    const container = document.getElementById('timeline-container');
    container.innerHTML = '';
    (appData.timeline || []).forEach((item, index) => {
        if (index > 0) {
            const connector = document.createElement('div');
            connector.className = 'timeline-connector';
            container.appendChild(connector);
        }
        const cardHTML = item.type === 'land' ? createLandCard(item) : createTitanCard(item);
        container.insertAdjacentHTML('beforeend', cardHTML);
    });
}

// --- [MERGED] --- This is the working function from your second script
function renderAlignmentsTool() {
    const wrapper = document.getElementById('alignments-container-wrapper');
    wrapper.innerHTML = `
        <div class="alignment-container">
            <svg class="absolute h-full" style="z-index: 0; width: 300%; left: -100%;">
                <defs>
                    <marker id="arrowhead" markerWidth="5" markerHeight="3" refX="5" refY="1.5" orient="auto">
                        <polygon points="0 0, 5 1.5, 0 3" fill="#666666" />
                    </marker>
                </defs>
                <line x1="0%" y1="50%" x2="100%" y2="50%" stroke="#f8fafc" stroke-width="2" stroke-dasharray="5, 5" />
                <line x1="38%" y1="7%" x2="41.67%" y2="35%" stroke="#666666" stroke-width="2" stroke-dasharray="5, 5" marker-end="url(#arrowhead)"/>
                <line x1="38%" y1="7%" x2="50%" y2="20%" stroke="#666666" stroke-width="2" stroke-dasharray="5, 5" marker-end="url(#arrowhead)"/>
                <line x1="38%" y1="7%" x2="41.67%" y2="65%" stroke="#666666" stroke-width="2" stroke-dasharray="5, 5" marker-end="url(#arrowhead)"/>
                <line x1="62%" y1="93%" x2="58.33%" y2="35%" stroke="#666666" stroke-width="2" stroke-dasharray="5, 5" marker-end="url(#arrowhead)"/>
                <line x1="62%" y1="93%" x2="50%" y2="80%" stroke="#666666" stroke-width="2" stroke-dasharray="5, 5" marker-end="url(#arrowhead)"/>
                <line x1="62%" y1="93%" x2="58.33%" y2="65%" stroke="#666666" stroke-width="2" stroke-dasharray="5, 5" marker-end="url(#arrowhead)"/>
            </svg>
            <div class="alignment-note-container note-passive"><span class="main-text">Passive</span></div>
            <div class="alignment-note-container note-active"><span class="main-text">Active</span></div>
            <div class="note-idealism">Idealism</div>
            <div class="note-vice">Vice</div>
            <div class="alignment-note-container note-nature"><span class="main-text">Stewardship</span><span class="sub-text">promote nature</span></div>
            <div class="alignment-note-container note-good"><span class="main-text">Selflessness</span><span class="sub-text">promote people</span></div>
            <div class="alignment-note-container note-war"><span class="main-text">Protection</span><span class="sub-text">promote conquest</span></div>
            <div class="alignment-note-container note-economy"><span class="main-text">Abundance</span><span class="sub-text">promote wealth</span></div>
            <div class="alignment-note-container note-evil"><span class="main-text">Selfishness</span><span class="sub-text">promote suffering</span></div>
            <div class="alignment-note-container note-arcane"><span class="main-text">Consumption</span><span class="sub-text">promote addiction</span></div>
            
            <div class="alignment-circle circle-good" data-alignment="good">Good</div>
            <div class="alignment-circle circle-nature" data-alignment="nature">Nature</div>
            <div class="alignment-circle circle-war" data-alignment="war">War</div>
            <div class="alignment-circle circle-evil" data-alignment="evil">Evil</div>
            <div class="alignment-circle circle-economy" data-alignment="economy">Economy</div>
            <div class="alignment-circle circle-arcane" data-alignment="arcane">Arcane</div>
        </div>
    `;
    
    wrapper.querySelectorAll('.alignment-circle').forEach(circle => {
        circle.addEventListener('click', (e) => {
            const alignmentId = e.target.dataset.alignment;
            openAlignmentModal(alignmentId);
        });
    });
}


// --- HTML ELEMENT CREATORS ---
function createOrganizationCard(org, type, charType) {
    const characters = org.characters || [];
    const charactersHTML = characters.map(c => createCharacterCard(c, org.id, type)).join('');
    return `
        <details class="dashboard-module" open>
            <summary class="dashboard-module-header cursor-pointer flex justify-between items-center">
                <span class="dashboard-module-title">${org.name} (${characters.length})</span>
                <button onclick="event.preventDefault(); openModal('${type}', '${org.id}')" class="btn btn-yellow btn-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clip-rule="evenodd" /></svg>
                </button>
            </summary>
            <div class="p-3 space-y-2 org-drop-zone" data-org-id="${org.id}" data-org-type="${type}" ondragover="handleDragOver(event)" ondragleave="handleDragLeave(event)" ondrop="handleDrop(event)">
                ${charactersHTML || `<p class="text-xs text-zinc-500">No ${charType}s in this ${type}.</p>`}
            </div>
        </details>
    `;
}

function createCharacterCard(char, orgId, orgType) {
    return `
        <div id="${char.id}" class="bg-zinc-800 border border-zinc-700 p-2 relative group cursor-grab" draggable="true" ondragstart="handleDragStart(event, '${char.id}', '${orgId}', '${orgType}')">
            <h5 class="font-bold" style="color: ${char.color || '#EF4444'}">${char.name}</h5>
            <div class="text-xs space-y-0.5 mt-1">
                ${char.creature ? `<p><span class="text-zinc-500">Creature:</span> ${char.creature}</p>` : ''}
                ${char.fate ? `<p><span class="text-zinc-500">Fate:</span> ${char.fate}</p>` : ''}
                ${char.role ? `<p><span class="text-zinc-500">Role:</span> ${char.role}</p>` : ''}
                ${char.alignment ? `<p><span class="text-zinc-500">Alignment:</span> ${char.alignment}</p>` : ''}
            </div>
            <button onclick="openModal('character', {charId: '${char.id}', orgId: '${orgId}', orgType: '${orgType}'})" class="absolute top-1 right-1 btn btn-yellow btn-icon opacity-0 group-hover:opacity-100 transition-opacity">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clip-rule="evenodd" /></svg>
            </button>
        </div>
    `;
}

function createLandCard(item) {
    const storyBeatsHTML = (item.storyBeats || []).map(beat => `<div class="story-beat text-xs mb-2">${beat}</div>`).join('');
    return `
        <div class="flex flex-col items-center flex-shrink-0 w-72 relative group timeline-item-container">
            <div class="mb-2 w-full text-center">${storyBeatsHTML}</div>
            <div id="${item.id}" class="land-card dashboard-module w-full">
                <div class="dashboard-module-header flex justify-between items-center">
                    <h4 class="dashboard-module-title text-red-500">${item.title}</h4>
                    <button onclick="openModal('land', '${item.id}')" class="btn btn-yellow btn-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clip-rule="evenodd" /></svg>
                    </button>
                </div>
                <div class="p-3 space-y-2">
                    <p class="text-center text-zinc-400 font-semibold">${item.location}</p>
                    <div class="grid grid-cols-2 gap-x-4 gap-y-1 text-sm pt-2">
                        <span class="text-zinc-500">Climate:</span> <span>${item.climate}</span>
                        <span class="text-zinc-500">Temp:</span> <span>${item.temp}</span>
                        <span class="text-zinc-500">Water:</span> <span>${item.water}</span>
                        <span class="text-zinc-500">Vegetation:</span> <span>${item.vegetation}</span>
                        <span class="text-zinc-500">Predator:</span> <span>${item.predator}</span>
                        <span class="text-zinc-500">Forage:</span> <span>${item.forage}</span>
                    </div>
                    <div class="border-t border-zinc-700 mt-2 pt-2 text-center">
                        <p class="text-xs text-zinc-500">Invader: <span class="font-semibold text-red-400">${item.invader}</span></p>
                        <p class="text-xs text-zinc-500">Defender: <span class="font-semibold text-yellow-400">${item.defender}</span></p>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function createTitanCard(item) {
    return `
        <div id="${item.id}" class="titan-card p-4 w-40 text-center relative group flex-shrink-0">
            <h4 class="font-bold text-red-500">${item.title}</h4>
            <p class="text-sm text-zinc-400">Creeds: <span class="font-semibold">${item.creeds}</span></p>
            <button onclick="openModal('titan', '${item.id}')" class="absolute top-1 right-1 btn btn-yellow btn-icon">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clip-rule="evenodd" /></svg>
            </button>
        </div>
    `;
}

// --- MODAL LOGIC ---
const modalBackdrop = document.getElementById('modal-backdrop');
const modalContainer = document.getElementById('modal-container');
const modalContent = document.getElementById('modal-content');
const alignmentModalOverlay = document.getElementById('alignment-modal-overlay');
const alignmentModalContent = document.getElementById('alignment-modal-content');

function createModalCloseButton() {
    return `<button onclick="closeModal()" class="absolute top-2 right-2 text-zinc-500 hover:text-white transition-colors"><svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" /></svg></button>`;
}

function openModal(type, params = null) {
    let content = '';
    if (type === 'character') {
        const isEditing = !!params;
        let char = { id: null, name: '', creature: '', fate: '', alignment: '', role: '', color: '#EF4444' };
        let orgId = null;
        let orgType = activeCharacterView === 'god' ? 'pantheon' : 'world';

        if(isEditing) {
            orgId = params.orgId;
            orgType = params.orgType;
            if(orgType === 'conscience'){
                char = appData.consciences.find(c => c.id === params.charId);
            } else {
                const orgList = orgType === 'pantheon' ? appData.pantheons : appData.worlds;
                const org = orgList.find(o => o.id === orgId);
                if(org) char = org.characters.find(c => c.id === params.charId);
            }
        }
        
        let orgOptionsHTML = '';
        if(activeCharacterView !== 'conscience') {
            const orgList = activeCharacterView === 'god' ? appData.pantheons : appData.worlds;
            orgOptionsHTML = orgList.map(p => `<option value="${p.id}" ${orgId === p.id ? 'selected' : ''}>${p.name}</option>`).join('');
        }

        const alignmentOptions = appData.alignments.map(a => `<option value="${a.name}" ${char.alignment === a.name ? 'selected' : ''}>${a.name}</option>`).join('');
        
        content = `
            ${createModalCloseButton()}
            <div class="dashboard-module-header"><h3 class="dashboard-module-title">${isEditing ? 'Edit' : 'Add'} ${activeCharacterView}</h3></div>
            <div class="modal-body">
                <form id="modal-form" class="space-y-3">
                    <input type="hidden" id="modalCharId" value="${isEditing ? params.charId : ''}">
                    <input type="hidden" id="modalOrgId" value="${isEditing ? params.orgId : ''}">
                    <div class="flex items-center space-x-4">
                        <div class="flex-grow"><label class="text-sm">Name</label><input type="text" id="char-name" value="${char.name}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                        <div><label class="text-sm">Color</label><input type="color" id="char-color" value="${char.color}" class="mt-1 block w-16 h-9 bg-zinc-900 border border-zinc-700"></div>
                    </div>
                    <div><label class="text-sm">Creature</label><input type="text" id="char-creature" value="${char.creature || ''}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                    <div><label class="text-sm">Fate</label><input type="text" id="char-fate" value="${char.fate || ''}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                    <div><label class="text-sm">Role</label><input type="text" id="char-role" value="${char.role || ''}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                    <div><label class="text-sm">Alignment</label><select id="char-alignment" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2">${alignmentOptions}</select></div>
                    ${activeCharacterView !== 'conscience' ? `<div><label class="text-sm">${activeCharacterView === 'god' ? 'Pantheon' : 'World'}</label><select id="char-organization" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2">${orgOptionsHTML}</select></div>` : ''}
                </form>
                <div class="mt-6 flex justify-end space-x-3">
                    ${isEditing ? `<button onclick="deleteData('character', { charId: '${params.charId}', orgId: '${params.orgId}', orgType: '${params.orgType}' })" class="btn btn-red px-3 py-1.5">Delete</button>` : ''}
                    <button onclick="closeModal()" class="btn btn-neutral">Cancel</button>
                    <button onclick="saveData('character')" class="btn btn-save">${isEditing ? 'Save Changes' : 'Add Character'}</button>
                </div>
            </div>
        `;
    } else if (type === 'pantheon' || type === 'world') {
        const isEditing = !!params;
        const orgList = type === 'pantheon' ? appData.pantheons : appData.worlds;
        const org = isEditing ? orgList.find(o => o.id === params) : { id: null, name: '' };
        const title = `${isEditing ? 'Edit' : 'Add'} ${type.charAt(0).toUpperCase() + type.slice(1)}`;
        content = `
            ${createModalCloseButton()}
            <div class="dashboard-module-header"><h3 class="dashboard-module-title">${title}</h3></div>
            <div class="modal-body">
                <form id="modal-form" class="space-y-3">
                    <input type="hidden" id="modalId" value="${isEditing ? params : ''}">
                    <div><label class="text-sm">${type} Name</label><input type="text" id="org-name" value="${org.name}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                </form>
                <div class="mt-6 flex justify-between">
                    ${isEditing ? `<button onclick="deleteData('${type}', '${params}')" class="btn btn-red px-3 py-1.5">Delete</button>` : '<div></div>'}
                    <div class="flex space-x-3">
                        <button onclick="closeModal()" class="btn btn-neutral">Cancel</button>
                        <button onclick="saveData('${type}')" class="btn btn-save">${isEditing ? 'Save Changes' : `Add ${type}`}</button>
                    </div>
                </div>
            </div>
        `;
    } else if (type === 'land') {
        const land = appData.timeline.find(l => l.id === params);
        const storyBeatsHTML = (land.storyBeats || []).map(beat => `
            <div class="flex items-center space-x-2 story-beat-entry">
                <input type="text" class="flex-grow bg-zinc-900 border border-zinc-700 p-2 story-beat-input" value="${beat}">
                <button type="button" onclick="this.parentElement.remove()" class="btn btn-red btn-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" /></svg>
                </button>
            </div>
        `).join('');

        content = `
            ${createModalCloseButton()}
            <div class="dashboard-module-header"><h3 class="dashboard-module-title">Edit Land: ${land.title}</h3></div>
            <div class="modal-body">
                <form id="modal-form" class="grid grid-cols-2 gap-4 mb-4">
                    <input type="hidden" id="modalId" value="${params}">
                    <div><label class="text-sm">Title</label><input type="text" id="land-title" value="${land.title}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                    <div><label class="text-sm">Location</label><input type="text" id="land-location" value="${land.location}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                    <div><label class="text-sm">Climate</label><input type="text" id="land-climate" value="${land.climate}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                    <div><label class="text-sm">Temperature</label><input type="text" id="land-temp" value="${land.temp}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                    <div><label class="text-sm">Water</label><input type="text" id="land-water" value="${land.water}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                    <div><label class="text-sm">Vegetation</label><input type="text" id="land-vegetation" value="${land.vegetation}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                    <div><label class="text-sm">Apex Predator</label><input type="text" id="land-predator" value="${land.predator}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                    <div><label class="text-sm">Forage</label><input type="text" id="land-forage" value="${land.forage}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                    <div><label class="text-sm">Invader</label><input type="text" id="land-invader" value="${land.invader}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                    <div><label class="text-sm">Defender</label><input type="text" id="land-defender" value="${land.defender}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                </form>
                <div class="border-t border-zinc-700 pt-4 mt-auto">
                    <h4 class="text-sm font-semibold mb-2">Story Beats</h4>
                    <div id="story-beats-container" class="space-y-2 pr-2">${storyBeatsHTML}</div>
                    <button onclick="addStoryBeatInput()" class="btn btn-save w-full mt-3">Add Story Beat</button>
                </div>
                <div class="mt-6 flex justify-between items-center border-t border-zinc-700 pt-4">
                    <button onclick="deleteData('land', '${params}')" class="btn btn-red">Delete Land</button>
                    <div class="flex space-x-3">
                        <button onclick="closeModal()" class="btn btn-neutral">Cancel</button>
                        <button onclick="saveData('land')" class="btn btn-save">Save Changes</button>
                    </div>
                </div>
            </div>
        `;
    } else if (type === 'titan') {
        const titan = appData.timeline.find(t => t.id === params);
        content = `
            ${createModalCloseButton()}
            <div class="dashboard-module-header"><h3 class="dashboard-module-title">Edit Titan World</h3></div>
            <div class="modal-body">
                <form id="modal-form" class="space-y-3">
                    <input type="hidden" id="modalId" value="${params}">
                    <div><label class="text-sm">Title</label><input type="text" id="titan-title" value="${titan.title}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                    <div><label class="text-sm">Creeds</label><input type="text" id="titan-creeds" value="${titan.creeds}" class="mt-1 block w-full bg-zinc-900 border border-zinc-700 p-2"></div>
                </form>
                <div class="mt-6 flex justify-end space-x-3">
                    <button onclick="deleteData('titan', '${params}')" class="btn btn-red">Delete Titan</button>
                    <button onclick="closeModal()" class="btn btn-neutral">Cancel</button>
                    <button onclick="saveData('titan')" class="btn btn-save">Save Changes</button>
                </div>
            </div>
        `;
    }
    modalContent.innerHTML = content;
    modalBackdrop.classList.remove('hidden');
    modalContainer.classList.remove('hidden');
}

// --- [MERGED] --- This is the working function from your second script
function openAlignmentModal(alignmentId) {
    const alignment = appData.alignments.find(a => a.id === alignmentId);
    if (!alignment) return;

    alignmentModalContent.style.borderColor = alignment.color;
    alignmentModalContent.style.boxShadow = `0 0 30px ${alignment.color}`;

    const feelings = ['Admires', 'Adores', 'Agrees With', 'Allied With', 'Amused By', 'Apathetic Towards', 'Approves Of', 'Aspires To Be', 'Befriended', 'Cherishes', 'Confused By', 'Curious About', 'Despises', 'Detests', 'Disagrees With', 'Distrusts', 'Dreads', 'Envious Of', 'Fears', 'Feels Betrayed By', 'Feels Pity For', 'Friendly Towards', 'Hates', 'Idolizes', 'Ignores', 'Intrigued By', 'Jealous Of', 'Likes', 'Loathes', 'Loves', 'Mistrusts', 'Neutral Towards', 'Opposes', 'Protective Of', 'Respects', 'Resents', 'Skeptical Of', 'Supports', 'Suspicious Of', 'Tolerates', 'Treasures', 'Trusts', 'Underestimates', 'Values', 'Wary Of', 'Worships'];
    let otherAlignmentsHtml = '';
    appData.alignments.forEach(other => {
        if (other.id !== alignmentId) {
            const currentFeeling = alignment.relationships ? (alignment.relationships[other.id] || 'Neutral Towards') : 'Neutral Towards';
            const options = feelings.map(feeling => `<option value="${feeling}" ${feeling === currentFeeling ? 'selected' : ''}>${feeling}</option>`).join('');
            otherAlignmentsHtml += `
                <div class="input-group">
                    <label>Relationship with ${other.name}</label>
                    <select data-target-id="${other.id}">${options}</select>
                </div>
            `;
        }
    });

    alignmentModalContent.innerHTML = `
        <h2 class="modal-title" style="color: ${alignment.color};">${alignment.name}</h2>
        <div id="imagePreviewContainer" class="my-4 ${alignment.imageUrl ? '' : 'hidden'}">
            <img id="imagePreview" src="${alignment.imageUrl || ''}" alt="Image Preview" class="max-w-full h-auto rounded-lg mx-auto cursor-pointer" onclick="openLightbox(this.src)">
        </div>
        <div class="input-group">
            <label>Image URL</label>
            <div class="flex items-center space-x-2">
                <input type="text" id="imageUrlInput" class="flex-grow" placeholder="https://example.com/image.png" value="${alignment.imageUrl || ''}">
                <button id="loadImageBtn" class="px-4 py-2 bg-gray-600 hover:bg-gray-500 rounded-md text-white font-semibold">Load</button>
            </div>
        </div>
        <div class="input-group"><label>Ontology</label><textarea id="ontology" rows="3" placeholder="Dealing with the nature of being, what is.">${alignment.ontology || ''}</textarea></div>
        <div class="input-group"><label>Epistemology</label><textarea id="epistemology" rows="3" placeholder="Distinguishes justified belief from opinion.">${alignment.epistemology || ''}</textarea></div>
        <div class="input-group"><label>Axiology</label><textarea id="axiology" rows="3" placeholder="The study of value, what ought to be.">${alignment.axiology || ''}</textarea></div>
        <div class="input-group"><label>Appearance</label><textarea id="appearance" rows="3" placeholder="A physical description.">${alignment.appearance || ''}</textarea></div>
        <div class="input-group"><label>Personality</label><textarea id="personality" rows="3" placeholder="How they behave.">${alignment.personality || ''}</textarea></div>
        <div class="input-group"><label>Fatal Flaw</label><textarea id="fatalFlaw" rows="3" placeholder="Main weakness.">${alignment.fatalFlaw || ''}</textarea></div>
        <div class="input-group"><label>Encouragement</label><textarea id="encouragement" rows="3" placeholder="What they promote in gameplay.">${alignment.encouragement || ''}</textarea></div>
        ${otherAlignmentsHtml}
        <button onclick="saveAlignmentData('${alignmentId}')" class="w-full mt-6 px-4 py-3 bg-green-600 hover:bg-green-500 rounded-md text-white font-semibold text-lg">Save & Push</button>
    `;
    alignmentModalOverlay.classList.add('active');

    document.getElementById('loadImageBtn').addEventListener('click', () => {
        const imageUrl = document.getElementById('imageUrlInput').value.trim();
        if (imageUrl) {
            const previewImg = document.getElementById('imagePreview');
            previewImg.src = imageUrl;
            previewImg.setAttribute('onclick', `openLightbox('${imageUrl}')`);
            document.getElementById('imagePreviewContainer').classList.remove('hidden');
        }
    });
}


function closeModal() {
    modalBackdrop.classList.add('hidden');
    modalContainer.classList.add('hidden');
    alignmentModalOverlay.classList.remove('active');
}

function openLightbox(imageUrl) {
    if (!imageUrl) return;
    const lightboxOverlay = document.getElementById('lightbox-overlay');
    const lightboxImage = document.getElementById('lightbox-image');
    lightboxImage.src = imageUrl;
    lightboxOverlay.classList.add('active');
}


function addStoryBeatInput() {
    const container = document.getElementById('story-beats-container');
    const newEntry = document.createElement('div');
    newEntry.className = 'flex items-center space-x-2 story-beat-entry';
    newEntry.innerHTML = `
        <input type="text" class="flex-grow bg-zinc-900 border border-zinc-700 p-2 story-beat-input" value="New Beat">
        <button type="button" onclick="this.parentElement.remove()" class="btn btn-red btn-icon">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" /></svg>
        </button>
    `;
    container.appendChild(newEntry);
}

async function fetchFromServer() {
    try {
        const response = await fetch(API_URL);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const data = await response.json();
        
        if (data) {
            appData = {
                consciences: data.consciences || [],
                pantheons: data.pantheons || [],
                worlds: data.worlds || [],
                timeline: data.timeline || [],
                alignments: data.alignments || []
            };
            console.log("Successfully loaded data from server.");
        }
    } catch (error) {
        console.error("Could not fetch data from server, using local data as fallback.", error);
    } finally {
        renderAll();
    }
}

async function pushToServer() {
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(appData)
        });
        
        const responseText = await response.text();

        if (!response.ok) {
            let errorMsg = `HTTP error! status: ${response.status}`;
            try {
                const errorData = JSON.parse(responseText);
                errorMsg = errorData.message || errorMsg;
                if(errorData.details) errorMsg += `\nDetails: ${errorData.details}`;
            } catch (e) {
                errorMsg = `Invalid JSON response from server. Raw response: ${responseText}`;
            }
            throw new Error(errorMsg);
        }

        const result = JSON.parse(responseText);
        alert(result.message);

    } catch (error) {
        console.error("Error saving data to server:", error);
        alert(`Error saving data to the server.\n\nDetails: ${error.message}`);
    }
}

function addTimelineItem(type) {
    if (type === 'land') {
        const newLand = { type: 'land', id: `land_${Date.now()}`, title: 'New Land', location: 'Unknown', climate: '', temp: '', water: '', vegetation: '', predator: '', forage: '', invader: '', defender: '', storyBeats: ['New Beat'] };
        appData.timeline.push(newLand);
    } else if (type === 'titan') {
        const newTitan = { type: 'titan', id: `titan_${Date.now()}`, title: 'New Titan World', creeds: '0' };
        appData.timeline.push(newTitan);
    }
    renderTimeline();
    const timelineContainer = document.getElementById('timeline-container');
    timelineContainer.scrollLeft = timelineContainer.scrollWidth;
}

function saveData(type, params = null) {
    const modalId = document.getElementById('modalId')?.value;

    if (type === 'character') {
        const charId = document.getElementById('modalCharId').value;
        const charData = {
            name: document.getElementById('char-name').value,
            creature: document.getElementById('char-creature').value,
            fate: document.getElementById('char-fate').value,
            alignment: document.getElementById('char-alignment').value,
            role: document.getElementById('char-role').value,
            color: document.getElementById('char-color').value,
        };

        if (charId) { // Editing
            const sourceOrgId = document.getElementById('modalOrgId').value;
            const targetOrgId = document.getElementById('char-organization')?.value;

            let character;
            if (activeCharacterView === 'conscience') {
                const charIndex = appData.consciences.findIndex(c => c.id === charId);
                if (charIndex > -1) [character] = appData.consciences.splice(charIndex, 1);
            } else {
                const orgList = activeCharacterView === 'god' ? appData.pantheons : appData.worlds;
                const sourceOrg = orgList.find(o => o.id === sourceOrgId);
                if (sourceOrg) {
                    const charIndex = sourceOrg.characters.findIndex(c => c.id === charId);
                    if (charIndex > -1) [character] = sourceOrg.characters.splice(charIndex, 1);
                }
            }

            if (character) {
                const updatedChar = { ...character, ...charData };
                if (activeCharacterView === 'conscience') {
                    appData.consciences.push(updatedChar);
                } else {
                    const orgList = activeCharacterView === 'god' ? appData.pantheons : appData.worlds;
                    const targetOrg = orgList.find(p => p.id === targetOrgId);
                    if (targetOrg) targetOrg.characters.push(updatedChar);
                }
            }
        } else { // Adding
            const newChar = { id: `char_${Date.now()}`, ...charData };
            if (activeCharacterView === 'conscience') {
                appData.consciences.push(newChar);
            } else {
                const orgSelect = document.getElementById('char-organization');
                const orgId = orgSelect.value;
                const orgList = activeCharacterView === 'god' ? appData.pantheons : appData.worlds;
                const org = orgList.find(o => o.id === orgId);
                if (org) {
                    if (!org.characters) org.characters = [];
                    org.characters.push(newChar);
                }
            }
        }
    } else if (type === 'pantheon' || type === 'world') {
        const name = document.getElementById('org-name').value;
        const orgList = type === 'pantheon' ? appData.pantheons : appData.worlds;
        if (modalId) { // Editing
            const org = orgList.find(o => o.id === modalId);
            if (org) org.name = name;
        } else { // Adding
            orgList.push({ id: `${type}_${Date.now()}`, name: name, characters: [] });
        }
    } else if (type === 'land') {
        const landIndex = appData.timeline.findIndex(l => l.id === modalId);
        if (landIndex > -1) {
            appData.timeline[landIndex] = {
                ...appData.timeline[landIndex],
                title: document.getElementById('land-title').value,
                location: document.getElementById('land-location').value,
                climate: document.getElementById('land-climate').value,
                temp: document.getElementById('land-temp').value,
                water: document.getElementById('land-water').value,
                vegetation: document.getElementById('land-vegetation').value,
                predator: document.getElementById('land-predator').value,
                forage: document.getElementById('land-forage').value,
                invader: document.getElementById('land-invader').value,
                defender: document.getElementById('land-defender').value,
                storyBeats: Array.from(document.querySelectorAll('.story-beat-input')).map(input => input.value)
            };
        }
    } else if (type === 'titan') {
        const titanIndex = appData.timeline.findIndex(t => t.id === modalId);
        if (titanIndex > -1) {
            appData.timeline[titanIndex] = {
                ...appData.timeline[titanIndex],
                title: document.getElementById('titan-title').value,
                creeds: document.getElementById('titan-creeds').value,
            };
        }
    }
    renderAll();
    closeModal();
}

// --- [MERGED] --- This is the new, working save function for the alignment modal
function saveAlignmentData(alignmentId) {
    const alignment = appData.alignments.find(a => a.id === alignmentId);
    if (!alignment) return;

    alignment.imageUrl = document.getElementById('imageUrlInput').value;
    alignment.ontology = document.getElementById('ontology').value;
    alignment.epistemology = document.getElementById('epistemology').value;
    alignment.axiology = document.getElementById('axiology').value;
    alignment.appearance = document.getElementById('appearance').value;
    alignment.personality = document.getElementById('personality').value;
    alignment.fatalFlaw = document.getElementById('fatalFlaw').value;
    alignment.encouragement = document.getElementById('encouragement').value;

    alignment.relationships = {};
    alignmentModalContent.querySelectorAll('select[data-target-id]').forEach(select => {
        alignment.relationships[select.dataset.targetId] = select.value;
    });

    closeModal();
    pushToServer(); // Push changes immediately after saving
}


function deleteData(type, params) {
    if (type === 'pantheon' || type === 'world') {
        const orgList = type === 'pantheon' ? appData.pantheons : appData.worlds;
        const org = orgList.find(o => o.id === params);
        if (org && org.characters && org.characters.length > 0) {
            alert(`Cannot delete a ${type} that contains characters. Please move them first.`);
            return;
        }
        if (window.confirm(`Are you sure you want to delete the "${org.name}" ${type}?`)) {
            if (type === 'pantheon') appData.pantheons = appData.pantheons.filter(p => p.id !== params);
            if (type === 'world') appData.worlds = appData.worlds.filter(w => w.id !== params);
            renderCharacterPanel();
            closeModal();
        }
    } else if (type === 'character') {
        if (window.confirm(`Are you sure you want to delete this character?`)) {
            if (params.orgType === 'conscience') {
                appData.consciences = appData.consciences.filter(c => c.id !== params.charId);
            } else {
                const orgList = params.orgType === 'pantheon' ? appData.pantheons : appData.worlds;
                const org = orgList.find(o => o.id === params.orgId);
                if (org) {
                    org.characters = org.characters.filter(c => c.id !== params.charId);
                }
            }
            renderCharacterPanel();
            closeModal();
        }
    } else if (type === 'land' || type === 'titan') {
        if (window.confirm(`Are you sure you want to delete this timeline item?`)) {
            appData.timeline = appData.timeline.filter(item => item.id !== params);
            renderTimeline();
            closeModal();
        }
    }
}

function handleDragStart(event, charId, orgId, orgType) {
    event.dataTransfer.setData('text/plain', JSON.stringify({ charId, orgId, orgType }));
    event.dataTransfer.effectAllowed = 'move';
}

function handleDragOver(event) {
    event.preventDefault();
    const dropZone = event.target.closest('.org-drop-zone');
    if (dropZone) {
        dropZone.style.backgroundColor = '#3f3f46'; // zinc-700
        event.dataTransfer.dropEffect = 'move';
    }
}

function handleDragLeave(event) {
    const dropZone = event.target.closest('.org-drop-zone');
    if (dropZone) {
        dropZone.style.backgroundColor = '';
    }
}

function handleDrop(event) {
    event.preventDefault();
    const targetZone = event.target.closest('.org-drop-zone');
    if (!targetZone) return;

    targetZone.style.backgroundColor = '';
    
    const { charId, orgId: sourceOrgId, orgType: sourceOrgType } = JSON.parse(event.dataTransfer.getData('text/plain'));
    const targetOrgId = targetZone.dataset.orgId;
    const targetOrgType = targetZone.dataset.orgType;

    if (sourceOrgType !== targetOrgType) {
        alert("Characters can only be moved within their own type (e.g., God to Pantheon).");
        return;
    }
    
    if (sourceOrgId !== targetOrgId) {
        const sourceList = sourceOrgType === 'pantheon' ? appData.pantheons : appData.worlds;
        const targetList = targetOrgType === 'pantheon' ? appData.pantheons : appData.worlds;

        const sourceOrg = sourceList.find(p => p.id === sourceOrgId);
        const charIndex = sourceOrg.characters.findIndex(c => c.id === charId);
        
        if (charIndex > -1) {
            const [character] = sourceOrg.characters.splice(charIndex, 1);
            const targetOrg = targetList.find(p => p.id === targetOrgId);
            targetOrg.characters.push(character);
            renderCharacterPanel();
        }
    }
}

function exportData() {
    const data = appData;
    const jsonData = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'campaign_data.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function importData() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const importedData = JSON.parse(e.target.result);
                    if (importedData.timeline && (importedData.pantheons || importedData.worlds || importedData.consciences)) {
                        appData = { ...appData, ...importedData };
                        renderAll();
                        alert('Campaign data imported successfully!');
                    } else {
                        throw new Error('File format is incorrect.');
                    }
                } catch (error) {
                    console.error('Error importing data:', error);
                    alert(`Invalid JSON file or incorrect file format. Details: ${error.message}`);
                }
            };
            reader.readAsText(file);
        }
    };
    input.click();
}

function switchCharacterView(view) {
    activeCharacterView = view;
    renderCharacterPanel();
}

function updateHeaderButtons() {
    const addOrgBtn = document.getElementById('add-organization-btn');
    const addCharBtn = document.getElementById('add-character-btn');
    const title = document.getElementById('character-panel-title');

    if (activeCharacterView === 'god') {
        title.textContent = 'Gods';
        addOrgBtn.textContent = 'Add Pantheon';
        addCharBtn.textContent = 'Add God';
        addOrgBtn.style.display = 'inline-flex';
    } else if (activeCharacterView === 'villager') {
        title.textContent = 'Villagers';
        addOrgBtn.textContent = 'Add World';
        addCharBtn.textContent = 'Add Villager';
        addOrgBtn.style.display = 'inline-flex';
    } else if (activeCharacterView === 'conscience') {
        title.textContent = 'Consciences';
        addCharBtn.textContent = 'Add Conscience';
        addOrgBtn.style.display = 'none';
    }
}

// --- INITIALIZATION & EVENT LISTENERS ---
document.addEventListener('DOMContentLoaded', () => {
    fetchFromServer();

    const timelineContainer = document.getElementById('timeline-container');
    const alignmentsContainer = document.getElementById('alignments-container-wrapper');
    const timelineBtn = document.getElementById('timeline-view-btn');
    const alignmentsBtn = document.getElementById('alignments-view-btn');
    const timelineControls = document.getElementById('timeline-controls');

    timelineBtn.addEventListener('click', () => {
        timelineContainer.style.display = 'flex';
        alignmentsContainer.classList.add('hidden');
        alignmentsContainer.classList.remove('flex');
        timelineControls.style.display = 'flex';
        timelineBtn.classList.add('active');
        alignmentsBtn.classList.remove('active');
    });

    alignmentsBtn.addEventListener('click', () => {
        timelineContainer.style.display = 'none';
        alignmentsContainer.classList.remove('hidden');
        alignmentsContainer.classList.add('flex');
        timelineControls.style.display = 'none';
        alignmentsBtn.classList.add('active');
        timelineBtn.classList.remove('active');
    });

    if (timelineContainer) {
        timelineContainer.addEventListener('wheel', (evt) => {
            evt.preventDefault();
            evt.stopPropagation();
            timelineContainer.scrollLeft += evt.deltaY;
        });
    }

    document.getElementById('add-organization-btn').addEventListener('click', () => {
        const type = activeCharacterView === 'god' ? 'pantheon' : 'world';
        openModal(type);
    });
    document.getElementById('add-character-btn').addEventListener('click', () => {
        openModal('character');
    });

    // Close modals
    const notificationModalOverlay = document.getElementById('notification-modal-overlay');
    const notificationOkBtn = document.getElementById('notification-ok-btn');
    const closeNotification = () => notificationModalOverlay.classList.remove('active');
    notificationOkBtn.addEventListener('click', closeNotification);
    notificationModalOverlay.addEventListener('click', (e) => {
        if (e.target === notificationModalOverlay) closeNotification();
    });
    
    alignmentModalOverlay.addEventListener('click', (e) => {
        if(e.target === alignmentModalOverlay) closeModal();
    });

    const lightboxOverlay = document.getElementById('lightbox-overlay');
    lightboxOverlay.addEventListener('click', () => {
        lightboxOverlay.classList.remove('active');
    });
    document.getElementById('lightbox-image').addEventListener('click', (e) => {
        e.stopPropagation();
    });
});