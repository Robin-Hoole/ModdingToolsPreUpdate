window.PD_ENGINE_BUILD = 'logic-array-fix-2026-06-27';
// --- PROMPT MANAGEMENT ---
function createNewPrompt() {
    const newPrompt = {
        id: crypto.randomUUID(),
        parentId: null,
        rootId: null,
        tag: activeTag || projectData.tags[0]?.name || "News Alert",
        title: "New Panel Setup",
        backgroundTintType: "none", 
        backgroundTintOpacity: 0, 
        bodyText: "Message content goes here...",
        textFormat: {
            bold: false,
            italic: false,
            underline: false,
            strikethrough: false,
            listStyle: 'none', 
            alignH: 'left', 
            alignV: 'top' 
        },
        priority: 0,
        isRepeatable: false,
        isCalledExternally: false,
        makeExternalCall: false,
        
        hasTriggers: false,
        triggers: [],
        windowPositionId: "",
        
        frames: [], // Array for Prompt Frames
        
        hasVisualPayload: false,
        visualPayloads: [{ name: "MainImage", path: "Assets/Resources/Announcement/" }],
        
        hasButton: false,
        buttons: [],
        
        conditions: [],
        gameStateChanges: [],
        
        winReopenDialogue: false,
        winCloseDialogue: false,
        winReopenMainMenu: false,
        winCloseMainMenu: false,
        winClosePromptPanel: true,

        timestamp: Date.now()
    };
    projectData.prompts.push(newPrompt);
    activePromptId = newPrompt.id;
    lastActivePerCategory[newPrompt.tag] = newPrompt.id;
    renderLists();
    renderLogicPanel();
    renderEditor();
}

function updateActivePrompt(field, val) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (prompt) {
        prompt[field] = val;
        if (field === 'title' || field === 'tag' || field === 'isCalledExternally' || field === 'makeExternalCall') {
            renderLists();
            updateCardGlowOnly();
            if(field === 'isCalledExternally' || field === 'makeExternalCall') renderLogicPanel();
        }
    }
}

function updateActivePromptBGType(type) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    prompt.backgroundTintType = type;
    if (type === 'none') prompt.backgroundTintOpacity = 0;
    else if (type === 'half') prompt.backgroundTintOpacity = 0.5;
    else if (type === 'black') prompt.backgroundTintOpacity = 1;
    else if (type === 'custom') {
        if (prompt.backgroundTintOpacity === undefined) prompt.backgroundTintOpacity = 0.5;
    }
    renderEditor();
}

function updateActivePromptBGOpacity(val) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    prompt.backgroundTintOpacity = parseFloat(val);
    const display = document.getElementById('bg-opacity-display');
    if(display) display.innerText = prompt.backgroundTintOpacity.toFixed(2);
}

function selectCategory(tagName) {
    activeTag = tagName;
    
    if (lastActivePerCategory[tagName] && projectData.prompts.some(p => p.id === lastActivePerCategory[tagName] && p.tag === tagName)) {
        activePromptId = lastActivePerCategory[tagName];
    } else {
        const firstPrompt = projectData.prompts.find(p => p.tag === tagName);
        activePromptId = firstPrompt ? firstPrompt.id : null;
        if (activePromptId) lastActivePerCategory[tagName] = activePromptId;
    }
    
    renderLists();
    renderEditor();
}

function selectPrompt(id) {
    activePromptId = id;
    
    const p = projectData.prompts.find(prompt => prompt.id === id);
    if (p && projectData.tags.some(t => t.name === p.tag)) {
        activeTag = p.tag;
        lastActivePerCategory[p.tag] = id;
    }
    
    renderLists();
    renderEditor();
}

// --- DRAG AND DROP (Prompts) ---
function handlePromptDragStart(e, id) {
    e.dataTransfer.setData("promptId", id);
}

function handlePromptDrop(e, tagName) {
    e.preventDefault();
    const tagGroup = e.currentTarget;
    tagGroup.classList.remove('drag-over');
    
    const promptId = e.dataTransfer.getData("promptId");
    const prompt = projectData.prompts.find(p => p.id === promptId);
    
    if (prompt && prompt.tag !== tagName) {
        prompt.tag = tagName;
        lastActivePerCategory[tagName] = prompt.id;
        showNotification(`Moved to ${tagName}`);
        
        if (activePromptId === promptId) {
            activeTag = tagName;
        }
        
        renderLists();
        if (activePromptId) renderEditor();
    }
}

// --- INLINE RENAME & HOVER DELETE (PROMPTS) ---
function startPromptTitleEdit(id, e) {
    if (e) e.stopPropagation();
    editingPromptTitleId = id;
    renderLists();
    setTimeout(() => {
        const input = document.getElementById(`inline-edit-${id}`);
        if (input) {
            input.focus();
            input.select();
        }
    }, 0);
}

function cancelPromptTitleEdit(e) {
    if (e) e.stopPropagation();
    editingPromptTitleId = null;
    renderLists();
}

function savePromptTitleEdit(id, e) {
    if (e) e.stopPropagation();
    const input = document.getElementById(`inline-edit-${id}`);
    if (!input) return;
    const newTitle = input.value.trim();
    if (newTitle) {
        const prompt = projectData.prompts.find(p => p.id === id);
        if (prompt) prompt.title = newTitle;
    }
    editingPromptTitleId = null;
    renderLists();
    if (activePromptId === id) renderEditor();
}

function deletePromptWithConfirm(id) {
    if (confirm("Permanently delete this prompt blueprint?")) {
        projectData.prompts = projectData.prompts.filter(p => p.id !== id);
        if (activePromptId === id) activePromptId = null;
        renderLists();
        renderLogicPanel();
        renderEditor();
        showNotification("Prompt Deleted");
    }
}

// --- PROMPT REORDERING ---
function movePromptOrder(promptId, newLocalIdxStr) {
    const newLocalIdx = parseInt(newLocalIdxStr, 10);
    const p = projectData.prompts.find(x => x.id === promptId);
    if (!p) return;
    const tag = p.tag;
    
    let tagPrompts = projectData.prompts.filter(x => x.tag === tag);
    const oldIdx = tagPrompts.findIndex(x => x.id === promptId);
    if (oldIdx === -1) return;
    
    tagPrompts.splice(oldIdx, 1);
    tagPrompts.splice(newLocalIdx, 0, p);
    
    let tagIndexCounter = 0;
    projectData.prompts = projectData.prompts.map(x => {
        if (x.tag === tag) {
            const mappedPrompt = tagPrompts[tagIndexCounter];
            tagIndexCounter++;
            return mappedPrompt;
        }
        return x;
    });
    
    renderLists();
    if (activePromptId) renderEditor();
}

// --- TMP FORMATTING ENGINE ---
function applyTextFormat(tagType, tagParam = '') {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    
    const textarea = document.getElementById('edit-body');
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = textarea.value.substring(start, end);
    
    if (selectedText.length > 0) {
        if (['top', 'middle', 'bottom'].includes(tagType)) {
            showNotification("Vertical alignment must be applied globally (select no text).");
            return;
        }
        
        let newText = '';
        let offsetCursor = 0;
        
        if (tagType === 'align') {
            newText = textarea.value.substring(0, start) + `<align="${tagParam}">` + selectedText + `</align>` + textarea.value.substring(end);
            offsetCursor = 17 + tagParam.length; 
        } else if (tagType === 'bullet') {
            const lines = selectedText.split('\n').map(l => `• ${l}`).join('\n');
            newText = textarea.value.substring(0, start) + lines + textarea.value.substring(end);
            offsetCursor = newText.length - textarea.value.length;
        } else if (tagType === 'number') {
            const lines = selectedText.split('\n').map((l, i) => `${i+1}. ${l}`).join('\n');
            newText = textarea.value.substring(0, start) + lines + textarea.value.substring(end);
            offsetCursor = newText.length - textarea.value.length;
        } else {
            newText = textarea.value.substring(0, start) + `<${tagType}>` + selectedText + `</${tagType}>` + textarea.value.substring(end);
            offsetCursor = 7; 
        }
        
        textarea.value = newText;
        updateActivePrompt('bodyText', newText);
        
        textarea.focus();
        textarea.setSelectionRange(start, end + offsetCursor);
        updatePreview();
    } 
    else {
        if (!prompt.textFormat) prompt.textFormat = {};
        
        if (tagType === 'align') {
            prompt.textFormat.alignH = tagParam;
        } else if (['top', 'middle', 'bottom'].includes(tagType)) {
            prompt.textFormat.alignV = tagType;
        } else if (tagType === 'bullet') {
            prompt.textFormat.listStyle = prompt.textFormat.listStyle === 'bullet' ? 'none' : 'bullet';
        } else if (tagType === 'number') {
            prompt.textFormat.listStyle = prompt.textFormat.listStyle === 'number' ? 'none' : 'number';
        } else {
            const keyMap = { 'b': 'bold', 'i': 'italic', 'u': 'underline', 's': 'strikethrough' };
            const key = keyMap[tagType];
            if (key) prompt.textFormat[key] = !prompt.textFormat[key];
        }
        renderEditor(); 
    }
}

// --- PROJECT LOGIC MANAGEMENT & GLOW EFFECTS ---
function getProjectLogic() {
    let logicMap = {}; 
    
    projectData.prompts.forEach(p => {
        if (p.conditions) {
            p.conditions.forEach(c => {
                if (!c.key) return;
                let id = `${c.key}||${c.op}||${c.val}`;
                if(!logicMap[id]) logicMap[id] = { key: c.key, op: c.op, val: c.val, isCondition: false, isStateChange: false, uses: [] };
                logicMap[id].isCondition = true;
                logicMap[id].uses.push({ promptId: p.id, type: 'Condition', text: p.title, context: c });
            });
        }
        
        if (p.gameStateChanges) {
            p.gameStateChanges.forEach(c => {
                if (!c.key) return;
                let id = `${c.key}||${c.op}||${c.val}`;
                if(!logicMap[id]) logicMap[id] = { key: c.key, op: c.op, val: c.val, isCondition: false, isStateChange: false, uses: [] };
                logicMap[id].isStateChange = true;
                logicMap[id].uses.push({ promptId: p.id, type: 'State Change', text: p.title, context: c });
            });
        }
        
        if(p.buttons) {
            p.buttons.forEach((b, bIdx) => {
                if(b.stateChanges) {
                    b.stateChanges.forEach(c => {
                        if (!c.key) return;
                        let id = `${c.key}||${c.op}||${c.val}`;
                        if(!logicMap[id]) logicMap[id] = { key: c.key, op: c.op, val: c.val, isCondition: false, isStateChange: false, uses: [] };
                        logicMap[id].isStateChange = true;
                        logicMap[id].uses.push({ promptId: p.id, type: 'Button State Change', text: b.text || 'Unnamed Button', context: c, btnIdx: bIdx });
                    });
                }
            });
        }
    });
    return Object.values(logicMap);
}

function getPromptGlowState(promptId, allLogic) {
    const p = projectData.prompts.find(pr => pr.id === promptId);
    if (!p) return 'none';

    let needsRed = false;
    if (!p.isCalledExternally && p.conditions) {
        for (let c of p.conditions) {
            if (!c.key) continue;
            let logicItem = allLogic.find(l => l.key === c.key && l.op === c.op && l.val === c.val);
            if (logicItem && !logicItem.isStateChange) {
                needsRed = true; break;
            }
        }
    }

    let needsBlue = false;
    if (!p.makeExternalCall) {
        let allChanges = [];
        if (p.gameStateChanges) allChanges.push(...p.gameStateChanges);
        if (p.buttons) p.buttons.forEach(b => { if (b.stateChanges) allChanges.push(...b.stateChanges); });
        
        for (let c of allChanges) {
            if (!c.key) continue;
            let logicItem = allLogic.find(l => l.key === c.key && l.op === c.op && l.val === c.val);
            if (logicItem && !logicItem.isCondition) {
                needsBlue = true; break;
            }
        }
    }

    if (needsRed && needsBlue) return 'purple';
    if (needsRed) return 'red';
    if (needsBlue) return 'blue';
    return 'none';
}

function openLogicModal(key, op, val) {
    currentLogicEdit = { key, op, val };
    document.getElementById('logic-edit-key').value = key;
    document.getElementById('logic-edit-val').value = val;
    document.getElementById('logic-modal').classList.remove('hidden');
    renderLogicDependencies();
}

function closeLogicModal() {
    document.getElementById('logic-modal').classList.add('hidden');
    currentLogicEdit = null;
}

function jumpToLogicDependency(promptId) {
    closeLogicModal();
    selectPrompt(promptId);
}

function deleteLogicDependency(promptId, type, btnIdx) {
    const p = projectData.prompts.find(pr => pr.id === promptId);
    if (!p) return;
    const isMatch = (c) => c.key === currentLogicEdit.key && c.op === currentLogicEdit.op && c.val === currentLogicEdit.val;
    
    if (type === 'Condition') {
        p.conditions = p.conditions.filter(c => !isMatch(c));
    } else if (type === 'State Change') {
        p.gameStateChanges = p.gameStateChanges.filter(c => !isMatch(c));
    } else if (type === 'Button State Change' && btnIdx !== null) {
        p.buttons[btnIdx].stateChanges = p.buttons[btnIdx].stateChanges.filter(c => !isMatch(c));
    }
    
    showNotification("Dependency Deleted");
    renderLogicDependencies();
    renderLogicPanel();
    updateDynamicGlows();
}

function applyLogicChangeThroughout() {
    const newKey = document.getElementById('logic-edit-key').value.trim();
    const newVal = document.getElementById('logic-edit-val').value.trim();
    if (!newKey) return;
    
    let count = 0;
    projectData.prompts.forEach(p => {
        const checkAndUpdate = (c) => {
            if (c.key === currentLogicEdit.key && c.op === currentLogicEdit.op && c.val === currentLogicEdit.val) {
                c.key = newKey;
                c.val = newVal;
                count++;
            }
        };
        
        if(p.conditions) p.conditions.forEach(checkAndUpdate);
        if(p.gameStateChanges) p.gameStateChanges.forEach(checkAndUpdate);
        if(p.buttons) {
            p.buttons.forEach(b => {
                if(b.stateChanges) b.stateChanges.forEach(checkAndUpdate);
            });
        }
    });
    
    showNotification(`Updated ${count} instances.`);
    closeLogicModal();
    renderLogicPanel();
    updateDynamicGlows();
}

// --- PROMPT FRAMES MANAGEMENT ---
function addFrame() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    if (!prompt.frames) prompt.frames = [];
    if (prompt.frames.length >= 2) return;

    prompt.frames.push({
        id: crypto.randomUUID(),
        frameId: "",
        positionId: "",
        disableOnClose: true,
        invert: false
    });
    renderFramesAndPositions();
}

function removeFrame(idx) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    prompt.frames.splice(idx, 1);
    renderFramesAndPositions();
}

function updateFrame(idx, field, val) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (prompt && prompt.frames[idx]) {
        prompt.frames[idx][field] = val;
    }
}

// --- VISUAL PAYLOAD MANAGEMENT ---
function addVisualPayload() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    if (!prompt.visualPayloads) prompt.visualPayloads = [];
    prompt.visualPayloads.push({ name: '', path: 'Assets/Resources/' });
    renderVisualPayloads();
}

function removeVisualPayload(idx) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !prompt.visualPayloads) return;
    prompt.visualPayloads.splice(idx, 1);
    renderVisualPayloads();
}

function updateVisualPayload(idx, field, val) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (prompt && prompt.visualPayloads) {
        prompt.visualPayloads[idx][field] = val;
    }
}

// --- BUTTON & BRANCHING MANAGEMENT ---
function toggleBranching(btnIdx, isChecked) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !prompt.buttons) return;
    
    prompt.buttons[btnIdx].isBranching = isChecked;
    
    if (isChecked && !prompt.buttons[btnIdx].branchPromptId) {
        const branchId = crypto.randomUUID();
        const rootId = prompt.rootId || prompt.id;
        
        const newPrompt = {
            id: branchId,
            parentId: prompt.id,
            rootId: rootId,
            tag: prompt.tag,
            title: prompt.title + " (Phase 2)",
            backgroundTintType: prompt.backgroundTintType || "none",
            backgroundTintOpacity: prompt.backgroundTintOpacity || 0,
            bodyText: "",
            textFormat: { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'left', alignV: 'top' },
            priority: prompt.priority,
            isRepeatable: prompt.isRepeatable,
            isCalledExternally: false,
            makeExternalCall: false,
            hasTriggers: false, triggers: [],
            windowPositionId: "",
            frames: [],
            hasVisualPayload: false, visualPayloads: [],
            hasButton: false, buttons: [],
            conditions: [], gameStateChanges: [],
            winReopenDialogue: false, winCloseDialogue: false, winReopenMainMenu: false, winCloseMainMenu: false, winClosePromptPanel: true,
            timestamp: Date.now()
        };
        projectData.prompts.push(newPrompt);
        prompt.buttons[btnIdx].branchPromptId = branchId;
    }
    renderActionButtons();
    renderLists();
}

function addActionButton() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    if (!prompt.buttons) prompt.buttons = [];
    
    if (prompt.buttons.length >= 4) return;
    
    prompt.buttons.push({
        id: crypto.randomUUID(),
        text: "Continue",
        stateChanges: [],
        isBranching: false,
        branchPromptId: null,
        closeMenu: false,
        isExternalLink: false,
        externalUrl: ''
    });
    renderActionButtons();
}

function removeActionButton(idx) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !prompt.buttons) return;
    prompt.buttons.splice(idx, 1);
    renderActionButtons();
    renderLogicPanel();
    updateDynamicGlows();
}

function updateActionButton(idx, field, val) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (prompt && prompt.buttons) {
        prompt.buttons[idx][field] = val;
    }
}

function addButtonStateChange(bIdx) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !prompt.buttons || !prompt.buttons[bIdx]) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('addButtonStateChange: missing response', { bIdx, activePromptId });
        return;
    }
    if (!Array.isArray(prompt.buttons[bIdx].stateChanges)) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('addButtonStateChange: repaired stateChanges array', { bIdx, previousType: typeof prompt.buttons[bIdx].stateChanges });
        prompt.buttons[bIdx].stateChanges = [];
    }
    prompt.buttons[bIdx].stateChanges.push({ key: '', op: '==', val: '' });
    prompt.buttons[bIdx].statesOpen = true;
    renderActionButtons();
    renderLogicPanel();
    updateDynamicGlows();
    if (typeof refreshPush === 'function') refreshPush();
}

function removeButtonStateChange(bIdx, sIdx) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !prompt.buttons || !prompt.buttons[bIdx]) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('removeButtonStateChange: missing response', { bIdx, sIdx, activePromptId });
        return;
    }
    if (!Array.isArray(prompt.buttons[bIdx].stateChanges)) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('removeButtonStateChange: repaired stateChanges array', { bIdx, sIdx, previousType: typeof prompt.buttons[bIdx].stateChanges });
        prompt.buttons[bIdx].stateChanges = [];
    }
    prompt.buttons[bIdx].stateChanges.splice(sIdx, 1);
    renderActionButtons();
    renderLogicPanel();
    updateDynamicGlows();
    if (typeof refreshPush === 'function') refreshPush();
}

function updateButtonStateChange(bIdx, sIdx, field, value) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !prompt.buttons || !prompt.buttons[bIdx]) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('updateButtonStateChange: missing response', { bIdx, sIdx, field, value, activePromptId });
        return;
    }
    if (!Array.isArray(prompt.buttons[bIdx].stateChanges)) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('updateButtonStateChange: repaired stateChanges array', { bIdx, sIdx, field, previousType: typeof prompt.buttons[bIdx].stateChanges });
        prompt.buttons[bIdx].stateChanges = [];
    }
    if (!prompt.buttons[bIdx].stateChanges[sIdx]) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('updateButtonStateChange: repaired missing row', { bIdx, sIdx, field, currentLength: prompt.buttons[bIdx].stateChanges.length });
        prompt.buttons[bIdx].stateChanges[sIdx] = { key: '', op: '==', val: '' };
    }
    prompt.buttons[bIdx].stateChanges[sIdx][field] = value;
    renderLogicPanel();
    updateDynamicGlows();
    if (typeof refreshPush === 'function') refreshPush();
}

// --- ARRAYS MANAGEMENT (Conditions & State Changes) ---
function addArrayItem(type) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('addArrayItem: no active prompt', { type, activePromptId });
        return;
    }

    if (!Array.isArray(prompt[type])) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('addArrayItem: repaired prompt logic array', { type, previousType: typeof prompt[type] });
        prompt[type] = [];
    }
    prompt[type].push({ key: '', op: '==', val: '' });
    if (type === 'conditions') prompt.conditionsOpen = true;
    if (type === 'gameStateChanges') prompt.statesOpen = true;
    renderArray(type);
    if (typeof pdSyncPromptLogicSectionVisibility === 'function') pdSyncPromptLogicSectionVisibility();
    renderLogicPanel();
    updateDynamicGlows();
    if (typeof refreshPush === 'function') refreshPush();
}

function removeArrayItem(type, index) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('removeArrayItem: no active prompt', { type, index, activePromptId });
        return;
    }

    if (!Array.isArray(prompt[type])) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('removeArrayItem: repaired prompt logic array', { type, index, previousType: typeof prompt[type] });
        prompt[type] = [];
    }
    if (index < 0 || index >= prompt[type].length) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('removeArrayItem: index out of range', { type, index, length: prompt[type].length });
        return;
    }
    prompt[type].splice(index, 1);
    renderArray(type);
    if (typeof pdSyncPromptLogicSectionVisibility === 'function') pdSyncPromptLogicSectionVisibility();
    renderLogicPanel();
    updateDynamicGlows();
    if (typeof refreshPush === 'function') refreshPush();
}

function updateArrayItem(type, index, field, value) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('updateArrayItem: no active prompt', { type, index, field, value, activePromptId });
        return;
    }
    if (!Array.isArray(prompt[type])) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('updateArrayItem: repaired prompt logic array', { type, index, field, previousType: typeof prompt[type] });
        prompt[type] = [];
    }
    if (!prompt[type][index]) {
        if (typeof pdReportDiagnostic === 'function') pdReportDiagnostic('updateArrayItem: repaired missing row', { type, index, field, length: prompt[type].length, engineBuild: window.PD_ENGINE_BUILD || null });
        prompt[type][index] = { key: '', op: '==', val: '' };
    }
    prompt[type][index][field] = value;
    renderLogicPanel();
    updateDynamicGlows();
    if (typeof refreshPush === 'function') refreshPush();
}

// --- TRIGGERS MANAGEMENT ---
function addTrigger() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    if (!prompt.triggers) prompt.triggers = [];
    prompt.triggers.push('OnGameAwake');
    renderTriggers();
    renderLists();
    showNotification("Trigger Added");
}

function removeTrigger(idx) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    prompt.triggers.splice(idx, 1);
    renderTriggers();
    renderLists();
}

function updateTrigger(idx, val) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (prompt) prompt.triggers[idx] = val;
    renderLists();
}

// --- EDITOR LOGIC & EXCLUSIVITY ---
function handleExclusivity(changedId, opposedId, isChecked) {
    updateActivePrompt(changedId, isChecked);
    if (isChecked) {
        const opposed = document.getElementById(opposedId);
        if(opposed) opposed.checked = false;
        updateActivePrompt(opposedId, false);
    }
}

function updatePromptTag(newTagName) {
    updateActivePrompt('tag', newTagName);
    activeTag = newTagName; 
    lastActivePerCategory[newTagName] = activePromptId;
    
    const tagObj = projectData.tags.find(t => t.name === newTagName);
    if (tagObj) {
        document.getElementById('active-prompt-card').style.borderLeftColor = tagObj.color;
    }
    renderLists();
}
