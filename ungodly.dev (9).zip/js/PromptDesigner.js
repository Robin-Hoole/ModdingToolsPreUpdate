const OPERATORS = ["==", ">=", "<=", "+", "-", "!="];
const TRIGGER_EVENTS = ["OnGameAwake", "OnDayStart", "OnRoomEnter", "OnTaskComplete", "RandomInterrupt", "Custom"];

// UI Definition for dynamic left-panel sections
const GLOBAL_SECTIONS = [
    { key: 'globalCast', title: 'Global Cast', placeholder: 'Character Name...', btnText: 'Create Character' },
    { key: 'globalStates', title: 'Global States', placeholder: 'State Name (e.g. Idle)...', btnText: 'Create State' },
    { key: 'globalMoods', title: 'Global Moods', placeholder: 'Mood (e.g. Happy)...', btnText: 'Create Mood' },
    { key: 'globalSettings', title: 'Global Settings', placeholder: 'Setting Name...', btnText: 'Create Setting' },
    { key: 'timesOfDay', title: 'Times of Day', placeholder: 'Time (e.g. Morning)...', btnText: 'Create Time' },
    { key: 'daysOfWeek', title: 'Days of the Week', placeholder: 'Day (e.g. Monday)...', btnText: 'Create Day' },
    { key: 'menuOptions', title: 'Menu Options', placeholder: 'Option Name...', btnText: 'Create Option' },
    { key: 'imageSequences', title: 'Image Sequences', placeholder: 'Sequence Name...', btnText: 'Create Sequence' },
    { key: 'globalFrames', title: 'Global Frames', placeholder: 'Frame Name...', btnText: 'Create Frame' }
];

let projectData = {
    tokens: [
        { key: "userName", value: "Player One" },
        { key: "location", value: "Cyber City" }
    ],
    tags: [
        { name: "News Alert", color: "#00f2ff" },
        { name: "Advertisement", color: "#ff8c00" },
        { name: "Dev Message", color: "#ff007b" }
    ],
    positionTypes: [], // New structure for Global Positions
    prompts: []
};

// Initialize empty arrays for dynamic sections
GLOBAL_SECTIONS.forEach(sec => {
    if(!projectData[sec.key]) projectData[sec.key] = [];
});

let activeTag = "News Alert";
let activePromptId = null;
let editingTagIdx = null;
let editingTokenIdx = null;
let lastSelectedPosTypeId = null; // Remembers previously selected Position dropdown

// Sticky Tab & Inline Edit Tracking
let lastActivePerCategory = {};
let editingPromptTitleId = null;

let editingGlobalItem = { section: null, id: null };
let logicSearchQuery = "";
let currentLogicEdit = null;

// Position specific edit states
let editingPosTypeId = null;
let editingPosTagId = null;
let contextMenuTargetId = null;

// Click anywhere closes context menu
document.addEventListener('click', closeContextMenus);
document.addEventListener('contextmenu', closeContextMenus);

// Keyboard Navigation Events
document.addEventListener('keydown', (e) => {
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) return;

    if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
        e.preventDefault();
        const currentIndex = projectData.tags.findIndex(t => t.name === activeTag);
        if (currentIndex === -1) return;
        let newIndex = e.key === 'ArrowRight' ? currentIndex + 1 : currentIndex - 1;
        if (newIndex >= 0 && newIndex < projectData.tags.length) {
            selectCategory(projectData.tags[newIndex].name);
            const tabElement = document.querySelector(`.char-tab:nth-child(${newIndex + 1})`);
            if (tabElement) tabElement.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        }
    } else if (['ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End'].includes(e.key)) {
        e.preventDefault();
        const promptsInTab = projectData.prompts.filter(p => p.tag === activeTag);
        if (promptsInTab.length === 0) return;
        
        const promptSearchInput = document.getElementById('prompt-search');
        const searchQ = promptSearchInput ? promptSearchInput.value.toLowerCase() : "";
        const filteredPrompts = promptsInTab.filter(p => {
            if (!searchQ) return true;
            return p.title.toLowerCase().includes(searchQ) || p.id.toLowerCase().includes(searchQ) || p.bodyText.toLowerCase().includes(searchQ);
        });

        if (filteredPrompts.length === 0) return;

        const currentIndex = filteredPrompts.findIndex(p => p.id === activePromptId);
        let newIndex = currentIndex;

        if (e.key === 'ArrowDown') newIndex = currentIndex + 1;
        if (e.key === 'ArrowUp') newIndex = currentIndex - 1;
        if (e.key === 'PageDown') newIndex = currentIndex + 10;
        if (e.key === 'PageUp') newIndex = currentIndex - 10;
        if (e.key === 'Home') newIndex = 0;
        if (e.key === 'End') newIndex = filteredPrompts.length - 1;
        
        newIndex = Math.max(0, Math.min(newIndex, filteredPrompts.length - 1));

        if (newIndex !== currentIndex) {
            selectPrompt(filteredPrompts[newIndex].id);
            document.getElementById('active-prompt-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
});

function getRandomHex() {
    return '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
}

function showNotification(msg) {
    const n = document.getElementById('notification');
    n.innerText = msg;
    n.classList.add('show');
    setTimeout(() => n.classList.remove('show'), 2500);
}

function closeContextMenus(e) {
    if (e && e.type === 'contextmenu') return; // let right click logic handle itself
    document.getElementById('pos-type-context-menu').classList.add('hidden');
    contextMenuTargetId = null;
}

// --- OPTGROUP HELPER ---
function getPositionOptionsHTML(selectedValue) {
    let html = `<option value="">-- Select Position --</option>`;
    projectData.positionTypes.forEach(pt => {
        if (pt.tags.length > 0) {
            html += `<optgroup label="${pt.name}">`;
            pt.tags.forEach(tag => {
                const selected = (tag.id === selectedValue) ? 'selected' : '';
                html += `<option value="${tag.id}" ${selected}>${tag.name}</option>`;
            });
            html += `</optgroup>`;
        }
    });
    return html;
}

// --- STICKY TABS LOGIC ---
function selectCategory(tagName) {
    activeTag = tagName;
    
    if (lastActivePerCategory[tagName] && projectData.prompts.some(p => p.id === lastActivePerCategory[tagName] && p.tag === tagName)) {
        activePromptId = lastActivePerCategory[tagName];
    } else {
        const firstPrompt = projectData.prompts.find(p => p.tag === tagName);
        activePromptId = firstPrompt ? firstPrompt.id : null;
        if (activePromptId) lastActivePerCategory[tagName] = activePromptId;
    }
    
    renderLists();
    renderEditor();
}

// --- DRAG AND DROP (Prompts) ---
function handlePromptDragStart(e, id) {
    e.dataTransfer.setData("promptId", id);
}

function handlePromptDrop(e, tagName) {
    e.preventDefault();
    const tagGroup = e.currentTarget;
    tagGroup.classList.remove('drag-over');
    
    const promptId = e.dataTransfer.getData("promptId");
    const prompt = projectData.prompts.find(p => p.id === promptId);
    
    if (prompt && prompt.tag !== tagName) {
        prompt.tag = tagName;
        lastActivePerCategory[tagName] = prompt.id;
        showNotification(`Moved to ${tagName}`);
        
        if (activePromptId === promptId) {
            activeTag = tagName;
        }
        
        renderLists();
        if (activePromptId) renderEditor();
    }
}

// --- INLINE RENAME & HOVER DELETE (PROMPTS) ---
function startPromptTitleEdit(id, e) {
    if (e) e.stopPropagation();
    editingPromptTitleId = id;
    renderLists();
    setTimeout(() => {
        const input = document.getElementById(`inline-edit-${id}`);
        if (input) {
            input.focus();
            input.select();
        }
    }, 0);
}

function cancelPromptTitleEdit(e) {
    if (e) e.stopPropagation();
    editingPromptTitleId = null;
    renderLists();
}

function savePromptTitleEdit(id, e) {
    if (e) e.stopPropagation();
    const input = document.getElementById(`inline-edit-${id}`);
    if (!input) return;
    const newTitle = input.value.trim();
    if (newTitle) {
        const prompt = projectData.prompts.find(p => p.id === id);
        if (prompt) prompt.title = newTitle;
    }
    editingPromptTitleId = null;
    renderLists();
    if (activePromptId === id) renderEditor();
}

function deletePromptWithConfirm(id) {
    if (confirm("Permanently delete this prompt blueprint?")) {
        projectData.prompts = projectData.prompts.filter(p => p.id !== id);
        if (activePromptId === id) activePromptId = null;
        renderLists();
        renderLogicPanel();
        renderEditor();
        showNotification("Prompt Deleted");
    }
}

// --- PROMPT REORDERING ---
function movePromptOrder(promptId, newLocalIdxStr) {
    const newLocalIdx = parseInt(newLocalIdxStr, 10);
    const p = projectData.prompts.find(x => x.id === promptId);
    if (!p) return;
    const tag = p.tag;
    
    let tagPrompts = projectData.prompts.filter(x => x.tag === tag);
    const oldIdx = tagPrompts.findIndex(x => x.id === promptId);
    if (oldIdx === -1) return;
    
    tagPrompts.splice(oldIdx, 1);
    tagPrompts.splice(newLocalIdx, 0, p);
    
    let tagIndexCounter = 0;
    projectData.prompts = projectData.prompts.map(x => {
        if (x.tag === tag) {
            const mappedPrompt = tagPrompts[tagIndexCounter];
            tagIndexCounter++;
            return mappedPrompt;
        }
        return x;
    });
    
    renderLists();
    if (activePromptId) renderEditor();
}


// --- GLOBAL POSITIONS MANAGER ---
function renderGlobalPositions() {
    const container = document.getElementById('global-positions-container');
    let html = `
        <div class="flex justify-between items-baseline mb-3 mt-6">
            <h3 class="!m-0 text-accent-pink">Global Positions</h3>
        </div>
        
        <!-- Position Type Authoring -->
        <div class="mb-3">
            <label class="text-[9px] uppercase font-bold text-dim mb-1 block">New Position Type</label>
            <div class="flex gap-1">
                <input type="text" id="new-pos-type" placeholder="Type Name..." class="text-[11px] p-2 bg-[#0a0a0a] border border-[#222] w-full focus:border-pink-500">
                <button class="bg-pink-500 text-white font-black px-3 hover:bg-pink-400 transition-colors" onclick="addPositionType()">+</button>
            </div>
        </div>

        <!-- Position Tag Authoring -->
        <div class="mb-4">
            <label class="text-[9px] uppercase font-bold text-dim mb-1 block">New PosTag</label>
            <div class="flex gap-1 mb-1">
                <input type="text" id="new-pos-tag" placeholder="Tag Name..." class="text-[11px] p-2 bg-[#0a0a0a] border border-[#222] w-full focus:border-pink-500">
                <input type="color" id="new-pos-tag-color" value="${getRandomHex()}" class="w-8 h-[31px] p-0 border border-[#222] cursor-pointer bg-transparent shrink-0">
            </div>
            <div class="flex gap-1">
                <select id="new-pos-tag-type" class="text-[10px] p-1.5 bg-[#0a0a0a] border border-[#222] focus:border-pink-500">
                    ${projectData.positionTypes.map(pt => `<option value="${pt.id}" ${lastSelectedPosTypeId === pt.id ? 'selected' : ''}>${pt.name}</option>`).join('')}
                </select>
                <button class="bg-pink-500 text-white font-black px-3 hover:bg-pink-400 transition-colors" onclick="addPositionTag()">+</button>
            </div>
        </div>
        
        <div class="space-y-2">
    `;

    let globalTagIndex = 0; // Maintains sequential counting across all lists

    projectData.positionTypes.forEach(pt => {
        const isEditingType = editingPosTypeId === pt.id;

        html += `<div class="bg-[#0a0a0a] border border-[#222] rounded-sm p-1.5" 
                      draggable="true"
                      ondragstart="handlePosTypeDragStart(event, '${pt.id}')"
                      ondragover="event.preventDefault(); this.classList.add('border-pink-500/50')"
                      ondragleave="this.classList.remove('border-pink-500/50')"
                      ondrop="handlePosDrop(event, '${pt.id}'); this.classList.remove('border-pink-500/50')">`;

        // Header / Type Edit
        if (isEditingType) {
            html += `
                <div class="flex items-center bg-black border border-pink-500 p-1 mb-2">
                    <input type="text" id="edit-postype-${pt.id}" value="${pt.name}" class="flex-1 text-[11px] bg-transparent text-white border-none focus:outline-none px-1 h-6">
                    <button class="text-pink-500 hover:bg-pink-500/20 px-2 py-1 text-[11px] font-bold rounded transition-colors" onclick="savePosTypeEdit('${pt.id}')">✓</button>
                    <button class="text-dim hover:text-white px-2 py-1 text-[11px] font-bold rounded transition-colors" onclick="cancelPosTypeEdit()">✕</button>
                </div>
            `;
        } else {
            html += `
                <div class="flex items-center justify-between mb-2 px-1 cursor-pointer group"
                     oncontextmenu="showPosTypeContextMenu(event, '${pt.id}')">
                    <div class="flex items-center gap-2 flex-1" onclick="togglePosTypeCollapse('${pt.id}')">
                        <span class="text-[10px] text-pink-500 triangle ${pt.collapsed ? 'collapsed' : ''}">▼</span>
                        <span class="text-[11px] font-black uppercase text-white truncate" ondblclick="event.stopPropagation(); startPosTypeEdit('${pt.id}')">${pt.name}</span>
                    </div>
                    <span class="text-[9px] text-dim font-bold opacity-50">${pt.tags.length}</span>
                </div>
            `;
        }

        // Tags List
        if (!pt.collapsed) {
            html += `<div class="space-y-1 pl-3">`;
            
            // Submenu specific Arrange and Clear controls
            html += `
                <div class="flex gap-2 mb-2 mt-2">
                    <button class="btn border border-white/20 text-dim hover:text-white px-2 py-1 text-[8px]" onclick="sortLocalPositions('${pt.id}')">ARRANGE A-Z</button>
                    <button class="btn border border-pink-500/50 text-pink-500 hover:text-white hover:bg-pink-500/20 px-2 py-1 text-[8px]" onclick="clearLocalPositions('${pt.id}')">CLEAR</button>
                </div>
            `;

            if (pt.tags.length === 0) {
                html += `<div class="text-[9px] text-dim italic opacity-50 px-1 py-1">No tags here. Drag one or add above.</div>`;
            }
            pt.tags.forEach((tag) => {
                const currentIdx = globalTagIndex++;
                const isEditingTag = editingPosTagId === tag.id;
                
                if (isEditingTag) {
                    html += `
                        <div class="flex items-center bg-black border border-pink-500 p-1">
                            <span class="text-[9px] text-dim px-1">#${currentIdx}</span>
                            <input type="text" id="edit-postag-${tag.id}" value="${tag.name}" class="flex-1 text-[10px] bg-transparent text-white border-none focus:outline-none px-1 h-5">
                            <input type="color" id="edit-postag-color-${tag.id}" value="${tag.color}" class="w-5 h-5 p-0 mx-1 border border-white/20 cursor-pointer bg-transparent shrink-0">
                            <button class="text-pink-500 px-1 text-[10px] font-bold" onclick="savePosTagEdit('${pt.id}', '${tag.id}')">✓</button>
                            <button class="text-dim hover:text-white px-1 text-[10px] font-bold" onclick="cancelPosTagEdit()">✕</button>
                        </div>
                    `;
                } else {
                    html += `
                        <div class="group/tag flex justify-between items-center bg-[#111] border-l-[3px] p-1.5 cursor-pointer hover:bg-[#1a1a1a] transition-colors"
                             style="border-left-color: ${tag.color};"
                             draggable="true"
                             ondragstart="handlePosTagDragStart(event, '${pt.id}', '${tag.id}')"
                             ondblclick="startPosTagEdit('${tag.id}')">
                            <div class="flex items-center gap-2 overflow-hidden">
                                <span class="text-[8px] font-mono text-dim opacity-50">#${currentIdx}</span>
                                <span class="text-[10px] text-white truncate pointer-events-none">${tag.name}</span>
                            </div>
                            <button class="text-pink-500 hover:text-pink-400 font-bold opacity-0 group-hover/tag:opacity-100 transition-opacity text-[10px] px-1" onclick="deletePositionTag('${pt.id}', '${tag.id}')">✕</button>
                        </div>
                    `;
                }
            });
            html += `</div>`;
        } else {
            // Keep continuous counter tracking even when elements are collapsed!
            globalTagIndex += pt.tags.length;
        }

        html += `</div>`;
    });

    html += `</div>`;
    document.getElementById('global-positions-container').innerHTML = html;
}

// Positions Authoring Functions
function addPositionType() {
    const input = document.getElementById('new-pos-type');
    const name = input.value.trim();
    if (!name) return;
    
    projectData.positionTypes.push({
        id: crypto.randomUUID(),
        name: name,
        collapsed: false,
        tags: []
    });
    
    input.value = '';
    renderGlobalPositions();
    if(activePromptId) renderEditor(); // to update optgroups
}

function addPositionTag() {
    const nameInput = document.getElementById('new-pos-tag');
    const typeSelect = document.getElementById('new-pos-tag-type');
    const colorInput = document.getElementById('new-pos-tag-color');
    
    const name = nameInput.value.trim();
    const typeId = typeSelect.value;
    if (!name || !typeId) return;

    lastSelectedPosTypeId = typeId; // Store state of dropdown selection
    
    const targetType = projectData.positionTypes.find(pt => pt.id === typeId);
    if (targetType) {
        targetType.tags.push({
            id: crypto.randomUUID(),
            name: name,
            color: colorInput.value
        });
        
        nameInput.value = '';
        colorInput.value = getRandomHex();
        if (targetType.collapsed) targetType.collapsed = false; // reveal the newly added tag
        
        renderGlobalPositions();
        if(activePromptId) renderEditor();
    }
}

function sortLocalPositions(typeId) {
    const type = projectData.positionTypes.find(pt => pt.id === typeId);
    if (type) {
        type.tags.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));
        renderGlobalPositions();
        if(activePromptId) renderEditor();
    }
}

function clearLocalPositions(typeId) {
    if (confirm("Clear all tags in this category?")) {
        const type = projectData.positionTypes.find(pt => pt.id === typeId);
        if (type) {
            type.tags = [];
            renderGlobalPositions();
            if(activePromptId) renderEditor();
        }
    }
}

// Positions Interactions (Collapse/Edit/Delete)
function togglePosTypeCollapse(id) {
    const type = projectData.positionTypes.find(pt => pt.id === id);
    if (type) {
        type.collapsed = !type.collapsed;
        renderGlobalPositions();
    }
}

function startPosTypeEdit(id) {
    editingPosTypeId = id;
    renderGlobalPositions();
    setTimeout(() => {
        const input = document.getElementById(`edit-postype-${id}`);
        if (input) { input.focus(); input.select(); }
    }, 0);
}

function cancelPosTypeEdit() {
    editingPosTypeId = null;
    renderGlobalPositions();
}

function savePosTypeEdit(id) {
    const input = document.getElementById(`edit-postype-${id}`);
    if (!input) return;
    const newName = input.value.trim();
    if (newName) {
        const type = projectData.positionTypes.find(pt => pt.id === id);
        if (type) type.name = newName;
    }
    editingPosTypeId = null;
    renderGlobalPositions();
    if(activePromptId) renderEditor();
}

// Right Click Context Menu (Position Type)
function showPosTypeContextMenu(e, typeId) {
    e.preventDefault();
    contextMenuTargetId = typeId;
    const menu = document.getElementById('pos-type-context-menu');
    menu.style.left = e.pageX + 'px';
    menu.style.top = e.pageY + 'px';
    menu.classList.remove('hidden');
}

function deletePosTypeFromContext() {
    if (!contextMenuTargetId) return;
    projectData.positionTypes = projectData.positionTypes.filter(pt => pt.id !== contextMenuTargetId);
    closeContextMenus();
    renderGlobalPositions();
    if(activePromptId) renderEditor();
}

// Tag Editing
function startPosTagEdit(id) {
    editingPosTagId = id;
    renderGlobalPositions();
    setTimeout(() => {
        const input = document.getElementById(`edit-postag-${id}`);
        if (input) { input.focus(); input.select(); }
    }, 0);
}

function cancelPosTagEdit() {
    editingPosTagId = null;
    renderGlobalPositions();
}

function savePosTagEdit(typeId, tagId) {
    const nameInput = document.getElementById(`edit-postag-${tagId}`);
    const colorInput = document.getElementById(`edit-postag-color-${tagId}`);
    if (!nameInput) return;
    
    const newName = nameInput.value.trim();
    if (newName) {
        const type = projectData.positionTypes.find(pt => pt.id === typeId);
        if (type) {
            const tag = type.tags.find(t => t.id === tagId);
            if (tag) {
                tag.name = newName;
                tag.color = colorInput.value;
            }
        }
    }
    editingPosTagId = null;
    renderGlobalPositions();
    if(activePromptId) renderEditor();
}

function deletePositionTag(typeId, tagId) {
    const type = projectData.positionTypes.find(pt => pt.id === typeId);
    if (type) {
        type.tags = type.tags.filter(t => t.id !== tagId);
        renderGlobalPositions();
        if(activePromptId) renderEditor();
    }
}

// Unified Drag & Drop for Types & PosTags
function handlePosTypeDragStart(e, typeId) {
    e.dataTransfer.setData("sourceTypeId", typeId);
    e.dataTransfer.setData("dragType", "type");
    e.stopPropagation();
}

function handlePosTagDragStart(e, sourceTypeId, tagId) {
    e.dataTransfer.setData("sourceTypeId", sourceTypeId);
    e.dataTransfer.setData("tagId", tagId);
    e.dataTransfer.setData("dragType", "tag");
    e.stopPropagation();
}

function handlePosDrop(e, targetTypeId) {
    e.preventDefault();
    e.stopPropagation();
    
    const dragType = e.dataTransfer.getData("dragType");
    
    if (dragType === "type") {
        const sourceTypeId = e.dataTransfer.getData("sourceTypeId");
        if (!sourceTypeId || sourceTypeId === targetTypeId) return;

        const sourceIdx = projectData.positionTypes.findIndex(pt => pt.id === sourceTypeId);
        const targetIdx = projectData.positionTypes.findIndex(pt => pt.id === targetTypeId);

        if (sourceIdx > -1 && targetIdx > -1) {
            const [movedType] = projectData.positionTypes.splice(sourceIdx, 1);
            projectData.positionTypes.splice(targetIdx, 0, movedType);
            renderGlobalPositions();
            if (activePromptId) renderEditor();
        }
    } else if (dragType === "tag") {
        const sourceTypeId = e.dataTransfer.getData("sourceTypeId");
        const tagId = e.dataTransfer.getData("tagId");
        
        if (!sourceTypeId || !tagId) return;
        if (sourceTypeId === targetTypeId) return; 
        
        const sourceType = projectData.positionTypes.find(pt => pt.id === sourceTypeId);
        const targetType = projectData.positionTypes.find(pt => pt.id === targetTypeId);
        
        if (sourceType && targetType) {
            const tagIndex = sourceType.tags.findIndex(t => t.id === tagId);
            if (tagIndex > -1) {
                const tag = sourceType.tags.splice(tagIndex, 1)[0];
                targetType.tags.push(tag); // appending to bottom of new list
                if (targetType.collapsed) targetType.collapsed = false;
                
                renderGlobalPositions();
                if(activePromptId) renderEditor();
            }
        }
    }
}

// --- DYNAMIC GLOBAL LISTS (LEFT PANEL - OTHER SECTIONS) ---
function renderGlobalSections() {
    const container = document.getElementById('global-sections-container');
    let html = '';
    
    GLOBAL_SECTIONS.forEach(sec => {
        const items = projectData[sec.key] || [];
        const colorInputId = `new-${sec.key}-color`;
        const existingColorInput = document.getElementById(colorInputId);
        const currentColor = existingColorInput ? existingColorInput.value : getRandomHex();

        html += `
        <div>
            <div class="flex justify-between items-baseline mb-3 mt-6">
                <h3 class="!m-0 text-accent-orange">${sec.title}</h3>
                <span class="text-[10px] text-dim font-bold">${items.length}</span>
            </div>
            <input type="text" id="new-${sec.key}-name" placeholder="${sec.placeholder}" class="text-[11px] p-2 bg-[#0a0a0a] border border-[#222] w-full mb-1 focus:border-cyan-400">
            <div class="flex justify-between items-center bg-[#0a0a0a] border border-[#222] p-2 mb-2 relative h-[38px]">
                <span class="text-[11px] text-white font-bold pl-1">Identity Color</span>
                <input type="color" id="${colorInputId}" value="${currentColor}" class="w-12 h-[26px] p-0 border border-[#333] cursor-pointer bg-transparent absolute right-2 top-1.5">
            </div>
            <button class="w-full bg-cyan-400 text-black font-black uppercase text-[11px] py-2.5 hover:bg-cyan-300 transition-colors tracking-widest" onclick="addGlobalItem('${sec.key}')">${sec.btnText}</button>
            <div class="mt-2 space-y-1">
        `;

        items.forEach(item => {
            const isEditing = editingGlobalItem.section === sec.key && editingGlobalItem.id === item.id;
            if (isEditing) {
                html += `
                <div class="flex items-center bg-black border border-cyan-400 p-1 transition-all mb-1">
                    <input type="text" id="edit-${sec.key}-${item.id}-name" value="${item.name}" class="flex-1 text-[11px] bg-transparent text-white border-none focus:outline-none px-1 h-6">
                    <input type="color" id="edit-${sec.key}-${item.id}-color" value="${item.color}" class="w-6 h-6 p-0 mx-1 border border-white/20 cursor-pointer bg-transparent">
                    <button class="text-cyan-400 hover:bg-cyan-400/20 px-2 py-1 text-[11px] font-bold rounded transition-colors" onclick="saveGlobalItemEdit('${sec.key}', '${item.id}')">✓</button>
                    <button class="text-pink-500 hover:bg-pink-500/20 px-2 py-1 text-[11px] font-bold rounded transition-colors" onclick="cancelGlobalItemEdit()">✕</button>
                </div>
                `;
            } else {
                html += `
                <div class="group flex justify-between items-center bg-[#0a0a0a] border-l-[6px] p-2.5 cursor-pointer transition-colors hover:bg-[#151515] mb-1" style="border-left-color: ${item.color};" ondblclick="startGlobalItemEdit('${sec.key}', '${item.id}')">
                    <span class="text-[12px] font-medium text-white truncate mr-2 pointer-events-none px-1">${item.name}</span>
                    <button class="text-pink-500 hover:text-pink-400 font-bold opacity-0 group-hover:opacity-100 transition-opacity text-sm pr-1" onclick="deleteGlobalItem('${sec.key}', '${item.id}')">✕</button>
                </div>
                `;
            }
        });

        html += `</div></div>`;
    });
    
    container.innerHTML = html;
}

function addGlobalItem(sectionKey) {
    const nameInput = document.getElementById(`new-${sectionKey}-name`);
    const colorInput = document.getElementById(`new-${sectionKey}-color`);
    const name = nameInput.value.trim();
    if (!name) return;
    
    projectData[sectionKey].push({
        id: crypto.randomUUID(),
        name: name,
        color: colorInput.value
    });
    
    colorInput.value = getRandomHex();
    nameInput.value = '';
    
    renderGlobalSections();
    if (activePromptId && sectionKey === 'globalFrames') renderEditor(); // refresh dropdowns
    showNotification("Item Added");
}

function deleteGlobalItem(sectionKey, id) {
    projectData[sectionKey] = projectData[sectionKey].filter(i => i.id !== id);
    renderGlobalSections();
    if (activePromptId && sectionKey === 'globalFrames') renderEditor();
}

function startGlobalItemEdit(sectionKey, id) {
    editingGlobalItem = { section: sectionKey, id: id };
    renderGlobalSections();
    setTimeout(() => {
        const input = document.getElementById(`edit-${sectionKey}-${id}-name`);
        if (input) {
            input.focus();
            input.select();
        }
    }, 0);
}

function cancelGlobalItemEdit() {
    editingGlobalItem = { section: null, id: null };
    renderGlobalSections();
}

function saveGlobalItemEdit(sectionKey, id) {
    const nameInput = document.getElementById(`edit-${sectionKey}-${id}-name`);
    const colorInput = document.getElementById(`edit-${sectionKey}-${id}-color`);
    
    if (!nameInput) return;
    const newName = nameInput.value.trim();
    if (newName) {
        const item = projectData[sectionKey].find(i => i.id === id);
        if (item) {
            item.name = newName;
            item.color = colorInput.value;
        }
    }
    editingGlobalItem = { section: null, id: null };
    renderGlobalSections();
    if (activePromptId && sectionKey === 'globalFrames') renderEditor();
}

// --- TOKEN MANAGEMENT ---
function addGlobalToken() {
    const keyInput = document.getElementById('new-token-key');
    const key = keyInput.value.trim().replace(/[^a-zA-Z0-9]/g, '');
    if (!key) return;
    if (projectData.tokens.some(t => t.key === key)) return;
    
    projectData.tokens.push({ key, value: "Sample Value" });
    keyInput.value = '';
    renderLists();
    updatePreview();
}

function removeToken(idx) {
    projectData.tokens.splice(idx, 1);
    renderLists();
    updatePreview();
}

function updateTokenValue(idx, val) {
    projectData.tokens[idx].value = val;
    updatePreview();
}

function startTokenEdit(idx) {
    editingTokenIdx = idx;
    renderLists();
    setTimeout(() => {
        const input = document.getElementById(`edit-token-key-${idx}`);
        if (input) {
            input.focus();
            input.select();
        }
    }, 0);
}

function cancelTokenEdit() {
    editingTokenIdx = null;
    renderLists();
}

function saveTokenKeyEdit(idx) {
    const input = document.getElementById(`edit-token-key-${idx}`);
    if (!input) return;
    const newKey = input.value.trim().replace(/[^a-zA-Z0-9]/g, '');
    if (!newKey) {
        cancelTokenEdit();
        return;
    }

    const oldKey = projectData.tokens[idx].key;
    if (newKey !== oldKey) {
        if (projectData.tokens.some((t, i) => i !== idx && t.key === newKey)) {
            showNotification("Token key already exists.");
            return;
        }

        // Search and Replace across all prompts and buttons
        const oldTagStr = `{{${oldKey}}}`;
        const newTagStr = `{{${newKey}}}`;
        
        let replacementsMade = 0;
        projectData.prompts.forEach(p => {
            if(p.bodyText && p.bodyText.includes(oldTagStr)) {
                p.bodyText = p.bodyText.split(oldTagStr).join(newTagStr);
                replacementsMade++;
            }
            if(p.title && p.title.includes(oldTagStr)) {
                p.title = p.title.split(oldTagStr).join(newTagStr);
                replacementsMade++;
            }
            if(p.buttons) {
                p.buttons.forEach(b => {
                    if(b.text && b.text.includes(oldTagStr)) {
                        b.text = b.text.split(oldTagStr).join(newTagStr);
                        replacementsMade++;
                    }
                });
            }
        });

        projectData.tokens[idx].key = newKey;
        if(replacementsMade > 0) showNotification(`Updated ${replacementsMade} token instances.`);
    }

    editingTokenIdx = null;
    renderLists();
    updatePreview();
    if(activePromptId) renderEditor();
}


// --- TAG MANAGEMENT ---
function addProjectTag() {
    const nameInput = document.getElementById('new-tag-name');
    const colorInput = document.getElementById('new-tag-color');
    const name = nameInput.value.trim();
    if (!name) return;
    projectData.tags.push({ name, color: colorInput.value });
    nameInput.value = '';
    renderLists();
    populateTagDropdown();
}

function removeTag(idx) {
    const tagName = projectData.tags[idx].name;
    projectData.tags.splice(idx, 1);
    if (activeTag === tagName) activeTag = projectData.tags[0]?.name || null;
    renderLists();
    populateTagDropdown();
}

function startTagEdit(idx) {
    editingTagIdx = idx;
    renderLists();
    setTimeout(() => {
        const input = document.getElementById(`edit-tag-input-${idx}`);
        if (input) {
            input.focus();
            input.select();
        }
    }, 0);
}

function cancelTagEdit() {
    editingTagIdx = null;
    renderLists();
}

function saveTagEdit(idx) {
    const nameInput = document.getElementById(`edit-tag-input-${idx}`);
    const colorInput = document.getElementById(`edit-tag-color-${idx}`);
    if (!nameInput) return;
    
    const newName = nameInput.value.trim();
    if (!newName) {
        cancelTagEdit();
        return;
    }

    const oldName = projectData.tags[idx].name;
    
    if (newName !== oldName && projectData.tags.some((t, i) => i !== idx && t.name === newName)) {
        showNotification("Tag name already exists.");
        return;
    }

    projectData.prompts.forEach(p => {
        if (p.tag === oldName) p.tag = newName;
    });

    if (activeTag === oldName) activeTag = newName;

    projectData.tags[idx].name = newName;
    projectData.tags[idx].color = colorInput.value;
    editingTagIdx = null;
    
    populateTagDropdown();
    renderLists();
    if (activePromptId) renderEditor();
}

// --- PROJECT LOGIC MANAGEMENT & GLOW EFFECTS ---
function getProjectLogic() {
    let logicMap = {}; 
    
    projectData.prompts.forEach(p => {
        if (p.conditions) {
            p.conditions.forEach(c => {
                if (!c.key) return;
                let id = `${c.key}||${c.op}||${c.val}`;
                if(!logicMap[id]) logicMap[id] = { key: c.key, op: c.op, val: c.val, isCondition: false, isStateChange: false, uses: [] };
                logicMap[id].isCondition = true;
                logicMap[id].uses.push({ promptId: p.id, type: 'Condition', text: p.title, context: c });
            });
        }
        
        if (p.gameStateChanges) {
            p.gameStateChanges.forEach(c => {
                if (!c.key) return;
                let id = `${c.key}||${c.op}||${c.val}`;
                if(!logicMap[id]) logicMap[id] = { key: c.key, op: c.op, val: c.val, isCondition: false, isStateChange: false, uses: [] };
                logicMap[id].isStateChange = true;
                logicMap[id].uses.push({ promptId: p.id, type: 'State Change', text: p.title, context: c });
            });
        }
        
        if(p.buttons) {
            p.buttons.forEach((b, bIdx) => {
                if(b.stateChanges) {
                    b.stateChanges.forEach(c => {
                        if (!c.key) return;
                        let id = `${c.key}||${c.op}||${c.val}`;
                        if(!logicMap[id]) logicMap[id] = { key: c.key, op: c.op, val: c.val, isCondition: false, isStateChange: false, uses: [] };
                        logicMap[id].isStateChange = true;
                        logicMap[id].uses.push({ promptId: p.id, type: 'Button State Change', text: b.text || 'Unnamed Button', context: c, btnIdx: bIdx });
                    });
                }
            });
        }
    });
    return Object.values(logicMap);
}

function getPromptGlowState(promptId, allLogic) {
    const p = projectData.prompts.find(pr => pr.id === promptId);
    if (!p) return 'none';

    let needsRed = false;
    if (!p.isCalledExternally && p.conditions) {
        for (let c of p.conditions) {
            if (!c.key) continue;
            let logicItem = allLogic.find(l => l.key === c.key && l.op === c.op && l.val === c.val);
            if (logicItem && !logicItem.isStateChange) {
                needsRed = true; break;
            }
        }
    }

    let needsBlue = false;
    if (!p.makeExternalCall) {
        let allChanges = [];
        if (p.gameStateChanges) allChanges.push(...p.gameStateChanges);
        if (p.buttons) p.buttons.forEach(b => { if (b.stateChanges) allChanges.push(...b.stateChanges); });
        
        for (let c of allChanges) {
            if (!c.key) continue;
            let logicItem = allLogic.find(l => l.key === c.key && l.op === c.op && l.val === c.val);
            if (logicItem && !logicItem.isCondition) {
                needsBlue = true; break;
            }
        }
    }

    if (needsRed && needsBlue) return 'purple';
    if (needsRed) return 'red';
    if (needsBlue) return 'blue';
    return 'none';
}

function updateCardGlowOnly() {
    const allLogic = getProjectLogic();
    const glowState = getPromptGlowState(activePromptId, allLogic);
    const card = document.getElementById('active-prompt-card');
    if (card) {
        card.style.boxShadow = 'none';
        if (glowState === 'purple') card.style.boxShadow = '0 0 25px rgba(168,85,247,0.4)';
        else if (glowState === 'red') card.style.boxShadow = '0 0 25px rgba(239,68,68,0.4)';
        else if (glowState === 'blue') card.style.boxShadow = '0 0 25px rgba(59,130,246,0.4)';
    }
}

function updateDynamicGlows() {
    updateCardGlowOnly();
    renderLists(); 
}

function renderLogicPanel() {
    const inputEl = document.getElementById('logic-search');
    logicSearchQuery = inputEl ? inputEl.value.toLowerCase() : "";
    const logicMap = getProjectLogic(); 
    const container = document.getElementById('logic-list-container');
    if(!container) return;
    
    let filtered = logicMap.filter(l => l.key.toLowerCase().includes(logicSearchQuery) || l.val.toLowerCase().includes(logicSearchQuery));
    filtered.sort((a,b) => a.key.localeCompare(b.key));
    
    let html = '';
    filtered.forEach(l => {
        let borderColor = 'border-green-500'; 
        if (l.isStateChange && !l.isCondition) borderColor = 'border-[#00f2ff]'; 
        if (l.isStateChange && l.isCondition) borderColor = 'border-purple-500'; 
        
        const safeKey = l.key.replace(/'/g, "\\'");
        const safeOp = l.op.replace(/'/g, "\\'");
        const safeVal = l.val.replace(/'/g, "\\'");
        
        html += `
        <div class="border-l-4 ${borderColor} bg-[#0c0c0c] hover:bg-[#1a1a1a] cursor-pointer pl-3 py-2 mb-1 flex items-center justify-between text-[12px] font-bold transition-colors shadow-sm" onclick="openLogicModal('${safeKey}', '${safeOp}', '${safeVal}')">
            <div class="flex gap-2 text-white truncate mr-2 items-center">
                <span class="truncate">${l.key}</span>
                <span class="opacity-50 text-[10px]">${l.op}</span>
                <span class="text-white truncate max-w-[80px]">${l.val}</span>
            </div>
            <span class="text-dim opacity-50 flex-shrink-0 text-[10px]">[${l.uses.length}]</span>
        </div>
        `;
    });
    
    container.innerHTML = html || '<div class="text-[10px] text-dim opacity-50 italic mt-2">No active tags match criteria.</div>';
}

function openLogicModal(key, op, val) {
    currentLogicEdit = { key, op, val };
    document.getElementById('logic-edit-key').value = key;
    document.getElementById('logic-edit-val').value = val;
    document.getElementById('logic-modal').classList.remove('hidden');
    renderLogicDependencies();
}

function closeLogicModal() {
    document.getElementById('logic-modal').classList.add('hidden');
    currentLogicEdit = null;
}

function renderLogicDependencies() {
    const list = document.getElementById('logic-dependencies-list');
    if(!currentLogicEdit) return;
    
    const allLogic = getProjectLogic();
    const target = allLogic.find(l => l.key === currentLogicEdit.key && l.op === currentLogicEdit.op && l.val === currentLogicEdit.val);
    
    if (!target || target.uses.length === 0) {
        list.innerHTML = '<div class="text-[10px] text-dim italic">No dependencies found.</div>';
        return;
    }
    
    let html = '';
    target.uses.forEach((use, i) => {
        let contextLabel = "NODE STATE CHANGE";
        if (use.type === 'Condition') contextLabel = "NODE CONDITION";
        else if (use.type === 'Button State Change') contextLabel = "NODE STATE CHANGE";
        
        let shortText = use.text;
        if (shortText && shortText.length > 55) shortText = shortText.substring(0, 55) + "...";
        
        html += `
        <div class="bg-[#0a0a0a] border border-[#222] p-4 flex justify-between items-center mb-2 rounded-sm shadow-inner">
            <div class="flex-1 mr-4 overflow-hidden">
                <div class="text-[10px] uppercase font-black text-[#ffe600] mb-1 tracking-widest">${contextLabel}</div>
                <div class="text-[13px] text-white italic truncate">"${shortText}"</div>
            </div>
            <div class="flex gap-2 flex-shrink-0">
                <button class="border border-cyan-400 text-cyan-400 hover:bg-cyan-400/10 transition-colors font-bold text-[9px] w-[60px] h-[36px] flex flex-col items-center justify-center rounded-sm uppercase tracking-widest leading-tight" onclick="jumpToLogicDependency('${use.promptId}')">JUMP<br><span class="text-[14px] leading-none">&crarr;</span></button>
                <button class="border border-pink-500 text-pink-500 hover:bg-pink-500/10 transition-colors font-bold text-[9px] w-[60px] h-[36px] flex items-center justify-center rounded-sm uppercase tracking-widest" onclick="deleteLogicDependency('${use.promptId}', '${use.type}', ${use.btnIdx !== undefined ? use.btnIdx : 'null'})">DELETE</button>
            </div>
        </div>
        `;
    });
    list.innerHTML = html;
}

function jumpToLogicDependency(promptId) {
    closeLogicModal();
    selectPrompt(promptId);
}

function deleteLogicDependency(promptId, type, btnIdx) {
    const p = projectData.prompts.find(pr => pr.id === promptId);
    if (!p) return;
    const isMatch = (c) => c.key === currentLogicEdit.key && c.op === currentLogicEdit.op && c.val === currentLogicEdit.val;
    
    if (type === 'Condition') {
        p.conditions = p.conditions.filter(c => !isMatch(c));
    } else if (type === 'State Change') {
        p.gameStateChanges = p.gameStateChanges.filter(c => !isMatch(c));
    } else if (type === 'Button State Change' && btnIdx !== null) {
        p.buttons[btnIdx].stateChanges = p.buttons[btnIdx].stateChanges.filter(c => !isMatch(c));
    }
    
    showNotification("Dependency Deleted");
    renderLogicDependencies();
    renderLogicPanel();
    updateDynamicGlows();
}

function applyLogicChangeThroughout() {
    const newKey = document.getElementById('logic-edit-key').value.trim();
    const newVal = document.getElementById('logic-edit-val').value.trim();
    if (!newKey) return;
    
    let count = 0;
    projectData.prompts.forEach(p => {
        const checkAndUpdate = (c) => {
            if (c.key === currentLogicEdit.key && c.op === currentLogicEdit.op && c.val === currentLogicEdit.val) {
                c.key = newKey;
                c.val = newVal;
                count++;
            }
        };
        
        if(p.conditions) p.conditions.forEach(checkAndUpdate);
        if(p.gameStateChanges) p.gameStateChanges.forEach(checkAndUpdate);
        if(p.buttons) {
            p.buttons.forEach(b => {
                if(b.stateChanges) b.stateChanges.forEach(checkAndUpdate);
            });
        }
    });
    
    showNotification(`Updated ${count} instances.`);
    closeLogicModal();
    renderLogicPanel();
    updateDynamicGlows();
}

// --- PROMPT MANAGEMENT ---
function createNewPrompt() {
    const newPrompt = {
        id: crypto.randomUUID(),
        parentId: null,
        rootId: null,
        tag: activeTag || projectData.tags[0]?.name || "News Alert",
        title: "New Panel Setup",
        backgroundTintType: "none", 
        backgroundTintOpacity: 0, 
        bodyText: "Message content goes here...",
        textFormat: {
            bold: false,
            italic: false,
            underline: false,
            strikethrough: false,
            listStyle: 'none', 
            alignH: 'left', 
            alignV: 'top' 
        },
        priority: 0,
        isRepeatable: false,
        isCalledExternally: false,
        makeExternalCall: false,
        
        hasTriggers: false,
        triggers: [],
        windowPositionId: "",
        
        frames: [], // Array for Prompt Frames
        
        hasVisualPayload: false,
        visualPayloads: [{ name: "MainImage", path: "Assets/Resources/Announcement/" }],
        
        hasButton: false,
        buttons: [],
        
        conditions: [],
        gameStateChanges: [],
        
        winReopenDialogue: false,
        winCloseDialogue: false,
        winReopenMainMenu: false,
        winCloseMainMenu: false,
        winClosePromptPanel: true,

        timestamp: Date.now()
    };
    projectData.prompts.push(newPrompt);
    activePromptId = newPrompt.id;
    lastActivePerCategory[newPrompt.tag] = newPrompt.id;
    renderLists();
    renderLogicPanel();
    renderEditor();
}

function updateActivePrompt(field, val) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (prompt) {
        prompt[field] = val;
        if (field === 'title' || field === 'tag' || field === 'isCalledExternally' || field === 'makeExternalCall') {
            renderLists();
            updateCardGlowOnly();
            if(field === 'isCalledExternally' || field === 'makeExternalCall') renderLogicPanel();
        }
    }
}

function updateActivePromptBGType(type) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    prompt.backgroundTintType = type;
    if (type === 'none') prompt.backgroundTintOpacity = 0;
    else if (type === 'half') prompt.backgroundTintOpacity = 0.5;
    else if (type === 'black') prompt.backgroundTintOpacity = 1;
    else if (type === 'custom') {
        if (prompt.backgroundTintOpacity === undefined) prompt.backgroundTintOpacity = 0.5;
    }
    renderEditor();
}

function updateActivePromptBGOpacity(val) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    prompt.backgroundTintOpacity = parseFloat(val);
    const display = document.getElementById('bg-opacity-display');
    if(display) display.innerText = prompt.backgroundTintOpacity.toFixed(2);
}

// --- TMP FORMATTING ENGINE ---
function applyTextFormat(tagType, tagParam = '') {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    
    const textarea = document.getElementById('edit-body');
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = textarea.value.substring(start, end);
    
    if (selectedText.length > 0) {
        if (['top', 'middle', 'bottom'].includes(tagType)) {
            showNotification("Vertical alignment must be applied globally (select no text).");
            return;
        }
        
        let newText = '';
        let offsetCursor = 0;
        
        if (tagType === 'align') {
            newText = textarea.value.substring(0, start) + `<align="${tagParam}">` + selectedText + `</align>` + textarea.value.substring(end);
            offsetCursor = 17 + tagParam.length; 
        } else if (tagType === 'bullet') {
            const lines = selectedText.split('\n').map(l => `• ${l}`).join('\n');
            newText = textarea.value.substring(0, start) + lines + textarea.value.substring(end);
            offsetCursor = newText.length - textarea.value.length;
        } else if (tagType === 'number') {
            const lines = selectedText.split('\n').map((l, i) => `${i+1}. ${l}`).join('\n');
            newText = textarea.value.substring(0, start) + lines + textarea.value.substring(end);
            offsetCursor = newText.length - textarea.value.length;
        } else {
            newText = textarea.value.substring(0, start) + `<${tagType}>` + selectedText + `</${tagType}>` + textarea.value.substring(end);
            offsetCursor = 7; 
        }
        
        textarea.value = newText;
        updateActivePrompt('bodyText', newText);
        
        textarea.focus();
        textarea.setSelectionRange(start, end + offsetCursor);
        updatePreview();
    } 
    else {
        if (!prompt.textFormat) prompt.textFormat = {};
        
        if (tagType === 'align') {
            prompt.textFormat.alignH = tagParam;
        } else if (['top', 'middle', 'bottom'].includes(tagType)) {
            prompt.textFormat.alignV = tagType;
        } else if (tagType === 'bullet') {
            prompt.textFormat.listStyle = prompt.textFormat.listStyle === 'bullet' ? 'none' : 'bullet';
        } else if (tagType === 'number') {
            prompt.textFormat.listStyle = prompt.textFormat.listStyle === 'number' ? 'none' : 'number';
        } else {
            const keyMap = { 'b': 'bold', 'i': 'italic', 'u': 'underline', 's': 'strikethrough' };
            const key = keyMap[tagType];
            if (key) prompt.textFormat[key] = !prompt.textFormat[key];
        }
        renderEditor(); 
    }
}

// --- PROMPT FRAMES MANAGEMENT ---
function renderFramesAndPositions() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const container = document.getElementById('container-frames-positions');
    if (!prompt || !container) return;

    if (!prompt.frames) prompt.frames = [];

    // Prebuild the OptGroup Options for Positions
    const positionOptionsHTML = getPositionOptionsHTML();

    // Prebuild Frame Options
    const globalFrames = projectData.globalFrames || [];
    let frameOptionsHTML = `<option value="">-- Select Frame --</option>`;
    globalFrames.forEach(gf => {
        frameOptionsHTML += `<option value="${gf.id}">${gf.name}</option>`;
    });

    let html = '';

    if (prompt.frames.length === 0) {
        html += `<button class="btn border border-green-500/50 text-green-500 hover:bg-green-500/10 transition-colors w-full flex justify-center py-2 text-[10px] font-black" onclick="addFrame()">+ ADD SINGLE FRAME</button>`;
    } else {
        html += prompt.frames.map((frame, idx) => `
            <div class="bg-black/50 border border-white/10 p-3 rounded relative hover:border-pink-500/30 transition-colors">
                <button class="absolute top-2 right-2 text-pink-500 font-bold hover:text-white" onclick="removeFrame(${idx})">✕</button>
                <div class="grid grid-cols-2 gap-3 mb-3 pr-4">
                    <div>
                        <label class="text-[9px] uppercase font-bold text-dim mb-1 block">Assigned Frame</label>
                        <select class="text-[10px] p-2 bg-[#0a0a0a] border border-[#222] focus:border-pink-500 w-full" onchange="updateFrame(${idx}, 'frameId', this.value)">
                            ${frameOptionsHTML.replace(`value="${frame.frameId}"`, `value="${frame.frameId}" selected`)}
                        </select>
                    </div>
                    <div>
                        <label class="text-[9px] uppercase font-bold text-dim mb-1 block">Render Position</label>
                        <select class="text-[10px] p-2 bg-[#0a0a0a] border border-[#222] focus:border-pink-500 w-full" onchange="updateFrame(${idx}, 'positionId', this.value)">
                            ${getPositionOptionsHTML(frame.positionId)}
                        </select>
                    </div>
                </div>
                <div class="flex gap-4 items-center border-t border-white/5 pt-2">
                    <label class="flex items-center gap-2 cursor-pointer text-[9px] font-black uppercase text-accent-teal">
                        <input type="checkbox" ${frame.disableOnClose ? 'checked' : ''} onchange="updateFrame(${idx}, 'disableOnClose', this.checked)"> Disable Frame On Close
                    </label>
                    <label class="flex items-center gap-2 cursor-pointer text-[9px] font-black uppercase text-accent-orange">
                        <input type="checkbox" ${frame.invert ? 'checked' : ''} onchange="updateFrame(${idx}, 'invert', this.checked)"> Invert
                    </label>
                </div>
            </div>
        `).join('');

        if (prompt.frames.length < 2) {
            html += `<button class="btn border border-green-500/50 text-green-500 hover:bg-green-500/10 text-xl font-black w-full flex items-center justify-center py-0 leading-none h-8" onclick="addFrame()">+</button>`;
        }
    }

    container.innerHTML = html;
}

function addFrame() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    if (!prompt.frames) prompt.frames = [];
    if (prompt.frames.length >= 2) return;

    prompt.frames.push({
        id: crypto.randomUUID(),
        frameId: "",
        positionId: "",
        disableOnClose: true,
        invert: false
    });
    renderFramesAndPositions();
}

function removeFrame(idx) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    prompt.frames.splice(idx, 1);
    renderFramesAndPositions();
}

function updateFrame(idx, field, val) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (prompt && prompt.frames[idx]) {
        prompt.frames[idx][field] = val;
    }
}


// --- VISUAL PAYLOAD MANAGEMENT ---
function addVisualPayload() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    if (!prompt.visualPayloads) prompt.visualPayloads = [];
    prompt.visualPayloads.push({ name: '', path: 'Assets/Resources/' });
    renderVisualPayloads();
}

function removeVisualPayload(idx) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !prompt.visualPayloads) return;
    prompt.visualPayloads.splice(idx, 1);
    renderVisualPayloads();
}

function updateVisualPayload(idx, field, val) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (prompt && prompt.visualPayloads) {
        prompt.visualPayloads[idx][field] = val;
    }
}

function renderVisualPayloads() {
    const container = document.getElementById('container-visualPayloads');
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !container) return;

    const arr = prompt.visualPayloads || [];
    if (arr.length === 0) {
        container.innerHTML = `<div class="text-[10px] text-dim italic opacity-50">No references configured.</div>`;
        return;
    }

    container.innerHTML = arr.map((item, idx) => `
        <div class="payload-row">
            <input type="text" class="text-[10px] p-1.5 focus:border-accent-orange" placeholder="Variable Name" value="${item.name}" oninput="updateVisualPayload(${idx}, 'name', this.value)">
            <input type="text" class="text-[10px] p-1.5 focus:border-accent-orange" placeholder="Object Path" value="${item.path}" oninput="updateVisualPayload(${idx}, 'path', this.value)">
            <button class="text-pink-500 font-bold hover:text-white bg-black/50 rounded h-full transition-colors" onclick="removeVisualPayload(${idx})">×</button>
        </div>
    `).join('');
}

// --- BUTTON & BRANCHING MANAGEMENT ---
function toggleBranching(btnIdx, isChecked) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !prompt.buttons) return;
    
    prompt.buttons[btnIdx].isBranching = isChecked;
    
    if (isChecked && !prompt.buttons[btnIdx].branchPromptId) {
        const branchId = crypto.randomUUID();
        const rootId = prompt.rootId || prompt.id;
        
        const newPrompt = {
            id: branchId,
            parentId: prompt.id,
            rootId: rootId,
            tag: prompt.tag,
            title: prompt.title + " (Phase 2)",
            backgroundTintType: prompt.backgroundTintType || "none",
            backgroundTintOpacity: prompt.backgroundTintOpacity || 0,
            bodyText: "",
            textFormat: { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'left', alignV: 'top' },
            priority: prompt.priority,
            isRepeatable: prompt.isRepeatable,
            isCalledExternally: false,
            makeExternalCall: false,
            hasTriggers: false, triggers: [],
            windowPositionId: "",
            frames: [],
            hasVisualPayload: false, visualPayloads: [],
            hasButton: false, buttons: [],
            conditions: [], gameStateChanges: [],
            winReopenDialogue: false, winCloseDialogue: false, winReopenMainMenu: false, winCloseMainMenu: false, winClosePromptPanel: true,
            timestamp: Date.now()
        };
        projectData.prompts.push(newPrompt);
        prompt.buttons[btnIdx].branchPromptId = branchId;
    }
    renderActionButtons();
    renderLists();
}

function addActionButton() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    if (!prompt.buttons) prompt.buttons = [];
    
    if (prompt.buttons.length >= 4) return;
    
    prompt.buttons.push({
        id: crypto.randomUUID(),
        text: "Continue",
        stateChanges: [],
        isBranching: false,
        branchPromptId: null,
        closeMenu: false,
        isExternalLink: false,
        externalUrl: ''
    });
    renderActionButtons();
}

function removeActionButton(idx) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !prompt.buttons) return;
    prompt.buttons.splice(idx, 1);
    renderActionButtons();
    renderLogicPanel();
    updateDynamicGlows();
}

function updateActionButton(idx, field, val) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (prompt && prompt.buttons) {
        prompt.buttons[idx][field] = val;
    }
}

function addButtonStateChange(bIdx) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    prompt.buttons[bIdx].stateChanges.push({ key: '', op: '==', val: '' });
    renderActionButtons();
    renderLogicPanel();
    updateDynamicGlows();
}

function removeButtonStateChange(bIdx, sIdx) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    prompt.buttons[bIdx].stateChanges.splice(sIdx, 1);
    renderActionButtons();
    renderLogicPanel();
    updateDynamicGlows();
}

function updateButtonStateChange(bIdx, sIdx, field, value) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (prompt) {
        prompt.buttons[bIdx].stateChanges[sIdx][field] = value;
        renderLogicPanel();
        updateDynamicGlows();
    }
}

function renderActionButtons() {
    const container = document.getElementById('buttons-list');
    const addBtn = document.getElementById('btn-add-action-button');
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !container) return;

    if (prompt.buttons === undefined) prompt.buttons = [];

    if (prompt.buttons.length >= 4) {
        addBtn.style.display = 'none';
    } else {
        addBtn.style.display = 'block';
        if (prompt.buttons.length === 0) {
            addBtn.innerText = "+ ADD BUTTON";
        } else {
            addBtn.innerText = `+ ADD BUTTON (${4 - prompt.buttons.length} REMAINING)`;
        }
    }

    container.innerHTML = prompt.buttons.map((btn, btnIdx) => {
        const branchExists = btn.branchPromptId && projectData.prompts.some(p => p.id === btn.branchPromptId);
        
        return `
        <div class="bg-black/60 border border-white/10 p-3 mb-4 relative hover:border-cyan-400/50 transition-colors">
            <button class="absolute top-2 right-2 text-pink-500 font-bold hover:text-white" onclick="removeActionButton(${btnIdx})">✕</button>
            <div class="mb-4 pr-6">
                <label class="section-header text-white">Button Text</label>
                <input type="text" value="${btn.text}" oninput="updateActionButton(${btnIdx}, 'text', this.value)" placeholder="Accept / Continue / Buy">
            </div>

            <div class="mb-4">
                <div class="flex justify-between items-center mb-3">
                    <label class="section-header text-accent-teal mb-0">Change Game State</label>
                    <button class="btn btn-outline py-1 px-2 text-[9px] text-accent-teal border-accent-teal hover:bg-accent-teal/10" onclick="addButtonStateChange(${btnIdx})">+ ADD STATE CHANGE</button>
                </div>
                <div id="container-btnStateChanges-${btnIdx}">
                    ${btn.stateChanges.length === 0 ? `<div class="text-[10px] text-dim italic opacity-50">No items configured.</div>` : 
                      btn.stateChanges.map((item, sIdx) => `
                        <div class="array-row">
                            <input type="text" class="text-[10px] p-1.5 focus:border-accent-teal" placeholder="Variable" value="${item.key}" oninput="updateButtonStateChange(${btnIdx}, ${sIdx}, 'key', this.value)">
                            <select class="text-[10px] p-1.5 font-bold focus:border-accent-teal" onchange="updateButtonStateChange(${btnIdx}, ${sIdx}, 'op', this.value)">
                                ${OPERATORS.map(o => `<option value="${o}" ${item.op === o ? 'selected' : ''}>${o}</option>`).join('')}
                            </select>
                            <input type="text" class="text-[10px] p-1.5 focus:border-accent-teal" placeholder="Value" value="${item.val}" oninput="updateButtonStateChange(${btnIdx}, ${sIdx}, 'val', this.value)">
                            <button class="text-pink-500 font-bold hover:text-white bg-black/50 rounded h-full transition-colors" onclick="removeButtonStateChange(${btnIdx}, ${sIdx})">×</button>
                        </div>
                      `).join('')
                    }
                </div>
            </div>

            <div class="mt-2 pt-3 border-t border-white/5 flex flex-wrap gap-4 items-center">
                 <label class="flex items-center gap-2 cursor-pointer text-[10px] font-black uppercase text-accent-gold">
                     <input type="checkbox" ${btn.isBranching ? 'checked' : ''} onchange="toggleBranching(${btnIdx}, this.checked)"> 
                     Branching Panel
                 </label>

                 <label class="flex items-center gap-2 cursor-pointer text-[10px] font-black uppercase text-accent-teal">
                     <input type="checkbox" ${btn.closeMenu ? 'checked' : ''} onchange="updateActionButton(${btnIdx}, 'closeMenu', this.checked)"> 
                     Close Menu?
                 </label>

                 <label class="flex items-center gap-2 cursor-pointer text-[10px] font-black uppercase text-accent-orange">
                     <input type="checkbox" ${btn.isExternalLink ? 'checked' : ''} onchange="updateActionButton(${btnIdx}, 'isExternalLink', this.checked); renderActionButtons();"> 
                     External Link?
                 </label>

                 ${btn.isBranching && branchExists ? `
                    <button class="btn btn-gold py-1 px-3 text-[9px] hover:bg-yellow-300" onclick="selectPrompt('${btn.branchPromptId}')">EDIT BRANCH ↳</button>
                 ` : ''}
            </div>

            ${btn.isExternalLink ? `
            <div class="mt-4 bg-black/30 p-3 border border-accent-orange/20">
                <label class="section-header text-accent-orange">External Redirect URL</label>
                <input type="text" value="${btn.externalUrl || ''}" oninput="updateActionButton(${btnIdx}, 'externalUrl', this.value)" placeholder="https://yourwebsite.com/news/123" class="focus:border-accent-orange">
                <p class="text-[9px] opacity-40 mt-1 uppercase italic">When clicked, this button will signal a web request.</p>
            </div>
            ` : ''}
        </div>
    `}).join('');
}

// --- ARRAYS MANAGEMENT (Conditions & State Changes) ---
function addArrayItem(type) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    
    prompt[type].push({ key: '', op: '==', val: '' });
    renderArray(type);
    renderLogicPanel();
    updateDynamicGlows();
}

function removeArrayItem(type, index) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;

    prompt[type].splice(index, 1);
    renderArray(type);
    renderLogicPanel();
    updateDynamicGlows();
}

function updateArrayItem(type, index, field, value) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (prompt) {
        prompt[type][index][field] = value;
        renderLogicPanel();
        updateDynamicGlows();
    }
}

function renderArray(type) {
    const container = document.getElementById(`container-${type}`);
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !container) return;

    const arr = prompt[type] || [];
    let inputFocusClass = type === 'conditions' ? 'focus:border-accent-pink' : 'focus:border-accent-green';

    if (arr.length === 0) {
        container.innerHTML = `<div class="text-[10px] text-dim italic opacity-50">No items configured.</div>`;
        return;
    }

    container.innerHTML = arr.map((item, idx) => `
        <div class="array-row">
            <input type="text" class="text-[10px] p-1.5 ${inputFocusClass}" placeholder="Variable" value="${item.key}" oninput="updateArrayItem('${type}', ${idx}, 'key', this.value)">
            <select class="text-[10px] p-1.5 font-bold ${inputFocusClass}" onchange="updateArrayItem('${type}', ${idx}, 'op', this.value)">
                ${OPERATORS.map(o => `<option value="${o}" ${item.op === o ? 'selected' : ''}>${o}</option>`).join('')}
            </select>
            <input type="text" class="text-[10px] p-1.5 ${inputFocusClass}" placeholder="Value" value="${item.val}" oninput="updateArrayItem('${type}', ${idx}, 'val', this.value)">
            <button class="text-pink-500 font-bold hover:text-white bg-black/50 rounded h-full transition-colors" onclick="removeArrayItem('${type}', ${idx})">×</button>
        </div>
    `).join('');
}

// --- TRIGGERS MANAGEMENT ---
function addTrigger() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    if (!prompt.triggers) prompt.triggers = [];
    prompt.triggers.push('OnGameAwake');
    renderTriggers();
    renderLists();
    showNotification("Trigger Added");
}

function removeTrigger(idx) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;
    prompt.triggers.splice(idx, 1);
    renderTriggers();
    renderLists();
}

function updateTrigger(idx, val) {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (prompt) prompt.triggers[idx] = val;
    renderLists();
}

function renderTriggers() {
    const container = document.getElementById('container-triggers');
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt || !container) return;

    const arr = prompt.triggers || [];
    if (arr.length === 0) {
        container.innerHTML = `<div class="text-[10px] text-dim italic opacity-50">No triggers configured.</div>`;
        return;
    }

    container.innerHTML = arr.map((item, idx) => `
        <div class="flex gap-2 mb-2 items-center">
            <select class="text-[10px] p-1.5 flex-1 font-bold bg-black/50 focus:border-accent-teal" onchange="updateTrigger(${idx}, this.value)">
                ${TRIGGER_EVENTS.map(o => `<option value="${o}" ${item === o ? 'selected' : ''}>${o}</option>`).join('')}
            </select>
            <button class="text-pink-500 font-bold hover:text-white bg-black/50 px-3 py-1.5 rounded transition-colors" onclick="removeTrigger(${idx})">×</button>
        </div>
    `).join('');
}

function toggleTriggersUI() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const container = document.getElementById('triggers-setup-container');
    if (prompt && prompt.hasTriggers) {
        container.classList.remove('hidden');
    } else {
        container.classList.add('hidden');
    }
}

// --- EDITOR LOGIC & EXCLUSIVITY ---
function handleExclusivity(changedId, opposedId, isChecked) {
    updateActivePrompt(changedId, isChecked);
    if (isChecked) {
        const opposed = document.getElementById(opposedId);
        if(opposed) opposed.checked = false;
        updateActivePrompt(opposedId, false);
    }
}

function toggleButtonUI() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const container = document.getElementById('button-setup-container');
    if (prompt && prompt.hasButton) {
        container.classList.remove('hidden');
    } else {
        container.classList.add('hidden');
    }
    renderActionButtons();
}

function toggleVisualPayloadUI() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    const container = document.getElementById('visual-payload-container');
    if (prompt && prompt.hasVisualPayload) {
        container.classList.remove('hidden');
    } else {
        container.classList.add('hidden');
    }
    renderVisualPayloads();
}

function updatePromptTag(newTagName) {
    updateActivePrompt('tag', newTagName);
    activeTag = newTagName; 
    lastActivePerCategory[newTagName] = activePromptId;
    
    const tagObj = projectData.tags.find(t => t.name === newTagName);
    if (tagObj) {
        document.getElementById('active-prompt-card').style.borderLeftColor = tagObj.color;
    }
    renderLists();
}

function populateTagDropdown() {
    const select = document.getElementById('edit-tag');
    if(select) {
        select.innerHTML = projectData.tags.map(t => `<option value="${t.name}">${t.name}</option>`).join('');
    }
}

// --- RENDERING ---
function renderLists() {
    const allLogic = getProjectLogic();
    
    const promptSearchInput = document.getElementById('prompt-search');
    const searchQ = promptSearchInput ? promptSearchInput.value.toLowerCase() : "";

    // Tokens
    const tokenList = document.getElementById('list-tokens');
    tokenList.innerHTML = projectData.tokens.map((t, idx) => {
        if (editingTokenIdx === idx) {
            return `
                <li class="bg-black border border-cyan-400 p-1 flex items-center">
                    <span class="text-cyan-400 font-monospace text-[10px] mr-1">{{</span>
                    <input type="text" id="edit-token-key-${idx}" value="${t.key}" class="flex-1 text-[10px] p-1 bg-transparent text-white border-none focus:outline-none m-0">
                    <span class="text-cyan-400 font-monospace text-[10px] ml-1 mr-2">}}</span>
                    <button class="text-cyan-400 font-bold px-1 hover:text-white" onclick="saveTokenKeyEdit(${idx})">✓</button>
                    <button class="text-pink-500 font-bold px-1 hover:text-white" onclick="cancelTokenEdit()">✕</button>
                </li>
            `;
        } else {
            return `
                <li>
                    <div class="flex flex-col gap-1 w-full">
                        <div class="flex justify-between items-center">
                            <span class="token-tag" ondblclick="startTokenEdit(${idx})" title="Double-click to rename token">{{${t.key}}}</span>
                            <span class="text-pink-500 cursor-pointer text-base hover:text-white transition-colors" onclick="removeToken(${idx})">×</span>
                        </div>
                        <input type="text" class="text-[9px] p-1 bg-[#151515] border border-[#222] focus:border-cyan-400 mt-1" value="${t.value}" oninput="updateTokenValue(${idx}, this.value)">
                    </div>
                </li>
            `;
        }
    }).join('');

    // Tags
    const tagList = document.getElementById('list-tags');
    tagList.innerHTML = projectData.tags.map((tag, idx) => {
        if (editingTagIdx === idx) {
            return `
                <li style="border-left-color: ${tag.color}; padding-right: 4px;">
                    <div class="flex gap-1 w-full items-center">
                        <input type="text" id="edit-tag-input-${idx}" value="${tag.name}" class="flex-1 text-[10px] p-1 bg-black text-white border border-teal-500 m-0 h-6">
                        <input type="color" id="edit-tag-color-${idx}" value="${tag.color}" class="w-5 h-5 p-0 m-0 border-none cursor-pointer bg-transparent">
                        <button class="text-cyan-400 font-bold px-1 hover:text-white" onclick="saveTagEdit(${idx})">✓</button>
                        <button class="text-pink-500 font-bold px-1 hover:text-white" onclick="cancelTagEdit()">✕</button>
                    </div>
                </li>
            `;
        } else {
            return `
                <li class="group" style="border-left-color: ${tag.color}">
                    <span class="flex-1 cursor-text" ondblclick="startTagEdit(${idx})" title="Double-click to edit">${tag.name}</span>
                    <span class="text-pink-500 cursor-pointer text-base ml-2 opacity-0 group-hover:opacity-100 transition-opacity" onclick="removeTag(${idx})">×</span>
                </li>
            `;
        }
    }).join('');

    // Render Global Positions Block
    renderGlobalPositions();

    // Render Dynamic Global Sections
    renderGlobalSections();

    // Category Tabs
    const tabs = document.getElementById('category-tabs');
    if(projectData.tags.length === 0) activeTag = null;
    
    tabs.innerHTML = projectData.tags.map(tag => `
        <div class="char-tab ${activeTag === tag.name ? 'active' : ''} hover:bg-[#1a1a1a] transition-colors" onclick="selectCategory('${tag.name}')">
            <span style="color: ${tag.color}">●</span> ${tag.name}
        </div>
    `).join('');

    // Prompt Library (Grouped by Tag)
    const list = document.getElementById('prompt-list');
    let listHTML = '';

    projectData.tags.forEach(tag => {
        const promptsForTag = projectData.prompts.filter(p => p.tag === tag.name);
        
        let hasVisiblePrompts = false;
        let tagGroupHTML = `
            <div class="tag-group" 
                 ondragover="event.preventDefault(); this.classList.add('drag-over')" 
                 ondragleave="this.classList.remove('drag-over')" 
                 ondrop="handlePromptDrop(event, '${tag.name}')">
                <div class="mt-5 mb-2 border-b border-white/10 pb-1 flex justify-between items-center">
                    <span class="text-[10px] uppercase font-black tracking-widest" style="color: ${tag.color}">${tag.name}</span>
                </div>
                <div class="space-y-2 min-h-[20px]">
        `;
        
        if (promptsForTag.length === 0 && !searchQ) {
            tagGroupHTML += `<div class="text-[10px] text-dim italic opacity-40 px-2">No prompts yet.</div>`;
            hasVisiblePrompts = true;
        } else {
            let localIdxCounter = 0;
            promptsForTag.forEach(p => {
                const localIdx = localIdxCounter++;
                
                // Apply DB Search Filter
                if (searchQ && !p.title.toLowerCase().includes(searchQ) && !p.id.toLowerCase().includes(searchQ) && !p.bodyText.toLowerCase().includes(searchQ)) {
                    return; 
                }
                hasVisiblePrompts = true;

                const isActive = activePromptId === p.id;
                const isEditing = editingPromptTitleId === p.id;
                const titleText = p.parentId ? `↳ ${p.title}` : p.title;

                const glowState = getPromptGlowState(p.id, allLogic);
                let extraGlowClass = "";
                if (glowState === 'purple') extraGlowClass = "shadow-[0_0_15px_rgba(168,85,247,0.3)] border-r-2 border-r-purple-500";
                else if (glowState === 'red') extraGlowClass = "shadow-[0_0_15px_rgba(239,68,68,0.3)] border-r-2 border-r-red-500";
                else if (glowState === 'blue') extraGlowClass = "shadow-[0_0_15px_rgba(59,130,246,0.3)] border-r-2 border-r-blue-500";

                if (isEditing) {
                    tagGroupHTML += `
                        <div class="p-2 bg-black border border-teal-500 flex gap-1 items-center mb-2 ${extraGlowClass}">
                            <input type="text" id="inline-edit-${p.id}" value="${p.title}" class="flex-1 text-[10px] p-1 bg-transparent border-none text-white focus:outline-none">
                            <button class="text-teal-400 font-bold px-1" onclick="savePromptTitleEdit('${p.id}', event)">✓</button>
                            <button class="text-pink-500 font-bold px-1" onclick="cancelPromptTitleEdit(event)">✕</button>
                        </div>
                    `;
                } else {
                    tagGroupHTML += `
                        <div class="prompt-item-container group mb-2" 
                             draggable="true" 
                             ondragstart="handlePromptDragStart(event, '${p.id}')">
                            <div class="p-3 bg-[#151515] border-l-[4px] cursor-pointer hover:bg-[#222] transition-colors relative ${isActive ? 'bg-black' : ''} ${extraGlowClass}"
                                 style="border-left-color: ${isActive ? tag.color : tag.color + '40'};"
                                 onclick="selectPrompt('${p.id}')"
                                 ondblclick="startPromptTitleEdit('${p.id}', event)">
                                 <div class="absolute -top-1 -right-1 text-[9px] font-black px-1.5 rounded-sm bg-black/60 opacity-50" style="color:${tag.color}">#${localIdx+1}</div>
                                <div class="flex justify-between items-start">
                                    <div class="font-bold text-[11px] uppercase tracking-tight pr-6" style="color: ${isActive ? tag.color : '#e0e0e0'}">${titleText}</div>
                                    <button class="delete-btn text-pink-500 hover:text-pink-400 text-base leading-none ml-2" 
                                            onclick="event.stopPropagation(); deletePromptWithConfirm('${p.id}')">✕</button>
                                </div>
                                <div class="text-[9px] opacity-40 mt-1 uppercase">Event(s): ${p.hasTriggers && p.triggers?.length > 0 ? p.triggers.join(', ') : 'None'}</div>
                            </div>
                        </div>
                    `;
                }
            });
        }
        tagGroupHTML += `</div></div>`;

        if (hasVisiblePrompts) {
            listHTML += tagGroupHTML;
        }
    });

    // Handle Uncategorized/Orphaned Prompts
    const orphanedPrompts = projectData.prompts.filter(p => !projectData.tags.some(t => t.name === p.tag));
    if (orphanedPrompts.length > 0) {
        let hasVisibleOrphans = false;
        let orphanHTML = `
            <div class="mt-5 mb-2 border-b border-white/10 pb-1">
                <span class="text-[10px] uppercase font-black tracking-widest text-dim">Uncategorized</span>
            </div>
            <div class="space-y-2">
        `;
        
        let localIdxCounter = 0;
        orphanedPrompts.forEach(p => {
            const localIdx = localIdxCounter++;

            // Apply DB Search Filter
            if (searchQ && !p.title.toLowerCase().includes(searchQ) && !p.id.toLowerCase().includes(searchQ) && !p.bodyText.toLowerCase().includes(searchQ)) {
                return; 
            }
            hasVisibleOrphans = true;

            const isActive = activePromptId === p.id;
            const isEditing = editingPromptTitleId === p.id;
            const titleText = p.parentId ? `↳ ${p.title}` : p.title;

            const glowState = getPromptGlowState(p.id, allLogic);
            let extraGlowClass = "";
            if (glowState === 'purple') extraGlowClass = "shadow-[0_0_15px_rgba(168,85,247,0.3)] border-r-2 border-r-purple-500";
            else if (glowState === 'red') extraGlowClass = "shadow-[0_0_15px_rgba(239,68,68,0.3)] border-r-2 border-r-red-500";
            else if (glowState === 'blue') extraGlowClass = "shadow-[0_0_15px_rgba(59,130,246,0.3)] border-r-2 border-r-blue-500";

            if (isEditing) {
                orphanHTML += `
                    <div class="p-2 bg-black border border-teal-500 flex gap-1 items-center mb-2 ${extraGlowClass}">
                        <input type="text" id="inline-edit-${p.id}" value="${p.title}" class="flex-1 text-[10px] p-1 bg-transparent border-none text-white focus:outline-none">
                        <button class="text-teal-400 font-bold px-1" onclick="savePromptTitleEdit('${p.id}', event)">✓</button>
                        <button class="text-pink-500 font-bold px-1" onclick="cancelPromptTitleEdit(event)">✕</button>
                    </div>
                `;
            } else {
                orphanHTML += `
                    <div class="prompt-item-container group mb-2" 
                         draggable="true" 
                         ondragstart="handlePromptDragStart(event, '${p.id}')">
                        <div class="p-3 bg-[#151515] border-l-[4px] cursor-pointer hover:bg-[#222] transition-colors relative ${isActive ? 'bg-black' : ''} ${extraGlowClass}"
                             style="border-left-color: ${isActive ? '#888' : '#333'};"
                             onclick="selectPrompt('${p.id}')"
                             ondblclick="startPromptTitleEdit('${p.id}', event)">
                             <div class="absolute -top-1 -right-1 text-[9px] font-black px-1.5 rounded-sm bg-black/60 opacity-50" style="color:#aaa">#${localIdx+1}</div>
                            <div class="flex justify-between items-start">
                                <div class="font-bold text-[11px] uppercase tracking-tight pr-6" style="color: ${isActive ? '#fff' : '#ccc'}">${titleText}</div>
                                <button class="delete-btn text-pink-500 hover:text-pink-400 text-base leading-none ml-2" 
                                        onclick="event.stopPropagation(); deletePromptWithConfirm('${p.id}')">✕</button>
                            </div>
                            <div class="text-[9px] opacity-40 mt-1 uppercase">Event(s): ${p.hasTriggers && p.triggers?.length > 0 ? p.triggers.join(', ') : 'None'}</div>
                        </div>
                    </div>
                `;
            }
        });
        orphanHTML += `</div>`;

        if (hasVisibleOrphans) {
            listHTML += orphanHTML;
        }
    }

    if (!listHTML && searchQ) {
        listHTML = `<div class="text-[10px] text-dim italic opacity-40 px-2 mt-4 text-center">No matching prompts found.</div>`;
    }

    list.innerHTML = listHTML;
}

function selectPrompt(id) {
    activePromptId = id;
    
    const p = projectData.prompts.find(prompt => prompt.id === id);
    if (p && projectData.tags.some(t => t.name === p.tag)) {
        activeTag = p.tag;
        lastActivePerCategory[p.tag] = id;
    }
    
    renderLists();
    renderEditor();
}

function renderEditor() {
    const editor = document.getElementById('editor-content');
    const placeholder = document.getElementById('placeholder-text');
    const navContainer = document.getElementById('editor-nav');
    const prompt = projectData.prompts.find(p => p.id === activePromptId);

    populateTagDropdown();

    // Clear any lingering number tabs before re-rendering
    const existingTab = document.getElementById('prompt-number-tab');
    if (existingTab) existingTab.remove();

    if (!prompt) {
        editor.style.display = 'none';
        placeholder.style.display = 'flex';
        return;
    }

    if (!prompt.textFormat) {
        prompt.textFormat = { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'left', alignV: 'top' };
    }
    if (!prompt.backgroundTintType) {
        prompt.backgroundTintType = "none";
        prompt.backgroundTintOpacity = 0;
    }
    if (prompt.windowPositionId === undefined) {
        prompt.windowPositionId = "";
    }

    editor.style.display = 'block';
    placeholder.style.display = 'none';

    // Document prompt ID inside the active card
    const idDisplay = document.getElementById('prompt-panel-id');
    if (idDisplay) idDisplay.innerText = prompt.id;

    // Calculate active prompt index for numbering
    const promptsInTag = projectData.prompts.filter(p => p.tag === prompt.tag);
    const localIdx = promptsInTag.findIndex(p => p.id === prompt.id);
    const totalInTag = promptsInTag.length;
    const tagObj = projectData.tags.find(t => t.name === prompt.tag) || { color: '#888' };

    // Inject the Prompt Number & Move Dropdown at the top of the card
    const card = document.getElementById('active-prompt-card');
    const numberTabHTML = `
        <div id="prompt-number-tab" class="absolute -top-7 left-[-4px] flex items-end z-10 h-[28px]">
            <div class="px-3 py-1 text-black font-black text-xs rounded-tl-md flex items-center justify-center h-[28px]" style="background-color: ${tagObj.color};">#${localIdx + 1}</div>
            <div class="bg-black border border-l-0 border-b-0 text-[10px] flex items-center px-2 py-1 h-[28px] rounded-tr-md" style="border-color: ${tagObj.color};">
                <span class="text-dim mr-2 font-bold tracking-widest">MOVE TO</span>
                <select class="bg-transparent font-bold outline-none p-0 cursor-pointer" style="color: ${tagObj.color}" onchange="movePromptOrder('${prompt.id}', this.value)">
                    ${Array.from({length: totalInTag}).map((_, i) => `<option value="${i}" ${i === localIdx ? 'selected' : ''}>#${i + 1}</option>`).join('')}
                </select>
            </div>
        </div>
    `;
    card.insertAdjacentHTML('afterbegin', numberTabHTML);

    // Navigation Headers (For Multi-Phase Branching)
    let navHTML = '';
    if (prompt.parentId) {
        const parentPrompt = projectData.prompts.find(p => p.id === prompt.parentId);
        const rootPrompt = projectData.prompts.find(p => p.id === prompt.rootId);
        
        navHTML += `<div class="flex gap-2">`;
        
        if (rootPrompt && rootPrompt.id !== parentPrompt?.id) {
            navHTML += `<button class="btn btn-outline text-[9px] text-dim border-dim hover:text-white hover:border-white transition-colors" onclick="selectPrompt('${rootPrompt.id}')">« ROOT: ${rootPrompt.title}</button>`;
        }
        
        if (parentPrompt) {
            navHTML += `<button class="btn btn-outline text-[9px] text-accent-gold border-accent-gold hover:bg-accent-gold/10 transition-colors" onclick="selectPrompt('${parentPrompt.id}')">‹ BACK TO: ${parentPrompt.title}</button>`;
        }
        
        navHTML += `</div>`;
    }
    navContainer.innerHTML = navHTML;

    // Base Setups
    const bodyInput = document.getElementById('edit-body');
    document.getElementById('edit-title').value = prompt.title || '';
    document.getElementById('edit-tag').value = prompt.tag || projectData.tags[0]?.name;
    document.getElementById('edit-priority').value = prompt.priority || 0;
    document.getElementById('edit-repeatable').checked = prompt.isRepeatable || false;
    document.getElementById('edit-isCalledExternally').checked = prompt.isCalledExternally || false;
    document.getElementById('edit-makeExternalCall').checked = prompt.makeExternalCall || false;
    
    // Window Position UI injection
    const windowPositionSelect = document.getElementById('edit-window-position');
    if (windowPositionSelect) {
        windowPositionSelect.innerHTML = getPositionOptionsHTML(prompt.windowPositionId);
    }
    
    bodyInput.value = prompt.bodyText || '';

    // Render Background Controls
    const bgContainer = document.getElementById('container-bg-controls');
    bgContainer.innerHTML = `
        <label class="section-header text-white">Background Controls</label>
        <div class="flex flex-wrap gap-x-6 gap-y-3 mb-3">
            <label class="flex items-center gap-2 cursor-pointer text-[10px] font-black uppercase text-white">
                <input type="radio" name="bgTint-${prompt.id}" value="none" ${prompt.backgroundTintType === 'none' ? 'checked' : ''} onchange="updateActivePromptBGType('none')"> No Tint
            </label>
            <label class="flex items-center gap-2 cursor-pointer text-[10px] font-black uppercase text-white">
                <input type="radio" name="bgTint-${prompt.id}" value="half" ${prompt.backgroundTintType === 'half' ? 'checked' : ''} onchange="updateActivePromptBGType('half')"> Half Tint
            </label>
            <label class="flex items-center gap-2 cursor-pointer text-[10px] font-black uppercase text-white">
                <input type="radio" name="bgTint-${prompt.id}" value="black" ${prompt.backgroundTintType === 'black' ? 'checked' : ''} onchange="updateActivePromptBGType('black')"> Black
            </label>
            <label class="flex items-center gap-2 cursor-pointer text-[10px] font-black uppercase text-white">
                <input type="radio" name="bgTint-${prompt.id}" value="custom" ${prompt.backgroundTintType === 'custom' ? 'checked' : ''} onchange="updateActivePromptBGType('custom')"> Custom
            </label>
        </div>
        <div id="bg-slider-container" class="${prompt.backgroundTintType === 'custom' ? 'block' : 'hidden'} mt-2 p-3 bg-black/30 border border-white/5">
            <div class="flex justify-between mb-1">
                <span class="text-[9px] uppercase font-bold text-dim">Opacity</span>
                <span class="text-[9px] font-mono text-white" id="bg-opacity-display">${prompt.backgroundTintOpacity.toFixed(2)}</span>
            </div>
            <input type="range" min="0" max="1" step="0.01" value="${prompt.backgroundTintOpacity}" class="w-full accent-pink-500 cursor-pointer" oninput="updateActivePromptBGOpacity(this.value)">
        </div>
    `;
    
    // Format UI Bindings
    const tf = prompt.textFormat;
    document.getElementById('fmt-bold').classList.toggle('active', tf.bold);
    document.getElementById('fmt-italic').classList.toggle('active', tf.italic);
    document.getElementById('fmt-underline').classList.toggle('active', tf.underline);
    document.getElementById('fmt-strikethrough').classList.toggle('active', tf.strikethrough);
    
    document.getElementById('fmt-list-bullet').classList.toggle('active', tf.listStyle === 'bullet');
    document.getElementById('fmt-list-number').classList.toggle('active', tf.listStyle === 'number');

    ['left', 'center', 'right', 'justified'].forEach(a => {
        document.getElementById(`fmt-alignH-${a}`).classList.toggle('active', tf.alignH === a);
    });
    ['top', 'middle', 'bottom'].forEach(a => {
        document.getElementById(`fmt-alignV-${a}`).classList.toggle('active', tf.alignV === a);
    });

    // Apply global styling to Textarea directly
    bodyInput.style.fontWeight = tf.bold ? 'bold' : 'normal';
    bodyInput.style.fontStyle = tf.italic ? 'italic' : 'normal';
    
    let decos = [];
    if (tf.underline) decos.push('underline');
    if (tf.strikethrough) decos.push('line-through');
    bodyInput.style.textDecoration = decos.length > 0 ? decos.join(' ') : 'none';
    
    bodyInput.style.textAlign = tf.alignH === 'justified' ? 'justify' : tf.alignH;
    bodyInput.style.paddingLeft = tf.listStyle !== 'none' ? '30px' : '12px';

    // Triggers Setup
    document.getElementById('edit-hasTriggers').checked = prompt.hasTriggers || false;
    toggleTriggersUI();

    // Visual Payload Setup
    document.getElementById('edit-hasVisualPayload').checked = prompt.hasVisualPayload || false;
    toggleVisualPayloadUI();
    
    // Button Setups
    document.getElementById('edit-hasButton').checked = prompt.hasButton || false;
    toggleButtonUI();

    // Render Frames & Positions Setups
    renderFramesAndPositions();

    // Window Logic Setups
    document.getElementById('winReopenDialogue').checked = prompt.winReopenDialogue || false;
    document.getElementById('winCloseDialogue').checked = prompt.winCloseDialogue || false;
    document.getElementById('winReopenMainMenu').checked = prompt.winReopenMainMenu || false;
    document.getElementById('winCloseMainMenu').checked = prompt.winCloseMainMenu || false;
    document.getElementById('winClosePromptPanel').checked = prompt.winClosePromptPanel !== false;

    // Set dynamic card border color
    if (tagObj) document.getElementById('active-prompt-card').style.borderLeftColor = tagObj.color;

    updateDynamicGlows();

    // Render Dynamic Arrays
    renderTriggers();
    renderArray('conditions');
    renderArray('gameStateChanges');

    updatePreview();
}

function updatePreview() {
    const prompt = projectData.prompts.find(p => p.id === activePromptId);
    if (!prompt) return;

    let text = prompt.bodyText || "";

    projectData.tokens.forEach(t => {
        const regex = new RegExp(`\\{\\{${t.key}\\}\\}`, 'g');
        text = text.replace(regex, `<span class="text-teal-400 font-bold">${t.value}</span>`);
    });

    const previewPane = document.getElementById('live-preview');
    if (!text.trim()) {
        previewPane.innerHTML = `<span class="opacity-30">No content...</span>`;
        return;
    }

    const tf = prompt.textFormat;

    if (tf.listStyle === 'bullet') {
        const items = text.split('\n').filter(i => i.trim() !== '').map(i => `<li>${i}</li>`).join('');
        text = `<ul style="list-style-type: disc; padding-left: 24px; margin: 0;">${items}</ul>`;
    } else if (tf.listStyle === 'number') {
        const items = text.split('\n').filter(i => i.trim() !== '').map(i => `<li>${i}</li>`).join('');
        text = `<ol style="list-style-type: decimal; padding-left: 24px; margin: 0;">${items}</ol>`;
    }

    text = text.replace(/<b>/g, '<strong>').replace(/<\/b>/g, '</strong>');
    text = text.replace(/<i>/g, '<em>').replace(/<\/i>/g, '</em>');
    text = text.replace(/<u>/g, '<u>').replace(/<\/u>/g, '</u>');
    text = text.replace(/<s>/g, '<s>').replace(/<\/s>/g, '</s>');
    text = text.replace(/<align="([^"]+)">/g, '<div style="text-align: $1;">').replace(/<\/align>/g, '</div>');

    let styleStr = '';
    styleStr += tf.bold ? 'font-weight: bold; ' : 'font-weight: normal; ';
    styleStr += tf.italic ? 'font-style: italic; ' : 'font-style: normal; ';
    
    let decos = [];
    if (tf.underline) decos.push('underline');
    if (tf.strikethrough) decos.push('line-through');
    styleStr += `text-decoration: ${decos.length > 0 ? decos.join(' ') : 'none'}; `;
    
    styleStr += `text-align: ${tf.alignH === 'justified' ? 'justify' : tf.alignH}; `;

    let flexAlign = 'flex-start';
    if (tf.alignV === 'middle') flexAlign = 'center';
    if (tf.alignV === 'bottom') flexAlign = 'flex-end';

    previewPane.innerHTML = `
        <div style="display: flex; flex-direction: column; min-height: 120px; justify-content: ${flexAlign}; width: 100%;">
            <div style="width: 100%; ${styleStr}">${text}</div>
        </div>
    `;
}

// --- IO ---
function importDialogues(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            
            const mapConfig = [
                { dKey: 'cast', pKey: 'globalCast', nameKey: 'name' },
                { dKey: 'globalStates', pKey: 'globalStates', nameKey: 'name' },
                { dKey: 'globalMoods', pKey: 'globalMoods', nameKey: 'name' },
                { dKey: 'globalSettings', pKey: 'globalSettings', nameKey: 'name' },
                { dKey: 'globalTimesOfDay', pKey: 'timesOfDay', nameKey: 'name' },
                { dKey: 'globalDaysOfWeek', pKey: 'daysOfWeek', nameKey: 'name' },
                { dKey: 'globalMenuOptions', pKey: 'menuOptions', nameKey: 'name' },
                { dKey: 'sequences', pKey: 'imageSequences', nameKey: 'title' }
            ];

            let itemsAdded = 0;

            mapConfig.forEach(config => {
                const sourceArray = data[config.dKey];
                if (sourceArray && Array.isArray(sourceArray)) {
                    sourceArray.forEach(item => {
                        let itemName = item[config.nameKey] || item.name || item.title || item.time || item.day || item.setting || item.menu || Object.values(item).find(v => typeof v === 'string') || "Unnamed";
                        let itemColor = item.color || getRandomHex();

                        if (itemName === "Unnamed" || itemName.trim() === "") return;

                        const existing = projectData[config.pKey].find(i => i.name.toLowerCase() === itemName.toLowerCase());
                        if (!existing) {
                            projectData[config.pKey].push({
                                id: crypto.randomUUID(),
                                name: itemName,
                                color: itemColor
                            });
                            itemsAdded++;
                        }
                    });
                }
            });

            renderGlobalSections();
            showNotification(`Imported ${itemsAdded} Global Items from Dialogues.`);
        } catch (err) {
            console.error(err);
            showNotification("Import Failed: Invalid Dialogue JSON");
        }
    };
    reader.readAsText(file);
    input.value = '';
}

function exportProject() {
    const now = new Date();
    const pad = num => String(num).padStart(2, '0');
    const dateStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
    const timeStr = `${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`;
    
    const activeLogicData = getProjectLogic().map(l => {
        let usage = "Unknown";
        if (l.isCondition && l.isStateChange) {
            usage = "Mixed Usage";
        } else if (l.isCondition) {
            usage = "Condition Only";
        } else if (l.isStateChange) {
            usage = "State Change Only";
        }

        return {
            key: l.key,
            operator: l.op,
            value: l.val,
            format: `${l.key} ${l.op} ${l.val}`,
            totalReferences: l.uses.length,
            usageClassification: usage
        };
    });

    // Deep clone data to avoid structurally mutating live state
    const exportObj = JSON.parse(JSON.stringify(projectData));
    
    // Inject continuous listIndex to position tags strictly for exporting
    let continuousPosIdx = 0;
    if (exportObj.positionTypes) {
        exportObj.positionTypes.forEach(pt => {
            if(pt.tags) {
                pt.tags.forEach((tag) => {
                    tag.listIndex = continuousPosIdx++;
                });
            }
        });
    }

    exportObj["Active Project Logic"] = activeLogicData;
    exportObj.exportTime = now.toISOString();
    exportObj.version = "2.9-PROMPT-REFACTOR";
    
    const blob = new Blob([JSON.stringify(exportObj, null, 2)], {type: "application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.download = `PromptDesigner_Export_${dateStr}_${timeStr}.json`;
    a.href = url;
    a.click();
    URL.revokeObjectURL(url);
    showNotification("Project Exported");
}

function importProject(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            
            if(data.prompts) {
                data.prompts.forEach(p => {
                    if(!p.conditions) p.conditions = [];
                    if(!p.gameStateChanges) p.gameStateChanges = [];
                    if (p.parentId === undefined) p.parentId = null;
                    if (p.rootId === undefined) p.rootId = null;

                    // Port backwards compatibility for Background Tint
                    if (p.backgroundTintType === undefined) {
                        if (p.backgroundTint === 'half') { p.backgroundTintType = 'half'; p.backgroundTintOpacity = 0.5; }
                        else if (p.backgroundTint === 'black') { p.backgroundTintType = 'black'; p.backgroundTintOpacity = 1; }
                        else { p.backgroundTintType = 'none'; p.backgroundTintOpacity = 0; }
                    }
                    if (p.windowPositionId === undefined) {
                        p.windowPositionId = "";
                    }
                    if (!p.frames) p.frames = [];

                    if(p.buttons === undefined) {
                        p.buttons = [];
                        if (p.hasButton || p.buttonText) {
                            p.buttons.push({
                                id: crypto.randomUUID(),
                                text: p.buttonText || "Continue",
                                stateChanges: [],
                                isBranching: false,
                                branchPromptId: null,
                                closeMenu: false,
                                isExternalLink: false,
                                externalUrl: ''
                            });
                        }
                    } else {
                        p.buttons.forEach(b => {
                            if (b.closeMenu === undefined) b.closeMenu = false;
                            if (b.isExternalLink === undefined) b.isExternalLink = false;
                            if (b.externalUrl === undefined) b.externalUrl = '';
                        });
                    }
                    
                    if(p.triggers === undefined) {
                        p.triggers = p.triggerEvent ? [p.triggerEvent] : [];
                        p.hasTriggers = p.triggers.length > 0;
                    }

                    if (p.visualPayloads === undefined) p.visualPayloads = [];
                    if(p.textFormat === undefined) {
                        p.textFormat = { bold: false, italic: false, underline: false, strikethrough: false, listStyle: 'none', alignH: 'left', alignV: 'top' };
                    }
                    if(p.winClosePromptPanel === undefined) p.winClosePromptPanel = true;
                    if(p.id === undefined) p.id = crypto.randomUUID();
                    if(p.isCalledExternally === undefined) p.isCalledExternally = false;
                    if(p.makeExternalCall === undefined) p.makeExternalCall = false;
                });
            }

            // Enforce dynamic global lists structure
            GLOBAL_SECTIONS.forEach(sec => {
                if(!data[sec.key]) data[sec.key] = [];
            });

            if (!data.positionTypes) data.positionTypes = [];

            projectData = data;
            if (projectData.tags.length > 0) activeTag = projectData.tags[0].name;
            activePromptId = projectData.prompts[0]?.id || null;
            
            populateTagDropdown();
            renderLists();
            renderLogicPanel();
            renderEditor();
            showNotification("Project Imported");
        } catch (err) {
            console.error(err);
            showNotification("Import Failed: Invalid JSON");
        }
    };
    reader.readAsText(file);
    input.value = '';
}

window.onload = () => {
    renderLists();
    renderLogicPanel();
};