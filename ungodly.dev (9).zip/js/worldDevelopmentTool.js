document.addEventListener('DOMContentLoaded', () => {
    const API_URL = 'api1.php';
    let currentWorldId = null;
    let worlds = [];
    let worldData = {};
    let allWorldsDataCache = {}; // Cache for global views

    // DOM Elements
    const worldListEl = document.getElementById('worldList');
    const contentEditorEl = document.getElementById('content-editor');
    const welcomeScreenEl = document.getElementById('welcome-screen');
    const saveBtn = document.getElementById('save-world-btn');
    const newWorldBtn = document.getElementById('new-world-btn');
    const navList = document.getElementById('navList');
    const worldTitleEl = document.getElementById('world-title');
    const newWorldModal = document.getElementById('newWorldModal');
    const createWorldBtn = document.getElementById('create-world-btn');
    const importBtn = document.getElementById('import-world-btn');
    const exportBtn = document.getElementById('export-world-btn');
    const editModal = document.getElementById('editModal');
    const editModalTitle = document.getElementById('edit-modal-title');
    const editModalBody = document.getElementById('edit-modal-body');
    const editModalSaveBtn = document.getElementById('edit-modal-save');


    // --- DATA INITIALIZATION ---
    const PREDEFINED_CHECKBOXES = {
        weather: ['Standard 4 Seasons', 'Long Summer', 'Endless Winter', 'Monsoon Season', 'Extreme Storms', 'Wild Magic Surges'],
        disasters: ['Volcanos', 'Earthquakes', 'Hurricanes', 'Tornados', 'Blizzards', 'Floods'],
        celestials: ['Single Moon', 'Multiple Moons', 'Ringed Planet', 'Regular Eclipses', 'Prophetic Comets', 'Strange Constellations']
    };

    const init = async () => {
        setupEventListeners();
        saveBtn.disabled = true;
        exportBtn.disabled = true;
        await loadWorlds();
    };

    const createCheckboxItem = (label, group, isChecked = false, id = null, controlsId = null) => {
        const div = document.createElement('div');
        div.className = 'checkbox-item';
        const inputId = id || `${group}-${label.replace(/\s+/g, '')}-checkbox`;
        const checkedAttr = isChecked ? 'checked' : '';
        const controlsAttr = controlsId ? `data-controls="${controlsId}"` : '';

        div.innerHTML = `
            <label for="${inputId}"><input type="checkbox" id="${inputId}" data-group="${group}" value="${label}" ${checkedAttr} ${controlsAttr}> ${label}</label>
            <span class="btn-delete-checkbox">×</span>`;
        return div;
    };

    // --- MODAL & NOTIFICATION SYSTEM ---
    const alertModal = document.getElementById('alertModal');
    const alertModalTitle = document.getElementById('alert-modal-title');
    const alertModalMessage = document.getElementById('alert-modal-message');
    const alertModalOk = document.getElementById('alert-modal-ok');
    const alertModalCancel = document.getElementById('alert-modal-cancel');

    const showModalMessage = (message, title = 'Notification', isConfirm = false) => {
        return new Promise((resolve) => {
            alertModalTitle.textContent = title;
            alertModalMessage.textContent = message;
            alertModalCancel.style.display = isConfirm ? 'inline-block' : 'none';
            alertModal.classList.add('active');

            const okListener = () => {
                alertModal.classList.remove('active');
                alertModalOk.removeEventListener('click', okListener);
                alertModalCancel.removeEventListener('click', cancelListener);
                resolve(true);
            };

            const cancelListener = () => {
                alertModal.classList.remove('active');
                alertModalOk.removeEventListener('click', okListener);
                alertModalCancel.removeEventListener('click', cancelListener);
                resolve(false);
            };

            alertModalOk.addEventListener('click', okListener);
            if (isConfirm) {
                alertModalCancel.addEventListener('click', cancelListener);
            }
        });
    };

    // --- API & DATA HANDLING ---
    const apiCall = async (action, method = 'GET', body = null) => {
        let url = `${API_URL}?action=${action}`;
        const options = { method, headers: { 'Content-Type': 'application/json' } };
        if (body && method !== 'GET') options.body = JSON.stringify(body);
        if (body && method === 'GET') url += `&${new URLSearchParams(body).toString()}`;
        try {
            const response = await fetch(url, options);
            const data = await response.json(); 
            
            if (!response.ok || data.success === false) {
                throw new Error(data.message || `HTTP error! status: ${response.status}`);
            }
            
            return data;
        } catch (error) {
            console.error(`API Error for '${action}':`, error);
            const errorMessage = error.message.startsWith('Server Error:') || error.message.startsWith('Uncaught Exception:') || error.message.startsWith('Database connection failed:')
                ? error.message
                : `An error occurred: ${error.message}`;
            await showModalMessage(errorMessage, 'API Error');
            return null;
        }
    };

    const loadWorlds = async () => {
        const data = await apiCall('getWorlds');
        if (data?.worlds) {
            worlds = data.worlds;
            renderWorldList();
            updateWorldDropdowns(currentWorldId); // Update dropdowns in case they are visible
        }
    };

    const selectWorld = async (worldId) => {
        if (!worldId) {
            currentWorldId = null;
            contentEditorEl.classList.add('hidden');
            welcomeScreenEl.classList.remove('hidden');
            saveBtn.disabled = true;
            exportBtn.disabled = true;
            worldTitleEl.textContent = 'World Development Tool';
            renderWorldList();
            return;
        }
        currentWorldId = worldId;
        const world = worlds.find(w => w.id === worldId);
        worldTitleEl.textContent = world ? world.name : 'Loading...';
        renderWorldList();
        contentEditorEl.classList.remove('hidden');
        welcomeScreenEl.classList.add('hidden');
        saveBtn.disabled = false;
        exportBtn.disabled = false;
        
        const data = await apiCall('getWorldData', 'GET', { id: worldId });
        if (data?.worldData) {
            worldData = data.worldData;
            allWorldsDataCache[worldId] = worldData; // Cache the data
            populateAllFields(worldData);
        } else {
            worldData = {}; 
            populateAllFields({});
        }
        updateWorldDropdowns(currentWorldId);
        switchTab('overview');
    };

    const handleSaveWorld = async (worldIdToSave = currentWorldId, dataToSave = worldData) => {
        if (!worldIdToSave) return;
        
        // This part is for saving from the main editor view
        if (worldIdToSave === currentWorldId && dataToSave === worldData) {
            const staticData = {};
            contentEditorEl.querySelectorAll('textarea[data-key]').forEach(ta => {
                staticData[ta.dataset.key] = ta.value;
            });
            dataToSave.static = staticData;

            dataToSave.environment = {
                weather: { options: [], selected: [] },
                disasters: { options: [], selected: [] },
                celestials: { options: [], selected: [] }
            };

            for (const group in dataToSave.environment) {
                const container = document.getElementById(`${group}-options`);
                if (container) {
                    container.querySelectorAll('.checkbox-item').forEach(item => {
                        const checkbox = item.querySelector('input[type="checkbox"]');
                        if (checkbox) {
                            dataToSave.environment[group].options.push(checkbox.value);
                            if (checkbox.checked) {
                                dataToSave.environment[group].selected.push(checkbox.value);
                            }
                        }
                    });
                }
            }
        }
        
        const result = await apiCall('saveWorldData', 'POST', { worldId: worldIdToSave, data: dataToSave });
        if (result?.success) {
            // Update cache
            allWorldsDataCache[worldIdToSave] = JSON.parse(JSON.stringify(dataToSave));
            if (worldIdToSave === currentWorldId) {
                    await showModalMessage('World saved successfully!');
            }
        }
    };
    
    // --- UI RENDERING & POPULATION ---
    const renderWorldList = () => {
        worldListEl.innerHTML = '';
        worlds.forEach(world => {
            const li = document.createElement('li');
            li.dataset.id = world.id;
            li.innerHTML = `<span>${world.name}</span> <button class="btn btn-delete delete-world-btn" data-id="${world.id}">X</button>`;
            li.classList.toggle('active', world.id === currentWorldId);
            worldListEl.appendChild(li);
        });
    };

    const populateAllFields = (data) => {
        // Clear all dynamic content first
        document.querySelectorAll('.dynamic-list, .gallery-grid, #gallery-container').forEach(ul => ul.innerHTML = '');
        document.querySelectorAll('textarea[data-key]').forEach(ta => ta.value = '');
        
        const envData = data.environment || {};
        ['weather', 'disasters', 'celestials'].forEach(group => {
            const container = document.getElementById(`${group}-options`);
            if (!container) return;
            container.innerHTML = '';
            const options = (envData[group] && envData[group].options && envData[group].options.length > 0)
                ? envData[group].options
                : PREDEFINED_CHECKBOXES[group];
            const selected = (envData[group] && envData[group].selected)
                ? new Set(envData[group].selected)
                : new Set();
            options.forEach(label => {
                const checkboxItem = createCheckboxItem(label, group, selected.has(label));
                container.appendChild(checkboxItem);
            });
        });
        
        if (data.static) {
            for (const key in data.static) {
                const textarea = contentEditorEl.querySelector(`textarea[data-key="${key}"]`);
                if (textarea) textarea.value = data.static[key];
            }
        }

        const listKeys = ['location', 'resource', 'faction', 'alliance', 'relic', 'magic-school', 'rune', 'bestiary', 'legendary', 'consumable', 'material', 'gallery', 'language', 'symbol', 'currency', 'route', 'weapon', 'craft', 'flora', 'quest'];
        listKeys.forEach(key => {
            const listData = getListFromKey(key, data);
            renderList(key, listData || []);
        });
    };

    const renderList = (type, items) => {
        const listKey = getListKey(type);
        const path = listKey.split('.');
        let pointer = worldData;
        for (let i = 0; i < path.length - 1; i++) {
            if (!pointer[path[i]]) pointer[path[i]] = {};
            pointer = pointer[path[i]];
        }
        pointer[path[path.length - 1]] = items;

        let container = document.getElementById(`${type}-list`);
            if (type === 'gallery') {
                    container = document.getElementById('gallery-container');
            } else if (type === 'symbol') {
                    container = document.getElementById('symbol-list');
            }

        if (!container) return;
        container.innerHTML = '';

        // Update list count
        const countEl = document.querySelector(`.list-count[data-list="${container.id}"]`);
        if (countEl) {
            countEl.textContent = `(${items.length})`;
        }

        if (type === 'gallery') {
            const categorized = items.reduce((acc, item) => {
                (acc[item.category] = acc[item.category] || []).push(item);
                return acc;
            }, {});
            for(const category in categorized){
                const section = document.createElement('div');
                section.innerHTML = `<h3 class="section-title" style="font-size: 14px; margin-top: 20px;">${category}</h3>`;
                const grid = document.createElement('div');
                grid.className = 'gallery-grid';
                categorized[category].forEach((item) => {
                    const originalIndex = items.indexOf(item);
                    const itemEl = createListItem(type, item, originalIndex);
                    grid.appendChild(itemEl);
                });
                section.appendChild(grid);
                container.appendChild(section);
            }
        } else {
            items.forEach((item, index) => {
                const el = createListItem(type, item, index);
                container.appendChild(el);
            });
        }

        if (type === 'faction') {
            updateFactionDropdowns();
        }
        if (type === 'location') {
            updateLocationDropdowns();
        }
        if(type === 'quest') {
            updateQuestDropdowns();
        }
    };
    
const createListItem = (type, item, index, isGlobal = false) => {
    const el = document.createElement(['symbol', 'gallery'].includes(type) ? 'div' : 'li');
    el.dataset.index = isGlobal ? item.originalIndex : index;
    el.dataset.type = type;
    if (isGlobal) {
        el.dataset.worldId = item.worldId;
    }

    let contentHTML = '';
    const worldName = item.worldId ? (worlds.find(w => w.id === item.worldId)?.name || 'Unknown World') : '';
    const worldInfo = (isGlobal || ['relic', 'rune', 'bestiary', 'legendary'].includes(type)) ? `<p><span class="prop-label">World:</span> ${worldName}</p>` : '';


    switch(type) {
        case 'location': contentHTML = `<strong>${item.name}</strong><p>${item.desc}</p><p><span class="prop-label">Pos:</span> (${item.x || 0}, ${item.y || 0}, ${item.z || 0})</p>`; break;
        case 'resource': contentHTML = `<strong>${item.name}</strong><p>${item.desc}</p><p><span class="prop-label">Pos:</span> (${item.x || 0}, ${item.y || 0}, ${item.z || 0})</p>`; break;
        case 'faction': contentHTML = `<strong>${item.name}</strong><p>${item.type}</p>`; break;
        case 'alliance': contentHTML = `<strong>${item.faction1_name}</strong> <span style="color: ${item.status === 'Allies' ? 'var(--green)' : item.status === 'Rivals' || item.status === 'War' ? 'var(--red)' : 'var(--text-medium)'};">${item.status}</span> <strong>${item.faction2_name}</strong>`; break;
        case 'relic': contentHTML = `<strong>${item.name}</strong>${worldInfo}<p>${item.effect}</p><p><span class="prop-label">Pos:</span> (${item.x || 0}, ${item.y || 0}, ${item.z || 0})</p>`; break;
        case 'magic-school': contentHTML = `<strong>${item.name}</strong>`; break;
        case 'rune':
            let runeSources = [];
            if (item.inWorld) runeSources.push(`In World at (${item.x || 0}, ${item.y || 0}, ${item.z || 0})`);
            if (item.questReward) runeSources.push('Quest Reward');
            if (item.craftedOnly) runeSources.push('Crafted Only');
            contentHTML = `<strong>${item.name}</strong>${worldInfo}<p>${item.desc}</p><p><span class="prop-label">Source:</span> ${runeSources.join(', ') || 'N/A'}</p>`; 
            break;
        case 'bestiary': 
            contentHTML = `<strong>${item.name}</strong>${worldInfo}
                             <p><span class="prop-label">Pos:</span> (${item.x || 0}, ${item.y || 0}, ${item.z || 0})</p>
                             <p><span class="prop-label">Habitat:</span> ${item.habitat || 'N/A'}</p>
                             <p><span class="prop-label">Abilities:</span> ${item.abilities || 'N/A'}</p>
                             <p><span class="prop-label">Lore:</span> ${item.lore || 'N/A'}</p>`; 
            break;
        case 'symbol': 
        case 'gallery':
            el.className = 'gallery-item';
            contentHTML = `<img class="item-image" src="${item.url}" onerror="this.src='https://placehold.co/200x200/1a1a1a/e0e0e0?text=Image'" alt="${item.desc}"><button class="btn btn-delete delete-list-item-btn">X</button>`;
            break;
        case 'legendary':
            let sources = [];
            if (item.inWorld) sources.push(`In World at (${item.x || 0}, ${item.y || 0}, ${item.z || 0})`);
            if (item.buyFromVendor) sources.push('Vendor');
            if (item.questReward) sources.push('Quest');
            contentHTML = `<strong>${item.name}</strong>${worldInfo}
                             <p><span class="prop-label">Stats:</span> ${item.stats || 'N/A'}</p>
                             <p><span class="prop-label">Source:</span> ${sources.join(', ') || 'N/A'}</p>
                             <p><span class="prop-label">Buy:</span> ${item.buy || 'N/A'} | <span class="prop-label">Sell:</span> ${item.sell || 'N/A'}</p>`; 
            break;
        case 'consumable': contentHTML = `<strong>${item.name}</strong><p><span class="prop-label">Effect:</span> ${item.effect || 'N/A'}</p><p><span class="prop-label">Buy:</span> ${item.buy || 'N/A'} | <span class="prop-label">Sell:</span> ${item.sell || 'N/A'}</p>`; break;
        case 'material': contentHTML = `<strong>${item.name}</strong><p><span class="prop-label">Buy:</span> ${item.buy || 'N/A'} | <span class="prop-label">Sell:</span> ${item.sell || 'N/A'}</p>`; break;
        case 'language': contentHTML = `<strong>${item.name}</strong>`; break;
        case 'currency': contentHTML = `<strong>${item.name}</strong>`; break;
        case 'route': contentHTML = `<strong>${item.location1_name}</strong> trades <em>${item.goods}</em> with <strong>${item.location2_name}</strong>`; break;
        case 'weapon': contentHTML = `<strong>${item.name}</strong><p><span class="prop-label">Stats:</span> ${item.stats || 'N/A'}</p><p><span class="prop-label">Buy:</span> ${item.buy || 'N/A'} | <span class="prop-label">Sell:</span> ${item.sell || 'N/A'}</p>`; break;
        case 'craft': contentHTML = `<strong>${item.name}</strong><p>${item.desc}</p>`; break;
        case 'flora': contentHTML = `<strong>${item.name}</strong><p>${item.desc}</p>`; break;
        case 'quest': 
            const prereqs = Array.isArray(item.prerequisites) ? item.prerequisites.join(', ') : item.prerequisites;
            const rewards = Array.isArray(item.rewards) ? item.rewards.join(', ') : item.rewards;
            contentHTML = `<strong>${item.name}</strong>
                             <p>${item.description || ''}</p>
                             <p><span class="prop-label">Location:</span> ${item.location || 'N/A'}</p>
                             <p><span class="prop-label">Giver:</span> ${item.giverCharacter || item.giverType || 'N/A'}</p>
                             <p><span class="prop-label">Prerequisites:</span> ${prereqs || 'None'}</p>
                             <p><span class="prop-label">Rewards:</span> ${rewards || 'None'}</p>`;
            break;
    }
    
    if (['symbol', 'gallery'].includes(type)) {
        el.innerHTML = contentHTML;
    } else {
        el.innerHTML = `<div class="item-content">${contentHTML}</div>
        <div class="item-actions">
            <button class="btn btn-edit edit-list-item-btn">Edit</button>
            <button class="btn btn-delete delete-list-item-btn">X</button>
        </div>`;
    }
    return el;
};

    const updateFactionDropdowns = () => {
        const factions = worldData.factions || [];
        const locations = factions.filter(f => f.type === 'City' || f.type === 'Village');
        
        const factionDropdowns = document.querySelectorAll('.faction-dropdown');
        const locationDropdowns = document.querySelectorAll('.faction-dropdown-locations');

        factionDropdowns.forEach(dd => {
            const currentVal = dd.value;
            dd.innerHTML = '<option value="">-- Select Faction --</option>';
            factions.forEach(f => dd.innerHTML += `<option value="${f.name}">${f.name} (${f.type})</option>`);
            dd.value = currentVal;
        });
        locationDropdowns.forEach(dd => {
            const currentVal = dd.value;
            dd.innerHTML = '<option value="">-- Select Location --</option>';
            locations.forEach(l => dd.innerHTML += `<option value="${l.name}">${l.name}</option>`);
            dd.value = currentVal;
        });
    };

    const updateLocationDropdowns = () => {
        const locations = getListFromKey('location', worldData) || [];
        const dropdown = document.getElementById('quest-location-input');
        const currentVal = dropdown.value;
        dropdown.innerHTML = '<option value="">-- Select Location --</option>';
        locations.forEach(loc => {
            dropdown.innerHTML += `<option value="${loc.name}">${loc.name}</option>`;
        });
        dropdown.value = currentVal;
    };

    const updateQuestDropdowns = () => {
        const quests = getListFromKey('quest', worldData) || [];
        const dropdown = document.getElementById('quest-prerequisite-input');
        const currentVal = dropdown.value;
        dropdown.innerHTML = '<option value="">-- No Prerequisite --</option>';
        quests.forEach(q => {
            dropdown.innerHTML += `<option value="${q.name}">${q.name}</option>`;
        });
        dropdown.value = currentVal;
    };

    const updateWorldDropdowns = (selectedId) => {
        document.querySelectorAll('.world-dropdown').forEach(dd => {
            const currentVal = dd.value;
            dd.innerHTML = '';
            worlds.forEach(w => {
                dd.innerHTML += `<option value="${w.id}">${w.name}</option>`;
            });
            if (selectedId && !dd.dataset.preserveValue) {
                dd.value = selectedId;
            } else {
                dd.value = currentVal;
            }
            delete dd.dataset.preserveValue;
        });
    };

    // --- EVENT LISTENERS ---
    const setupEventListeners = () => {
        document.getElementById('global-bestiary-btn').addEventListener('click', () => openGlobalView('bestiary'));
        document.getElementById('global-runes-btn').addEventListener('click', () => openGlobalView('rune'));
        document.getElementById('global-legendary-btn').addEventListener('click', () => openGlobalView('legendary'));
        document.getElementById('global-relics-btn').addEventListener('click', () => openGlobalView('relic'));
        
        document.body.addEventListener('click', e => {
            const itemEl = e.target.closest('li[data-world-id]');
            if (!itemEl) return;

            const type = itemEl.dataset.type;
            const worldId = itemEl.dataset.worldId;
            const originalIndex = itemEl.dataset.index;

            if (e.target.closest('.delete-list-item-btn')) {
                handleDeleteListItem(type, originalIndex, worldId);
            } else if (e.target.closest('.edit-list-item-btn')) {
                handleEditListItem(type, originalIndex, worldId);
            }
        });

        worldListEl.addEventListener('click', (e) => {
            const target = e.target;
            if (target.classList.contains('delete-world-btn')) {
                e.stopPropagation();
                handleDeleteWorld(target.dataset.id);
            } else {
                const li = target.closest('li');
                if (li && li.dataset.id) selectWorld(li.dataset.id);
            }
        });

        navList.addEventListener('click', (e) => {
            const li = e.target.closest('li');
            if (li?.dataset.tab) switchTab(li.dataset.tab);
        });

        document.querySelectorAll('.add-list-item-btn').forEach(btn => {
            btn.addEventListener('click', () => handleAddListItem(btn.dataset.type));
        });
        
        contentEditorEl.addEventListener('click', (e) => {
            const itemEl = e.target.closest('[data-type]:not([data-world-id])');
            if (!itemEl) return;

            const type = itemEl.dataset.type;
            const index = itemEl.dataset.index;

            if (e.target.closest('.delete-list-item-btn')) {
                    handleDeleteListItem(type, index);
            } else if (e.target.closest('.edit-list-item-btn')) {
                    handleEditListItem(type, index);
            }
        });
        
        contentEditorEl.addEventListener('change', e => {
            if (e.target.matches('input[type="checkbox"][data-controls]')) {
                const container = document.getElementById(e.target.dataset.controls);
                if (container) {
                    container.classList.toggle('hidden', !e.target.checked);
                }
            }
        });

        newWorldBtn.addEventListener('click', () => {
            document.getElementById('new-world-name-input').value = '';
            newWorldModal.classList.add('active');
        });
        createWorldBtn.addEventListener('click', handleCreateWorld);
        
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                }
            });
        });

        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', (e) => e.target.closest('.modal-overlay').classList.remove('active'));
        });

        saveBtn.addEventListener('click', () => handleSaveWorld());
        importBtn.addEventListener('click', () => document.getElementById('import-file-input').click());
        document.getElementById('import-file-input').addEventListener('change', handleFileImport);
        exportBtn.addEventListener('click', handleExportWorld);
        editModalSaveBtn.addEventListener('click', handleUpdateListItem);

        editModalBody.addEventListener('change', e => {
                if (e.target.matches('input[type="checkbox"][data-controls]')) {
                const container = editModalBody.querySelector(`#${e.target.dataset.controls}`);
                if (container) {
                    container.classList.toggle('hidden', !e.target.checked);
                }
            }
        });

        // Quest specific listeners
        document.getElementById('add-prerequisite-btn').addEventListener('click', () => {
            const select = document.getElementById('quest-prerequisite-input');
            const list = document.getElementById('quest-prerequisites-list');
            if (select.value && !Array.from(list.children).some(li => li.dataset.value === select.value)) {
                const li = document.createElement('li');
                li.dataset.value = select.value;
                li.innerHTML = `<span>${select.value}</span><button class="btn btn-delete">X</button>`;
                li.querySelector('button').onclick = () => li.remove();
                list.appendChild(li);
            }
        });

        document.getElementById('add-reward-btn').addEventListener('click', () => {
            const input = document.getElementById('quest-reward-input');
            const list = document.getElementById('quest-rewards-list');
            if (input.value.trim()) {
                const li = document.createElement('li');
                li.dataset.value = input.value.trim();
                li.innerHTML = `<span>${input.value.trim()}</span><button class="btn btn-delete">X</button>`;
                li.querySelector('button').onclick = () => li.remove();
                list.appendChild(li);
                input.value = '';
            }
        });

        document.getElementById('quest-giver-type-input').addEventListener('change', e => {
            const characterDropdown = document.getElementById('quest-giver-character-input');
            characterDropdown.innerHTML = '<option value="">-- Select Character --</option>'; // Reset
            
            const type = e.target.value; // "God", "Villager", or "Conscience"
            if (!type) return;

            const charArrayKey = type.toLowerCase() + 's'; // "gods", "villagers", or "consciences"

            if (worldData.characters && worldData.characters[charArrayKey]) {
                const characters = worldData.characters[charArrayKey];
                characters.forEach(char => {
                    const option = document.createElement('option');
                    option.value = char.name; 
                    option.textContent = char.name;
                    characterDropdown.appendChild(option);
                });
            }
        });
    };

    const getListKey = (type) => {
        const map = {
            'location': 'overview.locations', 'resource': 'overview.resources',
            'faction': 'factions', 'alliance': 'alliances', 'relic': 'relics',
            'magic-school': 'magic_schools', 'rune': 'runes', 'bestiary': 'bestiary',
            'legendary': 'items.legendary', 'consumable': 'items.consumable', 'material': 'items.material',
            'gallery': 'gallery', 'language': 'languages', 'symbol': 'symbols',
            'currency': 'economy.currency', 'route': 'economy.routes',
            'weapon': 'tech.weapons', 'craft': 'tech.crafts', 'flora': 'flora',
            'quest': 'quests'
        };
        return map[type] || type;
    };
    
    const getListFromKey = (type, dataObject) => {
        const listKey = getListKey(type);
        const path = listKey.split('.');
        let list = dataObject;
        for(const p of path) {
            if (!list) return [];
            list = list[p];
        }
        return list || [];
    };

    const handleAddListItem = async (type) => {
        let newItem = {};
        const list = getListFromKey(type, worldData) || [];
        
        const inputs = {};
        const checkboxes = {};
        document.querySelectorAll(`[id^="${type}-"]`).forEach(el => {
            const key = el.id.replace(`${type}-`, '').replace('-input', '');
            if (el.type === 'checkbox') {
                checkboxes[key] = el.checked;
            } else {
                inputs[key] = el.value;
            }
        });

        switch(type) {
            case 'location': newItem = { name: inputs.name.trim(), desc: inputs.desc.trim(), x: inputs.x, y: inputs.y, z: inputs.z }; if (!newItem.name) { await showModalMessage('Location name is required.', 'Input Error'); return; } break;
            case 'resource': newItem = { name: inputs.name.trim(), desc: inputs.desc.trim(), x: inputs.x, y: inputs.y, z: inputs.z }; if (!newItem.name) { await showModalMessage('Resource/Hazard name is required.', 'Input Error'); return; } break;
            case 'faction': newItem = { type: inputs.type, name: inputs.name.trim() }; if (!newItem.name) { await showModalMessage('Faction name is required.', 'Input Error'); return; } break;
            case 'alliance': newItem = { faction1_name: inputs.faction1, status: inputs.status, faction2_name: inputs.faction2 }; if (!newItem.faction1_name || !newItem.faction2_name) { await showModalMessage('Both factions must be selected.', 'Input Error'); return; } if (newItem.faction1_name === newItem.faction2_name) { await showModalMessage('A faction cannot have a relationship with itself.', 'Input Error'); return; } break;
            case 'relic': newItem = { name: inputs.name.trim(), effect: inputs.effect.trim(), worldId: inputs.world, x: inputs.x, y: inputs.y, z: inputs.z }; if (!newItem.name) { await showModalMessage('Relic name is required.', 'Input Error'); return; } break;
            case 'magic-school': newItem = { name: inputs.name.trim() }; if (!newItem.name) { await showModalMessage('School name is required.', 'Input Error'); return; } break;
            case 'rune': newItem = { name: inputs.name.trim(), desc: inputs.desc.trim(), worldId: inputs.world, x: inputs.x, y: inputs.y, z: inputs.z, inWorld: checkboxes.inWorld, questReward: checkboxes.questReward, craftedOnly: checkboxes.craftedOnly }; if (!newItem.name) { await showModalMessage('Rune name is required.', 'Input Error'); return; } break;
            case 'bestiary': newItem = { name: inputs.name.trim(), habitat: inputs.habitat.trim(), abilities: inputs.abilities.trim(), lore: inputs.lore.trim(), worldId: inputs.world, x: inputs.x, y: inputs.y, z: inputs.z }; if (!newItem.name) { await showModalMessage('Creature name is required.', 'Input Error'); return; } break;
            case 'legendary': newItem = { name: inputs.name.trim(), stats: inputs.stats.trim(), buy: inputs.buy, sell: inputs.sell, worldId: inputs.world, x: inputs.x, y: inputs.y, z: inputs.z, inWorld: checkboxes.inWorld, buyFromVendor: checkboxes.buyFromVendor, questReward: checkboxes.questReward }; if (!newItem.name) { await showModalMessage('Item name is required.', 'Input Error'); return; } break;
            case 'consumable': newItem = { name: inputs.name.trim(), effect: inputs.effect.trim(), buy: inputs.buy, sell: inputs.sell }; if (!newItem.name) { await showModalMessage('Item name is required.', 'Input Error'); return; } break;
            case 'material': newItem = { name: inputs.name.trim(), buy: inputs.buy, sell: inputs.sell }; if (!newItem.name) { await showModalMessage('Material name is required.', 'Input Error'); return; } break;
            case 'gallery': newItem = { category: inputs.category, url: inputs.url.trim(), desc: inputs.desc.trim() }; if (!newItem.url) { await showModalMessage('Image URL is required.', 'Input Error'); return; } break;
            case 'language': newItem = { name: inputs.name.trim() }; if (!newItem.name) { await showModalMessage('Language name is required.', 'Input Error'); return; } break;
            case 'symbol': newItem = { url: inputs.url.trim(), desc: inputs.desc.trim() }; if (!newItem.url) { await showModalMessage('Image URL is required.', 'Input Error'); return; } break;
            case 'currency': newItem = { name: inputs.name.trim() }; if (!newItem.name) { await showModalMessage('Currency name is required.', 'Input Error'); return; } break;
            case 'route': newItem = { location1_name: inputs.location1, goods: inputs.goods.trim(), location2_name: inputs.location2 }; if (!newItem.location1_name || !newItem.location2_name || !newItem.goods) { await showModalMessage('Both locations and goods are required.', 'Input Error'); return; } if (newItem.location1_name === newItem.location2_name) { await showModalMessage('A location cannot trade with itself.', 'Input Error'); return; } break;
            case 'weapon': newItem = { name: inputs.name.trim(), stats: inputs.stats.trim(), buy: inputs.buy, sell: inputs.sell }; if (!newItem.name) { await showModalMessage('Weapon name is required.', 'Input Error'); return; } break;
            case 'craft': newItem = { name: inputs.name.trim(), desc: inputs.desc.trim() }; if (!newItem.name) { await showModalMessage('Craft name is required.', 'Input Error'); return; } break;
            case 'flora': newItem = { name: inputs.name.trim(), desc: inputs.desc.trim() }; if (!newItem.name) { await showModalMessage('Name is required.', 'Input Error'); return; } break;
            case 'quest':
                newItem = {
                    name: inputs.name.trim(),
                    description: inputs.description.trim(),
                    location: inputs.location,
                    giverType: inputs['giver-type'],
                    giverCharacter: inputs['giver-character'],
                    prerequisites: Array.from(document.getElementById('quest-prerequisites-list').children).map(li => li.dataset.value),
                    rewards: Array.from(document.getElementById('quest-rewards-list').children).map(li => li.dataset.value)
                };
                if (!newItem.name) { await showModalMessage('Quest name is required.', 'Input Error'); return; }
                break;
            default: console.error("No handler for type:", type); return;
        }

        list.push(newItem);
        renderList(type, list);
        document.querySelectorAll(`[id^="${type}-"]`).forEach(el => { 
            if(el.tagName !== 'SELECT' && el.type !== 'checkbox') el.value = '';
            if(el.type === 'checkbox') el.checked = false;
        });
        // Clear quest sub-lists
        if (type === 'quest') {
            document.getElementById('quest-prerequisites-list').innerHTML = '';
            document.getElementById('quest-rewards-list').innerHTML = '';
        }
        document.querySelectorAll('[id$="-position-container"]').forEach(container => container.classList.add('hidden'));
    };
    
    const handleDeleteListItem = async (type, index, worldId) => {
        const isGlobal = !!worldId;
        const targetWorldId = isGlobal ? worldId : currentWorldId;
        const data = allWorldsDataCache[targetWorldId];
        if (!data) return;

        const list = getListFromKey(type, data);
        if(list && list[index]) {
            list.splice(index, 1);
            await handleSaveWorld(targetWorldId, data);
            if (isGlobal) {
                await openGlobalView(type);
            } else {
                renderList(type, list);
            }
        }
    };

    const handleEditListItem = async (type, index, worldId) => {
        const isGlobal = !!worldId;
        const targetWorldId = isGlobal ? worldId : currentWorldId;
        
        let data = allWorldsDataCache[targetWorldId];
        if (!data) {
            const result = await apiCall('getWorldData', 'GET', { id: targetWorldId });
            if (result?.worldData) {
                data = result.worldData;
                allWorldsDataCache[targetWorldId] = data;
            } else {
                return;
            }
        }

        const list = getListFromKey(type, data);
        const item = list[parseInt(index, 10)];
        if (!item) return;

        editModalTitle.textContent = `Edit ${type.replace('-', ' ')}`;
        editModalBody.innerHTML = '';
        editModalSaveBtn.dataset.type = type;
        editModalSaveBtn.dataset.index = index;
        if (isGlobal) {
            editModalSaveBtn.dataset.worldId = targetWorldId;
        } else {
            delete editModalSaveBtn.dataset.worldId;
        }
        
        const itemKeys = Object.keys(item);
        if (['relic', 'rune', 'bestiary', 'legendary'].includes(type) && !itemKeys.includes('worldId')) {
            itemKeys.unshift('worldId');
        }

        itemKeys.forEach(key => {
            const value = item[key];

            // --- FIX: Prevent arrays from being edited in this generic modal ---
            if (Array.isArray(value)) {
                const formGroup = document.createElement('div');
                formGroup.className = 'form-group';
                const label = document.createElement('label');
                label.textContent = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                
                const readOnlyDisplay = document.createElement('p');
                readOnlyDisplay.textContent = value.join(', ') || 'None';
                readOnlyDisplay.style.cssText = "padding: 12px; background-color: var(--bg-dark); border-radius: 5px; border: 1px solid var(--border-color); min-height: 45px;";
                
                const helpText = document.createElement('small');
                helpText.textContent = ` (This list cannot be edited here. Delete and re-add the item to change.)`;
                helpText.style.color = 'var(--text-medium)';
                
                formGroup.appendChild(label);
                label.appendChild(helpText);
                formGroup.appendChild(readOnlyDisplay);
                editModalBody.appendChild(formGroup);
                return; // Continue to next key
            }

            const formGroup = document.createElement('div');
            formGroup.className = 'form-group';
            const label = document.createElement('label');
            label.htmlFor = `edit-modal-${key}`;
            label.textContent = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            let input;
            if (key === 'worldId') {
                input = document.createElement('select');
                worlds.forEach(w => {
                    const option = document.createElement('option');
                    option.value = w.id;
                    option.textContent = w.name;
                    if (w.id === (value || targetWorldId)) option.selected = true;
                    input.appendChild(option);
                });
            } else if (key === 'type' && type === 'faction') {
                input = document.createElement('select');
                ['Nation', 'Clan', 'Guild', 'Religion', 'City', 'Village'].forEach(opt => {
                    const option = document.createElement('option'); option.value = opt; option.textContent = opt;
                    if (opt === value) option.selected = true;
                    input.appendChild(option);
                });
            } else if (key === 'status' && type === 'alliance') {
                input = document.createElement('select');
                ['Allies', 'Rivals', 'Neutral', 'War'].forEach(opt => {
                    const option = document.createElement('option'); option.value = opt; option.textContent = opt;
                    if (opt === value) option.selected = true;
                    input.appendChild(option);
                });
            } else if (typeof value === 'boolean') {
                formGroup.innerHTML = '';
                const checkboxId = `edit-modal-${key}`;
                const controlsId = key === 'inWorld' ? `edit-${type}-position-container` : null;
                const checkboxContainer = document.createElement('div');
                checkboxContainer.className = 'checkbox-item';
                if(controlsId) {
                    checkboxContainer.style.flexDirection = 'column';
                    checkboxContainer.style.alignItems = 'flex-start';
                    checkboxContainer.style.gap = '10px';
                }
                const labelElement = document.createElement('label');
                labelElement.htmlFor = checkboxId;
                labelElement.innerHTML = `<input type="checkbox" id="${checkboxId}" data-key="${key}" ${value ? 'checked' : ''} ${controlsId ? `data-controls="${controlsId}"` : ''}> ${label.textContent}`;
                checkboxContainer.appendChild(labelElement);
                if (key === 'inWorld') {
                    const posContainer = document.createElement('div');
                    posContainer.id = controlsId;
                    posContainer.className = 'coord-group';
                    if (!value) posContainer.classList.add('hidden');
                    posContainer.innerHTML = `
                        <div class="coord-input-item"><label>X</label><input type="number" data-key="x" value="${item.x || 0}"></div>
                        <div class="coord-input-item"><label>Y</label><input type="number" data-key="y" value="${item.y || 0}"></div>
                        <div class="coord-input-item"><label>Z</label><input type="number" data-key="z" value="${item.z || 0}"></div>
                    `;
                    checkboxContainer.appendChild(posContainer);
                }
                editModalBody.appendChild(checkboxContainer);
                return; 
            }
            else if (key.includes('desc') || key.includes('lore') || key.includes('habitat') || key.includes('abilities') || (typeof value === 'string' && value.length > 60)) {
                input = document.createElement('textarea');
                input.rows = 3;
                input.value = value;
            } else if (['x', 'y', 'z'].includes(key) && (type === 'legendary' || type === 'rune')) {
                return;
            } else {
                input = document.createElement('input');
                input.type = (key === 'x' || key === 'y' || key === 'z' || key.includes('buy') || key.includes('sell')) ? 'number' : 'text';
                input.value = value || (input.type === 'number' ? 0 : '');
            }
            
            input.id = `edit-modal-${key}`;
            input.dataset.key = key;
            formGroup.appendChild(label);
            formGroup.appendChild(input);
            editModalBody.appendChild(formGroup);
        });

        editModal.classList.add('active');
    };

    const handleUpdateListItem = async () => {
        const { type, index, worldId } = editModalSaveBtn.dataset;
        if (!type || index === undefined) return;

        const isGlobal = !!worldId;
        const targetWorldId = isGlobal ? worldId : currentWorldId;
        const data = allWorldsDataCache[targetWorldId];
        if (!data) return;

        const list = getListFromKey(type, data);
        const item = list[parseInt(index, 10)];
        if (!item) return;

        editModalBody.querySelectorAll('[data-key]').forEach(input => {
            const key = input.dataset.key;
            if (item.hasOwnProperty(key) || ['worldId', 'x', 'y', 'z'].includes(key)) {
                if (input.type === 'checkbox') {
                     item[key] = input.checked;
                } else {
                    item[key] = input.value;
                }
            }
        });

        await handleSaveWorld(targetWorldId, data);
        
        if (isGlobal) {
            await openGlobalView(type);
        } else {
            renderList(type, list);
        }
        editModal.classList.remove('active');
    };

    const switchTab = (tabId) => {
        navList.querySelectorAll('li').forEach(li => li.classList.toggle('active', li.dataset.tab === tabId));
        contentEditorEl.querySelectorAll('.tab-content').forEach(content => content.classList.toggle('active', content.id === `${tabId}-tab`));
    };
    
    const showSymbolModal = (symbol) => {
        document.getElementById('symbol-modal-title').textContent = symbol.desc || "Image";
        document.getElementById('symbol-modal-img').src = symbol.url;
        document.getElementById('symbol-modal-desc').textContent = symbol.desc;
        document.getElementById('symbolModal').classList.add('active');
    };
    
    // --- GLOBAL VIEW LOGIC ---
    const openGlobalView = async (type) => {
        const modalId = `global${type.charAt(0).toUpperCase() + type.slice(1)}Modal`;
        const modal = document.getElementById(modalId);
        const listEl = document.getElementById(`global-${type}-list`);
        if (!modal || !listEl) {
            console.error(`Modal or list element not found for type: ${type}`);
            return;
        }
        
        listEl.innerHTML = '<li>Loading...</li>';
        modal.classList.add('active');

        let aggregatedItems = [];
        for (const world of worlds) {
            let data = allWorldsDataCache[world.id];
            if (!data) {
                const result = await apiCall('getWorldData', 'GET', { id: world.id });
                if (result?.worldData) {
                    data = result.worldData;
                    allWorldsDataCache[world.id] = data;
                }
            }
            
            if (data) {
                const items = getListFromKey(type, data) || [];
                items.forEach((item, index) => {
                    aggregatedItems.push({
                        ...item,
                        worldId: world.id,
                        originalIndex: index
                    });
                });
            }
        }

        listEl.innerHTML = '';
        if (aggregatedItems.length === 0) {
            listEl.innerHTML = '<li>No items found across all worlds.</li>';
            return;
        }

        aggregatedItems.forEach(item => {
            const li = createListItem(type, item, null, true);
            listEl.appendChild(li);
        });
    };

    // --- Import/Export/CRUD for Worlds ---
    const handleCreateWorld = async () => {
        const name = document.getElementById('new-world-name-input').value.trim();
        if (name) {
            const result = await apiCall('createWorld', 'POST', { name });
            if (result?.newWorld) {
                await loadWorlds();
                selectWorld(result.newWorld.id);
                newWorldModal.classList.remove('active');
            }
        } else {
            await showModalMessage("World name cannot be empty.", "Input Error");
        }
    };

    const handleDeleteWorld = async (worldId) => {
        const world = worlds.find(w => w.id === worldId);
        const confirmation = await showModalMessage(`Are you sure you want to permanently delete the world "${world.name}"? This cannot be undone.`, 'Confirm Deletion', true);
        if (confirmation) {
            const result = await apiCall('deleteWorld', 'POST', { id: worldId });
            if (result?.success) {
                delete allWorldsDataCache[worldId];
                await loadWorlds();
                if (currentWorldId === worldId) {
                    selectWorld(null);
                }
            }
        }
    };
    
    const handleExportWorld = async () => {
        if (!currentWorldId) { await showModalMessage('Please select a world to export.', 'Export Error'); return; }
        const world = worlds.find(w => w.id === currentWorldId);
        
        const exportObject = {
            world: { name: world.name },
            data: worldData
        };
        
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportObject, null, 2));
        const downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", `${world.name.replace(/\s+/g, '_')}_export.json`);
        document.body.appendChild(downloadAnchorNode);
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
    };
    
    const handleFileImport = (event) => {
        const file = event.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = async (e) => {
            try {
                const imported = JSON.parse(e.target.result);
                if (!imported.world || !imported.data) { throw new Error('Invalid file format: Missing "world" or "data" keys.'); }

                // --- [MODIFICATION START] --- Normalize quest data before processing
                const quests = getListFromKey('quest', imported.data);
                if (quests && Array.isArray(quests)) {
                    quests.forEach(quest => {
                        if (quest.prerequisites && !Array.isArray(quest.prerequisites)) {
                            quest.prerequisites = [quest.prerequisites];
                        }
                        if (quest.rewards && !Array.isArray(quest.rewards)) {
                            quest.rewards = [quest.rewards];
                        }
                    });
                }
                // --- [MODIFICATION END] ---

                const importedName = imported.world.name;
                const existingWorld = worlds.find(w => w.name === importedName);

                if (existingWorld) {
                    // --- [MODIFICATION START] --- Handle overwrite for existing worlds
                    const confirmation = await showModalMessage(`A world named "${importedName}" already exists. Do you want to overwrite it with the imported data?`, 'Confirm Overwrite', true);
                    if (confirmation) {
                        // Overwrite existing world by calling save, which handles data clearing
                        await handleSaveWorld(existingWorld.id, imported.data);
                        await showModalMessage('World overwritten successfully!');
                        await selectWorld(existingWorld.id); // Reload the world to see changes
                    }
                    // If they cancel, do nothing.
                    // --- [MODIFICATION END] ---
                } else {
                    // --- Original logic for creating a new world ---
                    const confirmation = await showModalMessage(`Import the world "${imported.world.name}"? This will create a new world entry.`, 'Confirm Import', true);
                    if (confirmation) {
                        const result = await apiCall('importWorld', 'POST', { importData: imported });
                        if (result?.newWorld) {
                            await showModalMessage('World imported successfully!');
                            await loadWorlds();
                            selectWorld(result.newWorld.id);
                        }
                    }
                }
            } catch (error) {
                await showModalMessage(`Failed to import file: ${error.message}`, 'Import Error');
            } finally {
                event.target.value = ''; // Reset file input
            }
        };
        reader.readAsText(file);
    };

    init();
});