const API_URL = 'resource_list_api.php';
let appData = [];

document.addEventListener('DOMContentLoaded', () => {
    initParticles();
    fetchData();

    // Global Event Listeners
    document.getElementById('add-hub-btn').addEventListener('click', createNewHub);
    document.getElementById('refresh-btn').addEventListener('click', fetchData);
    document.getElementById('search-input').addEventListener('input', handleSearch);
});

// --- CORE DATA OPERATIONS ---

async function fetchData() {
    updateSidebar('Loading...');
    try {
        const res = await fetch(`${API_URL}?action=get_resources`);
        const text = await res.text(); // Get raw text first
        
        try {
            const data = JSON.parse(text); // Try to parse JSON
            if (data.status === 'error') {
                showNotification(data.message, 'error');
                updateSidebar('Error Loading Data');
            } else {
                appData = data;
                renderApp();
                renderSidebar();
            }
        } catch (jsonError) {
            console.error("Server returned invalid JSON:", text); // LOG THE RAW HTML ERROR
            showNotification('Server Error: Check Console for details', 'error');
            updateSidebar('Server Error');
        }
    } catch (e) {
        console.error(e);
        showNotification('Network Error', 'error');
    }
}

async function saveResource(resourceData, cardElement) {
    // 1. Collect Data from DOM (ensure we capture edits in dynamic fields)
    const collectedData = scrapeCardData(cardElement);
    
    // Merge with ID and Parent ID from original object if exists
    collectedData.id = resourceData.id;
    collectedData.parent_id = resourceData.parent_id;

    try {
        const res = await fetch(`${API_URL}?action=save`, {
            method: 'POST',
            body: JSON.stringify(collectedData)
        });
        const text = await res.text(); // Get raw text first

        try {
            const result = JSON.parse(text);
            
            if (result.status === 'success') {
                showNotification('Resource Saved Successfully');
                fetchData(); // Reload to get new IDs and clean state
            } else {
                showNotification(result.message || 'Save Failed', 'error');
                console.error("API Error:", result);
            }
        } catch (jsonError) {
            console.error("Server returned invalid JSON on Save:", text);
            showNotification('Server Crashed on Save (Check Console)', 'error');
        }
    } catch (e) {
        showNotification('Network Request Failed', 'error');
    }
}

async function deleteResource(id) {
    if(!confirm("Are you sure? This deletes the Hub and all Children.")) return;
    try {
        const res = await fetch(`${API_URL}?action=delete`, {
            method: 'POST',
            body: JSON.stringify({id: id})
        });
        const text = await res.text();
        const result = JSON.parse(text);
        
        if(result.status === 'success') {
            showNotification('Deleted');
            fetchData();
        } else {
            showNotification(result.message, 'error');
        }
    } catch (e) {
        showNotification('Delete failed', 'error');
    }
}

// --- DOM SCRAPING (The Fix for "Editable Lists") ---

function scrapeCardData(card) {
    return {
        title: card.querySelector('.input-title').value,
        contacted: card.querySelector('.input-contacted').checked,
        follow_up: card.querySelector('.input-followup').checked,
        last_follow_up_date: card.querySelector('.input-date').value,
        display_order: card.dataset.order || 0,
        // Scrape Dynamic Lists by iterating DOM elements in order
        contacts: [
            ...scrapeList(card, '.phone-list', 'phone'),
            ...scrapeList(card, '.email-list', 'email')
        ],
        websites: scrapeList(card, '.website-list', 'url'),
        notes: scrapeList(card, '.note-list', 'note')
    };
}

function scrapeList(card, selector, valueKey) {
    const rows = card.querySelectorAll(`${selector} .dynamic-row`);
    return Array.from(rows).map((row, index) => {
        const input = row.querySelector('input, textarea');
        let obj = { display_order: index };
        
        if (valueKey === 'phone' || valueKey === 'email') {
            obj.type = valueKey;
            obj.value = input.value;
        } else if (valueKey === 'url') {
            obj.url = input.value;
        } else if (valueKey === 'note') {
            obj.note = input.value;
        }
        return obj;
    });
}

// --- RENDERING ---

function renderApp() {
    const container = document.getElementById('resources-wrapper');
    container.innerHTML = '';

    appData.forEach((hub, index) => {
        container.appendChild(createHubElement(hub, index));
    });
}

function createHubElement(hub, index) {
    const div = document.createElement('div');
    div.className = 'hub-card';
    div.dataset.order = index; // Simple ordering logic
    
    // Header
    div.innerHTML = `
        <div class="hub-header">
            <div>
                <span class="hub-meta">HUB #${hub.id || 'NEW'}</span>
                <h3>${hub.title || 'Untitled Hub'}</h3>
            </div>
            <div class="actions">
                <i class="fas fa-chevron-down"></i>
            </div>
        </div>
        <div class="hub-body">
            <!-- Form Area -->
            <div class="hub-form-container"></div>
            
            <!-- Children Area -->
            <div class="child-container">
                <h4><i class="fas fa-sitemap"></i> Linked Services (Children)</h4>
                <div class="children-list"></div>
                <button class="glow-btn secondary add-child-btn" style="margin-top:10px;">
                    <i class="fas fa-plus"></i> Add Child Service
                </button>
            </div>
        </div>
    `;

    // 1. Render Main Form
    const formContainer = div.querySelector('.hub-form-container');
    formContainer.appendChild(createFormHTML(hub, 'hub'));

    // 2. Render Children
    const childList = div.querySelector('.children-list');
    (hub.children || []).forEach((child, cIndex) => {
        childList.appendChild(createChildElement(child, cIndex, hub.id));
    });

    // 3. Event Listeners
    // Toggle Accordion
    div.querySelector('.hub-header').addEventListener('click', (e) => {
        // Don't toggle if clicking buttons inside header
        if(e.target.closest('button')) return;
        div.querySelector('.hub-body').classList.toggle('open');
    });

    // Add Child Logic
    div.querySelector('.add-child-btn').addEventListener('click', () => {
        const newChild = { id: null, parent_id: hub.id, title: '', contacts: [], websites: [], notes: [] };
        childList.appendChild(createChildElement(newChild, 999, hub.id));
    });

    // Save/Delete Logic for HUB
    const saveBtn = formContainer.querySelector('.save-btn');
    const delBtn = formContainer.querySelector('.delete-btn');
    
    saveBtn.addEventListener('click', () => saveResource(hub, div));
    delBtn.addEventListener('click', () => deleteResource(hub.id));

    return div;
}

function createChildElement(child, index, parentId) {
    const div = document.createElement('div');
    div.className = 'child-card';
    div.dataset.order = index;
    
    div.innerHTML = `
        <div class="child-header">
            <h4>${child.title || 'New Child Service'}</h4>
            <div class="actions">
                <button class="icon-btn delete-child-btn"><i class="fas fa-trash"></i></button>
            </div>
        </div>
        <div class="child-form-container"></div>
    `;

    // Render Form
    const formContainer = div.querySelector('.child-form-container');
    formContainer.appendChild(createFormHTML(child, 'child'));

    // Save Logic (Child)
    const saveBtn = formContainer.querySelector('.save-btn');
    // Note: Child save scrapes the child card, not the hub card
    saveBtn.addEventListener('click', () => saveResource(child, div));

    // Delete Logic (Child)
    div.querySelector('.delete-child-btn').addEventListener('click', () => {
        if(child.id) deleteResource(child.id);
        else div.remove();
    });

    return div;
}

// --- DYNAMIC FORM GENERATION (The Core Logic) ---

function createFormHTML(data, type) {
    const container = document.createElement('div');
    
    // Basic Info
    const basics = `
        <div class="form-grid">
            <div class="full-width">
                <label>TITLE</label>
                <input type="text" class="input-title" value="${data.title || ''}" placeholder="Resource Name...">
            </div>
            <div>
                <label>LAST FOLLOW UP</label>
                <input type="date" class="input-date" value="${data.last_follow_up_date || ''}">
            </div>
            <div class="checkbox-group">
                <label><input type="checkbox" class="input-contacted" ${data.contacted ? 'checked' : ''}> Contacted</label>
                <label><input type="checkbox" class="input-followup" ${data.follow_up ? 'checked' : ''}> Needs Follow Up</label>
            </div>
        </div>
    `;
    container.innerHTML = basics;

    // Dynamic Sections Helper
    const createSection = (title, listClass, inputClass, btnText, inputType = 'text', key) => {
        const section = document.createElement('div');
        section.className = 'dynamic-section';
        section.innerHTML = `
            <h4>${title}</h4>
            <div class="${listClass} dynamic-list"></div>
            <div class="add-new-row">
                ${inputType === 'textarea' 
                    ? `<textarea class="${inputClass}" placeholder="New note content..."></textarea>` 
                    : `<input type="text" class="${inputClass}" placeholder="Enter value...">`
                }
                <button class="glow-btn primary add-btn">${btnText}</button>
            </div>
        `;

        // Load existing items
        const list = section.querySelector('.dynamic-list');
        const items = data[key] || []; // e.g. data.contacts or data.websites
        
        // Filter contacts by type if needed
        let filteredItems = items;
        if(key === 'contacts' && title.includes('PHONE')) filteredItems = items.filter(i => i.type === 'phone');
        if(key === 'contacts' && title.includes('EMAIL')) filteredItems = items.filter(i => i.type === 'email');

        filteredItems.forEach(item => {
            const val = item.value || item.url || item.note;
            list.appendChild(createDynamicRow(val, inputType));
        });

        // Add Button Listener (THE FIX)
        const addBtn = section.querySelector('.add-btn');
        const input = section.querySelector(`.${inputClass}`);
        
        addBtn.addEventListener('click', () => {
            if(!input.value.trim()) return;
            // 1. Create Row
            const row = createDynamicRow(input.value, inputType);
            // 2. Append to List
            list.appendChild(row);
            // 3. Clear Input
            input.value = '';
            input.focus();
        });

        return section;
    };

    container.appendChild(createSection('PHONE NUMBERS', 'phone-list', 'new-phone', 'Add Phone', 'text', 'contacts'));
    container.appendChild(createSection('EMAIL ADDRESSES', 'email-list', 'new-email', 'Add Email', 'text', 'contacts'));
    container.appendChild(createSection('WEBSITES', 'website-list', 'new-website', 'Add URL', 'text', 'websites'));
    container.appendChild(createSection('NOTES', 'note-list', 'new-note', 'Add Note', 'textarea', 'notes'));

    // Action Buttons
    const actions = document.createElement('div');
    actions.style.marginTop = '1rem';
    actions.innerHTML = `
        <button class="glow-btn primary save-btn"><i class="fas fa-save"></i> SAVE ${type.toUpperCase()}</button>
        ${type === 'hub' ? `<button class="glow-btn danger delete-btn" style="float:right"><i class="fas fa-trash"></i> DELETE HUB</button>` : ''}
    `;
    container.appendChild(actions);

    return container;
}

function createDynamicRow(value, type) {
    const row = document.createElement('div');
    row.className = 'dynamic-row';
    
    // Input/Textarea
    const inputHtml = type === 'textarea' 
        ? `<textarea>${value}</textarea>` 
        : `<input type="text" value="${value}">`;

    row.innerHTML = `
        ${inputHtml}
        <div class="row-actions">
            <button class="icon-btn up-btn"><i class="fas fa-arrow-up"></i></button>
            <button class="icon-btn down-btn"><i class="fas fa-arrow-down"></i></button>
            <button class="icon-btn del-btn" style="color:var(--danger)"><i class="fas fa-times"></i></button>
        </div>
    `;

    // Row Logic (Immediate attach)
    row.querySelector('.del-btn').addEventListener('click', () => row.remove());
    
    row.querySelector('.up-btn').addEventListener('click', () => {
        if(row.previousElementSibling) row.parentNode.insertBefore(row, row.previousElementSibling);
    });
    
    row.querySelector('.down-btn').addEventListener('click', () => {
        if(row.nextElementSibling) row.parentNode.insertBefore(row.nextElementSibling, row);
    });

    return row;
}

// --- SIDEBAR & SEARCH ---

function renderSidebar() {
    const list = document.getElementById('sidebar-list');
    list.innerHTML = '';

    const createMetaHtml = (item) => {
        let metaHtml = '';
        
        // 1. Get First Phone Number
        const phone = (item.contacts || []).find(c => c.type === 'phone');
        if (phone) {
            metaHtml += `<div class="sb-phone"><i class="fas fa-phone-alt"></i> ${phone.value}</div>`;
        }

        // 2. Get First Website
        const website = (item.websites || [])[0];
        if (website) {
            // Check protocol for display link to be safer
            let displayUrl = website.url;
            try {
                // Try to make a pretty URL (e.g. google.com instead of https://google.com)
                displayUrl = new URL(website.url).hostname; 
            } catch(e) { /* ignore invalid urls */ }
            
            metaHtml += `<a href="${website.url}" target="_blank" class="sb-link"><i class="fas fa-external-link-alt"></i> ${displayUrl}</a>`;
        }

        return metaHtml ? `<div class="sb-meta">${metaHtml}</div>` : '';
    };

    const attachClickListener = (element, hubIndex) => {
        element.addEventListener('click', (e) => {
            // If they clicked the website link, let it bubble (or handle naturally), don't scroll
            if(e.target.closest('.sb-link')) {
                e.stopPropagation();
                return; 
            }

            // Scroll to Resource
            const el = document.querySelector(`.hub-card[data-order="${hubIndex}"]`);
            if(el) {
                el.scrollIntoView({behavior: 'smooth'});
                el.querySelector('.hub-body').classList.add('open');
            }
        });
    };

    appData.forEach((hub, index) => {
        const li = document.createElement('li');
        li.className = 'sb-item';
        
        li.innerHTML = `
            <div class="sb-title"><strong>${hub.title || 'Untitled'}</strong></div>
            ${createMetaHtml(hub)}
        `;
        
        attachClickListener(li, index);
        list.appendChild(li);

        // Children in Sidebar
        (hub.children || []).forEach(child => {
            const childLi = document.createElement('li');
            childLi.className = 'sb-item child';
            
            childLi.innerHTML = `
                <div class="sb-title">↳ ${child.title || 'Untitled Child'}</div>
                ${createMetaHtml(child)}
            `;
            
            attachClickListener(childLi, index); // Scroll to parent Hub
            list.appendChild(childLi);
        });
    });
}

function updateSidebar(msg) {
    document.getElementById('sidebar-list').innerHTML = `<li class="loading-text">${msg}</li>`;
}

function handleSearch(e) {
    const term = e.target.value.toLowerCase();
    const cards = document.querySelectorAll('.hub-card');
    
    cards.forEach(card => {
        const text = card.innerText.toLowerCase();
        if(text.includes(term)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

// --- UTILS ---

function createNewHub() {
    const newHub = { id: null, parent_id: null, title: 'New Major Hub', contacts: [], websites: [], notes: [], children: [] };
    appData.push(newHub);
    renderApp();
    // Scroll to bottom
    const wrapper = document.getElementById('resources-wrapper');
    wrapper.lastChild.scrollIntoView({behavior: 'smooth'});
    wrapper.lastChild.querySelector('.hub-body').classList.add('open');
}

function showNotification(msg, type = 'success') {
    const notif = document.getElementById('notification-area');
    notif.textContent = msg;
    notif.className = type;
    notif.style.opacity = 1;
    notif.style.bottom = '20px';
    
    // Simple inline styles for notification since it wasn't in main CSS
    notif.style.position = 'fixed';
    notif.style.right = '20px';
    notif.style.padding = '15px 25px';
    notif.style.background = type === 'success' ? 'var(--neon-cyan)' : 'var(--danger)';
    notif.style.color = type === 'success' ? '#000' : '#fff';
    notif.style.borderRadius = '5px';
    notif.style.zIndex = '1000';
    notif.style.fontFamily = 'var(--font-tech)';
    notif.style.transition = '0.5s';

    setTimeout(() => {
        notif.style.opacity = 0;
        notif.style.bottom = '-100px';
    }, 3000);
}

// --- PARTICLES ---
function initParticles() {
    const canvas = document.getElementById('particle-canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    let particles = [];
    for(let i=0; i<50; i++) particles.push({
        x: Math.random()*canvas.width, 
        y: Math.random()*canvas.height, 
        vx: (Math.random()-0.5), 
        vy: (Math.random()-0.5)
    });

    function animate() {
        ctx.clearRect(0,0,canvas.width,canvas.height);
        ctx.fillStyle = '#00ffc4';
        particles.forEach(p => {
            p.x += p.vx; p.y += p.vy;
            if(p.x < 0 || p.x > canvas.width) p.vx *= -1;
            if(p.y < 0 || p.y > canvas.height) p.vy *= -1;
            ctx.beginPath();
            ctx.arc(p.x, p.y, 1, 0, Math.PI*2);
            ctx.fill();
        });
        requestAnimationFrame(animate);
    }
    animate();
}