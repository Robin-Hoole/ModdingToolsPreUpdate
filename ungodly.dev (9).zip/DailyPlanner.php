<?php
declare(strict_types=1);

$sharedAuthPath = __DIR__ . '/_private/AuthShared.php';
if (is_file($sharedAuthPath)) {
    require_once $sharedAuthPath;
    fsgAuth_startSharedSession();
} else {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function respondJson(array $payload, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function requireCredentials(): array
{
    if (function_exists('fsgAuth_requireCredentials')) {
        return fsgAuth_requireCredentials();
    }

    $credentialsPath = __DIR__ . '/_private/databaseCredentials.php';
    if (!is_file($credentialsPath)) {
        respondJson(['ok' => false, 'error' => 'Missing _private/databaseCredentials.php'], 500);
    }

    require $credentialsPath;

    foreach (['dbHost', 'dbUser', 'dbPass', 'dbName'] as $varName) {
        if (!isset(${$varName})) {
            respondJson(['ok' => false, 'error' => "Missing database credential variable: {$varName}"], 500);
        }
    }

    return [$dbHost, $dbUser, $dbPass, $dbName];
}

function dbConnection(): PDO
{
    if (function_exists('fsgAuth_dbConnection')) {
        return fsgAuth_dbConnection();
    }

    [$dbHost, $dbUser, $dbPass, $dbName] = requireCredentials();
    $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
    return new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function textValue(mixed $value): string
{
    if (function_exists('fsgAuth_textValue')) return fsgAuth_textValue($value);
    if ($value === null) return '';
    if (is_bool($value)) return $value ? '1' : '0';
    if (is_scalar($value)) return (string)$value;
    return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '';
}

function jsonText(mixed $value): string
{
    return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: 'null';
}

function arr(mixed $value): array
{
    return is_array($value) ? $value : [];
}

function tableExists(PDO $pdo, string $tableName): bool
{
    try {
        $stmt = $pdo->query('SHOW TABLES LIKE ' . $pdo->quote($tableName));
        return $stmt && $stmt->rowCount() > 0;
    } catch (Throwable $e) {
        return false;
    }
}

function columnExists(PDO $pdo, string $tableName, string $columnName): bool
{
    if (!tableExists($pdo, $tableName)) return false;
    try {
        $stmt = $pdo->query('SHOW COLUMNS FROM ' . $tableName . ' LIKE ' . $pdo->quote($columnName));
        return $stmt && $stmt->rowCount() > 0;
    } catch (Throwable $e) {
        return false;
    }
}

function requestBody(): array
{
    if (function_exists('fsgAuth_requestBody')) {
        return fsgAuth_requestBody();
    }

    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') return [];

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) respondJson(['ok' => false, 'error' => 'Invalid JSON body.'], 400);
    return $decoded;
}

function uuidv4(): string
{
    $data = random_bytes(16);
    $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
    $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

function sharedFsgUserIdSqlType(PDO $pdo): string
{
    if (function_exists('fsgAuth_sharedFsgUserIdSqlType')) {
        return fsgAuth_sharedFsgUserIdSqlType($pdo);
    }

    $stmt = $pdo->query("SHOW COLUMNS FROM FSG_users LIKE 'id'");
    $column = $stmt ? $stmt->fetch() : null;
    $type = strtolower((string)($column['Type'] ?? 'int'));
    $isUnsigned = strpos($type, 'unsigned') !== false;
    if (strpos($type, 'bigint') !== false) return $isUnsigned ? 'BIGINT UNSIGNED' : 'BIGINT';
    return $isUnsigned ? 'INT UNSIGNED' : 'INT';
}

function ensureDailyPlannerTables(PDO $pdo): void
{
    if (function_exists('fsgAuth_ensureAccountTables')) {
        try { fsgAuth_ensureAccountTables($pdo); } catch (Throwable $e) {}
    } else {
        $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_users (
            id INT NOT NULL AUTO_INCREMENT,
            username VARCHAR(64) NOT NULL,
            email VARCHAR(255) NOT NULL,
            password VARCHAR(255) NOT NULL,
            is_over_18 TINYINT(1) NOT NULL DEFAULT 0,
            agreed_terms TINYINT(1) NOT NULL DEFAULT 0,
            agreed_privacy TINYINT(1) NOT NULL DEFAULT 0,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_FSG_users_active_username (is_active, username),
            KEY idx_FSG_users_active_email (is_active, email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    $sharedUserIdSqlType = sharedFsgUserIdSqlType($pdo);

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DP_Workspaces (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_uuid CHAR(36) NOT NULL,
        session_id VARCHAR(96) NOT NULL,
        user_id {$sharedUserIdSqlType} NULL DEFAULT NULL,
        version VARCHAR(32) NOT NULL DEFAULT '',
        config_json LONGTEXT NULL,
        lists_json LONGTEXT NULL,
        schedule_json LONGTEXT NULL,
        raw_json LONGTEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_DP_Workspaces_uuid (workspace_uuid),
        KEY idx_FSG_DP_Workspaces_session_created (session_id, created_at),
        KEY idx_FSG_DP_Workspaces_user_session (user_id, session_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DP_UserSessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$sharedUserIdSqlType} NOT NULL,
        session_id VARCHAR(96) NOT NULL,
        first_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_viewed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        workspace_count INT UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_DP_UserSessions_session (session_id),
        KEY idx_FSG_DP_UserSessions_user_viewed (user_id, last_viewed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DP_RawJsonSnapshots (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        snapshot_label VARCHAR(96) NOT NULL DEFAULT '',
        raw_json LONGTEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_FSG_DP_RawJsonSnapshots_workspace (workspace_id),
        CONSTRAINT fk_FSG_DP_RawJsonSnapshots_workspace FOREIGN KEY (workspace_id) REFERENCES FSG_DP_Workspaces(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DP_Config (
        workspace_id BIGINT UNSIGNED NOT NULL,
        hours INT UNSIGNED NOT NULL DEFAULT 24,
        days INT UNSIGNED NOT NULL DEFAULT 7,
        weeks INT UNSIGNED NOT NULL DEFAULT 1,
        raw_json LONGTEXT NULL,
        PRIMARY KEY (workspace_id),
        CONSTRAINT fk_FSG_DP_Config_workspace FOREIGN KEY (workspace_id) REFERENCES FSG_DP_Workspaces(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DP_SpecialEvents (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        sort_order INT UNSIGNED NOT NULL DEFAULT 0,
        event_uuid VARCHAR(96) NOT NULL DEFAULT '',
        event_name VARCHAR(255) NOT NULL DEFAULT '',
        color VARCHAR(32) NOT NULL DEFAULT '',
        raw_json LONGTEXT NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_DP_SpecialEvents_workspace_order (workspace_id, sort_order),
        KEY idx_FSG_DP_SpecialEvents_event_uuid (event_uuid),
        CONSTRAINT fk_FSG_DP_SpecialEvents_workspace FOREIGN KEY (workspace_id) REFERENCES FSG_DP_Workspaces(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DP_ScheduleCells (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        entity_id VARCHAR(96) NOT NULL DEFAULT '',
        entity_type ENUM('cast','event','unknown') NOT NULL DEFAULT 'unknown',
        week_number INT UNSIGNED NOT NULL DEFAULT 1,
        day_index INT UNSIGNED NOT NULL DEFAULT 0,
        time_index INT UNSIGNED NOT NULL DEFAULT 0,
        default_setting_id VARCHAR(96) NOT NULL DEFAULT '',
        raw_json LONGTEXT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_DP_ScheduleCells_slot (workspace_id, entity_id, week_number, day_index, time_index),
        KEY idx_FSG_DP_ScheduleCells_workspace (workspace_id),
        KEY idx_FSG_DP_ScheduleCells_default_setting (default_setting_id),
        CONSTRAINT fk_FSG_DP_ScheduleCells_workspace FOREIGN KEY (workspace_id) REFERENCES FSG_DP_Workspaces(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DP_ScheduleAlternates (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        cell_id BIGINT UNSIGNED NOT NULL,
        sort_order INT UNSIGNED NOT NULL DEFAULT 0,
        setting_id VARCHAR(96) NOT NULL DEFAULT '',
        raw_json LONGTEXT NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_DP_ScheduleAlternates_cell_order (cell_id, sort_order),
        KEY idx_FSG_DP_ScheduleAlternates_setting (setting_id),
        CONSTRAINT fk_FSG_DP_ScheduleAlternates_cell FOREIGN KEY (cell_id) REFERENCES FSG_DP_ScheduleCells(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DP_ScheduleConditions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        alternate_id BIGINT UNSIGNED NOT NULL,
        sort_order INT UNSIGNED NOT NULL DEFAULT 0,
        condition_key VARCHAR(255) NOT NULL DEFAULT '',
        operator VARCHAR(16) NOT NULL DEFAULT '==',
        condition_value VARCHAR(255) NOT NULL DEFAULT '',
        raw_json LONGTEXT NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_DP_ScheduleConditions_alternate_order (alternate_id, sort_order),
        KEY idx_FSG_DP_ScheduleConditions_key_value (condition_key, condition_value),
        CONSTRAINT fk_FSG_DP_ScheduleConditions_alternate FOREIGN KEY (alternate_id) REFERENCES FSG_DP_ScheduleAlternates(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function currentUserId(?PDO $pdo = null): int
{
    if (isset($_SESSION['fsg_user_id'])) return (int)$_SESSION['fsg_user_id'];
    if (isset($_SESSION['dp_user_id'])) return (int)$_SESSION['dp_user_id'];
    if (isset($_SESSION['user_id'])) return (int)$_SESSION['user_id'];
    if ($pdo && function_exists('fsgAuth_currentUserIdFromRequest')) {
        try { return (int)fsgAuth_currentUserIdFromRequest($pdo); }
        catch (Throwable $e) { return 0; }
    }
    return 0;
}

function getUserById(PDO $pdo, int $userId): ?array
{
    if ($userId <= 0) return null;
    if (function_exists('fsgAuth_getUserById')) {
        try { return fsgAuth_getUserById($pdo, $userId); } catch (Throwable $e) {}
    }
    $stmt = $pdo->prepare('SELECT id, username, email, created_at FROM FSG_users WHERE id = ? AND is_active = 1 LIMIT 1');
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function listDailyPlannerUserSessions(PDO $pdo, int $userId): array
{
    if ($userId <= 0) return [];

    $sessionsById = [];
    $addSession = static function(array $row, string $appKey = 'DailyPlanner') use (&$sessionsById): void {
        $sid = trim((string)($row['session_id'] ?? $row['sessionId'] ?? ''));
        if ($sid === '') return;
        $existing = $sessionsById[$sid] ?? null;
        $next = ['app_key' => $appKey] + $row;
        if (!$existing) {
            $sessionsById[$sid] = $next;
            return;
        }
        $existingTime = strtotime((string)($existing['last_viewed_at'] ?? $existing['last_pushed_at'] ?? $existing['first_pushed_at'] ?? '')) ?: 0;
        $nextTime = strtotime((string)($next['last_viewed_at'] ?? $next['last_pushed_at'] ?? $next['first_pushed_at'] ?? '')) ?: 0;
        if ($nextTime >= $existingTime) {
            $next['app_key'] = trim((string)($existing['app_key'] ?? '')) !== '' && $existing['app_key'] !== $appKey
                ? $existing['app_key'] . '+' . $appKey
                : $appKey;
            $sessionsById[$sid] = $next;
        }
    };

    foreach (['DailyPlanner', 'DialogueDesigner'] as $appKey) {
        try {
            if (function_exists('fsgAuth_listUserSessions')) {
                foreach (fsgAuth_listUserSessions($pdo, $userId, $appKey) as $row) $addSession($row, $appKey);
            }
        } catch (Throwable $e) {}
    }

    try {
        $stmt = $pdo->prepare('SELECT session_id, first_pushed_at, last_pushed_at, last_viewed_at, workspace_count FROM FSG_DP_UserSessions WHERE user_id = ? ORDER BY last_viewed_at DESC, last_pushed_at DESC, id DESC');
        $stmt->execute([$userId]);
        foreach ($stmt->fetchAll() as $row) $addSession($row, 'DailyPlanner');
    } catch (Throwable $e) {}

    try {
        $stmt = $pdo->prepare("SELECT session_id, MIN(created_at) AS first_pushed_at, MAX(updated_at) AS last_pushed_at, MAX(updated_at) AS last_viewed_at, COUNT(*) AS workspace_count FROM FSG_DP_Workspaces WHERE user_id = ? AND session_id <> '' GROUP BY session_id ORDER BY last_viewed_at DESC");
        $stmt->execute([$userId]);
        foreach ($stmt->fetchAll() as $row) $addSession($row, 'DailyPlanner');
    } catch (Throwable $e) {}

    if (tableExists($pdo, 'FSG_DD_UserSessions')) {
        try {
            $stmt = $pdo->prepare('SELECT session_id, first_pushed_at, last_pushed_at, last_viewed_at, workspace_count FROM FSG_DD_UserSessions WHERE user_id = ? ORDER BY last_viewed_at DESC, last_pushed_at DESC, id DESC');
            $stmt->execute([$userId]);
            foreach ($stmt->fetchAll() as $row) $addSession($row, 'DialogueDesigner');
        } catch (Throwable $e) {}
    }

    if (tableExists($pdo, 'FSG_DD_Workspaces')) {
        try {
            $stmt = $pdo->prepare("SELECT session_id, MIN(created_at) AS first_pushed_at, MAX(created_at) AS last_pushed_at, MAX(updated_at) AS last_viewed_at, COUNT(*) AS workspace_count FROM FSG_DD_Workspaces WHERE user_id = ? AND session_id <> '' GROUP BY session_id ORDER BY last_viewed_at DESC");
            $stmt->execute([$userId]);
            foreach ($stmt->fetchAll() as $row) $addSession($row, 'DialogueDesigner');
        } catch (Throwable $e) {}
    }

    $sessions = array_values($sessionsById);
    usort($sessions, function($a, $b) {
        $aTime = strtotime((string)($a['last_viewed_at'] ?? $a['last_pushed_at'] ?? $a['first_pushed_at'] ?? '')) ?: 0;
        $bTime = strtotime((string)($b['last_viewed_at'] ?? $b['last_pushed_at'] ?? $b['first_pushed_at'] ?? '')) ?: 0;
        return $bTime <=> $aTime;
    });
    return $sessions;
}

function authPayload(PDO $pdo): array
{
    $userId = currentUserId($pdo);
    $user = getUserById($pdo, $userId);
    if (!$user) {
        if (function_exists('fsgAuth_clearCurrentUserSession')) {
            try { fsgAuth_clearCurrentUserSession(); } catch (Throwable $e) {}
        }
        return ['loggedIn' => false, 'user' => null, 'sessions' => [], 'authExpiresAt' => ''];
    }

    if (function_exists('fsgAuth_setCurrentUserSession')) {
        try { fsgAuth_setCurrentUserSession((int)$user['id'], (string)$user['username']); } catch (Throwable $e) {}
    }

    return [
        'loggedIn' => true,
        'user' => [
            'id' => (int)$user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'createdAt' => $user['created_at'] ?? '',
        ],
        'sessions' => listDailyPlannerUserSessions($pdo, (int)$user['id']),
        'authExpiresAt' => function_exists('fsgAuth_tokenLifetimeSeconds') ? gmdate('c', time() + fsgAuth_tokenLifetimeSeconds()) : '',
    ];
}

function withPlannerSessions(PDO $pdo, array $payload): array
{
    if (($payload['loggedIn'] ?? false) && isset($payload['user']['id'])) {
        $payload['sessions'] = listDailyPlannerUserSessions($pdo, (int)$payload['user']['id']);
    }
    return $payload;
}

function touchUserSessionViewed(PDO $pdo, string $sessionId): void
{
    $userId = currentUserId($pdo);
    if ($userId <= 0 || trim($sessionId) === '') return;

    $stmt = $pdo->prepare('INSERT INTO FSG_DP_UserSessions (user_id, session_id, last_viewed_at, workspace_count)
        VALUES (?, ?, CURRENT_TIMESTAMP, 0)
        ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), last_viewed_at = CURRENT_TIMESTAMP');
    $stmt->execute([$userId, $sessionId]);

    if (function_exists('fsgAuth_touchServerSession')) {
        try { fsgAuth_touchServerSession($pdo, $userId, 'DailyPlanner', $sessionId, 'view'); } catch (Throwable $e) {}
    }
}

function attachWorkspaceToUserSession(PDO $pdo, string $sessionId, int $userId): void
{
    if ($userId <= 0 || trim($sessionId) === '') return;

    $stmt = $pdo->prepare('INSERT INTO FSG_DP_UserSessions (user_id, session_id, first_pushed_at, last_pushed_at, last_viewed_at, workspace_count)
        VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1)
        ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), last_pushed_at = CURRENT_TIMESTAMP, last_viewed_at = CURRENT_TIMESTAMP, workspace_count = workspace_count + 1');
    $stmt->execute([$userId, $sessionId]);

    if (function_exists('fsgAuth_touchServerSession')) {
        try { fsgAuth_touchServerSession($pdo, $userId, 'DailyPlanner', $sessionId, 'push'); } catch (Throwable $e) {}
    }
}

function generateUniqueSessionId(PDO $pdo): string
{
    if (function_exists('fsgAuth_generateUniqueSessionId')) {
        try { return fsgAuth_generateUniqueSessionId($pdo); } catch (Throwable $e) {}
    }

    do {
        $candidate = 'DP-' . strtoupper(substr(str_replace('-', '', uuidv4()), 0, 7)) . '-' . strtoupper(substr(str_replace('-', '', uuidv4()), 0, 12));
        $stmt = $pdo->prepare('SELECT id FROM FSG_DP_Workspaces WHERE session_id = ? LIMIT 1');
        $stmt->execute([$candidate]);
    } while ($stmt->fetch());

    return $candidate;
}

function inferScheduleEntityType(array $data, string $entityId): string
{
    foreach (arr($data['lists']['events'] ?? []) as $event) {
        if (is_array($event) && textValue($event['id'] ?? '') === $entityId) return 'event';
    }
    foreach (arr($data['lists']['chars'] ?? []) as $castEntry) {
        if (is_array($castEntry) && textValue($castEntry['id'] ?? '') === $entityId) return 'cast';
    }
    return 'unknown';
}

function insertDailyPlannerNormalizedData(PDO $pdo, int $workspacePk, array $data): void
{
    $config = arr($data['config'] ?? []);
    $configStmt = $pdo->prepare('INSERT INTO FSG_DP_Config (workspace_id, hours, days, weeks, raw_json) VALUES (?, ?, ?, ?, ?)');
    $configStmt->execute([
        $workspacePk,
        max(1, (int)($config['hours'] ?? 24)),
        max(1, (int)($config['days'] ?? 7)),
        max(1, (int)($config['weeks'] ?? 1)),
        jsonText($config),
    ]);

    $eventStmt = $pdo->prepare('INSERT INTO FSG_DP_SpecialEvents (workspace_id, sort_order, event_uuid, event_name, color, raw_json) VALUES (?, ?, ?, ?, ?, ?)');
    foreach (array_values(arr($data['lists']['events'] ?? [])) as $eventIndex => $event) {
        $eventData = is_array($event) ? $event : ['name' => textValue($event)];
        $eventStmt->execute([
            $workspacePk,
            $eventIndex,
            textValue($eventData['id'] ?? ''),
            textValue($eventData['name'] ?? ''),
            textValue($eventData['color'] ?? ''),
            jsonText($eventData),
        ]);
    }

    $cellStmt = $pdo->prepare('INSERT INTO FSG_DP_ScheduleCells (workspace_id, entity_id, entity_type, week_number, day_index, time_index, default_setting_id, raw_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $alternateStmt = $pdo->prepare('INSERT INTO FSG_DP_ScheduleAlternates (cell_id, sort_order, setting_id, raw_json) VALUES (?, ?, ?, ?)');
    $conditionStmt = $pdo->prepare('INSERT INTO FSG_DP_ScheduleConditions (alternate_id, sort_order, condition_key, operator, condition_value, raw_json) VALUES (?, ?, ?, ?, ?, ?)');

    foreach (arr($data['schedule'] ?? []) as $entityId => $weeks) {
        $entityId = textValue($entityId);
        $entityType = inferScheduleEntityType($data, $entityId);
        foreach (arr($weeks) as $weekNumber => $days) {
            foreach (arr($days) as $dayIndex => $times) {
                foreach (arr($times) as $timeIndex => $cell) {
                    $cellData = is_array($cell) ? $cell : [];
                    $cellStmt->execute([
                        $workspacePk,
                        $entityId,
                        $entityType,
                        max(1, (int)$weekNumber),
                        max(0, (int)$dayIndex),
                        max(0, (int)$timeIndex),
                        textValue($cellData['defaultLocId'] ?? $cellData['defaultSettingId'] ?? ''),
                        jsonText($cellData),
                    ]);
                    $cellPk = (int)$pdo->lastInsertId();
                    foreach (array_values(arr($cellData['alternates'] ?? [])) as $alternateIndex => $alternate) {
                        $alternateData = is_array($alternate) ? $alternate : [];
                        $alternateStmt->execute([
                            $cellPk,
                            $alternateIndex,
                            textValue($alternateData['locId'] ?? $alternateData['settingId'] ?? ''),
                            jsonText($alternateData),
                        ]);
                        $alternatePk = (int)$pdo->lastInsertId();
                        foreach (array_values(arr($alternateData['conditions'] ?? [])) as $conditionIndex => $condition) {
                            $conditionData = is_array($condition) ? $condition : [];
                            $conditionStmt->execute([
                                $alternatePk,
                                $conditionIndex,
                                textValue($conditionData['key'] ?? $conditionData['variable'] ?? ''),
                                textValue($conditionData['op'] ?? $conditionData['operator'] ?? '=='),
                                textValue($conditionData['val'] ?? $conditionData['value'] ?? ''),
                                jsonText($conditionData),
                            ]);
                        }
                    }
                }
            }
        }
    }
}

function normalizeDdGlobalItem(mixed $item, string $fallbackColor = ''): array
{
    if (is_array($item)) {
        return [
            'id' => textValue($item['id'] ?? ''),
            'name' => textValue($item['name'] ?? $item['character_name'] ?? $item['item_name'] ?? $item['sequence_name'] ?? ''),
            'color' => textValue($item['color'] ?? $fallbackColor),
            'raw' => $item,
        ];
    }
    return ['id' => '', 'name' => textValue($item), 'color' => $fallbackColor, 'raw' => $item];
}

function normalizeDdGlobalToken(mixed $item): array
{
    if (is_array($item)) {
        return [
            'id' => textValue($item['id'] ?? ''),
            'key' => textValue($item['key'] ?? $item['token_key'] ?? $item['name'] ?? ''),
            'value' => textValue($item['value'] ?? $item['token_value'] ?? ''),
            'raw' => $item,
        ];
    }
    return ['id' => '', 'key' => textValue($item), 'value' => '', 'raw' => $item];
}

function extractDialogueDesignerGlobalsFromRaw(array $data): array
{
    $mapItems = static function(mixed $items, string $fallbackColor = ''): array {
        return array_values(array_filter(array_map(static fn($item) => normalizeDdGlobalItem($item, $fallbackColor), arr($items)), static fn($item) => trim((string)$item['name']) !== ''));
    };
    $mapTokens = static function(mixed $items): array {
        return array_values(array_filter(array_map(static fn($item) => normalizeDdGlobalToken($item), arr($items)), static fn($item) => trim((string)$item['key']) !== ''));
    };

    return [
        'cast' => $mapItems($data['cast'] ?? [], '#00f2ff'),
        'globalTokens' => $mapTokens($data['globalTokens'] ?? []),
        'globalSettings' => $mapItems($data['globalSettings'] ?? [], '#ff007b'),
        'globalDaysOfWeek' => $mapItems($data['globalDaysOfWeek'] ?? [], '#ff8c00'),
        'globalTimesOfDay' => $mapItems($data['globalTimesOfDay'] ?? [], '#00ff88'),
        'globalStates' => $mapItems($data['globalStates'] ?? [], '#b026ff'),
        'globalMoods' => $mapItems($data['globalMoods'] ?? [], '#ffd700'),
        'globalMenuOptions' => $mapItems($data['globalMenuOptions'] ?? [], '#00f2ff'),
    ];
}

function decodeMaybeRawJson(mixed $rawJson): array
{
    $decoded = json_decode((string)$rawJson, true);
    return is_array($decoded) ? $decoded : [];
}

function fetchDdCastTable(PDO $pdo, int $workspaceId): array
{
    if (!tableExists($pdo, 'FSG_DD_Cast')) return [];
    $stmt = $pdo->prepare('SELECT character_name, color, raw_json FROM FSG_DD_Cast WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC');
    $stmt->execute([$workspaceId]);
    $items = [];
    foreach ($stmt->fetchAll() as $row) {
        $raw = decodeMaybeRawJson($row['raw_json'] ?? '');
        $items[] = [
            'id' => textValue($raw['id'] ?? ''),
            'name' => textValue($raw['name'] ?? $row['character_name'] ?? ''),
            'color' => textValue($raw['color'] ?? $row['color'] ?? '#00f2ff'),
        ];
    }
    return array_values(array_filter($items, static fn($item) => trim((string)$item['name']) !== ''));
}

function fetchDdTokensTable(PDO $pdo, int $workspaceId): array
{
    if (!tableExists($pdo, 'FSG_DD_GlobalTokens')) return [];
    $stmt = $pdo->prepare('SELECT token_key, token_value, raw_json FROM FSG_DD_GlobalTokens WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC');
    $stmt->execute([$workspaceId]);
    $items = [];
    foreach ($stmt->fetchAll() as $row) {
        $raw = decodeMaybeRawJson($row['raw_json'] ?? '');
        $items[] = [
            'id' => textValue($raw['id'] ?? ''),
            'key' => textValue($raw['key'] ?? $row['token_key'] ?? ''),
            'value' => textValue($raw['value'] ?? $row['token_value'] ?? ''),
        ];
    }
    return array_values(array_filter($items, static fn($item) => trim((string)$item['key']) !== ''));
}

function fetchDdNamedGlobalTable(PDO $pdo, int $workspaceId, string $tableName, string $fallbackColor): array
{
    $allowed = [
        'FSG_DD_GlobalStates',
        'FSG_DD_GlobalMoods',
        'FSG_DD_GlobalSettings',
        'FSG_DD_GlobalTimesOfDay',
        'FSG_DD_GlobalDaysOfWeek',
        'FSG_DD_GlobalMenuOptions',
    ];
    if (!in_array($tableName, $allowed, true) || !tableExists($pdo, $tableName)) return [];
    $stmt = $pdo->prepare("SELECT item_name, color, raw_json FROM {$tableName} WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC");
    $stmt->execute([$workspaceId]);
    $items = [];
    foreach ($stmt->fetchAll() as $row) {
        $raw = decodeMaybeRawJson($row['raw_json'] ?? '');
        $items[] = [
            'id' => textValue($raw['id'] ?? ''),
            'name' => textValue($raw['name'] ?? $row['item_name'] ?? ''),
            'color' => textValue($raw['color'] ?? $row['color'] ?? $fallbackColor),
        ];
    }
    return array_values(array_filter($items, static fn($item) => trim((string)$item['name']) !== ''));
}

function loadDialogueDesignerGlobals(PDO $pdo, string $sessionId = ''): array
{
    $sessionId = trim($sessionId);
    if ($sessionId === '' || !tableExists($pdo, 'FSG_DD_Workspaces')) {
        return ['hasDialogueDesignerWorkspace' => false, 'dialogueDesignerWorkspaceId' => '', 'dialogueDesignerCreatedAt' => '', 'globals' => extractDialogueDesignerGlobalsFromRaw([])];
    }

    $stmt = $pdo->prepare('SELECT id, workspace_uuid, raw_json, created_at FROM FSG_DD_Workspaces WHERE session_id = ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$sessionId]);
    $row = $stmt->fetch();
    if (!$row) {
        return ['hasDialogueDesignerWorkspace' => false, 'dialogueDesignerWorkspaceId' => '', 'dialogueDesignerCreatedAt' => '', 'globals' => extractDialogueDesignerGlobalsFromRaw([])];
    }

    $workspaceId = (int)($row['id'] ?? 0);
    $decoded = decodeMaybeRawJson($row['raw_json'] ?? '');
    $globals = extractDialogueDesignerGlobalsFromRaw($decoded);

    $tableGlobals = [
        'cast' => fetchDdCastTable($pdo, $workspaceId),
        'globalTokens' => fetchDdTokensTable($pdo, $workspaceId),
        'globalSettings' => fetchDdNamedGlobalTable($pdo, $workspaceId, 'FSG_DD_GlobalSettings', '#ff007b'),
        'globalDaysOfWeek' => fetchDdNamedGlobalTable($pdo, $workspaceId, 'FSG_DD_GlobalDaysOfWeek', '#ff8c00'),
        'globalTimesOfDay' => fetchDdNamedGlobalTable($pdo, $workspaceId, 'FSG_DD_GlobalTimesOfDay', '#00ff88'),
        'globalStates' => fetchDdNamedGlobalTable($pdo, $workspaceId, 'FSG_DD_GlobalStates', '#b026ff'),
        'globalMoods' => fetchDdNamedGlobalTable($pdo, $workspaceId, 'FSG_DD_GlobalMoods', '#ffd700'),
        'globalMenuOptions' => fetchDdNamedGlobalTable($pdo, $workspaceId, 'FSG_DD_GlobalMenuOptions', '#00f2ff'),
    ];

    foreach ($tableGlobals as $key => $items) {
        if (count($items) > 0) $globals[$key] = $items;
    }

    return [
        'hasDialogueDesignerWorkspace' => true,
        'dialogueDesignerWorkspaceId' => textValue($row['workspace_uuid'] ?? ''),
        'dialogueDesignerCreatedAt' => textValue($row['created_at'] ?? ''),
        'globals' => $globals,
    ];
}


function ddGlobalNameKey(mixed $value): string
{
    return strtolower(trim(textValue($value)));
}

function ddGlobalTokenKey(mixed $value): string
{
    $key = textValue($value);
    $key = preg_replace('/^\s*\{\{\s*/', '', $key) ?? $key;
    $key = preg_replace('/\s*\}\}\s*$/', '', $key) ?? $key;
    $key = str_replace(['{', '}'], '', $key);
    return mb_strtolower(trim($key), 'UTF-8');
}

function normalizePlannerNamedGlobal(mixed $item, string $fallbackColor): array
{
    if (is_array($item)) {
        return [
            'id' => textValue($item['id'] ?? ''),
            'name' => trim(textValue($item['name'] ?? $item['character_name'] ?? $item['item_name'] ?? '')),
            'color' => textValue($item['color'] ?? $fallbackColor),
        ];
    }
    return ['id' => '', 'name' => trim(textValue($item)), 'color' => $fallbackColor];
}

function normalizePlannerGlobalTokenForDd(mixed $item): array
{
    if (is_array($item)) {
        return [
            'id' => textValue($item['id'] ?? ''),
            'key' => trim(textValue($item['key'] ?? $item['token_key'] ?? $item['name'] ?? '')),
            'value' => textValue($item['value'] ?? $item['token_value'] ?? ''),
        ];
    }
    return ['id' => '', 'key' => trim(textValue($item)), 'value' => ''];
}

function dedupeDdNamedGlobals(array $items, string $fallbackColor): array
{
    $seen = [];
    $out = [];
    foreach ($items as $item) {
        $normalized = normalizePlannerNamedGlobal($item, $fallbackColor);
        $key = ddGlobalNameKey($normalized['name']);
        if ($key === '' || isset($seen[$key])) continue;
        $seen[$key] = true;
        if ($normalized['color'] === '') $normalized['color'] = $fallbackColor;
        $out[] = $normalized;
    }
    return $out;
}

function dedupeDdGlobalTokens(array $items): array
{
    $seen = [];
    $out = [];
    foreach ($items as $item) {
        $normalized = normalizePlannerGlobalTokenForDd($item);
        $key = ddGlobalTokenKey($normalized['key']);
        if ($key === '' || isset($seen[$key])) continue;
        $seen[$key] = true;
        $normalized['key'] = trim(str_replace(['{', '}'], '', $normalized['key']));
        $out[] = $normalized;
    }
    return $out;
}

function plannerListsToDialogueDesignerGlobals(array $data): array
{
    $lists = arr($data['lists'] ?? []);
    return [
        'cast' => dedupeDdNamedGlobals(arr($lists['chars'] ?? []), '#00f2ff'),
        'globalTokens' => dedupeDdGlobalTokens(arr($lists['tokens'] ?? [])),
        'globalSettings' => dedupeDdNamedGlobals(arr($lists['locs'] ?? []), '#ff007b'),
        'globalDaysOfWeek' => dedupeDdNamedGlobals(arr($lists['days'] ?? []), '#ff8c00'),
        'globalTimesOfDay' => dedupeDdNamedGlobals(arr($lists['times'] ?? []), '#00ff88'),
    ];
}

function replaceDdCastTable(PDO $pdo, int $workspaceId, array $items): void
{
    if (!tableExists($pdo, 'FSG_DD_Cast')) return;
    $pdo->prepare('DELETE FROM FSG_DD_Cast WHERE workspace_id = ?')->execute([$workspaceId]);
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_Cast (workspace_id, sort_order, character_name, color, raw_json) VALUES (?, ?, ?, ?, ?)');
    foreach (array_values($items) as $index => $item) {
        $stmt->execute([$workspaceId, $index, textValue($item['name'] ?? ''), textValue($item['color'] ?? ''), jsonText($item)]);
    }
}

function replaceDdGlobalTokensTable(PDO $pdo, int $workspaceId, array $items): void
{
    if (!tableExists($pdo, 'FSG_DD_GlobalTokens')) return;
    $pdo->prepare('DELETE FROM FSG_DD_GlobalTokens WHERE workspace_id = ?')->execute([$workspaceId]);
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_GlobalTokens (workspace_id, sort_order, token_key, token_value, raw_json) VALUES (?, ?, ?, ?, ?)');
    foreach (array_values($items) as $index => $item) {
        $stmt->execute([$workspaceId, $index, textValue($item['key'] ?? ''), textValue($item['value'] ?? ''), jsonText($item)]);
    }
}

function replaceDdNamedGlobalTable(PDO $pdo, int $workspaceId, string $tableName, array $items): void
{
    $allowed = [
        'FSG_DD_GlobalStates',
        'FSG_DD_GlobalMoods',
        'FSG_DD_GlobalSettings',
        'FSG_DD_GlobalTimesOfDay',
        'FSG_DD_GlobalDaysOfWeek',
        'FSG_DD_GlobalMenuOptions',
    ];
    if (!in_array($tableName, $allowed, true) || !tableExists($pdo, $tableName)) return;
    $pdo->prepare("DELETE FROM {$tableName} WHERE workspace_id = ?")->execute([$workspaceId]);
    $stmt = $pdo->prepare("INSERT INTO {$tableName} (workspace_id, sort_order, item_name, color, raw_json) VALUES (?, ?, ?, ?, ?)");
    foreach (array_values($items) as $index => $item) {
        $stmt->execute([$workspaceId, $index, textValue($item['name'] ?? ''), textValue($item['color'] ?? ''), jsonText($item)]);
    }
}

function replaceDdGlobalTables(PDO $pdo, int $workspaceId, array $globals): void
{
    replaceDdCastTable($pdo, $workspaceId, arr($globals['cast'] ?? []));
    replaceDdGlobalTokensTable($pdo, $workspaceId, arr($globals['globalTokens'] ?? []));
    replaceDdNamedGlobalTable($pdo, $workspaceId, 'FSG_DD_GlobalStates', arr($globals['globalStates'] ?? []));
    replaceDdNamedGlobalTable($pdo, $workspaceId, 'FSG_DD_GlobalMoods', arr($globals['globalMoods'] ?? []));
    replaceDdNamedGlobalTable($pdo, $workspaceId, 'FSG_DD_GlobalSettings', arr($globals['globalSettings'] ?? []));
    replaceDdNamedGlobalTable($pdo, $workspaceId, 'FSG_DD_GlobalDaysOfWeek', arr($globals['globalDaysOfWeek'] ?? []));
    replaceDdNamedGlobalTable($pdo, $workspaceId, 'FSG_DD_GlobalTimesOfDay', arr($globals['globalTimesOfDay'] ?? []));
    replaceDdNamedGlobalTable($pdo, $workspaceId, 'FSG_DD_GlobalMenuOptions', arr($globals['globalMenuOptions'] ?? []));
}

function insertDdWorkspaceRow(PDO $pdo, string $workspaceUuid, string $sessionId, int $userId, array $ddData): int
{
    $columns = ['workspace_uuid', 'session_id'];
    $values = [$workspaceUuid, $sessionId];

    if (columnExists($pdo, 'FSG_DD_Workspaces', 'user_id')) {
        $columns[] = 'user_id';
        $values[] = $userId > 0 ? $userId : null;
    }
    if (columnExists($pdo, 'FSG_DD_Workspaces', 'version')) {
        $columns[] = 'version';
        $values[] = textValue($ddData['version'] ?? '2.21') ?: '2.21';
    }
    if (columnExists($pdo, 'FSG_DD_Workspaces', 'current_language')) {
        $columns[] = 'current_language';
        $values[] = textValue($ddData['currentLanguage'] ?? 'ENG') ?: 'ENG';
    }
    if (columnExists($pdo, 'FSG_DD_Workspaces', 'available_languages_json')) {
        $columns[] = 'available_languages_json';
        $values[] = jsonText(arr($ddData['availableLanguages'] ?? ['ENG']));
    }

    $columns[] = 'raw_json';
    $values[] = jsonText($ddData);

    $placeholders = implode(', ', array_fill(0, count($columns), '?'));
    $columnSql = implode(', ', $columns);
    $stmt = $pdo->prepare("INSERT INTO FSG_DD_Workspaces ({$columnSql}) VALUES ({$placeholders})");
    $stmt->execute($values);
    return (int)$pdo->lastInsertId();
}

function insertDdRawJsonSnapshot(PDO $pdo, int $workspaceId, string $label, array $ddData): void
{
    if ($workspaceId <= 0 || !tableExists($pdo, 'FSG_DD_RawJsonSnapshots')) return;
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_RawJsonSnapshots (workspace_id, snapshot_label, raw_json) VALUES (?, ?, ?)');
    $stmt->execute([$workspaceId, $label, jsonText($ddData)]);
}

function touchDialogueDesignerUserSession(PDO $pdo, string $sessionId, int $userId): void
{
    if ($userId <= 0 || trim($sessionId) === '') return;
    if (tableExists($pdo, 'FSG_DD_UserSessions')) {
        $stmt = $pdo->prepare('INSERT INTO FSG_DD_UserSessions (user_id, session_id, first_pushed_at, last_pushed_at, last_viewed_at, workspace_count)
            VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1)
            ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), last_pushed_at = CURRENT_TIMESTAMP, last_viewed_at = CURRENT_TIMESTAMP, workspace_count = workspace_count + 1');
        $stmt->execute([$userId, $sessionId]);
    }
    if (function_exists('fsgAuth_touchServerSession')) {
        try { fsgAuth_touchServerSession($pdo, $userId, 'DialogueDesigner', $sessionId, 'push'); } catch (Throwable $e) {}
    }
}

function syncDialogueDesignerGlobalsFromPlanner(PDO $pdo, string $sessionId, int $userId, array $data): array
{
    $sessionId = trim($sessionId);
    if ($sessionId === '') {
        return ['synced' => false, 'reason' => 'Daily Planner did not send a serverSessionId.'];
    }
    if (!tableExists($pdo, 'FSG_DD_Workspaces')) {
        return ['synced' => false, 'reason' => 'Dialogue Designer workspace table is not available.'];
    }

    $plannerGlobals = plannerListsToDialogueDesignerGlobals($data);

    $stmt = $pdo->prepare('SELECT id, workspace_uuid, raw_json FROM FSG_DD_Workspaces WHERE session_id = ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$sessionId]);
    $row = $stmt->fetch();

    $previousWorkspacePk = $row ? (int)($row['id'] ?? 0) : 0;
    $previousWorkspaceUuid = $row ? textValue($row['workspace_uuid'] ?? '') : '';
    $ddData = $row ? decodeMaybeRawJson($row['raw_json'] ?? '') : [];
    if (!$ddData) $ddData = [];

    foreach ($plannerGlobals as $key => $items) {
        $ddData[$key] = array_values($items);
    }

    $ddData['serverSessionId'] = $sessionId;
    if (empty($ddData['version'])) $ddData['version'] = '2.21';
    if (empty($ddData['availableLanguages']) || !is_array($ddData['availableLanguages'])) $ddData['availableLanguages'] = ['ENG'];
    if (!in_array('ENG', $ddData['availableLanguages'], true)) array_unshift($ddData['availableLanguages'], 'ENG');
    if (empty($ddData['currentLanguage'])) $ddData['currentLanguage'] = 'ENG';
    if (!isset($ddData['cast']) || !is_array($ddData['cast'])) $ddData['cast'] = [];
    if (!isset($ddData['globalTokens']) || !is_array($ddData['globalTokens'])) $ddData['globalTokens'] = [];
    if (!isset($ddData['globalStates']) || !is_array($ddData['globalStates'])) $ddData['globalStates'] = [];
    if (!isset($ddData['globalMoods']) || !is_array($ddData['globalMoods'])) $ddData['globalMoods'] = [];
    if (!isset($ddData['globalSettings']) || !is_array($ddData['globalSettings'])) $ddData['globalSettings'] = [];
    if (!isset($ddData['globalTimesOfDay']) || !is_array($ddData['globalTimesOfDay'])) $ddData['globalTimesOfDay'] = [];
    if (!isset($ddData['globalDaysOfWeek']) || !is_array($ddData['globalDaysOfWeek'])) $ddData['globalDaysOfWeek'] = [];
    if (!isset($ddData['globalMenuOptions']) || !is_array($ddData['globalMenuOptions'])) $ddData['globalMenuOptions'] = [];
    if (!isset($ddData['globalImageSequences']) || !is_array($ddData['globalImageSequences'])) $ddData['globalImageSequences'] = [];
    if (!isset($ddData['conversations']) || !is_array($ddData['conversations'])) $ddData['conversations'] = [];
    if (!isset($ddData['sequences']) || !is_array($ddData['sequences'])) $ddData['sequences'] = [];

    $tableGlobals = [
        'cast' => dedupeDdNamedGlobals(arr($ddData['cast'] ?? []), '#00f2ff'),
        'globalTokens' => dedupeDdGlobalTokens(arr($ddData['globalTokens'] ?? [])),
        'globalStates' => dedupeDdNamedGlobals(arr($ddData['globalStates'] ?? []), '#b026ff'),
        'globalMoods' => dedupeDdNamedGlobals(arr($ddData['globalMoods'] ?? []), '#ffd700'),
        'globalSettings' => dedupeDdNamedGlobals(arr($ddData['globalSettings'] ?? []), '#ff007b'),
        'globalDaysOfWeek' => dedupeDdNamedGlobals(arr($ddData['globalDaysOfWeek'] ?? []), '#ff8c00'),
        'globalTimesOfDay' => dedupeDdNamedGlobals(arr($ddData['globalTimesOfDay'] ?? []), '#00ff88'),
        'globalMenuOptions' => dedupeDdNamedGlobals(arr($ddData['globalMenuOptions'] ?? []), '#00f2ff'),
    ];

    foreach ($tableGlobals as $key => $items) {
        $ddData[$key] = array_values($items);
    }

    $workspaceUuid = uuidv4();
    $workspacePk = insertDdWorkspaceRow($pdo, $workspaceUuid, $sessionId, $userId, $ddData);
    insertDdRawJsonSnapshot($pdo, $workspacePk, 'Daily Planner Shared Global Sync', $ddData);
    replaceDdGlobalTables($pdo, $workspacePk, $tableGlobals);
    touchDialogueDesignerUserSession($pdo, $sessionId, $userId);

    return [
        'synced' => true,
        'mode' => $previousWorkspacePk > 0 ? 'inserted_new_dialogue_designer_workspace_from_previous' : 'created_dialogue_designer_global_workspace',
        'dialogueDesignerDatabaseId' => $workspacePk,
        'dialogueDesignerWorkspaceId' => $workspaceUuid,
        'previousDialogueDesignerDatabaseId' => $previousWorkspacePk,
        'previousDialogueDesignerWorkspaceId' => $previousWorkspaceUuid,
        'globalCounts' => [
            'cast' => count($tableGlobals['cast']),
            'globalTokens' => count($tableGlobals['globalTokens']),
            'globalSettings' => count($tableGlobals['globalSettings']),
            'globalDaysOfWeek' => count($tableGlobals['globalDaysOfWeek']),
            'globalTimesOfDay' => count($tableGlobals['globalTimesOfDay']),
        ],
    ];
}

function saveSuite(PDO $pdo, array $data): array
{
    $userId = currentUserId($pdo);
    if ($userId <= 0) {
        respondJson(['ok' => false, 'error' => 'Log in before pushing this Daily Planner workspace to the server.'], 401);
    }

    $sessionId = trim(textValue($data['serverSessionId'] ?? ''));
    if ($sessionId === '') $sessionId = generateUniqueSessionId($pdo);

    $workspaceId = uuidv4();
    $rawJson = jsonText($data);

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('INSERT INTO FSG_DP_Workspaces (workspace_uuid, session_id, user_id, version, config_json, lists_json, schedule_json, raw_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            $workspaceId,
            $sessionId,
            $userId,
            textValue($data['version'] ?? ''),
            jsonText($data['config'] ?? null),
            jsonText($data['lists'] ?? null),
            jsonText($data['schedule'] ?? null),
            $rawJson,
        ]);
        $workspacePk = (int)$pdo->lastInsertId();

        $snapshotStmt = $pdo->prepare('INSERT INTO FSG_DP_RawJsonSnapshots (workspace_id, snapshot_label, raw_json) VALUES (?, ?, ?)');
        $snapshotStmt->execute([$workspacePk, 'Full Planner Workspace Save', $rawJson]);
        insertDailyPlannerNormalizedData($pdo, $workspacePk, $data);

        $dialogueDesignerGlobalSync = syncDialogueDesignerGlobalsFromPlanner($pdo, $sessionId, $userId, $data);

        attachWorkspaceToUserSession($pdo, $sessionId, $userId);
        $pdo->commit();

        $account = authPayload($pdo);
        return [
            'workspaceId' => $workspaceId,
            'sessionId' => $sessionId,
            'databaseId' => $workspacePk,
            'attachedToUserId' => $userId,
            'dialogueDesignerGlobalSync' => $dialogueDesignerGlobalSync,
            'account' => $account,
            'sessions' => $account['sessions'] ?? [],
        ];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function loadLatestSuite(PDO $pdo, string $sessionId = ''): array
{
    $sessionId = trim($sessionId);
    if ($sessionId !== '') {
        $stmt = $pdo->prepare('SELECT workspace_uuid, session_id, raw_json, created_at FROM FSG_DP_Workspaces WHERE session_id = ? ORDER BY id DESC LIMIT 1');
        $stmt->execute([$sessionId]);
    } else {
        $stmt = $pdo->query('SELECT workspace_uuid, session_id, raw_json, created_at FROM FSG_DP_Workspaces ORDER BY id DESC LIMIT 1');
    }

    $row = $stmt->fetch();
    if (!$row) {
        return [
            'hasWorkspace' => false,
            'workspaceId' => '',
            'sessionId' => $sessionId,
            'createdAt' => '',
            'data' => null,
            'message' => $sessionId !== '' ? "No saved Daily Planner workspace exists yet for this session." : "No saved Daily Planner workspace exists yet."
        ] + loadDialogueDesignerGlobals($pdo, $sessionId);
    }

    $data = json_decode((string)$row['raw_json'], true);
    if (!is_array($data)) {
        respondJson(['ok' => false, 'error' => 'Latest planner raw_json is not valid JSON.'], 500);
    }

    touchUserSessionViewed($pdo, textValue($row['session_id'] ?? $sessionId));

    return [
        'hasWorkspace' => true,
        'workspaceId' => $row['workspace_uuid'],
        'sessionId' => $row['session_id'],
        'createdAt' => $row['created_at'],
        'data' => $data,
    ] + loadDialogueDesignerGlobals($pdo, textValue($row['session_id'] ?? $sessionId));
}

function listSavedSuites(PDO $pdo): array
{
    $stmt = $pdo->query('SELECT id, workspace_uuid, session_id, version, created_at, updated_at FROM FSG_DP_Workspaces ORDER BY id DESC LIMIT 100');
    return $stmt->fetchAll();
}

try {
    $action = $_GET['action'] ?? '';
    $body = requestBody();
    if ($action === '' && isset($body['action'])) $action = textValue($body['action']);
    if ($action === '') $action = $_SERVER['REQUEST_METHOD'] === 'GET' ? 'health' : 'saveSuite';

    $pdo = dbConnection();
    ensureDailyPlannerTables($pdo);

    if ($action === 'health') {
        respondJson(['ok' => true, 'api' => 'DailyPlanner', 'database' => 'connected']);
    }

    if ($action === 'authStatus' || $action === 'accountStatus') {
        respondJson(['ok' => true] + authPayload($pdo));
    }

    if ($action === 'register') {
        if (!function_exists('fsgAuth_registerAccount')) respondJson(['ok' => false, 'error' => 'Shared auth is not installed.'], 500);
        respondJson(['ok' => true] + withPlannerSessions($pdo, fsgAuth_registerAccount($pdo, $body)));
    }

    if ($action === 'login') {
        if (!function_exists('fsgAuth_loginAccount')) respondJson(['ok' => false, 'error' => 'Shared auth is not installed.'], 500);
        respondJson(['ok' => true] + withPlannerSessions($pdo, fsgAuth_loginAccount($pdo, $body)));
    }

    if ($action === 'logout') {
        if (function_exists('fsgAuth_logout')) fsgAuth_logout($pdo);
        else session_destroy();
        respondJson(['ok' => true, 'loggedIn' => false, 'user' => null, 'sessions' => []]);
    }

    if ($action === 'updateProfile') {
        if (!function_exists('fsgAuth_updateProfile')) respondJson(['ok' => false, 'error' => 'Shared auth is not installed.'], 500);
        respondJson(['ok' => true] + withPlannerSessions($pdo, fsgAuth_updateProfile($pdo, $body)));
    }

    if ($action === 'changePassword') {
        if (!function_exists('fsgAuth_changePassword')) respondJson(['ok' => false, 'error' => 'Shared auth is not installed.'], 500);
        respondJson(['ok' => true] + withPlannerSessions($pdo, fsgAuth_changePassword($pdo, $body)));
    }

    if ($action === 'generateSessionId') {
        respondJson(['ok' => true, 'sessionId' => generateUniqueSessionId($pdo)]);
    }

    if ($action === 'saveSuite') {
        $data = isset($body['data']) && is_array($body['data']) ? $body['data'] : $body;
        if (!$data) respondJson(['ok' => false, 'error' => 'No Daily Planner JSON was sent.'], 400);
        $saved = saveSuite($pdo, $data);
        respondJson(['ok' => true] + $saved);
    }

    if ($action === 'loadLatestSuite') {
        respondJson(['ok' => true] + loadLatestSuite($pdo, textValue($_GET['sessionId'] ?? $body['sessionId'] ?? '')));
    }

    if ($action === 'loadDialogueDesignerGlobals') {
        respondJson(['ok' => true] + loadDialogueDesignerGlobals($pdo, textValue($_GET['sessionId'] ?? $body['sessionId'] ?? '')));
    }

    if ($action === 'listSuites') {
        respondJson(['ok' => true, 'suites' => listSavedSuites($pdo)]);
    }

    respondJson(['ok' => false, 'error' => 'Unknown action.'], 404);
} catch (Throwable $e) {
    respondJson(['ok' => false, 'error' => $e->getMessage()], 500);
}
