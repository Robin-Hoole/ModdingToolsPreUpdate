<?php
/**
 * ==============================================================================
 * NAMESPACE: RobinHooleProduction.Task.API
 * CONTEXT: Task Manager database/login/session pipeline
 * DESCRIPTION: Shares the same 12-hour auth token and Dialogue Designer globals
 *              used by the other Ungodly/FSG web tools.
 * ==============================================================================
 */

declare(strict_types=1);
ini_set('display_errors', '0');
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Auth-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$authSharedPath = __DIR__ . '/_private/AuthShared.php';
if (is_file($authSharedPath)) {
    require_once $authSharedPath;
}
if (function_exists('fsgAuth_startSharedSession')) {
    fsgAuth_startSharedSession();
} elseif (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

register_shutdown_function(function(): void {
    $err = error_get_last();
    if ($err !== null && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
        http_response_code(500);
        echo json_encode([
            'ok' => false,
            'status' => 'error',
            'message' => 'Fatal PHP Execution Crash',
            'details' => $err['message'] . ' in ' . $err['file'] . ' on line ' . $err['line'],
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
    }
});

function task_json(array $payload, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit;
}

function task_text(mixed $value): string
{
    if ($value === null) return '';
    if (is_bool($value)) return $value ? '1' : '0';
    if (is_scalar($value)) return (string)$value;
    return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '';
}

function task_body(): array
{
    if (function_exists('fsgAuth_requestBody')) {
        return fsgAuth_requestBody();
    }
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') return [];
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) task_json(['ok' => false, 'error' => 'Invalid JSON body.'], 400);
    return $decoded;
}

function task_pdo(): PDO
{
    if (function_exists('fsgAuth_dbConnection')) {
        return fsgAuth_dbConnection();
    }

    $paths = [
        __DIR__ . '/_private/databaseCredentials.php',
        __DIR__ . '/_private/databasecredentials.php',
        __DIR__ . '/_Private/databaseCredentials.php',
        __DIR__ . '/private/databaseCredentials.php',
        (string)($_SERVER['DOCUMENT_ROOT'] ?? '') . '/_private/databaseCredentials.php',
        __DIR__ . '/databaseCredentials.php',
        __DIR__ . '/databaseCredentials (1).php',
    ];

    $loaded = false;
    $checked = [];
    foreach ($paths as $path) {
        if ($path === '/_private/databaseCredentials.php') continue;
        $checked[] = $path;
        if (is_file($path)) {
            require $path;
            $loaded = true;
            break;
        }
    }
    if (!$loaded) {
        throw new RuntimeException('Database credentials file missing. Checked: ' . implode(' | ', $checked));
    }
    foreach (['dbHost', 'dbUser', 'dbPass', 'dbName'] as $varName) {
        if (!isset(${$varName})) throw new RuntimeException('Missing database credential variable: ' . $varName);
    }
    $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
    return new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function task_identifier_is_safe(string $identifier): bool
{
    return $identifier !== '' && (bool)preg_match('/^[A-Za-z0-9_]+$/', $identifier);
}

function task_quote_identifier(string $identifier): string
{
    if (!task_identifier_is_safe($identifier)) {
        throw new RuntimeException('Unsafe SQL identifier: ' . $identifier);
    }
    return '`' . str_replace('`', '``', $identifier) . '`';
}

function task_table_exists(PDO $pdo, string $tableName): bool
{
    $tableName = trim($tableName);
    if (!task_identifier_is_safe($tableName)) return false;

    try {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?');
        $stmt->execute([$tableName]);
        if ((int)$stmt->fetchColumn() > 0) return true;
    } catch (Throwable $e) {}

    try {
        $stmt = $pdo->query('SHOW TABLES');
        foreach (($stmt ? $stmt->fetchAll(PDO::FETCH_NUM) : []) as $row) {
            if (strcasecmp((string)($row[0] ?? ''), $tableName) === 0) return true;
        }
    } catch (Throwable $e) {}

    try {
        $pdo->query('SHOW COLUMNS FROM ' . task_quote_identifier($tableName));
        return true;
    } catch (Throwable $e) {}

    return false;
}

function task_column_exists(PDO $pdo, string $tableName, string $columnName): bool
{
    $tableName = trim($tableName);
    $columnName = trim($columnName);
    if (!task_identifier_is_safe($tableName) || !task_identifier_is_safe($columnName)) return false;

    try {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?');
        $stmt->execute([$tableName, $columnName]);
        if ((int)$stmt->fetchColumn() > 0) return true;
    } catch (Throwable $e) {}

    try {
        $stmt = $pdo->query('SHOW COLUMNS FROM ' . task_quote_identifier($tableName));
        foreach (($stmt ? $stmt->fetchAll() : []) as $row) {
            if (strcasecmp((string)($row['Field'] ?? ''), $columnName) === 0) return true;
        }
    } catch (Throwable $e) {}

    return false;
}



function task_ensure_server_session_schema(PDO $pdo): void
{
    if (!task_table_exists($pdo, 'FSG_Server_Sessions')) return;
    $alterations = [];
    if (!task_column_exists($pdo, 'FSG_Server_Sessions', 'app_key') && !task_column_exists($pdo, 'FSG_Server_Sessions', 'app_name')) {
        $alterations[] = "ALTER TABLE FSG_Server_Sessions ADD COLUMN app_key VARCHAR(64) NOT NULL DEFAULT 'TaskManager' AFTER user_id";
    }
    if (!task_column_exists($pdo, 'FSG_Server_Sessions', 'first_seen_at') && !task_column_exists($pdo, 'FSG_Server_Sessions', 'first_used_at') && !task_column_exists($pdo, 'FSG_Server_Sessions', 'first_pushed_at')) {
        $alterations[] = "ALTER TABLE FSG_Server_Sessions ADD COLUMN first_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER session_id";
    }
    if (!task_column_exists($pdo, 'FSG_Server_Sessions', 'first_pushed_at')) {
        $afterFirst = task_column_exists($pdo, 'FSG_Server_Sessions', 'first_seen_at') ? 'first_seen_at' : (task_column_exists($pdo, 'FSG_Server_Sessions', 'first_used_at') ? 'first_used_at' : 'session_id');
        $alterations[] = "ALTER TABLE FSG_Server_Sessions ADD COLUMN first_pushed_at TIMESTAMP NULL DEFAULT NULL AFTER {$afterFirst}";
    }
    if (!task_column_exists($pdo, 'FSG_Server_Sessions', 'last_pushed_at')) {
        $alterations[] = "ALTER TABLE FSG_Server_Sessions ADD COLUMN last_pushed_at TIMESTAMP NULL DEFAULT NULL AFTER first_pushed_at";
    }
    if (!task_column_exists($pdo, 'FSG_Server_Sessions', 'last_viewed_at')) {
        $alterations[] = "ALTER TABLE FSG_Server_Sessions ADD COLUMN last_viewed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER last_pushed_at";
    }
    if (!task_column_exists($pdo, 'FSG_Server_Sessions', 'payload_table')) {
        $alterations[] = "ALTER TABLE FSG_Server_Sessions ADD COLUMN payload_table VARCHAR(128) NOT NULL DEFAULT '' AFTER last_viewed_at";
    }
    if (!task_column_exists($pdo, 'FSG_Server_Sessions', 'workspace_count')) {
        $alterations[] = "ALTER TABLE FSG_Server_Sessions ADD COLUMN workspace_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER payload_table";
    }
    if (!task_column_exists($pdo, 'FSG_Server_Sessions', 'is_active')) {
        $alterations[] = "ALTER TABLE FSG_Server_Sessions ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER workspace_count";
    }
    foreach ($alterations as $sql) {
        try { $pdo->exec($sql); } catch (Throwable $e) { task_diag_add('FSG_Server_Sessions migration skipped/failed', ['sql' => $sql, 'error' => $e->getMessage()]); }
    }
    try {
        $hasUserAppSessionIndex = false;
        $idx = $pdo->query("SHOW INDEX FROM FSG_Server_Sessions");
        foreach (($idx ? $idx->fetchAll() : []) as $row) {
            if (in_array((string)($row['Key_name'] ?? ''), ['uq_FSG_Server_Sessions_user_app_session', 'uq_fsg_server_session_app_sid'], true)) {
                $hasUserAppSessionIndex = true;
                break;
            }
        }
        if (!$hasUserAppSessionIndex) {
            $appColumn = task_column_exists($pdo, 'FSG_Server_Sessions', 'app_key') ? 'app_key' : (task_column_exists($pdo, 'FSG_Server_Sessions', 'app_name') ? 'app_name' : '');
            if ($appColumn !== '') {
                try { $pdo->exec("CREATE INDEX idx_FSG_Server_Sessions_task_lookup ON FSG_Server_Sessions (user_id, {$appColumn}, last_viewed_at)"); } catch (Throwable $e) {}
            }
        }
    } catch (Throwable $e) {}
}

function task_ensure_tables(PDO $pdo): void
{
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_TASK_app_state (
        state_key VARCHAR(80) NOT NULL,
        state_json LONGTEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (state_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_TASK_server_sessions (
        session_id VARCHAR(128) NOT NULL,
        user_id INT NULL,
        payload_json LONGTEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (session_id),
        KEY idx_task_session_user_updated (user_id, updated_at),
        KEY idx_task_session_updated (updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_TASK_sprite_directories (
        id VARCHAR(128) NOT NULL,
        name VARCHAR(255) NOT NULL DEFAULT 'New Directory',
        sort_order INT NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_task_sprite_dir_sort (sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_TASK_sprites (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        directory_id VARCHAR(128) NOT NULL,
        name VARCHAR(255) NOT NULL DEFAULT 'Unnamed Sprite',
        file TEXT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_task_sprite_directory (directory_id),
        CONSTRAINT fk_task_sprite_directory FOREIGN KEY (directory_id) REFERENCES FSG_TASK_sprite_directories(id) ON DELETE CASCADE ON UPDATE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Server_Sessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id INT NULL,
        app_key VARCHAR(64) NOT NULL DEFAULT 'TaskManager',
        session_id VARCHAR(128) NOT NULL,
        first_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        first_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_viewed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        payload_table VARCHAR(128) NOT NULL DEFAULT '',
        workspace_count INT UNSIGNED NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        KEY idx_fsg_server_session_user (user_id, last_viewed_at),
        KEY idx_fsg_server_session_sid (session_id),
        KEY idx_fsg_server_session_app_user (app_key, user_id, last_viewed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    task_ensure_server_session_schema($pdo);
}

function task_token_from_request(): string
{
    if (function_exists('fsgAuth_extractBearerToken')) return fsgAuth_extractBearerToken();
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authHeader = '';
    foreach ($headers as $key => $value) {
        if (strtolower((string)$key) === 'authorization') {
            $authHeader = (string)$value;
            break;
        }
    }
    if ($authHeader === '') $authHeader = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
    if ($authHeader === '') $authHeader = (string)($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (preg_match('/Bearer\s+(.+)/i', $authHeader, $matches)) return trim($matches[1]);
    $xToken = trim((string)($_SERVER['HTTP_X_AUTH_TOKEN'] ?? ''));
    if ($xToken !== '') return $xToken;
    $queryToken = trim((string)($_GET['authToken'] ?? ''));
    if ($queryToken !== '') return $queryToken;
    return trim((string)($_COOKIE['AUTH_TOKEN'] ?? ''));
}

function task_user_id(PDO $pdo): int
{
    try {
        if (function_exists('fsgAuth_ensureAccountTables')) fsgAuth_ensureAccountTables($pdo);
        if (function_exists('fsgAuth_currentUserIdFromRequest')) {
            $id = (int)fsgAuth_currentUserIdFromRequest($pdo);
            if ($id > 0) return $id;
        }
    } catch (Throwable $e) {}

    foreach (['fsg_user_id', 'dd_user_id', 'user_id'] as $key) {
        if (!empty($_SESSION[$key])) return (int)$_SESSION[$key];
    }

    if (!task_table_exists($pdo, 'FSG_auth_sessions') || !task_table_exists($pdo, 'FSG_users')) return 0;
    $token = task_token_from_request();
    if ($token === '') return 0;
    $hash = hash('sha256', $token);
    try {
        $stmt = $pdo->prepare('SELECT s.user_id, u.username FROM FSG_auth_sessions s JOIN FSG_users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > UTC_TIMESTAMP() AND u.is_active = 1 LIMIT 1');
        $stmt->execute([$hash]);
        $row = $stmt->fetch();
        if (!$row) return 0;
        $userId = (int)$row['user_id'];
        $_SESSION['fsg_user_id'] = $userId;
        $_SESSION['dd_user_id'] = $userId;
        $_SESSION['user_id'] = $userId;
        $_SESSION['fsg_username'] = (string)($row['username'] ?? '');
        $_SESSION['dd_username'] = (string)($row['username'] ?? '');
        $_SESSION['username'] = (string)($row['username'] ?? '');
        $pdo->prepare('UPDATE FSG_auth_sessions SET expires_at = ?, last_seen_at = UTC_TIMESTAMP() WHERE token_hash = ?')->execute([gmdate('Y-m-d H:i:s', time() + 43200), $hash]);
        return $userId;
    } catch (Throwable $e) {
        return 0;
    }
}

function task_current_user(PDO $pdo, int $userId): ?array
{
    if ($userId <= 0 || !task_table_exists($pdo, 'FSG_users')) return null;
    try {
        $stmt = $pdo->prepare('SELECT id, username, email, created_at FROM FSG_users WHERE id = ? AND is_active = 1 LIMIT 1');
        $stmt->execute([$userId]);
        $row = $stmt->fetch();
        if (!$row) return null;
        return ['id' => (int)$row['id'], 'username' => $row['username'], 'email' => $row['email'], 'createdAt' => $row['created_at'] ?? null];
    } catch (Throwable $e) {
        return null;
    }
}


function task_diag_add(string $message, array $context = []): void
{
    if (!isset($GLOBALS['TASK_DIAGNOSTICS']) || !is_array($GLOBALS['TASK_DIAGNOSTICS'])) $GLOBALS['TASK_DIAGNOSTICS'] = [];
    $GLOBALS['TASK_DIAGNOSTICS'][] = ['message' => $message, 'context' => $context];
}

function task_debug_line(string $question, string $answer): void
{
    if (!isset($GLOBALS['TASK_DEBUG_LINES']) || !is_array($GLOBALS['TASK_DEBUG_LINES'])) $GLOBALS['TASK_DEBUG_LINES'] = [];
    $line = '[TaskManager Check] ' . trim($question) . ' ' . trim($answer);
    if (!in_array($line, $GLOBALS['TASK_DEBUG_LINES'], true)) $GLOBALS['TASK_DEBUG_LINES'][] = $line;
}

function task_debug_payload(): array
{
    return [
        'diagnostics' => $GLOBALS['TASK_DIAGNOSTICS'] ?? [],
        'debugLogLines' => $GLOBALS['TASK_DEBUG_LINES'] ?? [],
    ];
}

function task_payload_with_debug(array $payload): array
{
    return $payload + task_debug_payload();
}

function task_server_sessions_columns(PDO $pdo): array
{
    $cols = [
        'app' => '',
        'first' => '',
        'lastViewed' => '',
        'lastPushed' => '',
        'payloadTable' => '',
        'isActive' => '',
    ];
    if (!task_table_exists($pdo, 'FSG_Server_Sessions')) return $cols;
    $cols['app'] = task_column_exists($pdo, 'FSG_Server_Sessions', 'app_key') ? 'app_key' : (task_column_exists($pdo, 'FSG_Server_Sessions', 'app_name') ? 'app_name' : '');
    $cols['first'] = task_column_exists($pdo, 'FSG_Server_Sessions', 'first_seen_at') ? 'first_seen_at' : (task_column_exists($pdo, 'FSG_Server_Sessions', 'first_used_at') ? 'first_used_at' : (task_column_exists($pdo, 'FSG_Server_Sessions', 'first_pushed_at') ? 'first_pushed_at' : ''));
    $cols['lastViewed'] = task_column_exists($pdo, 'FSG_Server_Sessions', 'last_viewed_at') ? 'last_viewed_at' : '';
    $cols['lastPushed'] = task_column_exists($pdo, 'FSG_Server_Sessions', 'last_pushed_at') ? 'last_pushed_at' : '';
    $cols['payloadTable'] = task_column_exists($pdo, 'FSG_Server_Sessions', 'payload_table') ? 'payload_table' : '';
    $cols['isActive'] = task_column_exists($pdo, 'FSG_Server_Sessions', 'is_active') ? 'is_active' : '';
    return $cols;
}

function task_server_sessions_time_expr(array $cols): string
{
    $parts = [];
    if ($cols['lastPushed'] !== '') $parts[] = $cols['lastPushed'];
    if ($cols['lastViewed'] !== '') $parts[] = $cols['lastViewed'];
    if ($cols['first'] !== '') $parts[] = $cols['first'];
    if (!$parts) return 'id';
    return 'COALESCE(' . implode(', ', $parts) . ')';
}

function task_latest_task_session(PDO $pdo, int $userId): array
{
    $result = ['sessionId' => '', 'source' => '', 'reason' => 'No logged-in user.'];
    if ($userId <= 0) {
        task_debug_line('Did I find their most recent server session?', 'NO; userId=0, so no account session can be queried.');
        return $result;
    }

    try {
        $dbName = (string)$pdo->query('SELECT DATABASE()')->fetchColumn();
        $hasServer = task_table_exists($pdo, 'FSG_Server_Sessions') ? 'YES' : 'NO';
        $hasTaskPayload = task_table_exists($pdo, 'FSG_TASK_server_sessions') ? 'YES' : 'NO';
        task_debug_line('Did I check the TaskManager account session tables in the same database as Dialogue Designer?', 'YES; database=' . $dbName . '; FSG_Server_Sessions=' . $hasServer . '; FSG_TASK_server_sessions=' . $hasTaskPayload . '.');
    } catch (Throwable $e) {}

    try {
        if (function_exists('fsgAuth_listUserSessions')) {
            $sessions = fsgAuth_listUserSessions($pdo, $userId, 'TaskManager');
            foreach ($sessions as $session) {
                $sid = trim(task_text($session['session_id'] ?? $session['sessionId'] ?? ''));
                if ($sid !== '') {
                    $result = ['sessionId' => $sid, 'source' => 'fsgAuth_listUserSessions(TaskManager)', 'reason' => 'Most recent shared auth TaskManager session.'];
                    task_debug_line('Did I find their most recent server session?', 'YES; sessionId=' . $sid . '; source=' . $result['source'] . '.');
                    return $result;
                }
            }
            task_debug_line('Did I find their most recent server session?', 'NO from fsgAuth_listUserSessions(TaskManager); userId=' . $userId . '; returnedRows=' . count($sessions) . '.');
        }
    } catch (Throwable $e) {
        task_diag_add('fsgAuth_listUserSessions(TaskManager) failed', ['error' => $e->getMessage()]);
        task_debug_line('Did I find their most recent server session?', 'NO from fsgAuth_listUserSessions(TaskManager); error=' . $e->getMessage());
    }

    try {
        task_ensure_server_session_schema($pdo);
        $cols = task_server_sessions_columns($pdo);
        if ($cols['app'] !== '') {
            $whereActive = $cols['isActive'] !== '' ? " AND {$cols['isActive']} = 1" : '';
            $timeExpr = task_server_sessions_time_expr($cols);
            $stmt = $pdo->prepare("SELECT session_id FROM FSG_Server_Sessions WHERE user_id = ? AND REPLACE(LOWER({$cols['app']}), ' ', '') = 'taskmanager'{$whereActive} ORDER BY {$timeExpr} DESC, id DESC LIMIT 1");
            $stmt->execute([$userId]);
            $sid = trim((string)($stmt->fetchColumn() ?: ''));
            if ($sid !== '') {
                $result = ['sessionId' => $sid, 'source' => 'FSG_Server_Sessions.' . $cols['app'], 'reason' => 'Most recent account-linked TaskManager session.'];
                task_debug_line('Did I find their most recent server session?', 'YES; sessionId=' . $sid . '; source=' . $result['source'] . '.');
                return $result;
            }
            task_debug_line('Did I find their most recent server session?', 'NO from FSG_Server_Sessions; userId=' . $userId . '; appColumn=' . $cols['app'] . '; no TaskManager row matched.');
        } else {
            $allColumns = [];
            try { $allColumns = array_map(fn($r) => (string)($r['Field'] ?? ''), $pdo->query('SHOW COLUMNS FROM FSG_Server_Sessions')->fetchAll()); } catch (Throwable $e) {}
            task_debug_line('Did I find their most recent server session?', 'NO from FSG_Server_Sessions; table exists=' . (task_table_exists($pdo, 'FSG_Server_Sessions') ? 'YES' : 'NO') . '; app_key/app_name column missing; columns=' . implode(',', $allColumns) . '.');
        }
    } catch (Throwable $e) {
        task_diag_add('latest_task_session from FSG_Server_Sessions failed', ['error' => $e->getMessage()]);
        task_debug_line('Did I find their most recent server session?', 'NO from FSG_Server_Sessions; error=' . $e->getMessage());
    }

    try {
        if (task_table_exists($pdo, 'FSG_TASK_server_sessions')) {
            $stmt = $pdo->prepare('SELECT session_id FROM FSG_TASK_server_sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1');
            $stmt->execute([$userId]);
            $sid = trim((string)($stmt->fetchColumn() ?: ''));
            if ($sid !== '') {
                $result = ['sessionId' => $sid, 'source' => 'FSG_TASK_server_sessions.user_id', 'reason' => 'Fallback to latest TaskManager payload owned by account.'];
                task_debug_line('Did I find their most recent server session?', 'YES; sessionId=' . $sid . '; source=' . $result['source'] . '.');
                return $result;
            }
            task_debug_line('Did I find their most recent server session?', 'NO from FSG_TASK_server_sessions; userId=' . $userId . '; no rows.');
        } else {
            task_debug_line('Did I find their most recent server session?', 'NO from FSG_TASK_server_sessions; table missing after ensureTables.');
        }
    } catch (Throwable $e) {
        task_diag_add('latest_task_session from FSG_TASK_server_sessions failed', ['error' => $e->getMessage()]);
        task_debug_line('Did I find their most recent server session?', 'NO from FSG_TASK_server_sessions; error=' . $e->getMessage());
    }

    $result['reason'] = 'No TaskManager session was found for this account.';
    return $result;
}

function task_latest_task_session_id(PDO $pdo, int $userId): string
{
    $latest = task_latest_task_session($pdo, $userId);
    return (string)($latest['sessionId'] ?? '');
}

function task_first_existing_table(PDO $pdo, array $tableNames): string
{
    foreach ($tableNames as $tableName) {
        if (task_table_exists($pdo, $tableName)) return $tableName;
    }
    return '';
}

function task_order_clause(PDO $pdo, string $tableName): string
{
    $parts = [];
    if (task_column_exists($pdo, $tableName, 'workspace_id')) $parts[] = 'workspace_id DESC';
    if (task_column_exists($pdo, $tableName, 'sort_order')) $parts[] = 'sort_order ASC';
    if (task_column_exists($pdo, $tableName, 'id')) $parts[] = 'id ASC';
    return $parts ? (' ORDER BY ' . implode(', ', $parts)) : '';
}

function task_first_existing_column(PDO $pdo, string $tableName, array $columnNames): string
{
    foreach ($columnNames as $columnName) {
        if (task_column_exists($pdo, $tableName, $columnName)) return $columnName;
    }
    return '';
}

function task_global_lookup_order(PDO $pdo, string $tableName): string
{
    $parts = [];
    if (task_column_exists($pdo, $tableName, 'sort_order')) $parts[] = 'sort_order ASC';
    if (task_column_exists($pdo, $tableName, 'id')) $parts[] = 'id ASC';
    return $parts ? (' ORDER BY ' . implode(', ', $parts)) : '';
}

function task_load_named_global_table(PDO $pdo, string $tableName, int $workspaceId = 0, array $nameColumns = ['item_name', 'character_name', 'name', 'key'], string $debugLabel = ''): array
{
    $label = $debugLabel !== '' ? $debugLabel : $tableName;
    if (!task_table_exists($pdo, $tableName)) {
        task_diag_add($tableName . ' table missing');
        task_debug_line('Did I find any ' . $label . '?', 'NO; checked table=' . $tableName . '; table missing.');
        return [];
    }
    try {
        $nameColumn = task_first_existing_column($pdo, $tableName, $nameColumns);
        if ($nameColumn === '') {
            task_diag_add($tableName . ' has no usable name column', ['checkedColumns' => $nameColumns]);
            task_debug_line('Did I find any ' . $label . '?', 'NO; checked table=' . $tableName . '; no usable name column; checked columns=' . implode(',', $nameColumns) . '.');
            return [];
        }
        $colorExpr = task_column_exists($pdo, $tableName, 'color') ? 'color' : "'#00f2ff'";
        $order = task_global_lookup_order($pdo, $tableName);
        $usedWorkspace = false;
        $fallbackAll = false;
        $rows = [];
        if ($workspaceId > 0 && task_column_exists($pdo, $tableName, 'workspace_id')) {
            $usedWorkspace = true;
            $stmt = $pdo->prepare("SELECT {$nameColumn} AS name, {$colorExpr} AS color FROM {$tableName} WHERE workspace_id = ?{$order}");
            $stmt->execute([$workspaceId]);
            $rows = $stmt->fetchAll();
        }
        if (!$rows) {
            if ($usedWorkspace) {
                $fallbackAll = true;
                task_diag_add($tableName . ' had no rows for workspace_id; falling back to all rows', ['workspaceId' => $workspaceId, 'nameColumn' => $nameColumn]);
            }
            $stmt = $pdo->query("SELECT {$nameColumn} AS name, {$colorExpr} AS color FROM {$tableName}{$order}");
            $rows = $stmt ? $stmt->fetchAll() : [];
        }
        $normalized = $rows ? task_normalize_list($rows) : [];
        task_debug_line('Did I find any ' . $label . '?', ($normalized ? 'YES' : 'NO') . '; checked table=' . $tableName . '; workspaceId=' . $workspaceId . '; nameColumn=' . $nameColumn . '; rows=' . count($normalized) . '; fallbackAllRows=' . ($fallbackAll ? 'YES' : 'NO') . '.');
        if (!$normalized) task_diag_add($tableName . ' exists but returned no usable rows', ['nameColumn' => $nameColumn, 'workspaceId' => $workspaceId]);
        return $normalized;
    } catch (Throwable $e) {
        task_diag_add($tableName . ' query failed', ['error' => $e->getMessage()]);
        task_debug_line('Did I find any ' . $label . '?', 'NO; checked table=' . $tableName . '; error=' . $e->getMessage());
    }
    return [];
}

function task_load_token_global_table(PDO $pdo, string $tableName, int $workspaceId = 0): array
{
    if (!task_table_exists($pdo, $tableName)) {
        task_diag_add($tableName . ' table missing');
        task_debug_line('Did I find any global tokens in the desired database table?', 'NO; checked table=' . $tableName . '; table missing.');
        return [];
    }
    try {
        $keyColumn = task_first_existing_column($pdo, $tableName, ['token_key', 'key', 'item_name', 'name']);
        $valueColumn = task_first_existing_column($pdo, $tableName, ['token_value', 'value', 'item_value']);
        if ($keyColumn === '') {
            task_diag_add($tableName . ' has no usable token key column');
            task_debug_line('Did I find any global tokens in the desired database table?', 'NO; checked table=' . $tableName . '; no usable token key column.');
            return [];
        }
        $valueExpr = $valueColumn !== '' ? $valueColumn : "''";
        $order = task_global_lookup_order($pdo, $tableName);
        $usedWorkspace = false;
        $fallbackAll = false;
        $rows = [];
        if ($workspaceId > 0 && task_column_exists($pdo, $tableName, 'workspace_id')) {
            $usedWorkspace = true;
            $stmt = $pdo->prepare("SELECT {$keyColumn} AS `key`, {$valueExpr} AS `value` FROM {$tableName} WHERE workspace_id = ?{$order}");
            $stmt->execute([$workspaceId]);
            $rows = $stmt->fetchAll();
        }
        if (!$rows) {
            if ($usedWorkspace) {
                $fallbackAll = true;
                task_diag_add($tableName . ' had no rows for workspace_id; falling back to all rows', ['workspaceId' => $workspaceId, 'keyColumn' => $keyColumn]);
            }
            $stmt = $pdo->query("SELECT {$keyColumn} AS `key`, {$valueExpr} AS `value` FROM {$tableName}{$order}");
            $rows = $stmt ? $stmt->fetchAll() : [];
        }
        $rows = array_values(array_filter($rows, fn($row) => trim(task_text($row['key'] ?? '')) !== ''));
        task_debug_line('Did I find any global tokens in the desired database table?', ($rows ? 'YES' : 'NO') . '; checked table=' . $tableName . '; workspaceId=' . $workspaceId . '; keyColumn=' . $keyColumn . '; valueColumn=' . ($valueColumn ?: '(none)') . '; rows=' . count($rows) . '; fallbackAllRows=' . ($fallbackAll ? 'YES' : 'NO') . '.');
        if (!$rows) task_diag_add($tableName . ' exists but returned no usable token rows', ['keyColumn' => $keyColumn, 'workspaceId' => $workspaceId]);
        return $rows;
    } catch (Throwable $e) {
        task_diag_add($tableName . ' query failed', ['error' => $e->getMessage()]);
        task_debug_line('Did I find any global tokens in the desired database table?', 'NO; checked table=' . $tableName . '; error=' . $e->getMessage());
    }
    return [];
}

function task_load_dd_cast_any(PDO $pdo, int $workspaceId = 0): array
{
    $checked = [];
    foreach (['FSG_DD_GlobalCast', 'FSG_DD_Cast'] as $tableName) {
        $checked[] = $tableName;
        if (!task_table_exists($pdo, $tableName)) continue;
        $rows = task_load_named_global_table($pdo, $tableName, $workspaceId, ['character_name', 'item_name', 'name', 'cast_name'], 'global cast');
        if ($rows) {
            task_debug_line('Did I find any global cast?', 'YES; checked table=' . $tableName . '; workspaceId=' . $workspaceId . '; rows=' . count($rows) . '.');
            return $rows;
        }
    }
    task_diag_add('Global Cast table missing or empty', ['checkedTables' => $checked, 'workspaceId' => $workspaceId]);
    task_debug_line('Did I find any global cast?', 'NO; checked tables=' . implode(',', $checked) . '; workspaceId=' . $workspaceId . '; no usable rows.');
    return [];
}

function task_default_values(): array
{
    return [
        'serverSessionId' => '',
        'availableLanguages' => ['ENG'],
        'currentLanguage' => 'ENG',
        'globalTokens' => [],
        'globalCast' => [],
        'globalStates' => [],
        'globalMoods' => [],
        'globalSettings' => [],
        'globalTimesOfDay' => [],
        'globalDaysOfWeek' => [],
        'globalMenuOptions' => [],
        'globalImageSequences' => [],
    ];
}

function task_default_workspace(): array
{
    return [
        'version' => 'TaskManager_2026_06_07',
        'Values' => task_default_values(),
        'Sprites' => [],
        'Registries' => [[
            'id' => task_uuid(),
            'name' => 'Quests',
            'color' => '#ff7a00',
            'entries' => [],
        ]],
    ];
}

function task_uuid(): string
{
    try {
        return bin2hex(random_bytes(4)) . '-' . bin2hex(random_bytes(2)) . '-' . bin2hex(random_bytes(2)) . '-' . bin2hex(random_bytes(2)) . '-' . bin2hex(random_bytes(6));
    } catch (Throwable $e) {
        return 'local-' . time() . '-' . mt_rand(1000, 9999);
    }
}

function task_decode_json(?string $json, array $fallback = []): array
{
    if ($json === null || trim($json) === '') return $fallback;
    $decoded = json_decode($json, true);
    return is_array($decoded) ? $decoded : $fallback;
}

function task_normalize_list(array $items, string $nameKey = 'name'): array
{
    $out = [];
    foreach ($items as $item) {
        if (is_string($item)) {
            $name = trim($item);
            $color = '#00f0ff';
        } else {
            $name = trim(task_text($item[$nameKey] ?? $item['name'] ?? $item['item_name'] ?? $item['character_name'] ?? $item['key'] ?? ''));
            $color = task_text($item['color'] ?? '#00f0ff');
        }
        if ($name === '') continue;
        $out[] = ['name' => $name, 'color' => $color !== '' ? $color : '#00f0ff'];
    }
    return $out;
}

function task_normalize_values(array $values): array
{
    $base = task_default_values();
    $values = array_replace($base, $values);
    $languages = $values['availableLanguages'] ?? $values['languages'] ?? ['ENG'];
    if (!is_array($languages)) $languages = ['ENG'];
    $cleanLanguages = [];
    foreach ($languages as $lang) {
        $code = strtoupper(substr(preg_replace('/[^a-zA-Z0-9_-]/', '', task_text($lang)), 0, 8));
        if ($code !== '' && !in_array($code, $cleanLanguages, true)) $cleanLanguages[] = $code;
    }
    if (!in_array('ENG', $cleanLanguages, true)) array_unshift($cleanLanguages, 'ENG');
    $values['availableLanguages'] = $cleanLanguages;
    $values['currentLanguage'] = in_array(task_text($values['currentLanguage'] ?? 'ENG'), $cleanLanguages, true) ? task_text($values['currentLanguage']) : 'ENG';

    $tokens = [];
    foreach (($values['globalTokens'] ?? []) as $token) {
        if (!is_array($token)) continue;
        $key = trim(task_text($token['key'] ?? $token['token_key'] ?? ''));
        if ($key === '') continue;
        $tokens[] = ['key' => $key, 'value' => task_text($token['value'] ?? $token['token_value'] ?? '')];
    }
    $values['globalTokens'] = $tokens;

    $castSource = $values['globalCast'] ?? $values['cast'] ?? [];
    $values['globalCast'] = is_array($castSource) ? task_normalize_list($castSource) : [];

    foreach (['globalStates', 'globalMoods', 'globalSettings', 'globalTimesOfDay', 'globalDaysOfWeek', 'globalMenuOptions'] as $key) {
        $values[$key] = is_array($values[$key] ?? null) ? task_normalize_list($values[$key]) : [];
    }

    $seqs = [];
    foreach (($values['globalImageSequences'] ?? []) as $seq) {
        if (!is_array($seq)) continue;
        $name = trim(task_text($seq['name'] ?? $seq['sequence_name'] ?? ''));
        if ($name === '') continue;
        $images = [];
        foreach (($seq['images'] ?? []) as $img) {
            $imageName = is_array($img) ? task_text($img['name'] ?? $img['image_name'] ?? $img['file'] ?? '') : task_text($img);
            if (trim($imageName) === '') continue;
            $images[] = ['name' => $imageName];
        }
        $path = task_text($seq['path'] ?? $seq['rootPath'] ?? 'Assets/2D/Sequences/');
        $seqs[] = [
            'id' => task_text($seq['id'] ?? task_uuid()),
            'name' => $name,
            'color' => task_text($seq['color'] ?? '#00f0ff'),
            'path' => $path !== '' ? $path : 'Assets/2D/Sequences/',
            'rootPath' => $path !== '' ? $path : 'Assets/2D/Sequences/',
            'images' => $images,
        ];
    }
    $values['globalImageSequences'] = $seqs;
    return $values;
}

function task_load_app_values(PDO $pdo): array
{
    $values = task_default_values();
    try {
        $stmt = $pdo->prepare("SELECT state_json FROM FSG_TASK_app_state WHERE state_key = 'values' LIMIT 1");
        $stmt->execute();
        $row = $stmt->fetchColumn();
        if ($row !== false) $values = array_replace($values, task_decode_json((string)$row, []));
    } catch (Throwable $e) {}
    return task_normalize_values($values);
}

function task_load_idle_app_values(PDO $pdo): array
{
    if (!task_table_exists($pdo, 'FSG_IDLE_app_state')) return [];
    try {
        $stmt = $pdo->prepare("SELECT state_json FROM FSG_IDLE_app_state WHERE state_key = 'values' LIMIT 1");
        $stmt->execute();
        $json = $stmt->fetchColumn();
        if ($json !== false) return task_normalize_values(task_decode_json((string)$json, []));
    } catch (Throwable $e) {}
    return [];
}

function task_save_idle_app_values(PDO $pdo, array $values): void
{
    if (!task_table_exists($pdo, 'FSG_IDLE_app_state')) return;
    try {
        $values = task_normalize_values($values);
        $stmt = $pdo->prepare("INSERT INTO FSG_IDLE_app_state (state_key, state_json) VALUES ('values', ?) ON DUPLICATE KEY UPDATE state_json = VALUES(state_json), updated_at = CURRENT_TIMESTAMP");
        $stmt->execute([json_encode($values, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
    } catch (Throwable $e) {}
}

function task_load_idle_sprites(PDO $pdo): array
{
    if (!task_table_exists($pdo, 'FSG_IDLE_sprite_directories') || !task_table_exists($pdo, 'FSG_IDLE_sprites')) return [];
    try {
        $dirs = [];
        $stmtDir = $pdo->query("SELECT * FROM FSG_IDLE_sprite_directories ORDER BY sort_order ASC, id ASC");
        foreach (($stmtDir ? $stmtDir->fetchAll() : []) as $dir) {
            $dirId = (string)($dir['id'] ?? '');
            if ($dirId === '') continue;
            $dirs[$dirId] = [
                'id' => $dirId,
                'name' => (string)($dir['name'] ?? 'New Directory'),
                'rootPath' => (string)($dir['rootPath'] ?? $dir['root_path'] ?? $dir['path'] ?? 'Assets/2D/MiniGames/OnlySam/'),
                'sprites' => [],
            ];
        }
        $stmtSpr = $pdo->query("SELECT * FROM FSG_IDLE_sprites ORDER BY sort_order ASC, id ASC");
        foreach (($stmtSpr ? $stmtSpr->fetchAll() : []) as $spr) {
            $dirId = (string)($spr['directory_id'] ?? '');
            if (!isset($dirs[$dirId])) continue;
            $dirs[$dirId]['sprites'][] = [
                'name' => (string)($spr['name'] ?? 'Unnamed Sprite'),
                'file' => (string)($spr['file'] ?? ''),
            ];
        }
        return array_values($dirs);
    } catch (Throwable $e) {
        return [];
    }
}

function task_save_app_values(PDO $pdo, array $values): void
{
    $values = task_normalize_values($values);
    $stmt = $pdo->prepare("INSERT INTO FSG_TASK_app_state (state_key, state_json) VALUES ('values', ?) ON DUPLICATE KEY UPDATE state_json = VALUES(state_json), updated_at = CURRENT_TIMESTAMP");
    $stmt->execute([json_encode($values, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
}

function task_find_dd_workspace(PDO $pdo, int $userId = 0, string $sessionId = ''): ?array
{
    if (!task_table_exists($pdo, 'FSG_DD_Workspaces')) {
        $like = [];
        try { $like = array_map(fn($r) => array_values($r)[0] ?? '', $pdo->query("SHOW TABLES LIKE 'FSG\\_DD\\_%'")->fetchAll(PDO::FETCH_NUM)); } catch (Throwable $e) {}
        task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'NO; FSG_DD_Workspaces table missing in current database; visible FSG_DD tables=' . implode(',', array_filter($like)) . '.');
        return null;
    }
    $sessionId = trim($sessionId);
    try {
        if ($sessionId !== '') {
            $stmt = $pdo->prepare('SELECT * FROM FSG_DD_Workspaces WHERE session_id = ? ORDER BY id DESC LIMIT 1');
            $stmt->execute([$sessionId]);
            $row = $stmt->fetch();
            if ($row) {
                task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'YES; exact DD workspace session_id=' . $sessionId . '; workspaceId=' . (int)($row['id'] ?? 0) . '.');
                return $row;
            }
            task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'NO from exact DD workspace session_id; sessionId=' . $sessionId . '.');
        }
    } catch (Throwable $e) {
        task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'NO from exact DD workspace session_id; error=' . $e->getMessage());
    }

    if ($userId > 0 && function_exists('fsgAuth_listUserSessions')) {
        try {
            $sessions = fsgAuth_listUserSessions($pdo, $userId, 'DialogueDesigner');
            foreach ($sessions as $session) {
                $ddSession = trim(task_text($session['session_id'] ?? ''));
                if ($ddSession === '') continue;
                $stmt = $pdo->prepare('SELECT * FROM FSG_DD_Workspaces WHERE session_id = ? ORDER BY id DESC LIMIT 1');
                $stmt->execute([$ddSession]);
                $row = $stmt->fetch();
                if ($row) {
                    task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'YES; fsgAuth_listUserSessions(DialogueDesigner) sessionId=' . $ddSession . '; workspaceId=' . (int)($row['id'] ?? 0) . '.');
                    return $row;
                }
            }
            task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'NO from fsgAuth_listUserSessions(DialogueDesigner); rows=' . count($sessions) . '.');
        } catch (Throwable $e) {
            task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'NO from fsgAuth_listUserSessions(DialogueDesigner); error=' . $e->getMessage());
        }
    }

    if ($userId > 0 && task_table_exists($pdo, 'FSG_Server_Sessions')) {
        try {
            task_ensure_server_session_schema($pdo);
            $cols = task_server_sessions_columns($pdo);
            if ($cols['app'] !== '') {
                $timeExpr = task_server_sessions_time_expr($cols);
                $whereActive = $cols['isActive'] !== '' ? " AND {$cols['isActive']} = 1" : '';
                $stmt = $pdo->prepare("SELECT session_id FROM FSG_Server_Sessions WHERE user_id = ? AND REPLACE(LOWER({$cols['app']}), ' ', '') = 'dialoguedesigner'{$whereActive} ORDER BY {$timeExpr} DESC, id DESC");
                $stmt->execute([$userId]);
                foreach ($stmt->fetchAll() as $sessionRow) {
                    $ddSession = trim(task_text($sessionRow['session_id'] ?? ''));
                    if ($ddSession === '') continue;
                    $w = $pdo->prepare('SELECT * FROM FSG_DD_Workspaces WHERE session_id = ? ORDER BY id DESC LIMIT 1');
                    $w->execute([$ddSession]);
                    $row = $w->fetch();
                    if ($row) {
                        task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'YES; FSG_Server_Sessions DialogueDesigner sessionId=' . $ddSession . '; workspaceId=' . (int)($row['id'] ?? 0) . '.');
                        return $row;
                    }
                }
                task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'NO from FSG_Server_Sessions DialogueDesigner rows; userId=' . $userId . '.');
            }
        } catch (Throwable $e) {
            task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'NO from FSG_Server_Sessions DialogueDesigner; error=' . $e->getMessage());
        }
    }

    if ($userId > 0 && task_table_exists($pdo, 'FSG_DD_UserSessions')) {
        try {
            $stmt = $pdo->prepare('SELECT w.* FROM FSG_DD_Workspaces w JOIN FSG_DD_UserSessions s ON s.session_id = w.session_id WHERE s.user_id = ? ORDER BY s.last_viewed_at DESC, s.last_pushed_at DESC, w.id DESC LIMIT 1');
            $stmt->execute([$userId]);
            $row = $stmt->fetch();
            if ($row) {
                task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'YES; matched FSG_DD_UserSessions.user_id=' . $userId . '; ddSessionId=' . task_text($row['session_id'] ?? '') . '; workspaceId=' . (int)($row['id'] ?? 0) . '.');
                return $row;
            }
            task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'NO from FSG_DD_UserSessions; userId=' . $userId . '; no joined workspace rows.');
        } catch (Throwable $e) {
            task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'NO from FSG_DD_UserSessions; error=' . $e->getMessage());
        }
    } else if ($userId > 0) {
        task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'NO from FSG_DD_UserSessions; table missing; userId=' . $userId . '.');
    }

    if ($userId > 0 && task_column_exists($pdo, 'FSG_DD_Workspaces', 'user_id')) {
        try {
            $stmt = $pdo->prepare('SELECT * FROM FSG_DD_Workspaces WHERE user_id = ? ORDER BY id DESC LIMIT 1');
            $stmt->execute([$userId]);
            $row = $stmt->fetch();
            if ($row) {
                task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'YES; matched FSG_DD_Workspaces.user_id=' . $userId . '; ddSessionId=' . task_text($row['session_id'] ?? '') . '; workspaceId=' . (int)($row['id'] ?? 0) . '.');
                return $row;
            }
            task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'NO from FSG_DD_Workspaces.user_id; userId=' . $userId . '; no rows.');
        } catch (Throwable $e) {
            task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'NO from FSG_DD_Workspaces.user_id; error=' . $e->getMessage());
        }
    }

    try {
        $stmt = $pdo->query('SELECT * FROM FSG_DD_Workspaces ORDER BY id DESC LIMIT 1');
        $row = $stmt ? $stmt->fetch() : null;
        if ($row) {
            task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'YES; fallback latest FSG_DD_Workspaces row; ddSessionId=' . task_text($row['session_id'] ?? '') . '; workspaceId=' . (int)($row['id'] ?? 0) . '.');
            return $row;
        }
    } catch (Throwable $e) {}
    task_debug_line('Did I find the Dialogue Designer workspace relationship for global values?', 'NO; all DD workspace lookup branches failed.');
    return null;
}

function task_values_from_dd_raw(array $workspace): array
{
    $raw = task_decode_json((string)($workspace['raw_json'] ?? ''), []);
    $values = task_default_values();
    $map = [
        'availableLanguages' => ['availableLanguages', 'languages'],
        'currentLanguage' => ['currentLanguage'],
        'globalTokens' => ['globalTokens'],
        'globalCast' => ['globalCast', 'cast'],
        'globalStates' => ['globalStates'],
        'globalMoods' => ['globalMoods'],
        'globalSettings' => ['globalSettings'],
        'globalTimesOfDay' => ['globalTimesOfDay'],
        'globalDaysOfWeek' => ['globalDaysOfWeek'],
        'globalMenuOptions' => ['globalMenuOptions'],
        'globalImageSequences' => ['globalImageSequences'],
    ];
    foreach ($map as $dest => $sources) {
        foreach ($sources as $src) {
            if (array_key_exists($src, $raw)) {
                $values[$dest] = $raw[$src];
                break;
            }
        }
    }
    if (!empty($workspace['available_languages_json'])) {
        $values['availableLanguages'] = task_decode_json((string)$workspace['available_languages_json'], $values['availableLanguages']);
    }
    if (!empty($workspace['current_language'])) {
        $values['currentLanguage'] = (string)$workspace['current_language'];
    }
    return task_normalize_values($values);
}

function task_merge_nonempty_values(array $base, array $incoming): array
{
    foreach ($incoming as $key => $value) {
        if (is_array($value) && count($value) === 0) continue;
        if (is_string($value) && trim($value) === '') continue;
        $base[$key] = $value;
    }
    return task_normalize_values($base);
}

function task_load_dd_table_values(PDO $pdo, int $workspaceId, array $values): array
{
    try {
        $castRows = task_load_dd_cast_any($pdo, $workspaceId);
        if ($castRows) $values['globalCast'] = $castRows;

        $tokenRows = task_load_token_global_table($pdo, 'FSG_DD_GlobalTokens', $workspaceId);
        if ($tokenRows) $values['globalTokens'] = $tokenRows;

        $globalTables = [
            'globalStates' => 'FSG_DD_GlobalStates',
            'globalMoods' => 'FSG_DD_GlobalMoods',
            'globalSettings' => 'FSG_DD_GlobalSettings',
            'globalTimesOfDay' => 'FSG_DD_GlobalTimesOfDay',
            'globalDaysOfWeek' => 'FSG_DD_GlobalDaysOfWeek',
            'globalMenuOptions' => 'FSG_DD_GlobalMenuOptions',
        ];
        foreach ($globalTables as $key => $table) {
            $rows = task_load_named_global_table($pdo, $table, $workspaceId, ['item_name', 'name', 'key', 'label']);
            if ($rows) $values[$key] = $rows;
        }

        if (task_table_exists($pdo, 'FSG_DD_GlobalImageSequences')) {
            $order = task_order_clause($pdo, 'FSG_DD_GlobalImageSequences');
            $rows = [];
            if ($workspaceId > 0 && task_column_exists($pdo, 'FSG_DD_GlobalImageSequences', 'workspace_id')) {
                $stmt = $pdo->prepare("SELECT * FROM FSG_DD_GlobalImageSequences WHERE workspace_id = ?{$order}");
                $stmt->execute([$workspaceId]);
                $rows = $stmt->fetchAll();
                if (!$rows) task_diag_add('FSG_DD_GlobalImageSequences had no rows for workspace_id; falling back to all rows', ['workspaceId' => $workspaceId]);
            }
            if (!$rows) {
                $stmt = $pdo->query("SELECT * FROM FSG_DD_GlobalImageSequences{$order}");
                $rows = $stmt ? $stmt->fetchAll() : [];
            }
            $seqs = [];
            foreach ($rows as $seq) {
                $raw = task_decode_json((string)($seq['raw_json'] ?? ''), []);
                $images = [];
                if (task_table_exists($pdo, 'FSG_DD_GlobalImageSequenceImages') && isset($seq['id'])) {
                    $imgStmt = $pdo->prepare('SELECT image_name AS name FROM FSG_DD_GlobalImageSequenceImages WHERE image_sequence_id = ? ORDER BY sort_order ASC, id ASC');
                    $imgStmt->execute([(int)$seq['id']]);
                    $images = $imgStmt->fetchAll();
                }
                if (!$images && isset($raw['images']) && is_array($raw['images'])) $images = $raw['images'];
                $name = task_text($seq['sequence_name'] ?? $seq['name'] ?? $raw['name'] ?? $raw['sequence_name'] ?? '');
                if (trim($name) === '') continue;
                $path = task_text($seq['path'] ?? $raw['path'] ?? $raw['rootPath'] ?? '');
                $seqs[] = [
                    'id' => task_text($seq['id'] ?? $raw['id'] ?? task_uuid()),
                    'name' => $name,
                    'color' => task_text($seq['color'] ?? $raw['color'] ?? '#00f2ff'),
                    'path' => $path,
                    'rootPath' => $path,
                    'images' => $images,
                ];
            }
            if ($seqs) $values['globalImageSequences'] = $seqs;
        } else {
            task_diag_add('FSG_DD_GlobalImageSequences table missing');
        }
    } catch (Throwable $e) {
        task_diag_add('task_load_dd_table_values failed', ['error' => $e->getMessage(), 'workspaceId' => $workspaceId]);
    }
    return task_normalize_values($values);
}

function task_load_shared_values(PDO $pdo, int $userId, string $sessionId = ''): array
{
    $values = task_load_app_values($pdo);
    $ddWorkspace = task_find_dd_workspace($pdo, $userId, $sessionId);
    $dialogueSessionId = '';
    if ($ddWorkspace) {
        $dialogueSessionId = (string)($ddWorkspace['session_id'] ?? '');
        $ddValues = task_values_from_dd_raw($ddWorkspace);
        $ddValues = task_load_dd_table_values($pdo, (int)($ddWorkspace['id'] ?? 0), $ddValues);
        $values = task_merge_nonempty_values($values, $ddValues);
    } else {
        task_diag_add('No FSG_DD_Workspaces row found for shared value load; loading shared DD global tables without workspace filter', ['userId' => $userId, 'sessionId' => $sessionId]);
        $values = task_load_dd_table_values($pdo, 0, $values);
    }
    $idleValues = task_load_idle_app_values($pdo);
    if ($idleValues) {
        // Idle Manager owns the Values tab presentation and image/sprite authoring side, so use it as another shared source.
        $values = task_merge_nonempty_values($values, $idleValues);
    }
    if ($sessionId !== '') $values['serverSessionId'] = $sessionId;
    if ($dialogueSessionId !== '') $values['dialogueSessionId'] = $dialogueSessionId;
    return ['Values' => task_normalize_values($values), 'Sprites' => task_load_idle_sprites($pdo), 'dialogueSessionId' => $dialogueSessionId];
}

function task_update_dd_raw_workspace(PDO $pdo, int $workspaceId, array $values): void
{
    if ($workspaceId <= 0 || !task_table_exists($pdo, 'FSG_DD_Workspaces')) return;
    $stmt = $pdo->prepare('SELECT raw_json FROM FSG_DD_Workspaces WHERE id = ? LIMIT 1');
    $stmt->execute([$workspaceId]);
    $raw = task_decode_json((string)($stmt->fetchColumn() ?: ''), []);
    $values = task_normalize_values($values);
    $raw['availableLanguages'] = $values['availableLanguages'];
    $raw['currentLanguage'] = $values['currentLanguage'];
    $raw['globalTokens'] = $values['globalTokens'];
    $raw['globalCast'] = $values['globalCast'];
    $raw['cast'] = $values['globalCast'];
    $raw['globalStates'] = $values['globalStates'];
    $raw['globalMoods'] = $values['globalMoods'];
    $raw['globalSettings'] = $values['globalSettings'];
    $raw['globalTimesOfDay'] = $values['globalTimesOfDay'];
    $raw['globalDaysOfWeek'] = $values['globalDaysOfWeek'];
    $raw['globalMenuOptions'] = $values['globalMenuOptions'];
    $raw['globalImageSequences'] = $values['globalImageSequences'];
    $availableJson = json_encode($values['availableLanguages'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $rawJson = json_encode($raw, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $pdo->prepare('UPDATE FSG_DD_Workspaces SET current_language = ?, available_languages_json = ?, raw_json = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')->execute([$values['currentLanguage'], $availableJson, $rawJson, $workspaceId]);
}

function task_replace_dd_tables(PDO $pdo, int $workspaceId, array $values): void
{
    if ($workspaceId <= 0) return;
    $values = task_normalize_values($values);
    try {
        $castTable = task_first_existing_table($pdo, ['FSG_DD_GlobalCast', 'FSG_DD_Cast']);
        if ($castTable !== '') {
            $castNameColumn = task_first_existing_column($pdo, $castTable, ['character_name', 'item_name', 'name', 'cast_name']);
            if ($castNameColumn !== '') {
                if (task_column_exists($pdo, $castTable, 'workspace_id')) {
                    $pdo->prepare("DELETE FROM {$castTable} WHERE workspace_id = ?")->execute([$workspaceId]);
                } else {
                    $pdo->exec("DELETE FROM {$castTable}");
                }
                $insertColumns = [];
                $placeholders = [];
                $staticValues = [];
                if (task_column_exists($pdo, $castTable, 'workspace_id')) { $insertColumns[] = 'workspace_id'; $placeholders[] = '?'; $staticValues[] = $workspaceId; }
                if (task_column_exists($pdo, $castTable, 'sort_order')) { $insertColumns[] = 'sort_order'; $placeholders[] = '?'; }
                $insertColumns[] = $castNameColumn; $placeholders[] = '?';
                if (task_column_exists($pdo, $castTable, 'color')) { $insertColumns[] = 'color'; $placeholders[] = '?'; }
                if (task_column_exists($pdo, $castTable, 'raw_json')) { $insertColumns[] = 'raw_json'; $placeholders[] = '?'; }
                $stmt = $pdo->prepare("INSERT INTO {$castTable} (" . implode(', ', $insertColumns) . ") VALUES (" . implode(', ', $placeholders) . ")");
                foreach ($values['globalCast'] as $i => $item) {
                    $rowValues = $staticValues;
                    if (task_column_exists($pdo, $castTable, 'sort_order')) $rowValues[] = $i;
                    $rowValues[] = $item['name'];
                    if (task_column_exists($pdo, $castTable, 'color')) $rowValues[] = $item['color'];
                    if (task_column_exists($pdo, $castTable, 'raw_json')) $rowValues[] = json_encode($item, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                    $stmt->execute($rowValues);
                }
            }
        }
        if (task_table_exists($pdo, 'FSG_DD_GlobalTokens')) {
            $pdo->prepare('DELETE FROM FSG_DD_GlobalTokens WHERE workspace_id = ?')->execute([$workspaceId]);
            $stmt = $pdo->prepare('INSERT INTO FSG_DD_GlobalTokens (workspace_id, sort_order, token_key, token_value, raw_json) VALUES (?, ?, ?, ?, ?)');
            foreach ($values['globalTokens'] as $i => $item) $stmt->execute([$workspaceId, $i, $item['key'], $item['value'], json_encode($item, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
        }
        $globalTables = [
            'globalStates' => 'FSG_DD_GlobalStates',
            'globalMoods' => 'FSG_DD_GlobalMoods',
            'globalSettings' => 'FSG_DD_GlobalSettings',
            'globalTimesOfDay' => 'FSG_DD_GlobalTimesOfDay',
            'globalDaysOfWeek' => 'FSG_DD_GlobalDaysOfWeek',
            'globalMenuOptions' => 'FSG_DD_GlobalMenuOptions',
        ];
        foreach ($globalTables as $key => $table) {
            if (!task_table_exists($pdo, $table)) continue;
            $pdo->prepare("DELETE FROM {$table} WHERE workspace_id = ?")->execute([$workspaceId]);
            $stmt = $pdo->prepare("INSERT INTO {$table} (workspace_id, sort_order, item_name, color, raw_json) VALUES (?, ?, ?, ?, ?)");
            foreach ($values[$key] as $i => $item) $stmt->execute([$workspaceId, $i, $item['name'], $item['color'], json_encode($item, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
        }
        if (task_table_exists($pdo, 'FSG_DD_GlobalImageSequences')) {
            $oldIds = [];
            $stmtOld = $pdo->prepare('SELECT id FROM FSG_DD_GlobalImageSequences WHERE workspace_id = ?');
            $stmtOld->execute([$workspaceId]);
            foreach ($stmtOld->fetchAll() as $row) $oldIds[] = (int)$row['id'];
            if ($oldIds && task_table_exists($pdo, 'FSG_DD_GlobalImageSequenceImages')) {
                $placeholders = implode(',', array_fill(0, count($oldIds), '?'));
                $pdo->prepare("DELETE FROM FSG_DD_GlobalImageSequenceImages WHERE image_sequence_id IN ({$placeholders})")->execute($oldIds);
            }
            $pdo->prepare('DELETE FROM FSG_DD_GlobalImageSequences WHERE workspace_id = ?')->execute([$workspaceId]);
            $seqStmt = $pdo->prepare('INSERT INTO FSG_DD_GlobalImageSequences (workspace_id, sort_order, sequence_name, color, path, raw_json) VALUES (?, ?, ?, ?, ?, ?)');
            $imgStmt = task_table_exists($pdo, 'FSG_DD_GlobalImageSequenceImages') ? $pdo->prepare('INSERT INTO FSG_DD_GlobalImageSequenceImages (image_sequence_id, sort_order, image_name) VALUES (?, ?, ?)') : null;
            foreach ($values['globalImageSequences'] as $i => $seq) {
                $seqStmt->execute([$workspaceId, $i, $seq['name'], $seq['color'], $seq['path'], json_encode($seq, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
                $seqId = (int)$pdo->lastInsertId();
                if ($imgStmt) {
                    foreach (($seq['images'] ?? []) as $j => $img) $imgStmt->execute([$seqId, $j, task_text(is_array($img) ? ($img['name'] ?? $img['image_name'] ?? '') : $img)]);
                }
            }
        }
    } catch (Throwable $e) {}
}

function task_save_shared_values(PDO $pdo, array $values, int $userId, string $sessionId = ''): array
{
    $values = task_normalize_values($values);
    if ($sessionId !== '') $values['serverSessionId'] = $sessionId;
    task_save_app_values($pdo, $values);
    task_save_idle_app_values($pdo, $values);
    $ddWorkspace = task_find_dd_workspace($pdo, $userId, $sessionId);
    $savedToDialogueDesigner = false;
    $dialogueSessionId = '';
    if ($ddWorkspace) {
        $workspaceId = (int)$ddWorkspace['id'];
        task_update_dd_raw_workspace($pdo, $workspaceId, $values);
        task_replace_dd_tables($pdo, $workspaceId, $values);
        $savedToDialogueDesigner = true;
        $dialogueSessionId = (string)($ddWorkspace['session_id'] ?? '');
    }
    return ['Values' => $values, 'savedToDialogueDesigner' => $savedToDialogueDesigner, 'dialogueSessionId' => $dialogueSessionId];
}


function task_values_has_author_data(array $values): bool
{
    foreach (['globalTokens','globalCast','globalStates','globalMoods','globalSettings','globalTimesOfDay','globalDaysOfWeek','globalMenuOptions','globalImageSequences'] as $key) {
        if (isset($values[$key]) && is_array($values[$key]) && count($values[$key]) > 0) return true;
    }
    return false;
}

function task_merge_shared_into_missing_values(array $payloadValues, array $sharedValues): array
{
    $payloadValues = task_normalize_values($payloadValues);
    $sharedValues = task_normalize_values($sharedValues);
    foreach ($sharedValues as $key => $value) {
        if ($key === 'serverSessionId') continue;
        if (is_array($value)) {
            if ((!isset($payloadValues[$key]) || !is_array($payloadValues[$key]) || count($payloadValues[$key]) === 0) && count($value) > 0) {
                $payloadValues[$key] = $value;
            }
        } elseif (!isset($payloadValues[$key]) || task_text($payloadValues[$key]) === '') {
            $payloadValues[$key] = $value;
        }
    }
    return task_normalize_values($payloadValues);
}

function task_session_id(array $payload, string $querySessionId = ''): string
{
    $querySessionId = trim($querySessionId);
    if ($querySessionId !== '') return $querySessionId;
    $candidates = [
        $payload['sessionId'] ?? null,
        $payload['serverSessionId'] ?? null,
        $payload['Values']['serverSessionId'] ?? null,
    ];
    foreach ($candidates as $candidate) {
        $sid = trim(task_text($candidate));
        if ($sid !== '') return $sid;
    }
    return 'TASK-' . strtoupper(bin2hex(random_bytes(4))) . '-' . strtoupper(base_convert((string)time(), 10, 36));
}

function task_save_payload(PDO $pdo, string $sessionId, int $userId, array $payload): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_TASK_server_sessions (session_id, user_id, payload_json) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), payload_json = VALUES(payload_json), updated_at = CURRENT_TIMESTAMP');
    $stmt->execute([$sessionId, $userId > 0 ? $userId : null, json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
}

function task_load_payload(PDO $pdo, string $sessionId = '', int $userId = 0): ?array
{
    $loaded = task_load_payload_with_meta($pdo, $sessionId, $userId);
    return $loaded['payload'];
}

function task_load_payload_with_meta(PDO $pdo, string $sessionId = '', int $userId = 0): array
{
    $meta = ['payload' => null, 'source' => '', 'sessionId' => $sessionId, 'found' => false, 'reason' => 'No payload found.'];
    try {
        if ($sessionId !== '') {
            $stmt = $pdo->prepare('SELECT payload_json FROM FSG_TASK_server_sessions WHERE session_id = ? LIMIT 1');
            $stmt->execute([$sessionId]);
            $json = $stmt->fetchColumn();
            if ($json !== false) {
                $meta['payload'] = task_decode_json((string)$json, []);
                $meta['source'] = 'FSG_TASK_server_sessions.session_id';
                $meta['found'] = true;
                $meta['reason'] = 'Loaded by explicit server session id.';
                task_debug_line('Did I load that server session into the current session and into the left side bar Values tab inside the Server State?', 'YES; loaded payload for sessionId=' . $sessionId . '; source=' . $meta['source'] . '.');
                return $meta;
            }
            task_debug_line('Did I load that server session into the current session and into the left side bar Values tab inside the Server State?', 'NO payload yet; checked FSG_TASK_server_sessions.session_id=' . $sessionId . '; no row.');
        }
        if ($userId > 0) {
            $stmt = $pdo->prepare('SELECT session_id, payload_json FROM FSG_TASK_server_sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1');
            $stmt->execute([$userId]);
            $row = $stmt->fetch();
            if ($row && isset($row['payload_json'])) {
                $meta['payload'] = task_decode_json((string)$row['payload_json'], []);
                $meta['source'] = 'FSG_TASK_server_sessions.user_id';
                $meta['sessionId'] = task_text($row['session_id'] ?? $sessionId);
                $meta['found'] = true;
                $meta['reason'] = 'Loaded latest payload by logged-in user id.';
                task_debug_line('Did I load that server session into the current session and into the left side bar Values tab inside the Server State?', 'YES; loaded latest payload by userId=' . $userId . '; sessionId=' . $meta['sessionId'] . '; source=' . $meta['source'] . '.');
                return $meta;
            }
        }
    } catch (Throwable $e) {
        task_diag_add('task_load_payload failed', ['error' => $e->getMessage(), 'sessionId' => $sessionId, 'userId' => $userId]);
        task_debug_line('Did I load that server session into the current session and into the left side bar Values tab inside the Server State?', 'NO; payload query error=' . $e->getMessage());
    }
    return $meta;
}

function task_record_session(PDO $pdo, int $userId, string $sessionId, bool $pushed): void
{
    if ($sessionId === '') return;
    try {
        if (function_exists('fsgAuth_touchServerSession') && $userId > 0) {
            try { fsgAuth_touchServerSession($pdo, $userId, 'TaskManager', $sessionId, $pushed ? 'push' : 'view'); } catch (Throwable $e) { task_diag_add('fsgAuth_touchServerSession(TaskManager) failed', ['error' => $e->getMessage(), 'sessionId' => $sessionId]); }
        }
        task_ensure_server_session_schema($pdo);
        $cols = task_server_sessions_columns($pdo);
        if ($cols['app'] === '') return;
        $insertCols = ['user_id', $cols['app'], 'session_id'];
        $valuesSql = ['?', '?', '?'];
        $params = [$userId > 0 ? $userId : null, 'TaskManager', $sessionId];
        if ($cols['lastViewed'] !== '') { $insertCols[] = $cols['lastViewed']; $valuesSql[] = 'CURRENT_TIMESTAMP'; }
        if ($cols['lastPushed'] !== '') { $insertCols[] = $cols['lastPushed']; $valuesSql[] = $pushed ? 'CURRENT_TIMESTAMP' : 'NULL'; }
        if ($cols['payloadTable'] !== '') { $insertCols[] = $cols['payloadTable']; $valuesSql[] = '?'; $params[] = 'FSG_TASK_server_sessions'; }
        if ($cols['isActive'] !== '') { $insertCols[] = $cols['isActive']; $valuesSql[] = '1'; }
        $updates = ['user_id = VALUES(user_id)'];
        if ($cols['lastViewed'] !== '') $updates[] = "{$cols['lastViewed']} = CURRENT_TIMESTAMP";
        if ($cols['lastPushed'] !== '') $updates[] = "{$cols['lastPushed']} = " . ($pushed ? 'CURRENT_TIMESTAMP' : $cols['lastPushed']);
        if ($cols['payloadTable'] !== '') $updates[] = "{$cols['payloadTable']} = 'FSG_TASK_server_sessions'";
        if ($cols['isActive'] !== '') $updates[] = "{$cols['isActive']} = 1";
        $sql = 'INSERT INTO FSG_Server_Sessions (`' . implode('`,`', $insertCols) . '`) VALUES (' . implode(',', $valuesSql) . ') ON DUPLICATE KEY UPDATE ' . implode(', ', $updates);
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
    } catch (Throwable $e) { task_diag_add('task_record_session failed', ['error' => $e->getMessage(), 'sessionId' => $sessionId]); }
}

function task_account_sessions(PDO $pdo, int $userId): array
{
    if ($userId <= 0) return [];
    $sessions = [];
    try {
        if (function_exists('fsgAuth_listUserSessions')) {
            foreach (fsgAuth_listUserSessions($pdo, $userId, 'TaskManager') as $row) {
                $sid = (string)($row['session_id'] ?? '');
                if ($sid !== '') $sessions['TaskManager:' . $sid] = ['app_name' => 'TaskManager'] + $row;
            }
        }
    } catch (Throwable $e) { task_diag_add('task_account_sessions fsgAuth_listUserSessions failed', ['error' => $e->getMessage()]); }
    try {
        task_ensure_server_session_schema($pdo);
        $cols = task_server_sessions_columns($pdo);
        if ($cols['app'] !== '') {
            $firstExpr = $cols['first'] !== '' ? $cols['first'] : 'NULL';
            $viewExpr = $cols['lastViewed'] !== '' ? $cols['lastViewed'] : 'NULL';
            $pushExpr = $cols['lastPushed'] !== '' ? $cols['lastPushed'] : 'NULL';
            $whereActive = $cols['isActive'] !== '' ? " AND {$cols['isActive']} = 1" : '';
            $timeExpr = task_server_sessions_time_expr($cols);
            $stmt = $pdo->prepare("SELECT {$cols['app']} AS app_name, session_id, {$firstExpr} AS first_used_at, {$viewExpr} AS last_viewed_at, {$pushExpr} AS last_pushed_at FROM FSG_Server_Sessions WHERE user_id = ?{$whereActive} ORDER BY {$timeExpr} DESC, id DESC");
            $stmt->execute([$userId]);
            foreach ($stmt->fetchAll() as $row) {
                $app = (string)($row['app_name'] ?? 'TaskManager');
                $sid = (string)($row['session_id'] ?? '');
                if ($sid !== '') $sessions[$app . ':' . $sid] = $row;
            }
        }
    } catch (Throwable $e) { task_diag_add('task_account_sessions from FSG_Server_Sessions failed', ['error' => $e->getMessage()]); }
    try {
        if (task_table_exists($pdo, 'FSG_TASK_server_sessions')) {
            $stmt = $pdo->prepare("SELECT 'TaskManager' AS app_name, session_id, created_at AS first_used_at, updated_at AS last_viewed_at, updated_at AS last_pushed_at FROM FSG_TASK_server_sessions WHERE user_id = ? ORDER BY updated_at DESC");
            $stmt->execute([$userId]);
            foreach ($stmt->fetchAll() as $row) {
                $sessions[$row['app_name'] . ':' . $row['session_id']] = $row;
            }
        }
    } catch (Throwable $e) { task_diag_add('task_account_sessions from FSG_TASK_server_sessions failed', ['error' => $e->getMessage()]); }
    $out = array_values($sessions);
    usort($out, function(array $a, array $b): int {
        $at = strtotime((string)($a['last_pushed_at'] ?? $a['last_viewed_at'] ?? $a['first_used_at'] ?? '')) ?: 0;
        $bt = strtotime((string)($b['last_pushed_at'] ?? $b['last_viewed_at'] ?? $b['first_used_at'] ?? '')) ?: 0;
        return $bt <=> $at;
    });
    return $out;
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
        task_json(['ok' => false, 'error' => 'Only GET, POST, and OPTIONS are supported.'], 405);
    }

    $pdo = task_pdo();
    task_ensure_tables($pdo);
    $userId = task_user_id($pdo);
    $action = task_text($_GET['action'] ?? 'health');
    $body = $_SERVER['REQUEST_METHOD'] === 'POST' ? task_body() : [];
    if ($action === '' && isset($body['action'])) $action = task_text($body['action']);
    $querySessionId = trim(task_text($_GET['sessionId'] ?? $_GET['serverSessionId'] ?? ''));

    if ($action === 'health') {
        task_json(task_payload_with_debug(['ok' => true, 'api' => 'TaskManager', 'database' => 'connected', 'loggedIn' => $userId > 0, 'sessionHours' => 12]));
    }

    if ($action === 'accountStatus') {
        $user = task_current_user($pdo, $userId);
        task_debug_line('Did I find the users account was already logged in, then log in for them?', ($userId > 0 ? 'YES; userId=' . $userId . '; username=' . task_text($user['username'] ?? '') . '.' : 'NO; shared auth returned no active userId.'));
        $latest = task_latest_task_session($pdo, $userId);
        task_json(task_payload_with_debug(['ok' => true, 'loggedIn' => $userId > 0, 'user' => $user, 'latestSessionId' => $latest['sessionId'], 'latestSessionSource' => $latest['source'], 'latestSessionReason' => $latest['reason'], 'sessions' => task_account_sessions($pdo, $userId)]));
    }

    if ($action === 'login') {
        if (!function_exists('fsgAuth_loginAccount')) task_json(['ok' => false, 'error' => 'Shared auth is not installed.'], 500);
        $payload = fsgAuth_loginAccount($pdo, $body);
        $authUserId = (int)($payload['user']['id'] ?? 0);
        $latest = task_latest_task_session($pdo, $authUserId);
        $payload['ok'] = true;
        $payload['latestSessionId'] = $latest['sessionId'];
        $payload['latestSessionSource'] = $latest['source'];
        $payload['latestSessionReason'] = $latest['reason'];
        $payload['sessions'] = task_account_sessions($pdo, $authUserId);
        task_json(task_payload_with_debug($payload));
    }

    if ($action === 'register') {
        if (!function_exists('fsgAuth_registerAccount')) task_json(['ok' => false, 'error' => 'Shared auth is not installed.'], 500);
        $payload = fsgAuth_registerAccount($pdo, $body);
        $authUserId = (int)($payload['user']['id'] ?? 0);
        $latest = task_latest_task_session($pdo, $authUserId);
        $payload['ok'] = true;
        $payload['latestSessionId'] = $latest['sessionId'];
        $payload['latestSessionSource'] = $latest['source'];
        $payload['latestSessionReason'] = $latest['reason'];
        $payload['sessions'] = task_account_sessions($pdo, $authUserId);
        task_json(task_payload_with_debug($payload));
    }

    if ($action === 'updateProfile') {
        if (!function_exists('fsgAuth_updateProfile')) task_json(['ok' => false, 'error' => 'Shared auth is not installed.'], 500);
        $payload = fsgAuth_updateProfile($pdo, $body);
        $authUserId = (int)($payload['user']['id'] ?? 0);
        $latest = task_latest_task_session($pdo, $authUserId);
        $payload['ok'] = true;
        $payload['latestSessionId'] = $latest['sessionId'];
        $payload['latestSessionSource'] = $latest['source'];
        $payload['latestSessionReason'] = $latest['reason'];
        $payload['sessions'] = task_account_sessions($pdo, $authUserId);
        task_json(task_payload_with_debug($payload));
    }

    if ($action === 'changePassword') {
        if (!function_exists('fsgAuth_changePassword')) task_json(['ok' => false, 'error' => 'Shared auth is not installed.'], 500);
        $payload = fsgAuth_changePassword($pdo, $body);
        $authUserId = (int)($payload['user']['id'] ?? 0);
        $payload['ok'] = true;
        $payload['sessions'] = task_account_sessions($pdo, $authUserId);
        task_json(task_payload_with_debug($payload));
    }

    if ($action === 'logout') {
        if (function_exists('fsgAuth_logout')) fsgAuth_logout($pdo);
        task_json(['ok' => true, 'loggedIn' => false]);
    }

    if ($action === 'loadSharedDialogueValues') {
        task_debug_line('Did I find the users account was already logged in, then log in for them?', ($userId > 0 ? 'YES; userId=' . $userId . '.' : 'NO; userId=0 while loading shared values.'));
        $result = task_load_shared_values($pdo, $userId, $querySessionId);
        task_json(task_payload_with_debug(['ok' => true] + $result));
    }

    if ($action === 'saveSharedDialogueValues') {
        $values = is_array($body['Values'] ?? null) ? $body['Values'] : (is_array($body['values'] ?? null) ? $body['values'] : []);
        $sessionId = task_session_id($body, $querySessionId);
        $result = task_save_shared_values($pdo, $values, $userId, $sessionId);
        if ($userId > 0) task_record_session($pdo, $userId, $sessionId, false);
        task_json(task_payload_with_debug(['ok' => true, 'sessionId' => $sessionId] + $result));
    }

    if ($action === 'loadSession') {
        if ($querySessionId === '') task_json(task_payload_with_debug(['ok' => false, 'error' => 'Missing sessionId.']), 400);
        task_debug_line('Did I find the users account was already logged in, then log in for them?', ($userId > 0 ? 'YES; userId=' . $userId . '.' : 'NO; manual load is running without a logged-in user.'));
        $loaded = task_load_payload_with_meta($pdo, $querySessionId, $userId);
        $payload = is_array($loaded['payload']) ? $loaded['payload'] : task_default_workspace();
        if (!$loaded['found']) task_debug_line('Did I load that server session into the current session and into the left side bar Values tab inside the Server State?', 'PARTIAL; no TaskManager payload row existed, but Server State will still use requested sessionId=' . $querySessionId . ' and hydrate shared Values.');
        $shared = task_load_shared_values($pdo, $userId, $querySessionId);
        $payloadValues = is_array($payload['Values'] ?? null) ? $payload['Values'] : (is_array($payload['values'] ?? null) ? $payload['values'] : []);
        $payload['Values'] = task_merge_nonempty_values(task_normalize_values($payloadValues), $shared['Values']);
        $payload['Values']['serverSessionId'] = $querySessionId;
        if (!empty($shared['dialogueSessionId'])) $payload['Values']['dialogueSessionId'] = $shared['dialogueSessionId'];
        if (empty($payload['Sprites']) && !empty($shared['Sprites'])) $payload['Sprites'] = $shared['Sprites'];
        task_record_session($pdo, $userId, $querySessionId, false);
        task_debug_line('Did I load that server session into the current session and into the left side bar Values tab inside the Server State?', 'YES; current Server State=' . $querySessionId . '; tokens=' . count($payload['Values']['globalTokens']) . '; cast=' . count($payload['Values']['globalCast']) . '; sprites=' . count($payload['Sprites'] ?? []) . '.');
        task_json(task_payload_with_debug(['ok' => true, 'sessionId' => $querySessionId, 'workspace' => $payload, 'Values' => $payload['Values'], 'Sprites' => $payload['Sprites'] ?? [], 'dialogueSessionId' => $shared['dialogueSessionId'], 'payloadSource' => $loaded['source'], 'payloadFound' => $loaded['found']]));
    }

    if ($action === 'loadLatest') {
        task_debug_line('Did I find the users account was already logged in, then log in for them?', ($userId > 0 ? 'YES; userId=' . $userId . '.' : 'NO; loadLatest is running without a logged-in user.'));
        $latest = ['sessionId' => $querySessionId, 'source' => 'queryString', 'reason' => 'Explicit query session id.'];
        if ($querySessionId === '') $latest = task_latest_task_session($pdo, $userId);
        $sessionId = trim(task_text($latest['sessionId'] ?? ''));
        $loaded = task_load_payload_with_meta($pdo, $sessionId, $userId);
        $payload = is_array($loaded['payload']) ? $loaded['payload'] : task_default_workspace();
        if ($sessionId === '') {
            $sessionId = trim(task_text($payload['Values']['serverSessionId'] ?? $payload['serverSessionId'] ?? ''));
            if ($sessionId === '') task_debug_line('Did I load that server session into the current session and into the left side bar Values tab inside the Server State?', 'NO; no account-linked TaskManager server session was found, so I did not generate a fake server state id during auto-load.');
        }
        $shared = task_load_shared_values($pdo, $userId, $sessionId);
        $payloadValues = is_array($payload['Values'] ?? null) ? $payload['Values'] : (is_array($payload['values'] ?? null) ? $payload['values'] : []);
        $payload['Values'] = task_merge_nonempty_values(task_normalize_values($payloadValues), $shared['Values']);
        $payload['Values']['serverSessionId'] = $sessionId;
        if (!empty($shared['dialogueSessionId'])) $payload['Values']['dialogueSessionId'] = $shared['dialogueSessionId'];
        if (empty($payload['Sprites']) && !empty($shared['Sprites'])) $payload['Sprites'] = $shared['Sprites'];
        task_record_session($pdo, $userId, $sessionId, false);
        task_debug_line('Did I load that server session into the current session and into the left side bar Values tab inside the Server State?', (($loaded['found'] || $sessionId !== '') ? 'YES' : 'NO') . '; current Server State=' . $sessionId . '; latestSource=' . task_text($latest['source'] ?? '') . '; payloadFound=' . ($loaded['found'] ? 'YES' : 'NO') . '; tokens=' . count($payload['Values']['globalTokens']) . '; cast=' . count($payload['Values']['globalCast']) . '; sprites=' . count($payload['Sprites'] ?? []) . '.');
        task_json(task_payload_with_debug(['ok' => true, 'sessionId' => $sessionId, 'workspace' => $payload, 'Values' => $payload['Values'], 'Sprites' => $payload['Sprites'] ?? [], 'dialogueSessionId' => $shared['dialogueSessionId'], 'latestSessionSource' => $latest['source'], 'latestSessionReason' => $latest['reason'], 'payloadSource' => $loaded['source'], 'payloadFound' => $loaded['found']]));
    }

    if ($action === 'saveSession') {
        if ($userId <= 0) task_json(['ok' => false, 'error' => 'You must be logged in to push Task Manager data to the server.'], 401);
        $payload = $body ?: task_default_workspace();
        $sessionId = task_session_id($payload, $querySessionId);
        if (!isset($payload['Values']) || !is_array($payload['Values'])) $payload['Values'] = is_array($payload['values'] ?? null) ? $payload['values'] : task_default_values();
        $payload['Values']['serverSessionId'] = $sessionId;
        $payload['Values'] = task_normalize_values($payload['Values']);
        task_save_payload($pdo, $sessionId, $userId, $payload);
        task_save_shared_values($pdo, $payload['Values'], $userId, $sessionId);
        task_record_session($pdo, $userId, $sessionId, true);
        task_json(task_payload_with_debug(['ok' => true, 'sessionId' => $sessionId, 'workspace' => $payload, 'sessions' => task_account_sessions($pdo, $userId)]));
    }

    task_json(task_payload_with_debug(['ok' => false, 'error' => 'Unknown TaskManager action.']), 404);
} catch (Throwable $e) {
    task_json(task_payload_with_debug(['ok' => false, 'status' => 'error', 'message' => $e->getMessage()]), 500);
}
