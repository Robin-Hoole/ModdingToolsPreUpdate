'use strict';

const APP = {
  schemaVersion: '1.0.0',
  storageKey: 'FSG_UngodlyAI_Project',
  endpoint: 'UngodlyAIDesigner.php',
  activeTab: 'sheet',
  selectedProfileId: null,
  curveDragPoint: null,
  modalCommit: null,
  dirty: false,
  project: null
};

const ENTITY_TIERS = ['god', 'creature', 'villager', 'village'];
const LEASH_CONTEXTS = ['off_leash', 'on_leash', 'either'];
const CURVE_TYPES = ['linear', 'ease_in', 'ease_out', 'sigmoid', 'custom'];
const VALUE_TYPES = ['boolean', 'number', 'string', 'entity_id', 'vector3', 'tag_set'];

function uid(prefix) {
  const random = crypto.getRandomValues(new Uint32Array(2));
  return `${prefix}_${Date.now().toString(36)}_${random[0].toString(36)}${random[1].toString(36)}`;
}

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

function clamp(value, min = 0, max = 1) {
  return Math.min(max, Math.max(min, Number(value) || 0));
}

function slugify(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '') || 'untitled';
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatLabel(value) {
  return String(value || '')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, letter => letter.toUpperCase());
}

function nowIso() {
  return new Date().toISOString();
}

function createDefaultProject() {
  const projectId = uid('ai_project');
  const creatureProfileId = uid('profile');
  const villagerProfileId = uid('profile');
  const villageProfileId = uid('profile');
  const godProfileId = uid('profile');

  const priorities = [
    {
      id: uid('driver'),
      key: 'hunger',
      name: 'Hunger',
      description: 'Raises the desire to acquire and consume food.',
      baseWeight: 1.0,
      evaluationInterval: 1.0,
      inputKey: 'need.hunger',
      curveType: 'sigmoid',
      curvePoints: [{x:0,y:0.02},{x:0.25,y:0.08},{x:0.5,y:0.38},{x:0.75,y:0.84},{x:1,y:1}],
      contexts: { off_leash: 1.15, on_leash: 0.95 },
      enabled: true
    },
    {
      id: uid('driver'),
      key: 'curiosity',
      name: 'Explore Curiosity',
      description: 'Rewards examining unfamiliar places, objects, and events.',
      baseWeight: 0.8,
      evaluationInterval: 2.5,
      inputKey: 'need.curiosity',
      curveType: 'ease_out',
      curvePoints: [{x:0,y:0},{x:0.25,y:0.46},{x:0.5,y:0.73},{x:0.75,y:0.91},{x:1,y:1}],
      contexts: { off_leash: 1.5, on_leash: 0.45 },
      enabled: true
    },
    {
      id: uid('driver'),
      key: 'obedience',
      name: 'Obedience',
      description: 'Raises the value of following the god, leash direction, and demonstrated behavior.',
      baseWeight: 0.7,
      evaluationInterval: 0.5,
      inputKey: 'relationship.obedience',
      curveType: 'linear',
      curvePoints: [{x:0,y:0},{x:0.25,y:0.25},{x:0.5,y:0.5},{x:0.75,y:0.75},{x:1,y:1}],
      contexts: { off_leash: 0.45, on_leash: 2.0 },
      enabled: true
    },
    {
      id: uid('driver'),
      key: 'fear',
      name: 'Fear',
      description: 'Prioritizes fleeing, seeking protection, or appeasing a threat.',
      baseWeight: 1.1,
      evaluationInterval: 0.25,
      inputKey: 'need.fear',
      curveType: 'ease_in',
      curvePoints: [{x:0,y:0},{x:0.25,y:0.03},{x:0.5,y:0.18},{x:0.75,y:0.52},{x:1,y:1}],
      contexts: { off_leash: 1.0, on_leash: 0.9 },
      enabled: true
    },
    {
      id: uid('driver'),
      key: 'town_duty',
      name: 'Town Duty',
      description: 'Values assigned work, communal shortages, defense, and construction.',
      baseWeight: 0.9,
      evaluationInterval: 2.0,
      inputKey: 'duty.urgency',
      curveType: 'linear',
      curvePoints: [{x:0,y:0},{x:0.25,y:0.25},{x:0.5,y:0.5},{x:0.75,y:0.75},{x:1,y:1}],
      contexts: { off_leash: 1.0, on_leash: 1.0 },
      enabled: true
    }
  ];

  const goals = [
    {
      id: uid('goal'), key: 'satisfy_hunger', name: 'Satisfy Hunger', tier: 'creature', driverKey: 'hunger',
      desiredState: [{ key: 'need.hunger', operator: '<=', value: 0.25 }],
      baseBias: 0.15, cooldownSeconds: 2, enabled: true, tags: ['survival']
    },
    {
      id: uid('goal'), key: 'explore_interest', name: 'Explore Interesting Target', tier: 'creature', driverKey: 'curiosity',
      desiredState: [{ key: 'need.curiosity', operator: '<=', value: 0.3 }],
      baseBias: 0.05, cooldownSeconds: 1, enabled: true, tags: ['play', 'learning']
    },
    {
      id: uid('goal'), key: 'follow_master', name: 'Follow Master Direction', tier: 'creature', driverKey: 'obedience',
      desiredState: [{ key: 'relationship.following_master', operator: '==', value: true }],
      baseBias: 0.1, cooldownSeconds: 0, enabled: true, tags: ['leash', 'learning']
    },
    {
      id: uid('goal'), key: 'escape_threat', name: 'Escape Threat', tier: 'creature', driverKey: 'fear',
      desiredState: [{ key: 'need.fear', operator: '<=', value: 0.25 }, { key: 'safety.in_danger', operator: '==', value: false }],
      baseBias: 0.25, cooldownSeconds: 0, enabled: true, tags: ['survival']
    },
    {
      id: uid('goal'), key: 'perform_job', name: 'Perform Assigned Job', tier: 'villager', driverKey: 'town_duty',
      desiredState: [{ key: 'job.current_task_complete', operator: '==', value: true }],
      baseBias: 0.1, cooldownSeconds: 1, enabled: true, tags: ['work']
    },
    {
      id: uid('goal'), key: 'resolve_food_shortage', name: 'Resolve Food Shortage', tier: 'village', driverKey: 'town_duty',
      desiredState: [{ key: 'village.food_days', operator: '>=', value: 3 }],
      baseBias: 0.2, cooldownSeconds: 8, enabled: true, tags: ['macro', 'resources']
    },
    {
      id: uid('goal'), key: 'respond_to_player_intent', name: 'Respond To Player Intent', tier: 'god', driverKey: 'obedience',
      desiredState: [{ key: 'god.intent_resolved', operator: '==', value: true }],
      baseBias: 0.2, cooldownSeconds: 1, enabled: true, tags: ['intervention']
    }
  ];

  const actions = [
    {
      id: uid('action'), key: 'find_food_target', name: 'Find Food Target', tiers: ['creature','villager'], contexts: ['either'],
      preconditions: [{ key: 'world.food_available', operator: '==', value: true }],
      effects: [{ key: 'target.food_acquired', operation: 'set', value: true }],
      cost: { base: 2, formula: 'base + distance.normalized * 4 - disposition.curiosity * 1.5' },
      durationSeconds: 1.5, tags: ['sense', 'food'], enabled: true
    },
    {
      id: uid('action'), key: 'move_to_food', name: 'Move To Food', tiers: ['creature','villager'], contexts: ['either'],
      preconditions: [{ key: 'target.food_acquired', operator: '==', value: true }],
      effects: [{ key: 'target.food_reached', operation: 'set', value: true }],
      cost: { base: 4, formula: 'base + distance.normalized * 8' },
      durationSeconds: 2.5, tags: ['movement', 'food'], enabled: true
    },
    {
      id: uid('action'), key: 'eat_food', name: 'Eat Food', tiers: ['creature','villager'], contexts: ['either'],
      preconditions: [{ key: 'target.food_reached', operator: '==', value: true }],
      effects: [{ key: 'need.hunger', operation: 'set', value: 0.1 }],
      cost: { base: 1, formula: 'base - disposition.gluttony * 0.25' },
      durationSeconds: 1.2, tags: ['consume', 'food'], enabled: true
    },
    {
      id: uid('action'), key: 'steal_village_food', name: 'Steal Village Food', tiers: ['creature'], contexts: ['off_leash'],
      preconditions: [{ key: 'world.village_food_available', operator: '==', value: true }, { key: 'relationship.supervised', operator: '==', value: false }],
      effects: [{ key: 'need.hunger', operation: 'set', value: 0.15 }, { key: 'reputation.village', operation: 'add', value: -0.1 }],
      cost: { base: 3, formula: 'base - disposition.mischief * 2 + relationship.village_love * 3' },
      durationSeconds: 2, tags: ['mischief', 'food'], enabled: true
    },
    {
      id: uid('action'), key: 'select_interest_target', name: 'Select Interesting Target', tiers: ['creature'], contexts: ['either'],
      preconditions: [{ key: 'world.interesting_object_visible', operator: '==', value: true }],
      effects: [{ key: 'target.interest_selected', operation: 'set', value: true }],
      cost: { base: 1.5, formula: 'base - disposition.curiosity * 0.8' },
      durationSeconds: 0.3, tags: ['sense', 'curiosity'], enabled: true
    },
    {
      id: uid('action'), key: 'inspect_target', name: 'Inspect Target', tiers: ['creature'], contexts: ['either'],
      preconditions: [{ key: 'target.interest_selected', operator: '==', value: true }],
      effects: [{ key: 'need.curiosity', operation: 'set', value: 0.2 }, { key: 'learning.observation_recorded', operation: 'set', value: true }],
      cost: { base: 2, formula: 'base - affinity.target * 1.25' },
      durationSeconds: 2, tags: ['learning', 'curiosity'], enabled: true
    },
    {
      id: uid('action'), key: 'accept_leash_direction', name: 'Accept Leash Direction', tiers: ['creature'], contexts: ['on_leash'],
      preconditions: [{ key: 'god.leash_direction_active', operator: '==', value: true }],
      effects: [{ key: 'relationship.following_master', operation: 'set', value: true }],
      cost: { base: 1, formula: 'base - disposition.obedience * 0.75' },
      durationSeconds: 0.25, tags: ['leash', 'obedience'], enabled: true
    },
    {
      id: uid('action'), key: 'flee_to_safety', name: 'Flee To Safety', tiers: ['creature','villager'], contexts: ['either'],
      preconditions: [{ key: 'safety.in_danger', operator: '==', value: true }],
      effects: [{ key: 'safety.in_danger', operation: 'set', value: false }, { key: 'need.fear', operation: 'set', value: 0.15 }],
      cost: { base: 1, formula: 'base + distance.to_safety * 0.4 - disposition.cowardice * 0.5' },
      durationSeconds: 2.2, tags: ['survival', 'movement'], enabled: true
    },
    {
      id: uid('action'), key: 'perform_job_step', name: 'Perform Job Step', tiers: ['villager'], contexts: ['either'],
      preconditions: [{ key: 'job.assigned', operator: '==', value: true }, { key: 'job.current_task_complete', operator: '==', value: false }],
      effects: [{ key: 'job.current_task_complete', operation: 'set', value: true }],
      cost: { base: 3, formula: 'base - skill.job * 2 + need.fatigue * 2' },
      durationSeconds: 4, tags: ['work'], enabled: true
    },
    {
      id: uid('action'), key: 'assign_food_workers', name: 'Assign Food Workers', tiers: ['village'], contexts: ['either'],
      preconditions: [{ key: 'village.available_workers', operator: '>', value: 0 }],
      effects: [{ key: 'village.food_workers_assigned', operation: 'set', value: true }],
      cost: { base: 2, formula: 'base + village.labor_shortage * 4' },
      durationSeconds: 0.5, tags: ['macro', 'resources'], enabled: true
    },
    {
      id: uid('action'), key: 'produce_food', name: 'Produce Food', tiers: ['village'], contexts: ['either'],
      preconditions: [{ key: 'village.food_workers_assigned', operator: '==', value: true }],
      effects: [{ key: 'village.food_days', operation: 'set', value: 4 }],
      cost: { base: 6, formula: 'base - village.fertility * 2 + weather.penalty * 3' },
      durationSeconds: 12, tags: ['macro', 'resources'], enabled: true
    },
    {
      id: uid('action'), key: 'interpret_gesture', name: 'Interpret Player Gesture', tiers: ['god'], contexts: ['either'],
      preconditions: [{ key: 'god.gesture_pending', operator: '==', value: true }],
      effects: [{ key: 'god.intent_known', operation: 'set', value: true }],
      cost: { base: 1, formula: 'base - confidence.gesture * 0.5' },
      durationSeconds: 0.1, tags: ['god_hand', 'intent'], enabled: true
    },
    {
      id: uid('action'), key: 'apply_intervention', name: 'Apply God Intervention', tiers: ['god'], contexts: ['either'],
      preconditions: [{ key: 'god.intent_known', operator: '==', value: true }],
      effects: [{ key: 'god.intent_resolved', operation: 'set', value: true }],
      cost: { base: 2, formula: 'base + miracle.cost_normalized * 3' },
      durationSeconds: 0.4, tags: ['god_hand', 'miracle'], enabled: true
    },
    {
      id: uid('action'), key: 'kick_boulder', name: 'Kick Boulder', tiers: ['creature'], contexts: ['off_leash','on_leash'],
      preconditions: [{ key: 'target.type', operator: '==', value: 'boulder' }, { key: 'target.in_range', operator: '==', value: true }],
      effects: [{ key: 'need.curiosity', operation: 'add', value: -0.3 }, { key: 'target.boulder_pushed', operation: 'set', value: true }],
      cost: { base: 10, formula: 'base - disposition.mischief * 5 - affinity.boulder_kick * 3' },
      durationSeconds: 1.1, tags: ['object_interaction', 'mischief'], enabled: true
    }
  ];

  const blackboard = [
    { id: uid('bb'), key: 'need.hunger', type: 'number', defaultValue: 0.72, scope: 'entity', description: 'Normalized hunger pressure.' },
    { id: uid('bb'), key: 'need.curiosity', type: 'number', defaultValue: 0.64, scope: 'entity', description: 'Normalized curiosity pressure.' },
    { id: uid('bb'), key: 'need.fear', type: 'number', defaultValue: 0.18, scope: 'entity', description: 'Normalized fear pressure.' },
    { id: uid('bb'), key: 'relationship.obedience', type: 'number', defaultValue: 0.55, scope: 'entity', description: 'Learned obedience toward the player.' },
    { id: uid('bb'), key: 'relationship.following_master', type: 'boolean', defaultValue: false, scope: 'entity', description: 'True while following a leash direction.' },
    { id: uid('bb'), key: 'world.food_available', type: 'boolean', defaultValue: true, scope: 'world', description: 'Food target can be found nearby.' },
    { id: uid('bb'), key: 'world.village_food_available', type: 'boolean', defaultValue: true, scope: 'world', description: 'Village food storage can be stolen from.' },
    { id: uid('bb'), key: 'world.interesting_object_visible', type: 'boolean', defaultValue: true, scope: 'world', description: 'An object with novelty or affinity is visible.' },
    { id: uid('bb'), key: 'safety.in_danger', type: 'boolean', defaultValue: false, scope: 'entity', description: 'Immediate danger flag.' },
    { id: uid('bb'), key: 'god.leash_direction_active', type: 'boolean', defaultValue: false, scope: 'god_hand', description: 'The leash is actively indicating a direction.' },
    { id: uid('bb'), key: 'duty.urgency', type: 'number', defaultValue: 0.45, scope: 'entity', description: 'Urgency of current duty.' },
    { id: uid('bb'), key: 'job.assigned', type: 'boolean', defaultValue: true, scope: 'entity', description: 'Villager has an assigned job.' },
    { id: uid('bb'), key: 'job.current_task_complete', type: 'boolean', defaultValue: false, scope: 'entity', description: 'Current job task completion state.' },
    { id: uid('bb'), key: 'village.available_workers', type: 'number', defaultValue: 6, scope: 'village', description: 'Workers available for reassignment.' },
    { id: uid('bb'), key: 'village.food_days', type: 'number', defaultValue: 1.2, scope: 'village', description: 'Days of food currently stored.' },
    { id: uid('bb'), key: 'god.gesture_pending', type: 'boolean', defaultValue: true, scope: 'god_hand', description: 'A player gesture is waiting for interpretation.' },
    { id: uid('bb'), key: 'god.intent_resolved', type: 'boolean', defaultValue: false, scope: 'god_hand', description: 'The current intervention intent has completed.' },
    { id: uid('bb'), key: 'target.food_acquired', type: 'boolean', defaultValue: false, scope: 'entity', description: 'A valid food target has been selected.' },
    { id: uid('bb'), key: 'target.food_reached', type: 'boolean', defaultValue: false, scope: 'entity', description: 'The selected food target is within interaction range.' },
    { id: uid('bb'), key: 'relationship.supervised', type: 'boolean', defaultValue: false, scope: 'entity', description: 'The entity is currently under direct supervision.' },
    { id: uid('bb'), key: 'reputation.village', type: 'number', defaultValue: 0.5, scope: 'entity', description: 'Current village reputation normalized from zero to one.' },
    { id: uid('bb'), key: 'target.interest_selected', type: 'boolean', defaultValue: false, scope: 'entity', description: 'An interesting target has been selected for inspection.' },
    { id: uid('bb'), key: 'learning.observation_recorded', type: 'boolean', defaultValue: false, scope: 'entity', description: 'The current observation has been stored as learning evidence.' },
    { id: uid('bb'), key: 'village.food_workers_assigned', type: 'boolean', defaultValue: false, scope: 'village', description: 'The village has assigned workers to food production.' },
    { id: uid('bb'), key: 'god.intent_known', type: 'boolean', defaultValue: false, scope: 'god_hand', description: 'The pending player gesture has been interpreted into intent.' },
    { id: uid('bb'), key: 'target.type', type: 'string', defaultValue: 'boulder', scope: 'entity', description: 'Type key of the current interaction target.' },
    { id: uid('bb'), key: 'target.in_range', type: 'boolean', defaultValue: true, scope: 'entity', description: 'The current target is within interaction range.' },
    { id: uid('bb'), key: 'target.boulder_pushed', type: 'boolean', defaultValue: false, scope: 'world', description: 'The selected boulder has been pushed by an interaction.' }
  ];

  const profiles = [
    {
      id: creatureProfileId,
      key: 'playful_impulsive_creature_v1',
      name: 'Playful Impulsive Creature',
      tier: 'creature',
      color: '#a97aff',
      description: 'Curious, mischievous, socially responsive, and strongly affected by leash context.',
      active: true,
      dispositions: { curiosity: 0.85, aggression: 0.2, mischief: 0.7, obedience: 0.55, compassion: 0.5, cowardice: 0.2, gluttony: 0.35 },
      fixations: ['shiny_objects', 'villager_piles'],
      fascinations: ['miracles', 'construction', 'dancing_villagers'],
      objectAffinities: {
        boulder: { kick: 0.8, throw: 0.4, eat: 0 },
        tree: { uproot: 0.6, water: 0.2, inspect: 0.7 },
        villager: { help: 0.45, scare: 0.25, eat: 0.02 }
      },
      allowedGoalIds: goals.filter(goal => goal.tier === 'creature').map(goal => goal.id),
      allowedActionIds: actions.filter(action => action.tiers.includes('creature')).map(action => action.id),
      priorityOrder: priorities.map(driver => driver.id),
      leashMode: 'off_leash',
      leashModifiers: {
        off_leash: { exploreMultiplier: 1.5, obedienceMultiplier: 0.45, maxActionDistance: 120, allowMischief: true, learningMultiplier: 0.8 },
        on_leash: { exploreMultiplier: 0.45, obedienceMultiplier: 2, maxActionDistance: 25, allowMischief: false, learningMultiplier: 1.8 }
      }
    },
    {
      id: villagerProfileId,
      key: 'balanced_farmer_v1',
      name: 'Balanced Farmer',
      tier: 'villager',
      color: '#63d58a',
      description: 'Balances hunger, fatigue, family, worship, and assigned farming obligations.',
      active: true,
      dispositions: { diligence: 0.72, sociability: 0.56, piety: 0.48, courage: 0.42, selfishness: 0.18 },
      fixations: [],
      fascinations: ['good_harvests', 'festivals'],
      objectAffinities: { field: { work: 0.9 }, temple: { worship: 0.5 }, home: { rest: 0.7 } },
      allowedGoalIds: goals.filter(goal => goal.tier === 'villager').map(goal => goal.id),
      allowedActionIds: actions.filter(action => action.tiers.includes('villager')).map(action => action.id),
      priorityOrder: priorities.map(driver => driver.id),
      leashMode: 'either',
      leashModifiers: {}
    },
    {
      id: villageProfileId,
      key: 'autonomous_village_manager_v1',
      name: 'Autonomous Village Manager',
      tier: 'village',
      color: '#f39a38',
      description: 'Allocates labor and resources while balancing food, housing, worship, defense, and expansion.',
      active: true,
      dispositions: { expansionism: 0.55, conservation: 0.66, defenseBias: 0.48, worshipBias: 0.52, riskTolerance: 0.35 },
      fixations: [],
      fascinations: ['surplus_resources', 'efficient_roads'],
      objectAffinities: { granary: { build: 0.9 }, tower: { build: 0.45 }, temple: { build: 0.52 } },
      allowedGoalIds: goals.filter(goal => goal.tier === 'village').map(goal => goal.id),
      allowedActionIds: actions.filter(action => action.tiers.includes('village')).map(action => action.id),
      priorityOrder: priorities.map(driver => driver.id),
      leashMode: 'either',
      leashModifiers: {}
    },
    {
      id: godProfileId,
      key: 'intervention_director_v1',
      name: 'Intervention Director',
      tier: 'god',
      color: '#e9c85b',
      description: 'Interprets player gestures and world events to guide supernatural intervention.',
      active: true,
      dispositions: { benevolence: 0.5, wrath: 0.35, spectacle: 0.62, restraint: 0.48, guidance: 0.7 },
      fixations: [],
      fascinations: ['player_gestures', 'village_crises', 'creature_learning'],
      objectAffinities: { village: { bless: 0.7, punish: 0.25 }, creature: { teach: 0.82 }, terrain: { terraform: 0.55 } },
      allowedGoalIds: goals.filter(goal => goal.tier === 'god').map(goal => goal.id),
      allowedActionIds: actions.filter(action => action.tiers.includes('god')).map(action => action.id),
      priorityOrder: priorities.map(driver => driver.id),
      leashMode: 'either',
      leashModifiers: {}
    }
  ];

  return {
    schemaVersion: APP.schemaVersion,
    projectId,
    title: 'Ungodly Unified AI System',
    createdAt: nowIso(),
    updatedAt: nowIso(),
    settings: {
      planningDepthLimit: 8,
      planningNodeLimit: 500,
      utilityTieThreshold: 0.025,
      defaultEvaluationInterval: 1,
      simulationSeed: 137,
      actionFailureReplan: true,
      normalizeUtilityScores: true,
      engineMode: 'utility_goap_hybrid'
    },
    profiles,
    priorities,
    goals,
    actions,
    blackboard,
    simulation: {
      activeProfileId: creatureProfileId,
      leashMode: 'off_leash',
      worldState: Object.fromEntries(blackboard.map(entry => [entry.key, entry.defaultValue])),
      lastResult: null,
      log: []
    }
  };
}

function normalizeProject(project) {
  const normalized = project && typeof project === 'object' ? project : createDefaultProject();
  normalized.schemaVersion = normalized.schemaVersion || APP.schemaVersion;
  normalized.projectId = normalized.projectId || uid('ai_project');
  normalized.title = normalized.title || 'Untitled Ungodly AI Project';
  normalized.createdAt = normalized.createdAt || nowIso();
  normalized.updatedAt = normalized.updatedAt || nowIso();
  normalized.settings = Object.assign(createDefaultProject().settings, normalized.settings || {});
  normalized.profiles = Array.isArray(normalized.profiles) ? normalized.profiles : [];
  normalized.priorities = Array.isArray(normalized.priorities) ? normalized.priorities : [];
  normalized.goals = Array.isArray(normalized.goals) ? normalized.goals : [];
  normalized.actions = Array.isArray(normalized.actions) ? normalized.actions : [];
  normalized.blackboard = Array.isArray(normalized.blackboard) ? normalized.blackboard : [];
  normalized.simulation = normalized.simulation || {};
  normalized.simulation.worldState = normalized.simulation.worldState || Object.fromEntries(normalized.blackboard.map(entry => [entry.key, entry.defaultValue]));
  normalized.simulation.log = Array.isArray(normalized.simulation.log) ? normalized.simulation.log : [];
  normalized.simulation.leashMode = normalized.simulation.leashMode || 'off_leash';
  normalized.simulation.activeProfileId = normalized.simulation.activeProfileId || normalized.profiles[0]?.id || null;
  normalized.profiles.forEach(profile => {
    profile.id = profile.id || uid('profile');
    profile.key = profile.key || slugify(profile.name);
    profile.name = profile.name || formatLabel(profile.key);
    profile.tier = ENTITY_TIERS.includes(profile.tier) ? profile.tier : 'creature';
    profile.color = profile.color || '#22d3c5';
    profile.description = profile.description || '';
    profile.active = profile.active !== false;
    profile.dispositions = profile.dispositions || {};
    profile.fixations = Array.isArray(profile.fixations) ? profile.fixations : [];
    profile.fascinations = Array.isArray(profile.fascinations) ? profile.fascinations : [];
    profile.objectAffinities = profile.objectAffinities || {};
    profile.allowedGoalIds = Array.isArray(profile.allowedGoalIds) ? profile.allowedGoalIds : [];
    profile.allowedActionIds = Array.isArray(profile.allowedActionIds) ? profile.allowedActionIds : [];
    profile.priorityOrder = Array.isArray(profile.priorityOrder) ? profile.priorityOrder : normalized.priorities.map(item => item.id);
    profile.leashMode = LEASH_CONTEXTS.includes(profile.leashMode) ? profile.leashMode : 'either';
    profile.leashModifiers = profile.leashModifiers || {};
  });
  return normalized;
}

function selectedProfile() {
  return APP.project.profiles.find(profile => profile.id === APP.selectedProfileId) || APP.project.profiles[0] || null;
}

function markDirty(message = 'Unsaved local changes') {
  APP.project.updatedAt = nowIso();
  APP.dirty = true;
  const state = document.getElementById('saveState');
  state.textContent = message;
  state.className = 'save-state dirty';
  saveLocal();
  renderDefinitionSummary();
  renderSidebarInsights();
  renderSimulationSummary();
  renderValidation();
}

function setSaveState(message, stateClass = 'saved') {
  APP.dirty = false;
  const state = document.getElementById('saveState');
  state.textContent = message;
  state.className = `save-state ${stateClass}`;
}

function saveLocal() {
  localStorage.setItem(APP.storageKey, JSON.stringify(APP.project));
}

function loadLocal() {
  try {
    const raw = localStorage.getItem(APP.storageKey);
    return raw ? normalizeProject(JSON.parse(raw)) : createDefaultProject();
  } catch (error) {
    console.error(error);
    return createDefaultProject();
  }
}

function toast(message) {
  const element = document.getElementById('toast');
  element.textContent = message;
  element.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => element.classList.remove('show'), 2200);
}

function tierBadge(tier) {
  return `<span class="tier-badge ${escapeHtml(tier)}">${escapeHtml(formatLabel(tier))}</span>`;
}

function renderAll() {
  document.getElementById('projectTitleInput').value = APP.project.title;
  document.getElementById('projectIdInput').value = APP.project.projectId;
  document.getElementById('schemaVersionInput').value = APP.project.schemaVersion;
  renderProfileList();
  renderActiveTab();
  renderDefinitionSummary();
  renderSidebarInsights();
  renderSimulationSummary();
  renderValidation();
}

function renderProfileList() {
  const searchInput = document.getElementById('profileSearchInput');
  const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
  const container = document.getElementById('profileList');
  const countLabel = document.getElementById('profileCountLabel');
  if (countLabel) countLabel.textContent = String(APP.project.profiles.length);
  const profiles = APP.project.profiles.filter(profile => {
    const haystack = `${profile.name} ${profile.key} ${profile.tier} ${profile.description}`.toLowerCase();
    return haystack.includes(query);
  });
  if (!profiles.length) {
    container.innerHTML = '<div class="empty-state">No matching profiles.</div>';
    return;
  }
  container.innerHTML = profiles.map(profile => `
    <article class="profile-card ${profile.id === APP.selectedProfileId ? 'active' : ''}" data-profile-id="${profile.id}" style="--profile-color:${escapeHtml(profile.color)}">
      <span class="profile-card-status ${profile.active !== false ? 'active' : ''}" title="${profile.active !== false ? 'Active profile' : 'Inactive profile'}"></span>
      <div class="profile-card-actions"><button class="small-action delete-profile" data-profile-id="${profile.id}" title="Delete profile">×</button></div>
      <h3>${escapeHtml(profile.name)}</h3>
      <p>${escapeHtml(profile.description || profile.key)}</p>
      ${tierBadge(profile.tier)}
    </article>
  `).join('');
  container.querySelectorAll('.profile-card').forEach(card => {
    card.addEventListener('click', event => {
      if (event.target.closest('.delete-profile')) return;
      APP.selectedProfileId = card.dataset.profileId;
      APP.project.simulation.activeProfileId = APP.selectedProfileId;
      renderProfileList();
      renderActiveTab();
      renderSidebarInsights();
      renderSimulationSummary();
    });
  });
  container.querySelectorAll('.delete-profile').forEach(button => {
    button.addEventListener('click', event => {
      event.stopPropagation();
      deleteProfile(button.dataset.profileId);
    });
  });
}

function renderSidebarInsights() {
  const profile = selectedProfile();
  const traitContainer = document.getElementById('globalTraitList');
  const blackboardContainer = document.getElementById('blackboardQuickList');
  const traitQuery = document.getElementById('globalTraitSearchInput')?.value.trim().toLowerCase() || '';
  const blackboardQuery = document.getElementById('blackboardSearchInput')?.value.trim().toLowerCase() || '';

  if (traitContainer) {
    if (!profile) {
      traitContainer.innerHTML = '<div class="empty-state">Select a profile to inspect its traits.</div>';
    } else {
      const traits = Object.entries(profile.dispositions || {}).filter(([key]) => formatLabel(key).toLowerCase().includes(traitQuery));
      traitContainer.innerHTML = traits.length ? traits.slice(0, 8).map(([key, value]) => `
        <div class="quick-item">
          <span class="quick-icon">${escapeHtml(formatLabel(key).slice(0, 1))}</span>
          <div><h3>${escapeHtml(formatLabel(key))}</h3><p>${escapeHtml(formatLabel(profile.tier))} disposition multiplier</p></div>
          <span class="quick-value">${clamp(value).toFixed(2)}</span>
        </div>
      `).join('') : '<div class="empty-state">No matching traits.</div>';
    }
  }

  if (blackboardContainer) {
    const keys = APP.project.blackboard.filter(entry => {
      const haystack = `${entry.key} ${entry.scope} ${entry.type} ${entry.description}`.toLowerCase();
      return haystack.includes(blackboardQuery);
    });
    blackboardContainer.innerHTML = keys.length ? keys.slice(0, 8).map(entry => {
      const rawValue = typeof entry.defaultValue === 'string' ? entry.defaultValue : JSON.stringify(entry.defaultValue);
      return `<div class="quick-item"><div><h3>${escapeHtml(entry.key)}</h3><p>${escapeHtml(formatLabel(entry.scope))} · ${escapeHtml(entry.type)}</p></div><span class="quick-value">${escapeHtml(rawValue)}</span></div>`;
    }).join('') : '<div class="empty-state">No matching blackboard keys.</div>';
  }

  const engineLabel = document.getElementById('runtimeEngineLabel');
  if (engineLabel) engineLabel.textContent = formatLabel(APP.project.settings.engineMode || 'utility_goap_hybrid').toUpperCase();
  const depth = Number(APP.project.settings.planningDepthLimit || 0);
  const nodes = Number(APP.project.settings.planningNodeLimit || 0);
  const budgetLabel = document.getElementById('planningBudgetLabel');
  if (budgetLabel) budgetLabel.textContent = `${depth} depth · ${nodes} nodes`;
  const budgetBar = document.getElementById('planningBudgetBar');
  if (budgetBar) {
    const depthScore = Math.min(1, depth / 16);
    const nodeScore = Math.min(1, nodes / 1000);
    budgetBar.style.width = `${Math.max(6, Math.round((depthScore * 0.45 + nodeScore * 0.55) * 100))}%`;
  }
}

function renderSimulationSummary() {
  const container = document.getElementById('simulationSummary');
  if (!container) return;
  const result = APP.project.simulation?.lastResult;
  const profile = APP.project.profiles.find(item => item.id === result?.profileId) || selectedProfile();
  const goal = APP.project.goals.find(item => item.id === result?.selectedGoalId);
  if (!result) {
    container.innerHTML = `
      <div class="simulation-summary-card">
        <div><h3>No simulation run yet</h3><p>Evaluate ${escapeHtml(profile?.name || 'a profile')} to inspect utility selection and its GOAP plan.</p></div>
        <button id="openSimulationSummaryButton" class="simulation-play-button" title="Open simulation">▶</button>
      </div>`;
  } else {
    const totalCost = result.plan.reduce((sum, step) => sum + Number(step.cost || 0), 0);
    container.innerHTML = `
      <div class="simulation-summary-card">
        <div><h3>${escapeHtml(goal?.name || 'No goal selected')}</h3><p>${escapeHtml(profile?.name || 'Unknown profile')} · ${result.plan.length} steps · cost ${totalCost.toFixed(2)}<br>${escapeHtml(new Date(result.evaluatedAt).toLocaleString())}</p></div>
        <button id="openSimulationSummaryButton" class="simulation-play-button" title="Open simulation">▶</button>
      </div>`;
  }
  document.getElementById('openSimulationSummaryButton')?.addEventListener('click', () => {
    APP.activeTab = 'simulation';
    renderActiveTab();
  });
}

function renderDefinitionSummary() {
  const counts = [
    ['Profiles', APP.project.profiles.length],
    ['Drivers', APP.project.priorities.length],
    ['Goals', APP.project.goals.length],
    ['Actions', APP.project.actions.length],
    ['Keys', APP.project.blackboard.length],
    ['Tiers', new Set(APP.project.profiles.map(profile => profile.tier)).size]
  ];
  document.getElementById('definitionSummary').innerHTML = counts.map(([label, value]) => `
    <div class="summary-tile"><strong>${value}</strong><span>${label}</span></div>
  `).join('');
}

function renderActiveTab() {
  document.querySelectorAll('#mainTabs .tab').forEach(tab => tab.classList.toggle('active', tab.dataset.tab === APP.activeTab));
  const profile = selectedProfile();
  const content = document.getElementById('tabContent');
  if (!profile && APP.activeTab !== 'blackboard') {
    content.innerHTML = '<div class="empty-state">Create or select a profile to begin authoring.</div>';
    return;
  }
  const renderers = {
    sheet: renderSheetTab,
    priorities: renderPrioritiesTab,
    goals: renderGoalsTab,
    actions: renderActionsTab,
    blackboard: renderBlackboardTab,
    simulation: renderSimulationTab
  };
  content.innerHTML = renderers[APP.activeTab]();
  bindActiveTabEvents();
  if (APP.activeTab === 'priorities') requestAnimationFrame(drawCurveCanvas);
}

function renderProfileDashboard(profile) {
  const orderedDrivers = (profile.priorityOrder || [])
    .map(id => APP.project.priorities.find(driver => driver.id === id))
    .filter(Boolean);
  APP.project.priorities.forEach(driver => {
    if (!orderedDrivers.some(item => item.id === driver.id)) orderedDrivers.push(driver);
  });
  const utilityRows = orderedDrivers.slice(0, 5).map(driver => {
    const weight = Number(driver.baseWeight || 0);
    const width = Math.max(2, Math.min(100, (weight / 1.5) * 100));
    return `<div class="dashboard-utility-row" data-dashboard-tab="priorities"><span>${escapeHtml(driver.name)}</span><div class="dashboard-meter"><span style="width:${width}%"></span></div><output>${weight.toFixed(2)}</output></div>`;
  }).join('');
  const allowedActions = profile.allowedActionIds
    .map(id => APP.project.actions.find(action => action.id === id))
    .filter(action => action && action.enabled)
    .slice(0, 5);
  const actionPalette = ['#a96cff', '#5aa9ff', '#50d36f', '#ff9f2e', '#ff4f86'];
  const leashModes = [
    ['off_leash', 'OFF', 'Unrestricted'],
    ['on_leash', 'ON', 'Guided'],
    ['either', 'AUTO', 'Contextual']
  ];
  return `
    <section class="profile-dashboard" style="--profile-accent:${escapeHtml(profile.color)}">
      <div class="profile-dashboard-header">
        <div class="profile-dashboard-title">
          <span class="eyebrow">PROFILE EDITOR</span>
          <div class="profile-dashboard-title-row"><h2>${escapeHtml(profile.name)}</h2>${tierBadge(profile.tier)}<span class="profile-stable-id">${escapeHtml(profile.id)}</span></div>
        </div>
        <div class="profile-dashboard-actions">
          <button id="exportSelectedProfileButton" class="button secondary export-project-button">⇩ EXPORT PROFILE</button>
          <label class="active-toggle">ACTIVE<input id="profileActiveToggle" type="checkbox" ${profile.active !== false ? 'checked' : ''}><span class="active-toggle-track"></span></label>
        </div>
      </div>
      <div class="dashboard-grid">
        <article class="dashboard-card">
          <h3>Utility Priorities</h3>
          <div class="dashboard-utility-list">${utilityRows || '<div class="empty-state">No drivers assigned.</div>'}</div>
        </article>
        <article class="dashboard-card">
          <h3>Leash / Context Mode</h3>
          <div class="leash-segments">${leashModes.map(([value, title, subtitle]) => `<button class="leash-segment ${profile.leashMode === value ? 'active' : ''}" data-leash-mode="${value}">${title}<small>${subtitle}</small></button>`).join('')}</div>
          <p class="dashboard-card-description">Context changes utility multipliers, allowed action distance, learning rate, and mischief access without replacing the profile.</p>
        </article>
        <article class="dashboard-card">
          <h3 class="orange">Runtime Guardrails</h3>
          <div class="guardrail-list">
            <label class="guardrail-row"><span>Action failure replans</span><span class="guardrail-state"><input id="dashboardReplanToggle" type="checkbox" ${APP.project.settings.actionFailureReplan ? 'checked' : ''}> ON</span></label>
            <label class="guardrail-row"><span>Normalize utility scores</span><span class="guardrail-state"><input id="dashboardNormalizeToggle" type="checkbox" ${APP.project.settings.normalizeUtilityScores ? 'checked' : ''}> ON</span></label>
            <div class="guardrail-row"><span>Planning depth limit</span><span class="guardrail-state numeric">${Number(APP.project.settings.planningDepthLimit)}</span></div>
            <div class="guardrail-row"><span>Planning node limit</span><span class="guardrail-state numeric">${Number(APP.project.settings.planningNodeLimit)}</span></div>
          </div>
        </article>
        <article class="dashboard-card core-actions-card">
          <h3 class="orange">Core Actions</h3>
          <div class="core-action-grid">${allowedActions.length ? allowedActions.map((action, index) => `
            <button class="core-action-card" data-action-id="${action.id}" style="--action-color:${actionPalette[index % actionPalette.length]}">
              <span class="core-action-icon">${index + 1}</span>
              <div><h4>${escapeHtml(action.name)}</h4><p>${escapeHtml(action.tags?.length ? action.tags.map(formatLabel).join(' · ') : 'Reusable GOAP action')}</p></div>
              <small>${escapeHtml(action.contexts.map(formatLabel).join(' / '))}</small>
            </button>
          `).join('') : '<div class="empty-state">No enabled actions are assigned to this profile.</div>'}</div>
        </article>
      </div>
    </section>
  `;
}

function renderSheetTab() {
  const profile = selectedProfile();
  const dispositions = Object.entries(profile.dispositions || {});
  const objectRows = Object.entries(profile.objectAffinities || {}).map(([objectKey, interactions]) => {
    const text = Object.entries(interactions).map(([key, value]) => `${key}: ${Number(value).toFixed(2)}`).join(' · ');
    return `<div class="draggable-card"><span class="drag-handle">◆</span><div class="card-main"><h3>${escapeHtml(formatLabel(objectKey))}</h3><p>${escapeHtml(text)}</p></div><div class="card-actions"><button class="button secondary edit-affinity" data-key="${escapeHtml(objectKey)}">Edit</button></div></div>`;
  }).join('');
  return `
    ${renderProfileDashboard(profile)}
    <div class="panel-grid">
      <section class="editor-panel full-span" style="--accent:${escapeHtml(profile.color)}">
        <div class="editor-panel-header"><div><h3>Profile Identity</h3><p>Stable entity sheet used by runtime instances.</p></div>${tierBadge(profile.tier)}</div>
        <div class="editor-panel-body">
          <div class="form-grid three">
            <label>Name<input id="profileNameInput" value="${escapeHtml(profile.name)}"></label>
            <label>Key<input id="profileKeyInput" value="${escapeHtml(profile.key)}"></label>
            <label>Tier<select id="profileTierSelect">${ENTITY_TIERS.map(tier => `<option value="${tier}" ${profile.tier === tier ? 'selected' : ''}>${formatLabel(tier)}</option>`).join('')}</select></label>
            <label>Panel color<input id="profileColorInput" type="color" value="${escapeHtml(profile.color)}"></label>
            <label>Default leash context<select id="profileLeashSelect">${LEASH_CONTEXTS.map(value => `<option value="${value}" ${profile.leashMode === value ? 'selected' : ''}>${formatLabel(value)}</option>`).join('')}</select></label>
            <label class="full">Description<textarea id="profileDescriptionInput">${escapeHtml(profile.description)}</textarea></label>
          </div>
        </div>
      </section>

      <section class="editor-panel" style="--accent:${escapeHtml(profile.color)}">
        <div class="editor-panel-header"><div><h3>Dispositions</h3><p>Baseline personality DNA and learned temperament.</p></div><button id="addDispositionButton" class="round-button">+</button></div>
        <div class="editor-panel-body">
          ${dispositions.length ? dispositions.map(([key, value]) => `
            <div class="slider-row">
              <span>${escapeHtml(formatLabel(key))}</span>
              <input class="disposition-slider" data-key="${escapeHtml(key)}" type="range" min="0" max="1" step="0.01" value="${clamp(value)}">
              <output>${clamp(value).toFixed(2)}</output>
            </div>
          `).join('') : '<div class="empty-state">No dispositions yet.</div>'}
        </div>
      </section>

      <section class="editor-panel" style="--accent:${escapeHtml(profile.color)}">
        <div class="editor-panel-header"><div><h3>Interests</h3><p>Fixations are sticky; fascinations are positive attractions.</p></div></div>
        <div class="editor-panel-body">
          <label>Fixations</label>
          <div class="tag-list">${profile.fixations.map(value => `<span class="tag">${escapeHtml(formatLabel(value))}<button class="remove-tag" data-list="fixations" data-value="${escapeHtml(value)}">×</button></span>`).join('')}</div>
          <div class="inline-add"><input id="newFixationInput" placeholder="shiny_objects"><button id="addFixationButton" class="button secondary">Add</button></div>
          <label>Fascinations</label>
          <div class="tag-list">${profile.fascinations.map(value => `<span class="tag">${escapeHtml(formatLabel(value))}<button class="remove-tag" data-list="fascinations" data-value="${escapeHtml(value)}">×</button></span>`).join('')}</div>
          <div class="inline-add"><input id="newFascinationInput" placeholder="miracles"><button id="addFascinationButton" class="button secondary">Add</button></div>
        </div>
      </section>

      <section class="editor-panel full-span" style="--accent:${escapeHtml(profile.color)}">
        <div class="editor-panel-header"><div><h3>Object Affinities</h3><p>Per-object action preference modifiers used by utility scoring and action costs.</p></div><button id="addAffinityButton" class="round-button">+</button></div>
        <div class="editor-panel-body"><div class="card-stack">${objectRows || '<div class="empty-state">No object affinities yet.</div>'}</div></div>
      </section>

      ${profile.tier === 'creature' ? renderLeashPanel(profile) : ''}
    </div>
  `;
}

function renderLeashPanel(profile) {
  const modes = ['off_leash', 'on_leash'];
  return `
    <section class="editor-panel full-span" style="--accent:${escapeHtml(profile.color)}">
      <div class="editor-panel-header"><div><h3>Creature Leash Modifier Sheets</h3><p>Context overlays alter weights, action availability, learning, and movement range.</p></div></div>
      <div class="editor-panel-body">
        <div class="panel-grid">
          ${modes.map(mode => {
            const data = profile.leashModifiers?.[mode] || {};
            return `<div class="modal-section"><h3>${formatLabel(mode)}</h3>
              <div class="form-grid">
                <label>Explore multiplier<input class="leash-number" data-mode="${mode}" data-key="exploreMultiplier" type="number" min="0" step="0.05" value="${Number(data.exploreMultiplier ?? 1)}"></label>
                <label>Obedience multiplier<input class="leash-number" data-mode="${mode}" data-key="obedienceMultiplier" type="number" min="0" step="0.05" value="${Number(data.obedienceMultiplier ?? 1)}"></label>
                <label>Maximum action distance<input class="leash-number" data-mode="${mode}" data-key="maxActionDistance" type="number" min="0" step="1" value="${Number(data.maxActionDistance ?? 30)}"></label>
                <label>Learning multiplier<input class="leash-number" data-mode="${mode}" data-key="learningMultiplier" type="number" min="0" step="0.05" value="${Number(data.learningMultiplier ?? 1)}"></label>
                <label class="full"><input class="leash-boolean" data-mode="${mode}" data-key="allowMischief" type="checkbox" ${data.allowMischief ? 'checked' : ''}> Allow mischief action cards</label>
              </div>
            </div>`;
          }).join('')}
        </div>
      </div>
    </section>
  `;
}

function renderPrioritiesTab() {
  const profile = selectedProfile();
  const ordered = profile.priorityOrder
    .map(id => APP.project.priorities.find(driver => driver.id === id))
    .filter(Boolean);
  APP.project.priorities.forEach(driver => {
    if (!profile.priorityOrder.includes(driver.id)) ordered.push(driver);
  });
  const selectedDriverId = profile.selectedDriverId || ordered[0]?.id;
  profile.selectedDriverId = selectedDriverId;
  const selectedDriver = APP.project.priorities.find(driver => driver.id === selectedDriverId) || ordered[0];
  return `
    <div class="panel-grid single">
      <section class="editor-panel" style="--accent:${escapeHtml(profile.color)}">
        <div class="editor-panel-header"><div><h3>Priority Stack</h3><p>Drag cards to establish evaluation order. Utility scores still decide the winner.</p></div><button id="addPriorityButton" class="round-button">+</button></div>
        <div class="editor-panel-body"><div id="priorityCardStack" class="card-stack">
          ${ordered.map((driver, index) => `
            <article class="draggable-card priority-card" draggable="true" data-id="${driver.id}">
              <span class="drag-handle">⋮⋮</span>
              <div class="card-main"><h3>${escapeHtml(driver.name)}</h3><p>${escapeHtml(driver.description)}</p>
                <div class="card-meta"><span class="status-badge">Weight ${Number(driver.baseWeight).toFixed(2)}</span><span class="status-badge">Every ${Number(driver.evaluationInterval).toFixed(2)}s</span><span class="status-badge">${escapeHtml(driver.curveType)}</span></div>
              </div>
              <div class="card-actions"><span class="priority-rank">${index + 1}</span><button class="button secondary select-driver" data-id="${driver.id}">Curve</button><button class="button danger delete-driver" data-id="${driver.id}">×</button></div>
            </article>
          `).join('') || '<div class="empty-state">No utility drivers.</div>'}
        </div></div>
      </section>
      ${selectedDriver ? `
      <section class="editor-panel" style="--accent:${escapeHtml(profile.color)}">
        <div class="editor-panel-header"><div><h3>Visual Curve Inspector — ${escapeHtml(selectedDriver.name)}</h3><p>Drag custom points or choose a standard response curve.</p></div></div>
        <div class="editor-panel-body">
          <div class="curve-layout">
            <div class="curve-canvas-wrap"><canvas id="curveCanvas" width="700" height="320"></canvas></div>
            <div class="curve-controls">
              <label>Name<input id="driverNameInput" value="${escapeHtml(selectedDriver.name)}"></label>
              <label>Input blackboard key<input id="driverInputKeyInput" value="${escapeHtml(selectedDriver.inputKey)}"></label>
              <label>Curve type<select id="driverCurveTypeSelect">${CURVE_TYPES.map(type => `<option value="${type}" ${selectedDriver.curveType === type ? 'selected' : ''}>${formatLabel(type)}</option>`).join('')}</select></label>
              <label>Base weight<input id="driverBaseWeightInput" type="number" min="0" step="0.05" value="${Number(selectedDriver.baseWeight)}"></label>
              <label>Evaluation interval<input id="driverIntervalInput" type="number" min="0.05" step="0.05" value="${Number(selectedDriver.evaluationInterval)}"></label>
              <label>Off-leash multiplier<input id="driverOffLeashInput" type="number" min="0" step="0.05" value="${Number(selectedDriver.contexts?.off_leash ?? 1)}"></label>
              <label>On-leash multiplier<input id="driverOnLeashInput" type="number" min="0" step="0.05" value="${Number(selectedDriver.contexts?.on_leash ?? 1)}"></label>
              <label>Description<textarea id="driverDescriptionInput">${escapeHtml(selectedDriver.description)}</textarea></label>
            </div>
          </div>
        </div>
      </section>` : ''}
    </div>
  `;
}

function renderGoalsTab() {
  const profile = selectedProfile();
  const compatible = APP.project.goals.filter(goal => goal.tier === profile.tier);
  return `
    <div class="panel-grid single">
      <section class="editor-panel" style="--accent:${escapeHtml(profile.color)}">
        <div class="editor-panel-header"><div><h3>${escapeHtml(profile.name)} Goal Pool</h3><p>Utility-selected objectives with explicit desired world states.</p></div><button id="addGoalButton" class="round-button">+</button></div>
        <div class="editor-panel-body"><div class="card-stack">
          ${compatible.map(goal => {
            const allowed = profile.allowedGoalIds.includes(goal.id);
            return `<article class="draggable-card">
              <span class="drag-handle">◎</span>
              <div class="card-main"><h3>${escapeHtml(goal.name)}</h3><p>${goal.desiredState.map(condition => `${escapeHtml(condition.key)} ${escapeHtml(condition.operator)} ${escapeHtml(condition.value)}`).join(' · ')}</p>
                <div class="card-meta"><span class="status-badge">Driver ${escapeHtml(goal.driverKey)}</span><span class="status-badge">Bias ${Number(goal.baseBias).toFixed(2)}</span>${tierBadge(goal.tier)}</div>
              </div>
              <div class="card-actions"><label class="context-badge"><input class="goal-allowed" data-id="${goal.id}" type="checkbox" ${allowed ? 'checked' : ''}> Allowed</label><button class="button secondary edit-goal" data-id="${goal.id}">Edit</button><button class="button danger delete-goal" data-id="${goal.id}">×</button></div>
            </article>`;
          }).join('') || '<div class="empty-state">No goals exist for this tier.</div>'}
        </div></div>
      </section>
    </div>
  `;
}

function renderActionsTab() {
  const profile = selectedProfile();
  const compatible = APP.project.actions.filter(action => action.tiers.includes(profile.tier));
  return `
    <div class="panel-grid single">
      <section class="editor-panel" style="--accent:${escapeHtml(profile.color)}">
        <div class="editor-panel-header"><div><h3>${escapeHtml(profile.name)} Action & Reaction Deck</h3><p>Reusable GOAP cards with preconditions, effects, context filters, and cost formulas.</p></div><button id="addActionButton" class="round-button">+</button></div>
        <div class="editor-panel-body"><div class="card-stack">
          ${compatible.map(action => {
            const allowed = profile.allowedActionIds.includes(action.id);
            const preconditions = action.preconditions.map(item => `${item.key} ${item.operator} ${item.value}`).join(' · ');
            const effects = action.effects.map(item => `${item.key} ${item.operation} ${item.value}`).join(' · ');
            return `<article class="draggable-card">
              <span class="drag-handle">▦</span>
              <div class="card-main"><h3>${escapeHtml(action.name)}</h3><p><strong>Requires:</strong> ${escapeHtml(preconditions || 'None')}<br><strong>Effects:</strong> ${escapeHtml(effects || 'None')}</p>
                <div class="card-meta">${action.contexts.map(context => `<span class="context-badge">${escapeHtml(formatLabel(context))}</span>`).join('')}<span class="status-badge">Cost ${Number(action.cost?.base ?? 1).toFixed(2)}</span><span class="status-badge">${Number(action.durationSeconds ?? 0).toFixed(2)}s</span></div>
              </div>
              <div class="card-actions"><label class="context-badge"><input class="action-allowed" data-id="${action.id}" type="checkbox" ${allowed ? 'checked' : ''}> Allowed</label><button class="button secondary edit-action" data-id="${action.id}">Edit</button><button class="button danger delete-action" data-id="${action.id}">×</button></div>
            </article>`;
          }).join('') || '<div class="empty-state">No actions exist for this tier.</div>'}
        </div></div>
      </section>
    </div>
  `;
}

function renderBlackboardTab() {
  return `
    <div class="panel-grid single">
      <section class="editor-panel" style="--accent:var(--teal)">
        <div class="editor-panel-header"><div><h3>Unified Blackboard Schema</h3><p>Typed keys shared by entity, village, world, and God Hand scopes.</p></div><button id="addBlackboardButton" class="round-button">+</button></div>
        <div class="editor-panel-body">
          <table class="blackboard-table">
            <thead><tr><th>Key</th><th>Type</th><th>Scope</th><th>Default</th><th>Description</th><th>Actions</th></tr></thead>
            <tbody>${APP.project.blackboard.map(entry => `
              <tr><td>${escapeHtml(entry.key)}</td><td>${escapeHtml(entry.type)}</td><td>${escapeHtml(entry.scope)}</td><td>${escapeHtml(JSON.stringify(entry.defaultValue))}</td><td>${escapeHtml(entry.description)}</td><td><button class="button secondary edit-blackboard" data-id="${entry.id}">Edit</button> <button class="button danger delete-blackboard" data-id="${entry.id}">×</button></td></tr>
            `).join('')}</tbody>
          </table>
        </div>
      </section>
    </div>
  `;
}

function renderSimulationTab() {
  const profile = selectedProfile();
  const sim = APP.project.simulation;
  if (sim.activeProfileId !== profile.id) sim.activeProfileId = profile.id;
  const result = sim.lastResult;
  const worldEntries = APP.project.blackboard.slice(0, 18);
  return `
    <div class="simulation-layout">
      <section class="editor-panel simulation-world" style="--accent:${escapeHtml(profile.color)}">
        <div class="editor-panel-header"><div><h3>Simulation Inputs</h3><p>Run one utility selection and GOAP planning pass.</p></div></div>
        <div class="editor-panel-body">
          <label>Profile<select id="simulationProfileSelect">${APP.project.profiles.map(item => `<option value="${item.id}" ${item.id === profile.id ? 'selected' : ''}>${escapeHtml(item.name)}</option>`).join('')}</select></label>
          ${profile.tier === 'creature' ? `<label>Leash context<select id="simulationLeashSelect"><option value="off_leash" ${sim.leashMode === 'off_leash' ? 'selected' : ''}>Off Leash</option><option value="on_leash" ${sim.leashMode === 'on_leash' ? 'selected' : ''}>On Leash</option></select></label>` : ''}
          <div class="modal-section"><h3>World State</h3>${worldEntries.map(entry => renderSimulationInput(entry, sim.worldState[entry.key])).join('')}</div>
          <button id="runSimulationButton" class="button primary full">Evaluate Utility + Build GOAP Plan</button>
          <button id="resetSimulationButton" class="button secondary full">Reset World State</button>
        </div>
      </section>
      <section class="editor-panel simulation-results" style="--accent:${escapeHtml(profile.color)}">
        <div class="editor-panel-header"><div><h3>Decision Trace</h3><p>Scored goals, selected objective, and cheapest valid plan.</p></div></div>
        <div class="editor-panel-body">
          ${result ? renderSimulationResult(result) : '<div class="empty-state">Run the simulation to inspect a decision.</div>'}
          <div class="modal-section"><h3>Runtime Log</h3><div class="log-box">${sim.log.length ? sim.log.map(line => escapeHtml(line)).join('<br>') : 'No simulation events yet.'}</div></div>
        </div>
      </section>
    </div>
  `;
}

function renderSimulationInput(entry, value) {
  const id = `sim_${entry.id}`;
  if (entry.type === 'boolean') {
    return `<label><input class="simulation-value" id="${id}" data-key="${escapeHtml(entry.key)}" data-type="boolean" type="checkbox" ${value ? 'checked' : ''}> ${escapeHtml(entry.key)}</label>`;
  }
  if (entry.type === 'number') {
    return `<label>${escapeHtml(entry.key)}<input class="simulation-value" id="${id}" data-key="${escapeHtml(entry.key)}" data-type="number" type="number" step="0.05" value="${Number(value ?? entry.defaultValue)}"></label>`;
  }
  return `<label>${escapeHtml(entry.key)}<input class="simulation-value" id="${id}" data-key="${escapeHtml(entry.key)}" data-type="string" value="${escapeHtml(value ?? entry.defaultValue)}"></label>`;
}

function renderSimulationResult(result) {
  const selectedGoal = APP.project.goals.find(goal => goal.id === result.selectedGoalId);
  return `
    <div class="simulation-result-card"><h3>Selected Goal: ${escapeHtml(selectedGoal?.name || 'None')}</h3><p class="muted">Final utility ${Number(result.selectedScore || 0).toFixed(3)} · ${escapeHtml(result.reason || '')}</p></div>
    <div class="modal-section"><h3>Utility Scores</h3>${result.scores.map(item => `
      <div><div class="card-main"><h3>${escapeHtml(item.goalName)}</h3><p>${escapeHtml(item.breakdown)}</p></div><div class="score-bar"><span style="width:${Math.max(0, Math.min(100, item.score * 100))}%"></span></div></div>
    `).join('')}</div>
    <div class="modal-section"><h3>GOAP Plan</h3>${result.plan.length ? result.plan.map((step, index) => `
      <div class="plan-step"><span class="plan-step-number">${index + 1}</span><div><strong>${escapeHtml(step.name)}</strong><p class="muted">Cost ${Number(step.cost).toFixed(2)} · ${Number(step.durationSeconds).toFixed(2)}s</p></div></div>
    `).join('') : '<p class="danger-text">No valid plan was found for the selected goal.</p>'}</div>
  `;
}

function bindActiveTabEvents() {
  if (APP.activeTab === 'sheet') bindSheetEvents();
  if (APP.activeTab === 'priorities') bindPriorityEvents();
  if (APP.activeTab === 'goals') bindGoalEvents();
  if (APP.activeTab === 'actions') bindActionEvents();
  if (APP.activeTab === 'blackboard') bindBlackboardEvents();
  if (APP.activeTab === 'simulation') bindSimulationEvents();
}

function bindSheetEvents() {
  const profile = selectedProfile();
  document.getElementById('profileActiveToggle')?.addEventListener('change', event => {
    profile.active = event.target.checked;
    markDirty();
    renderProfileList();
  });
  document.getElementById('exportSelectedProfileButton')?.addEventListener('click', exportSelectedProfile);
  document.querySelectorAll('.leash-segment').forEach(button => button.addEventListener('click', () => {
    profile.leashMode = button.dataset.leashMode;
    if (profile.tier === 'creature' && profile.leashMode !== 'either') APP.project.simulation.leashMode = profile.leashMode;
    markDirty();
    renderActiveTab();
  }));
  document.querySelectorAll('[data-dashboard-tab]').forEach(element => element.addEventListener('click', () => {
    APP.activeTab = element.dataset.dashboardTab;
    renderActiveTab();
  }));
  document.querySelectorAll('.core-action-card').forEach(button => button.addEventListener('click', () => {
    APP.activeTab = 'actions';
    renderActiveTab();
  }));
  document.getElementById('dashboardReplanToggle')?.addEventListener('change', event => {
    APP.project.settings.actionFailureReplan = event.target.checked;
    markDirty();
  });
  document.getElementById('dashboardNormalizeToggle')?.addEventListener('change', event => {
    APP.project.settings.normalizeUtilityScores = event.target.checked;
    markDirty();
  });
  const bindings = [
    ['profileNameInput', 'name'], ['profileKeyInput', 'key'], ['profileDescriptionInput', 'description'], ['profileColorInput', 'color'], ['profileTierSelect', 'tier'], ['profileLeashSelect', 'leashMode']
  ];
  bindings.forEach(([id, key]) => {
    const element = document.getElementById(id);
    if (!element) return;
    element.addEventListener('input', () => {
      profile[key] = key === 'key' ? slugify(element.value) : element.value;
      if (key === 'tier') {
        profile.allowedGoalIds = APP.project.goals.filter(goal => goal.tier === profile.tier).map(goal => goal.id);
        profile.allowedActionIds = APP.project.actions.filter(action => action.tiers.includes(profile.tier)).map(action => action.id);
      }
      markDirty();
      if (['name','color','tier'].includes(key)) renderProfileList();
    });
  });
  document.querySelectorAll('.disposition-slider').forEach(slider => {
    slider.addEventListener('input', () => {
      profile.dispositions[slider.dataset.key] = Number(slider.value);
      slider.nextElementSibling.value = Number(slider.value).toFixed(2);
      markDirty();
    });
  });
  document.getElementById('addDispositionButton')?.addEventListener('click', () => openDispositionModal());
  document.getElementById('addFixationButton')?.addEventListener('click', () => addTagFromInput('fixations', 'newFixationInput'));
  document.getElementById('addFascinationButton')?.addEventListener('click', () => addTagFromInput('fascinations', 'newFascinationInput'));
  document.querySelectorAll('.remove-tag').forEach(button => button.addEventListener('click', () => {
    profile[button.dataset.list] = profile[button.dataset.list].filter(value => value !== button.dataset.value);
    markDirty();
    renderActiveTab();
  }));
  document.getElementById('addAffinityButton')?.addEventListener('click', () => openAffinityModal());
  document.querySelectorAll('.edit-affinity').forEach(button => button.addEventListener('click', () => openAffinityModal(button.dataset.key)));
  document.querySelectorAll('.leash-number').forEach(input => input.addEventListener('input', () => {
    profile.leashModifiers[input.dataset.mode] ||= {};
    profile.leashModifiers[input.dataset.mode][input.dataset.key] = Number(input.value);
    markDirty();
  }));
  document.querySelectorAll('.leash-boolean').forEach(input => input.addEventListener('change', () => {
    profile.leashModifiers[input.dataset.mode] ||= {};
    profile.leashModifiers[input.dataset.mode][input.dataset.key] = input.checked;
    markDirty();
  }));
}

function bindPriorityEvents() {
  const profile = selectedProfile();
  const stack = document.getElementById('priorityCardStack');
  let draggingId = null;
  stack?.querySelectorAll('.priority-card').forEach(card => {
    card.addEventListener('dragstart', () => { draggingId = card.dataset.id; card.classList.add('dragging'); });
    card.addEventListener('dragend', () => { card.classList.remove('dragging'); draggingId = null; });
    card.addEventListener('dragover', event => event.preventDefault());
    card.addEventListener('drop', event => {
      event.preventDefault();
      const targetId = card.dataset.id;
      if (!draggingId || draggingId === targetId) return;
      const order = profile.priorityOrder.filter(id => id !== draggingId);
      const targetIndex = order.indexOf(targetId);
      order.splice(targetIndex, 0, draggingId);
      profile.priorityOrder = order;
      markDirty();
      renderActiveTab();
    });
  });
  document.querySelectorAll('.select-driver').forEach(button => button.addEventListener('click', () => {
    profile.selectedDriverId = button.dataset.id;
    renderActiveTab();
  }));
  document.querySelectorAll('.delete-driver').forEach(button => button.addEventListener('click', () => deleteDriver(button.dataset.id)));
  document.getElementById('addPriorityButton')?.addEventListener('click', openDriverModal);
  const driver = APP.project.priorities.find(item => item.id === profile.selectedDriverId);
  if (!driver) return;
  const bindings = [
    ['driverNameInput', 'name', String], ['driverInputKeyInput', 'inputKey', String], ['driverBaseWeightInput', 'baseWeight', Number],
    ['driverIntervalInput', 'evaluationInterval', Number], ['driverDescriptionInput', 'description', String]
  ];
  bindings.forEach(([id, key, convert]) => document.getElementById(id)?.addEventListener('input', event => {
    driver[key] = convert(event.target.value);
    markDirty();
    if (key === 'name') renderProfileList();
  }));
  document.getElementById('driverCurveTypeSelect')?.addEventListener('change', event => {
    driver.curveType = event.target.value;
    driver.curvePoints = curvePreset(driver.curveType);
    markDirty();
    drawCurveCanvas();
  });
  document.getElementById('driverOffLeashInput')?.addEventListener('input', event => { driver.contexts ||= {}; driver.contexts.off_leash = Number(event.target.value); markDirty(); });
  document.getElementById('driverOnLeashInput')?.addEventListener('input', event => { driver.contexts ||= {}; driver.contexts.on_leash = Number(event.target.value); markDirty(); });
  bindCurveCanvas(driver);
}

function bindGoalEvents() {
  const profile = selectedProfile();
  document.querySelectorAll('.goal-allowed').forEach(input => input.addEventListener('change', () => {
    profile.allowedGoalIds = input.checked
      ? [...new Set([...profile.allowedGoalIds, input.dataset.id])]
      : profile.allowedGoalIds.filter(id => id !== input.dataset.id);
    markDirty();
  }));
  document.querySelectorAll('.edit-goal').forEach(button => button.addEventListener('click', () => openGoalModal(button.dataset.id)));
  document.querySelectorAll('.delete-goal').forEach(button => button.addEventListener('click', () => deleteGoal(button.dataset.id)));
  document.getElementById('addGoalButton')?.addEventListener('click', () => openGoalModal());
}

function bindActionEvents() {
  const profile = selectedProfile();
  document.querySelectorAll('.action-allowed').forEach(input => input.addEventListener('change', () => {
    profile.allowedActionIds = input.checked
      ? [...new Set([...profile.allowedActionIds, input.dataset.id])]
      : profile.allowedActionIds.filter(id => id !== input.dataset.id);
    markDirty();
  }));
  document.querySelectorAll('.edit-action').forEach(button => button.addEventListener('click', () => openActionModal(button.dataset.id)));
  document.querySelectorAll('.delete-action').forEach(button => button.addEventListener('click', () => deleteAction(button.dataset.id)));
  document.getElementById('addActionButton')?.addEventListener('click', () => openActionModal());
}

function bindBlackboardEvents() {
  document.getElementById('addBlackboardButton')?.addEventListener('click', () => openBlackboardModal());
  document.querySelectorAll('.edit-blackboard').forEach(button => button.addEventListener('click', () => openBlackboardModal(button.dataset.id)));
  document.querySelectorAll('.delete-blackboard').forEach(button => button.addEventListener('click', () => deleteBlackboard(button.dataset.id)));
}

function bindSimulationEvents() {
  document.getElementById('simulationProfileSelect')?.addEventListener('change', event => {
    APP.selectedProfileId = event.target.value;
    APP.project.simulation.activeProfileId = event.target.value;
    renderProfileList();
    renderActiveTab();
  });
  document.getElementById('simulationLeashSelect')?.addEventListener('change', event => {
    APP.project.simulation.leashMode = event.target.value;
    markDirty();
  });
  document.querySelectorAll('.simulation-value').forEach(input => {
    const eventName = input.type === 'checkbox' ? 'change' : 'input';
    input.addEventListener(eventName, () => {
      APP.project.simulation.worldState[input.dataset.key] = input.dataset.type === 'boolean' ? input.checked : input.dataset.type === 'number' ? Number(input.value) : input.value;
      markDirty();
    });
  });
  document.getElementById('runSimulationButton')?.addEventListener('click', runSimulation);
  document.getElementById('resetSimulationButton')?.addEventListener('click', () => {
    APP.project.simulation.worldState = Object.fromEntries(APP.project.blackboard.map(entry => [entry.key, entry.defaultValue]));
    APP.project.simulation.lastResult = null;
    APP.project.simulation.log = [];
    markDirty('Simulation state reset');
    renderActiveTab();
  });
}

function addTagFromInput(listKey, inputId) {
  const profile = selectedProfile();
  const input = document.getElementById(inputId);
  const value = slugify(input.value);
  if (!value) return;
  profile[listKey] = [...new Set([...profile[listKey], value])];
  markDirty();
  renderActiveTab();
}

function openModal(title, bodyHtml, commit) {
  APP.modalCommit = commit;
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalBody').innerHTML = bodyHtml;
  document.getElementById('modalBackdrop').classList.remove('hidden');
}

function closeModal() {
  APP.modalCommit = null;
  document.getElementById('modalBackdrop').classList.add('hidden');
  document.getElementById('modalBody').innerHTML = '';
}

function openProfileModal() {
  openModal('Create Profile', `
    <div class="form-grid">
      <label>Name<input id="modalProfileName" value="New Creature Profile"></label>
      <label>Tier<select id="modalProfileTier">${ENTITY_TIERS.map(tier => `<option value="${tier}">${formatLabel(tier)}</option>`).join('')}</select></label>
      <label>Color<input id="modalProfileColor" type="color" value="#a97aff"></label>
      <label class="full">Description<textarea id="modalProfileDescription">A new database-driven AI profile.</textarea></label>
    </div>
  `, () => {
    const tier = document.getElementById('modalProfileTier').value;
    const name = document.getElementById('modalProfileName').value.trim() || 'New Profile';
    const profile = {
      id: uid('profile'), key: `${slugify(name)}_v1`, name, tier,
      color: document.getElementById('modalProfileColor').value,
      description: document.getElementById('modalProfileDescription').value,
      active: true,
      dispositions: {}, fixations: [], fascinations: [], objectAffinities: {},
      allowedGoalIds: APP.project.goals.filter(goal => goal.tier === tier).map(goal => goal.id),
      allowedActionIds: APP.project.actions.filter(action => action.tiers.includes(tier)).map(action => action.id),
      priorityOrder: APP.project.priorities.map(driver => driver.id), leashMode: tier === 'creature' ? 'off_leash' : 'either',
      leashModifiers: tier === 'creature' ? {
        off_leash: { exploreMultiplier: 1.5, obedienceMultiplier: 0.5, maxActionDistance: 120, allowMischief: true, learningMultiplier: 0.8 },
        on_leash: { exploreMultiplier: 0.5, obedienceMultiplier: 2, maxActionDistance: 25, allowMischief: false, learningMultiplier: 1.8 }
      } : {}
    };
    APP.project.profiles.push(profile);
    APP.selectedProfileId = profile.id;
    markDirty();
    closeModal();
    renderAll();
  });
}

function openDispositionModal() {
  const profile = selectedProfile();
  openModal('Add Disposition', `
    <div class="form-grid">
      <label>Name<input id="modalDispositionKey" placeholder="curiosity"></label>
      <label>Starting value<input id="modalDispositionValue" type="number" min="0" max="1" step="0.01" value="0.5"></label>
    </div>
  `, () => {
    const key = slugify(document.getElementById('modalDispositionKey').value);
    profile.dispositions[key] = clamp(document.getElementById('modalDispositionValue').value);
    markDirty();
    closeModal();
    renderActiveTab();
  });
}

function openAffinityModal(existingKey = null) {
  const profile = selectedProfile();
  const interactions = existingKey ? profile.objectAffinities[existingKey] : { inspect: 0.5 };
  openModal(existingKey ? 'Edit Object Affinity' : 'Add Object Affinity', `
    <div class="form-grid">
      <label>Object key<input id="modalAffinityObject" value="${escapeHtml(existingKey || '')}" ${existingKey ? 'readonly' : ''}></label>
      <label class="full">Interactions JSON<textarea id="modalAffinityInteractions">${escapeHtml(JSON.stringify(interactions, null, 2))}</textarea></label>
    </div>
  `, () => {
    const objectKey = slugify(document.getElementById('modalAffinityObject').value);
    let parsed;
    try { parsed = JSON.parse(document.getElementById('modalAffinityInteractions').value); }
    catch { toast('Interactions must be valid JSON.'); return false; }
    profile.objectAffinities[objectKey] = parsed;
    markDirty();
    closeModal();
    renderActiveTab();
  });
}

function openDriverModal() {
  openModal('Add Utility Driver', `
    <div class="form-grid">
      <label>Name<input id="modalDriverName" value="New Driver"></label>
      <label>Input key<input id="modalDriverInput" value="need.new_driver"></label>
      <label>Base weight<input id="modalDriverWeight" type="number" min="0" step="0.05" value="1"></label>
      <label>Evaluation interval<input id="modalDriverInterval" type="number" min="0.05" step="0.05" value="1"></label>
      <label>Curve<select id="modalDriverCurve">${CURVE_TYPES.map(type => `<option value="${type}">${formatLabel(type)}</option>`).join('')}</select></label>
      <label class="full">Description<textarea id="modalDriverDescription">Evaluates a normalized blackboard input and contributes to goal utility.</textarea></label>
    </div>
  `, () => {
    const name = document.getElementById('modalDriverName').value.trim() || 'New Driver';
    const driver = {
      id: uid('driver'), key: slugify(name), name,
      description: document.getElementById('modalDriverDescription').value,
      baseWeight: Number(document.getElementById('modalDriverWeight').value),
      evaluationInterval: Number(document.getElementById('modalDriverInterval').value),
      inputKey: document.getElementById('modalDriverInput').value.trim(),
      curveType: document.getElementById('modalDriverCurve').value,
      curvePoints: curvePreset(document.getElementById('modalDriverCurve').value),
      contexts: { off_leash: 1, on_leash: 1 }, enabled: true
    };
    APP.project.priorities.push(driver);
    APP.project.profiles.forEach(profile => profile.priorityOrder.push(driver.id));
    selectedProfile().selectedDriverId = driver.id;
    markDirty();
    closeModal();
    renderActiveTab();
  });
}

function openGoalModal(goalId = null) {
  const profile = selectedProfile();
  const existing = APP.project.goals.find(goal => goal.id === goalId);
  const goal = existing ? deepClone(existing) : {
    id: uid('goal'), key: 'new_goal', name: 'New Goal', tier: profile.tier,
    driverKey: APP.project.priorities[0]?.key || '', desiredState: [{ key: '', operator: '==', value: true }],
    baseBias: 0, cooldownSeconds: 0, enabled: true, tags: []
  };
  openModal(existing ? 'Edit Goal' : 'Add Goal', `
    <div class="form-grid">
      <label>Name<input id="modalGoalName" value="${escapeHtml(goal.name)}"></label>
      <label>Key<input id="modalGoalKey" value="${escapeHtml(goal.key)}"></label>
      <label>Tier<select id="modalGoalTier">${ENTITY_TIERS.map(tier => `<option value="${tier}" ${tier === goal.tier ? 'selected' : ''}>${formatLabel(tier)}</option>`).join('')}</select></label>
      <label>Utility driver<select id="modalGoalDriver">${APP.project.priorities.map(driver => `<option value="${escapeHtml(driver.key)}" ${driver.key === goal.driverKey ? 'selected' : ''}>${escapeHtml(driver.name)}</option>`).join('')}</select></label>
      <label>Base bias<input id="modalGoalBias" type="number" step="0.05" value="${Number(goal.baseBias)}"></label>
      <label>Cooldown seconds<input id="modalGoalCooldown" type="number" min="0" step="0.1" value="${Number(goal.cooldownSeconds)}"></label>
      <label class="full">Desired state JSON<textarea id="modalGoalState">${escapeHtml(JSON.stringify(goal.desiredState, null, 2))}</textarea></label>
      <label class="full">Tags, comma-separated<input id="modalGoalTags" value="${escapeHtml(goal.tags.join(', '))}"></label>
    </div>
  `, () => {
    let desiredState;
    try { desiredState = JSON.parse(document.getElementById('modalGoalState').value); }
    catch { toast('Desired state must be valid JSON.'); return false; }
    const updated = {
      ...goal,
      name: document.getElementById('modalGoalName').value.trim() || 'New Goal',
      key: slugify(document.getElementById('modalGoalKey').value),
      tier: document.getElementById('modalGoalTier').value,
      driverKey: document.getElementById('modalGoalDriver').value,
      baseBias: Number(document.getElementById('modalGoalBias').value),
      cooldownSeconds: Number(document.getElementById('modalGoalCooldown').value),
      desiredState,
      tags: document.getElementById('modalGoalTags').value.split(',').map(slugify).filter(Boolean)
    };
    if (existing) Object.assign(existing, updated);
    else {
      APP.project.goals.push(updated);
      APP.project.profiles.filter(item => item.tier === updated.tier).forEach(item => item.allowedGoalIds.push(updated.id));
    }
    markDirty();
    closeModal();
    renderActiveTab();
  });
}

function openActionModal(actionId = null) {
  const profile = selectedProfile();
  const existing = APP.project.actions.find(action => action.id === actionId);
  const action = existing ? deepClone(existing) : {
    id: uid('action'), key: 'new_action', name: 'New Action', tiers: [profile.tier], contexts: ['either'],
    preconditions: [], effects: [], cost: { base: 1, formula: 'base' }, durationSeconds: 1, tags: [], enabled: true
  };
  openModal(existing ? 'Edit Action Card' : 'Add Action Card', `
    <div class="form-grid">
      <label>Name<input id="modalActionName" value="${escapeHtml(action.name)}"></label>
      <label>Key<input id="modalActionKey" value="${escapeHtml(action.key)}"></label>
      <label class="full">Entity tiers<div class="tag-list">${ENTITY_TIERS.map(tier => `<label class="context-badge"><input class="modal-action-tier" type="checkbox" value="${tier}" ${action.tiers.includes(tier) ? 'checked' : ''}> ${formatLabel(tier)}</label>`).join('')}</div></label>
      <label class="full">Leash contexts<div class="tag-list">${LEASH_CONTEXTS.map(context => `<label class="context-badge"><input class="modal-action-context" type="checkbox" value="${context}" ${action.contexts.includes(context) ? 'checked' : ''}> ${formatLabel(context)}</label>`).join('')}</div></label>
      <label class="full">Preconditions JSON<textarea id="modalActionPreconditions">${escapeHtml(JSON.stringify(action.preconditions, null, 2))}</textarea></label>
      <label class="full">Effects JSON<textarea id="modalActionEffects">${escapeHtml(JSON.stringify(action.effects, null, 2))}</textarea></label>
      <label>Base cost<input id="modalActionBaseCost" type="number" min="0" step="0.1" value="${Number(action.cost?.base ?? 1)}"></label>
      <label>Duration seconds<input id="modalActionDuration" type="number" min="0" step="0.1" value="${Number(action.durationSeconds ?? 1)}"></label>
      <label class="full">Cost formula<input id="modalActionFormula" value="${escapeHtml(action.cost?.formula || 'base')}"></label>
      <label class="full">Tags, comma-separated<input id="modalActionTags" value="${escapeHtml(action.tags.join(', '))}"></label>
    </div>
  `, () => {
    let preconditions, effects;
    try {
      preconditions = JSON.parse(document.getElementById('modalActionPreconditions').value);
      effects = JSON.parse(document.getElementById('modalActionEffects').value);
    } catch {
      toast('Preconditions and effects must be valid JSON.');
      return false;
    }
    const tiers = [...document.querySelectorAll('.modal-action-tier:checked')].map(input => input.value);
    const contexts = [...document.querySelectorAll('.modal-action-context:checked')].map(input => input.value);
    if (!tiers.length || !contexts.length) { toast('Choose at least one tier and context.'); return false; }
    const updated = {
      ...action,
      name: document.getElementById('modalActionName').value.trim() || 'New Action',
      key: slugify(document.getElementById('modalActionKey').value),
      tiers, contexts, preconditions, effects,
      cost: { base: Number(document.getElementById('modalActionBaseCost').value), formula: document.getElementById('modalActionFormula').value.trim() || 'base' },
      durationSeconds: Number(document.getElementById('modalActionDuration').value),
      tags: document.getElementById('modalActionTags').value.split(',').map(slugify).filter(Boolean)
    };
    if (existing) Object.assign(existing, updated);
    else {
      APP.project.actions.push(updated);
      APP.project.profiles.filter(item => tiers.includes(item.tier)).forEach(item => item.allowedActionIds.push(updated.id));
    }
    markDirty();
    closeModal();
    renderActiveTab();
  });
}

function openBlackboardModal(entryId = null) {
  const existing = APP.project.blackboard.find(entry => entry.id === entryId);
  const entry = existing ? deepClone(existing) : { id: uid('bb'), key: 'custom.key', type: 'number', defaultValue: 0, scope: 'entity', description: '' };
  openModal(existing ? 'Edit Blackboard Key' : 'Add Blackboard Key', `
    <div class="form-grid">
      <label>Key<input id="modalBlackboardKey" value="${escapeHtml(entry.key)}"></label>
      <label>Type<select id="modalBlackboardType">${VALUE_TYPES.map(type => `<option value="${type}" ${type === entry.type ? 'selected' : ''}>${formatLabel(type)}</option>`).join('')}</select></label>
      <label>Scope<input id="modalBlackboardScope" value="${escapeHtml(entry.scope)}"></label>
      <label>Default value as JSON<input id="modalBlackboardDefault" value="${escapeHtml(JSON.stringify(entry.defaultValue))}"></label>
      <label class="full">Description<textarea id="modalBlackboardDescription">${escapeHtml(entry.description)}</textarea></label>
    </div>
  `, () => {
    let defaultValue;
    try { defaultValue = JSON.parse(document.getElementById('modalBlackboardDefault').value); }
    catch { toast('Default value must be valid JSON.'); return false; }
    const oldKey = entry.key;
    const updated = {
      ...entry,
      key: document.getElementById('modalBlackboardKey').value.trim(),
      type: document.getElementById('modalBlackboardType').value,
      defaultValue,
      scope: slugify(document.getElementById('modalBlackboardScope').value),
      description: document.getElementById('modalBlackboardDescription').value
    };
    if (existing) Object.assign(existing, updated); else APP.project.blackboard.push(updated);
    if (oldKey !== updated.key && Object.prototype.hasOwnProperty.call(APP.project.simulation.worldState, oldKey)) {
      APP.project.simulation.worldState[updated.key] = APP.project.simulation.worldState[oldKey];
      delete APP.project.simulation.worldState[oldKey];
    } else if (!Object.prototype.hasOwnProperty.call(APP.project.simulation.worldState, updated.key)) {
      APP.project.simulation.worldState[updated.key] = defaultValue;
    }
    markDirty();
    closeModal();
    renderActiveTab();
  });
}

function deleteProfile(profileId) {
  if (APP.project.profiles.length <= 1) { toast('At least one profile is required.'); return; }
  const profile = APP.project.profiles.find(item => item.id === profileId);
  if (!profile || !confirm(`Delete ${profile.name}?`)) return;
  APP.project.profiles = APP.project.profiles.filter(item => item.id !== profileId);
  APP.selectedProfileId = APP.project.profiles[0].id;
  markDirty();
  renderAll();
}

function deleteDriver(driverId) {
  const driver = APP.project.priorities.find(item => item.id === driverId);
  if (!driver || !confirm(`Delete utility driver ${driver.name}?`)) return;
  APP.project.priorities = APP.project.priorities.filter(item => item.id !== driverId);
  APP.project.profiles.forEach(profile => {
    profile.priorityOrder = profile.priorityOrder.filter(id => id !== driverId);
    if (profile.selectedDriverId === driverId) profile.selectedDriverId = profile.priorityOrder[0] || null;
  });
  markDirty();
  renderActiveTab();
}

function deleteGoal(goalId) {
  const goal = APP.project.goals.find(item => item.id === goalId);
  if (!goal || !confirm(`Delete goal ${goal.name}?`)) return;
  APP.project.goals = APP.project.goals.filter(item => item.id !== goalId);
  APP.project.profiles.forEach(profile => profile.allowedGoalIds = profile.allowedGoalIds.filter(id => id !== goalId));
  markDirty();
  renderActiveTab();
}

function deleteAction(actionId) {
  const action = APP.project.actions.find(item => item.id === actionId);
  if (!action || !confirm(`Delete action ${action.name}?`)) return;
  APP.project.actions = APP.project.actions.filter(item => item.id !== actionId);
  APP.project.profiles.forEach(profile => profile.allowedActionIds = profile.allowedActionIds.filter(id => id !== actionId));
  markDirty();
  renderActiveTab();
}

function deleteBlackboard(entryId) {
  const entry = APP.project.blackboard.find(item => item.id === entryId);
  if (!entry || !confirm(`Delete blackboard key ${entry.key}?`)) return;
  APP.project.blackboard = APP.project.blackboard.filter(item => item.id !== entryId);
  delete APP.project.simulation.worldState[entry.key];
  markDirty();
  renderActiveTab();
}

function curvePreset(type) {
  const points = {
    linear: [{x:0,y:0},{x:.25,y:.25},{x:.5,y:.5},{x:.75,y:.75},{x:1,y:1}],
    ease_in: [{x:0,y:0},{x:.25,y:.03},{x:.5,y:.18},{x:.75,y:.52},{x:1,y:1}],
    ease_out: [{x:0,y:0},{x:.25,y:.48},{x:.5,y:.75},{x:.75,y:.93},{x:1,y:1}],
    sigmoid: [{x:0,y:.02},{x:.25,y:.08},{x:.5,y:.5},{x:.75,y:.92},{x:1,y:.98}],
    custom: [{x:0,y:0},{x:.25,y:.25},{x:.5,y:.5},{x:.75,y:.75},{x:1,y:1}]
  };
  return deepClone(points[type] || points.linear);
}

function drawCurveCanvas() {
  const canvas = document.getElementById('curveCanvas');
  const profile = selectedProfile();
  const driver = APP.project.priorities.find(item => item.id === profile?.selectedDriverId);
  if (!canvas || !driver) return;
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.max(500, Math.round(rect.width * dpr));
  canvas.height = Math.round(320 * dpr);
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  const width = canvas.width / dpr;
  const height = canvas.height / dpr;
  const pad = 34;
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = '#0f141a'; ctx.fillRect(0, 0, width, height);
  ctx.strokeStyle = '#27313d'; ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const x = pad + (width - pad * 2) * (i / 4);
    const y = pad + (height - pad * 2) * (i / 4);
    ctx.beginPath(); ctx.moveTo(x, pad); ctx.lineTo(x, height - pad); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(pad, y); ctx.lineTo(width - pad, y); ctx.stroke();
  }
  ctx.fillStyle = '#7f91a4'; ctx.font = '10px system-ui';
  ctx.fillText('0', pad - 12, height - pad + 14);
  ctx.fillText('1 input', width - pad - 28, height - pad + 14);
  ctx.save(); ctx.translate(12, pad + 24); ctx.rotate(-Math.PI / 2); ctx.fillText('utility', 0, 0); ctx.restore();
  const points = driver.curvePoints || curvePreset(driver.curveType);
  ctx.strokeStyle = '#22d3c5'; ctx.lineWidth = 3; ctx.beginPath();
  points.forEach((point, index) => {
    const x = pad + point.x * (width - pad * 2);
    const y = height - pad - point.y * (height - pad * 2);
    if (index === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  });
  ctx.stroke();
  points.forEach((point, index) => {
    const x = pad + point.x * (width - pad * 2);
    const y = height - pad - point.y * (height - pad * 2);
    ctx.beginPath(); ctx.arc(x, y, index === APP.curveDragPoint ? 7 : 5, 0, Math.PI * 2);
    ctx.fillStyle = index === APP.curveDragPoint ? '#f39a38' : '#e8ffff'; ctx.fill();
    ctx.strokeStyle = '#087f78'; ctx.lineWidth = 2; ctx.stroke();
  });
}

function bindCurveCanvas(driver) {
  const canvas = document.getElementById('curveCanvas');
  if (!canvas) return;
  const pointFromEvent = event => {
    const rect = canvas.getBoundingClientRect();
    const pad = 34;
    return {
      x: clamp((event.clientX - rect.left - pad) / (rect.width - pad * 2)),
      y: clamp(1 - (event.clientY - rect.top - pad) / (320 - pad * 2))
    };
  };
  canvas.addEventListener('pointerdown', event => {
    const point = pointFromEvent(event);
    const points = driver.curvePoints || curvePreset(driver.curveType);
    let nearest = 0, distance = Infinity;
    points.forEach((candidate, index) => {
      const d = Math.hypot(candidate.x - point.x, candidate.y - point.y);
      if (d < distance) { distance = d; nearest = index; }
    });
    APP.curveDragPoint = nearest;
    canvas.setPointerCapture(event.pointerId);
    updateCurvePoint(driver, nearest, point);
  });
  canvas.addEventListener('pointermove', event => {
    if (APP.curveDragPoint === null) return;
    updateCurvePoint(driver, APP.curveDragPoint, pointFromEvent(event));
  });
  canvas.addEventListener('pointerup', event => {
    if (APP.curveDragPoint !== null) markDirty();
    APP.curveDragPoint = null;
    if (canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId);
    drawCurveCanvas();
  });
}

function updateCurvePoint(driver, index, point) {
  driver.curveType = 'custom';
  document.getElementById('driverCurveTypeSelect').value = 'custom';
  const points = driver.curvePoints || curvePreset('custom');
  const minX = index === 0 ? 0 : points[index - 1].x + 0.01;
  const maxX = index === points.length - 1 ? 1 : points[index + 1].x - 0.01;
  points[index] = { x: index === 0 ? 0 : index === points.length - 1 ? 1 : clamp(point.x, minX, maxX), y: clamp(point.y) };
  driver.curvePoints = points;
  drawCurveCanvas();
}

function evaluateCurve(driver, input) {
  const points = driver.curvePoints || curvePreset(driver.curveType);
  const x = clamp(input);
  if (x <= points[0].x) return clamp(points[0].y);
  for (let i = 1; i < points.length; i++) {
    if (x <= points[i].x) {
      const left = points[i - 1], right = points[i];
      const t = (x - left.x) / Math.max(0.0001, right.x - left.x);
      return clamp(left.y + (right.y - left.y) * t);
    }
  }
  return clamp(points[points.length - 1].y);
}

function compareValue(actual, operator, expected) {
  switch (operator) {
    case '==': return actual === expected;
    case '!=': return actual !== expected;
    case '>': return Number(actual) > Number(expected);
    case '>=': return Number(actual) >= Number(expected);
    case '<': return Number(actual) < Number(expected);
    case '<=': return Number(actual) <= Number(expected);
    case 'contains': return Array.isArray(actual) ? actual.includes(expected) : String(actual).includes(String(expected));
    case 'not_contains': return Array.isArray(actual) ? !actual.includes(expected) : !String(actual).includes(String(expected));
    default: return false;
  }
}

function stateSatisfies(state, conditions) {
  return conditions.every(condition => compareValue(state[condition.key], condition.operator, condition.value));
}

function applyEffects(state, effects) {
  const next = { ...state };
  effects.forEach(effect => {
    const current = next[effect.key];
    switch (effect.operation) {
      case 'set': next[effect.key] = effect.value; break;
      case 'add': next[effect.key] = Number(current || 0) + Number(effect.value || 0); break;
      case 'multiply': next[effect.key] = Number(current || 0) * Number(effect.value || 0); break;
      case 'toggle': next[effect.key] = !Boolean(current); break;
      case 'remove': delete next[effect.key]; break;
      default: next[effect.key] = effect.value;
    }
  });
  return next;
}

function estimateActionCost(action, profile, state) {
  let cost = Number(action.cost?.base ?? 1);
  const formula = String(action.cost?.formula || 'base');
  const replacements = {
    'disposition.curiosity': profile.dispositions.curiosity ?? 0,
    'disposition.mischief': profile.dispositions.mischief ?? 0,
    'disposition.obedience': profile.dispositions.obedience ?? 0,
    'disposition.cowardice': profile.dispositions.cowardice ?? 0,
    'disposition.gluttony': profile.dispositions.gluttony ?? 0,
    'affinity.boulder_kick': profile.objectAffinities?.boulder?.kick ?? 0,
    'affinity.target': 0.5,
    'relationship.village_love': Number(state['relationship.village_love'] || 0),
    'distance.normalized': Number(state['distance.normalized'] || 0.5),
    'distance.to_safety': Number(state['distance.to_safety'] || 1),
    'skill.job': Number(state['skill.job'] || 0.5),
    'need.fatigue': Number(state['need.fatigue'] || 0.2),
    'village.labor_shortage': Number(state['village.labor_shortage'] || 0.2),
    'village.fertility': Number(state['village.fertility'] || 0.5),
    'weather.penalty': Number(state['weather.penalty'] || 0),
    'confidence.gesture': Number(state['confidence.gesture'] || 0.8),
    'miracle.cost_normalized': Number(state['miracle.cost_normalized'] || 0.3)
  };
  let expression = formula.replace(/\bbase\b/g, String(cost));
  Object.entries(replacements).forEach(([key, value]) => { expression = expression.split(key).join(String(value)); });
  if (/^[0-9+\-*/().\s]+$/.test(expression)) {
    try { cost = Function(`"use strict"; return (${expression});`)(); } catch { cost = Number(action.cost?.base ?? 1); }
  }
  return Math.max(0.01, Number(cost) || 1);
}

function actionContextAllowed(action, leashMode) {
  return action.contexts.includes('either') || action.contexts.includes(leashMode);
}

function planGoal(profile, goal, initialState, leashMode) {
  if (stateSatisfies(initialState, goal.desiredState)) return [];
  const allowed = APP.project.actions.filter(action =>
    action.enabled &&
    profile.allowedActionIds.includes(action.id) &&
    action.tiers.includes(profile.tier) &&
    actionContextAllowed(action, leashMode) &&
    !(profile.tier === 'creature' && leashMode === 'on_leash' && action.tags.includes('mischief') && profile.leashModifiers?.on_leash?.allowMischief === false)
  );
  const queue = [{ state: initialState, plan: [], cost: 0 }];
  const visited = new Map();
  let expanded = 0;
  while (queue.length && expanded < APP.project.settings.planningNodeLimit) {
    queue.sort((a, b) => a.cost - b.cost);
    const node = queue.shift();
    const signature = JSON.stringify(Object.keys(node.state).sort().reduce((acc, key) => { acc[key] = node.state[key]; return acc; }, {}));
    if (visited.has(signature) && visited.get(signature) <= node.cost) continue;
    visited.set(signature, node.cost);
    if (stateSatisfies(node.state, goal.desiredState)) return node.plan;
    if (node.plan.length >= APP.project.settings.planningDepthLimit) continue;
    expanded++;
    for (const action of allowed) {
      if (!stateSatisfies(node.state, action.preconditions)) continue;
      const actionCost = estimateActionCost(action, profile, node.state);
      queue.push({
        state: applyEffects(node.state, action.effects),
        plan: [...node.plan, { id: action.id, name: action.name, cost: actionCost, durationSeconds: action.durationSeconds }],
        cost: node.cost + actionCost
      });
    }
  }
  return null;
}

function runSimulation() {
  const profile = selectedProfile();
  const sim = APP.project.simulation;
  const leashMode = profile.tier === 'creature' ? sim.leashMode : 'either';
  const goals = APP.project.goals.filter(goal => goal.enabled && goal.tier === profile.tier && profile.allowedGoalIds.includes(goal.id));
  const scores = goals.map(goal => {
    const driver = APP.project.priorities.find(item => item.key === goal.driverKey);
    if (!driver || !driver.enabled) return { goal, score: 0, breakdown: 'Missing or disabled driver.' };
    const input = Number(sim.worldState[driver.inputKey] ?? 0);
    const curve = evaluateCurve(driver, input);
    const contextMultiplier = profile.tier === 'creature' ? Number(driver.contexts?.[leashMode] ?? 1) : 1;
    let personality = 1;
    if (driver.key === 'curiosity') personality += Number(profile.dispositions.curiosity || 0) * 0.35;
    if (driver.key === 'obedience') personality += Number(profile.dispositions.obedience || 0) * 0.4;
    if (driver.key === 'fear') personality += Number(profile.dispositions.cowardice || 0) * 0.25;
    if (driver.key === 'hunger') personality += Number(profile.dispositions.gluttony || 0) * 0.2;
    const score = clamp(curve * Number(driver.baseWeight) * contextMultiplier * personality + Number(goal.baseBias || 0));
    return {
      goal,
      score,
      breakdown: `input ${input.toFixed(2)} × curve ${curve.toFixed(2)} × weight ${Number(driver.baseWeight).toFixed(2)} × context ${contextMultiplier.toFixed(2)} × personality ${personality.toFixed(2)} + bias ${Number(goal.baseBias).toFixed(2)}`
    };
  }).sort((a, b) => b.score - a.score);
  const selected = scores[0];
  const plan = selected ? planGoal(profile, selected.goal, sim.worldState, leashMode) : null;
  const result = {
    evaluatedAt: nowIso(),
    profileId: profile.id,
    leashMode,
    selectedGoalId: selected?.goal.id || null,
    selectedScore: selected?.score || 0,
    reason: selected ? `${selected.goal.name} produced the highest current utility.` : 'No enabled goals were available.',
    scores: scores.map(item => ({ goalId: item.goal.id, goalName: item.goal.name, score: item.score, breakdown: item.breakdown })),
    plan: plan || []
  };
  sim.lastResult = result;
  sim.log.unshift(`[${new Date().toLocaleTimeString()}] ${profile.name} selected ${selected?.goal.name || 'no goal'} at utility ${(selected?.score || 0).toFixed(3)}.`);
  if (plan === null) sim.log.unshift(`[${new Date().toLocaleTimeString()}] Planner exhausted its search without satisfying the goal.`);
  else sim.log.unshift(`[${new Date().toLocaleTimeString()}] Planner produced ${plan.length} action step${plan.length === 1 ? '' : 's'} with total cost ${plan.reduce((sum, step) => sum + step.cost, 0).toFixed(2)}.`);
  sim.log = sim.log.slice(0, 100);
  markDirty('Simulation completed');
  renderActiveTab();
}

function validateProject() {
  const issues = [];
  const duplicateCheck = (collection, label) => {
    const ids = new Set(), keys = new Set();
    collection.forEach(item => {
      if (!item.id) issues.push({ level: 'error', message: `${label} is missing a stable ID.` });
      else if (ids.has(item.id)) issues.push({ level: 'error', message: `Duplicate ${label} ID: ${item.id}` });
      ids.add(item.id);
      if (item.key) {
        if (keys.has(item.key)) issues.push({ level: 'error', message: `Duplicate ${label} key: ${item.key}` });
        keys.add(item.key);
      }
    });
  };
  duplicateCheck(APP.project.profiles, 'profile');
  duplicateCheck(APP.project.priorities, 'driver');
  duplicateCheck(APP.project.goals, 'goal');
  duplicateCheck(APP.project.actions, 'action');
  duplicateCheck(APP.project.blackboard, 'blackboard entry');
  const blackboardKeys = new Set(APP.project.blackboard.map(entry => entry.key));
  APP.project.priorities.forEach(driver => {
    if (!blackboardKeys.has(driver.inputKey)) issues.push({ level: 'warning', message: `Driver ${driver.name} reads undefined blackboard key ${driver.inputKey}.` });
  });
  APP.project.goals.forEach(goal => {
    if (!APP.project.priorities.some(driver => driver.key === goal.driverKey)) issues.push({ level: 'error', message: `Goal ${goal.name} references missing driver ${goal.driverKey}.` });
    goal.desiredState.forEach(condition => {
      if (!blackboardKeys.has(condition.key)) issues.push({ level: 'warning', message: `Goal ${goal.name} targets undeclared key ${condition.key}.` });
    });
  });
  APP.project.actions.forEach(action => {
    action.preconditions.forEach(condition => {
      if (!blackboardKeys.has(condition.key)) issues.push({ level: 'warning', message: `Action ${action.name} requires undeclared key ${condition.key}.` });
    });
    action.effects.forEach(effect => {
      if (!blackboardKeys.has(effect.key)) issues.push({ level: 'warning', message: `Action ${action.name} writes undeclared key ${effect.key}.` });
    });
  });
  APP.project.profiles.forEach(profile => {
    profile.allowedGoalIds.forEach(id => { if (!APP.project.goals.some(goal => goal.id === id)) issues.push({ level: 'error', message: `${profile.name} references missing goal ${id}.` }); });
    profile.allowedActionIds.forEach(id => { if (!APP.project.actions.some(action => action.id === id)) issues.push({ level: 'error', message: `${profile.name} references missing action ${id}.` }); });
  });
  if (!issues.length) issues.push({ level: 'ok', message: 'All stable IDs and primary references are valid.' });
  return issues;
}

function renderValidation() {
  const issues = validateProject();
  document.getElementById('validationList').innerHTML = issues.slice(0, 30).map(issue => `<div class="validation-item ${issue.level}">${escapeHtml(issue.message)}</div>`).join('');
}

function exportSelectedProfile() {
  const profile = selectedProfile();
  if (!profile) {
    toast('Select a profile before exporting.');
    return;
  }
  const goalIds = new Set(profile.allowedGoalIds || []);
  const actionIds = new Set(profile.allowedActionIds || []);
  const drivers = (profile.priorityOrder || [])
    .map(id => APP.project.priorities.find(driver => driver.id === id))
    .filter(Boolean);
  const goals = APP.project.goals.filter(goal => goalIds.has(goal.id));
  const actions = APP.project.actions.filter(action => actionIds.has(action.id));
  const referencedKeys = new Set();
  drivers.forEach(driver => referencedKeys.add(driver.inputKey));
  goals.forEach(goal => goal.desiredState.forEach(condition => referencedKeys.add(condition.key)));
  actions.forEach(action => {
    action.preconditions.forEach(condition => referencedKeys.add(condition.key));
    action.effects.forEach(effect => referencedKeys.add(effect.key));
  });
  const payload = {
    schemaVersion: APP.project.schemaVersion,
    exportedAt: nowIso(),
    sourceProjectId: APP.project.projectId,
    sourceProjectTitle: APP.project.title,
    profile: deepClone(profile),
    priorities: deepClone(drivers),
    goals: deepClone(goals),
    actions: deepClone(actions),
    blackboard: deepClone(APP.project.blackboard.filter(entry => referencedKeys.has(entry.key)))
  };
  const filename = `AIDESIGNER_Profile_${slugify(profile.name)}_${new Date().toISOString().slice(0, 10)}.json`;
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
  toast(`${profile.name} and its referenced definitions were exported.`);
}

function exportProject() {
  const filename = `Ungodly_AI_Designer_${new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19)}.json`;
  const blob = new Blob([JSON.stringify(APP.project, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
  toast('Project JSON exported.');
}

async function importProject(file) {
  try {
    const text = await file.text();
    APP.project = normalizeProject(JSON.parse(text));
    APP.selectedProfileId = APP.project.profiles[0]?.id || null;
    saveLocal();
    setSaveState('Imported project saved locally');
    renderAll();
    toast('Project imported.');
  } catch (error) {
    console.error(error);
    toast('Could not import this JSON file.');
  }
}

async function apiRequest(action, payload = {}) {
  const response = await fetch(APP.endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    body: JSON.stringify({ action, ...payload })
  });
  const data = await response.json();
  if (!response.ok || data.ok === false) throw new Error(data.error || `Request failed with ${response.status}`);
  return data;
}

async function saveServer() {
  try {
    setSaveState('Saving to server…', 'dirty');
    const sessionId = document.getElementById('serverSessionInput').value.trim();
    const data = await apiRequest('saveProject', { project: APP.project, serverSessionId: sessionId });
    if (data.project?.updatedAt) APP.project.updatedAt = data.project.updatedAt;
    saveLocal();
    setSaveState('Server save complete');
    toast('Project pushed to server.');
    loadServerList();
  } catch (error) {
    console.error(error);
    setSaveState(error.message, 'error');
    toast(error.message);
  }
}

async function loadServerList() {
  const container = document.getElementById('serverProjectList');
  const countLabel = document.getElementById('serverProjectCount');
  if (countLabel) countLabel.textContent = '…';
  container.innerHTML = '<div class="empty-state">Loading…</div>';
  try {
    const sessionId = document.getElementById('serverSessionInput').value.trim();
    const data = await apiRequest('listProjects', { serverSessionId: sessionId });
    if (countLabel) countLabel.textContent = String(data.projects.length);
    if (!data.projects.length) {
      container.innerHTML = '<div class="empty-state">No saved projects found.</div>';
      return;
    }
    container.innerHTML = data.projects.map(project => `
      <div class="server-project-card"><h3>${escapeHtml(project.title)}</h3><p>${escapeHtml(project.projectId)}<br>${escapeHtml(project.updatedAt)}</p><button class="button secondary full load-server-project" data-id="${escapeHtml(project.projectId)}">Load</button></div>
    `).join('');
    container.querySelectorAll('.load-server-project').forEach(button => button.addEventListener('click', () => loadServerProject(button.dataset.id)));
  } catch (error) {
    if (countLabel) countLabel.textContent = 'ERR';
    container.innerHTML = `<div class="validation-item error">${escapeHtml(error.message)}</div>`;
  }
}

async function loadServerProject(projectId) {
  try {
    const sessionId = document.getElementById('serverSessionInput').value.trim();
    const data = await apiRequest('loadProject', { projectId, serverSessionId: sessionId });
    APP.project = normalizeProject(data.project);
    APP.selectedProfileId = APP.project.profiles[0]?.id || null;
    saveLocal();
    setSaveState('Loaded from server');
    renderAll();
    toast('Server project loaded.');
  } catch (error) {
    toast(error.message);
  }
}

function bindGlobalEvents() {
  document.getElementById('projectTitleInput').addEventListener('input', event => {
    APP.project.title = event.target.value;
    markDirty();
  });
  document.getElementById('profileSearchInput').addEventListener('input', renderProfileList);
  document.getElementById('addProfileButton').addEventListener('click', openProfileModal);
  document.getElementById('globalTraitSearchInput').addEventListener('input', renderSidebarInsights);
  document.getElementById('blackboardSearchInput').addEventListener('input', renderSidebarInsights);
  document.getElementById('addGlobalTraitButton').addEventListener('click', openDispositionModal);
  document.getElementById('addBlackboardQuickButton').addEventListener('click', () => openBlackboardModal());
  document.querySelectorAll('[data-navigate-tab]').forEach(button => button.addEventListener('click', () => {
    APP.activeTab = button.dataset.navigateTab;
    renderActiveTab();
  }));
  document.getElementById('newProjectButton').addEventListener('click', () => {
    if (!confirm('Create a new project and replace the current local draft?')) return;
    APP.project = createDefaultProject();
    APP.selectedProfileId = APP.project.profiles[0].id;
    saveLocal();
    setSaveState('New project created locally');
    renderAll();
  });
  document.getElementById('exportButton').addEventListener('click', exportProject);
  document.getElementById('importButton').addEventListener('click', () => document.getElementById('importFileInput').click());
  document.getElementById('importFileInput').addEventListener('change', event => {
    const file = event.target.files[0];
    if (file) importProject(file);
    event.target.value = '';
  });
  document.getElementById('saveServerButton').addEventListener('click', saveServer);
  document.getElementById('loadServerListButton').addEventListener('click', loadServerList);
  document.getElementById('copyProjectIdButton').addEventListener('click', async () => {
    await navigator.clipboard.writeText(APP.project.projectId);
    toast('Project ID copied.');
  });
  document.getElementById('mainTabs').addEventListener('click', event => {
    const tab = event.target.closest('.tab');
    if (!tab) return;
    APP.activeTab = tab.dataset.tab;
    renderActiveTab();
  });
  document.querySelectorAll('.panel-title').forEach(button => button.addEventListener('click', () => {
    const body = document.getElementById(button.dataset.collapseTarget);
    body.classList.toggle('collapsed');
    button.querySelector('.panel-toggle').textContent = body.classList.contains('collapsed') ? '+' : '−';
  }));
  document.getElementById('deepCollapseButton').addEventListener('click', event => {
    const bodies = [...document.querySelectorAll('.right-sidebar .panel-body')];
    const collapse = bodies.some(body => !body.classList.contains('collapsed'));
    bodies.forEach(body => body.classList.toggle('collapsed', collapse));
    document.querySelectorAll('.right-sidebar .panel-toggle').forEach(toggle => toggle.textContent = collapse ? '+' : '−');
    event.currentTarget.textContent = collapse ? '+' : '−';
  });
  document.getElementById('modalCloseButton').addEventListener('click', closeModal);
  document.getElementById('modalCancelButton').addEventListener('click', closeModal);
  document.getElementById('modalConfirmButton').addEventListener('click', () => {
    if (typeof APP.modalCommit === 'function') APP.modalCommit();
  });
  document.getElementById('modalBackdrop').addEventListener('click', event => {
    if (event.target.id === 'modalBackdrop') closeModal();
  });
  window.addEventListener('resize', () => { if (APP.activeTab === 'priorities') drawCurveCanvas(); });
  window.addEventListener('beforeunload', saveLocal);
}

function init() {
  APP.project = loadLocal();
  APP.selectedProfileId = APP.project.simulation.activeProfileId || APP.project.profiles[0]?.id || null;
  bindGlobalEvents();
  renderAll();
  setSaveState('Local draft loaded');
}

document.addEventListener('DOMContentLoaded', init);
