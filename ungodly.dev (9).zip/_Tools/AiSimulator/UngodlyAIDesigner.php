<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

const MAX_PROJECT_BYTES = 8388608;

function respond(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function readInput(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return $_POST;
    }
    if (strlen($raw) > MAX_PROJECT_BYTES) {
        respond(['ok' => false, 'error' => 'Request is larger than the 8 MB project limit.'], 413);
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        respond(['ok' => false, 'error' => 'Request body must be valid JSON.'], 400);
    }
    return $decoded;
}

function envValue(string $name, ?string $fallback = null): ?string
{
    $value = getenv($name);
    return $value === false || $value === '' ? $fallback : $value;
}

function database(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $host = envValue('DB_HOST', '127.0.0.1');
    $port = envValue('DB_PORT', '3306');
    $name = envValue('DB_NAME');
    $user = envValue('DB_USER');
    $pass = envValue('DB_PASS', '');
    if ($name === null || $user === null) {
        respond(['ok' => false, 'error' => 'Database is not configured. Set DB_NAME and DB_USER on the server.'], 503);
    }
    $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
    try {
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (PDOException $exception) {
        respond(['ok' => false, 'error' => 'Database connection failed.'], 503);
    }
    return $pdo;
}

function requestHeader(string $name): ?string
{
    $serverKey = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
    $value = $_SERVER[$serverKey] ?? null;
    return is_string($value) && $value !== '' ? $value : null;
}

function authenticatedAccountId(): ?int
{
    $authShared = __DIR__ . '/AuthShared.php';
    if (is_file($authShared)) {
        require_once $authShared;
        foreach (['getAuthenticatedUserId', 'FSG_GetAuthenticatedUserId'] as $function) {
            if (function_exists($function)) {
                try {
                    $value = $function();
                    if (is_int($value) || ctype_digit((string)$value)) {
                        return (int)$value;
                    }
                } catch (Throwable $exception) {
                    return null;
                }
            }
        }
    }
    $header = requestHeader('X-Account-Id');
    return $header !== null && ctype_digit($header) ? (int)$header : null;
}

function clientTokenHash(): string
{
    $token = requestHeader('X-Auth-Token') ?? ($_COOKIE['AUTH_TOKEN'] ?? '');
    if ($token !== '') {
        return hash('sha256', $token);
    }
    $address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $agent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    return hash('sha256', $address . '|' . $agent);
}

function normalizeSessionId(mixed $value): ?string
{
    if (!is_string($value)) {
        return null;
    }
    $value = trim($value);
    if ($value === '') {
        return null;
    }
    return preg_match('/^[A-Za-z0-9._:-]{1,128}$/', $value) === 1 ? $value : null;
}

function accessScope(array $input): array
{
    return [
        'accountId' => authenticatedAccountId(),
        'serverSessionId' => normalizeSessionId($input['serverSessionId'] ?? null),
        'clientHash' => clientTokenHash(),
    ];
}

function whereScope(array $scope, array &$params): string
{
    if ($scope['accountId'] !== null) {
        $params[':account_id'] = $scope['accountId'];
        return 'account_id = :account_id';
    }
    if ($scope['serverSessionId'] !== null) {
        $params[':server_session_id'] = $scope['serverSessionId'];
        return 'server_session_id = :server_session_id';
    }
    $params[':client_hash'] = $scope['clientHash'];
    return 'client_hash = :client_hash';
}

function validateProject(array $project): array
{
    $projectId = trim((string)($project['projectId'] ?? ''));
    $title = trim((string)($project['title'] ?? ''));
    $schemaVersion = trim((string)($project['schemaVersion'] ?? '1.0.0'));
    if ($projectId === '' || strlen($projectId) > 128) {
        respond(['ok' => false, 'error' => 'Project ID is required and must be 128 characters or fewer.'], 422);
    }
    if ($title === '' || mb_strlen($title) > 120) {
        respond(['ok' => false, 'error' => 'Project title is required and must be 120 characters or fewer.'], 422);
    }
    foreach (['profiles', 'priorities', 'goals', 'actions', 'blackboard'] as $collection) {
        if (!isset($project[$collection]) || !is_array($project[$collection])) {
            respond(['ok' => false, 'error' => "Project collection {$collection} must be an array."], 422);
        }
    }
    return [$projectId, $title, $schemaVersion];
}

function saveProject(PDO $pdo, array $input): void
{
    $project = $input['project'] ?? null;
    if (!is_array($project)) {
        respond(['ok' => false, 'error' => 'A project object is required.'], 422);
    }
    [$projectId, $title, $schemaVersion] = validateProject($project);
    $scope = accessScope($input);
    $project['updatedAt'] = gmdate('c');
    $json = json_encode($project, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false || strlen($json) > MAX_PROJECT_BYTES) {
        respond(['ok' => false, 'error' => 'Serialized project exceeds the 8 MB limit.'], 413);
    }

    try {
        $pdo->beginTransaction();
        $ownerStatement = $pdo->prepare('SELECT account_id, server_session_id, client_hash FROM FSG_UngodlyAI_Projects WHERE project_id = :project_id FOR UPDATE');
        $ownerStatement->execute([':project_id' => $projectId]);
        $existingOwner = $ownerStatement->fetch();

        if ($existingOwner) {
            $ownedByCaller = false;
            if ($scope['accountId'] !== null) {
                $ownedByCaller = (int)$existingOwner['account_id'] === $scope['accountId'];
            } elseif ($scope['serverSessionId'] !== null) {
                $ownedByCaller = hash_equals((string)$existingOwner['server_session_id'], $scope['serverSessionId']);
            } else {
                $ownedByCaller = hash_equals((string)$existingOwner['client_hash'], $scope['clientHash']);
            }
            if (!$ownedByCaller) {
                $pdo->rollBack();
                respond(['ok' => false, 'error' => 'This project ID belongs to a different account or session.'], 403);
            }

            $statement = $pdo->prepare(<<<SQL
UPDATE FSG_UngodlyAI_Projects SET
account_id = :account_id,
server_session_id = :server_session_id,
client_hash = :client_hash,
title = :title,
schema_version = :schema_version,
project_json = :project_json,
updated_at = UTC_TIMESTAMP()
WHERE project_id = :project_id
SQL);
        } else {
            $statement = $pdo->prepare(<<<SQL
INSERT INTO FSG_UngodlyAI_Projects
(project_id, account_id, server_session_id, client_hash, title, schema_version, project_json, created_at, updated_at)
VALUES
(:project_id, :account_id, :server_session_id, :client_hash, :title, :schema_version, :project_json, UTC_TIMESTAMP(), UTC_TIMESTAMP())
SQL);
        }

        $statement->execute([
            ':project_id' => $projectId,
            ':account_id' => $scope['accountId'],
            ':server_session_id' => $scope['serverSessionId'],
            ':client_hash' => $scope['clientHash'],
            ':title' => $title,
            ':schema_version' => $schemaVersion,
            ':project_json' => $json,
        ]);

        $revisionStatement = $pdo->prepare(<<<SQL
INSERT INTO FSG_UngodlyAI_ProjectRevisions
(project_id, revision_number, project_json, created_by_account_id, created_at)
SELECT :project_id, COALESCE(MAX(revision_number), 0) + 1, :project_json, :account_id, UTC_TIMESTAMP()
FROM FSG_UngodlyAI_ProjectRevisions
WHERE project_id = :project_id_for_revision
SQL);
        $revisionStatement->execute([
            ':project_id' => $projectId,
            ':project_json' => $json,
            ':account_id' => $scope['accountId'],
            ':project_id_for_revision' => $projectId,
        ]);

        $pdo->commit();
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        respond(['ok' => false, 'error' => 'The project could not be saved.'], 500);
    }

    respond(['ok' => true, 'project' => ['projectId' => $projectId, 'updatedAt' => $project['updatedAt']]]);
}

function loadProject(PDO $pdo, array $input): void
{
    $projectId = trim((string)($input['projectId'] ?? ''));
    if ($projectId === '') {
        respond(['ok' => false, 'error' => 'Project ID is required.'], 422);
    }
    $scope = accessScope($input);
    $params = [':project_id' => $projectId];
    $where = whereScope($scope, $params);
    $statement = $pdo->prepare("SELECT project_json FROM FSG_UngodlyAI_Projects WHERE project_id = :project_id AND {$where} LIMIT 1");
    $statement->execute($params);
    $row = $statement->fetch();
    if (!$row) {
        respond(['ok' => false, 'error' => 'Project was not found for this account or session.'], 404);
    }
    $project = json_decode((string)$row['project_json'], true);
    if (!is_array($project)) {
        respond(['ok' => false, 'error' => 'Stored project JSON is invalid.'], 500);
    }
    respond(['ok' => true, 'project' => $project]);
}

function listProjects(PDO $pdo, array $input): void
{
    $scope = accessScope($input);
    $params = [];
    $where = whereScope($scope, $params);
    $statement = $pdo->prepare("SELECT project_id AS projectId, title, schema_version AS schemaVersion, DATE_FORMAT(updated_at, '%Y-%m-%dT%H:%i:%sZ') AS updatedAt FROM FSG_UngodlyAI_Projects WHERE {$where} ORDER BY updated_at DESC LIMIT 100");
    $statement->execute($params);
    respond(['ok' => true, 'projects' => $statement->fetchAll()]);
}

function deleteProject(PDO $pdo, array $input): void
{
    $projectId = trim((string)($input['projectId'] ?? ''));
    if ($projectId === '') {
        respond(['ok' => false, 'error' => 'Project ID is required.'], 422);
    }
    $scope = accessScope($input);
    $params = [':project_id' => $projectId];
    $where = whereScope($scope, $params);
    $statement = $pdo->prepare("DELETE FROM FSG_UngodlyAI_Projects WHERE project_id = :project_id AND {$where}");
    $statement->execute($params);
    respond(['ok' => true, 'deleted' => $statement->rowCount() > 0]);
}

$input = readInput();
$action = (string)($input['action'] ?? '');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(['ok' => true, 'service' => 'Ungodly AI Designer API', 'schemaVersion' => '1.0.0']);
}

$pdo = database();
match ($action) {
    'saveProject' => saveProject($pdo, $input),
    'loadProject' => loadProject($pdo, $input),
    'listProjects' => listProjects($pdo, $input),
    'deleteProject' => deleteProject($pdo, $input),
    default => respond(['ok' => false, 'error' => 'Unknown API action.'], 400),
};
