CREATE TABLE IF NOT EXISTS FSG_UngodlyAI_Projects (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    project_id VARCHAR(128) NOT NULL,
    account_id BIGINT UNSIGNED NULL,
    server_session_id VARCHAR(128) NULL,
    client_hash CHAR(64) NOT NULL,
    title VARCHAR(120) NOT NULL,
    schema_version VARCHAR(32) NOT NULL DEFAULT '1.0.0',
    project_json LONGTEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_UngodlyAI_Projects_project_id (project_id),
    KEY idx_FSG_UngodlyAI_Projects_account_updated (account_id, updated_at),
    KEY idx_FSG_UngodlyAI_Projects_session_updated (server_session_id, updated_at),
    KEY idx_FSG_UngodlyAI_Projects_client_updated (client_hash, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_UngodlyAI_ProjectRevisions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    project_id VARCHAR(128) NOT NULL,
    revision_number INT UNSIGNED NOT NULL,
    project_json LONGTEXT NOT NULL,
    created_by_account_id BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_UngodlyAI_ProjectRevisions_project_revision (project_id, revision_number),
    KEY idx_FSG_UngodlyAI_ProjectRevisions_project_created (project_id, created_at),
    CONSTRAINT fk_FSG_UngodlyAI_ProjectRevisions_project
        FOREIGN KEY (project_id) REFERENCES FSG_UngodlyAI_Projects(project_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_UngodlyAI_RuntimeSnapshots (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    project_id VARCHAR(128) NOT NULL,
    entity_instance_id VARCHAR(128) NOT NULL,
    profile_id VARCHAR(128) NOT NULL,
    entity_tier ENUM('god', 'creature', 'villager', 'village') NOT NULL,
    leash_context ENUM('off_leash', 'on_leash', 'either') NOT NULL DEFAULT 'either',
    blackboard_json LONGTEXT NOT NULL,
    current_goal_id VARCHAR(128) NULL,
    current_plan_json LONGTEXT NULL,
    utility_scores_json LONGTEXT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_UngodlyAI_RuntimeSnapshots_entity (project_id, entity_instance_id),
    KEY idx_FSG_UngodlyAI_RuntimeSnapshots_profile (project_id, profile_id),
    KEY idx_FSG_UngodlyAI_RuntimeSnapshots_tier (project_id, entity_tier),
    CONSTRAINT fk_FSG_UngodlyAI_RuntimeSnapshots_project
        FOREIGN KEY (project_id) REFERENCES FSG_UngodlyAI_Projects(project_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_UngodlyAI_DecisionLogs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    project_id VARCHAR(128) NOT NULL,
    entity_instance_id VARCHAR(128) NOT NULL,
    profile_id VARCHAR(128) NOT NULL,
    selected_goal_id VARCHAR(128) NULL,
    selected_utility DECIMAL(8,6) NULL,
    leash_context ENUM('off_leash', 'on_leash', 'either') NOT NULL DEFAULT 'either',
    utility_scores_json LONGTEXT NOT NULL,
    plan_json LONGTEXT NULL,
    outcome ENUM('selected', 'planned', 'completed', 'failed', 'replanned', 'cancelled') NOT NULL DEFAULT 'selected',
    failure_reason VARCHAR(500) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_FSG_UngodlyAI_DecisionLogs_project_time (project_id, created_at),
    KEY idx_FSG_UngodlyAI_DecisionLogs_entity_time (entity_instance_id, created_at),
    KEY idx_FSG_UngodlyAI_DecisionLogs_goal_time (selected_goal_id, created_at),
    CONSTRAINT fk_FSG_UngodlyAI_DecisionLogs_project
        FOREIGN KEY (project_id) REFERENCES FSG_UngodlyAI_Projects(project_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
