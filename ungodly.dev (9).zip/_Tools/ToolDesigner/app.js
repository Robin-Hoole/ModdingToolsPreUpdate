(() => {
  'use strict';

  const VERSION = 'ToolDesigner.2.1.0';
  const STORAGE_KEY = 'ToolDesignerWorkspaceV2';
  const TOKEN_KEY = 'ToolDesignerAuthToken';
  const SHARED_TOKEN_KEYS = [TOKEN_KEY, 'AuthShared_12h_token', 'DD_sharedAuthBearerToken'];

  const DEFAULT_THEME = {
    bg: '#07060a', bgDeep: '#020204', surface: '#0d0b11', panel: '#121018', panel2: '#191621', panel3: '#211c2a',
    border: '#352b3e', borderBright: '#5c4167', primary: '#ff2f92', primaryDim: '#c51669', accent: '#00e8ff',
    purple: '#a855f7', green: '#39e58c', yellow: '#f6c453', orange: '#ff8b57', red: '#ff4c6a', blue: '#428dff',
    text: '#f5eef7', muted: '#a99caf', muted2: '#75697b'
  };

  const FIELD_TYPES = ['text', 'textarea', 'number', 'checkbox', 'color', 'select', 'id', 'url', 'image', 'json', 'list'];
  const CONDITION_OPERATORS = ['==', '!=', '>', '>=', '<', '<=', 'exists', 'missing', 'contains', 'notContains'];
  const TRIGGER_OPERATORS = ['set', 'add', 'subtract', 'consume', 'clamp', 'enable', 'disable', 'spawn', 'despawn', 'teleport', 'awardXp', 'runSequence', 'complete'];

  function uid(prefix = '') {
    const value = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
    return prefix ? `${prefix}_${value}` : value;
  }

  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function $(selector, root = document) { return root.querySelector(selector); }
  function $$(selector, root = document) { return Array.from(root.querySelectorAll(selector)); }
  function esc(value) { return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function escAttr(value) { return esc(value).replace(/'/g, '&#39;'); }
  function safeName(value, fallback = 'Tool') { return String(value || fallback).replace(/[^A-Za-z0-9_.-]+/g, '_').replace(/_+/g, '_').replace(/^_+|_+$/g, '') || fallback; }
  function nowReadable() { return new Date().toLocaleString(); }
  function truthy(value) { return value === true || value === 'true' || value === 1 || value === '1'; }
  function openModal(id) { const el = $('#' + id); if (el) el.classList.add('open'); }
  function closeModal(id) { const el = $('#' + id); if (el) el.classList.remove('open'); }
  function copyText(text) { return navigator.clipboard?.writeText(String(text ?? '')).catch(() => {}); }
  function storageGet(key) { try { return localStorage.getItem(key) || ''; } catch (_) { return ''; } }
  function storageSet(key, value) { try { localStorage.setItem(key, value); } catch (_) {} }
  function storageRemove(key) { try { localStorage.removeItem(key); } catch (_) {} }
  function getStoredAuthToken() { for (const key of SHARED_TOKEN_KEYS) { const value = storageGet(key); if (value) return value; } return ''; }
  function storeAuthToken(token) { SHARED_TOKEN_KEYS.forEach(key => storageSet(key, token)); }
  function clearAuthToken() { SHARED_TOKEN_KEYS.forEach(storageRemove); }

  const BUILTIN_TYPES = [
    {
      typeKey: 'DialogueStatement', displayName: 'Dialogue Statement', category: 'Dialogue', color: '#39e58c',
      tooltip: 'A complete Dialogue Designer statement with speaker, localized text, flags, responses, conditions and triggers.',
      description: 'The primary narrative node used to author a speaker line and route into response components.',
      hasConditions: true, hasTriggers: true,
      fields: [
        { key: 'statementId', label: 'Statement ID', type: 'id', default: '' },
        { key: 'speaker', label: 'Speaker', type: 'text', default: 'Narration' },
        { key: 'language', label: 'Language', type: 'select', options: ['ENG', 'SPA', 'FRA', 'DEU'], default: 'ENG' },
        { key: 'text', label: 'Statement Text', type: 'textarea', default: '' },
        { key: 'voiceLine', label: 'Voice Line', type: 'checkbox', default: false },
        { key: 'voiceAsset', label: 'Voice Asset', type: 'image', default: '' },
        { key: 'responseIds', label: 'Response IDs', type: 'list', default: [] },
        { key: 'nextStatementId', label: 'Default Next ID', type: 'id', default: '' }
      ]
    },
    {
      typeKey: 'Response', displayName: 'Response', category: 'Dialogue', color: '#428dff',
      tooltip: 'A player or NPC response with its own conditional visibility and trigger mutations.',
      description: 'Response card compatible with statement routing and localized text.', hasConditions: true, hasTriggers: true,
      fields: [
        { key: 'responseId', label: 'Response ID', type: 'id', default: '' },
        { key: 'language', label: 'Language', type: 'select', options: ['ENG', 'SPA', 'FRA', 'DEU'], default: 'ENG' },
        { key: 'text', label: 'Response Text', type: 'textarea', default: '' },
        { key: 'nextStatementId', label: 'Next Statement ID', type: 'id', default: '' },
        { key: 'voiceLine', label: 'Voice Line', type: 'checkbox', default: false },
        { key: 'allowRepeating', label: 'Allow Repeating', type: 'checkbox', default: false }
      ]
    },
    {
      typeKey: 'CastMember', displayName: 'Cast Member', category: 'Dialogue', color: '#e51fde',
      tooltip: 'A reusable speaker definition with display color, identity, image roots and metadata.',
      description: 'Can populate speaker dropdowns throughout a generated tool.', hasConditions: false, hasTriggers: false,
      fields: [
        { key: 'castId', label: 'Cast ID', type: 'id', default: '' },
        { key: 'name', label: 'Display Name', type: 'text', default: '' },
        { key: 'speakerColor', label: 'Speaker Color', type: 'color', default: '#e51fde' },
        { key: 'imageRoot', label: 'Image Root', type: 'image', default: '' },
        { key: 'description', label: 'Biography / Notes', type: 'textarea', default: '' }
      ]
    },
    {
      typeKey: 'GlobalToken', displayName: 'Global Token', category: 'Globals', color: '#00e8ff', tooltip: 'A reusable {{token}} key and localized value.',
      description: 'Global replacement value available to authored tools.', hasConditions: false, hasTriggers: false,
      fields: [{ key: 'key', label: 'Token Key', type: 'text', default: '' }, { key: 'value', label: 'Value', type: 'text', default: '' }, { key: 'language', label: 'Language', type: 'select', options: ['ENG', 'SPA', 'FRA', 'DEU'], default: 'ENG' }]
    },
    {
      typeKey: 'GlobalState', displayName: 'Global State', category: 'Globals', color: '#f6c453', tooltip: 'A globally available state definition.', description: 'Boolean, numeric, enum or text state.', hasConditions: false, hasTriggers: false,
      fields: [{ key: 'stateId', label: 'State ID', type: 'id', default: '' }, { key: 'valueType', label: 'Value Type', type: 'select', options: ['boolean', 'number', 'text', 'enum'], default: 'boolean' }, { key: 'defaultValue', label: 'Default Value', type: 'text', default: 'false' }, { key: 'allowedValues', label: 'Allowed Values', type: 'list', default: [] }]
    },
    {
      typeKey: 'ImageSequence', displayName: 'Image Sequence', category: 'Media', color: '#a855f7', tooltip: 'An ordered image list rooted beneath the configured Images folder.', description: 'Reusable image sequence definition.', hasConditions: true, hasTriggers: true,
      fields: [{ key: 'sequenceId', label: 'Sequence ID', type: 'id', default: '' }, { key: 'root', label: 'Image Root', type: 'image', default: 'Characters/' }, { key: 'frames', label: 'Frames', type: 'list', default: [] }, { key: 'loop', label: 'Loop', type: 'checkbox', default: true }, { key: 'frameDurationMs', label: 'Frame Duration', type: 'number', default: 120 }]
    },
    {
      typeKey: 'TaskDefinition', displayName: 'Task / Quest', category: 'Progression', color: '#ff8b57', tooltip: 'Task Manager-compatible quest or task definition.', description: 'Includes identifiers, localized text, manager data, objectives and progression triggers.', hasConditions: true, hasTriggers: true,
      fields: [{ key: 'taskId', label: 'Task ID', type: 'id', default: '' }, { key: 'title', label: 'Task Title', type: 'text', default: '' }, { key: 'description', label: 'Task Description', type: 'textarea', default: '' }, { key: 'managerName', label: 'Manager Name', type: 'text', default: '' }, { key: 'objectiveIds', label: 'Objective IDs', type: 'list', default: [] }, { key: 'repeatable', label: 'Repeatable', type: 'checkbox', default: false }]
    },
    {
      typeKey: 'Objective', displayName: 'Objective', category: 'Progression', color: '#f6c453', tooltip: 'A reusable objective record with target and required quantity.', description: 'Can be nested beneath a Task component.', hasConditions: true, hasTriggers: true,
      fields: [{ key: 'objectiveId', label: 'Objective ID', type: 'id', default: '' }, { key: 'objectiveType', label: 'Objective Type', type: 'select', options: ['kill', 'collect', 'visit', 'talk', 'interact', 'custom'], default: 'custom' }, { key: 'targetId', label: 'Target ID', type: 'id', default: '' }, { key: 'requiredAmount', label: 'Required Amount', type: 'number', default: 1 }, { key: 'description', label: 'Description', type: 'textarea', default: '' }]
    },
    {
      typeKey: 'PromptBlueprint', displayName: 'Prompt Blueprint', category: 'AI', color: '#ff2f92', tooltip: 'Prompt Designer-compatible prompt body, tag and routing metadata.', description: 'Reusable prompt or AI blueprint.', hasConditions: true, hasTriggers: true,
      fields: [{ key: 'promptId', label: 'Prompt ID', type: 'id', default: '' }, { key: 'tag', label: 'Tag', type: 'text', default: '' }, { key: 'systemText', label: 'System Text', type: 'textarea', default: '' }, { key: 'promptText', label: 'Prompt Text', type: 'textarea', default: '' }, { key: 'allowRepeating', label: 'Allow Repeating', type: 'checkbox', default: false }]
    },
    {
      typeKey: 'MenuOption', displayName: 'Menu Option', category: 'UI', color: '#39e58c', tooltip: 'A Menu Designer option with text, icon, destination and external link support.', description: 'Reusable menu item or context action.', hasConditions: true, hasTriggers: true,
      fields: [{ key: 'optionId', label: 'Option ID', type: 'id', default: '' }, { key: 'buttonText', label: 'Button Text', type: 'text', default: '' }, { key: 'icon', label: 'Icon Path', type: 'image', default: '' }, { key: 'destination', label: 'Destination', type: 'text', default: '' }, { key: 'externalUrl', label: 'External URL', type: 'url', default: '' }]
    },
    {
      typeKey: 'SequenceSettings', displayName: 'Sequence Settings', category: 'Engine', color: '#00e8ff', tooltip: 'Sequence-level defaults, entry point and validation controls.', description: 'A settings component for a complete tool or sequence.', hasConditions: false, hasTriggers: false,
      fields: [{ key: 'sequenceId', label: 'Sequence ID', type: 'id', default: '' }, { key: 'entryComponentId', label: 'Entry Component ID', type: 'id', default: '' }, { key: 'language', label: 'Default Language', type: 'select', options: ['ENG', 'SPA', 'FRA', 'DEU'], default: 'ENG' }, { key: 'validateConnections', label: 'Validate Connections', type: 'checkbox', default: true }]
    },
    {
      typeKey: 'Connection', displayName: 'Connection', category: 'Logic', color: '#9d77ff', tooltip: 'A typed connection between component IDs.', description: 'Supports next, success, failure and alternate branches.', hasConditions: true, hasTriggers: false,
      fields: [{ key: 'sourceId', label: 'Source Component ID', type: 'id', default: '' }, { key: 'connectionType', label: 'Connection Type', type: 'select', options: ['next', 'success', 'failure', 'alternate', 'incoming'], default: 'next' }, { key: 'targetId', label: 'Target Component ID', type: 'id', default: '' }]
    },
    {
      typeKey: 'SessionCard', displayName: 'Server Session Card', category: 'Engine', color: '#00e8ff', tooltip: 'The shared suite session surface containing two fields and four operations.', description: 'Reusable session UI definition for suite applications.', hasConditions: false, hasTriggers: true,
      fields: [{ key: 'sessionLengthHours', label: 'Session Length Hours', type: 'number', default: 12 }, { key: 'allowGuestJson', label: 'Allow Guest JSON', type: 'checkbox', default: true }, { key: 'allowGuestDatabase', label: 'Allow Guest Database', type: 'checkbox', default: false }, { key: 'passwordOptional', label: 'Password Optional', type: 'checkbox', default: true }]
    },
    {
      typeKey: 'GenericPanel', displayName: 'Generic Panel', category: 'Foundation', color: '#c984ff', tooltip: 'A flexible base component with metadata and arbitrary JSON fields.', description: 'Use this as the starting point for a new panel family.', hasConditions: true, hasTriggers: true,
      fields: [{ key: 'label', label: 'Label', type: 'text', default: '' }, { key: 'body', label: 'Body', type: 'textarea', default: '' }, { key: 'settings', label: 'Settings JSON', type: 'json', default: {} }]
    }
  ];

  const state = {
    user: null,
    authToken: getStoredAuthToken(),
    authMode: 'login',
    needsPasswordReset: false,
    sessionId: '',
    sessionPassword: '',
    prefixes: { project: 'Ungodly', tool: 'ToolMenuEmpty', instance: 'FSG' },
    theme: clone(DEFAULT_THEME),
    jsonRootPath: 'Json/Defaults',
    imagesRootPath: 'Images',
    dbHostDisplay: 'localhost',
    profileName: 'ToolDesigner Default',
    topBarButtons: [
      { id: uid('button'), buttonText: 'DIALOGUE DESIGNER', linkType: 'url', url: '#DialogueDesigner', imagePath: '', tooltip: 'Open the Dialogue Designer context', description: 'Conversation and statement authoring tool.', visible: true, sortOrder: 0 },
      { id: uid('button'), buttonText: 'TASK MANAGER', linkType: 'url', url: '#TaskManager', imagePath: '', tooltip: 'Open the Task Manager context', description: 'Quest and objective authoring tool.', visible: true, sortOrder: 1 },
      { id: uid('button'), buttonText: 'PROMPT DESIGNER', linkType: 'url', url: '#PromptDesigner', imagePath: '', tooltip: 'Open the Prompt Designer context', description: 'Prompt and AI blueprint authoring tool.', visible: true, sortOrder: 2 },
      { id: uid('button'), buttonText: 'MENU DESIGNER', linkType: 'url', url: '#MenuDesigner', imagePath: '', tooltip: 'Open the Menu Designer context', description: 'Menu and interface navigation authoring tool.', visible: true, sortOrder: 3 }
    ],
    panelTypes: clone(BUILTIN_TYPES),
    globalTokens: [
      { id: uid('token'), key: 'playerName', value: 'Rookie' },
      { id: uid('token'), key: 'currentLanguage', value: 'ENG' },
      { id: uid('token'), key: 'projectName', value: 'Ungodly' }
    ],
    tools: [],
    savedComponents: [],
    activeToolId: null,
    selectedComponentId: null,
    editingComponentTypeKey: null,
    editingPanelId: null,
    leftCollapsed: false,
    rightCollapsed: false,
    leftWidth: 302,
    rightWidth: 316,
    history: [],
    historyIndex: -1,
    namedSnapshots: [],
    validationReport: [],
    uiInspectMode: false,
    developerMode: false,
    consoleExpanded: false,
    messages: [],
    sidebarMeta: {
      left: { label: 'Component Library', tooltip: 'Server session, globals and reusable component definitions.', notes: '' },
      right: { label: 'Tools & Inspector', tooltip: 'Tool tabs, SQL, account and selected component details.', notes: '' }
    },
    sqlSource: ''
  };

  function definition(typeKey) { return state.panelTypes.find(type => type.typeKey === typeKey) || state.panelTypes.find(type => type.typeKey === 'GenericPanel'); }
  function activeTool() { return state.tools.find(tool => tool.id === state.activeToolId) || null; }
  function selectedComponent() { const tool = activeTool(); return tool?.components.find(component => component.id === state.selectedComponentId) || null; }
  function isAuthenticated() { return !!(state.user && state.authToken); }
  function isAdmin() { return !!(state.user && state.user.isAdmin); }
  function prefixStem() { return [state.prefixes.project, state.prefixes.tool, state.prefixes.instance].map(value => String(value || '').replace(/[^A-Za-z0-9_]/g, '')).filter(Boolean).join('_') + '_'; }

  function defaultPayload(type) {
    const payload = {};
    (type.fields || []).forEach(field => {
      if (field.type === 'id') payload[field.key] = field.default || uid(field.key.replace(/Id$/i, '').toLowerCase() || 'id');
      else payload[field.key] = clone(field.default ?? (field.type === 'checkbox' ? false : field.type === 'number' ? 0 : field.type === 'list' ? [] : field.type === 'json' ? {} : ''));
    });
    return payload;
  }

  function makeComponent(typeKey, overrides = {}) {
    const type = definition(typeKey);
    const component = {
      id: uid('component'),
      typeKey: type.typeKey,
      title: overrides.title || type.displayName,
      identityColor: overrides.identityColor || type.color,
      tooltip: overrides.tooltip ?? type.tooltip ?? '',
      description: overrides.description ?? type.description ?? '',
      source: overrides.source || `ToolDesigner.definition.${type.typeKey}`,
      externalId: overrides.externalId || '',
      calledExternally: !!overrides.calledExternally,
      makesExternalCall: !!overrides.makesExternalCall,
      conditionsCollapsed: !!overrides.conditionsCollapsed,
      triggersCollapsed: !!overrides.triggersCollapsed,
      conditionsTooltip: overrides.conditionsTooltip || 'All conditions must pass before this component can run.',
      triggersTooltip: overrides.triggersTooltip || 'Authorized mutations applied when this component runs.',
      glowCondition: overrides.glowCondition !== false,
      glowTrigger: overrides.glowTrigger !== false,
      conditions: clone(overrides.conditions || []),
      triggers: clone(overrides.triggers || []),
      payload: Object.assign(defaultPayload(type), clone(overrides.payload || {})),
      unknownFields: clone(overrides.unknownFields || {}),
      createdAtMs: overrides.createdAtMs || Date.now(),
      createdAt: overrides.createdAt || nowReadable(),
      updatedAtMs: Date.now(),
      updatedAt: nowReadable()
    };
    Object.keys(overrides).forEach(key => {
      if (!(key in component) && key !== 'payload') component.unknownFields[key] = clone(overrides[key]);
    });
    return component;
  }

  function makeTool(title, options = {}) {
    return {
      id: options.id || uid('tool'),
      title: title || 'Untitled Tool',
      exportTitle: options.exportTitle || title || 'Untitled_Tool',
      color: options.color || state.theme.primary,
      description: options.description || '',
      components: clone(options.components || []),
      settings: Object.assign({ language: 'ENG', browserExport: true, unityExport: true, serverPush: false }, clone(options.settings || {})),
      createdAtMs: options.createdAtMs || Date.now(),
      createdAt: options.createdAt || nowReadable(),
      updatedAtMs: Date.now(),
      updatedAt: nowReadable(),
      unknownFields: clone(options.unknownFields || {})
    };
  }

  function touchComponent(component) { component.updatedAtMs = Date.now(); component.updatedAt = nowReadable(); autoSave(); }
  function touchTool(tool) { tool.updatedAtMs = Date.now(); tool.updatedAt = nowReadable(); autoSave(); }

  function seedWorkspace() {
    const dialogue = makeTool('Dialogue Designer Blueprint', {
      exportTitle: 'DialogueDesigner_Blueprint', color: '#39e58c', description: 'A self-tutorial example showing how ToolDesigner can reconstruct Dialogue Designer.',
      components: [
        makeComponent('SequenceSettings', { title: 'Conversation Sequence Settings', identityColor: '#00e8ff', payload: { language: 'ENG', validateConnections: true } }),
        makeComponent('CastMember', { title: 'Narration', payload: { name: 'Narration', speakerColor: '#8888aa', description: 'Neutral narrative voice.' } }),
        makeComponent('CastMember', { title: 'Sam', payload: { name: 'Sam', speakerColor: '#e51fde', description: 'Security staff member in the tutorial scene.' } }),
        makeComponent('DialogueStatement', {
          title: 'Sam greets the player', calledExternally: true, glowCondition: true, glowTrigger: true,
          conditions: [{ id: uid('condition'), path: 'game.metSam', operator: '==', value: false, tooltip: 'Only show before Sam has been met.' }],
          triggers: [{ id: uid('trigger'), path: 'game.metSam', operation: 'set', value: true, tooltip: 'Marks the introduction complete.' }],
          payload: { speaker: 'Sam', language: 'ENG', text: 'Hey, {{playerName}}. You ready for Blacksite duty?', voiceLine: true, responseIds: [], nextStatementId: '' }
        }),
        makeComponent('Response', { title: 'Ready Response', payload: { language: 'ENG', text: 'Born ready.', allowRepeating: false } }),
        makeComponent('Response', { title: 'Nervous Response', conditions: [{ id: uid('condition'), path: 'player.confidence', operator: '<', value: 3, tooltip: 'Only appears for low confidence.' }], payload: { language: 'ENG', text: 'I… think so.', allowRepeating: false } }),
        makeComponent('ImageSequence', { title: 'Sam Intro Frames', payload: { root: 'Characters/Sam/', frames: ['idle.png', 'wave.png', 'talk.png'], loop: true, frameDurationMs: 120 } })
      ]
    });
    const task = makeTool('Task Manager Blueprint', {
      exportTitle: 'TaskManager_Blueprint', color: '#ff8b57', description: 'Task, objective and state mutation example.',
      components: [
        makeComponent('TaskDefinition', { title: 'Job Application', conditions: [{ id: uid('condition'), path: 'player.facilityAccess', operator: '==', value: true, tooltip: '' }], triggers: [{ id: uid('trigger'), path: 'quests.jobApplication.status', operation: 'set', value: 'active', tooltip: '' }], payload: { title: 'Job Application', description: 'Submit credentials to the HR terminal.', managerName: 'Human Resources', objectiveIds: [], repeatable: false } }),
        makeComponent('Objective', { title: 'Submit Credentials', payload: { objectiveType: 'interact', targetId: 'hr_terminal', requiredAmount: 1, description: 'Use the HR terminal.' } }),
        makeComponent('Objective', { title: 'Collect Badge', conditions: [{ id: uid('condition'), path: 'quests.jobApplication.objectives.submitCredentials', operator: '==', value: 'complete', tooltip: '' }], payload: { objectiveType: 'collect', targetId: 'employee_badge', requiredAmount: 1, description: 'Collect the employee badge.' } })
      ]
    });
    const prompt = makeTool('Prompt Designer Blueprint', {
      exportTitle: 'PromptDesigner_Blueprint', color: '#ff2f92', description: 'Prompt authoring and conditional execution example.',
      components: [
        makeComponent('PromptBlueprint', { title: 'Containment Breach Alert', calledExternally: true, conditions: [{ id: uid('condition'), path: 'facility.alertLevel', operator: '>=', value: 3, tooltip: '' }], triggers: [{ id: uid('trigger'), path: 'audio.paOverride', operation: 'enable', value: true, tooltip: '' }], payload: { tag: 'NEWS_ALERT', systemText: 'Generate a concise emergency alert.', promptText: 'Containment breach in sector {{sector}}.', allowRepeating: false } }),
        makeComponent('GlobalToken', { title: 'Sector Token', payload: { key: 'sector', value: 'B-14', language: 'ENG' } })
      ]
    });
    const sandbox = makeTool('Component Sandbox', {
      exportTitle: 'ToolDesigner_ComponentSandbox', color: '#a855f7', description: 'Experiment here without changing the tutorial blueprints.',
      components: [makeComponent('GenericPanel', { title: 'Start Here', tooltip: 'Open the gear to edit metadata. Open {} to edit the lossless JSON instance.', payload: { label: 'Reusable Panel', body: 'This component can become a saved definition.', settings: { tutorial: true } } })]
    });
    state.tools = [dialogue, task, prompt, sandbox];
    state.activeToolId = dialogue.id;
  }

  function loadLocal() {
    try {
      const saved = JSON.parse(storageGet(STORAGE_KEY) || 'null');
      if (!saved || !String(saved.version || '').startsWith('ToolDesigner.2.')) return false;
      ['prefixes', 'theme', 'jsonRootPath', 'imagesRootPath', 'dbHostDisplay', 'profileName', 'topBarButtons', 'panelTypes', 'globalTokens', 'tools', 'savedComponents', 'activeToolId', 'selectedComponentId', 'leftCollapsed', 'rightCollapsed', 'leftWidth', 'rightWidth', 'namedSnapshots', 'developerMode', 'sidebarMeta'].forEach(key => {
        if (saved[key] !== undefined) state[key] = clone(saved[key]);
      });
      return Array.isArray(state.tools) && state.tools.length > 0;
    } catch (_) { return false; }
  }

  let saveTimer = null;
  let historyTimer = null;
  let suppressHistory = false;

  function serializableWorkspaceState() {
    return {
      version: VERSION, prefixes: clone(state.prefixes), theme: clone(state.theme), jsonRootPath: state.jsonRootPath, imagesRootPath: state.imagesRootPath,
      dbHostDisplay: state.dbHostDisplay, profileName: state.profileName, topBarButtons: clone(state.topBarButtons), panelTypes: clone(state.panelTypes),
      globalTokens: clone(state.globalTokens), tools: clone(state.tools), savedComponents: clone(state.savedComponents), activeToolId: state.activeToolId,
      selectedComponentId: state.selectedComponentId, leftCollapsed: state.leftCollapsed, rightCollapsed: state.rightCollapsed,
      leftWidth: state.leftWidth, rightWidth: state.rightWidth, developerMode: state.developerMode, sidebarMeta: clone(state.sidebarMeta)
    };
  }

  function persistLocal() {
    const payload = Object.assign(serializableWorkspaceState(), { namedSnapshots: clone(state.namedSnapshots.slice(-20)) });
    storageSet(STORAGE_KEY, JSON.stringify(payload));
  }

  function captureHistory(label = 'Authored change', named = false) {
    if (suppressHistory) return;
    const data = JSON.stringify(serializableWorkspaceState());
    const current = state.history[state.historyIndex];
    if (current && current.data === data) return;
    if (state.historyIndex < state.history.length - 1) state.history = state.history.slice(0, state.historyIndex + 1);
    const entry = { id: uid('history'), label, named, atMs: Date.now(), at: nowReadable(), data };
    state.history.push(entry);
    if (state.history.length > 45) state.history.shift();
    state.historyIndex = state.history.length - 1;
    updateHistoryButtons();
  }

  function autoSave(label = 'Authored change') {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(persistLocal, 120);
    if (!suppressHistory) {
      clearTimeout(historyTimer);
      historyTimer = setTimeout(() => captureHistory(label), 260);
    }
  }

  function restoreHistoryEntry(index) {
    const entry = state.history[index];
    if (!entry) return;
    suppressHistory = true;
    try {
      const saved = JSON.parse(entry.data);
      Object.keys(saved).forEach(key => { if (key !== 'version') state[key] = clone(saved[key]); });
      state.historyIndex = index;
      renderAll();
      persistLocal();
      log(`Restored history: ${entry.label}`);
    } finally { suppressHistory = false; updateHistoryButtons(); }
  }

  function undo() { if (state.historyIndex > 0) restoreHistoryEntry(state.historyIndex - 1); }
  function redo() { if (state.historyIndex < state.history.length - 1) restoreHistoryEntry(state.historyIndex + 1); }
  function updateHistoryButtons() {
    const undoButton = $('#btnUndo'); const redoButton = $('#btnRedo');
    if (undoButton) undoButton.disabled = state.historyIndex <= 0;
    if (redoButton) redoButton.disabled = state.historyIndex < 0 || state.historyIndex >= state.history.length - 1;
  }

  function applyTheme() {
    const map = {
      bg: '--td-bg', bgDeep: '--td-bg-deep', surface: '--td-surface', panel: '--td-panel', panel2: '--td-panel-2', panel3: '--td-panel-3',
      border: '--td-border', borderBright: '--td-border-bright', primary: '--td-primary', primaryDim: '--td-primary-dim', accent: '--td-accent',
      purple: '--td-purple', green: '--td-green', yellow: '--td-yellow', orange: '--td-orange', red: '--td-red', blue: '--td-blue',
      text: '--td-text', muted: '--td-muted', muted2: '--td-muted-2'
    };
    Object.entries(map).forEach(([key, css]) => document.documentElement.style.setProperty(css, state.theme[key] || DEFAULT_THEME[key]));
    document.documentElement.style.setProperty('--td-primary-soft', hexToRgba(state.theme.primary, .12));
    document.documentElement.style.setProperty('--td-primary-glow', hexToRgba(state.theme.primary, .42));
    document.documentElement.style.setProperty('--td-accent-soft', hexToRgba(state.theme.accent, .11));
  }

  function hexToRgba(hex, alpha) {
    const clean = String(hex || '#000000').replace('#', '');
    const normalized = clean.length === 3 ? clean.split('').map(c => c + c).join('') : clean.padEnd(6, '0').slice(0, 6);
    const num = parseInt(normalized, 16);
    return `rgba(${num >> 16},${(num >> 8) & 255},${num & 255},${alpha})`;
  }

  function log(message, who = state.user?.username || 'local') {
    state.messages.unshift({ id: uid('message'), timestamp: Date.now(), readable: nowReadable(), who, message: String(message) });
    state.messages = state.messages.slice(0, 200);
    renderConsole();
  }

  function renderConsole() {
    const last = $('#consoleLastMsg');
    const list = $('#consoleLog');
    if (!last || !list) return;
    const newest = state.messages[0];
    last.innerHTML = newest ? `<span class="ts">${esc(newest.readable)}</span><span class="who">${esc(newest.who)}</span><span class="body">${esc(newest.message)}</span>` : '<span class="body text-muted">No messages yet.</span>';
    list.innerHTML = state.messages.map(item => `<div class="console-log-row"><span class="ts">${esc(item.readable)}</span><span class="who">${esc(item.who)}</span><span>${esc(item.message)}</span></div>`).join('');
  }

  function renderAdminState() {
    $$('.developer-only').forEach(el => el.classList.toggle('hidden', !isAdmin()));
    $('#btnAdminLeft')?.classList.toggle('hidden', !isAdmin());
    $('#btnAdminRight')?.classList.toggle('hidden', !isAdmin());
    document.body.classList.toggle('developer-mode', state.developerMode && isAdmin());
    const badge = $('#accountBadge');
    if (badge) badge.textContent = isAdmin() ? 'ADMIN' : isAuthenticated() ? 'USER' : 'GUEST';
  }

  function renderAuthStatus() {
    const status = $('#authStatus');
    const hint = $('#sessionPermissionHint');
    if (!status) return;
    if (isAuthenticated()) {
      status.className = 'account-status online';
      status.textContent = `${state.user.username} — ${state.user.isAdmin ? 'administrator' : 'authenticated user'}`;
      $('#btnOpenAuth').textContent = 'ACCOUNT / LOGOUT';
      if (hint) hint.textContent = 'Authenticated sessions may be pushed to the database. Administrative definition editing remains permission-gated.';
    } else {
      status.className = 'account-status';
      status.textContent = 'Guest — JSON only';
      $('#btnOpenAuth').textContent = 'LOGIN / REGISTER';
      if (hint) hint.textContent = 'Guests can import and export JSON but cannot save server data.';
    }
    renderAdminState();
  }

  function renderTopNav() {
    const dropdown = $('#suiteDropdown');
    dropdown.innerHTML = '';
    state.topBarButtons.filter(button => button.visible !== false).sort((a, b) => Number(a.sortOrder) - Number(b.sortOrder)).forEach(button => {
      const action = document.createElement(button.linkType === 'url' ? 'a' : 'button');
      if (button.linkType === 'url') {
        action.href = button.url || '#';
        if (button.url && !button.url.startsWith('#')) action.target = '_blank';
      } else action.type = 'button';
      action.textContent = button.buttonText || 'UNTITLED BUTTON';
      action.title = button.tooltip || button.description || '';
      action.addEventListener('click', event => {
        if (button.linkType === 'image') {
          event.preventDefault();
          log(`Image button resolved to ${state.imagesRootPath}/${button.imagePath || ''}`, 'system');
          return;
        }
        if (!button.url || button.url === '#' || button.url.startsWith('#')) {
          event.preventDefault();
          const query = (button.url || button.buttonText).replace(/^#/, '').replace(/\s+/g, '').toLowerCase();
          const tool = state.tools.find(candidate => candidate.title.replace(/\s+/g, '').toLowerCase().includes(query.replace(/designer|manager|blueprint/g, '')));
          if (tool) selectTool(tool.id); else log(`No local tool matches ${button.buttonText}`, 'system');
        }
      });
      dropdown.appendChild(action);
    });
    const divider = document.createElement('hr'); divider.className = 'dd-sep'; dropdown.appendChild(divider);
    const settings = document.createElement('button'); settings.type = 'button'; settings.textContent = '⚙ Edit Suite Dropdown'; settings.addEventListener('click', () => { closeMenus(); openTopBarModal(); }); dropdown.appendChild(settings);
  }

  function renderTokens() {
    const list = $('#globalTokensList');
    list.innerHTML = '';
    state.globalTokens.forEach((token, index) => {
      const row = document.createElement('div'); row.className = 'token-row';
      row.innerHTML = `<input data-token-key value="${escAttr(token.key)}" data-tooltip="Displayed as {{${escAttr(token.key)}}}"><input data-token-value value="${escAttr(token.value)}"><button class="mini-icon" type="button">×</button>`;
      $('[data-token-key]', row).addEventListener('input', event => { token.key = event.target.value.replace(/[{}]/g, ''); autoSave(); });
      $('[data-token-value]', row).addEventListener('input', event => { token.value = event.target.value; autoSave(); });
      $('button', row).addEventListener('click', () => { state.globalTokens.splice(index, 1); renderTokens(); autoSave(); });
      list.appendChild(row);
    });
    $('#tokenCount').textContent = state.globalTokens.length;
  }

  function renderPanelTypes(filter = '') {
    const list = $('#panelTypeList');
    const query = String(filter || '').trim().toLowerCase();
    list.innerHTML = '';
    state.panelTypes.filter(type => !query || `${type.typeKey} ${type.displayName} ${type.category} ${type.description}`.toLowerCase().includes(query)).sort((a, b) => `${a.category}${a.displayName}`.localeCompare(`${b.category}${b.displayName}`)).forEach(type => {
      const row = document.createElement('div');
      row.className = 'panel-type-item'; row.draggable = true; row.style.setProperty('--type-color', type.color); row.dataset.typeKey = type.typeKey;
      row.setAttribute('data-tooltip', type.tooltip || type.description || 'Reusable component type');
      row.innerHTML = `<div class="panel-type-name">${esc(type.displayName)}</div><div class="panel-type-meta"><span>${esc(type.category)}</span><span>${(type.fields || []).length} fields</span></div>`;
      row.addEventListener('dblclick', () => addComponent(type.typeKey));
      row.addEventListener('dragstart', event => event.dataTransfer.setData('text/tool-designer-type', type.typeKey));
      row.addEventListener('contextmenu', event => { event.preventDefault(); if (isAdmin()) openComponentBuilder(type.typeKey); });
      list.appendChild(row);
    });
    $('#typeCount').textContent = state.panelTypes.length;
  }

  function renderToolTabs() {
    const tabs = $('#contextTabs'); tabs.innerHTML = '';
    state.tools.forEach(tool => {
      const tab = document.createElement('button'); tab.type = 'button'; tab.className = 'context-tab' + (tool.id === state.activeToolId ? ' active' : ''); tab.style.setProperty('--tab-color', tool.color);
      tab.innerHTML = `<span class="context-dot" style="background:${escAttr(tool.color)};color:${escAttr(tool.color)}"></span><span class="tab-name">${esc(tool.title)}</span><span class="tab-close">×</span>`;
      tab.addEventListener('click', event => { if (event.target.classList.contains('tab-close')) { removeTool(tool.id); return; } selectTool(tool.id); });
      tabs.appendChild(tab);
    });
  }

  function renderToolList() {
    const list = $('#contextList'); list.innerHTML = '';
    state.tools.forEach(tool => {
      const row = document.createElement('div'); row.className = 'context-list-row' + (tool.id === state.activeToolId ? ' active' : '');
      row.innerHTML = `<div class="context-list-head"><span class="context-dot" style="background:${escAttr(tool.color)};color:${escAttr(tool.color)}"></span><span class="context-list-name">${esc(tool.title)}</span><span class="count">${tool.components.length}</span><button class="mini-icon" type="button">×</button></div>`;
      row.addEventListener('click', event => { if (event.target.tagName !== 'BUTTON') selectTool(tool.id); });
      $('button', row).addEventListener('click', () => removeTool(tool.id));
      list.appendChild(row);
    });
    $('#contextCount').textContent = state.tools.length;
  }

  function renderCanvas() {
    const area = $('#canvasArea');
    area.querySelectorAll('.canvas-context-header, .panel-card').forEach(node => node.remove());
    const empty = $('#canvasEmpty');
    const tool = activeTool();
    empty.classList.toggle('hidden', !!tool);
    if (!tool) { renderInspector(); return; }

    const header = document.createElement('div'); header.className = 'canvas-context-header'; header.style.setProperty('--context-color', tool.color);
    header.innerHTML = `<div class="canvas-title-wrap"><div class="canvas-title-label">Tool Title — this becomes a suite context tab</div><input class="canvas-title" value="${escAttr(tool.title)}"></div><div class="canvas-meta"><input type="color" class="tool-color" value="${escAttr(tool.color)}" data-tooltip="Tool identity color"><span class="canvas-uuid">${esc(tool.id)}</span><div class="canvas-toolbar"><button class="btn btn-sm" data-tool-action="json" type="button">JSON</button><button class="btn btn-sm btn-cyan" data-tool-action="download" type="button">DOWNLOAD</button></div></div>`;
    $('.canvas-title', header).addEventListener('input', event => { tool.title = event.target.value || 'Untitled Tool'; touchTool(tool); renderToolTabs(); renderToolList(); });
    $('.tool-color', header).addEventListener('input', event => { tool.color = event.target.value; touchTool(tool); renderToolTabs(); renderToolList(); header.style.setProperty('--context-color', tool.color); });
    $('[data-tool-action="download"]', header).addEventListener('click', exportActiveTool);
    $('[data-tool-action="json"]', header).addEventListener('click', () => { $('#panelJsonEditor').value = JSON.stringify(sanitizeTool(tool), null, 2); $('#modalPanelJson').dataset.mode = 'tool'; openModal('modalPanelJson'); });
    area.insertBefore(header, empty);

    tool.components.forEach((component, index) => area.insertBefore(buildComponentCard(component, index), empty));
    renderInspector();
  }

  function buildComponentCard(component, index) {
    const type = definition(component.typeKey);
    const card = document.createElement('article');
    const conditionGlow = component.glowCondition && component.conditions?.length;
    const triggerGlow = component.glowTrigger && component.triggers?.length;
    card.className = `panel-card${component.id === state.selectedComponentId ? ' selected' : ''}${conditionGlow ? ' glow-condition' : ''}${triggerGlow ? ' glow-trigger' : ''}`;
    card.dataset.componentId = component.id; card.dataset.path = `${activeTool()?.title || 'Tool'} > ${component.title}`; card.style.setProperty('--identity', component.identityColor || type.color);
    const badges = `${component.calledExternally ? '<span class="external-badge incoming">Externally Called</span>' : ''}${component.makesExternalCall ? '<span class="external-badge outgoing">Calls Externally</span>' : ''}`;
    card.innerHTML = `
      <div class="panel-card-header">
        <span class="panel-card-swatch"></span>
        <span class="panel-card-title" contenteditable="true">${esc(component.title)}</span>
        <span class="panel-card-type">${esc(type.displayName)}</span>
        <span class="panel-card-id">${esc(component.id.slice(0, 18))}…</span>
        <div class="panel-card-actions">
          <button class="card-icon" data-card-action="json" data-tooltip="Directly edit this instance JSON" type="button">{ }</button>
          <button class="card-icon" data-card-action="settings" data-tooltip="Tooltip, description, calls, glow and section settings" type="button">⚙</button>
          <button class="card-icon" data-card-action="duplicate" data-tooltip="Duplicate component" type="button">⧉</button>
          <button class="card-icon" data-card-action="delete" data-tooltip="Delete component" type="button">×</button>
        </div>
      </div>
      ${badges ? `<div class="external-badges">${badges}</div>` : ''}
      ${type.hasConditions !== false ? buildRuleSectionMarkup(component, 'conditions') : ''}
      <div class="panel-payload"></div>
      ${component.description ? `<div class="panel-meta-note">${esc(component.description)}</div>` : ''}
      ${type.hasTriggers !== false ? buildRuleSectionMarkup(component, 'triggers') : ''}
      <div class="panel-card-footer"><span class="source-path">${esc(component.source || `ToolDesigner.definition.${component.typeKey}`)}</span><button class="btn btn-sm" data-card-action="save" type="button">SAVE COMPONENT</button></div>`;

    $('.panel-card-title', card).addEventListener('blur', event => { component.title = event.target.textContent.trim() || type.displayName; touchComponent(component); renderToolList(); renderInspector(); });
    renderPayloadFields($('.panel-payload', card), component, type);
    wireRuleSection(card, component, 'conditions');
    wireRuleSection(card, component, 'triggers');

    card.addEventListener('click', event => {
      if (event.target.closest('button,input,select,textarea,[contenteditable],.panel-section-header')) return;
      state.selectedComponentId = component.id; renderCanvas();
    });
    $$('[data-card-action]', card).forEach(button => button.addEventListener('click', event => {
      event.stopPropagation();
      const action = button.dataset.cardAction;
      if (action === 'json') openComponentJson(component);
      if (action === 'settings') openPanelSettings(component);
      if (action === 'duplicate') duplicateComponent(component);
      if (action === 'delete') deleteComponent(component.id);
      if (action === 'save') saveReusableComponent(component);
    }));
    card.addEventListener('dragover', event => event.preventDefault());
    card.addEventListener('drop', event => {
      const typeKey = event.dataTransfer.getData('text/tool-designer-type');
      if (!typeKey) return;
      event.preventDefault();
      addComponent(typeKey, index + 1);
    });
    return card;
  }

  function buildRuleSectionMarkup(component, kind) {
    const isConditions = kind === 'conditions';
    const collapsed = isConditions ? component.conditionsCollapsed : component.triggersCollapsed;
    const tooltip = isConditions ? component.conditionsTooltip : component.triggersTooltip;
    const title = isConditions ? 'Conditions' : 'Triggers';
    return `<section class="panel-section ${kind} ${collapsed ? 'collapsed' : ''}" data-rule-section="${kind}"><div class="panel-section-header" data-tooltip="${escAttr(tooltip)}"><span class="section-chevron">▾</span><span>${title}</span><span class="section-count">${(component[kind] || []).length}</span><button class="section-gear" type="button" data-section-gear="${kind}" data-tooltip="Edit hidden ${title.toLowerCase()} tooltip">⚙</button></div><div class="panel-section-body"><div class="rule-list"></div><button class="btn btn-sm" data-add-rule="${kind}" type="button">＋ ${isConditions ? 'CONDITION' : 'TRIGGER'}</button></div></section>`;
  }

  function wireRuleSection(card, component, kind) {
    const section = $(`[data-rule-section="${kind}"]`, card);
    if (!section) return;
    const list = $('.rule-list', section);
    (component[kind] || []).forEach((rule, index) => list.appendChild(buildRuleRow(component, kind, rule, index)));
    $('.panel-section-header', section).addEventListener('click', event => {
      if (event.target.closest('button')) return;
      section.classList.toggle('collapsed');
      if (kind === 'conditions') component.conditionsCollapsed = section.classList.contains('collapsed');
      else component.triggersCollapsed = section.classList.contains('collapsed');
      touchComponent(component);
    });
    $(`[data-add-rule="${kind}"]`, section).addEventListener('click', () => {
      component[kind].push(kind === 'conditions' ? { id: uid('condition'), path: '', operator: '==', value: '', tooltip: '' } : { id: uid('trigger'), path: '', operation: 'set', value: '', tooltip: '' });
      touchComponent(component); renderCanvas();
    });
    $(`[data-section-gear="${kind}"]`, section).addEventListener('click', event => { event.stopPropagation(); openPanelSettings(component, kind); });
  }

  function buildRuleRow(component, kind, rule, index) {
    const row = document.createElement('div'); row.className = 'kv-row';
    const operationKey = kind === 'conditions' ? 'operator' : 'operation';
    const operations = kind === 'conditions' ? CONDITION_OPERATORS : TRIGGER_OPERATORS;
    row.innerHTML = `<input data-rule-key="path" value="${escAttr(rule.path || '')}" placeholder="data.path" data-tooltip="${escAttr(rule.tooltip || 'Target path')}"><select data-rule-key="${operationKey}">${operations.map(op => `<option value="${escAttr(op)}" ${rule[operationKey] === op ? 'selected' : ''}>${esc(op)}</option>`).join('')}</select><input data-rule-key="value" value="${escAttr(typeof rule.value === 'object' ? JSON.stringify(rule.value) : rule.value ?? '')}" placeholder="value"><button class="mini-icon" type="button">×</button>`;
    $$('[data-rule-key]', row).forEach(input => input.addEventListener('change', event => {
      let value = event.target.value;
      if (event.target.dataset.ruleKey === 'value') value = parseLooseValue(value);
      rule[event.target.dataset.ruleKey] = value; touchComponent(component);
    }));
    $('button', row).addEventListener('click', () => { component[kind].splice(index, 1); touchComponent(component); renderCanvas(); });
    return row;
  }

  function parseLooseValue(value) {
    const text = String(value).trim();
    if (text === 'true') return true;
    if (text === 'false') return false;
    if (text === 'null') return null;
    if (text !== '' && !Number.isNaN(Number(text))) return Number(text);
    if ((text.startsWith('{') && text.endsWith('}')) || (text.startsWith('[') && text.endsWith(']'))) { try { return JSON.parse(text); } catch (_) {} }
    return value;
  }

  function renderPayloadFields(container, component, type) {
    container.innerHTML = '';
    (type.fields || []).forEach(field => {
      const wrapper = document.createElement('label');
      wrapper.className = `payload-field${field.type === 'textarea' || field.type === 'json' || field.type === 'list' ? ' full' : ''}${field.type === 'checkbox' ? ' checkbox' : ''}`;
      const value = component.payload[field.key];
      if (field.type === 'checkbox') {
        wrapper.innerHTML = `<input type="checkbox" data-field="${escAttr(field.key)}" ${truthy(value) ? 'checked' : ''}><span>${esc(field.label || field.key)}</span>`;
      } else if (field.type === 'textarea') {
        wrapper.innerHTML = `<span>${esc(field.label || field.key)}</span><textarea data-field="${escAttr(field.key)}">${esc(value ?? '')}</textarea>`;
      } else if (field.type === 'select') {
        wrapper.innerHTML = `<span>${esc(field.label || field.key)}</span><select data-field="${escAttr(field.key)}">${(field.options || []).map(option => `<option value="${escAttr(option)}" ${String(value) === String(option) ? 'selected' : ''}>${esc(option)}</option>`).join('')}</select>`;
      } else if (field.type === 'color') {
        wrapper.innerHTML = `<span>${esc(field.label || field.key)}</span><input type="color" data-field="${escAttr(field.key)}" value="${escAttr(value || field.default || '#ff2f92')}">`;
      } else if (field.type === 'number') {
        wrapper.innerHTML = `<span>${esc(field.label || field.key)}</span><input type="number" data-field="${escAttr(field.key)}" value="${escAttr(value ?? 0)}">`;
      } else if (field.type === 'json') {
        wrapper.innerHTML = `<span>${esc(field.label || field.key)}</span><textarea data-field="${escAttr(field.key)}" data-json-field="1">${esc(JSON.stringify(value ?? {}, null, 2))}</textarea>`;
      } else if (field.type === 'list') {
        wrapper.innerHTML = `<span>${esc(field.label || field.key)}</span><input data-field="${escAttr(field.key)}" data-list-field="1" value="${escAttr(Array.isArray(value) ? value.join(', ') : value || '')}" placeholder="comma-separated values">`;
      } else {
        const tooltip = field.type === 'image' ? `Relative to ${state.imagesRootPath}/` : field.type === 'url' ? 'Complete web address' : field.type === 'id' ? 'Stable ID; renaming the title does not change this' : '';
        wrapper.innerHTML = `<span>${esc(field.label || field.key)}</span><input type="${field.type === 'url' ? 'url' : 'text'}" data-field="${escAttr(field.key)}" value="${escAttr(value ?? '')}" ${tooltip ? `data-tooltip="${escAttr(tooltip)}"` : ''}>`;
      }
      const input = $('[data-field]', wrapper);
      input.addEventListener(field.type === 'color' || field.type === 'checkbox' ? 'input' : 'change', event => {
        let next;
        if (field.type === 'checkbox') next = event.target.checked;
        else if (field.type === 'number') next = Number(event.target.value || 0);
        else if (field.type === 'list') next = event.target.value.split(',').map(item => item.trim()).filter(Boolean);
        else if (field.type === 'json') { try { next = JSON.parse(event.target.value || '{}'); event.target.setCustomValidity(''); } catch (_) { event.target.setCustomValidity('Invalid JSON'); return; } }
        else next = event.target.value;
        component.payload[field.key] = next;
        if (field.key === 'speakerColor' || field.key === 'color') { component.identityColor = String(next); cardColorRefresh(component); }
        touchComponent(component);
      });
      container.appendChild(wrapper);
    });
    if (!(type.fields || []).length) container.innerHTML = '<div class="empty-inspector">This definition has no inline fields. Use the JSON editor or author fields in the Component Type Builder.</div>';
  }

  function cardColorRefresh(component) {
    const card = $(`[data-component-id="${CSS.escape(component.id)}"]`); if (card) card.style.setProperty('--identity', component.identityColor);
  }

  function renderInspector() {
    const component = selectedComponent();
    $('#inspectorEmpty').classList.toggle('hidden', !!component);
    $('#inspectorBody').classList.toggle('hidden', !component);
    $('#selectedTypeBadge').textContent = component ? component.typeKey : '—';
    if (!component) return;
    $('#inspTitle').textContent = component.title;
    $('#inspId').textContent = component.id;
    $('#inspFacts').innerHTML = [
      ['Conditions', component.conditions?.length || 0], ['Triggers', component.triggers?.length || 0],
      ['Incoming', component.calledExternally ? 'Yes' : 'No'], ['Outgoing', component.makesExternalCall ? 'Yes' : 'No']
    ].map(([label, value]) => `<div class="inspector-fact"><span>${esc(label)}</span><b>${esc(value)}</b></div>`).join('');
  }

  function selectTool(id) {
    if (!state.tools.some(tool => tool.id === id)) return;
    state.activeToolId = id; state.selectedComponentId = null;
    renderToolTabs(); renderToolList(); renderCanvas(); autoSave(); closeMenus();
  }

  function createTool(title) {
    const tool = makeTool(title || `New Tool ${state.tools.length + 1}`, { color: state.theme.primary, components: [makeComponent('SequenceSettings', { title: 'Tool Settings' })] });
    state.tools.push(tool); selectTool(tool.id); log(`Created tool ${tool.title}`); autoSave();
  }

  function removeTool(id) {
    const tool = state.tools.find(item => item.id === id); if (!tool) return;
    if (!confirm(`Delete the tool “${tool.title}” and all ${tool.components.length} components?`)) return;
    state.tools = state.tools.filter(item => item.id !== id);
    if (state.activeToolId === id) state.activeToolId = state.tools[0]?.id || null;
    state.selectedComponentId = null; renderToolTabs(); renderToolList(); renderCanvas(); autoSave(); log(`Deleted tool ${tool.title}`);
  }

  function addComponent(typeKey, index = null) {
    const tool = activeTool(); if (!tool) { createTool('New Tool'); return addComponent(typeKey, index); }
    const component = makeComponent(typeKey);
    if (Number.isInteger(index)) tool.components.splice(index, 0, component); else tool.components.push(component);
    state.selectedComponentId = component.id; touchTool(tool); renderToolList(); renderCanvas(); log(`Added ${component.typeKey} to ${tool.title}`);
  }

  function duplicateComponent(component) {
    const tool = activeTool(); if (!tool) return;
    const copy = clone(component); copy.id = uid('component'); copy.title += ' Copy'; copy.createdAtMs = Date.now(); copy.createdAt = nowReadable(); copy.updatedAtMs = Date.now(); copy.updatedAt = nowReadable();
    const index = tool.components.findIndex(item => item.id === component.id); tool.components.splice(index + 1, 0, copy); state.selectedComponentId = copy.id; touchTool(tool); renderToolList(); renderCanvas();
  }

  function deleteComponent(id) {
    const tool = activeTool(); const component = tool?.components.find(item => item.id === id); if (!component) return;
    if (!confirm(`Delete “${component.title}”?`)) return;
    tool.components = tool.components.filter(item => item.id !== id); if (state.selectedComponentId === id) state.selectedComponentId = null; touchTool(tool); renderToolList(); renderCanvas();
  }

  function saveReusableComponent(component) {
    const saved = clone(component); saved.libraryId = uid('saved'); saved.savedAtMs = Date.now(); saved.savedAt = nowReadable();
    state.savedComponents.push(saved); autoSave(); log(`Saved reusable component ${component.title}`); alert('Saved to the reusable component library in this profile. It is included in complete workspace exports.');
  }

  function openComponentJson(component) {
    $('#panelJsonEditor').value = JSON.stringify(sanitizeComponent(component), null, 2);
    $('#modalPanelJson').dataset.mode = 'component'; $('#modalPanelJson').dataset.componentId = component.id; openModal('modalPanelJson');
  }

  function applyJsonEditor() {
    try {
      const parsed = JSON.parse($('#panelJsonEditor').value);
      const mode = $('#modalPanelJson').dataset.mode;
      if (mode === 'tool') {
        const tool = activeTool(); if (!tool) return;
        const normalized = normalizeImportedTool(parsed); const index = state.tools.findIndex(item => item.id === tool.id); state.tools[index] = normalized; state.activeToolId = normalized.id;
      } else {
        const tool = activeTool(); const component = tool?.components.find(item => item.id === $('#modalPanelJson').dataset.componentId); if (!component) return;
        const normalized = normalizeImportedComponent(parsed); const index = tool.components.findIndex(item => item.id === component.id); tool.components[index] = normalized; state.selectedComponentId = normalized.id;
      }
      closeModal('modalPanelJson'); renderAll(); autoSave(); log(`Applied ${mode} JSON live`);
    } catch (error) { alert(`Invalid JSON: ${error.message}`); }
  }

  function openPanelSettings(component, focusKind = '') {
    state.editingPanelId = component.id;
    $('#panelTooltip').value = component.tooltip || '';
    $('#panelDescription').value = component.description || '';
    $('#panelSource').value = component.source || '';
    $('#panelExternalId').value = component.externalId || '';
    $('#panelCalledExternally').checked = !!component.calledExternally;
    $('#panelMakesExternalCall').checked = !!component.makesExternalCall;
    $('#panelConditionsCollapsed').checked = !!component.conditionsCollapsed;
    $('#panelTriggersCollapsed').checked = !!component.triggersCollapsed;
    $('#panelGlowCondition').checked = component.glowCondition !== false;
    $('#panelGlowTrigger').checked = component.glowTrigger !== false;
    $('#conditionsTooltip').value = component.conditionsTooltip || '';
    $('#triggersTooltip').value = component.triggersTooltip || '';
    openModal('modalPanelSettings');
    if (focusKind) setTimeout(() => $(focusKind === 'conditions' ? '#conditionsTooltip' : '#triggersTooltip')?.focus(), 0);
  }

  function savePanelSettings() {
    const tool = activeTool(); const component = tool?.components.find(item => item.id === state.editingPanelId); if (!component) return;
    component.tooltip = $('#panelTooltip').value;
    component.description = $('#panelDescription').value;
    component.source = $('#panelSource').value;
    component.externalId = $('#panelExternalId').value;
    component.calledExternally = $('#panelCalledExternally').checked;
    component.makesExternalCall = $('#panelMakesExternalCall').checked;
    component.conditionsCollapsed = $('#panelConditionsCollapsed').checked;
    component.triggersCollapsed = $('#panelTriggersCollapsed').checked;
    component.glowCondition = $('#panelGlowCondition').checked;
    component.glowTrigger = $('#panelGlowTrigger').checked;
    component.conditionsTooltip = $('#conditionsTooltip').value;
    component.triggersTooltip = $('#triggersTooltip').value;
    touchComponent(component); closeModal('modalPanelSettings'); renderCanvas();
  }

  function openTopBarModal() {
    const list = $('#topBarButtonList'); list.innerHTML = '';
    state.topBarButtons.sort((a, b) => Number(a.sortOrder) - Number(b.sortOrder)).forEach((button, index) => {
      const row = document.createElement('div'); row.className = 'topbar-editor-row';
      row.innerHTML = `<div class="topbar-editor-grid">
        <div class="field-group"><label>Button Text</label><input data-button-field="buttonText" value="${escAttr(button.buttonText)}"></div>
        <div class="field-group"><label>Order</label><input type="number" data-button-field="sortOrder" value="${Number(button.sortOrder) || 0}"></div>
        <div class="field-group"><label>Destination Type</label><div class="topbar-type-choice"><label><input type="radio" name="linkType_${escAttr(button.id)}" value="url" ${button.linkType !== 'image' ? 'checked' : ''}> Web address</label><label><input type="radio" name="linkType_${escAttr(button.id)}" value="image" ${button.linkType === 'image' ? 'checked' : ''}> Image root path</label></div></div>
        <div class="field-group destination-field"><label>${button.linkType === 'image' ? 'Images/[field name]' : 'Web Address or #LocalTool'}</label><input data-button-field="destination" value="${escAttr(button.linkType === 'image' ? button.imagePath : button.url)}"></div>
        <div class="field-group"><label>Tooltip</label><input data-button-field="tooltip" value="${escAttr(button.tooltip || '')}"></div>
        <div class="field-group"><label>Description / Developer Memory</label><textarea data-button-field="description" rows="3">${esc(button.description || '')}</textarea></div>
        <label class="flag"><input type="checkbox" data-button-field="visible" ${button.visible !== false ? 'checked' : ''}> Visible in dropdown</label>
        <button class="btn btn-sm" data-remove-button type="button">REMOVE</button>
      </div>`;
      $$('[data-button-field]', row).forEach(input => input.addEventListener('input', event => {
        const key = event.target.dataset.buttonField;
        if (key === 'visible') button.visible = event.target.checked;
        else if (key === 'sortOrder') button.sortOrder = Number(event.target.value || 0);
        else if (key === 'destination') { if (button.linkType === 'image') button.imagePath = event.target.value; else button.url = event.target.value; }
        else button[key] = event.target.value;
        autoSave();
      }));
      $$(`input[name="linkType_${CSS.escape(button.id)}"]`, row).forEach(radio => radio.addEventListener('change', event => { button.linkType = event.target.value; openTopBarModal(); }));
      $('[data-remove-button]', row).addEventListener('click', () => { state.topBarButtons.splice(index, 1); openTopBarModal(); });
      list.appendChild(row);
    });
    openModal('modalTopBar');
  }

  function renderThemeEditor() {
    const grid = $('#themeTokenGrid'); grid.innerHTML = '';
    Object.keys(DEFAULT_THEME).forEach(key => {
      const row = document.createElement('div'); row.className = 'theme-token-row'; row.innerHTML = `<label>${esc(key.replace(/([A-Z])/g, ' $1'))}</label><input type="color" data-theme-key="${escAttr(key)}" value="${escAttr(state.theme[key] || DEFAULT_THEME[key])}">`;
      $('input', row).addEventListener('input', event => { state.theme[key] = event.target.value; applyTheme(); autoSave(); });
      grid.appendChild(row);
    });
  }

  const THEME_PRESETS = {
    dialoguePink: clone(DEFAULT_THEME),
    violet: Object.assign(clone(DEFAULT_THEME), { primary: '#b85cff', primaryDim: '#7f2dc4', accent: '#ff66c4', borderBright: '#6d4b7d' }),
    cyan: Object.assign(clone(DEFAULT_THEME), { primary: '#00d9ff', primaryDim: '#0086aa', accent: '#ff2f92', borderBright: '#356c77' }),
    reset: clone(DEFAULT_THEME)
  };

  function openProfileModal() {
    $('#profileName').value = state.profileName;
    $('#jsonRootPath').value = state.jsonRootPath;
    $('#imagesRootPath').value = state.imagesRootPath;
    $('#dbHostDisplay').value = state.dbHostDisplay;
    $('#jsonRootPath').disabled = !isAdmin();
    $('#imagesRootPath').disabled = !isAdmin();
    renderThemeEditor(); renderServerProfiles(); openModal('modalProfileSettings');
  }

  function applyProfileSettings() {
    state.profileName = $('#profileName').value.trim() || 'ToolDesigner Default';
    if (isAdmin()) {
      state.jsonRootPath = normalizeRoot($('#jsonRootPath').value, 'Json/Defaults');
      state.imagesRootPath = normalizeRoot($('#imagesRootPath').value, 'Images');
    }
    state.dbHostDisplay = $('#dbHostDisplay').value.trim() || 'localhost';
    applyTheme(); renderAll(); autoSave(); log(`Applied profile ${state.profileName}`); closeModal('modalProfileSettings');
  }

  function normalizeRoot(value, fallback) {
    const cleaned = String(value || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '').replace(/\.\./g, '');
    return cleaned || fallback;
  }

  function openComponentBuilder(typeKey = null) {
    if (!isAdmin()) { alert('Administrator permission is required to author component definitions.'); return; }
    state.editingComponentTypeKey = typeKey;
    const type = typeKey ? clone(definition(typeKey)) : { typeKey: '', displayName: '', category: 'General', color: state.theme.primary, tooltip: '', description: '', hasConditions: true, hasTriggers: true, fields: [] };
    $('#componentTypeKey').value = type.typeKey;
    $('#componentDisplayName').value = type.displayName;
    $('#componentCategory').value = type.category;
    $('#componentColor').value = type.color;
    $('#componentTooltip').value = type.tooltip || '';
    $('#componentDescription').value = type.description || '';
    $('#componentConditions').checked = type.hasConditions !== false;
    $('#componentTriggers').checked = type.hasTriggers !== false;
    $('#componentTypeKey').disabled = !!typeKey;
    $('#btnDeleteComponentType').disabled = !typeKey || BUILTIN_TYPES.some(item => item.typeKey === typeKey);
    state._componentBuilderFields = clone(type.fields || []);
    renderComponentFieldRows(); updateComponentPreview(); openModal('modalComponentBuilder');
  }

  function renderComponentFieldRows() {
    const list = $('#componentFieldList'); list.innerHTML = '';
    state._componentBuilderFields.forEach((field, index) => {
      const row = document.createElement('div'); row.className = 'component-field-row';
      row.innerHTML = `<input data-def-field="key" value="${escAttr(field.key || '')}" placeholder="fieldKey"><input data-def-field="label" value="${escAttr(field.label || '')}" placeholder="Field Label"><select data-def-field="type">${FIELD_TYPES.map(type => `<option value="${type}" ${field.type === type ? 'selected' : ''}>${type}</option>`).join('')}</select><input data-def-field="default" value="${escAttr(typeof field.default === 'object' ? JSON.stringify(field.default) : field.default ?? '')}" placeholder="default"><button class="mini-icon" type="button">×</button>`;
      $$('[data-def-field]', row).forEach(input => input.addEventListener('input', event => { field[event.target.dataset.defField] = event.target.dataset.defField === 'default' ? parseLooseValue(event.target.value) : event.target.value; updateComponentPreview(); }));
      $('button', row).addEventListener('click', () => { state._componentBuilderFields.splice(index, 1); renderComponentFieldRows(); updateComponentPreview(); });
      list.appendChild(row);
    });
  }

  function componentBuilderValue() {
    return {
      typeKey: $('#componentTypeKey').value.trim().replace(/[^A-Za-z0-9_]/g, ''),
      displayName: $('#componentDisplayName').value.trim(),
      category: $('#componentCategory').value.trim() || 'General',
      color: $('#componentColor').value,
      tooltip: $('#componentTooltip').value,
      description: $('#componentDescription').value,
      hasConditions: $('#componentConditions').checked,
      hasTriggers: $('#componentTriggers').checked,
      fields: clone(state._componentBuilderFields || [])
    };
  }

  function updateComponentPreview() { $('#componentDefinitionPreview').textContent = JSON.stringify(componentBuilderValue(), null, 2); }

  function saveComponentType() {
    const type = componentBuilderValue();
    if (!type.typeKey || !type.displayName) { alert('Type Key and Display Name are required.'); return; }
    const duplicate = state.panelTypes.find(item => item.typeKey === type.typeKey);
    if (duplicate && state.editingComponentTypeKey !== type.typeKey) { alert('That Type Key already exists.'); return; }
    if (duplicate) Object.assign(duplicate, type); else state.panelTypes.push(type);
    closeModal('modalComponentBuilder'); renderPanelTypes($('#librarySearch').value); renderCanvas(); autoSave(); log(`Saved component type ${type.typeKey}`);
  }

  function deleteComponentType() {
    const key = state.editingComponentTypeKey; if (!key || BUILTIN_TYPES.some(item => item.typeKey === key)) return;
    const usage = state.tools.reduce((count, tool) => count + tool.components.filter(component => component.typeKey === key).length, 0);
    if (usage && !confirm(`${usage} components use this definition. Delete it anyway? Existing instances will fall back to Generic Panel rendering.`)) return;
    state.panelTypes = state.panelTypes.filter(item => item.typeKey !== key); closeModal('modalComponentBuilder'); renderPanelTypes(); renderCanvas(); autoSave();
  }

  function buildDefinitionIndex() {
    const entries = [];
    state.panelTypes.forEach(type => entries.push({ key: `definition.${type.typeKey}`, kind: 'definition', value: type.displayName, location: `Component Type Builder > ${type.displayName}`, toolId: '', componentId: '', tooltip: type.description || type.tooltip || '' }));
    state.globalTokens.forEach(token => entries.push({ key: `token.${token.key}`, kind: 'token', value: token.value, location: `Global Values > {{${token.key}}}`, toolId: '', componentId: '', tooltip: 'Global token definition.' }));
    state.tools.forEach(tool => tool.components.forEach(component => {
      (component.conditions || []).forEach((rule, index) => entries.push({ key: rule.path || '(empty condition path)', kind: 'condition', value: `${rule.operator} ${stringifyValue(rule.value)}`, location: `${tool.title} > ${component.title} > Conditions[${index}]`, toolId: tool.id, componentId: component.id, tooltip: rule.tooltip || component.conditionsTooltip || '' }));
      (component.triggers || []).forEach((rule, index) => entries.push({ key: rule.path || '(empty trigger path)', kind: 'trigger', value: `${rule.operation} ${stringifyValue(rule.value)}`, location: `${tool.title} > ${component.title} > Triggers[${index}]`, toolId: tool.id, componentId: component.id, tooltip: rule.tooltip || component.triggersTooltip || '' }));
      flattenPayload(component.payload).forEach(item => entries.push({ key: `${component.typeKey}.${item.path}`, kind: 'payload', value: stringifyValue(item.value), location: `${tool.title} > ${component.title} > payload.${item.path}`, toolId: tool.id, componentId: component.id, tooltip: component.tooltip || component.description || '' }));
    }));
    return entries;
  }

  function flattenPayload(value, prefix = '') {
    const results = [];
    if (value && typeof value === 'object' && !Array.isArray(value)) Object.entries(value).forEach(([key, child]) => results.push(...flattenPayload(child, prefix ? `${prefix}.${key}` : key)));
    else results.push({ path: prefix || 'value', value });
    return results;
  }

  function stringifyValue(value) { return typeof value === 'string' ? value : JSON.stringify(value); }

  function openJsonLibrary() {
    state._definitionIndex = buildDefinitionIndex(); renderJsonLibrary(); openModal('modalJsonLib');
  }

  function renderJsonLibrary() {
    const list = $('#jsonLibList'); const query = $('#jsonLibSearch').value.trim().toLowerCase(); const kindFilter = $('#jsonLibKind').value;
    const groups = new Map();
    (state._definitionIndex || buildDefinitionIndex()).filter(entry => (kindFilter === 'all' || entry.kind === kindFilter) && (!query || `${entry.key} ${entry.value} ${entry.location} ${entry.tooltip}`.toLowerCase().includes(query))).forEach(entry => {
      const groupKey = `${entry.kind}|${entry.key}|${entry.value}`;
      if (!groups.has(groupKey)) groups.set(groupKey, { kind: entry.kind, key: entry.key, value: entry.value, entries: [] });
      groups.get(groupKey).entries.push(entry);
    });
    list.innerHTML = '';
    Array.from(groups.values()).sort((a, b) => `${a.kind}.${a.key}`.localeCompare(`${b.kind}.${b.key}`)).forEach(group => {
      const row = document.createElement('div'); row.className = 'json-lib-row'; row.title = group.entries.map(entry => `${entry.location}${entry.tooltip ? ` — ${entry.tooltip}` : ''}`).join('\n');
      row.innerHTML = `<div class="json-lib-head"><span class="json-lib-key">${esc(group.key)}</span><span class="json-lib-kind">${esc(group.kind)}</span><span class="json-lib-count">${group.entries.length}</span><span title="${escAttr(group.value)}">${esc(String(group.value).slice(0, 42))}</span></div><div class="json-lib-locations"><select><option value="">Choose a placement to jump to…</option>${group.entries.map((entry, index) => `<option value="${index}">${esc(entry.location)}</option>`).join('')}</select></div>`;
      $('select', row).addEventListener('change', event => { const entry = group.entries[Number(event.target.value)]; if (entry) jumpToEntry(entry); });
      list.appendChild(row);
    });
    if (!groups.size) list.innerHTML = '<div class="empty-inspector">No definitions match this filter.</div>';
  }

  function jumpToEntry(entry) {
    if (entry.kind === 'definition') { closeModal('modalJsonLib'); openComponentBuilder(entry.key.replace('definition.', '')); return; }
    if (entry.toolId) { state.activeToolId = entry.toolId; state.selectedComponentId = entry.componentId; renderAll(); closeModal('modalJsonLib'); setTimeout(() => $(`[data-component-id="${CSS.escape(entry.componentId)}"]`)?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 0); }
  }

  function validationIssue(severity, code, message, location = '', toolId = '', componentId = '') { return { id: uid('validation'), severity, code, message, location, toolId, componentId }; }

  function validateWorkspace() {
    const issues = []; const seenTools = new Set(); const seenComponents = new Set(); const seenTypes = new Set();
    if (!state.tools.length) issues.push(validationIssue('error', 'NO_TOOLS', 'The workspace does not contain any Tool contexts.', 'workspace.tools'));
    state.panelTypes.forEach((type, index) => {
      if (!type.typeKey) issues.push(validationIssue('error', 'TYPE_KEY_MISSING', `Component definition ${index + 1} has no typeKey.`, `panelTypes[${index}]`));
      else if (seenTypes.has(type.typeKey)) issues.push(validationIssue('error', 'TYPE_KEY_DUPLICATE', `Component definition key ${type.typeKey} is duplicated.`, `panelTypes.${type.typeKey}`));
      else seenTypes.add(type.typeKey);
      const fieldKeys = new Set(); (type.fields || []).forEach(field => { if (!field.key) issues.push(validationIssue('warning', 'FIELD_KEY_MISSING', `${type.displayName || type.typeKey} contains an inline field without a key.`, `panelTypes.${type.typeKey}.fields`)); else if (fieldKeys.has(field.key)) issues.push(validationIssue('error', 'FIELD_KEY_DUPLICATE', `${type.typeKey} repeats field key ${field.key}.`, `panelTypes.${type.typeKey}.fields.${field.key}`)); else fieldKeys.add(field.key); });
    });
    const tokenKeys = new Set(); state.globalTokens.forEach((token, index) => { const key = String(token.key || '').trim(); if (!key) issues.push(validationIssue('warning', 'TOKEN_EMPTY', `Global token ${index + 1} has no key.`, `globalTokens[${index}]`)); else if (tokenKeys.has(key)) issues.push(validationIssue('warning', 'TOKEN_DUPLICATE', `Global token {{${key}}} is duplicated.`, `globalTokens.${key}`)); else tokenKeys.add(key); });
    state.tools.forEach((tool, toolIndex) => {
      if (!tool.id) issues.push(validationIssue('error', 'TOOL_ID_MISSING', `${tool.title || `Tool ${toolIndex + 1}`} has no permanent ID.`, `tools[${toolIndex}]`));
      else if (seenTools.has(tool.id)) issues.push(validationIssue('error', 'TOOL_ID_DUPLICATE', `Tool ID ${tool.id} is duplicated.`, `tools.${tool.id}`, tool.id)); else seenTools.add(tool.id);
      const idsInTool = new Set((tool.components || []).map(component => component.id));
      (tool.components || []).forEach((component, componentIndex) => {
        const location = `${tool.title}.components[${componentIndex}]`;
        if (!component.id) issues.push(validationIssue('error', 'COMPONENT_ID_MISSING', `${component.title || 'Component'} has no permanent ID.`, location, tool.id));
        else if (seenComponents.has(component.id)) issues.push(validationIssue('error', 'COMPONENT_ID_DUPLICATE', `Component ID ${component.id} is duplicated across the workspace.`, location, tool.id, component.id)); else seenComponents.add(component.id);
        if (!state.panelTypes.some(type => type.typeKey === component.typeKey)) issues.push(validationIssue('error', 'DEFINITION_MISSING', `${component.title} references missing definition ${component.typeKey}.`, location, tool.id, component.id));
        if (component.calledExternally && !String(component.externalId || '').trim()) issues.push(validationIssue('warning', 'EXTERNAL_ID_MISSING', `${component.title} is marked Called Externally but has no external identifier.`, location, tool.id, component.id));
        [...(component.conditions || []).map(rule => ['condition', rule]), ...(component.triggers || []).map(rule => ['trigger', rule])].forEach(([kind, rule], ruleIndex) => {
          if (!String(rule.path || '').trim()) issues.push(validationIssue('warning', 'RULE_PATH_MISSING', `${component.title} has a ${kind} without a target path.`, `${location}.${kind}s[${ruleIndex}]`, tool.id, component.id));
          if (kind === 'condition' && !String(rule.operator || '').trim()) issues.push(validationIssue('warning', 'CONDITION_OPERATOR_MISSING', `${component.title} has a condition without an operator.`, `${location}.conditions[${ruleIndex}]`, tool.id, component.id));
          if (kind === 'trigger' && !String(rule.operation || '').trim()) issues.push(validationIssue('warning', 'TRIGGER_OPERATION_MISSING', `${component.title} has a trigger without an operation.`, `${location}.triggers[${ruleIndex}]`, tool.id, component.id));
        });
        const definitionData = definition(component.typeKey); (definitionData?.fields || []).filter(field => field.type === 'id').forEach(field => { if (!String(component.payload?.[field.key] || '').trim()) issues.push(validationIssue('info', 'AUTHORED_ID_EMPTY', `${component.title} has an empty authored ID field: ${field.label || field.key}.`, `${location}.payload.${field.key}`, tool.id, component.id)); });
        ['nextStatementId', 'entryComponentId'].forEach(key => { const value = component.payload?.[key]; if (value && !idsInTool.has(value)) issues.push(validationIssue('warning', 'INTERNAL_LINK_MISSING', `${component.title}.${key} points to ${value}, which is not a component ID in this Tool.`, `${location}.payload.${key}`, tool.id, component.id)); });
        ['responseIds', 'objectiveIds'].forEach(key => { const values = component.payload?.[key]; if (Array.isArray(values)) values.filter(Boolean).forEach(value => { if (!idsInTool.has(value)) issues.push(validationIssue('warning', 'INTERNAL_LINK_MISSING', `${component.title}.${key} contains ${value}, which is not a component ID in this Tool.`, `${location}.payload.${key}`, tool.id, component.id)); }); });
        if (component.unknownFields && Object.keys(component.unknownFields).length) issues.push(validationIssue('info', 'UNKNOWN_FIELDS_PRESERVED', `${component.title} preserves ${Object.keys(component.unknownFields).length} fields not mechanically understood by this build.`, `${location}.unknownFields`, tool.id, component.id));
      });
    });
    state.topBarButtons.filter(button => button.visible !== false).forEach(button => { if (button.linkType === 'url' && !String(button.url || '').trim()) issues.push(validationIssue('warning', 'TOPBAR_URL_EMPTY', `${button.buttonText || 'Top bar button'} is visible but has no web address.`, `topBarButtons.${button.id}`)); if (button.linkType === 'image' && !String(button.imagePath || '').trim()) issues.push(validationIssue('warning', 'TOPBAR_IMAGE_EMPTY', `${button.buttonText || 'Top bar button'} is configured as an image but has no image path.`, `topBarButtons.${button.id}`)); });
    if (!state.prefixes.project || !state.prefixes.tool || !state.prefixes.instance) issues.push(validationIssue('warning', 'PREFIX_INCOMPLETE', 'All three database prefix fields should be filled before generating SQL.', 'profile.prefixes'));
    state.validationReport = issues; return issues;
  }

  function openValidation(showModal = true) { validateWorkspace(); renderValidation(); if (showModal) openModal('modalValidation'); }
  function renderValidation() {
    const issues = state.validationReport || []; const counts = severity => issues.filter(issue => issue.severity === severity).length;
    $('#validationSummary').innerHTML = `<div class="validation-stat"><b>${issues.length}</b><span>Total findings</span></div><div class="validation-stat error"><b>${counts('error')}</b><span>Errors</span></div><div class="validation-stat warning"><b>${counts('warning')}</b><span>Warnings</span></div><div class="validation-stat info"><b>${counts('info')}</b><span>Information</span></div>`;
    const severity = $('#validationSeverity')?.value || 'all'; const query = ($('#validationSearch')?.value || '').toLowerCase(); const list = $('#validationList');
    const filtered = issues.filter(issue => (severity === 'all' || issue.severity === severity) && (!query || `${issue.code} ${issue.message} ${issue.location}`.toLowerCase().includes(query)));
    list.innerHTML = filtered.map(issue => `<div class="validation-row ${issue.severity}"><span class="validation-badge">${esc(issue.severity)}</span><div><div class="validation-message">${esc(issue.message)}</div><div class="validation-path">${esc(issue.code)} · ${esc(issue.location)}</div></div>${issue.componentId ? `<button class="btn btn-sm" data-validation-jump="${escAttr(issue.id)}" type="button">Jump</button>` : ''}</div>`).join('') || '<div class="empty-inspector">No validation findings match this filter.</div>';
    $$('[data-validation-jump]', list).forEach(button => button.addEventListener('click', () => { const issue = issues.find(item => item.id === button.dataset.validationJump); if (!issue) return; state.activeToolId = issue.toolId; state.selectedComponentId = issue.componentId; closeModal('modalValidation'); renderAll(); setTimeout(() => $(`[data-component-id="${CSS.escape(issue.componentId)}"]`)?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 0); }));
  }

  function openHistory() { renderHistory(); openModal('modalHistory'); }
  function renderHistory() {
    const combined = [...state.namedSnapshots.map(snapshot => ({...snapshot, named:true, snapshot:true})), ...state.history.map((entry,index) => ({...entry,index,current:index===state.historyIndex}))].sort((a,b) => b.atMs-a.atMs);
    $('#historyList').innerHTML = combined.map(entry => `<div class="history-row ${entry.current ? 'current' : ''}"><div><div class="history-title">${entry.named ? '★ ' : ''}${esc(entry.label)}</div><div class="history-meta">${esc(entry.at)}${entry.current ? ' · current state' : ''}</div></div><button class="btn btn-sm" data-history-id="${escAttr(entry.id)}" data-history-kind="${entry.snapshot ? 'snapshot' : 'history'}" type="button">Restore</button></div>`).join('') || '<div class="empty-inspector">No history has been captured yet.</div>';
    $$('[data-history-id]', $('#historyList')).forEach(button => button.addEventListener('click', () => { const kind = button.dataset.historyKind; if (kind === 'snapshot') { const snapshot = state.namedSnapshots.find(item => item.id === button.dataset.historyId); if (snapshot) restoreNamedSnapshot(snapshot); } else { const index = state.history.findIndex(item => item.id === button.dataset.historyId); if (index >= 0) restoreHistoryEntry(index); } closeModal('modalHistory'); }));
  }
  function createNamedSnapshot() { const label = $('#snapshotName').value.trim() || `Snapshot ${state.namedSnapshots.length + 1}`; const snapshot = { id: uid('snapshot'), label, atMs: Date.now(), at: nowReadable(), data: JSON.stringify(serializableWorkspaceState()) }; state.namedSnapshots.push(snapshot); state.namedSnapshots = state.namedSnapshots.slice(-20); $('#snapshotName').value=''; persistLocal(); renderHistory(); log(`Saved snapshot: ${label}`); }
  function restoreNamedSnapshot(snapshot) { suppressHistory = true; try { const saved = JSON.parse(snapshot.data); Object.keys(saved).forEach(key => { if (key !== 'version') state[key] = clone(saved[key]); }); renderAll(); persistLocal(); } finally { suppressHistory = false; captureHistory(`Restored snapshot: ${snapshot.label}`); } }

  let inspectedHover = null;
  function cssPathForElement(element) { if (!element || element === document.body) return 'body'; const parts=[]; let node=element; while(node && node.nodeType===1 && node!==document.body){ let part=node.tagName.toLowerCase(); if(node.id){part+=`#${node.id}`;parts.unshift(part);break;} const classes=[...node.classList].filter(name=>!['ui-inspect-hover','open','collapsed'].includes(name)).slice(0,3); if(classes.length)part+='.'+classes.join('.'); const parent=node.parentElement; if(parent){const siblings=[...parent.children].filter(child=>child.tagName===node.tagName);if(siblings.length>1)part+=`:nth-of-type(${siblings.indexOf(node)+1})`;} parts.unshift(part);node=parent;} return ['body',...parts].join(' > '); }
  function colorToHex(value) { const match=String(value||'').match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i); if(!match)return ''; return '#'+[match[1],match[2],match[3]].map(v=>Number(v).toString(16).padStart(2,'0')).join(''); }
  function nearestThemeToken(color) { const hex=colorToHex(color).toLowerCase(); if(!hex)return 'primary'; let best='primary',bestDistance=Infinity; Object.entries(state.theme).forEach(([key,value])=>{ if(!/^#[0-9a-f]{6}$/i.test(value))return; const a=parseInt(hex.slice(1),16),b=parseInt(value.slice(1),16); const distance=Math.abs((a>>16)-(b>>16))+Math.abs(((a>>8)&255)-((b>>8)&255))+Math.abs((a&255)-(b&255)); if(distance<bestDistance){bestDistance=distance;best=key;} }); return best; }
  function startUiInspector() { if (!isAdmin()) return alert('Administrator permission required for UI token inspection.'); state.uiInspectMode=true; document.body.classList.add('ui-inspect-mode'); $('#uiInspectorTray').classList.remove('hidden'); populateUiTokenSelect(); $('#uiInspectorPath').textContent='Hover and click an interface element.'; log('UI Token Inspector enabled'); }
  function stopUiInspector() { state.uiInspectMode=false; document.body.classList.remove('ui-inspect-mode'); inspectedHover?.classList.remove('ui-inspect-hover'); inspectedHover=null; $('#uiInspectorTray').classList.add('hidden'); }
  function populateUiTokenSelect() { const select=$('#uiInspectorToken'); select.innerHTML=Object.keys(state.theme).map(key=>`<option value="${escAttr(key)}">${esc(key)} · ${esc(state.theme[key])}</option>`).join(''); }
  function inspectElement(element) { const styles=getComputedStyle(element); const values={color:styles.color,background:styles.backgroundColor,border:styles.borderTopColor,font:styles.fontFamily}; $('#uiInspectorPath').textContent=cssPathForElement(element); $('#uiInspectorStyles').innerHTML=Object.entries(values).map(([key,value])=>`<div class="ui-style-chip">${key==='font'?'':`<i style="background:${escAttr(value)}"></i>`}<b>${esc(key)}</b><br>${esc(value)}</div>`).join(''); const token=nearestThemeToken(values.color !== 'rgba(0, 0, 0, 0)' ? values.color : values.background); $('#uiInspectorToken').value=token; $('#uiInspectorColor').value=state.theme[token] || '#ff2f92'; state._inspectedElement=element; }
  function openDefinitionMap() {
    const map = {
      version: VERSION,
      componentDefinitions: state.panelTypes.map(type => ({ typeKey: type.typeKey, fields: type.fields.map(field => field.key), placements: state.tools.flatMap(tool => tool.components.filter(component => component.typeKey === type.typeKey).map(component => ({ toolId: tool.id, tool: tool.title, componentId: component.id, component: component.title }))) })),
      tools: state.tools.map(tool => ({ id: tool.id, title: tool.title, components: tool.components.map(component => ({ id: component.id, typeKey: component.typeKey, title: component.title })) })),
      globalTokens: state.globalTokens
    };
    $('#definitionMapPreview').textContent = JSON.stringify(map, null, 2); openModal('modalDefinitionMap');
  }

  function sanitizeComponent(component) {
    return {
      id: component.id, typeKey: component.typeKey, title: component.title, identityColor: component.identityColor,
      tooltip: component.tooltip, description: component.description, source: component.source, externalId: component.externalId,
      calledExternally: !!component.calledExternally, makesExternalCall: !!component.makesExternalCall,
      conditionsCollapsed: !!component.conditionsCollapsed, triggersCollapsed: !!component.triggersCollapsed,
      conditionsTooltip: component.conditionsTooltip, triggersTooltip: component.triggersTooltip,
      glowCondition: component.glowCondition !== false, glowTrigger: component.glowTrigger !== false,
      conditions: clone(component.conditions || []), triggers: clone(component.triggers || []), payload: clone(component.payload || {}),
      unknownFields: clone(component.unknownFields || {}), createdAtMs: component.createdAtMs, createdAt: component.createdAt, updatedAtMs: component.updatedAtMs, updatedAt: component.updatedAt
    };
  }

  function sanitizeTool(tool) {
    return { id: tool.id, title: tool.title, exportTitle: tool.exportTitle, color: tool.color, description: tool.description, settings: clone(tool.settings), components: tool.components.map(sanitizeComponent), unknownFields: clone(tool.unknownFields || {}), createdAtMs: tool.createdAtMs, createdAt: tool.createdAt, updatedAtMs: tool.updatedAtMs, updatedAt: tool.updatedAt };
  }

  function profilePayload() {
    return {
      version: VERSION, kind: 'profile', profileName: state.profileName, exportedAt: new Date().toISOString(),
      theme: clone(state.theme), prefixes: clone(state.prefixes), jsonRootPath: state.jsonRootPath, imagesRootPath: state.imagesRootPath,
      dbHostDisplay: state.dbHostDisplay, topBarButtons: clone(state.topBarButtons), globalTokens: clone(state.globalTokens), panelTypes: clone(state.panelTypes),
      chrome: { leftCollapsed: state.leftCollapsed, rightCollapsed: state.rightCollapsed }, sidebarMeta: clone(state.sidebarMeta), developerMode: state.developerMode
    };
  }

  function workspacePayload() {
    return { version: VERSION, kind: 'workspace', exportedAt: new Date().toISOString(), profile: profilePayload(), tools: state.tools.map(sanitizeTool), savedComponents: clone(state.savedComponents) };
  }

  function toolPayload(tool) {
    return { version: VERSION, kind: 'tool', exportedAt: new Date().toISOString(), exportTitle: tool.exportTitle || tool.title, tool: sanitizeTool(tool), globalTokens: clone(state.globalTokens), componentDefinitions: state.panelTypes.filter(type => tool.components.some(component => component.typeKey === type.typeKey)).map(clone) };
  }

  function unityPayload(tool) {
    return {
      version: VERSION, kind: 'unity-tool', exportedAt: new Date().toISOString(), toolId: tool.id, toolName: tool.title,
      components: tool.components.map(component => ({ id: component.id, type: component.typeKey, name: component.title, enabled: true, conditions: clone(component.conditions), triggers: clone(component.triggers), settings: clone(component.payload), connections: extractConnections(component), source: { file: component.source, externalId: component.externalId }, metadata: { tooltip: component.tooltip, description: component.description } })),
      globalTokens: clone(state.globalTokens)
    };
  }

  function extractConnections(component) {
    const payload = component.payload || {}; const keys = ['nextStatementId', 'targetId', 'entryComponentId', 'responseIds', 'objectiveIds'];
    return keys.filter(key => payload[key] !== undefined).map(key => ({ kind: key, target: clone(payload[key]) }));
  }

  function downloadJson(payload, filename) { const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }); downloadBlob(blob, filename); }
  function downloadBlob(blob, filename) { const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = filename; document.body.appendChild(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(link.href), 1000); }
  function exportWorkspace() { downloadJson(workspacePayload(), 'ToolDesigner_CompleteWorkspace.json'); }
  function exportProfile() { downloadJson(profilePayload(), `${safeName(state.profileName, 'ToolDesigner_Profile')}.json`); }
  function exportActiveTool() { const tool = activeTool(); if (!tool) return alert('No active tool.'); downloadJson(toolPayload(tool), `${safeName(tool.exportTitle || tool.title)}.json`); }
  function exportUnity() { const tool = activeTool(); if (!tool) return alert('No active tool.'); downloadJson(unityPayload(tool), `${safeName(tool.exportTitle || tool.title)}_Unity.json`); }

  function normalizeImportedComponent(raw) {
    const base = makeComponent(raw.typeKey || raw.panelType || 'GenericPanel');
    const known = ['id', 'typeKey', 'panelType', 'title', 'identityColor', 'tooltip', 'description', 'source', 'externalId', 'calledExternally', 'makesExternalCall', 'makeExternalCall', 'conditionsCollapsed', 'triggersCollapsed', 'conditionsTooltip', 'triggersTooltip', 'glowCondition', 'glowTrigger', 'conditions', 'triggers', 'payload', 'unknownFields', 'createdAtMs', 'createdAt', 'updatedAtMs', 'updatedAt'];
    Object.assign(base, {
      id: raw.id || base.id, typeKey: raw.typeKey || raw.panelType || base.typeKey, title: raw.title || base.title, identityColor: raw.identityColor || base.identityColor,
      tooltip: raw.tooltip || '', description: raw.description || '', source: raw.source || base.source, externalId: raw.externalId || '',
      calledExternally: !!raw.calledExternally, makesExternalCall: !!(raw.makesExternalCall ?? raw.makeExternalCall),
      conditionsCollapsed: !!raw.conditionsCollapsed, triggersCollapsed: !!raw.triggersCollapsed,
      conditionsTooltip: raw.conditionsTooltip || base.conditionsTooltip, triggersTooltip: raw.triggersTooltip || base.triggersTooltip,
      glowCondition: raw.glowCondition !== false, glowTrigger: raw.glowTrigger !== false,
      conditions: clone(raw.conditions || []), triggers: clone(raw.triggers || []), payload: Object.assign(base.payload, clone(raw.payload || {})), unknownFields: clone(raw.unknownFields || {}),
      createdAtMs: raw.createdAtMs || base.createdAtMs, createdAt: raw.createdAt || base.createdAt, updatedAtMs: raw.updatedAtMs || Date.now(), updatedAt: raw.updatedAt || nowReadable()
    });
    Object.keys(raw).filter(key => !known.includes(key)).forEach(key => { base.unknownFields[key] = clone(raw[key]); });
    return base;
  }

  function normalizeImportedTool(raw) {
    const source = raw.tool || raw.context || raw;
    const tool = makeTool(source.title || 'Imported Tool', { id: source.id, exportTitle: raw.exportTitle || source.exportTitle, color: source.color, description: source.description, settings: source.settings, unknownFields: source.unknownFields, createdAtMs: source.createdAtMs, createdAt: source.createdAt });
    tool.components = (source.components || source.panels || []).map(normalizeImportedComponent);
    return tool;
  }

  function detectImport(data, fileName = 'Imported.json') {
    const source = data || {};
    const kind = source.kind || (source.tool || source.context ? 'tool' : Array.isArray(source.tools) ? 'workspace-like' : Array.isArray(source.components) ? 'component-collection' : 'arbitrary-json');
    const tools = Array.isArray(source.tools) ? source.tools.length : source.tool || source.context ? 1 : 0;
    const components = Array.isArray(source.components) ? source.components.length : Array.isArray(source.tools) ? source.tools.reduce((sum, tool) => sum + (tool.components?.length || tool.panels?.length || 0), 0) : (source.tool?.components?.length || source.context?.components?.length || 0);
    const definitions = Array.isArray(source.componentDefinitions) ? source.componentDefinitions.length : Array.isArray(source.panelTypes) ? source.panelTypes.length : 0;
    const keys = source && typeof source === 'object' ? Object.keys(source) : [];
    return { kind, tools, components, definitions, topLevelKeys: keys.length, fileName };
  }

  function arbitraryJsonTool(data, fileName) {
    const title = String(fileName || 'Imported Data').replace(/\.json$/i, '') || 'Imported Data';
    const tool = makeTool(title, { exportTitle: safeName(title), description: 'Compatibility-adapted JSON. Every original field is retained inside component payloads and unknownFields.' });
    const entries = Array.isArray(data) ? data.map((value, index) => [String(index), value]) : Object.entries(data && typeof data === 'object' ? data : { value: data });
    tool.components = entries.map(([key, value]) => makeComponent('GenericPanel', {
      title: key || 'Imported Value', source: `${fileName || 'import'}.${key}`,
      payload: { label: key, body: typeof value === 'string' ? value : JSON.stringify(value, null, 2), settings: clone(value) },
      unknownFields: { importedOriginalValue: clone(value), importedPath: key }
    }));
    return tool;
  }

  function importJsonFile(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        state._pendingImport = { data, fileName: file.name, detected: detectImport(data, file.name) };
        const d = state._pendingImport.detected;
        $('#importReviewSummary').innerHTML = `<div class="import-detect-grid"><div class="import-detect"><b>${esc(d.kind)}</b><span>Detected kind</span></div><div class="import-detect"><b>${d.tools}</b><span>Tools</span></div><div class="import-detect"><b>${d.components}</b><span>Components</span></div><div class="import-detect"><b>${d.definitions}</b><span>Definitions</span></div></div><p class="microcopy"><code>${esc(file.name)}</code> contains ${d.topLevelKeys} top-level keys. Unknown fields can be retained even when ToolDesigner does not mechanically understand them.</p>`;
        $('#importReviewPreview').textContent = JSON.stringify(data, null, 2).slice(0, 30000);
        $('#importStrategy').value = d.kind === 'arbitrary-json' ? 'new-tool' : 'smart';
        openModal('modalImportReview');
      } catch (error) { alert(`Import failed: ${error.message}`); }
    };
    reader.readAsText(file);
  }

  function applyPendingImport() {
    const pending = state._pendingImport; if (!pending) return;
    const data = pending.data; const strategy = $('#importStrategy').value; const preserveUnknown = $('#importPreserveUnknown').checked;
    try {
      if (strategy === 'new-tool' || (!data.kind && !data.tool && !data.context && !Array.isArray(data.tools) && data.kind !== 'unity-tool')) {
        const tool = arbitraryJsonTool(data, pending.fileName); state.tools.push(tool); state.activeToolId = tool.id;
      } else if (data.kind === 'workspace' || Array.isArray(data.tools)) {
        const importedTools = (data.tools || []).map(normalizeImportedTool);
        if (strategy === 'replace') {
          applyProfilePayload(data.profile || {}); state.tools = importedTools; state.savedComponents = clone(data.savedComponents || []);
        } else {
          if (Array.isArray(data.componentDefinitions)) mergeDefinitions(data.componentDefinitions);
          if (data.profile) applyProfilePayload(data.profile);
          importedTools.forEach(tool => { const existing = state.tools.findIndex(item => item.id === tool.id); if (existing >= 0) state.tools[existing] = tool; else state.tools.push(tool); });
          if (Array.isArray(data.savedComponents)) state.savedComponents.push(...clone(data.savedComponents));
        }
        state.activeToolId = importedTools[0]?.id || state.activeToolId;
      } else if (data.kind === 'profile') applyProfilePayload(data);
      else if (data.kind === 'tool' || data.tool || data.context) {
        if (Array.isArray(data.componentDefinitions)) mergeDefinitions(data.componentDefinitions);
        const tool = normalizeImportedTool(data); const existing = strategy === 'smart' ? state.tools.findIndex(item => item.id === tool.id) : -1;
        if (existing >= 0) state.tools[existing] = tool; else state.tools.push(tool); state.activeToolId = tool.id;
      } else if (data.kind === 'unity-tool' && Array.isArray(data.components)) {
        const tool = makeTool(data.toolName || 'Imported Unity Tool', { components: data.components.map(component => normalizeImportedComponent({ id: component.id, typeKey: component.type, title: component.name, conditions: component.conditions, triggers: component.triggers, payload: component.settings, source: component.source?.file, externalId: component.source?.externalId, tooltip: component.metadata?.tooltip, description: component.metadata?.description })) });
        state.tools.push(tool); state.activeToolId = tool.id;
      } else { const tool = arbitraryJsonTool(data, pending.fileName); state.tools.push(tool); state.activeToolId = tool.id; }
      if (!preserveUnknown) state.tools.forEach(tool => tool.components.forEach(component => { component.unknownFields = {}; }));
      state._pendingImport = null; closeModal('modalImportReview'); renderAll(); autoSave(`Imported ${pending.fileName}`); log(`Imported ${pending.fileName}`); openValidation(false);
    } catch (error) { alert(`Import failed: ${error.message}`); }
  }

  function mergeDefinitions(definitions) {
    definitions.forEach(raw => {
      if (!raw || !raw.typeKey) return;
      const existing = state.panelTypes.findIndex(type => type.typeKey === raw.typeKey);
      if (existing >= 0) state.panelTypes[existing] = Object.assign({}, state.panelTypes[existing], clone(raw)); else state.panelTypes.push(clone(raw));
    });
  }

  function applyProfilePayload(data) {
    const profile = data.profile || data;
    if (profile.theme) state.theme = Object.assign(clone(DEFAULT_THEME), clone(profile.theme));
    if (profile.prefixes) state.prefixes = Object.assign(state.prefixes, clone(profile.prefixes));
    if (profile.topBarButtons) state.topBarButtons = clone(profile.topBarButtons);
    if (profile.globalTokens) state.globalTokens = clone(profile.globalTokens);
    if (profile.panelTypes) state.panelTypes = clone(profile.panelTypes);
    if (profile.jsonRootPath) state.jsonRootPath = normalizeRoot(profile.jsonRootPath, 'Json/Defaults');
    if (profile.imagesRootPath) state.imagesRootPath = normalizeRoot(profile.imagesRootPath, 'Images');
    if (profile.dbHostDisplay) state.dbHostDisplay = profile.dbHostDisplay;
    if (profile.profileName) state.profileName = profile.profileName;
    if (profile.sidebarMeta) state.sidebarMeta = clone(profile.sidebarMeta);
    if (profile.chrome) { state.leftCollapsed = !!profile.chrome.leftCollapsed; state.rightCollapsed = !!profile.chrome.rightCollapsed; }
    applyTheme();
  }

  async function api(action, payload = {}) {
    try {
      const response = await fetch(`app.php?action=${encodeURIComponent(action)}`, {
        method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, state.authToken ? { Authorization: `Bearer ${state.authToken}` } : {}),
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (!response.ok && !data.error) data.error = `HTTP ${response.status}`;
      return data;
    } catch (error) { return { ok: false, error: `Server unavailable: ${error.message}` }; }
  }

  async function generateSessionId() {
    const result = await api('generateSessionId');
    state.sessionId = result.ok ? result.sessionId : `TD-${Math.random().toString(36).slice(2, 10).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;
    $('#sessionId').value = state.sessionId; $('#sessionLoadId').value = state.sessionId; autoSave();
  }

  async function pushSession() {
    if (!isAuthenticated()) return alert('Guests cannot save to the database. Export JSON instead.');
    const tool = activeTool(); if (!tool) return alert('No active tool.');
    const result = await api('saveTool', { sessionId: state.sessionId, password: $('#sessionPassword').value, tool: sanitizeTool(tool), profile: profilePayload() });
    if (result.ok) { log(`Pushed ${tool.title} to session ${state.sessionId}`, state.user.username); alert('Active tool saved to the server.'); }
    else alert(result.error || 'Save failed.');
  }

  async function loadSession() {
    const sessionId = $('#sessionLoadId').value.trim(); if (!sessionId) return alert('Paste a session ID first.');
    const result = await api('loadTool', { sessionId, password: $('#sessionPassword').value });
    if (!result.ok) return alert(result.error || 'Session could not be loaded.');
    const tool = normalizeImportedTool(result.tool); const existing = state.tools.findIndex(item => item.id === tool.id); if (existing >= 0) state.tools[existing] = tool; else state.tools.push(tool);
    state.sessionId = sessionId; $('#sessionId').value = sessionId; state.activeToolId = tool.id; renderAll(); autoSave(); log(`Loaded session ${sessionId}`);
  }

  function renderPasswordRequirements(targetId, first, second) {
    const checks = [
      ['len', '8–28 characters', first.length >= 8 && first.length <= 28],
      ['upper', 'Uppercase letter', /[A-Z]/.test(first)],
      ['lower', 'Lowercase letter', /[a-z]/.test(first)],
      ['digit', 'Digit', /\d/.test(first)],
      ['special', 'Special character', /[^A-Za-z0-9]/.test(first)],
      ['match', 'Passwords match', first.length > 0 && first === second]
    ];
    $('#' + targetId).innerHTML = checks.map(([, label, ok]) => `<div class="pw-req ${ok ? 'ok' : ''}">${ok ? '✓' : '×'} ${esc(label)}</div>`).join('');
    return checks.every(([, , ok]) => ok);
  }

  function openAuthModal() {
    if (isAuthenticated()) {
      const logout = confirm(`Logged in as ${state.user.username}. Press OK to log out, or Cancel to keep the session.`);
      if (logout) { state.user = null; state.authToken = ''; clearAuthToken(); api('logout'); renderAuthStatus(); log('Logged out'); }
      return;
    }
    state.authMode = 'login'; state.needsPasswordReset = false; renderAuthMode(); $('#authMsg').classList.add('hidden'); openModal('modalAuth');
  }

  function renderAuthMode() {
    const reset = state.needsPasswordReset;
    $('#authModeTabs').classList.toggle('hidden', reset);
    $('#authLoginPane').classList.toggle('hidden', reset || state.authMode !== 'login');
    $('#authRegisterPane').classList.toggle('hidden', reset || state.authMode !== 'register');
    $('#authResetPane').classList.toggle('hidden', !reset);
    $('#authModalTitle').textContent = reset ? 'Secure Bootstrap Administrator' : state.authMode === 'register' ? 'Register Account' : 'Account Access';
    $('#btnAuthSubmit').textContent = reset ? 'Save Administrator' : state.authMode === 'register' ? 'Register' : 'Access';
    renderPasswordRequirements('pwReqs', $('#resetPass1').value, $('#resetPass2').value);
    renderPasswordRequirements('registerPwReqs', $('#registerPass1').value, $('#registerPass2').value);
  }

  async function submitAuth() {
    const message = $('#authMsg'); message.classList.add('hidden');
    let result;
    if (state.needsPasswordReset) {
      const pass1 = $('#resetPass1').value; const pass2 = $('#resetPass2').value;
      if (!renderPasswordRequirements('pwReqs', pass1, pass2)) { message.textContent = 'Complete every password requirement.'; message.classList.remove('hidden'); return; }
      result = await api('resetBootstrap', { username: $('#resetUser').value.trim(), password: pass1, bootstrapToken: state._bootstrapToken });
    } else if (state.authMode === 'register') {
      const pass1 = $('#registerPass1').value; const pass2 = $('#registerPass2').value;
      if (!renderPasswordRequirements('registerPwReqs', pass1, pass2)) { message.textContent = 'Complete every password requirement.'; message.classList.remove('hidden'); return; }
      if (!$('#registerOver18').checked || !$('#registerTerms').checked || !$('#registerPrivacy').checked) { message.textContent = 'Confirm 18+, Terms of Service, and Privacy Policy.'; message.classList.remove('hidden'); return; }
      result = await api('register', { username: $('#registerUser').value.trim(), email: $('#registerEmail').value.trim(), password: pass1, passwordConfirm: pass2, over18: true, terms: true, privacy: true, browserLabel: navigator.userAgent.slice(0,120) });
    } else {
      result = await api('login', { username: $('#authUser').value.trim(), password: $('#authPass').value, browserLabel: navigator.userAgent.slice(0,120) });
      if (result.ok && result.needsReset) { state.needsPasswordReset = true; state._bootstrapToken = result.bootstrapToken; $('#resetUser').value = result.user.username === 'admin' ? '' : result.user.username; renderAuthMode(); return; }
    }
    if (!result.ok) { message.textContent = result.error || 'Authentication failed.'; message.classList.remove('hidden'); return; }
    state.user = result.user; state.authToken = result.token || result.authToken; storeAuthToken(state.authToken); state.needsPasswordReset = false; closeModal('modalAuth'); renderAuthStatus(); log(`Logged in as ${state.user.username}`); await renderServerProfiles();
  }

  async function restoreAuth() {
    if (!state.authToken) return;
    const result = await api('whoami');
    if (result.ok) state.user = result.user;
    else { state.authToken = ''; clearAuthToken(); }
  }

  async function renderServerProfiles() {
    const list = $('#profileServerList'); if (!list) return;
    list.innerHTML = '<div class="microcopy">Loading profiles…</div>';
    const result = await api('listProfiles', { root: state.jsonRootPath });
    if (!result.ok) { list.innerHTML = `<div class="microcopy">${esc(result.error || 'Log in to load server profiles.')}</div>`; return; }
    list.innerHTML = '';
    (result.profiles || []).forEach(profile => {
      const row = document.createElement('div'); row.className = 'profile-list-row';
      row.innerHTML = `<span>${esc(profile.name)}</span><button class="btn btn-sm" type="button">LOAD</button><button class="btn btn-sm" type="button">JSON</button>`;
      const [load, json] = $$('button', row);
      load.addEventListener('click', async () => { const response = await api('loadProfile', { root: state.jsonRootPath, filename: profile.filename }); if (!response.ok) return alert(response.error); applyProfilePayload(response.profile); renderAll(); autoSave(); alert(`Loaded ${profile.name}.`); });
      json.addEventListener('click', () => downloadJson(profile.preview || {}, profile.filename));
      list.appendChild(row);
    });
    if (!result.profiles?.length) list.innerHTML = '<div class="microcopy">No saved profiles in this root.</div>';
  }

  async function saveServerProfile() {
    if (!isAuthenticated()) return alert('Log in before saving server profiles.');
    const result = await api('saveProfile', { root: state.jsonRootPath, profileName: $('#profileName').value.trim() || state.profileName, profile: profilePayload() });
    if (!result.ok) return alert(result.error || 'Profile save failed.');
    log(`Saved profile ${result.filename} to ${state.jsonRootPath}`, state.user.username); await renderServerProfiles();
  }

  const SQL_TABLE_FAMILIES = [
    { key: 'auth', label: 'Auth & Sessions', tables: ['Users', 'AuthTokens', 'Sessions'] },
    { key: 'runtime', label: 'Runtime Tools', tables: ['Tools', 'Components', 'ComponentValues', 'ComponentRules'] },
    { key: 'definitions', label: 'Definitions', tables: ['ComponentDefinitions', 'TopBarButtons', 'Profiles'] },
    { key: 'defaults', label: 'Default Catalogue', tables: ['DefaultTools', 'DefaultComponents', 'DefaultThemes'] },
    { key: 'audit', label: 'Audit & Messages', tables: ['AuditLog', 'ServerMessages'] }
  ];

  async function openSqlModal() {
    $('#sqlTableChecks').innerHTML = SQL_TABLE_FAMILIES.map(family => `<label class="sql-family flag"><input type="checkbox" data-sql-family="${family.key}" checked> ${esc(family.label)} <span class="count">${family.tables.length}</span></label>`).join('');
    if (!state.sqlSource) {
      try { state.sqlSource = await fetch('schema.sql').then(response => response.text()); }
      catch (_) { state.sqlSource = ''; }
    }
    refreshSqlPreview(); openModal('modalSql');
  }

  function selectedSqlFamilies() { return new Set($$('[data-sql-family]:checked').map(input => input.dataset.sqlFamily)); }

  function refreshSqlPreview() {
    const families = selectedSqlFamilies();
    let query = buildCoreSql(families, $('#sqlIncludeDrop').checked, $('#sqlIncludeSeed').checked);
    if ($('#sqlIncludeComponentTables').checked) query += '\n\n' + buildComponentDefinitionTables($('#sqlIncludeDrop').checked);
    $('#sqlPreview').textContent = query.trim() + '\n';
  }

  function sqlIdentifier(value) { return String(value || '').replace(/[^A-Za-z0-9_]/g, '_').replace(/_+/g, '_'); }
  function sqlString(value) { return `'${String(value ?? '').replace(/\\/g, '\\\\').replace(/'/g, "''")}'`; }

  function tableSql(name, body, indexes = '') {
    const full = `${prefixStem()}${name}`;
    return `CREATE TABLE IF NOT EXISTS \`${full}\` (\n${body}${indexes ? `,\n${indexes}` : ''}\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`;
  }

  function buildCoreSql(families, includeDrops, includeSeed) {
    const wanted = SQL_TABLE_FAMILIES.filter(family => families.has(family.key)).flatMap(family => family.tables);
    const drops = includeDrops ? wanted.slice().reverse().map(name => `DROP TABLE IF EXISTS \`${prefixStem()}${name}\`;`).join('\n') : '';
    const definitions = {
      Users: tableSql('Users', '  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,\n  `username` VARCHAR(64) NOT NULL,\n  `email` VARCHAR(255) NOT NULL DEFAULT \'\',\n  `password_hash` VARCHAR(255) NOT NULL,\n  `is_admin` TINYINT(1) NOT NULL DEFAULT 0,\n  `is_active` TINYINT(1) NOT NULL DEFAULT 1,\n  `needs_reset` TINYINT(1) NOT NULL DEFAULT 0,\n  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', '  PRIMARY KEY (`id`),\n  UNIQUE KEY `uq_username` (`username`)'),
      AuthTokens: tableSql('AuthTokens', '  `token_hash` CHAR(64) NOT NULL,\n  `user_id` BIGINT UNSIGNED NOT NULL,\n  `scope` ENUM(\'bootstrap\',\'user\') NOT NULL DEFAULT \'user\',\n  `expires_at` DATETIME NOT NULL,\n  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n  `last_seen_at` TIMESTAMP NULL', '  PRIMARY KEY (`token_hash`),\n  KEY `idx_user_expiry` (`user_id`,`expires_at`)'),
      Sessions: tableSql('Sessions', '  `session_id` VARCHAR(96) NOT NULL,\n  `owner_user_id` BIGINT UNSIGNED NULL,\n  `password_hash` VARCHAR(255) NULL,\n  `expires_at` DATETIME NOT NULL,\n  `is_active` TINYINT(1) NOT NULL DEFAULT 1,\n  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', '  PRIMARY KEY (`session_id`),\n  KEY `idx_owner` (`owner_user_id`)'),
      Tools: tableSql('Tools', '  `tool_id` VARCHAR(128) NOT NULL,\n  `session_id` VARCHAR(96) NOT NULL,\n  `owner_user_id` BIGINT UNSIGNED NOT NULL,\n  `title` VARCHAR(255) NOT NULL,\n  `export_title` VARCHAR(255) NOT NULL DEFAULT \'\',\n  `identity_color` VARCHAR(16) NOT NULL DEFAULT \'#ff2f92\',\n  `tool_json` LONGTEXT NOT NULL,\n  `profile_json` LONGTEXT NULL,\n  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', '  PRIMARY KEY (`tool_id`),\n  UNIQUE KEY `uq_session_tool` (`session_id`,`tool_id`),\n  KEY `idx_session_owner` (`session_id`,`owner_user_id`)'),
      Components: tableSql('Components', '  `component_id` VARCHAR(128) NOT NULL,\n  `tool_id` VARCHAR(128) NOT NULL,\n  `type_key` VARCHAR(128) NOT NULL,\n  `title` VARCHAR(255) NOT NULL,\n  `sort_order` INT NOT NULL DEFAULT 0,\n  `called_externally` TINYINT(1) NOT NULL DEFAULT 0,\n  `makes_external_call` TINYINT(1) NOT NULL DEFAULT 0,\n  `tooltip` VARCHAR(1024) NOT NULL DEFAULT \'\',\n  `description` TEXT NULL,\n  `payload_json` JSON NOT NULL,\n  `unknown_fields_json` JSON NULL,\n  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', '  PRIMARY KEY (`component_id`),\n  KEY `idx_tool_type` (`tool_id`,`type_key`,`sort_order`)'),
      ComponentValues: tableSql('ComponentValues', '  `value_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,\n  `component_id` VARCHAR(128) NOT NULL,\n  `field_key` VARCHAR(128) NOT NULL,\n  `value_json` JSON NOT NULL,\n  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', '  PRIMARY KEY (`value_id`),\n  UNIQUE KEY `uq_component_field` (`component_id`,`field_key`)'),
      ComponentRules: tableSql('ComponentRules', '  `rule_id` VARCHAR(128) NOT NULL,\n  `component_id` VARCHAR(128) NOT NULL,\n  `rule_kind` ENUM(\'condition\',\'trigger\') NOT NULL,\n  `target_path` VARCHAR(512) NOT NULL DEFAULT \'\',\n  `operation` VARCHAR(64) NOT NULL DEFAULT \'\',\n  `value_json` JSON NULL,\n  `tooltip` VARCHAR(1024) NOT NULL DEFAULT \'\',\n  `sort_order` INT NOT NULL DEFAULT 0', '  PRIMARY KEY (`rule_id`),\n  KEY `idx_component_rules` (`component_id`,`rule_kind`,`sort_order`)'),
      ComponentDefinitions: tableSql('ComponentDefinitions', '  `type_key` VARCHAR(128) NOT NULL,\n  `display_name` VARCHAR(255) NOT NULL,\n  `category` VARCHAR(128) NOT NULL DEFAULT \'General\',\n  `identity_color` VARCHAR(16) NOT NULL DEFAULT \'#ff2f92\',\n  `description` TEXT NULL,\n  `tooltip` VARCHAR(1024) NOT NULL DEFAULT \'\',\n  `schema_json` JSON NOT NULL,\n  `authored_by_user_id` BIGINT UNSIGNED NULL,\n  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', '  PRIMARY KEY (`type_key`)'),
      TopBarButtons: tableSql('TopBarButtons', '  `button_id` VARCHAR(128) NOT NULL,\n  `button_text` VARCHAR(128) NOT NULL,\n  `link_type` ENUM(\'url\',\'image\') NOT NULL DEFAULT \'url\',\n  `url` VARCHAR(2048) NOT NULL DEFAULT \'\',\n  `image_path` VARCHAR(1024) NOT NULL DEFAULT \'\',\n  `tooltip` VARCHAR(1024) NOT NULL DEFAULT \'\',\n  `description` TEXT NULL,\n  `sort_order` INT NOT NULL DEFAULT 0,\n  `visible` TINYINT(1) NOT NULL DEFAULT 1', '  PRIMARY KEY (`button_id`)'),
      Profiles: tableSql('Profiles', '  `profile_id` VARCHAR(128) NOT NULL,\n  `owner_user_id` BIGINT UNSIGNED NOT NULL,\n  `name` VARCHAR(255) NOT NULL,\n  `filename` VARCHAR(255) NOT NULL,\n  `root_path` VARCHAR(1024) NOT NULL DEFAULT \'Json/Defaults\',\n  `payload_json` LONGTEXT NOT NULL,\n  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', '  PRIMARY KEY (`profile_id`),\n  UNIQUE KEY `uq_owner_filename` (`owner_user_id`,`filename`),\n  KEY `idx_owner_name` (`owner_user_id`,`name`)'),
      DefaultTools: tableSql('DefaultTools', '  `default_tool_id` VARCHAR(128) NOT NULL,\n  `title` VARCHAR(255) NOT NULL,\n  `sort_order` INT NOT NULL DEFAULT 0,\n  `payload_json` JSON NOT NULL', '  PRIMARY KEY (`default_tool_id`)'),
      DefaultComponents: tableSql('DefaultComponents', '  `default_component_id` VARCHAR(128) NOT NULL,\n  `type_key` VARCHAR(128) NOT NULL,\n  `title` VARCHAR(255) NOT NULL,\n  `payload_json` JSON NOT NULL', '  PRIMARY KEY (`default_component_id`),\n  KEY `idx_default_type` (`type_key`)'),
      DefaultThemes: tableSql('DefaultThemes', '  `theme_key` VARCHAR(128) NOT NULL,\n  `display_name` VARCHAR(255) NOT NULL,\n  `tokens_json` JSON NOT NULL,\n  `is_default` TINYINT(1) NOT NULL DEFAULT 0', '  PRIMARY KEY (`theme_key`)'),
      AuditLog: tableSql('AuditLog', '  `audit_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,\n  `user_id` BIGINT UNSIGNED NULL,\n  `action_name` VARCHAR(128) NOT NULL,\n  `target_type` VARCHAR(64) NOT NULL DEFAULT \'\',\n  `target_id` VARCHAR(128) NOT NULL DEFAULT \'\',\n  `payload_json` JSON NULL,\n  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP', '  PRIMARY KEY (`audit_id`),\n  KEY `idx_action_time` (`action_name`,`created_at`)'),
      ServerMessages: tableSql('ServerMessages', '  `message_id` VARCHAR(128) NOT NULL,\n  `username` VARCHAR(64) NOT NULL DEFAULT \'system\',\n  `message_body` TEXT NOT NULL,\n  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP', '  PRIMARY KEY (`message_id`),\n  KEY `idx_created` (`created_at`)')
    };
    const creates = wanted.map(name => definitions[name]).filter(Boolean).join('\n\n');
    const seedStatements = [];
    if (includeSeed && wanted.includes('Users')) {
      seedStatements.push(`INSERT IGNORE INTO \`${prefixStem()}Users\` (\`username\`,\`email\`,\`password_hash\`,\`is_admin\`,\`needs_reset\`) VALUES ('admin','admin@ungodly.local','BOOTSTRAP:123',1,1);`);
    }
    if (includeSeed && wanted.includes('DefaultThemes')) {
      seedStatements.push(`INSERT IGNORE INTO \`${prefixStem()}DefaultThemes\` (\`theme_key\`,\`display_name\`,\`tokens_json\`,\`is_default\`) VALUES ('dialogue-pink','Dialogue Pink',${sqlString(JSON.stringify(DEFAULT_THEME))},1);`);
    }
    const seeds = seedStatements.length ? `\n\n${seedStatements.join('\n\n')}` : '';
    return `-- ToolDesigner generated MySQL 8+ query\n-- Prefix: ${prefixStem()}\n-- Generated: ${new Date().toISOString()}\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n${drops ? `${drops}\n` : ''}${creates}${seeds}\nSET FOREIGN_KEY_CHECKS = 1;`;
  }

  function buildComponentDefinitionTables(includeDrops) {
    return state.panelTypes.map(type => {
      const name = `${prefixStem()}Component_${sqlIdentifier(type.typeKey)}`;
      const columns = (type.fields || []).map(field => `  \`${sqlIdentifier(field.key)}\` ${field.type === 'number' ? 'DECIMAL(18,4) NULL' : field.type === 'checkbox' ? 'TINYINT(1) NOT NULL DEFAULT 0' : field.type === 'json' || field.type === 'list' ? 'JSON NULL' : field.type === 'textarea' ? 'LONGTEXT NULL' : 'VARCHAR(2048) NULL'}`);
      return `${includeDrops ? `DROP TABLE IF EXISTS \`${name}\`;\n` : ''}CREATE TABLE IF NOT EXISTS \`${name}\` (\n  \`component_id\` VARCHAR(128) NOT NULL,\n  \`tool_id\` VARCHAR(128) NOT NULL,\n${columns.length ? columns.join(',\n') + ',\n' : ''}  \`payload_json\` JSON NOT NULL,\n  \`updated_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n  PRIMARY KEY (\`component_id\`),\n  KEY \`idx_tool\` (\`tool_id\`)\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`;
    }).join('\n\n');
  }

  function downloadSql() { downloadBlob(new Blob([$('#sqlPreview').textContent], { type: 'application/sql' }), `${safeName(prefixStem().replace(/_$/, ''))}_ToolDesigner.sql`); }

  function openExportTitles() {
    const list = $('#exportTitlesList'); list.innerHTML = '';
    state.tools.forEach(tool => {
      const row = document.createElement('div'); row.className = 'topbar-editor-row';
      row.innerHTML = `<div class="field-group"><label>${esc(tool.title)}</label><input data-tool-id="${escAttr(tool.id)}" value="${escAttr(tool.exportTitle || tool.title)}"></div><div class="microcopy">${esc(safeName(tool.exportTitle || tool.title))}.json</div>`;
      $('input', row).addEventListener('input', event => { tool.exportTitle = event.target.value; $('.microcopy', row).textContent = `${safeName(tool.exportTitle || tool.title)}.json`; autoSave(); });
      list.appendChild(row);
    }); openModal('modalExportTitles');
  }

  function openHelp(key) {
    const help = {
      left: { title: 'Component Library & Shared Session', body: '<h3>Server Session</h3><p>The assigned session is collision-checked against the database. The second field accepts another session ID. Guests can move data through JSON; authenticated users can push and load server tools.</p><h3>Reusable Components</h3><p>Double-click or drag a component type into the active tool. Administrators can right-click a type or use Developer → Component Type Builder to edit its inline schema.</p>' },
      center: { title: 'Tool Canvas', body: '<h3>Tools and Components</h3><p>Each top tab is a complete tool context, such as Dialogue Designer. Cards are component instances. Their reusable definition controls the fields shown in the center.</p><h3>Universal Structure</h3><ul><li>Conditions are checked before execution.</li><li>Inline fields contain component-specific settings.</li><li>Triggers are authorized mutations applied after execution.</li><li>The gear stores tooltip, description, source, external-call flags and glow behavior.</li></ul>' },
      right: { title: 'Tools, SQL & Inspector', body: '<h3>Database Prefix</h3><p>The three fields create the default <code>Ungodly_ToolMenuEmpty_FSG_</code> prefix. The SQL builder can prepend drops, include seed defaults and generate one table for every component definition.</p><h3>Profiles</h3><p>Front-end colors, chrome, buttons, definitions, roots and global values can be exported or saved under <code>Json/Defaults</code>. Only administrators can change server root paths.</p>' }
    }[key];
    $('#helpTitle').textContent = help.title; $('#helpBody').innerHTML = help.body; openModal('modalHelp');
  }

  function renderPrefix() {
    $('#prefixProject').value = state.prefixes.project; $('#prefixTool').value = state.prefixes.tool; $('#prefixInstance').value = state.prefixes.instance; $('#prefixPreview').textContent = prefixStem();
  }

  function applyCollapsedState() {
    const left = $('#region-left'); const right = $('#region-right');
    document.documentElement.style.setProperty('--td-left-w', `${Math.max(230, Math.min(560, Number(state.leftWidth) || 302))}px`);
    document.documentElement.style.setProperty('--td-right-w', `${Math.max(240, Math.min(620, Number(state.rightWidth) || 316))}px`);
    left.classList.toggle('collapsed', state.leftCollapsed); right.classList.toggle('collapsed', state.rightCollapsed);
    const leftPin = $('[data-action="dock-left"]', left); const rightPin = $('[data-action="dock-right"]', right);
    if (leftPin) { leftPin.setAttribute('aria-expanded', String(!state.leftCollapsed)); leftPin.setAttribute('aria-label', state.leftCollapsed ? 'Open component library' : 'Collapse component library'); leftPin.dataset.tooltip = state.leftCollapsed ? 'Open component library' : 'Collapse component library'; }
    if (rightPin) { rightPin.setAttribute('aria-expanded', String(!state.rightCollapsed)); rightPin.setAttribute('aria-label', state.rightCollapsed ? 'Open tools and inspector' : 'Collapse tools and inspector'); rightPin.dataset.tooltip = state.rightCollapsed ? 'Open tools and inspector' : 'Collapse tools and inspector'; }
    $('#leftResizer')?.classList.toggle('disabled', state.leftCollapsed); $('#rightResizer')?.classList.toggle('disabled', state.rightCollapsed);
  }

  function toggleSidebar(side) {
    if (side === 'left') state.leftCollapsed = !state.leftCollapsed;
    if (side === 'right') state.rightCollapsed = !state.rightCollapsed;
    applyCollapsedState(); autoSave(`${side} sidebar ${side === 'left' ? (state.leftCollapsed ? 'collapsed' : 'opened') : (state.rightCollapsed ? 'collapsed' : 'opened')}`);
  }

  function wirePanelResizer(id, side) {
    const handle = $('#' + id); if (!handle) return;
    handle.addEventListener('pointerdown', event => {
      if ((side === 'left' && state.leftCollapsed) || (side === 'right' && state.rightCollapsed)) return;
      event.preventDefault(); handle.setPointerCapture?.(event.pointerId); document.body.classList.add('is-resizing');
      const startX = event.clientX; const startWidth = side === 'left' ? Number(state.leftWidth) : Number(state.rightWidth);
      const move = moveEvent => {
        const delta = moveEvent.clientX - startX;
        const next = side === 'left' ? startWidth + delta : startWidth - delta;
        if (side === 'left') state.leftWidth = Math.max(230, Math.min(560, next)); else state.rightWidth = Math.max(240, Math.min(620, next));
        applyCollapsedState();
      };
      const end = () => { document.body.classList.remove('is-resizing'); window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', end); autoSave(`${side} sidebar resized`); };
      window.addEventListener('pointermove', move); window.addEventListener('pointerup', end, { once: true });
    });
  }

  function renderSidebars() {
    const leftTitle = $('#region-left .chrome-title'); const rightTitle = $('#region-right .chrome-title');
    leftTitle.textContent = state.sidebarMeta.left.label || 'Component Library'; leftTitle.title = state.sidebarMeta.left.tooltip || '';
    rightTitle.textContent = state.sidebarMeta.right.label || 'Tools & Inspector'; rightTitle.title = state.sidebarMeta.right.tooltip || '';
  }

  function renderAll() {
    applyTheme(); renderTopNav(); renderTokens(); renderPanelTypes($('#librarySearch')?.value || ''); renderToolTabs(); renderToolList(); renderCanvas(); renderPrefix(); renderAuthStatus(); applyCollapsedState(); renderSidebars(); renderConsole(); updateHistoryButtons();
  }

  function closeMenus() { $$('.top-nav-item.open').forEach(item => item.classList.remove('open')); }

  function wireMenus() {
    document.addEventListener('click', closeMenus);
    [['btnSuiteMenu', 'suiteMenuWrap'], ['btnJsonMenu', 'jsonMenuWrap'], ['btnDeveloperMenu', 'developerMenuWrap']].forEach(([buttonId, wrapId]) => {
      $('#' + buttonId)?.addEventListener('click', event => { event.stopPropagation(); const wrap = $('#' + wrapId); const open = wrap.classList.contains('open'); closeMenus(); wrap.classList.toggle('open', !open); });
    });
    document.body.addEventListener('click', event => {
      const action = event.target.closest('[data-action]')?.dataset.action; if (!action) return;
      if (action === 'dock-left') toggleSidebar('left');
      if (action === 'dock-right') toggleSidebar('right');
      if (action === 'help-left') openHelp('left');
      if (action === 'help-center') openHelp('center');
      if (action === 'help-right') openHelp('right');
      if (action === 'export-workspace') exportWorkspace();
      if (action === 'export-profile') exportProfile();
      if (action === 'export-tool') exportActiveTool();
      if (action === 'export-unity') exportUnity();
      if (action === 'import-json') $('#importFileInput').click();
      if (action === 'open-export-titles') openExportTitles();
      if (action === 'open-json-library') openJsonLibrary();
      if (action === 'open-component-builder') openComponentBuilder();
      if (action === 'open-theme-studio') openProfileModal();
      if (action === 'open-definition-map') openDefinitionMap();
      if (action === 'validate-workspace') openValidation();
      if (action === 'open-history') openHistory();
      if (action === 'inspect-ui') startUiInspector();
      if (action === 'toggle-developer-mode') { state.developerMode = !state.developerMode; renderAdminState(); autoSave(); }
    });
  }

  function wire() {
    wireMenus();
    wirePanelResizer('leftResizer', 'left'); wirePanelResizer('rightResizer', 'right');
    $('#btnUndo').addEventListener('click', undo); $('#btnRedo').addEventListener('click', redo);
    $$('[data-close]').forEach(button => button.addEventListener('click', () => closeModal(button.dataset.close)));
    $$('.modal-overlay').forEach(overlay => overlay.addEventListener('click', event => { if (event.target === overlay) overlay.classList.remove('open'); }));

    $('#btnNewContext').addEventListener('click', () => createTool());
    $('#btnInitContext').addEventListener('click', () => { createTool($('#newContextName').value.trim()); $('#newContextName').value = ''; });
    $('#btnAddToken').addEventListener('click', () => { const key = $('#tokenKeyInput').value.trim().replace(/[{}]/g, ''); if (!key) return; state.globalTokens.push({ id: uid('token'), key, value: '' }); $('#tokenKeyInput').value = ''; renderTokens(); autoSave(); });
    $('#librarySearch').addEventListener('input', event => renderPanelTypes(event.target.value));
    $('#btnNewComponentType').addEventListener('click', () => openComponentBuilder());
    $('#btnCanvasSchema').addEventListener('click', openDefinitionMap);

    ['prefixProject', 'prefixTool', 'prefixInstance'].forEach(id => $('#' + id).addEventListener('input', () => {
      state.prefixes = { project: $('#prefixProject').value, tool: $('#prefixTool').value, instance: $('#prefixInstance').value }; $('#prefixPreview').textContent = prefixStem(); autoSave();
    }));

    $('#btnSessionRefresh').addEventListener('click', generateSessionId);
    $('#btnCopySession').addEventListener('click', () => copyText($('#sessionId').value));
    $('#btnPasteSession').addEventListener('click', async () => { try { $('#sessionLoadId').value = await navigator.clipboard.readText(); } catch (_) {} });
    $('#btnSessionDownload').addEventListener('click', exportActiveTool);
    $('#btnSessionUpload').addEventListener('click', () => $('#importFileInput').click());
    $('#btnSessionApply').addEventListener('click', loadSession);
    $('#btnSessionPush').addEventListener('click', pushSession);
    $('#sessionPassword').addEventListener('input', event => { state.sessionPassword = event.target.value; });

    $('#btnOpenAuth').addEventListener('click', openAuthModal); $('#btnUser').addEventListener('click', openAuthModal); $('#btnAuthSubmit').addEventListener('click', submitAuth);
    $$('[data-auth-mode]').forEach(button => button.addEventListener('click', () => { state.authMode = button.dataset.authMode; $$('[data-auth-mode]').forEach(item => item.classList.toggle('active', item === button)); renderAuthMode(); }));
    ['resetPass1', 'resetPass2'].forEach(id => $('#' + id).addEventListener('input', () => renderPasswordRequirements('pwReqs', $('#resetPass1').value, $('#resetPass2').value)));
    ['registerPass1', 'registerPass2'].forEach(id => $('#' + id).addEventListener('input', () => renderPasswordRequirements('registerPwReqs', $('#registerPass1').value, $('#registerPass2').value)));

    $('#btnInspJson').addEventListener('click', () => { const component = selectedComponent(); if (component) openComponentJson(component); });
    $('#btnInspSave').addEventListener('click', () => { const component = selectedComponent(); if (component) saveReusableComponent(component); });
    $('#btnCopyPanelJson').addEventListener('click', () => copyText($('#panelJsonEditor').value));
    $('#btnApplyPanelJson').addEventListener('click', applyJsonEditor);
    $('#btnSavePanelSettings').addEventListener('click', savePanelSettings);

    $('#btnSaveTopBar').addEventListener('click', () => { renderTopNav(); autoSave(); closeModal('modalTopBar'); });
    $('#btnAddTopBarButton').addEventListener('click', () => { state.topBarButtons.push({ id: uid('button'), buttonText: 'NEW BUTTON', linkType: 'url', url: '', imagePath: '', tooltip: '', description: '', visible: true, sortOrder: state.topBarButtons.length }); openTopBarModal(); });

    $('#btnProfileSettings').addEventListener('click', openProfileModal);
    $('#btnSaveProfileSettings').addEventListener('click', applyProfileSettings);
    $('#btnRefreshProfiles').addEventListener('click', renderServerProfiles);
    $('#btnSaveServerProfile').addEventListener('click', saveServerProfile);
    $$('[data-theme-preset]').forEach(button => button.addEventListener('click', () => { state.theme = clone(THEME_PRESETS[button.dataset.themePreset] || DEFAULT_THEME); applyTheme(); renderThemeEditor(); autoSave(); }));

    ['componentTypeKey', 'componentDisplayName', 'componentCategory', 'componentColor', 'componentTooltip', 'componentDescription', 'componentConditions', 'componentTriggers'].forEach(id => $('#' + id).addEventListener('input', updateComponentPreview));
    $('#btnAddComponentField').addEventListener('click', () => { state._componentBuilderFields.push({ key: '', label: '', type: 'text', default: '' }); renderComponentFieldRows(); updateComponentPreview(); });
    $('#btnSaveComponentType').addEventListener('click', saveComponentType); $('#btnDeleteComponentType').addEventListener('click', deleteComponentType);

    $('#btnSqlGen').addEventListener('click', openSqlModal);
    ['sqlIncludeDrop', 'sqlIncludeSeed', 'sqlIncludeComponentTables'].forEach(id => $('#' + id).addEventListener('change', refreshSqlPreview));
    $('#sqlTableChecks').addEventListener('change', refreshSqlPreview);
    $('#btnCopySql').addEventListener('click', () => copyText($('#sqlPreview').textContent)); $('#btnDownloadSql').addEventListener('click', downloadSql);

    $('#jsonLibSearch').addEventListener('input', renderJsonLibrary); $('#jsonLibKind').addEventListener('change', renderJsonLibrary);
    $('#btnSaveExportTitles').addEventListener('click', () => { closeModal('modalExportTitles'); renderToolList(); autoSave(); });

    $('#btnAdminLeft').addEventListener('click', () => openSidebarEditor('left'));
    $('#btnAdminRight').addEventListener('click', () => openSidebarEditor('right'));
    $('#btnSaveAdminSidebar').addEventListener('click', saveSidebarEditor);

    $('#btnValidateWorkspace').addEventListener('click', () => openValidation()); $('#btnOpenHistory').addEventListener('click', openHistory); $('#btnInspectUi').addEventListener('click', startUiInspector);
    $('#btnRunValidation').addEventListener('click', () => { validateWorkspace(); renderValidation(); }); $('#validationSeverity').addEventListener('change', renderValidation); $('#validationSearch').addEventListener('input', renderValidation);
    $('#btnCopyValidation').addEventListener('click', () => copyText(JSON.stringify({ version: VERSION, generatedAt: new Date().toISOString(), findings: state.validationReport }, null, 2)));
    $('#btnCreateSnapshot').addEventListener('click', createNamedSnapshot); $('#btnClearHistory').addEventListener('click', () => { state.history=[]; state.historyIndex=-1; captureHistory('History reset'); renderHistory(); });
    $('#btnApplyImport').addEventListener('click', applyPendingImport);
    $('#btnCloseUiInspector').addEventListener('click', stopUiInspector); $('#btnOpenThemeFromInspector').addEventListener('click', () => { stopUiInspector(); openProfileModal(); });
    $('#uiInspectorToken').addEventListener('change', event => { $('#uiInspectorColor').value = state.theme[event.target.value] || '#ff2f92'; });
    $('#btnApplyUiToken').addEventListener('click', () => { const token=$('#uiInspectorToken').value; state.theme[token]=$('#uiInspectorColor').value; applyTheme(); renderThemeEditor(); populateUiTokenSelect(); autoSave(`Theme token ${token} changed`); });
    document.addEventListener('mousemove', event => { if (!state.uiInspectMode) return; const target=event.target.closest('*'); if (!target || target.closest('#uiInspectorTray') || target.closest('.modal-overlay')) return; if(inspectedHover!==target){inspectedHover?.classList.remove('ui-inspect-hover');inspectedHover=target;inspectedHover.classList.add('ui-inspect-hover');} }, true);
    document.addEventListener('click', event => { if (!state.uiInspectMode) return; if (event.target.closest('#uiInspectorTray') || event.target.closest('.modal-overlay')) return; event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation(); inspectElement(event.target); }, true);

    $('#btnConsoleToggle').addEventListener('click', () => { state.consoleExpanded = !state.consoleExpanded; $('#consoleBar').classList.toggle('expanded', state.consoleExpanded); $('#btnConsoleToggle').textContent = state.consoleExpanded ? '⌃' : '⌄'; });
    $('#btnConsoleClear').addEventListener('click', () => { state.messages = []; renderConsole(); });
    $('#consoleInput').addEventListener('keydown', event => { if (event.key === 'Enter' && event.target.value.trim()) { log(event.target.value.trim()); event.target.value = ''; } });

    $('#importFileInput').addEventListener('change', event => { const file = event.target.files?.[0]; if (file) importJsonFile(file); event.target.value = ''; });

    const canvas = $('#canvasArea');
    canvas.addEventListener('dragover', event => event.preventDefault());
    canvas.addEventListener('drop', event => { const typeKey = event.dataTransfer.getData('text/tool-designer-type'); if (typeKey) { event.preventDefault(); addComponent(typeKey); } });
    $$('[data-tutorial]').forEach(button => button.addEventListener('click', () => openHelp(button.dataset.tutorial === 'component' ? 'left' : button.dataset.tutorial === 'edit' ? 'center' : 'right')));
  }

  function openSidebarEditor(side) {
    if (!isAdmin()) return alert('Administrator permission required.');
    state._sidebarSide = side; const data = state.sidebarMeta[side];
    $('#adminSidebarTitle').textContent = side === 'left' ? 'Left Sidebar Definition' : 'Right Sidebar Definition';
    $('#adminSidebarLabel').value = data.label || ''; $('#adminSidebarTooltip').value = data.tooltip || ''; $('#adminSidebarNotes').value = data.notes || ''; openModal('modalAdminSidebar');
  }

  function saveSidebarEditor() {
    const side = state._sidebarSide || 'left'; state.sidebarMeta[side] = { label: $('#adminSidebarLabel').value, tooltip: $('#adminSidebarTooltip').value, notes: $('#adminSidebarNotes').value };
    renderSidebars(); autoSave(); closeModal('modalAdminSidebar'); log(`Updated ${side} sidebar definition`, state.user?.username || 'admin');
  }

  async function boot() {
    if (!loadLocal()) seedWorkspace();
    applyTheme(); wire(); await restoreAuth(); await generateSessionId(); renderAll();
    captureHistory('Application started'); updateHistoryButtons();
    log(`ToolDesigner ${VERSION} started`, 'system');
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
