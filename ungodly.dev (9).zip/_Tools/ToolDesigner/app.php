<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

const APP_VERSION = 'ToolDesigner.2.1.0';
const TOKEN_LIFETIME_SECONDS = 43200;
const DEFAULT_JSON_ROOT = 'Json/Defaults';

$sharedAuthLoaded = false;
foreach ([__DIR__ . '/_private/AuthShared.php', dirname(__DIR__) . '/_private/AuthShared.php'] as $sharedAuthPath) {
    if (is_file($sharedAuthPath)) {
        require_once $sharedAuthPath;
        $sharedAuthLoaded = function_exists('fsgAuth_currentUserIdFromRequest');
        break;
    }
}

$dbHost = getenv('TD_DB_HOST') ?: 'localhost';
$dbPort = getenv('TD_DB_PORT') ?: '3306';
$dbUser = getenv('TD_DB_USER') ?: 'root';
$dbPass = getenv('TD_DB_PASS') ?: '';
$dbName = getenv('TD_DB_NAME') ?: 'ungodly';
$tablePrefix = getenv('TD_TABLE_PREFIX') ?: 'Ungodly_ToolMenuEmpty_FSG_';

function respond(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function requestBody(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function db(): PDO
{
    global $dbHost, $dbPort, $dbUser, $dbPass, $dbName;
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4";
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}

function tableName(string $suffix): string
{
    global $tablePrefix;
    $prefix = preg_replace('/[^A-Za-z0-9_]/', '', $tablePrefix) ?: 'Ungodly_ToolMenuEmpty_FSG_';
    if (!str_ends_with($prefix, '_')) {
        $prefix .= '_';
    }
    return $prefix . preg_replace('/[^A-Za-z0-9_]/', '', $suffix);
}

function jsonEncode(mixed $value): string
{
    $encoded = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($encoded === false) {
        throw new RuntimeException('Could not encode JSON payload.');
    }
    return $encoded;
}

function bearerToken(): string
{
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/^Bearer\s+(.+)$/i', trim($header), $match)) {
        return trim($match[1]);
    }
    return '';
}

function randomToken(int $bytes = 32): string
{
    return rtrim(strtr(base64_encode(random_bytes($bytes)), '+/', '-_'), '=');
}

function tokenHash(string $token): string
{
    return hash('sha256', $token);
}

function userPublic(array $row): array
{
    return [
        'id' => (int)$row['id'],
        'username' => (string)$row['username'],
        'email' => (string)($row['email'] ?? ''),
        'isAdmin' => (int)$row['is_admin'] === 1,
    ];
}

function bootstrap(PDO $pdo): void
{
    global $sharedAuthLoaded;
    if ($sharedAuthLoaded && function_exists('fsgAuth_ensureAccountTables')) { fsgAuth_ensureAccountTables($pdo); }
    $users = tableName('Users');
    $tokens = tableName('AuthTokens');
    $sessions = tableName('Sessions');
    $tools = tableName('Tools');
    $profiles = tableName('Profiles');
    $audit = tableName('AuditLog');

    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$users}` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `username` VARCHAR(64) NOT NULL,
        `email` VARCHAR(255) NOT NULL DEFAULT '',
        `password_hash` VARCHAR(255) NOT NULL,
        `is_admin` TINYINT(1) NOT NULL DEFAULT 0,
        `is_active` TINYINT(1) NOT NULL DEFAULT 1,
        `needs_reset` TINYINT(1) NOT NULL DEFAULT 0,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uq_username` (`username`),
        UNIQUE KEY `uq_email` (`email`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tokens}` (
        `token_hash` CHAR(64) NOT NULL,
        `user_id` BIGINT UNSIGNED NOT NULL,
        `scope` ENUM('bootstrap','user') NOT NULL DEFAULT 'user',
        `expires_at` DATETIME NOT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `last_seen_at` TIMESTAMP NULL,
        PRIMARY KEY (`token_hash`),
        KEY `idx_user_expiry` (`user_id`,`expires_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$sessions}` (
        `session_id` VARCHAR(96) NOT NULL,
        `owner_user_id` BIGINT UNSIGNED NULL,
        `password_hash` VARCHAR(255) NULL,
        `expires_at` DATETIME NOT NULL,
        `is_active` TINYINT(1) NOT NULL DEFAULT 1,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`session_id`),
        KEY `idx_owner` (`owner_user_id`),
        KEY `idx_expiry` (`expires_at`,`is_active`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tools}` (
        `tool_id` VARCHAR(128) NOT NULL,
        `session_id` VARCHAR(96) NOT NULL,
        `owner_user_id` BIGINT UNSIGNED NOT NULL,
        `title` VARCHAR(255) NOT NULL,
        `export_title` VARCHAR(255) NOT NULL DEFAULT '',
        `identity_color` VARCHAR(16) NOT NULL DEFAULT '#ff2f92',
        `tool_json` LONGTEXT NOT NULL,
        `profile_json` LONGTEXT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`tool_id`),
        UNIQUE KEY `uq_session_tool` (`session_id`,`tool_id`),
        KEY `idx_session_latest` (`session_id`,`updated_at`),
        KEY `idx_owner_latest` (`owner_user_id`,`updated_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$profiles}` (
        `profile_id` VARCHAR(128) NOT NULL,
        `owner_user_id` BIGINT UNSIGNED NOT NULL,
        `name` VARCHAR(255) NOT NULL,
        `filename` VARCHAR(255) NOT NULL,
        `root_path` VARCHAR(1024) NOT NULL DEFAULT 'Json/Defaults',
        `payload_json` LONGTEXT NOT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`profile_id`),
        UNIQUE KEY `uq_owner_filename` (`owner_user_id`,`filename`),
        KEY `idx_owner_name` (`owner_user_id`,`name`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$audit}` (
        `audit_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id` BIGINT UNSIGNED NULL,
        `action_name` VARCHAR(128) NOT NULL,
        `target_type` VARCHAR(64) NOT NULL DEFAULT '',
        `target_id` VARCHAR(128) NOT NULL DEFAULT '',
        `payload_json` LONGTEXT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`audit_id`),
        KEY `idx_action_time` (`action_name`,`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $count = (int)$pdo->query("SELECT COUNT(*) FROM `{$users}`")->fetchColumn();
    if ($count === 0) {
        $statement = $pdo->prepare("INSERT INTO `{$users}` (`username`,`email`,`password_hash`,`is_admin`,`needs_reset`) VALUES (?,?,?,?,?)");
        $statement->execute(['admin', 'admin@ungodly.local', 'BOOTSTRAP:123', 1, 1]);
    }
}

function issueToken(PDO $pdo, int $userId, string $scope = 'user'): string
{
    $plain = randomToken();
    $hash = tokenHash($plain);
    $expires = gmdate('Y-m-d H:i:s', time() + TOKEN_LIFETIME_SECONDS);
    $table = tableName('AuthTokens');
    $statement = $pdo->prepare("INSERT INTO `{$table}` (`token_hash`,`user_id`,`scope`,`expires_at`,`last_seen_at`) VALUES (?,?,?,?,UTC_TIMESTAMP())");
    $statement->execute([$hash, $userId, $scope, $expires]);
    return $plain;
}

function currentUser(PDO $pdo, bool $required = false, string $requiredScope = 'user'): ?array
{
    global $sharedAuthLoaded;
    if ($sharedAuthLoaded && function_exists('fsgAuth_currentUserIdFromRequest')) {
        try {
            $sharedId = fsgAuth_currentUserIdFromRequest($pdo);
            if ($sharedId > 0) {
                $statement = $pdo->prepare('SELECT id, username, email, is_admin, is_active FROM FSG_users WHERE id=? AND is_active=1 LIMIT 1');
                $statement->execute([$sharedId]);
                $shared = $statement->fetch();
                if ($shared) return $shared;
            }
        } catch (Throwable $ignored) {}
    }
    $plain = bearerToken();
    if ($plain === '') {
        if ($required) {
            respond(['ok' => false, 'error' => 'Authentication required.'], 401);
        }
        return null;
    }
    $tokens = tableName('AuthTokens');
    $users = tableName('Users');
    $statement = $pdo->prepare("SELECT u.*, t.scope, t.token_hash FROM `{$tokens}` t JOIN `{$users}` u ON u.id=t.user_id WHERE t.token_hash=? AND t.expires_at>UTC_TIMESTAMP() AND u.is_active=1 LIMIT 1");
    $statement->execute([tokenHash($plain)]);
    $row = $statement->fetch();
    if (!$row || ($requiredScope !== '' && $row['scope'] !== $requiredScope)) {
        if ($required) {
            respond(['ok' => false, 'error' => 'Authentication token is invalid or expired.'], 401);
        }
        return null;
    }
    $touch = $pdo->prepare("UPDATE `{$tokens}` SET `last_seen_at`=UTC_TIMESTAMP() WHERE `token_hash`=?");
    $touch->execute([$row['token_hash']]);
    return $row;
}

function requireAdmin(array $user): void
{
    if ((int)$user['is_admin'] !== 1) {
        respond(['ok' => false, 'error' => 'Administrator permission required.'], 403);
    }
}

function validPassword(string $password): bool
{
    $length = strlen($password);
    return $length >= 8 && $length <= 28
        && preg_match('/[A-Z]/', $password)
        && preg_match('/[a-z]/', $password)
        && preg_match('/\d/', $password)
        && preg_match('/[^A-Za-z0-9]/', $password);
}

function findUser(PDO $pdo, string $username): ?array
{
    $table = tableName('Users');
    $statement = $pdo->prepare("SELECT * FROM `{$table}` WHERE `username`=? AND `is_active`=1 LIMIT 1");
    $statement->execute([$username]);
    $row = $statement->fetch();
    return $row ?: null;
}

function audit(PDO $pdo, ?int $userId, string $action, string $targetType = '', string $targetId = '', mixed $payload = null): void
{
    $table = tableName('AuditLog');
    $statement = $pdo->prepare("INSERT INTO `{$table}` (`user_id`,`action_name`,`target_type`,`target_id`,`payload_json`) VALUES (?,?,?,?,?)");
    $statement->execute([$userId, $action, $targetType, $targetId, $payload === null ? null : jsonEncode($payload)]);
}

function sanitizeSessionId(string $value): string
{
    return substr(preg_replace('/[^A-Za-z0-9_-]/', '', $value) ?: '', 0, 96);
}

function profileFilename(string $name): string
{
    $base = preg_replace('/[^A-Za-z0-9_.-]+/', '_', trim($name)) ?: 'ToolDesigner_Profile';
    $base = trim($base, '._-');
    return ($base !== '' ? $base : 'ToolDesigner_Profile') . '.json';
}

function safeRoot(string $requested, bool $allowCustom): array
{
    $root = $allowCustom ? $requested : DEFAULT_JSON_ROOT;
    $root = str_replace('\\', '/', trim($root));
    $root = trim($root, '/');
    $root = preg_replace('#/+#', '/', $root) ?: DEFAULT_JSON_ROOT;
    if ($root === '' || str_contains($root, '..') || !preg_match('#^[A-Za-z0-9_./-]+$#', $root)) {
        $root = DEFAULT_JSON_ROOT;
    }
    $absolute = __DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $root);
    $base = realpath(__DIR__);
    if ($base === false) {
        throw new RuntimeException('Application root could not be resolved.');
    }
    if (!is_dir($absolute) && !mkdir($absolute, 0775, true) && !is_dir($absolute)) {
        throw new RuntimeException('Profile directory could not be created.');
    }
    $resolved = realpath($absolute);
    if ($resolved === false || !str_starts_with($resolved, $base)) {
        throw new RuntimeException('Profile path must remain inside the application folder.');
    }
    return [$root, $resolved];
}

$action = (string)($_GET['action'] ?? '');
$data = requestBody();
if ($action === '' && isset($data['action'])) {
    $action = (string)$data['action'];
}

try {
    $pdo = db();
    bootstrap($pdo);

    if ($action === 'health') {
        respond(['ok' => true, 'version' => APP_VERSION, 'database' => 'connected']);
    }

    if ($action === 'login') {
        $username = trim((string)($data['username'] ?? ''));
        $password = (string)($data['password'] ?? '');
        $user = findUser($pdo, $username);
        if (!$user) {
            if ($sharedAuthLoaded && function_exists('fsgAuth_loginAccount')) {
                $sharedPayload = fsgAuth_loginAccount($pdo, ['identity' => $username, 'password' => $password, 'browserLabel' => (string)($data['browserLabel'] ?? '')]);
                $sharedId = (int)($sharedPayload['user']['id'] ?? 0);
                $sharedStmt = $pdo->prepare('SELECT id, username, email, is_admin FROM FSG_users WHERE id=? LIMIT 1'); $sharedStmt->execute([$sharedId]); $sharedUser = $sharedStmt->fetch();
                respond(['ok' => true, 'token' => $sharedPayload['authToken'] ?? '', 'authToken' => $sharedPayload['authToken'] ?? '', 'user' => userPublic($sharedUser ?: ['id'=>$sharedId,'username'=>$username,'email'=>'','is_admin'=>0])]);
            }
            respond(['ok' => false, 'error' => 'Invalid credentials.'], 401);
        }
        $needsReset = (int)$user['needs_reset'] === 1;
        $valid = $needsReset
            ? hash_equals('BOOTSTRAP:123', (string)$user['password_hash']) && hash_equals('123', $password)
            : password_verify($password, (string)$user['password_hash']);
        if (!$valid) {
            if ($sharedAuthLoaded && function_exists('fsgAuth_loginAccount')) {
                $sharedPayload = fsgAuth_loginAccount($pdo, ['identity' => $username, 'password' => $password, 'browserLabel' => (string)($data['browserLabel'] ?? '')]);
                $sharedId = (int)($sharedPayload['user']['id'] ?? 0);
                $sharedStmt = $pdo->prepare('SELECT id, username, email, is_admin FROM FSG_users WHERE id=? LIMIT 1');
                $sharedStmt->execute([$sharedId]);
                $sharedUser = $sharedStmt->fetch();
                respond(['ok' => true, 'token' => $sharedPayload['authToken'] ?? '', 'authToken' => $sharedPayload['authToken'] ?? '', 'user' => userPublic($sharedUser ?: ['id'=>$sharedId,'username'=>$username,'email'=>'','is_admin'=>0])]);
            }
            respond(['ok' => false, 'error' => 'Invalid credentials.'], 401);
        }
        if ($needsReset) {
            $bootstrapToken = issueToken($pdo, (int)$user['id'], 'bootstrap');
            respond(['ok' => true, 'needsReset' => true, 'bootstrapToken' => $bootstrapToken, 'user' => userPublic($user)]);
        }
        $token = issueToken($pdo, (int)$user['id']);
        $publicUser = userPublic($user);
        if ($sharedAuthLoaded && function_exists('fsgAuth_issueAuthToken')) {
            try {
                $sharedStmt = $pdo->prepare('SELECT id, username, email, password, is_admin FROM FSG_users WHERE LOWER(username)=LOWER(?) AND is_active=1 LIMIT 1');
                $sharedStmt->execute([$username]);
                $sharedUser = $sharedStmt->fetch();
                if ($sharedUser && (int)($sharedUser['is_admin'] ?? 0) === 1 && password_verify($password, (string)$sharedUser['password'])) {
                    $token = fsgAuth_issueAuthToken($pdo, (int)$sharedUser['id'], (string)($data['browserLabel'] ?? 'ToolDesigner'));
                    $publicUser = userPublic($sharedUser);
                }
            } catch (Throwable $ignored) {}
        }
        audit($pdo, (int)$user['id'], 'login', 'user', (string)$user['id']);
        respond(['ok' => true, 'needsReset' => false, 'token' => $token, 'authToken' => $token, 'user' => $publicUser]);
    }

    if ($action === 'resetBootstrap') {
        $bootstrapToken = (string)($data['bootstrapToken'] ?? '');
        $tokens = tableName('AuthTokens');
        $users = tableName('Users');
        $statement = $pdo->prepare("SELECT u.*, t.token_hash FROM `{$tokens}` t JOIN `{$users}` u ON u.id=t.user_id WHERE t.token_hash=? AND t.scope='bootstrap' AND t.expires_at>UTC_TIMESTAMP() AND u.needs_reset=1 LIMIT 1");
        $statement->execute([tokenHash($bootstrapToken)]);
        $user = $statement->fetch();
        if (!$user) {
            respond(['ok' => false, 'error' => 'Bootstrap authorization expired. Log in with admin / 123 again.'], 401);
        }
        $username = trim((string)($data['username'] ?? '')) ?: (string)$user['username'];
        $password = (string)($data['password'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_.-]{3,64}$/', $username)) {
            respond(['ok' => false, 'error' => 'Username must be 3–64 letters, numbers, dots, underscores or dashes.'], 400);
        }
        if (!validPassword($password)) {
            respond(['ok' => false, 'error' => 'Password must be 8–28 characters with upper, lower, number and special character.'], 400);
        }
        $check = $pdo->prepare("SELECT id FROM `{$users}` WHERE username=? AND id<>? LIMIT 1");
        $check->execute([$username, $user['id']]);
        if ($check->fetch()) {
            respond(['ok' => false, 'error' => 'That username is already in use.'], 409);
        }
        $update = $pdo->prepare("UPDATE `{$users}` SET username=?, password_hash=?, needs_reset=0, is_admin=1 WHERE id=?");
        $update->execute([$username, password_hash($password, PASSWORD_DEFAULT), $user['id']]);
        $delete = $pdo->prepare("DELETE FROM `{$tokens}` WHERE user_id=? AND scope='bootstrap'");
        $delete->execute([$user['id']]);
        $user['username'] = $username;
        $user['needs_reset'] = 0;
        $user['is_admin'] = 1;
        $token = issueToken($pdo, (int)$user['id']);
        $publicUser = userPublic($user);
        if ($sharedAuthLoaded && function_exists('fsgAuth_issueAuthToken')) {
            try {
                $sharedEmail = strtolower($username) . '@ungodly.local';
                $sharedLookup = $pdo->prepare('SELECT id, username, email, password, is_admin FROM FSG_users WHERE LOWER(username)=LOWER(?) OR LOWER(email)=LOWER(?) LIMIT 1');
                $sharedLookup->execute([$username, $sharedEmail]);
                $sharedUser = $sharedLookup->fetch();
                if (!$sharedUser) {
                    $sharedInsert = $pdo->prepare('INSERT INTO FSG_users (username,email,password,is_over_18,agreed_terms,agreed_privacy,is_active,is_admin) VALUES (?,?,?,1,1,1,1,1)');
                    $sharedInsert->execute([$username, $sharedEmail, password_hash($password, PASSWORD_DEFAULT)]);
                    $sharedUser = ['id'=>(int)$pdo->lastInsertId(),'username'=>$username,'email'=>$sharedEmail,'is_admin'=>1];
                } elseif ((int)($sharedUser['is_admin'] ?? 0) === 1) {
                    $sharedUpdate = $pdo->prepare('UPDATE FSG_users SET password=?, is_active=1 WHERE id=?');
                    $sharedUpdate->execute([password_hash($password, PASSWORD_DEFAULT), $sharedUser['id']]);
                } else {
                    $sharedUser = null;
                }
                if ($sharedUser) {
                    $token = fsgAuth_issueAuthToken($pdo, (int)$sharedUser['id'], 'ToolDesigner bootstrap administrator');
                    $publicUser = userPublic($sharedUser);
                }
            } catch (Throwable $ignored) {}
        }
        audit($pdo, (int)$user['id'], 'bootstrap_reset', 'user', (string)$user['id']);
        respond(['ok' => true, 'token' => $token, 'authToken' => $token, 'user' => $publicUser]);
    }

    if ($action === 'register') {
        if ($sharedAuthLoaded && function_exists('fsgAuth_registerAccount')) {
            $sharedPayload = fsgAuth_registerAccount($pdo, [
                'username' => (string)($data['username'] ?? ''), 'email' => (string)($data['email'] ?? ''),
                'password' => (string)($data['password'] ?? ''), 'passwordConfirm' => (string)($data['passwordConfirm'] ?? ''),
                'over18' => (bool)($data['over18'] ?? false), 'terms' => (bool)($data['terms'] ?? false), 'privacy' => (bool)($data['privacy'] ?? false),
                'browserLabel' => (string)($data['browserLabel'] ?? '')
            ]);
            $sharedId = (int)($sharedPayload['user']['id'] ?? 0);
            $sharedStmt = $pdo->prepare('SELECT id, username, email, is_admin FROM FSG_users WHERE id=? LIMIT 1'); $sharedStmt->execute([$sharedId]); $sharedUser = $sharedStmt->fetch();
            respond(['ok' => true, 'token' => $sharedPayload['authToken'] ?? '', 'authToken' => $sharedPayload['authToken'] ?? '', 'user' => userPublic($sharedUser ?: ['id'=>$sharedId,'username'=>(string)($data['username'] ?? ''),'email'=>(string)($data['email'] ?? ''),'is_admin'=>0])]);
        }
        $username = trim((string)($data['username'] ?? ''));
        $email = trim((string)($data['email'] ?? ''));
        $password = (string)($data['password'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_.-]{3,64}$/', $username)) {
            respond(['ok' => false, 'error' => 'Username must be 3–64 letters, numbers, dots, underscores or dashes.'], 400);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            respond(['ok' => false, 'error' => 'A valid email address is required.'], 400);
        }
        if (!validPassword($password)) {
            respond(['ok' => false, 'error' => 'Password must be 8–28 characters with upper, lower, number and special character.'], 400);
        }
        $users = tableName('Users');
        $statement = $pdo->prepare("INSERT INTO `{$users}` (`username`,`email`,`password_hash`,`is_admin`,`needs_reset`) VALUES (?,?,?,0,0)");
        try {
            $statement->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT)]);
        } catch (PDOException $error) {
            if ((int)$error->errorInfo[1] === 1062) {
                respond(['ok' => false, 'error' => 'Username or email already exists.'], 409);
            }
            throw $error;
        }
        $id = (int)$pdo->lastInsertId();
        $user = findUser($pdo, $username);
        $token = issueToken($pdo, $id);
        audit($pdo, $id, 'register', 'user', (string)$id);
        respond(['ok' => true, 'token' => $token, 'user' => userPublic($user ?: ['id' => $id, 'username' => $username, 'email' => $email, 'is_admin' => 0])]);
    }

    if ($action === 'whoami') {
        $user = currentUser($pdo, true, '');
        respond(['ok' => true, 'user' => userPublic($user)]);
    }

    if ($action === 'logout') {
        if ($sharedAuthLoaded && function_exists('fsgAuth_logout')) { try { fsgAuth_logout($pdo); } catch (Throwable $ignored) {} }
        $plain = bearerToken();
        if ($plain !== '') { try { $tokens = tableName('AuthTokens'); $statement = $pdo->prepare("DELETE FROM `{$tokens}` WHERE token_hash=?"); $statement->execute([tokenHash($plain)]); } catch (Throwable $ignored) {} }
        respond(['ok' => true]);
    }

    if ($action === 'generateSessionId') {
        $sessions = tableName('Sessions');
        for ($attempt = 0; $attempt < 40; $attempt++) {
            $sessionId = 'TD-' . strtoupper(bin2hex(random_bytes(3))) . '-' . strtoupper(bin2hex(random_bytes(5)));
            $collision = false;
            foreach ([$sessions, 'FSG_Server_Sessions', 'FSG_DD_Workspaces', 'FSG_PD_server_sessions', 'FSG_NF_server_sessions', 'FSG_TASK_server_sessions'] as $table) {
                try {
                    $quoted = '`' . str_replace('`', '``', $table) . '`';
                    $statement = $pdo->prepare("SELECT session_id FROM {$quoted} WHERE session_id=? LIMIT 1");
                    $statement->execute([$sessionId]);
                    if ($statement->fetch()) { $collision = true; break; }
                } catch (Throwable $ignored) {}
            }
            if (!$collision) respond(['ok' => true, 'sessionId' => $sessionId]);
        }
        respond(['ok' => true, 'sessionId' => 'TD-' . strtoupper(bin2hex(random_bytes(4))) . '-' . strtoupper(bin2hex(random_bytes(6)))]);
    }

    if ($action === 'saveTool') {
        $user = currentUser($pdo, true);
        $sessionId = sanitizeSessionId((string)($data['sessionId'] ?? ''));
        $password = (string)($data['password'] ?? '');
        $tool = $data['tool'] ?? null;
        $profile = $data['profile'] ?? null;
        if ($sessionId === '' || !is_array($tool)) {
            respond(['ok' => false, 'error' => 'A valid session and tool payload are required.'], 400);
        }
        $sessions = tableName('Sessions');
        $tools = tableName('Tools');
        $pdo->beginTransaction();
        $statement = $pdo->prepare("SELECT * FROM `{$sessions}` WHERE session_id=? LIMIT 1 FOR UPDATE");
        $statement->execute([$sessionId]);
        $session = $statement->fetch();
        $expiry = gmdate('Y-m-d H:i:s', time() + TOKEN_LIFETIME_SECONDS);
        if ($session) {
            if ($session['owner_user_id'] !== null && (int)$session['owner_user_id'] !== (int)$user['id'] && (int)$user['is_admin'] !== 1) {
                $pdo->rollBack();
                respond(['ok' => false, 'error' => 'This session belongs to another account.'], 403);
            }
            $hash = $password !== '' ? password_hash($password, PASSWORD_DEFAULT) : $session['password_hash'];
            $update = $pdo->prepare("UPDATE `{$sessions}` SET owner_user_id=?, password_hash=?, expires_at=?, is_active=1 WHERE session_id=?");
            $update->execute([$user['id'], $hash, $expiry, $sessionId]);
        } else {
            $insert = $pdo->prepare("INSERT INTO `{$sessions}` (`session_id`,`owner_user_id`,`password_hash`,`expires_at`,`is_active`) VALUES (?,?,?,?,1)");
            $insert->execute([$sessionId, $user['id'], $password !== '' ? password_hash($password, PASSWORD_DEFAULT) : null, $expiry]);
        }
        $toolId = substr(preg_replace('/[^A-Za-z0-9_-]/', '', (string)($tool['id'] ?? '')) ?: bin2hex(random_bytes(16)), 0, 128);
        $title = substr((string)($tool['title'] ?? 'Untitled Tool'), 0, 255);
        $exportTitle = substr((string)($tool['exportTitle'] ?? $title), 0, 255);
        $color = substr((string)($tool['color'] ?? '#ff2f92'), 0, 16);
        $toolJson = jsonEncode($tool);
        $profileJson = is_array($profile) ? jsonEncode($profile) : null;
        $upsert = $pdo->prepare("INSERT INTO `{$tools}` (`tool_id`,`session_id`,`owner_user_id`,`title`,`export_title`,`identity_color`,`tool_json`,`profile_json`) VALUES (?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE session_id=VALUES(session_id), owner_user_id=VALUES(owner_user_id), title=VALUES(title), export_title=VALUES(export_title), identity_color=VALUES(identity_color), tool_json=VALUES(tool_json), profile_json=VALUES(profile_json)");
        $upsert->execute([$toolId, $sessionId, $user['id'], $title, $exportTitle, $color, $toolJson, $profileJson]);
        $pdo->commit();
        audit($pdo, (int)$user['id'], 'save_tool', 'tool', $toolId, ['sessionId' => $sessionId, 'title' => $title]);
        if ($sharedAuthLoaded && function_exists('fsgAuth_touchServerSession')) { try { fsgAuth_touchServerSession($pdo, (int)$user['id'], 'ToolDesigner', $sessionId, 'push'); } catch (Throwable $ignored) {} }
        respond(['ok' => true, 'sessionId' => $sessionId, 'toolId' => $toolId, 'expiresAt' => $expiry]);
    }

    if ($action === 'loadTool') {
        $viewer = currentUser($pdo, false);
        $sessionId = sanitizeSessionId((string)($data['sessionId'] ?? ''));
        $password = (string)($data['password'] ?? '');
        if ($sessionId === '') {
            respond(['ok' => false, 'error' => 'Session ID is required.'], 400);
        }
        $sessions = tableName('Sessions');
        $tools = tableName('Tools');
        $statement = $pdo->prepare("SELECT * FROM `{$sessions}` WHERE session_id=? AND is_active=1 AND expires_at>UTC_TIMESTAMP() LIMIT 1");
        $statement->execute([$sessionId]);
        $session = $statement->fetch();
        if (!$session) {
            respond(['ok' => false, 'error' => 'Session was not found or has expired.'], 404);
        }
        $owns = $viewer && ((int)$viewer['id'] === (int)$session['owner_user_id'] || (int)$viewer['is_admin'] === 1);
        if (!$owns && $session['password_hash'] !== null && !password_verify($password, (string)$session['password_hash'])) {
            respond(['ok' => false, 'error' => 'Session password is incorrect.'], 403);
        }
        $statement = $pdo->prepare("SELECT tool_json, profile_json FROM `{$tools}` WHERE session_id=? ORDER BY updated_at DESC LIMIT 1");
        $statement->execute([$sessionId]);
        $row = $statement->fetch();
        if (!$row) {
            respond(['ok' => false, 'error' => 'No tool has been saved to this session.'], 404);
        }
        if ($viewer && $sharedAuthLoaded && function_exists('fsgAuth_touchServerSession')) { try { fsgAuth_touchServerSession($pdo, (int)$viewer['id'], 'ToolDesigner', $sessionId, 'view'); } catch (Throwable $ignored) {} }
        respond(['ok' => true, 'tool' => json_decode((string)$row['tool_json'], true), 'profile' => $row['profile_json'] ? json_decode((string)$row['profile_json'], true) : null]);
    }

    if ($action === 'listProfiles') {
        $user = currentUser($pdo, false);
        $allowCustom = $user && (int)$user['is_admin'] === 1;
        [$root, $directory] = safeRoot((string)($data['root'] ?? DEFAULT_JSON_ROOT), $allowCustom);
        $files = glob($directory . DIRECTORY_SEPARATOR . '*.json') ?: [];
        $profiles = [];
        foreach ($files as $file) {
            $contents = file_get_contents($file);
            $decoded = is_string($contents) ? json_decode($contents, true) : null;
            if (!is_array($decoded)) {
                continue;
            }
            $profiles[] = [
                'name' => (string)($decoded['profileName'] ?? pathinfo($file, PATHINFO_FILENAME)),
                'filename' => basename($file),
                'modifiedAt' => gmdate(DATE_ATOM, (int)filemtime($file)),
                'preview' => $decoded,
            ];
        }
        usort($profiles, fn(array $a, array $b): int => strcmp($b['modifiedAt'], $a['modifiedAt']));
        respond(['ok' => true, 'root' => $root, 'profiles' => $profiles]);
    }

    if ($action === 'saveProfile') {
        $user = currentUser($pdo, true);
        $allowCustom = (int)$user['is_admin'] === 1;
        [$root, $directory] = safeRoot((string)($data['root'] ?? DEFAULT_JSON_ROOT), $allowCustom);
        $name = trim((string)($data['profileName'] ?? 'ToolDesigner Default')) ?: 'ToolDesigner Default';
        $profile = $data['profile'] ?? null;
        if (!is_array($profile)) {
            respond(['ok' => false, 'error' => 'Profile JSON is required.'], 400);
        }
        $profile['profileName'] = $name;
        $profile['savedAt'] = gmdate(DATE_ATOM);
        $filename = profileFilename($name);
        $path = $directory . DIRECTORY_SEPARATOR . $filename;
        $json = jsonEncode($profile);
        if (file_put_contents($path, $json . PHP_EOL, LOCK_EX) === false) {
            throw new RuntimeException('Profile file could not be written.');
        }
        $profiles = tableName('Profiles');
        $profileId = hash('sha256', $user['id'] . '|' . $root . '|' . $filename);
        $statement = $pdo->prepare("INSERT INTO `{$profiles}` (`profile_id`,`owner_user_id`,`name`,`filename`,`root_path`,`payload_json`) VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name), root_path=VALUES(root_path), payload_json=VALUES(payload_json)");
        $statement->execute([$profileId, $user['id'], $name, $filename, $root, $json]);
        audit($pdo, (int)$user['id'], 'save_profile', 'profile', $profileId, ['root' => $root, 'filename' => $filename]);
        respond(['ok' => true, 'root' => $root, 'filename' => $filename]);
    }

    if ($action === 'loadProfile') {
        $user = currentUser($pdo, false);
        $allowCustom = $user && (int)$user['is_admin'] === 1;
        [, $directory] = safeRoot((string)($data['root'] ?? DEFAULT_JSON_ROOT), $allowCustom);
        $filename = basename((string)($data['filename'] ?? ''));
        if (!preg_match('/^[A-Za-z0-9_.-]+\.json$/', $filename)) {
            respond(['ok' => false, 'error' => 'Invalid profile filename.'], 400);
        }
        $path = $directory . DIRECTORY_SEPARATOR . $filename;
        if (!is_file($path)) {
            respond(['ok' => false, 'error' => 'Profile file was not found.'], 404);
        }
        $profile = json_decode((string)file_get_contents($path), true);
        if (!is_array($profile)) {
            respond(['ok' => false, 'error' => 'Profile file does not contain valid JSON.'], 500);
        }
        respond(['ok' => true, 'profile' => $profile]);
    }

    respond(['ok' => false, 'error' => 'Unknown action.'], 404);
} catch (Throwable $error) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    respond(['ok' => false, 'error' => $error->getMessage()], 500);
}
