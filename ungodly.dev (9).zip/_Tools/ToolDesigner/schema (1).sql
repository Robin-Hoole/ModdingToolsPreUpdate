-- =============================================================================
-- ToolDesigner Schema
-- Prefix system: ProjectPrefix_ToolPrefix_InstanceName_
-- Defaults: Ungodly_ToolMenuEmpty_FSG_
-- Generated for the meta-authoring engine of the Ungodly suite.
-- =============================================================================

-- Optional: uncomment the DROP block when you want a clean reset.
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_TopBarButtons`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_Panels`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_Contexts`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_Sessions`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_Profiles`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_DefaultPanelTypes`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_DefaultContexts`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_DefaultThemes`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_Users`;

-- ---------------------------------------------------------------------------
-- Runtime family
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_Users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(64) NOT NULL,
  `email` VARCHAR(255) NOT NULL DEFAULT '',
  `password_hash` VARCHAR(255) NOT NULL,
  `is_admin` TINYINT(1) NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `needs_reset` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_Sessions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `session_id` VARCHAR(96) NOT NULL,
  `owner_user_id` INT UNSIGNED NULL DEFAULT NULL,
  `password_hash` VARCHAR(255) NULL DEFAULT NULL,
  `browser_label` VARCHAR(128) NOT NULL DEFAULT '',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` DATETIME NOT NULL,
  `last_seen_at` DATETIME NULL DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_session_id` (`session_id`),
  KEY `idx_owner` (`owner_user_id`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_Contexts` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `context_uuid` CHAR(36) NOT NULL,
  `session_id` VARCHAR(96) NOT NULL DEFAULT '',
  `owner_user_id` INT UNSIGNED NULL DEFAULT NULL,
  `title` VARCHAR(255) NOT NULL DEFAULT 'Untitled Context',
  `color` VARCHAR(16) NOT NULL DEFAULT '#ff007f',
  `sort_order` INT NOT NULL DEFAULT 0,
  `raw_json` LONGTEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_context_uuid` (`context_uuid`),
  KEY `idx_session` (`session_id`),
  KEY `idx_owner` (`owner_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_Panels` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `panel_uuid` CHAR(36) NOT NULL,
  `context_id` BIGINT UNSIGNED NOT NULL,
  `panel_type` VARCHAR(64) NOT NULL,
  `title` VARCHAR(255) NOT NULL DEFAULT '',
  `identity_color` VARCHAR(16) NOT NULL DEFAULT '#ff007f',
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_collapsed` TINYINT(1) NOT NULL DEFAULT 0,
  `called_externally` TINYINT(1) NOT NULL DEFAULT 0,
  `make_external_call` TINYINT(1) NOT NULL DEFAULT 0,
  `tooltip` VARCHAR(512) NOT NULL DEFAULT '',
  `description` TEXT NULL,
  `conditions_json` JSON NULL,
  `triggers_json` JSON NULL,
  `payload_json` JSON NULL,
  `raw_json` LONGTEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_panel_uuid` (`panel_uuid`),
  KEY `idx_context` (`context_id`),
  KEY `idx_type` (`panel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_Profiles` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `profile_uuid` CHAR(36) NOT NULL,
  `name` VARCHAR(128) NOT NULL DEFAULT 'Default Profile',
  `owner_user_id` INT UNSIGNED NULL DEFAULT NULL,
  `is_default` TINYINT(1) NOT NULL DEFAULT 0,
  `theme_tokens_json` JSON NULL,
  `chrome_json` JSON NULL,
  `prefixes_json` JSON NULL,
  `top_bar_buttons_json` JSON NULL,
  `json_root_path` VARCHAR(512) NOT NULL DEFAULT 'Json/Defaults',
  `raw_json` LONGTEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_profile_uuid` (`profile_uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_TopBarButtons` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `button_uuid` CHAR(36) NOT NULL,
  `button_text` VARCHAR(128) NOT NULL,
  `link_type` ENUM('url','image') NOT NULL DEFAULT 'url',
  `url` VARCHAR(1024) NOT NULL DEFAULT '',
  `image_path` VARCHAR(512) NOT NULL DEFAULT '',
  `tooltip` VARCHAR(512) NOT NULL DEFAULT '',
  `description` TEXT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `visible` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_button_uuid` (`button_uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Defaults family (admin seed)
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_DefaultPanelTypes` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `type_key` VARCHAR(64) NOT NULL,
  `display_name` VARCHAR(128) NOT NULL,
  `category` VARCHAR(64) NOT NULL DEFAULT 'General',
  `default_color` VARCHAR(16) NOT NULL DEFAULT '#ff007f',
  `schema_json` JSON NULL,
  `description` TEXT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_type_key` (`type_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_DefaultContexts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `context_key` VARCHAR(64) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `color` VARCHAR(16) NOT NULL DEFAULT '#ff007f',
  `raw_json` LONGTEXT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_context_key` (`context_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_DefaultThemes` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `theme_key` VARCHAR(64) NOT NULL,
  `display_name` VARCHAR(128) NOT NULL,
  `tokens_json` JSON NULL,
  `is_default` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_theme_key` (`theme_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- Bootstrap admin (password 123 — forces reset on first login)
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO `Ungodly_ToolMenuEmpty_FSG_Users`
  (`username`, `email`, `password_hash`, `is_admin`, `needs_reset`)
VALUES
  ('admin', 'admin@ungodly.local', '123', 1, 1);

-- Seed a few default panel types so the left library is not empty
INSERT IGNORE INTO `Ungodly_ToolMenuEmpty_FSG_DefaultPanelTypes`
  (`type_key`, `display_name`, `category`, `default_color`, `description`, `sort_order`)
VALUES
  ('SessionCard', 'Session Card', 'Engine', '#00f3ff', 'Shared session / auth surface used by almost every suite tool.', 10),
  ('ConditionBlock', 'Condition Block', 'Logic', '#ff007f', 'Key / operator / value condition triples.', 20),
  ('TriggerBlock', 'Trigger Block', 'Logic', '#ff4d9e', 'Formerly gameStateChanges — state mutations fired by the panel.', 30),
  ('CastMember', 'Cast Member', 'Character', '#e51fde', 'Named speaker with colour.', 40),
  ('GlobalToken', 'Global Token', 'Character', '#00f3ff', 'Key / value token (playerName, pronouns, …).', 50),
  ('DialogueNode', 'Dialogue Node', 'Dialogue', '#3DE435', 'Speaker + text + responses + advanced flags.', 60),
  ('Response', 'Response', 'Dialogue', '#057AFD', 'Player or NPC reply with nextStatementId.', 70),
  ('ImageSequence', 'Image Sequence', 'World', '#c50fc3', 'Named ordered list of images + root path.', 80),
  ('JSONLibraryEntry', 'JSON Library Entry', 'Engine', '#8000ff', 'Definition index with origin jump-to.', 90);

INSERT IGNORE INTO `Ungodly_ToolMenuEmpty_FSG_DefaultThemes`
  (`theme_key`, `display_name`, `tokens_json`, `is_default`)
VALUES
  ('hot-pink', 'Hot Pink (Default)', JSON_OBJECT(
    'primary', '#ff007f',
    'accent', '#00f3ff',
    'surface', '#0a0a0c',
    'panel', '#15151e',
    'text', '#e5e7eb',
    'muted', '#9ca3af',
    'success', '#22c55e',
    'danger', '#ef4444',
    'glow', '0 0 12px #ff007f66'
  ), 1);

-- Server message log (admin path changes, terminal notes)
CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_ServerMessages` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `message_uuid` CHAR(36) NOT NULL,
  `username` VARCHAR(64) NOT NULL DEFAULT 'system',
  `body` TEXT NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_msg_uuid` (`message_uuid`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
