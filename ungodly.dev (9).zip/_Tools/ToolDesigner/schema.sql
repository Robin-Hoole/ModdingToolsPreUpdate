-- =============================================================================
-- ToolDesigner 2.1.0 — MySQL 8+ schema
-- Default prefix: Ungodly_ToolMenuEmpty_FSG_
--
-- The running application can generate a customized copy of this schema using
-- three editable prefix fields and can optionally prepend active DROP statements.
-- =============================================================================

SET NAMES utf8mb4;

-- Optional shared-suite account/session compatibility. These are created only when absent.
-- Existing ungodly.dev installations keep their current data and table definitions.
CREATE TABLE IF NOT EXISTS `FSG_users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(64) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `is_over_18` TINYINT(1) NOT NULL DEFAULT 0,
  `agreed_terms` TINYINT(1) NOT NULL DEFAULT 0,
  `agreed_privacy` TINYINT(1) NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `is_admin` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_FSG_users_active_username` (`is_active`,`username`),
  KEY `idx_FSG_users_active_email` (`is_active`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FSG_auth_sessions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `token_hash` CHAR(64) NOT NULL,
  `browser_label` VARCHAR(128) NOT NULL DEFAULT '',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` DATETIME NOT NULL,
  `last_seen_at` DATETIME NULL DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_FSG_auth_sessions_token_hash` (`token_hash`),
  KEY `idx_FSG_auth_sessions_active` (`user_id`,`is_active`,`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FSG_Server_Sessions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `app_key` VARCHAR(64) NOT NULL DEFAULT 'ToolDesigner',
  `session_id` VARCHAR(96) NOT NULL,
  `first_seen_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `first_pushed_at` TIMESTAMP NULL DEFAULT NULL,
  `last_pushed_at` TIMESTAMP NULL DEFAULT NULL,
  `last_viewed_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `workspace_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_FSG_Server_Sessions_user_app_session` (`user_id`,`app_key`,`session_id`),
  KEY `idx_FSG_Server_Sessions_session` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 0;

-- OPTIONAL CLEAN RESET
-- Uncomment only when a complete ToolDesigner reset is intended.
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_ServerMessages`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_AuditLog`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_DefaultThemes`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_DefaultComponents`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_DefaultTools`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_SavedComponents`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_Profiles`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_TopBarButtons`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_ComponentDefinitions`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_ComponentRules`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_ComponentValues`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_Components`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_ToolVersions`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_Tools`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_Sessions`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_AuthTokens`;
-- DROP TABLE IF EXISTS `Ungodly_ToolMenuEmpty_FSG_Users`;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_Users` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(64) NOT NULL,
  `email` VARCHAR(255) NOT NULL DEFAULT '',
  `password_hash` VARCHAR(255) NOT NULL,
  `is_admin` TINYINT(1) NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `needs_reset` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_td_username` (`username`),
  UNIQUE KEY `uq_td_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_AuthTokens` (
  `token_hash` CHAR(64) NOT NULL,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `scope` ENUM('bootstrap','user') NOT NULL DEFAULT 'user',
  `expires_at` DATETIME NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_seen_at` TIMESTAMP NULL,
  PRIMARY KEY (`token_hash`),
  KEY `idx_td_auth_user_expiry` (`user_id`,`expires_at`),
  CONSTRAINT `fk_td_auth_user` FOREIGN KEY (`user_id`)
    REFERENCES `Ungodly_ToolMenuEmpty_FSG_Users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_Sessions` (
  `session_id` VARCHAR(96) NOT NULL,
  `owner_user_id` BIGINT UNSIGNED NULL,
  `password_hash` VARCHAR(255) NULL,
  `expires_at` DATETIME NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`),
  KEY `idx_td_session_owner` (`owner_user_id`),
  KEY `idx_td_session_expiry` (`expires_at`,`is_active`),
  CONSTRAINT `fk_td_session_owner` FOREIGN KEY (`owner_user_id`)
    REFERENCES `Ungodly_ToolMenuEmpty_FSG_Users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_Tools` (
  `tool_id` VARCHAR(128) NOT NULL,
  `session_id` VARCHAR(96) NOT NULL,
  `owner_user_id` BIGINT UNSIGNED NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `export_title` VARCHAR(255) NOT NULL DEFAULT '',
  `identity_color` VARCHAR(16) NOT NULL DEFAULT '#ff2f92',
  `tool_json` LONGTEXT NOT NULL,
  `profile_json` LONGTEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`tool_id`),
  UNIQUE KEY `uq_td_session_tool` (`session_id`,`tool_id`),
  KEY `idx_td_tool_session_owner` (`session_id`,`owner_user_id`),
  KEY `idx_td_tool_updated` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_ToolVersions` (
  `version_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `tool_id` VARCHAR(128) NOT NULL,
  `version_number` BIGINT UNSIGNED NOT NULL DEFAULT 1,
  `created_by_user_id` BIGINT UNSIGNED NULL,
  `snapshot_json` JSON NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`version_id`),
  UNIQUE KEY `uq_td_tool_version` (`tool_id`,`version_number`),
  KEY `idx_td_tool_version_latest` (`tool_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_Components` (
  `component_id` VARCHAR(128) NOT NULL,
  `tool_id` VARCHAR(128) NOT NULL,
  `type_key` VARCHAR(128) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `identity_color` VARCHAR(16) NOT NULL DEFAULT '#ff2f92',
  `sort_order` INT NOT NULL DEFAULT 0,
  `called_externally` TINYINT(1) NOT NULL DEFAULT 0,
  `makes_external_call` TINYINT(1) NOT NULL DEFAULT 0,
  `tooltip` VARCHAR(1024) NOT NULL DEFAULT '',
  `description` TEXT NULL,
  `source_path` VARCHAR(1024) NOT NULL DEFAULT '',
  `external_id` VARCHAR(255) NOT NULL DEFAULT '',
  `conditions_collapsed` TINYINT(1) NOT NULL DEFAULT 0,
  `triggers_collapsed` TINYINT(1) NOT NULL DEFAULT 0,
  `glow_condition` TINYINT(1) NOT NULL DEFAULT 1,
  `glow_trigger` TINYINT(1) NOT NULL DEFAULT 1,
  `payload_json` JSON NOT NULL,
  `unknown_fields_json` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`component_id`),
  KEY `idx_td_component_tool_type` (`tool_id`,`type_key`,`sort_order`),
  CONSTRAINT `fk_td_component_tool` FOREIGN KEY (`tool_id`)
    REFERENCES `Ungodly_ToolMenuEmpty_FSG_Tools` (`tool_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_ComponentValues` (
  `value_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `component_id` VARCHAR(128) NOT NULL,
  `field_key` VARCHAR(128) NOT NULL,
  `field_type` VARCHAR(32) NOT NULL DEFAULT 'text',
  `value_json` JSON NOT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`value_id`),
  UNIQUE KEY `uq_td_component_field` (`component_id`,`field_key`),
  CONSTRAINT `fk_td_value_component` FOREIGN KEY (`component_id`)
    REFERENCES `Ungodly_ToolMenuEmpty_FSG_Components` (`component_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_ComponentRules` (
  `rule_id` VARCHAR(128) NOT NULL,
  `component_id` VARCHAR(128) NOT NULL,
  `rule_kind` ENUM('condition','trigger') NOT NULL,
  `target_path` VARCHAR(512) NOT NULL DEFAULT '',
  `operation` VARCHAR(64) NOT NULL DEFAULT '',
  `value_json` JSON NULL,
  `tooltip` VARCHAR(1024) NOT NULL DEFAULT '',
  `sort_order` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`rule_id`),
  KEY `idx_td_component_rules` (`component_id`,`rule_kind`,`sort_order`),
  CONSTRAINT `fk_td_rule_component` FOREIGN KEY (`component_id`)
    REFERENCES `Ungodly_ToolMenuEmpty_FSG_Components` (`component_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_ComponentDefinitions` (
  `type_key` VARCHAR(128) NOT NULL,
  `display_name` VARCHAR(255) NOT NULL,
  `category` VARCHAR(128) NOT NULL DEFAULT 'General',
  `identity_color` VARCHAR(16) NOT NULL DEFAULT '#ff2f92',
  `description` TEXT NULL,
  `tooltip` VARCHAR(1024) NOT NULL DEFAULT '',
  `has_conditions` TINYINT(1) NOT NULL DEFAULT 1,
  `has_triggers` TINYINT(1) NOT NULL DEFAULT 1,
  `schema_json` JSON NOT NULL,
  `authored_by_user_id` BIGINT UNSIGNED NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`type_key`),
  KEY `idx_td_definition_category` (`category`,`display_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_TopBarButtons` (
  `button_id` VARCHAR(128) NOT NULL,
  `button_text` VARCHAR(128) NOT NULL,
  `link_type` ENUM('url','image') NOT NULL DEFAULT 'url',
  `url` VARCHAR(2048) NOT NULL DEFAULT '',
  `image_path` VARCHAR(1024) NOT NULL DEFAULT '',
  `tooltip` VARCHAR(1024) NOT NULL DEFAULT '',
  `description` TEXT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `visible` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`button_id`),
  KEY `idx_td_button_order` (`visible`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_Profiles` (
  `profile_id` VARCHAR(128) NOT NULL,
  `owner_user_id` BIGINT UNSIGNED NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `filename` VARCHAR(255) NOT NULL,
  `root_path` VARCHAR(1024) NOT NULL DEFAULT 'Json/Defaults',
  `payload_json` LONGTEXT NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`profile_id`),
  UNIQUE KEY `uq_td_owner_profile_filename` (`owner_user_id`,`filename`),
  KEY `idx_td_profile_owner_name` (`owner_user_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_SavedComponents` (
  `saved_component_id` VARCHAR(128) NOT NULL,
  `owner_user_id` BIGINT UNSIGNED NOT NULL,
  `type_key` VARCHAR(128) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `payload_json` JSON NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`saved_component_id`),
  KEY `idx_td_saved_component_owner_type` (`owner_user_id`,`type_key`,`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_DefaultTools` (
  `default_tool_id` VARCHAR(128) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `payload_json` JSON NOT NULL,
  PRIMARY KEY (`default_tool_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_DefaultComponents` (
  `default_component_id` VARCHAR(128) NOT NULL,
  `type_key` VARCHAR(128) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `payload_json` JSON NOT NULL,
  PRIMARY KEY (`default_component_id`),
  KEY `idx_td_default_component_type` (`type_key`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_DefaultThemes` (
  `theme_key` VARCHAR(128) NOT NULL,
  `display_name` VARCHAR(255) NOT NULL,
  `tokens_json` JSON NOT NULL,
  `is_default` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`theme_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_AuditLog` (
  `audit_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NULL,
  `action_name` VARCHAR(128) NOT NULL,
  `target_type` VARCHAR(64) NOT NULL DEFAULT '',
  `target_id` VARCHAR(128) NOT NULL DEFAULT '',
  `payload_json` JSON NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`audit_id`),
  KEY `idx_td_audit_action_time` (`action_name`,`created_at`),
  KEY `idx_td_audit_user_time` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `Ungodly_ToolMenuEmpty_FSG_ServerMessages` (
  `message_id` VARCHAR(128) NOT NULL,
  `username` VARCHAR(64) NOT NULL DEFAULT 'system',
  `message_body` TEXT NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_id`),
  KEY `idx_td_message_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `Ungodly_ToolMenuEmpty_FSG_Users`
  (`username`,`email`,`password_hash`,`is_admin`,`needs_reset`)
VALUES
  ('admin','admin@ungodly.local','BOOTSTRAP:123',1,1);

INSERT IGNORE INTO `Ungodly_ToolMenuEmpty_FSG_DefaultThemes`
  (`theme_key`,`display_name`,`tokens_json`,`is_default`)
VALUES
  ('dialogue-pink','Dialogue Pink',JSON_OBJECT(
    'bg','#07060a',
    'bgDeep','#020204',
    'surface','#0d0b11',
    'panel','#121018',
    'panel2','#191621',
    'panel3','#211c2a',
    'border','#352b3e',
    'borderBright','#5c4167',
    'primary','#ff2f92',
    'primaryDim','#c51669',
    'accent','#00e8ff',
    'purple','#a855f7',
    'green','#39e58c',
    'yellow','#f6c453',
    'orange','#ff8b57',
    'red','#ff4c6a',
    'blue','#428dff',
    'text','#f5eef7',
    'muted','#a99caf',
    'muted2','#75697b'
  ),1);

INSERT IGNORE INTO `Ungodly_ToolMenuEmpty_FSG_ComponentDefinitions`
  (`type_key`,`display_name`,`category`,`identity_color`,`description`,`tooltip`,`has_conditions`,`has_triggers`,`schema_json`)
VALUES
  ('DialogueStatement','Dialogue Statement','Dialogue','#39e58c','Speaker line, localized text, response links and voice metadata.','Primary Dialogue Designer statement component.',1,1,JSON_OBJECT('fields',JSON_ARRAY('statementId','speaker','language','text','voiceLine','voiceAsset','responseIds','nextStatementId'))),
  ('Response','Response','Dialogue','#428dff','Conditional response with routing and trigger data.','Dialogue Designer response component.',1,1,JSON_OBJECT('fields',JSON_ARRAY('responseId','language','text','nextStatementId','voiceLine','allowRepeating'))),
  ('CastMember','Cast Member','Dialogue','#e51fde','Reusable speaker identity and image root.','Populates cast and speaker dropdowns.',0,0,JSON_OBJECT('fields',JSON_ARRAY('castId','name','speakerColor','imageRoot','description'))),
  ('GlobalToken','Global Token','Globals','#00e8ff','Reusable token key and localized value.','Displayed as {{tokenKey}}.',0,0,JSON_OBJECT('fields',JSON_ARRAY('key','value','language'))),
  ('GenericPanel','Generic Panel','Foundation','#c984ff','Flexible base component with arbitrary JSON settings.','Starting point for new component families.',1,1,JSON_OBJECT('fields',JSON_ARRAY('label','body','settings')));

INSERT IGNORE INTO `Ungodly_ToolMenuEmpty_FSG_TopBarButtons`
  (`button_id`,`button_text`,`link_type`,`url`,`tooltip`,`description`,`sort_order`,`visible`)
VALUES
  ('button_dialogue_designer','DIALOGUE DESIGNER','url','#DialogueDesigner','Open the Dialogue Designer context','Conversation and statement authoring tool.',0,1),
  ('button_task_manager','TASK MANAGER','url','#TaskManager','Open the Task Manager context','Quest and objective authoring tool.',1,1),
  ('button_prompt_designer','PROMPT DESIGNER','url','#PromptDesigner','Open the Prompt Designer context','Prompt and AI blueprint authoring tool.',2,1),
  ('button_menu_designer','MENU DESIGNER','url','#MenuDesigner','Open the Menu Designer context','Menu and interface navigation authoring tool.',3,1);

SET FOREIGN_KEY_CHECKS = 1;
