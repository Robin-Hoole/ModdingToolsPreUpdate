-- Emberwake / Dawnreach Isles — MySQL 8+ schema
-- Every application-owned table uses the required FSG_TIBIALIKE_ prefix.
-- Run this file once, then let app.php upsert catalog and save data.

SET NAMES utf8mb4;

-- Clean rebuild: dependent tables are dropped before the tables they reference.
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS FSG_TIBIALIKE_RealmBuildingEvents;
DROP TABLE IF EXISTS FSG_TIBIALIKE_RealmBuildingInstances;
DROP TABLE IF EXISTS FSG_TIBIALIKE_RealmSimulationStates;
DROP TABLE IF EXISTS FSG_TIBIALIKE_RealmBuildingDefinitions;
DROP TABLE IF EXISTS FSG_TIBIALIKE_ServerEventRuns;
DROP TABLE IF EXISTS FSG_TIBIALIKE_CharacterAbilityAssignments;
DROP TABLE IF EXISTS FSG_TIBIALIKE_ServerEventDefinitions;
DROP TABLE IF EXISTS FSG_TIBIALIKE_AbilityDefinitions;
DROP TABLE IF EXISTS FSG_TIBIALIKE_ReportEscalationVotes;
DROP TABLE IF EXISTS FSG_TIBIALIKE_CharacterMemorials;
DROP TABLE IF EXISTS FSG_TIBIALIKE_PostalMail;
DROP TABLE IF EXISTS FSG_TIBIALIKE_CharacterReports;
DROP TABLE IF EXISTS FSG_TIBIALIKE_ControlBindings;
DROP TABLE IF EXISTS FSG_TIBIALIKE_CharacterBirths;
DROP TABLE IF EXISTS FSG_TIBIALIKE_InviteLinks;
DROP TABLE IF EXISTS FSG_TIBIALIKE_SocialRelations;
DROP TABLE IF EXISTS FSG_TIBIALIKE_PlayerPresence;
DROP TABLE IF EXISTS FSG_TIBIALIKE_GuildMemberTags;
DROP TABLE IF EXISTS FSG_TIBIALIKE_ItemProvenance;
DROP TABLE IF EXISTS FSG_TIBIALIKE_VillageStoreItems;
DROP TABLE IF EXISTS FSG_TIBIALIKE_SessionAccessRequests;
DROP TABLE IF EXISTS FSG_TIBIALIKE_ServerSessionMembers;
DROP TABLE IF EXISTS FSG_TIBIALIKE_ServerSessions;
DROP TABLE IF EXISTS FSG_TIBIALIKE_ExternalTables;
DROP TABLE IF EXISTS FSG_TIBIALIKE_ApiActions;
DROP TABLE IF EXISTS FSG_TIBIALIKE_WorldInstances;
DROP TABLE IF EXISTS FSG_TIBIALIKE_ServerLocks;
DROP TABLE IF EXISTS FSG_TIBIALIKE_AuditLog;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Events;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Relationships;
DROP TABLE IF EXISTS FSG_TIBIALIKE_EntityAliases;
DROP TABLE IF EXISTS FSG_TIBIALIKE_IntegrationSnapshots;
DROP TABLE IF EXISTS FSG_TIBIALIKE_IntegrationSystems;
DROP TABLE IF EXISTS FSG_TIBIALIKE_ContentVersions;
DROP TABLE IF EXISTS FSG_TIBIALIKE_SaveRevisions;
DROP TABLE IF EXISTS FSG_TIBIALIKE_GroundItems;
DROP TABLE IF EXISTS FSG_TIBIALIKE_FurniturePlacements;
DROP TABLE IF EXISTS FSG_TIBIALIKE_PlayerHouses;
DROP TABLE IF EXISTS FSG_TIBIALIKE_PlayerQuestStates;
DROP TABLE IF EXISTS FSG_TIBIALIKE_PlayerSpellbooks;
DROP TABLE IF EXISTS FSG_TIBIALIKE_PlayerEquipment;
DROP TABLE IF EXISTS FSG_TIBIALIKE_PlayerDepot;
DROP TABLE IF EXISTS FSG_TIBIALIKE_PlayerInventory;
DROP TABLE IF EXISTS FSG_TIBIALIKE_PlayerSkills;
DROP TABLE IF EXISTS FSG_TIBIALIKE_PlayerSurvival;
DROP TABLE IF EXISTS FSG_TIBIALIKE_PlayerCharacters;
DROP TABLE IF EXISTS FSG_TIBIALIKE_PlayerSaves;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Mounts;
DROP TABLE IF EXISTS FSG_TIBIALIKE_WorldTiles;
DROP TABLE IF EXISTS FSG_TIBIALIKE_FurnitureDefinitions;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Houses;
DROP TABLE IF EXISTS FSG_TIBIALIKE_SpawnPoints;
DROP TABLE IF EXISTS FSG_TIBIALIKE_ShopEntries;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Shops;
DROP TABLE IF EXISTS FSG_TIBIALIKE_QuestGivers;
DROP TABLE IF EXISTS FSG_TIBIALIKE_NPCs;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Placements;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Buildings;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Zones;
DROP TABLE IF EXISTS FSG_TIBIALIKE_QuestRewards;
DROP TABLE IF EXISTS FSG_TIBIALIKE_QuestObjectives;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Quests;
DROP TABLE IF EXISTS FSG_TIBIALIKE_DropEntries;
DROP TABLE IF EXISTS FSG_TIBIALIKE_DropTables;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Monsters;
DROP TABLE IF EXISTS FSG_TIBIALIKE_VocationSpells;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Spells;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Items;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Skills;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Vocations;
DROP TABLE IF EXISTS FSG_TIBIALIKE_CatalogEntries;
DROP TABLE IF EXISTS FSG_TIBIALIKE_Projects;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Projects (
    project_id VARCHAR(128) NOT NULL,
    owner_key VARCHAR(128) NOT NULL,
    name VARCHAR(160) NOT NULL,
    version VARCHAR(32) NOT NULL,
    admin_id BIGINT UNSIGNED NULL,
    payload_json JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE FSG_TIBIALIKE_Projects ADD COLUMN IF NOT EXISTS admin_id BIGINT UNSIGNED NULL AFTER version;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_CatalogEntries (
    owner_key VARCHAR(128) NOT NULL,
    project_id VARCHAR(128) NOT NULL,
    category VARCHAR(64) NOT NULL,
    entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL DEFAULT '',
    authored_by VARCHAR(128) NOT NULL DEFAULT 'emberwake_authoring',
    authored_at DATETIME NULL,
    updated_by VARCHAR(128) NOT NULL DEFAULT 'emberwake_authoring',
    sort_order INT NOT NULL DEFAULT 0,
    payload_json JSON NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, category, entity_id),
    KEY idx_fsg_tibialike_catalog_category (project_id, category),
    CONSTRAINT fk_fsg_tibialike_catalog_project FOREIGN KEY (owner_key, project_id)
      REFERENCES FSG_TIBIALIKE_Projects (owner_key, project_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE FSG_TIBIALIKE_CatalogEntries ADD COLUMN IF NOT EXISTS authored_by VARCHAR(128) NOT NULL DEFAULT 'emberwake_authoring' AFTER name;
ALTER TABLE FSG_TIBIALIKE_CatalogEntries ADD COLUMN IF NOT EXISTS authored_at DATETIME NULL AFTER authored_by;
ALTER TABLE FSG_TIBIALIKE_CatalogEntries ADD COLUMN IF NOT EXISTS updated_by VARCHAR(128) NOT NULL DEFAULT 'emberwake_authoring' AFTER authored_at;

-- Static rule families. Each keeps queryable common fields plus the lossless JSON row.
CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Vocations (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, role VARCHAR(255) NOT NULL DEFAULT '', payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Skills (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, family VARCHAR(64) NOT NULL DEFAULT '', payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Items (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, item_type VARCHAR(64) NOT NULL DEFAULT '', equip_slot VARCHAR(64) NULL,
    weight_oz DECIMAL(12,3) NOT NULL DEFAULT 0, buy_value INT NOT NULL DEFAULT 0, sell_value INT NOT NULL DEFAULT 0,
    payload_json JSON NOT NULL, PRIMARY KEY (owner_key, project_id, entity_id), KEY idx_fsg_tibialike_item_type (project_id, item_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Spells (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, spell_group VARCHAR(64) NOT NULL DEFAULT '', effect_type VARCHAR(64) NOT NULL DEFAULT '',
    min_level INT NOT NULL DEFAULT 1, mana_cost INT NOT NULL DEFAULT 0, zeal_cost INT NOT NULL DEFAULT 0, cooldown_ms INT NOT NULL DEFAULT 0,
    payload_json JSON NOT NULL, PRIMARY KEY (owner_key, project_id, entity_id), KEY idx_fsg_tibialike_spell_group (project_id, spell_group)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_VocationSpells (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, vocation_id VARCHAR(128) NOT NULL, spell_id VARCHAR(128) NOT NULL,
    min_level INT NOT NULL DEFAULT 1, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, vocation_id, spell_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Monsters (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, monster_level INT NOT NULL DEFAULT 1, max_hp INT NOT NULL DEFAULT 1, attack_value INT NOT NULL DEFAULT 0,
    defense_value INT NOT NULL DEFAULT 0, xp_value INT NOT NULL DEFAULT 0, element_type VARCHAR(64) NOT NULL DEFAULT 'physical', is_boss TINYINT(1) NOT NULL DEFAULT 0,
    payload_json JSON NOT NULL, PRIMARY KEY (owner_key, project_id, entity_id), KEY idx_fsg_tibialike_monster_level (project_id, monster_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_DropTables (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL DEFAULT '', monster_id VARCHAR(128) NOT NULL, roll_count INT NOT NULL DEFAULT 1, nothing_weight DECIMAL(14,4) NOT NULL DEFAULT 0,
    payload_json JSON NOT NULL, PRIMARY KEY (owner_key, project_id, entity_id), KEY idx_fsg_tibialike_drop_monster (project_id, monster_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_DropEntries (
    drop_entry_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, drop_table_id VARCHAR(128) NOT NULL,
    item_id VARCHAR(128) NOT NULL, tier VARCHAR(32) NOT NULL, weight_value DECIMAL(14,4) NOT NULL DEFAULT 0,
    min_quantity INT NOT NULL DEFAULT 1, max_quantity INT NOT NULL DEFAULT 1, sort_order INT NOT NULL DEFAULT 0, payload_json JSON NOT NULL,
    PRIMARY KEY (drop_entry_id), KEY idx_fsg_tibialike_drop_entry_table (owner_key, project_id, drop_table_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Quests (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, giver_id VARCHAR(128) NULL, recommended_level INT NOT NULL DEFAULT 1, is_soloable TINYINT(1) NOT NULL DEFAULT 1,
    payload_json JSON NOT NULL, PRIMARY KEY (owner_key, project_id, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_QuestObjectives (
    objective_row_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, quest_id VARCHAR(128) NOT NULL, objective_id VARCHAR(128) NOT NULL,
    objective_type VARCHAR(64) NOT NULL, target_id VARCHAR(128) NOT NULL, required_amount INT NOT NULL DEFAULT 1, sort_order INT NOT NULL DEFAULT 0, payload_json JSON NOT NULL,
    PRIMARY KEY (objective_row_id), UNIQUE KEY uq_fsg_tibialike_quest_objective (owner_key, project_id, quest_id, objective_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_QuestRewards (
    reward_row_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, quest_id VARCHAR(128) NOT NULL,
    reward_type VARCHAR(64) NOT NULL, target_id VARCHAR(128) NOT NULL DEFAULT '', amount INT NOT NULL DEFAULT 0, sort_order INT NOT NULL DEFAULT 0, payload_json JSON NOT NULL,
    PRIMARY KEY (reward_row_id), KEY idx_fsg_tibialike_quest_reward (owner_key, project_id, quest_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Spatial and interaction families.
CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Zones (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, floor_z INT NOT NULL DEFAULT 0, min_level INT NOT NULL DEFAULT 1, max_level INT NOT NULL DEFAULT 1,
    danger VARCHAR(32) NOT NULL DEFAULT 'low', is_protection_zone TINYINT(1) NOT NULL DEFAULT 0, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Buildings (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, building_type VARCHAR(64) NOT NULL DEFAULT '', pos_x INT NOT NULL, pos_y INT NOT NULL, pos_z INT NOT NULL DEFAULT 0,
    width_tiles INT NOT NULL DEFAULT 1, height_tiles INT NOT NULL DEFAULT 1, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, entity_id), KEY idx_fsg_tibialike_building_position (project_id, pos_z, pos_x, pos_y)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Placements (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL DEFAULT '', placement_type VARCHAR(64) NOT NULL DEFAULT '', template_id VARCHAR(128) NOT NULL DEFAULT '',
    pos_x INT NOT NULL, pos_y INT NOT NULL, pos_z INT NOT NULL DEFAULT 0, target_x INT NULL, target_y INT NULL, target_z INT NULL, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, entity_id), KEY idx_fsg_tibialike_placement_position (project_id, pos_z, pos_x, pos_y)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_NPCs (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, npc_role VARCHAR(255) NOT NULL DEFAULT '', pos_x INT NOT NULL, pos_y INT NOT NULL, pos_z INT NOT NULL DEFAULT 0,
    shop_id VARCHAR(128) NULL, payload_json JSON NOT NULL, PRIMARY KEY (owner_key, project_id, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_QuestGivers (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL DEFAULT '', npc_id VARCHAR(128) NOT NULL, quest_id VARCHAR(128) NOT NULL,
    pos_x INT NOT NULL, pos_y INT NOT NULL, pos_z INT NOT NULL DEFAULT 0, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, entity_id), KEY idx_fsg_tibialike_giver_npc (project_id, npc_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Shops (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, payload_json JSON NOT NULL, PRIMARY KEY (owner_key, project_id, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_ShopEntries (
    shop_entry_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, shop_id VARCHAR(128) NOT NULL, item_id VARCHAR(128) NOT NULL,
    direction ENUM('buy','sell') NOT NULL, price_override INT NULL, payload_json JSON NOT NULL,
    PRIMARY KEY (shop_entry_id), UNIQUE KEY uq_fsg_tibialike_shop_entry (owner_key, project_id, shop_id, item_id, direction)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_SpawnPoints (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL DEFAULT '', monster_id VARCHAR(128) NOT NULL, pos_x INT NOT NULL, pos_y INT NOT NULL, pos_z INT NOT NULL DEFAULT 0,
    spawn_count INT NOT NULL DEFAULT 1, radius_tiles INT NOT NULL DEFAULT 0, respawn_seconds INT NOT NULL DEFAULT 15, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, entity_id), KEY idx_fsg_tibialike_spawn_position (project_id, pos_z, pos_x, pos_y)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Houses (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, town VARCHAR(128) NOT NULL DEFAULT '', pos_x INT NOT NULL, pos_y INT NOT NULL, pos_z INT NOT NULL DEFAULT 0,
    width_tiles INT NOT NULL DEFAULT 1, height_tiles INT NOT NULL DEFAULT 1, purchase_price INT NOT NULL DEFAULT 0, rent_gold INT NOT NULL DEFAULT 0,
    payload_json JSON NOT NULL, PRIMARY KEY (owner_key, project_id, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_FurnitureDefinitions (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, category VARCHAR(64) NOT NULL DEFAULT 'decor', buy_value INT NOT NULL DEFAULT 0, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_WorldTiles (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    pos_x INT NOT NULL, pos_y INT NOT NULL, pos_z INT NOT NULL DEFAULT 0, terrain_id VARCHAR(64) NOT NULL,
    color_hex VARCHAR(16) NOT NULL DEFAULT '', is_walkable TINYINT(1) NOT NULL DEFAULT 1,
    is_wall TINYINT(1) NOT NULL DEFAULT 0, is_water TINYINT(1) NOT NULL DEFAULT 0, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, entity_id),
    KEY idx_fsg_tibialike_world_tile_position (project_id, pos_z, pos_x, pos_y)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Mounts (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, entity_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, speed_bonus DECIMAL(8,4) NOT NULL DEFAULT 0, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Player/session families. owner_key is user:<id> when authenticated, guest:<hash> otherwise.
CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_PlayerSaves (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, save_version VARCHAR(32) NOT NULL,
    active_character_id VARCHAR(128) NULL, payload_json JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_PlayerCharacters (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL,
    slot_number INT NOT NULL, character_name VARCHAR(255) NOT NULL, vocation_id VARCHAR(128) NOT NULL, character_level INT NOT NULL DEFAULT 1,
    xp BIGINT NOT NULL DEFAULT 0, hp_current INT NOT NULL DEFAULT 1, hp_max INT NOT NULL DEFAULT 1, mana_current INT NOT NULL DEFAULT 0, mana_max INT NOT NULL DEFAULT 0,
    zeal_current INT NOT NULL DEFAULT 0, gold BIGINT NOT NULL DEFAULT 0, pos_x INT NOT NULL, pos_y INT NOT NULL, pos_z INT NOT NULL DEFAULT 0,
    payload_json JSON NOT NULL, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, character_id), UNIQUE KEY uq_fsg_tibialike_character_slot (owner_key, project_id, slot_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_PlayerSurvival (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL,
    hunger DECIMAL(7,3) NOT NULL DEFAULT 100, thirst DECIMAL(7,3) NOT NULL DEFAULT 100, rest_level DECIMAL(7,3) NOT NULL DEFAULT 100,
    last_updated_ms BIGINT NOT NULL DEFAULT 0, payload_json JSON NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, character_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_PlayerSkills (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL, skill_id VARCHAR(128) NOT NULL,
    skill_level INT NOT NULL DEFAULT 1, skill_xp BIGINT NOT NULL DEFAULT 0, next_xp BIGINT NOT NULL DEFAULT 100, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, character_id, skill_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_PlayerInventory (
    inventory_row_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL,
    slot_index INT NOT NULL, item_id VARCHAR(128) NOT NULL, quantity INT NOT NULL DEFAULT 1, parent_instance_id VARCHAR(128) NULL, payload_json JSON NOT NULL,
    PRIMARY KEY (inventory_row_id), UNIQUE KEY uq_fsg_tibialike_inventory_slot (owner_key, project_id, character_id, slot_index)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_PlayerDepot (
    depot_row_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL,
    slot_index INT NOT NULL, item_id VARCHAR(128) NOT NULL, quantity INT NOT NULL DEFAULT 1, payload_json JSON NOT NULL,
    PRIMARY KEY (depot_row_id), UNIQUE KEY uq_fsg_tibialike_depot_slot (owner_key, project_id, character_id, slot_index),
    KEY idx_fsg_tibialike_depot_character (owner_key, project_id, character_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_PlayerEquipment (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL,
    equip_slot VARCHAR(64) NOT NULL, item_id VARCHAR(128) NULL, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, character_id, equip_slot)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_PlayerSpellbooks (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL, spell_id VARCHAR(128) NOT NULL,
    hotbar_slot INT NULL, learned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, character_id, spell_id), KEY idx_fsg_tibialike_hotbar (owner_key, project_id, character_id, hotbar_slot)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_PlayerQuestStates (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL, quest_id VARCHAR(128) NOT NULL,
    quest_status VARCHAR(32) NOT NULL DEFAULT 'available', progress_json JSON NOT NULL, payload_json JSON NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, character_id, quest_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_PlayerHouses (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL, house_id VARCHAR(128) NOT NULL,
    purchased_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, rent_paid_until TIMESTAMP NULL, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, character_id, house_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_FurniturePlacements (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL, placement_id VARCHAR(128) NOT NULL,
    house_id VARCHAR(128) NOT NULL, item_id VARCHAR(128) NOT NULL, pos_x INT NOT NULL, pos_y INT NOT NULL, pos_z INT NOT NULL DEFAULT 0,
    rotation INT NOT NULL DEFAULT 0, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, character_id, placement_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_GroundItems (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL, ground_item_id VARCHAR(128) NOT NULL,
    item_id VARCHAR(128) NULL, quantity INT NOT NULL DEFAULT 1, pos_x INT NOT NULL, pos_y INT NOT NULL, pos_z INT NOT NULL DEFAULT 0,
    container_json JSON NULL, payload_json JSON NOT NULL, PRIMARY KEY (owner_key, project_id, character_id, ground_item_id),
    KEY idx_fsg_tibialike_ground_position (project_id, pos_z, pos_x, pos_y)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cross-application contract layer. Definitions, runtime state and persistence stay
-- separate; foreign payloads remain lossless JSON while stable IDs stay queryable.
CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_SaveRevisions (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL,
    revision BIGINT UNSIGNED NOT NULL DEFAULT 0, content_revision BIGINT UNSIGNED NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_ContentVersions (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, content_revision BIGINT UNSIGNED NOT NULL,
    schema_version INT NOT NULL DEFAULT 1, content_version INT NOT NULL DEFAULT 1, payload_json JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, content_revision),
    KEY idx_fsg_tibialike_content_latest (owner_key, project_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_IntegrationSystems (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, system_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, authority_scope VARCHAR(255) NOT NULL DEFAULT '', schema_version INT NOT NULL DEFAULT 1,
    content_version INT NOT NULL DEFAULT 1, payload_json JSON NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, system_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_IntegrationSnapshots (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, system_id VARCHAR(128) NOT NULL,
    schema_version INT NOT NULL DEFAULT 1, content_version INT NOT NULL DEFAULT 1, source_revision VARCHAR(128) NULL,
    payload_json JSON NOT NULL, imported_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, system_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_EntityAliases (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, alias_id VARCHAR(128) NOT NULL,
    source_system VARCHAR(128) NOT NULL, entity_type VARCHAR(64) NOT NULL, external_id VARCHAR(255) NOT NULL,
    canonical_id VARCHAR(255) NOT NULL, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, alias_id),
    KEY idx_fsg_tibialike_alias_lookup (project_id, source_system, entity_type, external_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Relationships (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, relationship_id VARCHAR(128) NOT NULL,
    source_type VARCHAR(64) NOT NULL, source_id VARCHAR(255) NOT NULL, relation_type VARCHAR(64) NOT NULL,
    target_type VARCHAR(64) NOT NULL, target_id VARCHAR(255) NOT NULL, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, relationship_id),
    KEY idx_fsg_tibialike_relationship_source (project_id, source_type, source_id),
    KEY idx_fsg_tibialike_relationship_target (project_id, target_type, target_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_Events (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, event_id VARCHAR(128) NOT NULL,
    event_type VARCHAR(128) NOT NULL, character_id VARCHAR(128) NULL, occurred_at_ms BIGINT NOT NULL DEFAULT 0,
    payload_json JSON NOT NULL, received_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, event_id),
    KEY idx_fsg_tibialike_event_stream (owner_key, project_id, occurred_at_ms)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_AuditLog (
    audit_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL,
    action_id VARCHAR(64) NOT NULL, revision_before BIGINT UNSIGNED NULL, revision_after BIGINT UNSIGNED NULL,
    payload_json JSON NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (audit_id), KEY idx_fsg_tibialike_audit_project (owner_key, project_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_ServerLocks (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, lock_name VARCHAR(128) NOT NULL,
    lock_token VARCHAR(128) NOT NULL, expires_at TIMESTAMP NOT NULL, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, lock_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_WorldInstances (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, instance_key VARCHAR(128) NOT NULL,
    content_revision BIGINT UNSIGNED NOT NULL DEFAULT 0, revision BIGINT UNSIGNED NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1, state_json JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, instance_key),
    KEY idx_fsg_tibialike_world_active (project_id, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_ApiActions (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, action_id VARCHAR(128) NOT NULL,
    http_method VARCHAR(16) NOT NULL, requires_auth TINYINT(1) NOT NULL DEFAULT 0, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, action_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_ExternalTables (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, table_id VARCHAR(128) NOT NULL,
    source_system VARCHAR(128) NOT NULL, table_name VARCHAR(255) NOT NULL, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, table_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Suite-correlated server sessions and project-scoped authorization.
CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_ServerSessions (
    project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL,
    data_owner_key VARCHAR(128) NOT NULL, admin_id BIGINT UNSIGNED NULL, created_by_user_id BIGINT UNSIGNED NULL,
    name VARCHAR(160) NOT NULL DEFAULT '', status ENUM('active','revoked','archived') NOT NULL DEFAULT 'active',
    payload_json JSON NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (project_id, session_id), UNIQUE KEY uq_fsg_tibialike_session_owner (data_owner_key),
    KEY idx_fsg_tibialike_session_admin (admin_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_ServerSessionMembers (
    project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL, user_id BIGINT UNSIGNED NOT NULL,
    role ENUM('player','guild_moderator','forum_moderator','gameplay_moderator','moderator','guild_master','game_master','admin','server_owner') NOT NULL DEFAULT 'player',
    role_tags_json JSON NOT NULL, granted_by_user_id BIGINT UNSIGNED NULL, is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (project_id, session_id, user_id), KEY idx_fsg_tibialike_session_role (project_id, session_id, role, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_SessionAccessRequests (
    request_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL, requested_role VARCHAR(32) NOT NULL DEFAULT 'player',
    status ENUM('pending','approved','denied','revoked') NOT NULL DEFAULT 'pending', reviewed_by_user_id BIGINT UNSIGNED NULL,
    message VARCHAR(500) NOT NULL DEFAULT '', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at TIMESTAMP NULL, PRIMARY KEY (request_id),
    UNIQUE KEY uq_fsg_tibialike_access_request (project_id, session_id, user_id),
    KEY idx_fsg_tibialike_access_admin (project_id, session_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_GuildMemberTags (
    project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL, guild_id VARCHAR(128) NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL, rank_id VARCHAR(128) NOT NULL DEFAULT 'member', title_tag VARCHAR(128) NOT NULL DEFAULT '',
    is_guild_moderator TINYINT(1) NOT NULL DEFAULT 0, assigned_by_user_id BIGINT UNSIGNED NULL,
    payload_json JSON NOT NULL, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (project_id, session_id, guild_id, user_id),
    KEY idx_fsg_tibialike_guild_tag (project_id, session_id, guild_id, rank_id, title_tag)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_VillageStoreItems (
    project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL, store_id VARCHAR(128) NOT NULL,
    item_id VARCHAR(128) NOT NULL, quantity BIGINT UNSIGNED NOT NULL DEFAULT 0, updated_by_user_id BIGINT UNSIGNED NULL,
    payload_json JSON NOT NULL, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (project_id, session_id, store_id, item_id),
    KEY idx_fsg_tibialike_village_store (project_id, session_id, store_id, quantity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_ItemProvenance (
    provenance_id VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL,
    item_instance_id VARCHAR(128) NOT NULL, item_id VARCHAR(128) NOT NULL, authored_by_id VARCHAR(128) NOT NULL,
    authored_by_type ENUM('server','player') NOT NULL, source_type VARCHAR(64) NOT NULL, source_id VARCHAR(128) NOT NULL,
    admin_created TINYINT(1) NOT NULL DEFAULT 0, current_owner_id VARCHAR(128) NOT NULL,
    ownership_chain_json JSON NOT NULL, payload_json JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (provenance_id), UNIQUE KEY uq_fsg_tibialike_item_instance (project_id, session_id, item_instance_id),
    KEY idx_fsg_tibialike_item_owner (project_id, session_id, current_owner_id, item_id),
    KEY idx_fsg_tibialike_item_author (project_id, session_id, authored_by_id, admin_created)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_PlayerPresence (
    project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL, owner_key VARCHAR(128) NOT NULL,
    account_id BIGINT UNSIGNED NULL, character_id VARCHAR(128) NOT NULL, client_instance_id VARCHAR(128) NOT NULL,
    character_name VARCHAR(255) NOT NULL DEFAULT '', vocation_id VARCHAR(128) NOT NULL DEFAULT '', character_level INT NOT NULL DEFAULT 1,
    active_map_id VARCHAR(128) NOT NULL DEFAULT 'map_emberwake_overworld', pos_x INT NOT NULL DEFAULT 0, pos_y INT NOT NULL DEFAULT 0, pos_z INT NOT NULL DEFAULT 0,
    is_online TINYINT(1) NOT NULL DEFAULT 1, payload_json JSON NOT NULL,
    last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (project_id, session_id, character_id),
    KEY idx_fsg_tibialike_presence_world (project_id, session_id, active_map_id, pos_z, is_online, last_seen_at),
    KEY idx_fsg_tibialike_presence_account (project_id, session_id, account_id, is_online)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_SocialRelations (
    relation_id VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL,
    actor_account_id BIGINT UNSIGNED NOT NULL, actor_character_id VARCHAR(128) NOT NULL,
    relation_type ENUM('friend','mute','block') NOT NULL, scope_type ENUM('character','account_humanoids','god','account_gods','account') NOT NULL,
    target_account_id VARCHAR(128) NOT NULL DEFAULT '', target_character_id VARCHAR(128) NOT NULL DEFAULT '', target_god_id VARCHAR(128) NOT NULL DEFAULT '',
    payload_json JSON NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (relation_id),
    UNIQUE KEY uq_fsg_tibialike_social_relation (project_id, session_id, actor_account_id, actor_character_id, relation_type, scope_type, target_account_id, target_character_id, target_god_id),
    KEY idx_fsg_tibialike_social_target (project_id, session_id, target_account_id, target_character_id, relation_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_InviteLinks (
    invite_id VARCHAR(128) NOT NULL, token_hash CHAR(64) NOT NULL, project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL,
    created_by_user_id BIGINT UNSIGNED NOT NULL, inviter_character_id VARCHAR(128) NOT NULL DEFAULT '',
    maximum_uses INT UNSIGNED NOT NULL DEFAULT 100, use_count INT UNSIGNED NOT NULL DEFAULT 0, is_active TINYINT(1) NOT NULL DEFAULT 1,
    expires_at TIMESTAMP NULL, payload_json JSON NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (invite_id), UNIQUE KEY uq_fsg_tibialike_invite_token (token_hash),
    KEY idx_fsg_tibialike_invite_session (project_id, session_id, is_active, expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_CharacterBirths (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL,
    birth_world_id VARCHAR(128) NOT NULL, birth_village_id VARCHAR(128) NOT NULL, birth_server_session_id VARCHAR(96) NOT NULL,
    birth_server_time DATETIME(3) NOT NULL, birth_server_epoch_ms BIGINT UNSIGNED NOT NULL, payload_json JSON NOT NULL,
    PRIMARY KEY (owner_key, project_id, character_id),
    KEY idx_fsg_tibialike_birth_place (project_id, birth_world_id, birth_village_id, birth_server_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_ControlBindings (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, action_id VARCHAR(128) NOT NULL,
    desktop_binding VARCHAR(255) NOT NULL DEFAULT '', mobile_binding VARCHAR(255) NOT NULL DEFAULT '', payload_json JSON NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, action_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_CharacterReports (
    report_id VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL,
    reporter_owner_key VARCHAR(128) NOT NULL, reporter_account_id VARCHAR(128) NOT NULL, reporter_character_id VARCHAR(128) NOT NULL,
    subject_account_id VARCHAR(128) NOT NULL, subject_character_id VARCHAR(128) NOT NULL,
    offense_type_id VARCHAR(128) NOT NULL, suggested_action_id VARCHAR(128) NOT NULL,
    details TEXT NOT NULL, proof_url VARCHAR(2048) NOT NULL DEFAULT '', moderation_flag TINYINT(1) NOT NULL DEFAULT 1,
    status ENUM('open','reviewing','escalated','resolved','dismissed') NOT NULL DEFAULT 'open', escalation_vote_count INT UNSIGNED NOT NULL DEFAULT 0,
    snapshot_json JSON NOT NULL, payload_json JSON NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (report_id),
    KEY idx_fsg_tibialike_reports_queue (project_id, session_id, moderation_flag, status, created_at),
    KEY idx_fsg_tibialike_reports_subject (project_id, subject_account_id, subject_character_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_ReportEscalationVotes (
    report_id VARCHAR(128) NOT NULL, voter_user_id BIGINT UNSIGNED NOT NULL, voter_role VARCHAR(64) NOT NULL,
    vote ENUM('escalate','do_not_escalate','abstain') NOT NULL, reason VARCHAR(1000) NOT NULL DEFAULT '', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (report_id, voter_user_id),
    KEY idx_fsg_tibialike_report_votes (report_id, vote, updated_at),
    CONSTRAINT fk_fsg_tibialike_report_vote FOREIGN KEY (report_id) REFERENCES FSG_TIBIALIKE_CharacterReports(report_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_PostalMail (
    mail_id VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL,
    sender_account_id VARCHAR(128) NOT NULL, sender_character_id VARCHAR(128) NOT NULL, sender_name VARCHAR(255) NOT NULL,
    recipient_character_id VARCHAR(128) NOT NULL, recipient_name_at_send VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL DEFAULT '', message TEXT NOT NULL, container_item_id VARCHAR(128) NOT NULL,
    contents_json JSON NOT NULL, status ENUM('waiting','delivered','returned') NOT NULL DEFAULT 'waiting',
    sent_at DATETIME(3) NOT NULL, delivered_at DATETIME(3) NULL, payload_json JSON NOT NULL,
    PRIMARY KEY (mail_id),
    KEY idx_fsg_tibialike_postal_inbox (project_id, session_id, recipient_character_id, status, sent_at),
    KEY idx_fsg_tibialike_postal_sender (project_id, session_id, sender_character_id, sent_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_CharacterMemorials (
    memorial_id VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL,
    owner_account_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL, god_id VARCHAR(128) NOT NULL,
    destruction_reason VARCHAR(255) NOT NULL DEFAULT 'god_destroyed', destroyed_at DATETIME(3) NOT NULL,
    character_snapshot_json JSON NOT NULL, payload_json JSON NOT NULL,
    PRIMARY KEY (memorial_id),
    KEY idx_fsg_tibialike_memorial_owner (project_id, session_id, owner_account_id, destroyed_at),
    KEY idx_fsg_tibialike_memorial_god (project_id, session_id, god_id, destroyed_at),
    UNIQUE KEY uq_fsg_tibialike_memorial_character (project_id, session_id, character_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_AbilityDefinitions (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, ability_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, activation_type VARCHAR(32) NOT NULL DEFAULT 'passive', rank_maximum INT UNSIGNED NOT NULL DEFAULT 1,
    cooldown_ms INT UNSIGNED NOT NULL DEFAULT 0, conditions_json JSON NOT NULL, effects_json JSON NOT NULL, targeting_json JSON NOT NULL, resource_costs_json JSON NOT NULL,
    description TEXT NOT NULL, tooltip TEXT NOT NULL, icon_directory VARCHAR(1024) NOT NULL DEFAULT '', model_directory VARCHAR(1024) NOT NULL DEFAULT '',
    payload_json JSON NOT NULL, authored_by VARCHAR(128) NOT NULL DEFAULT 'emberwake_authoring', authored_at DATETIME(3) NOT NULL,
    updated_by VARCHAR(128) NOT NULL DEFAULT 'emberwake_authoring', updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, ability_id),
    KEY idx_fsg_tibialike_ability_activation (project_id, activation_type, ability_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_ServerEventDefinitions (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, event_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, map_id VARCHAR(128) NOT NULL, monster_id VARCHAR(128) NOT NULL, enabled TINYINT(1) NOT NULL DEFAULT 1,
    duration_seconds INT UNSIGNED NOT NULL DEFAULT 60, wave_interval_seconds INT UNSIGNED NOT NULL DEFAULT 10, count_per_wave INT UNSIGNED NOT NULL DEFAULT 1,
    maximum_alive INT UNSIGNED NOT NULL DEFAULT 100, region_json JSON NOT NULL, ability_grant_ids_json JSON NOT NULL,
    description TEXT NOT NULL, tooltip TEXT NOT NULL, icon_directory VARCHAR(1024) NOT NULL DEFAULT '', model_directory VARCHAR(1024) NOT NULL DEFAULT '',
    payload_json JSON NOT NULL, authored_by VARCHAR(128) NOT NULL DEFAULT 'emberwake_authoring', authored_at DATETIME(3) NOT NULL,
    updated_by VARCHAR(128) NOT NULL DEFAULT 'emberwake_authoring', updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, event_id),
    KEY idx_fsg_tibialike_server_event_map (project_id, map_id, enabled, event_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_CharacterAbilityAssignments (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL,
    assignment_id VARCHAR(128) NOT NULL, character_id VARCHAR(128) NOT NULL, ability_id VARCHAR(128) NOT NULL,
    rank_value INT UNSIGNED NOT NULL DEFAULT 1, enabled TINYINT(1) NOT NULL DEFAULT 1, source_type VARCHAR(64) NOT NULL DEFAULT 'authoring', source_id VARCHAR(128) NOT NULL DEFAULT '',
    payload_json JSON NOT NULL, created_at DATETIME(3) NOT NULL, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, assignment_id),
    UNIQUE KEY uq_fsg_tibialike_character_ability (owner_key, project_id, session_id, character_id, ability_id),
    KEY idx_fsg_tibialike_character_abilities (project_id, session_id, character_id, enabled)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_ServerEventRuns (
    run_id VARCHAR(128) NOT NULL, owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL,
    event_id VARCHAR(128) NOT NULL, map_id VARCHAR(128) NOT NULL, started_at DATETIME(3) NOT NULL, ends_at DATETIME(3) NOT NULL, finished_at DATETIME(3) NULL,
    waves_spawned INT UNSIGNED NOT NULL DEFAULT 0, total_spawned INT UNSIGNED NOT NULL DEFAULT 0, stop_reason VARCHAR(128) NOT NULL DEFAULT '',
    runtime_json JSON NOT NULL, created_by VARCHAR(128) NOT NULL DEFAULT 'emberwake_authoring',
    PRIMARY KEY (run_id),
    KEY idx_fsg_tibialike_event_runs (project_id, session_id, map_id, event_id, finished_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_RealmBuildingDefinitions (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, building_id VARCHAR(128) NOT NULL,
    name VARCHAR(255) NOT NULL, group_id VARCHAR(64) NOT NULL, age_id VARCHAR(32) NOT NULL, base_hp INT UNSIGNED NOT NULL DEFAULT 1,
    work_required DECIMAL(14,3) NOT NULL DEFAULT 0, width_tiles DECIMAL(10,3) NOT NULL DEFAULT 1, depth_tiles DECIMAL(10,3) NOT NULL DEFAULT 1, height_world DECIMAL(10,3) NOT NULL DEFAULT 1,
    cost_json JSON NOT NULL, effects_json JSON NOT NULL, worker_requirement_json JSON NULL, placement_rules_json JSON NOT NULL, special_rules_json JSON NOT NULL, tier_rules_json JSON NOT NULL,
    command_mode VARCHAR(64) NOT NULL DEFAULT 'system', guild_class_id VARCHAR(128) NOT NULL DEFAULT '',
    description TEXT NOT NULL, tooltip TEXT NOT NULL, icon_directory VARCHAR(1024) NOT NULL DEFAULT '', model_directory VARCHAR(1024) NOT NULL DEFAULT '', payload_json JSON NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, building_id), KEY idx_fsg_tibialike_realm_building_group (project_id, group_id, age_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_RealmSimulationStates (
    owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL,
    age_id VARCHAR(32) NOT NULL DEFAULT 'Dark', alignment_value DECIMAL(8,5) NOT NULL DEFAULT 0, appeal_value DECIMAL(14,3) NOT NULL DEFAULT 0,
    running TINYINT(1) NOT NULL DEFAULT 0, victory TINYINT(1) NOT NULL DEFAULT 0, defeat TINYINT(1) NOT NULL DEFAULT 0,
    resources_json JSON NOT NULL, population_json JSON NOT NULL, unlocks_json JSON NOT NULL, heroes_json JSON NOT NULL, soldiers_json JSON NOT NULL, state_json JSON NOT NULL,
    revision BIGINT UNSIGNED NOT NULL DEFAULT 0, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner_key, project_id, session_id), KEY idx_fsg_tibialike_realm_state (project_id, session_id, running, defeat, victory)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_RealmBuildingInstances (
    instance_id VARCHAR(128) NOT NULL, owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL,
    building_id VARCHAR(128) NOT NULL, map_id VARCHAR(128) NOT NULL, pos_x DECIMAL(12,3) NOT NULL, pos_y DECIMAL(12,3) NOT NULL, pos_z INT NOT NULL DEFAULT 0,
    tier_value INT UNSIGNED NOT NULL DEFAULT 1, hp_value DECIMAL(14,3) NOT NULL DEFAULT 1, max_hp_value DECIMAL(14,3) NOT NULL DEFAULT 1,
    status_value ENUM('constructing','complete','destroyed') NOT NULL DEFAULT 'constructing', enabled TINYINT(1) NOT NULL DEFAULT 1,
    construction_progress DECIMAL(14,3) NOT NULL DEFAULT 0, assigned_worker_count INT UNSIGNED NOT NULL DEFAULT 0, assigned_worker_ids_json JSON NOT NULL,
    source_type VARCHAR(64) NOT NULL DEFAULT 'authoring', instance_json JSON NOT NULL, created_at DATETIME(3) NOT NULL, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (instance_id), KEY idx_fsg_tibialike_realm_instance_map (project_id, session_id, map_id, pos_z, pos_x, pos_y),
    KEY idx_fsg_tibialike_realm_instance_type (project_id, session_id, building_id, status_value, tier_value)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_TIBIALIKE_RealmBuildingEvents (
    event_id VARCHAR(128) NOT NULL, owner_key VARCHAR(128) NOT NULL, project_id VARCHAR(128) NOT NULL, session_id VARCHAR(96) NOT NULL,
    instance_id VARCHAR(128) NOT NULL DEFAULT '', building_id VARCHAR(128) NOT NULL DEFAULT '', event_type VARCHAR(96) NOT NULL,
    occurred_at_ms BIGINT UNSIGNED NOT NULL, created_at DATETIME(3) NOT NULL, payload_json JSON NOT NULL,
    PRIMARY KEY (event_id), KEY idx_fsg_tibialike_realm_event_time (project_id, session_id, occurred_at_ms),
    KEY idx_fsg_tibialike_realm_event_building (project_id, session_id, building_id, event_type, occurred_at_ms)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
