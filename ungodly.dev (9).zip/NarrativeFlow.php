<?php
/**
 * ==============================================================================
 * NAMESPACE: RobinHooleProduction.NarrativeFlow.API
 * CONTEXT: Narrative Flow database/login/session pipeline
 * DESCRIPTION: Saves/restores full Narrative Flow configurations by server session
 *              while sharing the same auth/session relationship as Dialogue
 *              Designer and Task Manager.
 * ==============================================================================
 */

declare(strict_types=1);
ini_set('display_errors', '0');
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Auth-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$authSharedPath = __DIR__ . '/_private/AuthShared.php';
if (is_file($authSharedPath)) require_once $authSharedPath;
if (function_exists('fsgAuth_startSharedSession')) fsgAuth_startSharedSession();
elseif (session_status() !== PHP_SESSION_ACTIVE) session_start();

register_shutdown_function(function(): void {
    $err = error_get_last();
    if ($err !== null && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
        http_response_code(500);
        echo json_encode([
            'ok' => false,
            'error' => 'Fatal PHP Execution Crash',
            'details' => $err['message'] . ' in ' . $err['file'] . ' on line ' . $err['line'],
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
    }
});

function nf_json(array $payload, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit;
}

function nf_text(mixed $value): string
{
    if ($value === null) return '';
    if (is_bool($value)) return $value ? '1' : '0';
    if (is_scalar($value)) return (string)$value;
    return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '';
}

function nf_body(): array
{
    if (function_exists('fsgAuth_requestBody')) return fsgAuth_requestBody();
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') return [];
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) nf_json(['ok' => false, 'error' => 'Invalid JSON body.'], 400);
    return $decoded;
}

function nf_pdo(): PDO
{
    if (function_exists('fsgAuth_dbConnection')) return fsgAuth_dbConnection();
    $paths = [
        __DIR__ . '/_private/databaseCredentials.php',
        (string)($_SERVER['DOCUMENT_ROOT'] ?? '') . '/_private/databaseCredentials.php',
        __DIR__ . '/databaseCredentials.php',
    ];
    $checked = [];
    foreach ($paths as $path) {
        if ($path === '/_private/databaseCredentials.php') continue;
        $checked[] = $path;
        if (is_file($path)) { require $path; break; }
    }
    foreach (['dbHost', 'dbUser', 'dbPass', 'dbName'] as $varName) {
        if (!isset(${$varName})) throw new RuntimeException('Missing database credential variable: ' . $varName . '. Checked: ' . implode(' | ', $checked));
    }
    $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
    return new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function nf_identifier_is_safe(string $identifier): bool
{
    return $identifier !== '' && (bool)preg_match('/^[A-Za-z0-9_]+$/', $identifier);
}

function nf_quote_identifier(string $identifier): string
{
    if (!nf_identifier_is_safe($identifier)) throw new RuntimeException('Unsafe SQL identifier: ' . $identifier);
    return '`' . str_replace('`', '``', $identifier) . '`';
}

function nf_table_exists(PDO $pdo, string $tableName): bool
{
    if (!nf_identifier_is_safe($tableName)) return false;
    try {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?');
        $stmt->execute([$tableName]);
        if ((int)$stmt->fetchColumn() > 0) return true;
    } catch (Throwable $e) {}
    try {
        $stmt = $pdo->query('SHOW TABLES');
        foreach (($stmt ? $stmt->fetchAll(PDO::FETCH_NUM) : []) as $row) {
            if (strcasecmp((string)($row[0] ?? ''), $tableName) === 0) return true;
        }
    } catch (Throwable $e) {}
    return false;
}

function nf_column_exists(PDO $pdo, string $tableName, string $columnName): bool
{
    if (!nf_identifier_is_safe($tableName) || !nf_identifier_is_safe($columnName)) return false;
    try {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?');
        $stmt->execute([$tableName, $columnName]);
        if ((int)$stmt->fetchColumn() > 0) return true;
    } catch (Throwable $e) {}
    try {
        $stmt = $pdo->query('SHOW COLUMNS FROM ' . nf_quote_identifier($tableName));
        foreach (($stmt ? $stmt->fetchAll() : []) as $row) {
            if (strcasecmp((string)($row['Field'] ?? ''), $columnName) === 0) return true;
        }
    } catch (Throwable $e) {}
    return false;
}

function nf_user_id_type(PDO $pdo): string
{
    if (function_exists('fsgAuth_sharedFsgUserIdSqlType')) return fsgAuth_sharedFsgUserIdSqlType($pdo);
    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM FSG_users LIKE 'id'");
        $col = $stmt ? $stmt->fetch() : null;
        $type = strtolower((string)($col['Type'] ?? 'int'));
        $unsigned = str_contains($type, 'unsigned');
        if (str_contains($type, 'bigint')) return $unsigned ? 'BIGINT UNSIGNED' : 'BIGINT';
        return $unsigned ? 'INT UNSIGNED' : 'INT';
    } catch (Throwable $e) { return 'INT'; }
}

function nf_ensure_schema(PDO $pdo): void
{
    if (function_exists('fsgAuth_ensureAccountTables')) {
        try { fsgAuth_ensureAccountTables($pdo); } catch (Throwable $e) {}
    }
    $userType = nf_user_id_type($pdo);

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_NF_server_sessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$userType} NOT NULL,
        session_id VARCHAR(96) NOT NULL,
        linked_app VARCHAR(64) NOT NULL DEFAULT '',
        linked_session_id VARCHAR(96) NOT NULL DEFAULT '',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_NF_server_sessions_user_session (user_id, session_id),
        KEY idx_FSG_NF_server_sessions_user_updated (user_id, updated_at),
        KEY idx_FSG_NF_server_sessions_linked (linked_app, linked_session_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_NF_workspaces (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$userType} NOT NULL,
        session_id VARCHAR(96) NOT NULL,
        title VARCHAR(255) NOT NULL DEFAULT 'Narrative Flow Workspace',
        payload_hash CHAR(64) NOT NULL DEFAULT '',
        payload_json LONGTEXT NOT NULL,
        source_imports_json LONGTEXT NULL,
        logic_registry_json LONGTEXT NULL,
        metadata_json LONGTEXT NULL,
        tooling_data_json LONGTEXT NULL,
        flow_nodes_json LONGTEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_NF_workspaces_user_session (user_id, session_id),
        KEY idx_FSG_NF_workspaces_session (session_id),
        KEY idx_FSG_NF_workspaces_user_updated (user_id, updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    foreach (['source_imports', 'logic_registry', 'metadata', 'tooling_data', 'flow_nodes'] as $name) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_NF_{$name} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id {$userType} NOT NULL,
            session_id VARCHAR(96) NOT NULL,
            data_json LONGTEXT NOT NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_FSG_NF_{$name}_user_session (user_id, session_id),
            KEY idx_FSG_NF_{$name}_session (session_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
}

function nf_current_user_id(PDO $pdo): int
{
    if (function_exists('fsgAuth_currentUserIdFromRequest')) return (int)fsgAuth_currentUserIdFromRequest($pdo);
    return (int)($_SESSION['fsg_user_id'] ?? $_SESSION['user_id'] ?? 0);
}

function nf_current_user_payload(PDO $pdo): array
{
    if (function_exists('fsgAuth_authPayload')) return fsgAuth_authPayload($pdo);
    $uid = nf_current_user_id($pdo);
    return ['loggedIn' => $uid > 0, 'user' => $uid > 0 ? ['id' => $uid] : null, 'sessions' => []];
}

function nf_generate_session_id(PDO $pdo): string
{
    if (function_exists('fsgAuth_generateUniqueSessionId')) return fsgAuth_generateUniqueSessionId($pdo);
    return 'NF-' . strtoupper(bin2hex(random_bytes(3))) . '-' . strtoupper(bin2hex(random_bytes(5)));
}

function nf_json_encode(mixed $value): string
{
    return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR) ?: '{}';
}

function nf_json_decode_array(mixed $json): array
{
    if (!is_string($json) || trim($json) === '') return [];
    $decoded = json_decode($json, true);
    return is_array($decoded) ? $decoded : [];
}

function nf_normalize_session_id(string $sessionId): string
{
    $sessionId = strtoupper(trim($sessionId));
    return preg_replace('/[^A-Z0-9_\-]/', '', $sessionId) ?: '';
}

function nf_list_nf_sessions(PDO $pdo, int $userId): array
{
    if ($userId <= 0) return [];
    $stmt = $pdo->prepare('SELECT session_id, linked_app, linked_session_id, created_at AS first_pushed_at, updated_at AS last_pushed_at, updated_at AS last_viewed_at, 1 AS workspace_count FROM FSG_NF_server_sessions WHERE user_id = ? ORDER BY updated_at DESC, id DESC');
    $stmt->execute([$userId]);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) $row['app_key'] = 'NarrativeFlow';
    return $rows;
}

function nf_parse_session_time(array $row): int
{
    return strtotime((string)($row['last_viewed_at'] ?? $row['last_pushed_at'] ?? $row['first_pushed_at'] ?? '')) ?: 0;
}

function nf_latest_external_session(PDO $pdo, int $userId): array
{
    $choices = [];
    if ($userId <= 0) return [];
    if (function_exists('fsgAuth_listUserSessions')) {
        try {
            foreach (fsgAuth_listUserSessions($pdo, $userId, 'DialogueDesigner') as $row) {
                $row['app_key'] = $row['app_key'] ?? 'DialogueDesigner';
                $choices[] = $row;
            }
        } catch (Throwable $e) {}
        try {
            foreach (fsgAuth_listUserSessions($pdo, $userId, 'MenuDesigner') as $row) {
                $row['app_key'] = $row['app_key'] ?? 'MenuDesigner';
                $choices[] = $row;
            }
        } catch (Throwable $e) {}
        try {
            foreach (fsgAuth_listUserSessions($pdo, $userId, 'TaskManager') as $row) {
                $row['app_key'] = $row['app_key'] ?? 'TaskManager';
                $choices[] = $row;
            }
        } catch (Throwable $e) {}
    }
    if (nf_table_exists($pdo, 'FSG_MD_Workspaces')) {
        try {
            $stmt = $pdo->prepare('SELECT session_id, MIN(created_at) AS first_pushed_at, MAX(updated_at) AS last_pushed_at, MAX(updated_at) AS last_viewed_at, COUNT(*) AS workspace_count FROM FSG_MD_Workspaces WHERE user_id = ? AND session_id <> "" GROUP BY session_id ORDER BY last_viewed_at DESC LIMIT 20');
            $stmt->execute([$userId]);
            foreach ($stmt->fetchAll() as $row) {
                $row['app_key'] = 'MenuDesigner';
                $choices[] = $row;
            }
        } catch (Throwable $e) {}
    }
    usort($choices, fn($a, $b) => nf_parse_session_time($b) <=> nf_parse_session_time($a));
    return $choices[0] ?? [];
}

function nf_latest_session(PDO $pdo, int $userId): array
{
    $nf = nf_list_nf_sessions($pdo, $userId);
    if (!empty($nf)) return ['source' => 'NarrativeFlow', 'session_id' => (string)$nf[0]['session_id'], 'row' => $nf[0]];
    $external = nf_latest_external_session($pdo, $userId);
    $sid = trim((string)($external['session_id'] ?? ''));
    if ($sid !== '') return ['source' => (string)($external['app_key'] ?? 'DialogueDesigner'), 'session_id' => $sid, 'row' => $external];
    return [];
}

function nf_load_workspace(PDO $pdo, int $userId, string $sessionId): array
{
    $sessionId = nf_normalize_session_id($sessionId);
    if ($userId <= 0 || $sessionId === '') return [];
    $stmt = $pdo->prepare('SELECT * FROM FSG_NF_workspaces WHERE user_id = ? AND session_id = ? ORDER BY updated_at DESC, id DESC LIMIT 1');
    $stmt->execute([$userId, $sessionId]);
    $row = $stmt->fetch();
    if (!$row) return [];
    $payload = json_decode((string)$row['payload_json'], true);
    if (!is_array($payload)) $payload = [];
    return ['row' => $row, 'payload' => $payload];
}

function nf_touch_session(PDO $pdo, int $userId, string $sessionId, string $linkedApp = '', string $linkedSessionId = '', string $mode = 'view'): void
{
    $sessionId = nf_normalize_session_id($sessionId);
    if ($userId <= 0 || $sessionId === '') return;
    $stmt = $pdo->prepare('INSERT INTO FSG_NF_server_sessions (user_id, session_id, linked_app, linked_session_id) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE linked_app = VALUES(linked_app), linked_session_id = VALUES(linked_session_id), updated_at = CURRENT_TIMESTAMP');
    $stmt->execute([$userId, $sessionId, $linkedApp, $linkedSessionId]);
    if (function_exists('fsgAuth_touchServerSession')) {
        try { fsgAuth_touchServerSession($pdo, $userId, 'NarrativeFlow', $sessionId, $mode); } catch (Throwable $e) {}
    }
}

function nf_save_workspace(PDO $pdo, int $userId, string $sessionId, array $payload, string $linkedApp = '', string $linkedSessionId = ''): void
{
    $sessionId = nf_normalize_session_id($sessionId);
    if ($sessionId === '') throw new RuntimeException('Missing session id.');
    if ($userId <= 0) throw new RuntimeException('You must be logged in to push Narrative Flow to the server.');

    $payload['serverSessionId'] = $sessionId;
    $payloadJson = nf_json_encode($payload);
    $hash = hash('sha256', $payloadJson);
    $sourceJson = nf_json_encode($payload['sourceImports'] ?? []);
    $logicJson = nf_json_encode($payload['logicRegistry'] ?? []);
    $metadataJson = nf_json_encode($payload['metadata'] ?? []);
    $toolingJson = nf_json_encode($payload['toolingData'] ?? []);
    $nodesJson = nf_json_encode($payload['flowNodes'] ?? []);

    $stmt = $pdo->prepare('INSERT INTO FSG_NF_workspaces (user_id, session_id, title, payload_hash, payload_json, source_imports_json, logic_registry_json, metadata_json, tooling_data_json, flow_nodes_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE title = VALUES(title), payload_hash = VALUES(payload_hash), payload_json = VALUES(payload_json), source_imports_json = VALUES(source_imports_json), logic_registry_json = VALUES(logic_registry_json), metadata_json = VALUES(metadata_json), tooling_data_json = VALUES(tooling_data_json), flow_nodes_json = VALUES(flow_nodes_json), updated_at = CURRENT_TIMESTAMP');
    $stmt->execute([$userId, $sessionId, 'Narrative Flow Workspace', $hash, $payloadJson, $sourceJson, $logicJson, $metadataJson, $toolingJson, $nodesJson]);

    $sectionMap = [
        'source_imports' => $payload['sourceImports'] ?? [],
        'logic_registry' => $payload['logicRegistry'] ?? [],
        'metadata' => $payload['metadata'] ?? [],
        'tooling_data' => $payload['toolingData'] ?? [],
        'flow_nodes' => $payload['flowNodes'] ?? [],
    ];
    foreach ($sectionMap as $tableSuffix => $sectionPayload) {
        $table = 'FSG_NF_' . $tableSuffix;
        $json = nf_json_encode($sectionPayload);
        $sql = 'INSERT INTO ' . nf_quote_identifier($table) . ' (user_id, session_id, data_json) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE data_json = VALUES(data_json), updated_at = CURRENT_TIMESTAMP';
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$userId, $sessionId, $json]);
    }

    nf_touch_session($pdo, $userId, $sessionId, $linkedApp, $linkedSessionId, 'push');
}

function nf_latest_menu_designer_workspace(PDO $pdo, int $userId, string $sessionId = ''): array
{
    if ($userId <= 0 || !nf_table_exists($pdo, 'FSG_MD_Workspaces')) return [];
    $sessionId = nf_normalize_session_id($sessionId);
    if ($sessionId !== '') {
        $stmt = $pdo->prepare('SELECT * FROM FSG_MD_Workspaces WHERE session_id = ? AND (user_id = ? OR user_id IS NULL OR user_id = 0) ORDER BY updated_at DESC, id DESC LIMIT 1');
        $stmt->execute([$sessionId, $userId]);
        $row = $stmt->fetch();
        if (is_array($row)) return $row;

        $stmt = $pdo->prepare('SELECT * FROM FSG_MD_Workspaces WHERE session_id = ? ORDER BY updated_at DESC, id DESC LIMIT 1');
        $stmt->execute([$sessionId]);
    } else {
        $stmt = $pdo->prepare('SELECT * FROM FSG_MD_Workspaces WHERE user_id = ? ORDER BY updated_at DESC, id DESC LIMIT 1');
        $stmt->execute([$userId]);
    }
    $row = $stmt->fetch();
    return is_array($row) ? $row : [];
}

function nf_latest_menu_designer_legacy_workspace(PDO $pdo, string $sessionId = ''): array
{
    if (!nf_table_exists($pdo, 'FSG_DD_Workspaces')) return [];
    $sessionId = nf_normalize_session_id($sessionId);
    if ($sessionId !== '') {
        $stmt = $pdo->prepare('SELECT id, workspace_uuid, session_id, raw_json, created_at, updated_at FROM FSG_DD_Workspaces WHERE session_id = ? ORDER BY updated_at DESC, id DESC LIMIT 1');
        $stmt->execute([$sessionId]);
    } else {
        $stmt = $pdo->query('SELECT id, workspace_uuid, session_id, raw_json, created_at, updated_at FROM FSG_DD_Workspaces ORDER BY updated_at DESC, id DESC LIMIT 1');
    }
    $row = $stmt ? $stmt->fetch() : null;
    if (!is_array($row)) return [];
    $payload = nf_json_decode_array($row['raw_json'] ?? '');
    if (($payload['app'] ?? '') !== 'MenuDesigner' && !isset($payload['menus'])) return [];
    $row['dd_workspace_id'] = (int)($row['id'] ?? 0);
    $row['source_table'] = 'FSG_DD_Workspaces';
    return $row;
}

function nf_fetch_debug_rows(PDO $pdo, string $sql, array $params = []): array
{
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        return is_array($rows) ? $rows : [];
    } catch (Throwable $e) {
        return [['debug_error' => $e->getMessage()]];
    }
}

function nf_count_md_rows(PDO $pdo, string $tableName, string $where, array $params): int
{
    if (!nf_table_exists($pdo, $tableName)) return 0;
    try {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM ' . nf_quote_identifier($tableName) . ' ' . $where);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

function nf_hydrate_md_named_rows(PDO $pdo, string $tableName, int $workspaceId, array $columns): array
{
    if ($workspaceId <= 0 || !nf_table_exists($pdo, $tableName)) return [];
    $select = implode(', ', array_map('nf_quote_identifier', $columns));
    $stmt = $pdo->prepare("SELECT id, {$select}, raw_json FROM " . nf_quote_identifier($tableName) . ' WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC');
    $stmt->execute([$workspaceId]);
    $items = [];
    foreach ($stmt->fetchAll() as $row) {
        $raw = nf_json_decode_array($row['raw_json'] ?? '');
        $items[] = array_merge($raw, array_filter([
            'id' => $raw['id'] ?? null,
            'name' => $raw['name'] ?? $raw['title'] ?? $row[$columns[0]] ?? '',
            'key' => $raw['key'] ?? $row[$columns[0]] ?? null,
            'value' => $raw['value'] ?? $row[$columns[1] ?? ''] ?? null,
            'color' => $raw['color'] ?? $row['color'] ?? null,
        ], static fn($value) => $value !== null));
    }
    return array_values(array_filter($items, static fn($item) => trim(nf_text($item['name'] ?? $item['key'] ?? '')) !== ''));
}

function nf_merge_md_shared_sidebar(PDO $pdo, array $workspaceRow, array $payload): array
{
    $ddWorkspaceId = (int)($workspaceRow['dd_workspace_id'] ?? 0);
    if ($ddWorkspaceId <= 0) return $payload;

    $sharedMap = [
        'globalCast' => ['FSG_DD_Cast', ['character_name', 'color']],
        'globalTokens' => ['FSG_DD_GlobalTokens', ['token_key', 'token_value']],
        'globalStates' => ['FSG_DD_GlobalStates', ['item_name', 'color']],
        'globalMoods' => ['FSG_DD_GlobalMoods', ['item_name', 'color']],
        'globalSettings' => ['FSG_DD_GlobalSettings', ['item_name', 'color']],
        'globalTimes' => ['FSG_DD_GlobalTimesOfDay', ['item_name', 'color']],
        'globalDays' => ['FSG_DD_GlobalDaysOfWeek', ['item_name', 'color']],
        'globalMenuOptions' => ['FSG_DD_GlobalMenuOptions', ['item_name', 'color']],
        'globalImageSequences' => ['FSG_DD_GlobalImageSequences', ['sequence_name', 'color']],
    ];

    foreach ($sharedMap as $payloadKey => [$tableName, $columns]) {
        $items = nf_hydrate_md_named_rows($pdo, $tableName, $ddWorkspaceId, $columns);
        if ($items) $payload[$payloadKey] = $items;
    }
    if (!empty($payload['globalCast'])) $payload['cast'] = $payload['globalCast'];
    if (!empty($payload['globalTimes'])) $payload['globalTimesOfDay'] = $payload['globalTimes'];
    if (!empty($payload['globalDays'])) $payload['globalDaysOfWeek'] = $payload['globalDays'];
    return $payload;
}

function nf_hydrate_md_imported_conversations(PDO $pdo, int $workspaceId): array
{
    if ($workspaceId <= 0 || !nf_table_exists($pdo, 'FSG_MD_ImportedConversations')) return [];
    $stmt = $pdo->prepare('SELECT title, color, participants_json, raw_json FROM FSG_MD_ImportedConversations WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC');
    $stmt->execute([$workspaceId]);
    $items = [];
    foreach ($stmt->fetchAll() as $row) {
        $raw = nf_json_decode_array($row['raw_json'] ?? '');
        $participants = nf_json_decode_array($row['participants_json'] ?? '');
        $items[] = array_merge($raw, [
            'title' => nf_text($raw['title'] ?? $row['title'] ?? ''),
            'color' => nf_text($raw['color'] ?? $row['color'] ?? ''),
            'participants' => is_array($raw['participants'] ?? null) ? $raw['participants'] : $participants,
        ]);
    }
    return array_values(array_filter($items, static fn($item) => trim(nf_text($item['title'] ?? '')) !== ''));
}

function nf_hydrate_md_menus(PDO $pdo, int $workspaceId): array
{
    if (
        $workspaceId <= 0 ||
        !nf_table_exists($pdo, 'FSG_MD_MenuOptions') ||
        !nf_table_exists($pdo, 'FSG_MD_MenuContexts') ||
        !nf_table_exists($pdo, 'FSG_MD_MenuCharacters')
    ) return [];
    $sql = 'SELECT ctx.context_key, ch.character_name, opt.id AS option_pk, opt.parent_option_id, opt.option_uuid, opt.sort_order, opt.title, opt.raw_json
            FROM FSG_MD_MenuOptions opt
            JOIN FSG_MD_MenuContexts ctx ON ctx.id = opt.context_id
            JOIN FSG_MD_MenuCharacters ch ON ch.id = opt.character_id
            WHERE opt.workspace_id = ?
            ORDER BY ctx.sort_order ASC, ch.sort_order ASC, opt.depth ASC, opt.sort_order ASC, opt.id ASC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$workspaceId]);

    $byPk = [];
    $children = [];
    $meta = [];
    foreach ($stmt->fetchAll() as $row) {
        $option = nf_json_decode_array($row['raw_json'] ?? '');
        $option['id'] = nf_text($option['id'] ?? $row['option_uuid'] ?? ('md-option-' . $row['option_pk']));
        $option['title'] = nf_text($option['title'] ?? $row['title'] ?? '');
        $option['subMenuOptions'] = [];
        $pk = (int)$row['option_pk'];
        $parentPk = (int)($row['parent_option_id'] ?? 0);
        $byPk[$pk] = $option;
        $children[$parentPk][] = $pk;
        $meta[$pk] = [
            'context' => nf_text($row['context_key'] ?? 'ROOT'),
            'character' => nf_text($row['character_name'] ?? 'General'),
        ];
    }

    $build = function (int $pk) use (&$build, &$byPk, &$children): array {
        $item = $byPk[$pk] ?? [];
        $item['subMenuOptions'] = [];
        foreach ($children[$pk] ?? [] as $childPk) $item['subMenuOptions'][] = $build($childPk);
        return $item;
    };

    $menus = [];
    foreach ($children[0] ?? [] as $rootPk) {
        $contextKey = $meta[$rootPk]['context'] ?? 'ROOT';
        $character = $meta[$rootPk]['character'] ?? 'General';
        if (!isset($menus[$contextKey])) $menus[$contextKey] = [];
        if (!isset($menus[$contextKey][$character])) $menus[$contextKey][$character] = [];
        $menus[$contextKey][$character][] = $build($rootPk);
    }
    return $menus;
}

function nf_load_menu_designer_payload(PDO $pdo, int $userId, string $sessionId = ''): array
{
    $workspace = nf_latest_menu_designer_workspace($pdo, $userId, $sessionId);
    if (!$workspace) $workspace = nf_latest_menu_designer_legacy_workspace($pdo, $sessionId);
    if (!$workspace) return [];
    $payload = nf_json_decode_array($workspace['raw_json'] ?? '');
    $workspaceId = (int)($workspace['id'] ?? 0);

    $sourceTable = nf_text($workspace['source_table'] ?? 'FSG_MD_Workspaces');
    $menus = $sourceTable === 'FSG_MD_Workspaces' ? nf_hydrate_md_menus($pdo, $workspaceId) : [];
    if ($menus) {
        $payload['menus'] = $menus;
    } elseif (!isset($payload['menus'])) {
        $payload['menus'] = [];
    }

    $importedConvs = $sourceTable === 'FSG_MD_Workspaces' ? nf_hydrate_md_imported_conversations($pdo, $workspaceId) : [];
    if ($importedConvs) $payload['importedConvs'] = $importedConvs;

    $payload = nf_merge_md_shared_sidebar($pdo, $workspace, $payload);
    $payload['app'] = 'MenuDesigner';
    $payload['serverSessionId'] = nf_text($workspace['session_id'] ?? '');
    $payload['sessionId'] = nf_text($workspace['session_id'] ?? '');
    return [
        'workspace' => $workspace,
        'payload' => $payload,
        'debug' => [
            'workspaceId' => $workspaceId,
            'sessionId' => nf_text($workspace['session_id'] ?? ''),
            'sourceTable' => $sourceTable,
            'rawJsonHasMenus' => !empty($payload['menus']),
            'tableCounts' => [
                'FSG_MD_MenuContexts' => nf_count_md_rows($pdo, 'FSG_MD_MenuContexts', 'WHERE workspace_id = ?', [$workspaceId]),
                'FSG_MD_MenuCharacters' => nf_count_md_rows($pdo, 'FSG_MD_MenuCharacters', 'mc JOIN FSG_MD_MenuContexts ctx ON ctx.id = mc.context_id WHERE ctx.workspace_id = ?', [$workspaceId]),
                'FSG_MD_MenuOptions' => nf_count_md_rows($pdo, 'FSG_MD_MenuOptions', 'WHERE workspace_id = ?', [$workspaceId]),
                'FSG_MD_ImportedConversations' => nf_count_md_rows($pdo, 'FSG_MD_ImportedConversations', 'WHERE workspace_id = ?', [$workspaceId]),
                'FSG_MD_ActiveProjectLogic' => nf_count_md_rows($pdo, 'FSG_MD_ActiveProjectLogic', 'WHERE workspace_id = ?', [$workspaceId]),
            ],
        ],
    ];
}

function nf_flatten_menu_designer_menus_for_workspace(array $payload): array
{
    $menus = [];
    $walk = function (array $options, string $groupName, string $characterName, int $depth = 0) use (&$walk, &$menus): void {
        foreach (array_values($options) as $option) {
            if (!is_array($option)) continue;
            $entry = $option;
            $entry['groupName'] = $depth > 0 ? $groupName . ' (Sub)' : $groupName;
            $entry['characterName'] = $characterName !== '' ? $characterName : 'General';
            $entry['_sourceFile'] = 'MenuDesigner SQL';
            $entry['_sourceApp'] = 'MenuDesigner';
            $menus[] = $entry;
            $children = $option['subMenuOptions'] ?? [];
            if (is_array($children) && $children) $walk($children, $groupName, $characterName, $depth + 1);
        }
    };

    $menuSrc = $payload['menus'] ?? $payload['conversations'] ?? [];
    if (is_array($menuSrc)) {
        foreach ($menuSrc as $contextName => $characters) {
            $groupName = (string)$contextName === 'ROOT' ? 'GLOBAL MENUS' : nf_text($contextName);
            if (is_array($characters)) {
                $isCharacterMap = false;
                foreach ($characters as $key => $value) {
                    if (!is_int($key) && is_array($value)) { $isCharacterMap = true; break; }
                }
                if ($isCharacterMap) {
                    foreach ($characters as $characterName => $options) {
                        if (is_array($options)) $walk($options, $groupName, nf_text($characterName), 0);
                    }
                } else {
                    $walk($characters, $groupName, 'General', 0);
                }
            }
        }
    }
    return $menus;
}

function nf_merge_menu_designer_into_workspace(PDO $pdo, int $userId, string $sessionId, ?array $workspacePayload): ?array
{
    if ($userId <= 0 || $sessionId === '') return $workspacePayload;
    $workspacePayload = is_array($workspacePayload) ? $workspacePayload : [];
    $loaded = nf_load_menu_designer_payload($pdo, $userId, $sessionId);
    if (!$loaded || !is_array($loaded['payload'] ?? null)) return $workspacePayload;

    $mdPayload = $loaded['payload'];
    $flatMenus = nf_flatten_menu_designer_menus_for_workspace($mdPayload);
    if (!$flatMenus) return $workspacePayload;

    if (!isset($workspacePayload['sourceImports']) || !is_array($workspacePayload['sourceImports'])) $workspacePayload['sourceImports'] = [];
    foreach (['dialogues', 'sequences', 'tasks', 'menus', 'prompts', 'importedLogic', 'importedGameplayValues'] as $key) {
        if (!isset($workspacePayload['sourceImports'][$key]) || !is_array($workspacePayload['sourceImports'][$key])) $workspacePayload['sourceImports'][$key] = [];
    }

    $workspacePayload['sourceImports']['menus'] = array_values(array_filter(
        $workspacePayload['sourceImports']['menus'],
        static fn($item) => !is_array($item) || (($item['_sourceApp'] ?? '') !== 'MenuDesigner' && ($item['_sourceFile'] ?? '') !== 'MenuDesigner SQL')
    ));
    $workspacePayload['sourceImports']['menus'] = array_merge($workspacePayload['sourceImports']['menus'], $flatMenus);

    foreach (($mdPayload['Active Project Logic'] ?? []) as $logicRow) {
        if (is_array($logicRow)) {
            $logicRow['_sourceFile'] = 'MenuDesigner SQL';
            $workspacePayload['sourceImports']['importedLogic'][] = $logicRow;
        }
    }
    foreach (($mdPayload['Gameplay Values'] ?? []) as $gameplayRow) {
        if (is_array($gameplayRow)) {
            $gameplayRow['_sourceFile'] = 'MenuDesigner SQL';
            $workspacePayload['sourceImports']['importedGameplayValues'][] = $gameplayRow;
        }
    }

    $workspacePayload['metadata']['menuDesignerSqlImport'] = [
        'sessionId' => nf_text($loaded['workspace']['session_id'] ?? $sessionId),
        'menuDesignerDatabaseId' => (int)($loaded['workspace']['id'] ?? 0),
        'sourceTable' => nf_text($loaded['debug']['sourceTable'] ?? ''),
        'menuCount' => count($flatMenus),
        'debug' => $loaded['debug'] ?? null,
    ];
    return $workspacePayload;
}

function nf_latest_task_manager_payload(PDO $pdo, int $userId, string $sessionId = ''): array
{
    $sessionId = nf_normalize_session_id($sessionId);
    $debug = [
        'requestedUserId' => $userId,
        'requestedSessionId' => $sessionId,
        'FSG_TASK_server_sessions_exists' => nf_table_exists($pdo, 'FSG_TASK_server_sessions'),
        'FSG_TM_Workspaces_exists' => nf_table_exists($pdo, 'FSG_TM_Workspaces'),
        'FSG_TM_Tasks_exists' => nf_table_exists($pdo, 'FSG_TM_Tasks'),
        'FSG_Server_Sessions_exists' => nf_table_exists($pdo, 'FSG_Server_Sessions'),
        'exactSessionRows' => $sessionId !== '' ? nf_count_md_rows($pdo, 'FSG_TASK_server_sessions', 'WHERE session_id = ?', [$sessionId]) : 0,
        'exactSessionUserRows' => $sessionId !== '' ? nf_count_md_rows($pdo, 'FSG_TASK_server_sessions', 'WHERE session_id = ? AND (user_id = ? OR user_id IS NULL OR user_id = 0)', [$sessionId, $userId]) : 0,
        'userRows' => $userId > 0 ? nf_count_md_rows($pdo, 'FSG_TASK_server_sessions', 'WHERE user_id = ?', [$userId]) : 0,
        'latestRowsForSession' => [],
        'latestRowsForUser' => [],
        'sharedServerSessionRows' => [],
    ];
    if (!nf_table_exists($pdo, 'FSG_TASK_server_sessions')) {
        return ['payload' => [], 'row' => [], 'debug' => $debug + ['status' => 'missing_payload_table']];
    }
    if ($sessionId !== '') {
        $debug['latestRowsForSession'] = nf_fetch_debug_rows(
            $pdo,
            'SELECT session_id, user_id, LENGTH(payload_json) AS payload_json_bytes, updated_at, created_at FROM FSG_TASK_server_sessions WHERE session_id = ? ORDER BY updated_at DESC LIMIT 8',
            [$sessionId]
        );
        if (nf_table_exists($pdo, 'FSG_Server_Sessions')) {
            $debug['sharedServerSessionRows'] = nf_fetch_debug_rows(
                $pdo,
                "SELECT * FROM FSG_Server_Sessions WHERE session_id = ? ORDER BY id DESC LIMIT 8",
                [$sessionId]
            );
        }

        $stmt = $pdo->prepare('SELECT * FROM FSG_TASK_server_sessions WHERE session_id = ? AND (user_id = ? OR user_id IS NULL OR user_id = 0) ORDER BY updated_at DESC LIMIT 1');
        $stmt->execute([$sessionId, $userId]);
        $row = $stmt->fetch();
        if (!is_array($row)) {
            $stmt = $pdo->prepare('SELECT * FROM FSG_TASK_server_sessions WHERE session_id = ? ORDER BY updated_at DESC LIMIT 1');
            $stmt->execute([$sessionId]);
            $row = $stmt->fetch();
            if (is_array($row)) $debug['matchedBy'] = 'session_any_user';
        } else {
            $debug['matchedBy'] = 'session_and_user';
        }
        if (is_array($row)) {
            $payload = nf_json_decode_array($row['payload_json'] ?? '');
            return ['payload' => $payload, 'row' => $row, 'debug' => $debug + ['status' => 'payload_found']];
        }
    }

    if ($userId > 0) {
        $debug['latestRowsForUser'] = nf_fetch_debug_rows(
            $pdo,
            'SELECT session_id, user_id, LENGTH(payload_json) AS payload_json_bytes, updated_at, created_at FROM FSG_TASK_server_sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 8',
            [$userId]
        );
        $stmt = $pdo->prepare('SELECT * FROM FSG_TASK_server_sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1');
        $stmt->execute([$userId]);
        $row = $stmt->fetch();
        if (is_array($row)) {
            $payload = nf_json_decode_array($row['payload_json'] ?? '');
            return ['payload' => $payload, 'row' => $row, 'debug' => $debug + ['status' => 'payload_found', 'matchedBy' => 'latest_for_user_fallback']];
        }
    }

    return ['payload' => [], 'row' => [], 'debug' => $debug + ['status' => 'no_matching_payload']];
}

function nf_tag_task_manager_sources(array $items): array
{
    $tagged = [];
    foreach (array_values($items) as $item) {
        if (!is_array($item)) continue;
        $item['_sourceFile'] = 'TaskManager SQL';
        $item['_sourceApp'] = 'TaskManager';
        $tagged[] = $item;
    }
    return $tagged;
}

function nf_merge_task_manager_into_workspace(PDO $pdo, int $userId, string $sessionId, ?array $workspacePayload): ?array
{
    if ($userId <= 0 || $sessionId === '') return $workspacePayload;
    $workspacePayload = is_array($workspacePayload) ? $workspacePayload : [];
    if (!isset($workspacePayload['metadata']) || !is_array($workspacePayload['metadata'])) $workspacePayload['metadata'] = [];
    $loaded = nf_latest_task_manager_payload($pdo, $userId, $sessionId);
    $payload = is_array($loaded['payload'] ?? null) ? $loaded['payload'] : [];
    $tasks = nf_tag_task_manager_sources(is_array($payload['entries'] ?? null) ? $payload['entries'] : (is_array($payload['tasks'] ?? null) ? $payload['tasks'] : []));

    if (!isset($workspacePayload['sourceImports']) || !is_array($workspacePayload['sourceImports'])) $workspacePayload['sourceImports'] = [];
    foreach (['dialogues', 'sequences', 'tasks', 'menus', 'prompts', 'importedLogic', 'importedGameplayValues'] as $key) {
        if (!isset($workspacePayload['sourceImports'][$key]) || !is_array($workspacePayload['sourceImports'][$key])) $workspacePayload['sourceImports'][$key] = [];
    }
    $workspacePayload['sourceImports']['tasks'] = array_values(array_filter(
        $workspacePayload['sourceImports']['tasks'],
        static fn($item) => !is_array($item) || (($item['_sourceApp'] ?? '') !== 'TaskManager' && ($item['_sourceFile'] ?? '') !== 'TaskManager SQL')
    ));
    $workspacePayload['sourceImports']['tasks'] = array_merge($workspacePayload['sourceImports']['tasks'], $tasks);

    if (isset($payload['tabColors']) && is_array($payload['tabColors'])) {
        $existingColors = is_array($workspacePayload['metadata']['taskTabColors'] ?? null) ? $workspacePayload['metadata']['taskTabColors'] : [];
        $workspacePayload['metadata']['taskTabColors'] = array_merge($existingColors, $payload['tabColors']);
    }

    $row = is_array($loaded['row'] ?? null) ? $loaded['row'] : [];
    $workspacePayload['metadata']['taskManagerSqlImport'] = [
        'sessionId' => nf_text($row['session_id'] ?? $sessionId),
        'sourceTable' => 'FSG_TASK_server_sessions',
        'taskCount' => count($tasks),
        'tabCount' => is_array($payload['tabs'] ?? null) ? count($payload['tabs']) : 0,
        'tabColorCount' => is_array($payload['tabColors'] ?? null) ? count($payload['tabColors']) : 0,
        'status' => $tasks ? 'imported' : 'no_tasks_found',
        'debug' => [
            'payloadKeys' => array_slice(array_keys($payload), 0, 40),
            'entryCount' => is_array($payload['entries'] ?? null) ? count($payload['entries']) : 0,
            'taskCountLegacy' => is_array($payload['tasks'] ?? null) ? count($payload['tasks']) : 0,
            'firstTaskNames' => array_slice(array_map(static fn($item) => nf_text($item['name'] ?? ($item['title'] ?? '')), $tasks), 0, 12),
            'payloadJsonBytes' => strlen(nf_text($row['payload_json'] ?? '')),
            'rowUserId' => (int)($row['user_id'] ?? 0),
        ] + ($loaded['debug'] ?? []),
    ];
    return $workspacePayload;
}

function nf_load_prompt_designer_structured_payload(PDO $pdo, string $sessionId): array
{
    $sessionId = nf_normalize_session_id($sessionId);
    $payload = ['prompts' => [], 'tags' => []];
    $debug = [
        'structuredPromptRows' => 0,
        'structuredTagRows' => 0,
        'structuredPromptTitles' => [],
        'structuredTagNames' => [],
    ];
    if ($sessionId === '') return ['payload' => $payload, 'debug' => $debug];
    if (nf_table_exists($pdo, 'FSG_PD_Tags')) {
        $stmt = $pdo->prepare('SELECT tag_name, color, raw_json FROM FSG_PD_Tags WHERE session_id = ? ORDER BY sort_order ASC, id ASC');
        $stmt->execute([$sessionId]);
        foreach ($stmt->fetchAll() as $row) {
            $tag = nf_json_decode_array($row['raw_json'] ?? '');
            if (!$tag) $tag = [];
            $tag['name'] = nf_text($tag['name'] ?? ($row['tag_name'] ?? ''));
            $tag['color'] = nf_text($tag['color'] ?? ($row['color'] ?? '#00f2ff'));
            if ($tag['name'] !== '') $payload['tags'][] = $tag;
        }
        $debug['structuredTagRows'] = count($payload['tags']);
        $debug['structuredTagNames'] = array_slice(array_map(static fn($tag) => nf_text($tag['name'] ?? ''), $payload['tags']), 0, 12);
    }
    if (nf_table_exists($pdo, 'FSG_PD_Prompts')) {
        $stmt = $pdo->prepare('SELECT id, tag_name, title, raw_json FROM FSG_PD_Prompts WHERE session_id = ? ORDER BY sort_order ASC, id ASC');
        $stmt->execute([$sessionId]);
        foreach ($stmt->fetchAll() as $row) {
            $prompt = nf_json_decode_array($row['raw_json'] ?? '');
            if (!$prompt) $prompt = [];
            $prompt['id'] = nf_text($prompt['id'] ?? ($row['id'] ?? ''));
            $prompt['tag'] = nf_text($prompt['tag'] ?? ($row['tag_name'] ?? ''));
            $prompt['title'] = nf_text($prompt['title'] ?? ($row['title'] ?? ''));
            if ($prompt['id'] !== '' || $prompt['title'] !== '') $payload['prompts'][] = $prompt;
        }
        $debug['structuredPromptRows'] = count($payload['prompts']);
        $debug['structuredPromptTitles'] = array_slice(array_map(static fn($prompt) => nf_text($prompt['title'] ?? ''), $payload['prompts']), 0, 12);
    }
    return ['payload' => $payload, 'debug' => $debug];
}

function nf_latest_prompt_designer_payload(PDO $pdo, int $userId, string $sessionId = ''): array
{
    $sessionId = nf_normalize_session_id($sessionId);
    $debug = [
        'requestedUserId' => $userId,
        'requestedSessionId' => $sessionId,
        'FSG_PD_server_sessions_exists' => nf_table_exists($pdo, 'FSG_PD_server_sessions'),
        'FSG_PD_Prompts_exists' => nf_table_exists($pdo, 'FSG_PD_Prompts'),
        'FSG_PD_Tags_exists' => nf_table_exists($pdo, 'FSG_PD_Tags'),
        'FSG_Server_Sessions_exists' => nf_table_exists($pdo, 'FSG_Server_Sessions'),
        'exactSessionRows' => $sessionId !== '' ? nf_count_md_rows($pdo, 'FSG_PD_server_sessions', 'WHERE session_id = ?', [$sessionId]) : 0,
        'exactSessionUserRows' => $sessionId !== '' ? nf_count_md_rows($pdo, 'FSG_PD_server_sessions', 'WHERE session_id = ? AND (user_id = ? OR user_id IS NULL OR user_id = 0)', [$sessionId, $userId]) : 0,
        'dialogueSessionRows' => $sessionId !== '' ? nf_count_md_rows($pdo, 'FSG_PD_server_sessions', 'WHERE dialogue_session_id = ?', [$sessionId]) : 0,
        'userRows' => $userId > 0 ? nf_count_md_rows($pdo, 'FSG_PD_server_sessions', 'WHERE user_id = ?', [$userId]) : 0,
        'promptRowsForSession' => $sessionId !== '' ? nf_count_md_rows($pdo, 'FSG_PD_Prompts', 'WHERE session_id = ?', [$sessionId]) : 0,
        'tagRowsForSession' => $sessionId !== '' ? nf_count_md_rows($pdo, 'FSG_PD_Tags', 'WHERE session_id = ?', [$sessionId]) : 0,
        'latestRowsForSession' => [],
        'latestRowsForDialogueSession' => [],
        'latestRowsForUser' => [],
        'sharedServerSessionRows' => [],
    ];
    $row = null;
    if (nf_table_exists($pdo, 'FSG_PD_server_sessions')) {
        if ($sessionId !== '') {
            $debug['latestRowsForSession'] = nf_fetch_debug_rows($pdo, 'SELECT session_id, user_id, dialogue_session_id, LENGTH(payload_json) AS payload_json_bytes, updated_at, created_at FROM FSG_PD_server_sessions WHERE session_id = ? ORDER BY updated_at DESC LIMIT 8', [$sessionId]);
            $debug['latestRowsForDialogueSession'] = nf_fetch_debug_rows($pdo, 'SELECT session_id, user_id, dialogue_session_id, LENGTH(payload_json) AS payload_json_bytes, updated_at, created_at FROM FSG_PD_server_sessions WHERE dialogue_session_id = ? ORDER BY updated_at DESC LIMIT 8', [$sessionId]);
            if (nf_table_exists($pdo, 'FSG_Server_Sessions')) {
                $debug['sharedServerSessionRows'] = nf_fetch_debug_rows($pdo, 'SELECT * FROM FSG_Server_Sessions WHERE session_id = ? ORDER BY id DESC LIMIT 8', [$sessionId]);
            }
            $stmt = $pdo->prepare('SELECT * FROM FSG_PD_server_sessions WHERE session_id = ? AND (user_id = ? OR user_id IS NULL OR user_id = 0) ORDER BY updated_at DESC LIMIT 1');
            $stmt->execute([$sessionId, $userId]);
            $row = $stmt->fetch();
            if (is_array($row)) $debug['matchedBy'] = 'session_and_user';
            if (!is_array($row)) {
                $stmt = $pdo->prepare('SELECT * FROM FSG_PD_server_sessions WHERE session_id = ? ORDER BY updated_at DESC LIMIT 1');
                $stmt->execute([$sessionId]);
                $row = $stmt->fetch();
                if (is_array($row)) $debug['matchedBy'] = 'session_any_user';
            }
            if (!is_array($row)) {
                $stmt = $pdo->prepare('SELECT * FROM FSG_PD_server_sessions WHERE dialogue_session_id = ? AND (user_id = ? OR user_id IS NULL OR user_id = 0) ORDER BY updated_at DESC LIMIT 1');
                $stmt->execute([$sessionId, $userId]);
                $row = $stmt->fetch();
                if (is_array($row)) $debug['matchedBy'] = 'dialogue_session_and_user';
            }
            if (!is_array($row)) {
                $stmt = $pdo->prepare('SELECT * FROM FSG_PD_server_sessions WHERE dialogue_session_id = ? ORDER BY updated_at DESC LIMIT 1');
                $stmt->execute([$sessionId]);
                $row = $stmt->fetch();
                if (is_array($row)) $debug['matchedBy'] = 'dialogue_session_any_user';
            }
        }
        if (!is_array($row) && $userId > 0) {
            $debug['latestRowsForUser'] = nf_fetch_debug_rows($pdo, 'SELECT session_id, user_id, dialogue_session_id, LENGTH(payload_json) AS payload_json_bytes, updated_at, created_at FROM FSG_PD_server_sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 8', [$userId]);
            $stmt = $pdo->prepare('SELECT * FROM FSG_PD_server_sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1');
            $stmt->execute([$userId]);
            $row = $stmt->fetch();
            if (is_array($row)) $debug['matchedBy'] = 'latest_for_user_fallback';
        }
    }
    $payload = is_array($row) ? nf_json_decode_array($row['payload_json'] ?? '') : [];
    $structuredSessionId = nf_text($row['session_id'] ?? $sessionId);
    $structured = nf_load_prompt_designer_structured_payload($pdo, $structuredSessionId);
    if (empty($payload['prompts']) && !empty($structured['payload']['prompts'])) $payload['prompts'] = $structured['payload']['prompts'];
    if (empty($payload['tags']) && !empty($structured['payload']['tags'])) $payload['tags'] = $structured['payload']['tags'];
    return [
        'payload' => $payload,
        'row' => is_array($row) ? $row : [],
        'debug' => $debug + [
            'status' => is_array($row) ? 'payload_found' : ($structured['payload']['prompts'] ? 'structured_only_found' : 'no_matching_payload'),
            'structuredSessionId' => $structuredSessionId,
            'structured' => $structured['debug'],
        ],
    ];
}

function nf_tag_prompt_designer_sources(array $items): array
{
    $tagged = [];
    foreach (array_values($items) as $item) {
        if (!is_array($item)) continue;
        $item['_sourceFile'] = 'PromptDesigner SQL';
        $item['_sourceApp'] = 'PromptDesigner';
        $tagged[] = $item;
    }
    return $tagged;
}

function nf_merge_prompt_designer_into_workspace(PDO $pdo, int $userId, string $sessionId, ?array $workspacePayload): ?array
{
    if ($userId <= 0 || $sessionId === '') return $workspacePayload;
    $workspacePayload = is_array($workspacePayload) ? $workspacePayload : [];
    if (!isset($workspacePayload['metadata']) || !is_array($workspacePayload['metadata'])) $workspacePayload['metadata'] = [];
    $loaded = nf_latest_prompt_designer_payload($pdo, $userId, $sessionId);
    $payload = is_array($loaded['payload'] ?? null) ? $loaded['payload'] : [];
    $prompts = nf_tag_prompt_designer_sources(is_array($payload['prompts'] ?? null) ? $payload['prompts'] : []);

    if (!isset($workspacePayload['sourceImports']) || !is_array($workspacePayload['sourceImports'])) $workspacePayload['sourceImports'] = [];
    foreach (['dialogues', 'sequences', 'tasks', 'menus', 'prompts', 'importedLogic', 'importedGameplayValues'] as $key) {
        if (!isset($workspacePayload['sourceImports'][$key]) || !is_array($workspacePayload['sourceImports'][$key])) $workspacePayload['sourceImports'][$key] = [];
    }
    $workspacePayload['sourceImports']['prompts'] = array_values(array_filter(
        $workspacePayload['sourceImports']['prompts'],
        static fn($item) => !is_array($item) || (($item['_sourceApp'] ?? '') !== 'PromptDesigner' && ($item['_sourceFile'] ?? '') !== 'PromptDesigner SQL')
    ));
    $workspacePayload['sourceImports']['prompts'] = array_merge($workspacePayload['sourceImports']['prompts'], $prompts);

    if (is_array($payload['tags'] ?? null)) {
        $existingColors = is_array($workspacePayload['metadata']['promptTagColors'] ?? null) ? $workspacePayload['metadata']['promptTagColors'] : [];
        foreach ($payload['tags'] as $tag) {
            if (!is_array($tag)) continue;
            $name = nf_text($tag['name'] ?? '');
            $color = nf_text($tag['color'] ?? '');
            if ($name !== '' && $color !== '') $existingColors[$name] = $color;
        }
        $workspacePayload['metadata']['promptTagColors'] = $existingColors;
    }

    $row = is_array($loaded['row'] ?? null) ? $loaded['row'] : [];
    $workspacePayload['metadata']['promptDesignerSqlImport'] = [
        'sessionId' => nf_text($row['session_id'] ?? $sessionId),
        'dialogueSessionId' => nf_text($row['dialogue_session_id'] ?? ($payload['dialogueSessionId'] ?? '')),
        'sourceTable' => 'FSG_PD_server_sessions',
        'promptCount' => count($prompts),
        'tagCount' => is_array($payload['tags'] ?? null) ? count($payload['tags']) : 0,
        'status' => $prompts ? 'imported' : 'no_prompts_found',
        'debug' => [
            'payloadKeys' => array_slice(array_keys($payload), 0, 50),
            'payloadPromptCount' => is_array($payload['prompts'] ?? null) ? count($payload['prompts']) : 0,
            'payloadTagCount' => is_array($payload['tags'] ?? null) ? count($payload['tags']) : 0,
            'firstPromptTitles' => array_slice(array_map(static fn($item) => nf_text($item['title'] ?? ($item['name'] ?? '')), $prompts), 0, 12),
            'payloadJsonBytes' => strlen(nf_text($row['payload_json'] ?? '')),
            'rowUserId' => (int)($row['user_id'] ?? 0),
        ] + ($loaded['debug'] ?? []),
    ];
    return $workspacePayload;
}

function nf_latest_dialogue_designer_workspace(PDO $pdo, int $userId, string $sessionId = ''): array
{
    if ($userId <= 0 || !nf_table_exists($pdo, 'FSG_DD_Workspaces')) return [];
    $sessionId = nf_normalize_session_id($sessionId);
    $projectCountExpr = nf_table_exists($pdo, 'FSG_DD_Projects') ? '(SELECT COUNT(*) FROM FSG_DD_Projects p WHERE p.workspace_id = w.id)' : '0';
    $rawSequenceScoreExpr = "(CASE WHEN w.raw_json LIKE '%\"sequences\":[{%' OR w.raw_json LIKE '%\"sequences\": [{%' THEN 1 ELSE 0 END)";
    $rawConversationScoreExpr = "(CASE WHEN w.raw_json LIKE '%\"conversations\":[{%' OR w.raw_json LIKE '%\"conversations\": [{%' THEN 1 ELSE 0 END)";
    $workspaceOrderSql = "_project_count DESC, _raw_sequence_score DESC, _raw_conversation_score DESC, _raw_json_bytes DESC, w.id DESC";
    $debugSelectSql = "w.id, w.workspace_uuid, w.session_id, w.user_id, {$projectCountExpr} AS project_count, {$rawSequenceScoreExpr} AS raw_sequence_score, {$rawConversationScoreExpr} AS raw_conversation_score, LENGTH(w.raw_json) AS raw_json_bytes, w.created_at, w.updated_at";
    $selectSql = "w.*, {$projectCountExpr} AS _project_count, {$rawSequenceScoreExpr} AS _raw_sequence_score, {$rawConversationScoreExpr} AS _raw_conversation_score, LENGTH(w.raw_json) AS _raw_json_bytes";
    $lookupDebug = [
        'requestedUserId' => $userId,
        'requestedSessionId' => $sessionId,
        'workspaceTableExists' => nf_table_exists($pdo, 'FSG_DD_Workspaces'),
        'projectTableExists' => nf_table_exists($pdo, 'FSG_DD_Projects'),
        'nodeTableExists' => nf_table_exists($pdo, 'FSG_DD_Nodes'),
        'responseTableExists' => nf_table_exists($pdo, 'FSG_DD_Responses'),
        'exactSessionRows' => $sessionId !== '' ? nf_count_md_rows($pdo, 'FSG_DD_Workspaces', 'WHERE session_id = ?', [$sessionId]) : 0,
        'exactSessionUserRows' => $sessionId !== '' ? nf_count_md_rows($pdo, 'FSG_DD_Workspaces', 'WHERE session_id = ? AND (user_id = ? OR user_id IS NULL OR user_id = 0)', [$sessionId, $userId]) : 0,
        'rawJsonSessionRows' => $sessionId !== '' ? nf_count_md_rows($pdo, 'FSG_DD_Workspaces', 'WHERE raw_json LIKE ?', ['%' . $sessionId . '%']) : 0,
        'rawJsonSessionUserRows' => $sessionId !== '' ? nf_count_md_rows($pdo, 'FSG_DD_Workspaces', 'WHERE raw_json LIKE ? AND (user_id = ? OR user_id IS NULL OR user_id = 0)', ['%' . $sessionId . '%', $userId]) : 0,
        'userRows' => nf_count_md_rows($pdo, 'FSG_DD_Workspaces', 'WHERE user_id = ?', [$userId]),
        'latestRowsForSession' => [],
        'latestRowsForRawJsonSession' => [],
        'latestRowsForUser' => [],
        'projectRowsForSessionWorkspaces' => [],
        'projectRowsForUserWorkspaces' => [],
    ];
    if ($sessionId !== '') {
        $lookupDebug['latestRowsForSession'] = nf_fetch_debug_rows($pdo, "SELECT {$debugSelectSql} FROM FSG_DD_Workspaces w WHERE w.session_id = ? ORDER BY project_count DESC, raw_sequence_score DESC, raw_conversation_score DESC, raw_json_bytes DESC, w.id DESC LIMIT 8", [$sessionId]);
        $lookupDebug['latestRowsForRawJsonSession'] = nf_fetch_debug_rows($pdo, "SELECT {$debugSelectSql} FROM FSG_DD_Workspaces w WHERE w.raw_json LIKE ? ORDER BY project_count DESC, raw_sequence_score DESC, raw_conversation_score DESC, raw_json_bytes DESC, w.id DESC LIMIT 8", ['%' . $sessionId . '%']);
        $lookupDebug['projectRowsForSessionWorkspaces'] = $lookupDebug['latestRowsForSession'];
    }
    $lookupDebug['latestRowsForUser'] = nf_fetch_debug_rows($pdo, "SELECT {$debugSelectSql} FROM FSG_DD_Workspaces w WHERE w.user_id = ? ORDER BY project_count DESC, raw_sequence_score DESC, raw_conversation_score DESC, raw_json_bytes DESC, w.id DESC LIMIT 8", [$userId]);
    $lookupDebug['projectRowsForUserWorkspaces'] = $lookupDebug['latestRowsForUser'];

    if ($sessionId !== '') {
        $stmt = $pdo->prepare("SELECT {$selectSql} FROM FSG_DD_Workspaces w WHERE w.session_id = ? AND (w.user_id = ? OR w.user_id IS NULL OR w.user_id = 0) ORDER BY {$workspaceOrderSql} LIMIT 1");
        $stmt->execute([$sessionId, $userId]);
        $row = $stmt->fetch();
        if (is_array($row)) {
            $row['_lookupDebug'] = $lookupDebug + ['matchedBy' => 'session_and_user'];
            return $row;
        }

        $stmt = $pdo->prepare("SELECT {$selectSql} FROM FSG_DD_Workspaces w WHERE w.session_id = ? ORDER BY {$workspaceOrderSql} LIMIT 1");
        $stmt->execute([$sessionId]);
        $row = $stmt->fetch();
        if (is_array($row)) {
            $row['_lookupDebug'] = $lookupDebug + ['matchedBy' => 'session_any_user'];
            return $row;
        }

        $stmt = $pdo->prepare("SELECT {$selectSql} FROM FSG_DD_Workspaces w WHERE w.raw_json LIKE ? AND (w.user_id = ? OR w.user_id IS NULL OR w.user_id = 0) ORDER BY {$workspaceOrderSql} LIMIT 1");
        $stmt->execute(['%' . $sessionId . '%', $userId]);
        $row = $stmt->fetch();
        if (is_array($row)) {
            $row['_lookupDebug'] = $lookupDebug + ['matchedBy' => 'raw_json_session_and_user'];
            return $row;
        }

        $stmt = $pdo->prepare("SELECT {$selectSql} FROM FSG_DD_Workspaces w WHERE w.raw_json LIKE ? ORDER BY {$workspaceOrderSql} LIMIT 1");
        $stmt->execute(['%' . $sessionId . '%']);
        $row = $stmt->fetch();
        if (is_array($row)) {
            $row['_lookupDebug'] = $lookupDebug + ['matchedBy' => 'raw_json_session_any_user'];
            return $row;
        }
    }

    $stmt = $pdo->prepare("SELECT {$selectSql} FROM FSG_DD_Workspaces w WHERE w.user_id = ? ORDER BY {$workspaceOrderSql} LIMIT 1");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    if (is_array($row)) {
        $row['_lookupDebug'] = $lookupDebug + ['matchedBy' => 'latest_for_user_fallback'];
        return $row;
    }
    return ['_lookupDebug' => $lookupDebug + ['matchedBy' => 'none']];
}

function nf_hydrate_dialogue_designer_nodes(PDO $pdo, int $projectId): array
{
    if ($projectId <= 0 || !nf_table_exists($pdo, 'FSG_DD_Nodes')) return [];
    $stmt = $pdo->prepare('SELECT * FROM FSG_DD_Nodes WHERE project_id = ? ORDER BY sort_order ASC, id ASC');
    $stmt->execute([$projectId]);
    $nodes = [];
    foreach ($stmt->fetchAll() as $row) {
        $node = nf_json_decode_array($row['raw_json'] ?? '');
        if (!$node) {
            $node = [
                'id' => nf_text($row['node_uuid'] ?? ''),
                'speaker' => nf_text($row['speaker'] ?? ''),
                'text' => nf_text($row['text'] ?? ''),
                'nodeColor' => nf_text($row['node_color'] ?? ''),
                'voiceLine' => (bool)($row['voice_line'] ?? false),
                'isCollapsed' => (bool)($row['is_collapsed'] ?? false),
                'advancedOpen' => (bool)($row['advanced_open'] ?? false),
                'conditionsOpen' => (bool)($row['conditions_open'] ?? true),
                'statesOpen' => (bool)($row['states_open'] ?? true),
                'responsesOpen' => (bool)($row['responses_open'] ?? true),
                'resourcePath' => nf_text($row['resource_path'] ?? ''),
                'usePath' => (bool)($row['use_path'] ?? false),
                'closeMainMenu' => (bool)($row['close_main_menu'] ?? false),
                'closeDialogueMenu' => (bool)($row['close_dialogue_menu'] ?? false),
                'openPromptPanel' => (bool)($row['open_prompt_panel'] ?? false),
                'closePromptPanel' => (bool)($row['close_prompt_panel'] ?? false),
                'controlSequence' => (bool)($row['control_sequence'] ?? false),
                'sequenceName' => nf_text($row['sequence_name'] ?? ''),
                'sequenceImage' => nf_text($row['sequence_image'] ?? ''),
                'canPlayerRespond' => (bool)($row['can_player_respond'] ?? false),
                'externalCall' => (bool)($row['external_call'] ?? false),
                'makeExternalCall' => (bool)($row['make_external_call'] ?? false),
                'parentResponseId' => nf_text($row['parent_response_uuid'] ?? ''),
                'parentResponsePreview' => nf_text($row['parent_response_preview'] ?? ''),
            ];
        }
        $nodeId = (int)($row['id'] ?? 0);
        if ($nodeId > 0 && nf_table_exists($pdo, 'FSG_DD_Responses')) {
            $responseStmt = $pdo->prepare('SELECT * FROM FSG_DD_Responses WHERE node_id = ? ORDER BY sort_order ASC, id ASC');
            $responseStmt->execute([$nodeId]);
            $responses = [];
            foreach ($responseStmt->fetchAll() as $responseRow) {
                $response = nf_json_decode_array($responseRow['raw_json'] ?? '');
                if (!$response) {
                    $response = [
                        'id' => nf_text($responseRow['response_uuid'] ?? ''),
                        'speaker' => nf_text($responseRow['speaker'] ?? ''),
                        'text' => nf_text($responseRow['text'] ?? ''),
                        'nextStatementId' => nf_text($responseRow['next_statement_uuid'] ?? ''),
                        'autoIncrement' => (bool)($responseRow['auto_increment_flag'] ?? false),
                        'voiceLine' => (bool)($responseRow['voice_line'] ?? false),
                        'isCollapsed' => (bool)($responseRow['is_collapsed'] ?? false),
                    ];
                }
                $responses[] = $response;
            }
            $node['responses'] = $responses;
        }
        $nodes[] = $node;
    }
    return $nodes;
}

function nf_load_dialogue_designer_structured_payload(PDO $pdo, int $workspaceId): array
{
    if ($workspaceId <= 0 || !nf_table_exists($pdo, 'FSG_DD_Projects')) {
        return ['conversations' => [], 'sequences' => [], 'projectCount' => 0];
    }
    $stmt = $pdo->prepare('SELECT * FROM FSG_DD_Projects WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC');
    $stmt->execute([$workspaceId]);
    $conversations = [];
    $sequences = [];
    $projectCount = 0;
    foreach ($stmt->fetchAll() as $row) {
        $projectCount++;
        $project = nf_json_decode_array($row['raw_json'] ?? '');
        if (!$project) {
            $projectId = (int)($row['id'] ?? 0);
            $participants = [];
            if ($projectId > 0 && nf_table_exists($pdo, 'FSG_DD_ProjectParticipants')) {
                $participantStmt = $pdo->prepare('SELECT participant_name FROM FSG_DD_ProjectParticipants WHERE project_id = ? ORDER BY sort_order ASC, id ASC');
                $participantStmt->execute([$projectId]);
                $participants = array_values(array_filter(array_map('nf_text', $participantStmt->fetchAll(PDO::FETCH_COLUMN))));
            }
            $project = [
                'id' => nf_text($row['project_uuid'] ?? ''),
                'title' => nf_text($row['title'] ?? ''),
                'color' => nf_text($row['color'] ?? ''),
                'participants' => $participants,
                'nodes' => nf_hydrate_dialogue_designer_nodes($pdo, $projectId),
                'isRepeatable' => (bool)($row['is_repeatable'] ?? false),
                'repeatVariable' => nf_text($row['repeat_variable'] ?? ''),
            ];
        }
        $type = strtolower(nf_text($row['project_type'] ?? ''));
        if ($type === 'sequence') $sequences[] = $project;
        else $conversations[] = $project;
    }
    return [
        'conversations' => $conversations,
        'sequences' => $sequences,
        'projectCount' => $projectCount,
    ];
}

function nf_load_dialogue_designer_snapshot_payload(PDO $pdo, int $workspaceId): array
{
    if ($workspaceId <= 0 || !nf_table_exists($pdo, 'FSG_DD_RawJsonSnapshots')) return ['payload' => [], 'debug' => []];
    $stmt = $pdo->prepare('SELECT id, snapshot_label, raw_json, LENGTH(raw_json) AS raw_json_bytes FROM FSG_DD_RawJsonSnapshots WHERE workspace_id = ? ORDER BY raw_json_bytes DESC, id DESC LIMIT 1');
    $stmt->execute([$workspaceId]);
    $row = $stmt->fetch();
    if (!is_array($row)) return ['payload' => [], 'debug' => []];
    return [
        'payload' => nf_json_decode_array($row['raw_json'] ?? ''),
        'debug' => [
            'snapshotId' => (int)($row['id'] ?? 0),
            'snapshotLabel' => nf_text($row['snapshot_label'] ?? ''),
            'snapshotRawJsonBytes' => (int)($row['raw_json_bytes'] ?? 0),
        ],
    ];
}

function nf_load_dialogue_designer_payload(PDO $pdo, int $userId, string $sessionId = ''): array
{
    $workspace = nf_latest_dialogue_designer_workspace($pdo, $userId, $sessionId);
    if (!$workspace) {
        return [
            'workspace' => [],
            'payload' => [],
            'debug' => [
                'status' => 'no_workspace_table_or_user',
                'requestedUserId' => $userId,
                'requestedSessionId' => nf_normalize_session_id($sessionId),
                'workspaceTableExists' => nf_table_exists($pdo, 'FSG_DD_Workspaces'),
                'projectTableExists' => nf_table_exists($pdo, 'FSG_DD_Projects'),
                'nodeTableExists' => nf_table_exists($pdo, 'FSG_DD_Nodes'),
                'responseTableExists' => nf_table_exists($pdo, 'FSG_DD_Responses'),
            ],
        ];
    }
    $payload = nf_json_decode_array($workspace['raw_json'] ?? '');
    $workspaceId = (int)($workspace['id'] ?? 0);
    $snapshot = nf_load_dialogue_designer_snapshot_payload($pdo, $workspaceId);
    $snapshotPayload = is_array($snapshot['payload'] ?? null) ? $snapshot['payload'] : [];
    $structured = nf_load_dialogue_designer_structured_payload($pdo, $workspaceId);
    $rawConversations = is_array($payload['conversations'] ?? null) ? $payload['conversations'] : [];
    $rawSequences = is_array($payload['sequences'] ?? null) ? $payload['sequences'] : [];
    $snapshotConversations = is_array($snapshotPayload['conversations'] ?? null) ? $snapshotPayload['conversations'] : [];
    $snapshotSequences = is_array($snapshotPayload['sequences'] ?? null) ? $snapshotPayload['sequences'] : [];
    $snapshotConversationUsed = !$rawConversations && !empty($snapshotConversations);
    $snapshotSequenceUsed = !$rawSequences && !empty($snapshotSequences);
    if ($snapshotConversationUsed) $payload['conversations'] = $snapshotConversations;
    if ($snapshotSequenceUsed) $payload['sequences'] = $snapshotSequences;
    $rawConversations = is_array($payload['conversations'] ?? null) ? $payload['conversations'] : [];
    $rawSequences = is_array($payload['sequences'] ?? null) ? $payload['sequences'] : [];
    if (!$rawConversations && !empty($structured['conversations'])) $payload['conversations'] = $structured['conversations'];
    if (!$rawSequences && !empty($structured['sequences'])) $payload['sequences'] = $structured['sequences'];
    return [
        'workspace' => $workspace,
        'payload' => $payload,
        'debug' => [
            'status' => $workspaceId > 0 ? 'workspace_found' : 'no_matching_workspace',
            'workspaceId' => $workspaceId,
            'sessionId' => nf_text($workspace['session_id'] ?? ''),
            'workspaceUuid' => nf_text($workspace['workspace_uuid'] ?? ''),
            'workspaceUserId' => (int)($workspace['user_id'] ?? 0),
            'workspaceProjectCountHint' => (int)($workspace['_project_count'] ?? -1),
            'workspaceRawSequenceScoreHint' => (int)($workspace['_raw_sequence_score'] ?? -1),
            'workspaceRawConversationScoreHint' => (int)($workspace['_raw_conversation_score'] ?? -1),
            'workspaceRawJsonBytesHint' => (int)($workspace['_raw_json_bytes'] ?? -1),
            'createdAt' => nf_text($workspace['created_at'] ?? ''),
            'updatedAt' => nf_text($workspace['updated_at'] ?? ''),
            'lookup' => $workspace['_lookupDebug'] ?? null,
            'rawJsonByteLength' => strlen(nf_text($workspace['raw_json'] ?? '')),
            'rawJsonKeys' => array_slice(array_keys($payload), 0, 30),
            'rawJsonConversationCount' => count($rawConversations),
            'rawJsonSequenceCount' => count($rawSequences),
            'rawJsonLooksNonEmptyConversation' => str_contains(nf_text($workspace['raw_json'] ?? ''), '"conversations":[{') || str_contains(nf_text($workspace['raw_json'] ?? ''), '"conversations": [{'),
            'rawJsonLooksNonEmptySequence' => str_contains(nf_text($workspace['raw_json'] ?? ''), '"sequences":[{') || str_contains(nf_text($workspace['raw_json'] ?? ''), '"sequences": [{'),
            'snapshot' => $snapshot['debug'] ?? null,
            'snapshotConversationCount' => count($snapshotConversations),
            'snapshotSequenceCount' => count($snapshotSequences),
            'snapshotConversationUsed' => $snapshotConversationUsed,
            'snapshotSequenceUsed' => $snapshotSequenceUsed,
            'structuredProjectCount' => (int)($structured['projectCount'] ?? 0),
            'structuredConversationCount' => is_array($structured['conversations'] ?? null) ? count($structured['conversations']) : 0,
            'structuredSequenceCount' => is_array($structured['sequences'] ?? null) ? count($structured['sequences']) : 0,
            'structuredConversationUsed' => !$rawConversations && !empty($structured['conversations']),
            'structuredSequenceUsed' => !$rawSequences && !empty($structured['sequences']),
            'structuredConversationTitles' => array_slice(array_map(static fn($item) => nf_text($item['title'] ?? ''), is_array($structured['conversations'] ?? null) ? $structured['conversations'] : []), 0, 10),
            'structuredSequenceTitles' => array_slice(array_map(static fn($item) => nf_text($item['title'] ?? ''), is_array($structured['sequences'] ?? null) ? $structured['sequences'] : []), 0, 10),
            'tableCounts' => [
                'FSG_DD_Projects' => nf_count_md_rows($pdo, 'FSG_DD_Projects', 'WHERE workspace_id = ?', [$workspaceId]),
                'FSG_DD_Nodes' => nf_count_md_rows($pdo, 'FSG_DD_Nodes', 'n JOIN FSG_DD_Projects p ON p.id = n.project_id WHERE p.workspace_id = ?', [$workspaceId]),
                'FSG_DD_Responses' => nf_count_md_rows($pdo, 'FSG_DD_Responses', 'r JOIN FSG_DD_Nodes n ON n.id = r.node_id JOIN FSG_DD_Projects p ON p.id = n.project_id WHERE p.workspace_id = ?', [$workspaceId]),
            ],
            'projectSamples' => $workspaceId > 0 && nf_table_exists($pdo, 'FSG_DD_Projects')
                ? nf_fetch_debug_rows($pdo, 'SELECT id, workspace_id, project_uuid, project_type, sort_order, title, LENGTH(raw_json) AS raw_json_bytes FROM FSG_DD_Projects WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC LIMIT 10', [$workspaceId])
                : [],
        ],
    ];
}

function nf_tag_dialogue_designer_sources(array $items, string $type): array
{
    $tagged = [];
    foreach (array_values($items) as $item) {
        if (!is_array($item)) continue;
        $item['_sourceFile'] = 'DialogueDesigner SQL';
        $item['_sourceApp'] = 'DialogueDesigner';
        $item['_sourceType'] = $type;
        $tagged[] = $item;
    }
    return $tagged;
}

function nf_merge_dialogue_designer_into_workspace(PDO $pdo, int $userId, string $sessionId, ?array $workspacePayload): ?array
{
    if ($userId <= 0 || $sessionId === '') return $workspacePayload;
    $workspacePayload = is_array($workspacePayload) ? $workspacePayload : [];
    $loaded = nf_load_dialogue_designer_payload($pdo, $userId, $sessionId);
    if (!isset($workspacePayload['metadata']) || !is_array($workspacePayload['metadata'])) $workspacePayload['metadata'] = [];
    if (!$loaded || !is_array($loaded['payload'] ?? null)) {
        $workspacePayload['metadata']['dialogueDesignerSqlImport'] = [
            'sessionId' => $sessionId,
            'dialogueDesignerDatabaseId' => 0,
            'dialogueCount' => 0,
            'sequenceCount' => 0,
            'status' => 'load_failed',
            'debug' => $loaded['debug'] ?? null,
        ];
        return $workspacePayload;
    }

    $ddPayload = $loaded['payload'];
    $dialogues = nf_tag_dialogue_designer_sources(is_array($ddPayload['conversations'] ?? null) ? $ddPayload['conversations'] : [], 'conversation');
    $sequences = nf_tag_dialogue_designer_sources(is_array($ddPayload['sequences'] ?? null) ? $ddPayload['sequences'] : [], 'sequence');
    if (!isset($workspacePayload['sourceImports']) || !is_array($workspacePayload['sourceImports'])) $workspacePayload['sourceImports'] = [];
    foreach (['dialogues', 'sequences', 'tasks', 'menus', 'prompts', 'importedLogic', 'importedGameplayValues'] as $key) {
        if (!isset($workspacePayload['sourceImports'][$key]) || !is_array($workspacePayload['sourceImports'][$key])) $workspacePayload['sourceImports'][$key] = [];
    }

    $workspacePayload['sourceImports']['dialogues'] = array_values(array_filter(
        $workspacePayload['sourceImports']['dialogues'],
        static fn($item) => !is_array($item) || (($item['_sourceApp'] ?? '') !== 'DialogueDesigner' && ($item['_sourceFile'] ?? '') !== 'DialogueDesigner SQL')
    ));
    $workspacePayload['sourceImports']['sequences'] = array_values(array_filter(
        $workspacePayload['sourceImports']['sequences'],
        static fn($item) => !is_array($item) || (($item['_sourceApp'] ?? '') !== 'DialogueDesigner' && ($item['_sourceFile'] ?? '') !== 'DialogueDesigner SQL')
    ));

    $workspacePayload['sourceImports']['dialogues'] = array_merge($workspacePayload['sourceImports']['dialogues'], $dialogues);
    $workspacePayload['sourceImports']['sequences'] = array_merge($workspacePayload['sourceImports']['sequences'], $sequences);

    $workspacePayload['metadata']['dialogueDesignerSqlImport'] = [
        'sessionId' => nf_text($loaded['workspace']['session_id'] ?? $sessionId),
        'dialogueDesignerDatabaseId' => (int)($loaded['workspace']['id'] ?? 0),
        'dialogueCount' => count($dialogues),
        'sequenceCount' => count($sequences),
        'status' => ($dialogues || $sequences) ? 'imported' : 'no_dialogues_or_sequences_found',
        'debug' => $loaded['debug'] ?? null,
    ];
    return $workspacePayload;
}

function nf_merge_external_designers_into_workspace(PDO $pdo, int $userId, string $sessionId, ?array $workspacePayload): ?array
{
    $workspacePayload = nf_merge_dialogue_designer_into_workspace($pdo, $userId, $sessionId, $workspacePayload);
    $workspacePayload = nf_merge_menu_designer_into_workspace($pdo, $userId, $sessionId, $workspacePayload);
    $workspacePayload = nf_merge_task_manager_into_workspace($pdo, $userId, $sessionId, $workspacePayload);
    $workspacePayload = nf_merge_prompt_designer_into_workspace($pdo, $userId, $sessionId, $workspacePayload);
    return $workspacePayload;
}

try {
    $pdo = nf_pdo();
    nf_ensure_schema($pdo);
    if (function_exists('fsgAuth_touchSharedSession')) fsgAuth_touchSharedSession();

    $body = nf_body();
    $action = nf_text($_GET['action'] ?? ($body['action'] ?? 'health'));
    $auth = nf_current_user_payload($pdo);
    $userId = (int)($auth['user']['id'] ?? 0);

    if ($action === 'health') {
        nf_json(['ok' => true, 'api' => 'NarrativeFlow', 'database' => 'connected']);
    }

    if ($action === 'generateSessionId') {
        nf_json(['ok' => true, 'sessionId' => nf_generate_session_id($pdo)]);
    }

    if ($action === 'debugDialogueDesignerSql') {
        $sessionId = nf_normalize_session_id($_GET['sessionId'] ?? ($body['sessionId'] ?? nf_current_session_id()));
        $loaded = $userId > 0 ? nf_load_dialogue_designer_payload($pdo, $userId, $sessionId) : [];
        $payload = is_array($loaded['payload'] ?? null) ? $loaded['payload'] : [];
        nf_json(['ok' => true] + $auth + [
            'requestedSessionId' => $sessionId,
            'dialogueCount' => is_array($payload['conversations'] ?? null) ? count($payload['conversations']) : 0,
            'sequenceCount' => is_array($payload['sequences'] ?? null) ? count($payload['sequences']) : 0,
            'debug' => $loaded['debug'] ?? [
                'status' => 'not_loaded',
                'userId' => $userId,
                'workspaceTableExists' => nf_table_exists($pdo, 'FSG_DD_Workspaces'),
                'projectTableExists' => nf_table_exists($pdo, 'FSG_DD_Projects'),
            ],
        ]);
    }

    if ($action === 'debugTaskManagerSql') {
        $sessionId = nf_normalize_session_id($_GET['sessionId'] ?? ($body['sessionId'] ?? nf_current_session_id()));
        $loaded = $userId > 0 ? nf_latest_task_manager_payload($pdo, $userId, $sessionId) : [];
        $payload = is_array($loaded['payload'] ?? null) ? $loaded['payload'] : [];
        nf_json(['ok' => true] + $auth + [
            'requestedSessionId' => $sessionId,
            'taskCount' => is_array($payload['entries'] ?? null) ? count($payload['entries']) : 0,
            'tabCount' => is_array($payload['tabs'] ?? null) ? count($payload['tabs']) : 0,
            'payloadKeys' => array_slice(array_keys($payload), 0, 40),
            'debug' => $loaded['debug'] ?? [
                'status' => 'not_loaded',
                'userId' => $userId,
                'payloadTableExists' => nf_table_exists($pdo, 'FSG_TASK_server_sessions'),
                'tmWorkspaceTableExists' => nf_table_exists($pdo, 'FSG_TM_Workspaces'),
            ],
        ]);
    }

    if ($action === 'debugPromptDesignerSql') {
        $sessionId = nf_normalize_session_id($_GET['sessionId'] ?? ($body['sessionId'] ?? nf_current_session_id()));
        $loaded = $userId > 0 ? nf_latest_prompt_designer_payload($pdo, $userId, $sessionId) : [];
        $payload = is_array($loaded['payload'] ?? null) ? $loaded['payload'] : [];
        nf_json(['ok' => true] + $auth + [
            'requestedSessionId' => $sessionId,
            'promptCount' => is_array($payload['prompts'] ?? null) ? count($payload['prompts']) : 0,
            'tagCount' => is_array($payload['tags'] ?? null) ? count($payload['tags']) : 0,
            'payloadKeys' => array_slice(array_keys($payload), 0, 50),
            'debug' => $loaded['debug'] ?? [
                'status' => 'not_loaded',
                'userId' => $userId,
                'payloadTableExists' => nf_table_exists($pdo, 'FSG_PD_server_sessions'),
                'promptTableExists' => nf_table_exists($pdo, 'FSG_PD_Prompts'),
                'tagTableExists' => nf_table_exists($pdo, 'FSG_PD_Tags'),
            ],
        ]);
    }

    if ($action === 'accountStatus') {
        $sessions = $userId > 0 ? nf_list_nf_sessions($pdo, $userId) : [];
        $externalLatest = $userId > 0 ? nf_latest_external_session($pdo, $userId) : [];
        nf_json(['ok' => true] + $auth + [
            'sessions' => $sessions,
            'latestExternalSession' => $externalLatest,
        ]);
    }

    if ($action === 'loadLatest') {
        if ($userId <= 0) {
            nf_json(['ok' => true, 'loggedIn' => false, 'sessionId' => '', 'payloadFound' => false, 'workspace' => null] + $auth);
        }
        $latest = nf_latest_session($pdo, $userId);
        $sessionId = nf_normalize_session_id((string)($latest['session_id'] ?? ''));
        $source = (string)($latest['source'] ?? '');
        $workspace = $sessionId !== '' ? nf_load_workspace($pdo, $userId, $sessionId) : [];
        $workspacePayload = nf_merge_external_designers_into_workspace($pdo, $userId, $sessionId, $workspace['payload'] ?? null);
        if ($sessionId !== '') nf_touch_session($pdo, $userId, $sessionId, $source === 'NarrativeFlow' ? '' : $source, $source === 'NarrativeFlow' ? '' : $sessionId, 'view');
        nf_json(['ok' => true] + $auth + [
            'sessionId' => $sessionId,
            'latestSessionId' => $sessionId,
            'latestSessionSource' => $source,
            'linkedSourceApp' => $source === 'NarrativeFlow' ? '' : $source,
            'linkedSessionId' => $source === 'NarrativeFlow' ? '' : $sessionId,
            'payloadFound' => !empty($workspace) || !empty($workspacePayload['sourceImports']['dialogues'] ?? []) || !empty($workspacePayload['sourceImports']['sequences'] ?? []) || !empty($workspacePayload['sourceImports']['tasks'] ?? []) || !empty($workspacePayload['sourceImports']['menus'] ?? []) || !empty($workspacePayload['sourceImports']['prompts'] ?? []),
            'workspace' => $workspacePayload,
            'sessions' => nf_list_nf_sessions($pdo, $userId),
        ]);
    }

    if ($action === 'loadSession') {
        $sessionId = nf_normalize_session_id(nf_text($_GET['sessionId'] ?? ($body['sessionId'] ?? '')));
        if ($userId <= 0) throw new RuntimeException('Login required to load server sessions.');
        if ($sessionId === '') throw new RuntimeException('Missing session id.');
        $workspace = nf_load_workspace($pdo, $userId, $sessionId);
        $workspacePayload = nf_merge_external_designers_into_workspace($pdo, $userId, $sessionId, $workspace['payload'] ?? null);
        nf_touch_session($pdo, $userId, $sessionId, '', '', 'view');
        nf_json(['ok' => true] + $auth + [
            'sessionId' => $sessionId,
            'payloadFound' => !empty($workspace) || !empty($workspacePayload['sourceImports']['dialogues'] ?? []) || !empty($workspacePayload['sourceImports']['sequences'] ?? []) || !empty($workspacePayload['sourceImports']['tasks'] ?? []) || !empty($workspacePayload['sourceImports']['menus'] ?? []) || !empty($workspacePayload['sourceImports']['prompts'] ?? []),
            'workspace' => $workspacePayload,
            'sessions' => nf_list_nf_sessions($pdo, $userId),
        ]);
    }

    if ($action === 'loadMenuDesignerOptions') {
        if ($userId <= 0) throw new RuntimeException('Login required to load Menu Designer options.');
        $sessionId = nf_normalize_session_id(nf_text($_GET['sessionId'] ?? ($body['sessionId'] ?? '')));
        $loaded = nf_load_menu_designer_payload($pdo, $userId, $sessionId);
        $mdSessionId = nf_text($loaded['workspace']['session_id'] ?? $sessionId);
        nf_json(['ok' => true] + $auth + [
            'payloadFound' => !empty($loaded),
            'menuDesignerSessionId' => $mdSessionId,
            'menuDesignerDatabaseId' => (int)($loaded['workspace']['id'] ?? 0),
            'sharedDialogueWorkspaceDatabaseId' => (int)($loaded['workspace']['dd_workspace_id'] ?? 0),
            'data' => $loaded['payload'] ?? null,
            'debug' => $loaded['debug'] ?? null,
            'sessions' => nf_list_nf_sessions($pdo, $userId),
        ]);
    }

    if ($action === 'saveSession') {
        if ($userId <= 0) throw new RuntimeException('Login required to push Narrative Flow to the server.');
        $sessionId = nf_normalize_session_id(nf_text($_GET['sessionId'] ?? ($body['sessionId'] ?? '')));
        if ($sessionId === '') $sessionId = nf_generate_session_id($pdo);
        $payload = $body['workspace'] ?? $body['payload'] ?? [];
        if (!is_array($payload)) throw new RuntimeException('Missing workspace payload.');
        $linkedApp = nf_text($body['linkedSourceApp'] ?? '');
        $linkedSessionId = nf_normalize_session_id(nf_text($body['linkedSessionId'] ?? ''));
        nf_save_workspace($pdo, $userId, $sessionId, $payload, $linkedApp, $linkedSessionId);
        nf_json(['ok' => true] + $auth + [
            'sessionId' => $sessionId,
            'payloadFound' => true,
            'sessions' => nf_list_nf_sessions($pdo, $userId),
        ]);
    }

    nf_json(['ok' => false, 'error' => 'Unknown Narrative Flow action.'], 404);
} catch (Throwable $e) {
    nf_json(['ok' => false, 'error' => $e->getMessage()], 500);
}
