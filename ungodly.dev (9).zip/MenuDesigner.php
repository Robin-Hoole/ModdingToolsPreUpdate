<?php
declare(strict_types=1);

$sharedAuthPath = __DIR__ . '/_private/AuthShared.php';
if (is_file($sharedAuthPath)) {
    require_once $sharedAuthPath;
    fsgAuth_startSharedSession();
} else {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function respondJson(array $payload, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function requireCredentials(): array
{
    $credentialsPath = __DIR__ . '/_private/databaseCredentials.php';
    if (!is_file($credentialsPath)) {
        respondJson(['ok' => false, 'error' => 'Missing _private/databaseCredentials.php'], 500);
    }

    require $credentialsPath;

    foreach (['dbHost', 'dbUser', 'dbPass', 'dbName'] as $varName) {
        if (!isset(${$varName})) {
            respondJson(['ok' => false, 'error' => "Missing database credential variable: {$varName}"], 500);
        }
    }

    return [$dbHost, $dbUser, $dbPass, $dbName];
}

function dbConnection(): PDO
{
    [$dbHost, $dbUser, $dbPass, $dbName] = requireCredentials();
    $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
    return new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}


function sharedFsgUserIdSqlType(PDO $pdo): string
{
    $stmt = $pdo->query("SHOW COLUMNS FROM FSG_users LIKE 'id'");
    $column = $stmt ? $stmt->fetch() : null;
    $type = strtolower((string)($column['Type'] ?? 'int'));
    $isUnsigned = strpos($type, 'unsigned') !== false;
    if (strpos($type, 'bigint') !== false) return $isUnsigned ? 'BIGINT UNSIGNED' : 'BIGINT';
    return $isUnsigned ? 'INT UNSIGNED' : 'INT';
}

function ensureAccountTables(PDO $pdo): void
{
    if (function_exists('fsgAuth_ensureAccountTables')) {
        try { fsgAuth_ensureAccountTables($pdo); } catch (Throwable $e) {}
    }
    // MenuDesigner intentionally uses the shared front-end FSG_users table.
    // This CREATE only runs on a fresh database; existing FSG site accounts are never dropped here.
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_users (
        id INT NOT NULL AUTO_INCREMENT,
        username VARCHAR(64) NOT NULL,
        email VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        is_over_18 TINYINT(1) NOT NULL DEFAULT 0,
        agreed_terms TINYINT(1) NOT NULL DEFAULT 0,
        agreed_privacy TINYINT(1) NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        is_admin TINYINT(1) NOT NULL DEFAULT 0,
        banned_until DATETIME NULL DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_FSG_users_active_username (is_active, username),
        KEY idx_FSG_users_active_email (is_active, email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $userColumns = [
        'is_over_18' => "ALTER TABLE FSG_users ADD COLUMN is_over_18 TINYINT(1) NOT NULL DEFAULT 0",
        'agreed_terms' => "ALTER TABLE FSG_users ADD COLUMN agreed_terms TINYINT(1) NOT NULL DEFAULT 0",
        'agreed_privacy' => "ALTER TABLE FSG_users ADD COLUMN agreed_privacy TINYINT(1) NOT NULL DEFAULT 0",
        'is_active' => "ALTER TABLE FSG_users ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1",
        'is_admin' => "ALTER TABLE FSG_users ADD COLUMN is_admin TINYINT(1) NOT NULL DEFAULT 0",
        'banned_until' => "ALTER TABLE FSG_users ADD COLUMN banned_until DATETIME NULL DEFAULT NULL",
        'created_at' => "ALTER TABLE FSG_users ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP",
        'updated_at' => "ALTER TABLE FSG_users ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
    ];
    foreach ($userColumns as $columnName => $alterSql) {
        $check = $pdo->query("SHOW COLUMNS FROM FSG_users LIKE " . $pdo->quote($columnName));
        if ($check && $check->rowCount() === 0) $pdo->exec($alterSql);
    }

    $sharedUserIdSqlType = sharedFsgUserIdSqlType($pdo);

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_user_identity_history (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$sharedUserIdSqlType} NOT NULL,
        field_name ENUM('username','email','password') NOT NULL,
        old_value VARCHAR(255) NOT NULL DEFAULT '',
        new_value VARCHAR(255) NOT NULL DEFAULT '',
        changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_FSG_user_identity_history_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DD_UserSessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$sharedUserIdSqlType} NOT NULL,
        session_id VARCHAR(96) NOT NULL,
        first_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_viewed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        workspace_count INT UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_DD_UserSessions_session (session_id),
        KEY idx_FSG_DD_UserSessions_user_viewed (user_id, last_viewed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_auth_sessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$sharedUserIdSqlType} NOT NULL,
        token_hash CHAR(64) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME NOT NULL,
        last_seen_at DATETIME NULL DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_auth_sessions_token_hash (token_hash),
        KEY idx_FSG_auth_sessions_user_seen (user_id, last_seen_at),
        KEY idx_FSG_auth_sessions_expires (expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->prepare('DELETE FROM FSG_auth_sessions WHERE expires_at < UTC_TIMESTAMP()')->execute();

    try {
        $check = $pdo->query("SHOW COLUMNS FROM FSG_DD_Workspaces LIKE 'user_id'");
        if ($check && $check->rowCount() === 0) {
            $pdo->exec("ALTER TABLE FSG_DD_Workspaces ADD COLUMN user_id {$sharedUserIdSqlType} NULL DEFAULT NULL AFTER session_id");
            $pdo->exec("CREATE INDEX idx_FSG_DD_Workspaces_user_session ON FSG_DD_Workspaces (user_id, session_id, created_at)");
        }
    } catch (Throwable $e) {
        // Workspaces table may not exist before the main schema is run.
    }
}

function currentUserId(?PDO $pdo = null): int
{
    if (isset($_SESSION['fsg_user_id'])) return (int)$_SESSION['fsg_user_id'];
    if (isset($_SESSION['dd_user_id'])) return (int)$_SESSION['dd_user_id'];
    if (isset($_SESSION['user_id'])) return (int)$_SESSION['user_id'];
    if ($pdo && function_exists('fsgAuth_currentUserIdFromRequest')) {
        try {
            return (int)fsgAuth_currentUserIdFromRequest($pdo);
        } catch (Throwable $e) {
            return 0;
        }
    }
    return 0;
}

function passwordMeetsPolicy(string $password): bool
{
    return (bool)preg_match('/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z0-9]).{8,}/', $password);
}

function normalizeUsername(string $username): string
{
    return trim($username);
}

function normalizeEmail(string $email): string
{
    return strtolower(trim($email));
}

function activeIdentityExists(PDO $pdo, string $username, string $email, int $excludeUserId = 0): bool
{
    $sql = 'SELECT id FROM FSG_users WHERE is_active = 1 AND (LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?))';
    $params = [$username, $email];
    if ($excludeUserId > 0) {
        $sql .= ' AND id != ?';
        $params[] = $excludeUserId;
    }
    $sql .= ' LIMIT 1';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (bool)$stmt->fetch();
}

function getUserById(PDO $pdo, int $userId): ?array
{
    if ($userId <= 0) return null;
    $stmt = $pdo->prepare('SELECT id, username, email, created_at FROM FSG_users WHERE id = ? AND is_active = 1 LIMIT 1');
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function listUserSessions(PDO $pdo, int $userId): array
{
    if ($userId <= 0) return [];

    $sessionsById = [];

    $mergeSessionRow = static function (array $row, string $source) use (&$sessionsById): void {
        $sid = textValue($row['session_id'] ?? '');
        if ($sid === '') return;
        if (!isset($sessionsById[$sid])) {
            $sessionsById[$sid] = [
                'sessionId' => $sid,
                'session_id' => $sid,
                'firstPushedAt' => $row['first_pushed_at'] ?? null,
                'lastPushedAt' => $row['last_pushed_at'] ?? null,
                'lastViewedAt' => $row['last_viewed_at'] ?? null,
                'workspaceCount' => (int)($row['workspace_count'] ?? 0),
                'sources' => [$source],
            ];
            return;
        }

        $sessionsById[$sid]['workspaceCount'] = max((int)$sessionsById[$sid]['workspaceCount'], (int)($row['workspace_count'] ?? 0));
        foreach (['firstPushedAt' => 'first_pushed_at', 'lastPushedAt' => 'last_pushed_at', 'lastViewedAt' => 'last_viewed_at'] as $camel => $snake) {
            $incoming = textValue($row[$snake] ?? '');
            if ($incoming === '') continue;
            $current = textValue($sessionsById[$sid][$camel] ?? '');
            if ($current === '' || $incoming > $current) $sessionsById[$sid][$camel] = $incoming;
        }
        if (!in_array($source, $sessionsById[$sid]['sources'], true)) $sessionsById[$sid]['sources'][] = $source;
    };

    try {
        $stmt = $pdo->prepare('SELECT session_id, first_pushed_at, last_pushed_at, last_viewed_at, workspace_count FROM FSG_DD_UserSessions WHERE user_id = ? ORDER BY last_viewed_at DESC, last_pushed_at DESC, id DESC');
        $stmt->execute([$userId]);
        foreach ($stmt->fetchAll() as $row) $mergeSessionRow($row, 'shared-session');
    } catch (Throwable $e) {}

    foreach ([
        'menu-designer' => 'FSG_MD_Workspaces',
        'dialogue-designer' => 'FSG_DD_Workspaces',
    ] as $source => $tableName) {
        try {
            $stmt = $pdo->prepare("SELECT session_id, MIN(created_at) AS first_pushed_at, MAX(created_at) AS last_pushed_at, MAX(updated_at) AS last_viewed_at, COUNT(*) AS workspace_count FROM {$tableName} WHERE user_id = ? AND session_id <> '' GROUP BY session_id ORDER BY last_pushed_at DESC");
            $stmt->execute([$userId]);
            foreach ($stmt->fetchAll() as $row) $mergeSessionRow($row, $source);
        } catch (Throwable $e) {}
    }

    usort($sessionsById, static function (array $a, array $b): int {
        return strcmp(textValue($b['lastViewedAt'] ?? $b['lastPushedAt'] ?? ''), textValue($a['lastViewedAt'] ?? $a['lastPushedAt'] ?? ''));
    });

    return array_values($sessionsById);
}

function authPayload(PDO $pdo): array
{
    $user = getUserById($pdo, currentUserId($pdo));
    if (!$user) {
        unset($_SESSION['dd_user_id'], $_SESSION['dd_username'], $_SESSION['user_id'], $_SESSION['username']);
        return ['loggedIn' => false, 'user' => null, 'sessions' => []];
    }
    return [
        'loggedIn' => true,
        'user' => [
            'id' => (int)$user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'createdAt' => $user['created_at'],
        ],
        'sessions' => listUserSessions($pdo, (int)$user['id']),
    ];
}

function registerAccount(PDO $pdo, array $body): array
{
    $username = normalizeUsername(textValue($body['username'] ?? ''));
    $email = normalizeEmail(textValue($body['email'] ?? ''));
    $password = textValue($body['password'] ?? '');
    $passwordConfirm = textValue($body['passwordConfirm'] ?? '');
    $over18 = boolValue($body['over18'] ?? false);
    $terms = boolValue($body['terms'] ?? false);
    $privacy = boolValue($body['privacy'] ?? false);

    if ($username === '' || $email === '') respondJson(['ok' => false, 'error' => 'Username and email are required.'], 400);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) respondJson(['ok' => false, 'error' => 'Enter a valid email address.'], 400);
    if (!$over18 || !$terms || !$privacy) respondJson(['ok' => false, 'error' => 'You must confirm 18+ and agree to the Terms of Service and Privacy Policy.'], 400);
    if ($password !== $passwordConfirm) respondJson(['ok' => false, 'error' => 'Passwords do not match.'], 400);
    if (!passwordMeetsPolicy($password)) respondJson(['ok' => false, 'error' => 'Password must be at least 8 characters with 1 uppercase, 1 lowercase, 1 number, and 1 special character.'], 400);
    if (activeIdentityExists($pdo, $username, $email)) respondJson(['ok' => false, 'error' => 'Username or email is already active.'], 409);

    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO FSG_users (username, email, password, is_over_18, agreed_terms, agreed_privacy, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)');
    $stmt->execute([$username, $email, $hash, $over18, $terms, $privacy]);
    $_SESSION['dd_user_id'] = (int)$pdo->lastInsertId();
    $_SESSION['dd_username'] = $username;
    $_SESSION['user_id'] = $_SESSION['dd_user_id'];
    $_SESSION['username'] = $username;
    $payload = authPayload($pdo);
    if (function_exists('fsgAuth_issueAuthToken')) {
        $payload['authToken'] = fsgAuth_issueAuthToken($pdo, (int)$_SESSION['dd_user_id']);
    }
    return $payload;
}

function loginAccount(PDO $pdo, array $body): array
{
    $identity = trim(textValue($body['identity'] ?? ''));
    $password = textValue($body['password'] ?? '');
    if ($identity === '' || $password === '') respondJson(['ok' => false, 'error' => 'Username/email and password are required.'], 400);
    $stmt = $pdo->prepare('SELECT id, username, password FROM FSG_users WHERE is_active = 1 AND (LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)) LIMIT 1');
    $stmt->execute([$identity, $identity]);
    $row = $stmt->fetch();
    if (!$row || !password_verify($password, $row['password'])) {
        respondJson(['ok' => false, 'error' => 'Invalid credentials.'], 401);
    }
    $_SESSION['dd_user_id'] = (int)$row['id'];
    $_SESSION['dd_username'] = $row['username'];
    $_SESSION['user_id'] = $_SESSION['dd_user_id'];
    $_SESSION['username'] = $row['username'];
    $payload = authPayload($pdo);
    if (function_exists('fsgAuth_issueAuthToken')) {
        $payload['authToken'] = fsgAuth_issueAuthToken($pdo, (int)$_SESSION['dd_user_id']);
    }
    return $payload;
}

function updateProfile(PDO $pdo, array $body): array
{
    $userId = currentUserId($pdo);
    $user = getUserById($pdo, $userId);
    if (!$user) respondJson(['ok' => false, 'error' => 'You are not logged in.'], 401);
    $username = normalizeUsername(textValue($body['username'] ?? ''));
    $email = normalizeEmail(textValue($body['email'] ?? ''));
    if ($username === '' || $email === '') respondJson(['ok' => false, 'error' => 'Username and email are required.'], 400);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) respondJson(['ok' => false, 'error' => 'Enter a valid email address.'], 400);
    if (activeIdentityExists($pdo, $username, $email, $userId)) respondJson(['ok' => false, 'error' => 'Username or email is already active.'], 409);

    $pdo->beginTransaction();
    try {
        if ($username !== $user['username']) {
            $hist = $pdo->prepare("INSERT INTO FSG_user_identity_history (user_id, field_name, old_value, new_value) VALUES (?, 'username', ?, ?)");
            $hist->execute([$userId, $user['username'], $username]);
        }
        if ($email !== strtolower($user['email'])) {
            $hist = $pdo->prepare("INSERT INTO FSG_user_identity_history (user_id, field_name, old_value, new_value) VALUES (?, 'email', ?, ?)");
            $hist->execute([$userId, $user['email'], $email]);
        }
        $stmt = $pdo->prepare('UPDATE FSG_users SET username = ?, email = ? WHERE id = ?');
        $stmt->execute([$username, $email, $userId]);
        $_SESSION['dd_username'] = $username;
        $_SESSION['username'] = $username;
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    return authPayload($pdo);
}

function changePassword(PDO $pdo, array $body): array
{
    $userId = currentUserId($pdo);
    if (!getUserById($pdo, $userId)) respondJson(['ok' => false, 'error' => 'You are not logged in.'], 401);
    $password = textValue($body['password'] ?? '');
    $passwordConfirm = textValue($body['passwordConfirm'] ?? '');
    if ($password !== $passwordConfirm) respondJson(['ok' => false, 'error' => 'Passwords do not match.'], 400);
    if (!passwordMeetsPolicy($password)) respondJson(['ok' => false, 'error' => 'Password must be at least 8 characters with 1 uppercase, 1 lowercase, 1 number, and 1 special character.'], 400);
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('UPDATE FSG_users SET password = ? WHERE id = ?');
        $stmt->execute([$hash, $userId]);
        $hist = $pdo->prepare("INSERT INTO FSG_user_identity_history (user_id, field_name, old_value, new_value) VALUES (?, 'password', '[password changed]', '[password changed]')");
        $hist->execute([$userId]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    return authPayload($pdo);
}

function generateUniqueSessionId(PDO $pdo): string
{
    for ($attempt = 0; $attempt < 25; $attempt++) {
        $bytes = strtoupper(bin2hex(random_bytes(8)));
        $sessionId = 'MD-' . substr($bytes, 0, 6) . '-' . substr($bytes, 6, 10);

        foreach (['FSG_MD_Workspaces', 'FSG_DD_Workspaces', 'FSG_DD_UserSessions'] as $tableName) {
            try {
                $stmt = $pdo->prepare("SELECT session_id FROM {$tableName} WHERE session_id = ? LIMIT 1");
                $stmt->execute([$sessionId]);
                if ($stmt->fetch()) continue 2;
            } catch (Throwable $e) {
                // The schema may not exist yet during first boot; the generated id is still valid.
            }
        }

        return $sessionId;
    }
    return 'MD-' . strtoupper(bin2hex(random_bytes(4))) . '-' . strtoupper(bin2hex(random_bytes(5)));
}

function touchUserSessionViewed(PDO $pdo, string $sessionId): void
{
    $userId = currentUserId($pdo);
    if ($userId <= 0 || trim($sessionId) === '') return;
    $stmt = $pdo->prepare('UPDATE FSG_DD_UserSessions SET last_viewed_at = CURRENT_TIMESTAMP WHERE user_id = ? AND session_id = ?');
    $stmt->execute([$userId, $sessionId]);
}

function attachWorkspaceToUserSession(PDO $pdo, string $sessionId, ?int $explicitUserId = null): void
{
    $userId = $explicitUserId !== null ? $explicitUserId : currentUserId();
    if ($userId <= 0 || trim($sessionId) === '') return;
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_UserSessions (user_id, session_id, first_pushed_at, last_pushed_at, last_viewed_at, workspace_count)
        VALUES (?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1)
        ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), last_pushed_at = CURRENT_TIMESTAMP, last_viewed_at = CURRENT_TIMESTAMP, workspace_count = workspace_count + 1');
    $stmt->execute([$userId, $sessionId]);
    if (function_exists('fsgAuth_touchServerSession')) {
        try { fsgAuth_touchServerSession($pdo, $userId, 'MenuDesigner', $sessionId, 'push'); } catch (Throwable $e) {}
    }
}

function requestBody(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        respondJson(['ok' => false, 'error' => 'Invalid JSON body.'], 400);
    }

    return $decoded;
}

function uuidv4(): string
{
    $data = random_bytes(16);
    $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
    $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

function textValue(mixed $value): string
{
    if ($value === null) return '';
    if (is_bool($value)) return $value ? '1' : '0';
    if (is_scalar($value)) return (string)$value;
    return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '';
}

function imageEntryDisplayName(mixed $value): string
{
    if ($value === null) return '';
    if (is_array($value)) {
        $candidateKeys = ['name', 'title', 'imageName', 'image_name', 'image', 'filename', 'fileName', 'value', 'key', 'label'];
        foreach ($candidateKeys as $key) {
            if (array_key_exists($key, $value)) {
                $candidate = imageEntryDisplayName($value[$key]);
                if ($candidate !== '') return $candidate;
            }
        }
        foreach ($value as $entry) {
            $candidate = imageEntryDisplayName($entry);
            if ($candidate !== '') return $candidate;
        }
        return '';
    }
    $text = trim(textValue($value));
    if ($text === '') return '';
    $first = substr($text, 0, 1);
    $last = substr($text, -1);
    if (($first === '{' && $last === '}') || ($first === '[' && $last === ']')) {
        $decoded = json_decode($text, true);
        if (is_array($decoded)) {
            $candidate = imageEntryDisplayName($decoded);
            if ($candidate !== '') return $candidate;
        } elseif (is_string($decoded)) {
            $candidate = trim($decoded);
            if ($candidate !== '') return $candidate;
        }
    }
    return $text;
}

function boolValue(mixed $value): int
{
    if (is_bool($value)) return $value ? 1 : 0;
    if (is_numeric($value)) return ((int)$value) !== 0 ? 1 : 0;
    if (is_string($value)) return in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true) ? 1 : 0;
    return 0;
}

function jsonText(mixed $value): string
{
    return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: 'null';
}

function arr(mixed $value): array
{
    return is_array($value) ? $value : [];
}

function insertLanguages(PDO $pdo, int $workspaceId, array $languages): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_Languages (workspace_id, language_code, sort_order) VALUES (?, ?, ?)');
    foreach (array_values($languages) as $index => $language) {
        $languageCode = strtoupper(trim(textValue($language)));
        if ($languageCode === '') continue;
        $stmt->execute([$workspaceId, $languageCode, $index]);
    }
}

function insertCast(PDO $pdo, int $workspaceId, array $items): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_Cast (workspace_id, sort_order, character_name, color, raw_json) VALUES (?, ?, ?, ?, ?)');
    foreach (array_values($items) as $index => $item) {
        $data = is_array($item) ? $item : ['name' => textValue($item), 'color' => ''];
        $stmt->execute([
            $workspaceId,
            $index,
            textValue($data['name'] ?? ''),
            textValue($data['color'] ?? ''),
            jsonText($data),
        ]);
    }
}

function insertGlobalTokens(PDO $pdo, int $workspaceId, array $items): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_GlobalTokens (workspace_id, sort_order, token_key, token_value, raw_json) VALUES (?, ?, ?, ?, ?)');
    foreach (array_values($items) as $index => $item) {
        $data = is_array($item) ? $item : ['key' => textValue($item), 'value' => ''];
        $stmt->execute([
            $workspaceId,
            $index,
            textValue($data['key'] ?? ''),
            textValue($data['value'] ?? ''),
            jsonText($data),
        ]);
    }
}

function insertNamedGlobals(PDO $pdo, int $workspaceId, string $tableName, array $items): void
{
    $allowed = [
        'FSG_DD_GlobalStates',
        'FSG_DD_GlobalMoods',
        'FSG_DD_GlobalSettings',
        'FSG_DD_GlobalTimesOfDay',
        'FSG_DD_GlobalDaysOfWeek',
        'FSG_DD_GlobalMenuOptions',
    ];
    if (!in_array($tableName, $allowed, true)) {
        throw new RuntimeException('Unsupported global table.');
    }

    $stmt = $pdo->prepare("INSERT INTO {$tableName} (workspace_id, sort_order, item_name, color, raw_json) VALUES (?, ?, ?, ?, ?)");
    foreach (array_values($items) as $index => $item) {
        $data = is_array($item) ? $item : ['name' => textValue($item), 'color' => ''];
        $stmt->execute([
            $workspaceId,
            $index,
            textValue($data['name'] ?? ''),
            textValue($data['color'] ?? ''),
            jsonText($data),
        ]);
    }
}

function insertImageSequences(PDO $pdo, int $workspaceId, array $items): void
{
    $seqStmt = $pdo->prepare('INSERT INTO FSG_DD_GlobalImageSequences (workspace_id, sort_order, sequence_name, color, path, raw_json) VALUES (?, ?, ?, ?, ?, ?)');
    $imgStmt = $pdo->prepare('INSERT INTO FSG_DD_GlobalImageSequenceImages (image_sequence_id, sort_order, image_name) VALUES (?, ?, ?)');

    foreach (array_values($items) as $index => $item) {
        $data = is_array($item) ? $item : ['name' => textValue($item), 'images' => []];
        $seqStmt->execute([
            $workspaceId,
            $index,
            textValue($data['name'] ?? ''),
            textValue($data['color'] ?? ''),
            textValue($data['path'] ?? ''),
            jsonText($data),
        ]);
        $sequenceId = (int)$pdo->lastInsertId();
        foreach (array_values(arr($data['images'] ?? [])) as $imgIndex => $imageName) {
            $cleanImageName = imageEntryDisplayName($imageName);
            if ($cleanImageName === '') continue;
            $imgStmt->execute([$sequenceId, $imgIndex, $cleanImageName]);
        }
    }
}


function decodeJsonAssoc(mixed $value): array
{
    if ($value === null) return [];
    $text = trim((string)$value);
    if ($text === '') return [];
    $decoded = json_decode($text, true);
    return is_array($decoded) ? $decoded : [];
}

function ddSharedTableAllowList(): array
{
    return [
        'FSG_DD_Languages',
        'FSG_DD_Cast',
        'FSG_DD_GlobalTokens',
        'FSG_DD_GlobalStates',
        'FSG_DD_GlobalMoods',
        'FSG_DD_GlobalSettings',
        'FSG_DD_GlobalTimesOfDay',
        'FSG_DD_GlobalDaysOfWeek',
        'FSG_DD_GlobalMenuOptions',
        'FSG_DD_GlobalImageSequences',
    ];
}

function assertAllowedDdSharedTable(string $tableName): string
{
    if (!in_array($tableName, ddSharedTableAllowList(), true)) {
        throw new RuntimeException('Unsupported shared Dialogue Designer table.');
    }
    return $tableName;
}

function latestDialogueWorkspaceIdForSession(PDO $pdo, string $sessionId): int
{
    $sessionId = trim($sessionId);
    if ($sessionId === '') return 0;
    $stmt = $pdo->prepare('SELECT id FROM FSG_DD_Workspaces WHERE session_id = ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$sessionId]);
    return (int)($stmt->fetchColumn() ?: 0);
}

function ddWorkspaceHasRows(PDO $pdo, int $workspaceId, string $tableName): bool
{
    $tableName = assertAllowedDdSharedTable($tableName);
    if ($workspaceId <= 0) return false;
    $stmt = $pdo->prepare("SELECT 1 FROM {$tableName} WHERE workspace_id = ? LIMIT 1");
    $stmt->execute([$workspaceId]);
    return (bool)$stmt->fetchColumn();
}

function latestDialogueWorkspaceIdWithRows(PDO $pdo, string $sessionId, string $tableName, int $preferredWorkspaceId = 0): int
{
    $tableName = assertAllowedDdSharedTable($tableName);
    $sessionId = trim($sessionId);

    if ($sessionId !== '') {
        $stmt = $pdo->prepare("SELECT w.id
            FROM FSG_DD_Workspaces w
            WHERE w.session_id = ?
              AND EXISTS (SELECT 1 FROM {$tableName} g WHERE g.workspace_id = w.id LIMIT 1)
            ORDER BY w.id DESC
            LIMIT 1");
        $stmt->execute([$sessionId]);
        $workspaceId = (int)($stmt->fetchColumn() ?: 0);
        if ($workspaceId > 0) return $workspaceId;
    }

    if ($preferredWorkspaceId > 0 && ddWorkspaceHasRows($pdo, $preferredWorkspaceId, $tableName)) {
        return $preferredWorkspaceId;
    }

    return 0;
}

function hydrateSharedLanguages(PDO $pdo, int $workspaceId): array
{
    if ($workspaceId <= 0) return [];
    $stmt = $pdo->prepare('SELECT current_language, available_languages_json FROM FSG_DD_Workspaces WHERE id = ? LIMIT 1');
    $stmt->execute([$workspaceId]);
    $workspace = $stmt->fetch() ?: [];

    $languages = [];
    $langStmt = $pdo->prepare('SELECT language_code FROM FSG_DD_Languages WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC');
    $langStmt->execute([$workspaceId]);
    foreach ($langStmt->fetchAll() as $row) {
        $code = strtoupper(trim(textValue($row['language_code'] ?? '')));
        if ($code !== '' && !in_array($code, $languages, true)) $languages[] = $code;
    }

    if (!$languages) {
        $decoded = decodeJsonAssoc($workspace['available_languages_json'] ?? null);
        foreach ($decoded as $language) {
            $code = strtoupper(trim(textValue($language)));
            if ($code !== '' && !in_array($code, $languages, true)) $languages[] = $code;
        }
    }

    if (!in_array('ENG', $languages, true)) array_unshift($languages, 'ENG');
    return [
        'availableLanguages' => $languages,
        'currentLanguage' => strtoupper(trim(textValue($workspace['current_language'] ?? 'ENG'))) ?: 'ENG',
    ];
}

function hydrateSharedCast(PDO $pdo, int $workspaceId): array
{
    if ($workspaceId <= 0) return [];
    $stmt = $pdo->prepare('SELECT id, character_name, color, raw_json FROM FSG_DD_Cast WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC');
    $stmt->execute([$workspaceId]);
    $items = [];
    foreach ($stmt->fetchAll() as $row) {
        $raw = decodeJsonAssoc($row['raw_json'] ?? null);
        $name = textValue($raw['name'] ?? $raw['character_name'] ?? $row['character_name'] ?? '');
        if (trim($name) === '') continue;
        $raw['id'] = textValue($raw['id'] ?? ('dd-cast-' . $row['id']));
        $raw['name'] = $name;
        $raw['color'] = textValue($raw['color'] ?? $row['color'] ?? '');
        $items[] = $raw;
    }
    return $items;
}

function hydrateSharedTokens(PDO $pdo, int $workspaceId): array
{
    if ($workspaceId <= 0) return [];
    $stmt = $pdo->prepare('SELECT id, token_key, token_value, raw_json FROM FSG_DD_GlobalTokens WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC');
    $stmt->execute([$workspaceId]);
    $items = [];
    foreach ($stmt->fetchAll() as $row) {
        $raw = decodeJsonAssoc($row['raw_json'] ?? null);
        $key = textValue($raw['key'] ?? $raw['token'] ?? $raw['name'] ?? $row['token_key'] ?? '');
        if (trim($key) === '') continue;
        $raw['key'] = $key;
        $raw['value'] = textValue($raw['value'] ?? $raw['defaultValue'] ?? $row['token_value'] ?? '');
        $items[] = $raw;
    }
    return $items;
}

function hydrateSharedNamedGlobals(PDO $pdo, int $workspaceId, string $tableName): array
{
    $tableName = assertAllowedDdSharedTable($tableName);
    if ($workspaceId <= 0) return [];
    $stmt = $pdo->prepare("SELECT id, item_name, color, raw_json FROM {$tableName} WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC");
    $stmt->execute([$workspaceId]);
    $items = [];
    foreach ($stmt->fetchAll() as $row) {
        $raw = decodeJsonAssoc($row['raw_json'] ?? null);
        $name = textValue($raw['name'] ?? $raw['title'] ?? $raw['key'] ?? $row['item_name'] ?? '');
        if (trim($name) === '') continue;
        $raw['id'] = textValue($raw['id'] ?? ('dd-global-' . $row['id']));
        $raw['name'] = $name;
        $raw['color'] = textValue($raw['color'] ?? $row['color'] ?? '');
        $items[] = $raw;
    }
    return $items;
}

function hydrateSharedImageSequences(PDO $pdo, int $workspaceId): array
{
    if ($workspaceId <= 0) return [];
    $seqStmt = $pdo->prepare('SELECT id, sequence_name, color, path, raw_json FROM FSG_DD_GlobalImageSequences WHERE workspace_id = ? ORDER BY sort_order ASC, id ASC');
    $seqStmt->execute([$workspaceId]);
    $imgStmt = $pdo->prepare('SELECT image_name FROM FSG_DD_GlobalImageSequenceImages WHERE image_sequence_id = ? ORDER BY sort_order ASC, id ASC');
    $items = [];
    foreach ($seqStmt->fetchAll() as $row) {
        $raw = decodeJsonAssoc($row['raw_json'] ?? null);
        $name = textValue($raw['name'] ?? $raw['title'] ?? $raw['sequence_name'] ?? $row['sequence_name'] ?? '');
        if (trim($name) === '') continue;
        $imgStmt->execute([(int)$row['id']]);
        $images = array_map(static fn($imgRow) => imageEntryDisplayName($imgRow['image_name'] ?? ''), $imgStmt->fetchAll());
        $images = array_values(array_filter($images, static fn($imageName) => trim($imageName) !== ''));
        $raw['id'] = textValue($raw['id'] ?? ('dd-image-seq-' . $row['id']));
        $raw['name'] = $name;
        $raw['color'] = textValue($raw['color'] ?? $row['color'] ?? '');
        $raw['path'] = textValue($raw['path'] ?? $row['path'] ?? '');
        $rawImages = array_map(static fn($imageName) => imageEntryDisplayName($imageName), arr($raw['images'] ?? []));
        $rawImages = array_values(array_filter($rawImages, static fn($imageName) => trim($imageName) !== ''));
        $raw['images'] = $images ?: $rawImages;
        $items[] = $raw;
    }
    return $items;
}

function arrayHasItems(mixed $value): bool
{
    return is_array($value) && count($value) > 0;
}

function mergeSharedDialogueSidebarFromTables(PDO $pdo, string $sessionId, int $preferredDdWorkspaceId, array $data): array
{
    $meta = [];
    $latestWorkspaceId = latestDialogueWorkspaceIdForSession($pdo, $sessionId);
    $languageWorkspaceId = latestDialogueWorkspaceIdWithRows($pdo, $sessionId, 'FSG_DD_Languages', $preferredDdWorkspaceId) ?: $latestWorkspaceId ?: $preferredDdWorkspaceId;
    $languages = hydrateSharedLanguages($pdo, $languageWorkspaceId);
    if (arrayHasItems($languages['availableLanguages'] ?? [])) {
        $data['availableLanguages'] = $languages['availableLanguages'];
        $data['currentLanguage'] = $languages['currentLanguage'] ?? ($data['currentLanguage'] ?? 'ENG');
        $meta['languagesWorkspaceId'] = $languageWorkspaceId;
    }

    $castWorkspaceId = latestDialogueWorkspaceIdWithRows($pdo, $sessionId, 'FSG_DD_Cast', $preferredDdWorkspaceId);
    $cast = hydrateSharedCast($pdo, $castWorkspaceId);
    if (arrayHasItems($cast)) {
        $data['cast'] = $cast;
        $data['globalCast'] = $cast;
        $meta['castWorkspaceId'] = $castWorkspaceId;
    }

    $tokensWorkspaceId = latestDialogueWorkspaceIdWithRows($pdo, $sessionId, 'FSG_DD_GlobalTokens', $preferredDdWorkspaceId);
    $tokens = hydrateSharedTokens($pdo, $tokensWorkspaceId);
    if (arrayHasItems($tokens)) {
        $data['globalTokens'] = $tokens;
        $meta['globalTokensWorkspaceId'] = $tokensWorkspaceId;
    }

    $namedMap = [
        'globalStates' => ['table' => 'FSG_DD_GlobalStates'],
        'globalMoods' => ['table' => 'FSG_DD_GlobalMoods'],
        'globalSettings' => ['table' => 'FSG_DD_GlobalSettings'],
        'globalTimesOfDay' => ['table' => 'FSG_DD_GlobalTimesOfDay', 'alias' => 'globalTimes'],
        'globalDaysOfWeek' => ['table' => 'FSG_DD_GlobalDaysOfWeek', 'alias' => 'globalDays'],
        'globalMenuOptions' => ['table' => 'FSG_DD_GlobalMenuOptions'],
    ];

    foreach ($namedMap as $payloadKey => $config) {
        $workspaceId = latestDialogueWorkspaceIdWithRows($pdo, $sessionId, $config['table'], $preferredDdWorkspaceId);
        $items = hydrateSharedNamedGlobals($pdo, $workspaceId, $config['table']);
        if (!arrayHasItems($items)) continue;
        $data[$payloadKey] = $items;
        if (isset($config['alias'])) $data[$config['alias']] = $items;
        $meta[$payloadKey . 'WorkspaceId'] = $workspaceId;
    }

    $imageSeqWorkspaceId = latestDialogueWorkspaceIdWithRows($pdo, $sessionId, 'FSG_DD_GlobalImageSequences', $preferredDdWorkspaceId);
    $imageSequences = hydrateSharedImageSequences($pdo, $imageSeqWorkspaceId);
    if (arrayHasItems($imageSequences)) {
        $data['globalImageSequences'] = $imageSequences;
        $meta['globalImageSequencesWorkspaceId'] = $imageSeqWorkspaceId;
    }

    $data['__sharedSidebarHydration'] = [
        'sessionId' => $sessionId,
        'preferredDialogueWorkspaceId' => $preferredDdWorkspaceId,
        'latestDialogueWorkspaceId' => $latestWorkspaceId,
        'sources' => $meta,
    ];

    return $data;
}

function hasSharedSidebarData(array $data): bool
{
    foreach (['cast', 'globalCast', 'globalTokens', 'globalStates', 'globalMoods', 'globalSettings', 'globalTimesOfDay', 'globalTimes', 'globalDaysOfWeek', 'globalDays', 'globalMenuOptions', 'globalImageSequences'] as $key) {
        if (arrayHasItems($data[$key] ?? null)) return true;
    }
    return false;
}

function loadSharedSidebarOnly(PDO $pdo, string $sessionId): array
{
    $latestWorkspaceId = latestDialogueWorkspaceIdForSession($pdo, $sessionId);
    if ($latestWorkspaceId <= 0) return [];
    $data = mergeSharedDialogueSidebarFromTables($pdo, $sessionId, $latestWorkspaceId, [
        'version' => 'shared-sidebar-only',
        'app' => 'MenuDesigner',
        'serverSessionId' => $sessionId,
        'sessionId' => $sessionId,
        'currentLanguage' => 'ENG',
        'availableLanguages' => ['ENG'],
    ]);
    return hasSharedSidebarData($data) ? $data : [];
}

function collectProjectLogic(array $project): array
{
    $tags = [];
    $add = static function (mixed $key, mixed $value, string $type) use (&$tags): void {
        $variable = trim(textValue($key));
        $val = textValue($value);
        if ($variable === '' && trim($val) === '') return;
        $mapKey = $variable . "\0" . $val;
        if (!isset($tags[$mapKey])) {
            $tags[$mapKey] = [
                'key' => $variable,
                'value' => $val,
                'condition_count' => 0,
                'state_change_count' => 0,
            ];
        }
        if ($type === 'condition') $tags[$mapKey]['condition_count']++;
        if ($type === 'state') $tags[$mapKey]['state_change_count']++;
    };

    foreach (arr($project['nodes'] ?? []) as $node) {
        foreach (arr($node['conditions'] ?? []) as $condition) $add($condition['variable'] ?? '', $condition['value'] ?? '', 'condition');
        foreach (arr($node['gameStateChanges'] ?? []) as $change) $add($change['variable'] ?? '', $change['value'] ?? '', 'state');
        foreach (arr($node['responses'] ?? []) as $response) {
            foreach (arr($response['conditions'] ?? []) as $condition) $add($condition['variable'] ?? '', $condition['value'] ?? '', 'condition');
            foreach (arr($response['gameStateChanges'] ?? []) as $change) $add($change['variable'] ?? '', $change['value'] ?? '', 'state');
        }
    }

    return array_values($tags);
}

function insertActiveProjectLogic(PDO $pdo, int $projectId, array $project): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_ActiveProjectLogic (project_id, sort_order, key_variable, value_text, condition_count, state_change_count, total_references, usage_classification) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (collectProjectLogic($project) as $index => $tag) {
        $conditionCount = (int)$tag['condition_count'];
        $stateCount = (int)$tag['state_change_count'];
        $usage = 'Matched';
        if ($conditionCount > 0 && $stateCount === 0) $usage = 'Condition Only';
        if ($conditionCount === 0 && $stateCount > 0) $usage = 'State Change Only';
        $stmt->execute([
            $projectId,
            $index,
            $tag['key'],
            $tag['value'],
            $conditionCount,
            $stateCount,
            $conditionCount + $stateCount,
            $usage,
        ]);
    }
}

function insertLogicRows(PDO $pdo, string $tableName, string $ownerColumn, int $ownerId, array $rows): void
{
    $allowed = [
        'FSG_DD_NodeConditions' => 'node_id',
        'FSG_DD_NodeGameStateChanges' => 'node_id',
        'FSG_DD_ResponseConditions' => 'response_id',
        'FSG_DD_ResponseGameStateChanges' => 'response_id',
    ];
    if (!isset($allowed[$tableName]) || $allowed[$tableName] !== $ownerColumn) {
        throw new RuntimeException('Unsupported logic row target.');
    }

    $stmt = $pdo->prepare("INSERT INTO {$tableName} ({$ownerColumn}, sort_order, key_variable, operator_text, value_text) VALUES (?, ?, ?, ?, ?)");
    foreach (array_values($rows) as $index => $row) {
        $data = is_array($row) ? $row : [];
        $stmt->execute([
            $ownerId,
            $index,
            textValue($data['variable'] ?? ''),
            textValue($data['operator'] ?? '==') ?: '==',
            textValue($data['value'] ?? ''),
        ]);
    }
}

function insertNamedChangeRows(PDO $pdo, string $tableName, string $ownerColumn, string $nameColumn, int $ownerId, array $rows, string $sourceNameKey): void
{
    $allowed = [
        'FSG_DD_NodeTimeOfDayChanges' => ['node_id', 'time_name'],
        'FSG_DD_NodeDayOfWeekChanges' => ['node_id', 'day_name'],
        'FSG_DD_NodeMenuOptionChanges' => ['node_id', 'menu_name'],
        'FSG_DD_NodeSettingChanges' => ['node_id', 'setting_name'],
        'FSG_DD_ResponseTimeOfDayChanges' => ['response_id', 'time_name'],
        'FSG_DD_ResponseDayOfWeekChanges' => ['response_id', 'day_name'],
        'FSG_DD_ResponseMenuOptionChanges' => ['response_id', 'menu_name'],
        'FSG_DD_ResponseSettingChanges' => ['response_id', 'setting_name'],
    ];
    if (!isset($allowed[$tableName]) || $allowed[$tableName] !== [$ownerColumn, $nameColumn]) {
        throw new RuntimeException('Unsupported named change target.');
    }

    $stmt = $pdo->prepare("INSERT INTO {$tableName} ({$ownerColumn}, sort_order, {$nameColumn}, value_text) VALUES (?, ?, ?, ?)");
    foreach (array_values($rows) as $index => $row) {
        $data = is_array($row) ? $row : [];
        $stmt->execute([
            $ownerId,
            $index,
            textValue($data[$sourceNameKey] ?? ''),
            textValue($data['value'] ?? ''),
        ]);
    }
}

function insertPuppets(PDO $pdo, string $tableName, string $ownerColumn, int $ownerId, array $puppets): void
{
    $allowed = [
        'FSG_DD_NodePuppets' => 'node_id',
        'FSG_DD_ResponsePuppets' => 'response_id',
    ];
    if (!isset($allowed[$tableName]) || $allowed[$tableName] !== $ownerColumn) {
        throw new RuntimeException('Unsupported puppet target.');
    }

    $stmt = $pdo->prepare("INSERT INTO {$tableName} ({$ownerColumn}, sort_order, puppet_name, enabled, position_text, path, state_name, mood_name, invert, raw_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    foreach (array_values($puppets) as $index => $puppet) {
        $data = is_array($puppet) ? $puppet : [];
        $stmt->execute([
            $ownerId,
            $index,
            textValue($data['name'] ?? ''),
            boolValue($data['enabled'] ?? true),
            textValue($data['position'] ?? ''),
            textValue($data['path'] ?? ''),
            textValue($data['state'] ?? ''),
            textValue($data['mood'] ?? ''),
            boolValue($data['invert'] ?? false),
            jsonText($data),
        ]);
    }
}

function insertTranslations(PDO $pdo, string $tableName, string $ownerColumn, int $ownerId, array $translations): void
{
    $allowed = [
        'FSG_DD_NodeTranslations' => 'node_id',
        'FSG_DD_ResponseTranslations' => 'response_id',
    ];
    if (!isset($allowed[$tableName]) || $allowed[$tableName] !== $ownerColumn) {
        throw new RuntimeException('Unsupported translation target.');
    }

    $stmt = $pdo->prepare("INSERT INTO {$tableName} ({$ownerColumn}, language_code, text) VALUES (?, ?, ?)");
    foreach ($translations as $language => $text) {
        $languageCode = strtoupper(trim(textValue($language)));
        if ($languageCode === '') continue;
        $stmt->execute([$ownerId, $languageCode, textValue($text)]);
    }
}

function insertResponses(PDO $pdo, int $nodeId, array $responses): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_Responses (
        node_id, response_uuid, sort_order, speaker, text, next_statement_uuid, auto_increment_flag, voice_line, is_collapsed, advanced_open, conditions_open, states_open,
        resource_path, use_path, close_main_menu, close_dialogue_menu, open_prompt_panel, close_prompt_panel, change_time_of_day, change_day_of_week,
        change_menu_option, change_setting, control_sequence, sequence_name, sequence_image, control_puppets, puppet_use_path, puppet_use_tag,
        change_puppet_state, change_puppet_mood, change_puppet_invert, text_format_json, raw_json
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');

    foreach (array_values($responses) as $index => $response) {
        $r = is_array($response) ? $response : [];
        $responseUuid = textValue($r['id'] ?? '') ?: uuidv4();
        $stmt->execute([
            $nodeId,
            $responseUuid,
            $index,
            textValue($r['speaker'] ?? ''),
            textValue($r['text'] ?? ''),
            textValue($r['nextStatementId'] ?? '') ?: null,
            boolValue($r['autoIncrement'] ?? false),
            boolValue($r['voiceLine'] ?? false),
            boolValue($r['isCollapsed'] ?? false),
            boolValue($r['advancedOpen'] ?? false),
            boolValue($r['conditionsOpen'] ?? true),
            boolValue($r['statesOpen'] ?? true),
            textValue($r['resourcePath'] ?? ''),
            boolValue($r['usePath'] ?? false),
            boolValue($r['closeMainMenu'] ?? false),
            boolValue($r['closeDialogueMenu'] ?? false),
            boolValue($r['openPromptPanel'] ?? false),
            boolValue($r['closePromptPanel'] ?? false),
            boolValue($r['changeTimeOfDay'] ?? false),
            boolValue($r['changeDayOfWeek'] ?? false),
            boolValue($r['changeMenuOption'] ?? false),
            boolValue($r['changeSetting'] ?? false),
            boolValue($r['controlSequence'] ?? false),
            textValue($r['sequenceName'] ?? ''),
            textValue($r['sequenceImage'] ?? ''),
            boolValue($r['controlPuppets'] ?? false),
            boolValue($r['puppetUsePath'] ?? false),
            boolValue($r['puppetUseTag'] ?? false),
            boolValue($r['changePuppetState'] ?? false),
            boolValue($r['changePuppetMood'] ?? false),
            boolValue($r['changePuppetInvert'] ?? false),
            jsonText($r['textFormat'] ?? null),
            jsonText($r),
        ]);
        $responseId = (int)$pdo->lastInsertId();

        insertTranslations($pdo, 'FSG_DD_ResponseTranslations', 'response_id', $responseId, arr($r['translations'] ?? []));
        insertLogicRows($pdo, 'FSG_DD_ResponseConditions', 'response_id', $responseId, arr($r['conditions'] ?? []));
        insertLogicRows($pdo, 'FSG_DD_ResponseGameStateChanges', 'response_id', $responseId, arr($r['gameStateChanges'] ?? []));
        insertNamedChangeRows($pdo, 'FSG_DD_ResponseTimeOfDayChanges', 'response_id', 'time_name', $responseId, arr($r['timeOfDayChanges'] ?? []), 'time');
        insertNamedChangeRows($pdo, 'FSG_DD_ResponseDayOfWeekChanges', 'response_id', 'day_name', $responseId, arr($r['dayOfWeekChanges'] ?? []), 'day');
        insertNamedChangeRows($pdo, 'FSG_DD_ResponseMenuOptionChanges', 'response_id', 'menu_name', $responseId, arr($r['menuOptionChanges'] ?? []), 'menu');
        insertNamedChangeRows($pdo, 'FSG_DD_ResponseSettingChanges', 'response_id', 'setting_name', $responseId, arr($r['settingChanges'] ?? []), 'setting');
        insertPuppets($pdo, 'FSG_DD_ResponsePuppets', 'response_id', $responseId, arr($r['puppets'] ?? []));
    }
}

function insertNodes(PDO $pdo, int $projectId, array $nodes): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_Nodes (
        project_id, node_uuid, sort_order, speaker, text, node_color, voice_line, is_collapsed, advanced_open, conditions_open, states_open, responses_open,
        resource_path, use_path, close_main_menu, close_dialogue_menu, open_prompt_panel, close_prompt_panel, change_time_of_day, change_day_of_week,
        change_menu_option, change_setting, control_sequence, sequence_name, sequence_image, control_puppets, puppet_use_path, puppet_use_tag,
        change_puppet_state, change_puppet_mood, change_puppet_invert, can_player_respond, external_call, make_external_call, parent_response_uuid,
        parent_response_preview, text_format_json, raw_json
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');

    foreach (array_values($nodes) as $index => $node) {
        $n = is_array($node) ? $node : [];
        $nodeUuid = textValue($n['id'] ?? '') ?: uuidv4();
        $stmt->execute([
            $projectId,
            $nodeUuid,
            $index,
            textValue($n['speaker'] ?? ''),
            textValue($n['text'] ?? ''),
            textValue($n['nodeColor'] ?? ''),
            boolValue($n['voiceLine'] ?? true),
            boolValue($n['isCollapsed'] ?? false),
            boolValue($n['advancedOpen'] ?? false),
            boolValue($n['conditionsOpen'] ?? true),
            boolValue($n['statesOpen'] ?? true),
            boolValue($n['responsesOpen'] ?? true),
            textValue($n['resourcePath'] ?? ''),
            boolValue($n['usePath'] ?? false),
            boolValue($n['closeMainMenu'] ?? false),
            boolValue($n['closeDialogueMenu'] ?? false),
            boolValue($n['openPromptPanel'] ?? false),
            boolValue($n['closePromptPanel'] ?? false),
            boolValue($n['changeTimeOfDay'] ?? false),
            boolValue($n['changeDayOfWeek'] ?? false),
            boolValue($n['changeMenuOption'] ?? false),
            boolValue($n['changeSetting'] ?? false),
            boolValue($n['controlSequence'] ?? false),
            textValue($n['sequenceName'] ?? ''),
            textValue($n['sequenceImage'] ?? ''),
            boolValue($n['controlPuppets'] ?? false),
            boolValue($n['puppetUsePath'] ?? false),
            boolValue($n['puppetUseTag'] ?? false),
            boolValue($n['changePuppetState'] ?? false),
            boolValue($n['changePuppetMood'] ?? false),
            boolValue($n['changePuppetInvert'] ?? false),
            boolValue($n['canPlayerRespond'] ?? false),
            boolValue($n['externalCall'] ?? false),
            boolValue($n['makeExternalCall'] ?? false),
            textValue($n['parentResponseId'] ?? '') ?: null,
            textValue($n['parentResponsePreview'] ?? ''),
            jsonText($n['textFormat'] ?? null),
            jsonText($n),
        ]);
        $nodeId = (int)$pdo->lastInsertId();

        insertTranslations($pdo, 'FSG_DD_NodeTranslations', 'node_id', $nodeId, arr($n['translations'] ?? []));
        insertLogicRows($pdo, 'FSG_DD_NodeConditions', 'node_id', $nodeId, arr($n['conditions'] ?? []));
        insertLogicRows($pdo, 'FSG_DD_NodeGameStateChanges', 'node_id', $nodeId, arr($n['gameStateChanges'] ?? []));
        insertNamedChangeRows($pdo, 'FSG_DD_NodeTimeOfDayChanges', 'node_id', 'time_name', $nodeId, arr($n['timeOfDayChanges'] ?? []), 'time');
        insertNamedChangeRows($pdo, 'FSG_DD_NodeDayOfWeekChanges', 'node_id', 'day_name', $nodeId, arr($n['dayOfWeekChanges'] ?? []), 'day');
        insertNamedChangeRows($pdo, 'FSG_DD_NodeMenuOptionChanges', 'node_id', 'menu_name', $nodeId, arr($n['menuOptionChanges'] ?? []), 'menu');
        insertNamedChangeRows($pdo, 'FSG_DD_NodeSettingChanges', 'node_id', 'setting_name', $nodeId, arr($n['settingChanges'] ?? []), 'setting');
        insertPuppets($pdo, 'FSG_DD_NodePuppets', 'node_id', $nodeId, arr($n['puppets'] ?? []));
        insertResponses($pdo, $nodeId, arr($n['responses'] ?? []));
    }
}

function insertProjects(PDO $pdo, int $workspaceId, string $projectType, array $projects): int
{
    $inserted = 0;
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_Projects (workspace_id, project_uuid, project_type, sort_order, title, color, is_repeatable, repeat_variable, raw_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $participantStmt = $pdo->prepare('INSERT INTO FSG_DD_ProjectParticipants (project_id, sort_order, participant_name) VALUES (?, ?, ?)');

    foreach (array_values($projects) as $index => $project) {
        $p = is_array($project) ? $project : [];
        $projectUuid = textValue($p['id'] ?? '') ?: uuidv4();
        $stmt->execute([
            $workspaceId,
            $projectUuid,
            $projectType,
            $index,
            textValue($p['title'] ?? ''),
            textValue($p['color'] ?? ''),
            boolValue($p['isRepeatable'] ?? false),
            textValue($p['repeatVariable'] ?? ''),
            jsonText($p),
        ]);
        $projectId = (int)$pdo->lastInsertId();
        $inserted++;

        foreach (array_values(arr($p['participants'] ?? [])) as $participantIndex => $participant) {
            $participantStmt->execute([$projectId, $participantIndex, textValue($participant)]);
        }

        insertActiveProjectLogic($pdo, $projectId, $p);
        insertNodes($pdo, $projectId, arr($p['nodes'] ?? []));
    }

    return $inserted;
}

function ensureColumn(PDO $pdo, string $tableName, string $columnName, string $alterSql): void
{
    try {
        $check = $pdo->query("SHOW COLUMNS FROM {$tableName} LIKE " . $pdo->quote($columnName));
        if ($check && $check->rowCount() === 0) $pdo->exec($alterSql);
    } catch (Throwable $e) {}
}

function ensureSharedDialogueTablesForMenuDesigner(PDO $pdo): void
{
    $sharedUserIdSqlType = sharedFsgUserIdSqlType($pdo);

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DD_Workspaces (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_uuid VARCHAR(64) NOT NULL,
        session_id VARCHAR(96) NOT NULL DEFAULT '',
        user_id {$sharedUserIdSqlType} NULL DEFAULT NULL,
        version VARCHAR(32) NOT NULL DEFAULT '',
        current_language VARCHAR(16) NOT NULL DEFAULT 'ENG',
        available_languages_json JSON NULL,
        raw_json LONGTEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_FSG_DD_Workspaces_session_created (session_id, created_at),
        KEY idx_FSG_DD_Workspaces_user_session (user_id, session_id, created_at),
        KEY idx_FSG_DD_Workspaces_uuid (workspace_uuid)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    ensureColumn($pdo, 'FSG_DD_Workspaces', 'user_id', "ALTER TABLE FSG_DD_Workspaces ADD COLUMN user_id {$sharedUserIdSqlType} NULL DEFAULT NULL AFTER session_id");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DD_RawJsonSnapshots (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        snapshot_label VARCHAR(128) NOT NULL DEFAULT '',
        raw_json LONGTEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_FSG_DD_RawJsonSnapshots_workspace (workspace_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DD_Languages (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        language_code VARCHAR(16) NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        KEY idx_FSG_DD_Languages_workspace (workspace_id, sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DD_Cast (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        character_name VARCHAR(255) NOT NULL DEFAULT '',
        color VARCHAR(32) NOT NULL DEFAULT '',
        raw_json JSON NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_DD_Cast_workspace (workspace_id, sort_order),
        KEY idx_FSG_DD_Cast_name (character_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DD_GlobalTokens (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        token_key VARCHAR(255) NOT NULL DEFAULT '',
        token_value TEXT NULL,
        raw_json JSON NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_DD_GlobalTokens_workspace (workspace_id, sort_order),
        KEY idx_FSG_DD_GlobalTokens_key (token_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    foreach (['FSG_DD_GlobalStates', 'FSG_DD_GlobalMoods', 'FSG_DD_GlobalSettings', 'FSG_DD_GlobalTimesOfDay', 'FSG_DD_GlobalDaysOfWeek', 'FSG_DD_GlobalMenuOptions'] as $tableName) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS {$tableName} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            workspace_id BIGINT UNSIGNED NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            item_name VARCHAR(255) NOT NULL DEFAULT '',
            color VARCHAR(32) NOT NULL DEFAULT '',
            raw_json JSON NULL,
            PRIMARY KEY (id),
            KEY idx_{$tableName}_workspace (workspace_id, sort_order),
            KEY idx_{$tableName}_name (item_name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DD_GlobalImageSequences (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        sequence_name VARCHAR(255) NOT NULL DEFAULT '',
        color VARCHAR(32) NOT NULL DEFAULT '',
        path TEXT NULL,
        raw_json JSON NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_DD_GlobalImageSequences_workspace (workspace_id, sort_order),
        KEY idx_FSG_DD_GlobalImageSequences_name (sequence_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DD_GlobalImageSequenceImages (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        image_sequence_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        image_name TEXT NOT NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_DD_GlobalImageSequenceImages_sequence (image_sequence_id, sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function ensureMenuDesignerTables(PDO $pdo): void
{
    $sharedUserIdSqlType = sharedFsgUserIdSqlType($pdo);

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_MD_Workspaces (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_uuid VARCHAR(64) NOT NULL,
        dd_workspace_id BIGINT UNSIGNED NULL DEFAULT NULL,
        session_id VARCHAR(96) NOT NULL DEFAULT '',
        user_id {$sharedUserIdSqlType} NULL DEFAULT NULL,
        app_version VARCHAR(32) NOT NULL DEFAULT '',
        current_language VARCHAR(16) NOT NULL DEFAULT 'ENG',
        available_languages_json JSON NULL,
        global_max_options INT NOT NULL DEFAULT 5,
        active_context VARCHAR(255) NOT NULL DEFAULT 'ROOT',
        active_character VARCHAR(255) NOT NULL DEFAULT '',
        raw_json LONGTEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_FSG_MD_Workspaces_session_created (session_id, created_at),
        KEY idx_FSG_MD_Workspaces_user_session (user_id, session_id, created_at),
        KEY idx_FSG_MD_Workspaces_dd_workspace (dd_workspace_id),
        KEY idx_FSG_MD_Workspaces_uuid (workspace_uuid)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_MD_ImportedConversations (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        title VARCHAR(255) NOT NULL DEFAULT '',
        color VARCHAR(32) NOT NULL DEFAULT '',
        participants_json JSON NULL,
        raw_json JSON NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_MD_ImportedConversations_workspace (workspace_id, sort_order),
        KEY idx_FSG_MD_ImportedConversations_title (title)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_MD_MenuContexts (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        context_key VARCHAR(255) NOT NULL DEFAULT '',
        context_title VARCHAR(255) NOT NULL DEFAULT '',
        raw_json JSON NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_MD_MenuContexts_workspace_key (workspace_id, context_key),
        KEY idx_FSG_MD_MenuContexts_workspace (workspace_id, sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_MD_MenuCharacters (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        context_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        character_name VARCHAR(255) NOT NULL DEFAULT '',
        is_dismissed TINYINT(1) NOT NULL DEFAULT 0,
        raw_json JSON NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_MD_MenuCharacters_context_name (context_id, character_name),
        KEY idx_FSG_MD_MenuCharacters_context (context_id, sort_order),
        KEY idx_FSG_MD_MenuCharacters_name (character_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_MD_MenuOptions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        context_id BIGINT UNSIGNED NOT NULL,
        character_id BIGINT UNSIGNED NOT NULL,
        parent_option_id BIGINT UNSIGNED NULL DEFAULT NULL,
        option_uuid VARCHAR(64) NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        depth INT NOT NULL DEFAULT 0,
        title VARCHAR(255) NOT NULL DEFAULT '',
        identity_color VARCHAR(32) NOT NULL DEFAULT '',
        button_label_text_format_json JSON NULL,
        characters_response LONGTEXT NULL,
        button_text TEXT NULL,
        use_button TINYINT(1) NOT NULL DEFAULT 0,
        close_main_menu TINYINT(1) NOT NULL DEFAULT 0,
        close_dialogue TINYINT(1) NOT NULL DEFAULT 0,
        reopen_dialogue TINYINT(1) NOT NULL DEFAULT 0,
        reopen_prompt_panel TINYINT(1) NOT NULL DEFAULT 0,
        close_prompt_panel TINYINT(1) NOT NULL DEFAULT 0,
        is_called_externally TINYINT(1) NOT NULL DEFAULT 0,
        make_external_call TINYINT(1) NOT NULL DEFAULT 0,
        is_return_to_parent TINYINT(1) NOT NULL DEFAULT 0,
        parent_menu_select VARCHAR(255) NOT NULL DEFAULT '',
        is_link_to_menu TINYINT(1) NOT NULL DEFAULT 0,
        link_menu_select VARCHAR(255) NOT NULL DEFAULT '',
        resource_path TEXT NULL,
        use_path TINYINT(1) NOT NULL DEFAULT 0,
        control_puppets TINYINT(1) NOT NULL DEFAULT 0,
        change_puppets TINYINT(1) NOT NULL DEFAULT 0,
        change_puppet_state TINYINT(1) NOT NULL DEFAULT 0,
        change_puppet_mood TINYINT(1) NOT NULL DEFAULT 0,
        change_puppet_invert TINYINT(1) NOT NULL DEFAULT 0,
        raw_json JSON NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_MD_MenuOptions_workspace (workspace_id),
        KEY idx_FSG_MD_MenuOptions_context_character (context_id, character_id, sort_order),
        KEY idx_FSG_MD_MenuOptions_parent (parent_option_id, sort_order),
        KEY idx_FSG_MD_MenuOptions_uuid (option_uuid),
        KEY idx_FSG_MD_MenuOptions_title (title)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_MD_MenuOptionAvailabilityConditions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        option_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        logic_key VARCHAR(255) NOT NULL DEFAULT '',
        operator VARCHAR(16) NOT NULL DEFAULT '',
        value_text TEXT NULL,
        raw_json JSON NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_MD_MenuOptionAvailabilityConditions_option (option_id, sort_order),
        KEY idx_FSG_MD_MenuOptionAvailabilityConditions_key (logic_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_MD_MenuOptionOnPressResults (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        option_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        logic_key VARCHAR(255) NOT NULL DEFAULT '',
        operator VARCHAR(16) NOT NULL DEFAULT '',
        value_text TEXT NULL,
        raw_json JSON NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_MD_MenuOptionOnPressResults_option (option_id, sort_order),
        KEY idx_FSG_MD_MenuOptionOnPressResults_key (logic_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    foreach ([
        'FSG_MD_MenuOptionTimeOfDayChanges' => 'time_name',
        'FSG_MD_MenuOptionDayOfWeekChanges' => 'day_name',
        'FSG_MD_MenuOptionSettingChanges' => 'setting_name',
    ] as $tableName => $nameColumn) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS {$tableName} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            option_id BIGINT UNSIGNED NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            {$nameColumn} VARCHAR(255) NOT NULL DEFAULT '',
            value_text TEXT NULL,
            raw_json JSON NULL,
            PRIMARY KEY (id),
            KEY idx_{$tableName}_option (option_id, sort_order),
            KEY idx_{$tableName}_name ({$nameColumn})
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_MD_MenuOptionPuppets (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        option_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        puppet_name VARCHAR(255) NOT NULL DEFAULT '',
        enabled TINYINT(1) NOT NULL DEFAULT 1,
        position_name VARCHAR(255) NOT NULL DEFAULT '',
        path TEXT NULL,
        state_name VARCHAR(255) NOT NULL DEFAULT '',
        mood_name VARCHAR(255) NOT NULL DEFAULT '',
        invert TINYINT(1) NOT NULL DEFAULT 0,
        raw_json JSON NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_MD_MenuOptionPuppets_option (option_id, sort_order),
        KEY idx_FSG_MD_MenuOptionPuppets_name (puppet_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_MD_MenuReplyPhases (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        option_id BIGINT UNSIGNED NOT NULL,
        phase_uuid VARCHAR(64) NOT NULL DEFAULT '',
        sort_order INT NOT NULL DEFAULT 0,
        speaker VARCHAR(255) NOT NULL DEFAULT '',
        text LONGTEXT NULL,
        raw_json JSON NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_MD_MenuReplyPhases_option (option_id, sort_order),
        KEY idx_FSG_MD_MenuReplyPhases_uuid (phase_uuid),
        KEY idx_FSG_MD_MenuReplyPhases_speaker (speaker)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_MD_MenuReplyPhasePuppets (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        reply_phase_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        puppet_name VARCHAR(255) NOT NULL DEFAULT '',
        enabled TINYINT(1) NOT NULL DEFAULT 1,
        position_name VARCHAR(255) NOT NULL DEFAULT '',
        path TEXT NULL,
        state_name VARCHAR(255) NOT NULL DEFAULT '',
        mood_name VARCHAR(255) NOT NULL DEFAULT '',
        invert TINYINT(1) NOT NULL DEFAULT 0,
        raw_json JSON NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_MD_MenuReplyPhasePuppets_phase (reply_phase_id, sort_order),
        KEY idx_FSG_MD_MenuReplyPhasePuppets_name (puppet_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_MD_DismissedCharacters (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        context_key VARCHAR(255) NOT NULL DEFAULT '',
        character_name VARCHAR(255) NOT NULL DEFAULT '',
        PRIMARY KEY (id),
        KEY idx_FSG_MD_DismissedCharacters_workspace (workspace_id, context_key),
        KEY idx_FSG_MD_DismissedCharacters_character (character_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_MD_ActiveProjectLogic (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        logic_group ENUM('logic','gameplay') NOT NULL DEFAULT 'logic',
        key_variable VARCHAR(255) NOT NULL DEFAULT '',
        operator VARCHAR(16) NOT NULL DEFAULT '',
        value_text TEXT NULL,
        format_text TEXT NULL,
        total_references INT NOT NULL DEFAULT 0,
        usage_classification VARCHAR(64) NOT NULL DEFAULT '',
        raw_json JSON NULL,
        PRIMARY KEY (id),
        KEY idx_FSG_MD_ActiveProjectLogic_workspace (workspace_id, sort_order),
        KEY idx_FSG_MD_ActiveProjectLogic_key (key_variable),
        KEY idx_FSG_MD_ActiveProjectLogic_group (logic_group)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    ensureColumn($pdo, 'FSG_MD_MenuOptions', 'identity_color', "ALTER TABLE FSG_MD_MenuOptions ADD COLUMN identity_color VARCHAR(32) NOT NULL DEFAULT '' AFTER title");
    ensureColumn($pdo, 'FSG_MD_MenuOptions', 'button_label_text_format_json', "ALTER TABLE FSG_MD_MenuOptions ADD COLUMN button_label_text_format_json JSON NULL AFTER identity_color");
}

function insertMenuImportedConversations(PDO $pdo, int $workspaceId, array $items): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_MD_ImportedConversations (workspace_id, sort_order, title, color, participants_json, raw_json) VALUES (?, ?, ?, ?, ?, ?)');
    foreach (array_values($items) as $index => $item) {
        $data = is_array($item) ? $item : ['title' => textValue($item)];
        $stmt->execute([
            $workspaceId,
            $index,
            textValue($data['title'] ?? $data['name'] ?? ''),
            textValue($data['color'] ?? ''),
            jsonText(arr($data['participants'] ?? [])),
            jsonText($data),
        ]);
    }
}

function insertMenuLogicRows(PDO $pdo, string $tableName, int $optionId, array $items): void
{
    $allowed = ['FSG_MD_MenuOptionAvailabilityConditions', 'FSG_MD_MenuOptionOnPressResults'];
    if (!in_array($tableName, $allowed, true)) throw new RuntimeException('Unsupported MenuDesigner logic table.');
    $stmt = $pdo->prepare("INSERT INTO {$tableName} (option_id, sort_order, logic_key, operator, value_text, raw_json) VALUES (?, ?, ?, ?, ?, ?)");
    foreach (array_values($items) as $index => $item) {
        $data = is_array($item) ? $item : [];
        $stmt->execute([
            $optionId,
            $index,
            textValue($data['key'] ?? $data['variable'] ?? ''),
            textValue($data['op'] ?? $data['operator'] ?? ''),
            textValue($data['val'] ?? $data['value'] ?? ''),
            jsonText($data),
        ]);
    }
}

function insertMenuNamedChangeRows(PDO $pdo, string $tableName, string $nameColumn, int $optionId, array $items, string $sourceKey): void
{
    $allowed = [
        'FSG_MD_MenuOptionTimeOfDayChanges' => 'time_name',
        'FSG_MD_MenuOptionDayOfWeekChanges' => 'day_name',
        'FSG_MD_MenuOptionSettingChanges' => 'setting_name',
    ];
    if (($allowed[$tableName] ?? '') !== $nameColumn) throw new RuntimeException('Unsupported MenuDesigner named change table.');
    $stmt = $pdo->prepare("INSERT INTO {$tableName} (option_id, sort_order, {$nameColumn}, value_text, raw_json) VALUES (?, ?, ?, ?, ?)");
    foreach (array_values($items) as $index => $item) {
        $data = is_array($item) ? $item : [];
        $stmt->execute([
            $optionId,
            $index,
            textValue($data[$sourceKey] ?? $data['name'] ?? ''),
            textValue($data['value'] ?? $data['val'] ?? ''),
            jsonText($data),
        ]);
    }
}

function insertMenuOptionPuppets(PDO $pdo, string $tableName, string $ownerColumn, int $ownerId, array $items): void
{
    $allowed = [
        'FSG_MD_MenuOptionPuppets' => 'option_id',
        'FSG_MD_MenuReplyPhasePuppets' => 'reply_phase_id',
    ];
    if (($allowed[$tableName] ?? '') !== $ownerColumn) throw new RuntimeException('Unsupported MenuDesigner puppet table.');
    $stmt = $pdo->prepare("INSERT INTO {$tableName} ({$ownerColumn}, sort_order, puppet_name, enabled, position_name, path, state_name, mood_name, invert, raw_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    foreach (array_values($items) as $index => $item) {
        $data = is_array($item) ? $item : ['name' => textValue($item)];
        $stmt->execute([
            $ownerId,
            $index,
            textValue($data['name'] ?? $data['puppet'] ?? ''),
            boolValue($data['enabled'] ?? true),
            textValue($data['position'] ?? $data['positionName'] ?? ''),
            textValue($data['path'] ?? ''),
            textValue($data['state'] ?? $data['stateName'] ?? ''),
            textValue($data['mood'] ?? $data['moodName'] ?? ''),
            boolValue($data['invert'] ?? false),
            jsonText($data),
        ]);
    }
}

function insertMenuReplyPhases(PDO $pdo, int $optionId, array $items): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_MD_MenuReplyPhases (option_id, phase_uuid, sort_order, speaker, text, raw_json) VALUES (?, ?, ?, ?, ?, ?)');
    foreach (array_values($items) as $index => $item) {
        $data = is_array($item) ? $item : [];
        $phaseUuid = textValue($data['id'] ?? '') ?: uuidv4();
        $stmt->execute([
            $optionId,
            $phaseUuid,
            $index,
            textValue($data['speaker'] ?? ''),
            textValue($data['text'] ?? $data['charactersResponse'] ?? ''),
            jsonText($data),
        ]);
        $phaseId = (int)$pdo->lastInsertId();
        insertMenuOptionPuppets($pdo, 'FSG_MD_MenuReplyPhasePuppets', 'reply_phase_id', $phaseId, arr($data['puppets'] ?? []));
    }
}

function insertMenuOptionsRecursive(PDO $pdo, int $workspaceId, int $contextId, int $characterId, ?int $parentOptionId, array $options, int $depth = 0): int
{
    $inserted = 0;
    $stmt = $pdo->prepare('INSERT INTO FSG_MD_MenuOptions (
        workspace_id, context_id, character_id, parent_option_id, option_uuid, sort_order, depth, title, identity_color, button_label_text_format_json, characters_response, button_text, use_button,
        close_main_menu, close_dialogue, reopen_dialogue, reopen_prompt_panel, close_prompt_panel, is_called_externally, make_external_call,
        is_return_to_parent, parent_menu_select, is_link_to_menu, link_menu_select, resource_path, use_path, control_puppets, change_puppets,
        change_puppet_state, change_puppet_mood, change_puppet_invert, raw_json
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');

    foreach (array_values($options) as $index => $option) {
        $data = is_array($option) ? $option : [];
        $optionUuid = textValue($data['id'] ?? '') ?: uuidv4();
        $stmt->execute([
            $workspaceId,
            $contextId,
            $characterId,
            $parentOptionId,
            $optionUuid,
            $index,
            $depth,
            textValue($data['title'] ?? ''),
            textValue($data['identityColor'] ?? $data['identity_color'] ?? $data['panelColor'] ?? $data['nodeColor'] ?? $data['color'] ?? ''),
            jsonText($data['buttonLabelTextFormat'] ?? $data['buttonLabelFormat'] ?? null),
            textValue($data['charactersResponse'] ?? $data['text'] ?? ''),
            textValue($data['buttonText'] ?? ''),
            boolValue($data['useButton'] ?? false),
            boolValue($data['closeMainMenu'] ?? false),
            boolValue($data['closeDialogue'] ?? false),
            boolValue($data['reopenDialogue'] ?? false),
            boolValue($data['reopenPromptPanel'] ?? false),
            boolValue($data['closePromptPanel'] ?? false),
            boolValue($data['isCalledExternally'] ?? false),
            boolValue($data['makeExternalCall'] ?? false),
            boolValue($data['isReturnToParent'] ?? false),
            textValue($data['parentMenuSelect'] ?? ''),
            boolValue($data['isLinkToMenu'] ?? false),
            textValue($data['linkMenuSelect'] ?? ''),
            textValue($data['resourcePath'] ?? ''),
            boolValue($data['usePath'] ?? false),
            boolValue($data['controlPuppets'] ?? false),
            boolValue($data['changePuppets'] ?? false),
            boolValue($data['changePuppetState'] ?? false),
            boolValue($data['changePuppetMood'] ?? false),
            boolValue($data['changePuppetInvert'] ?? false),
            jsonText($data),
        ]);
        $optionId = (int)$pdo->lastInsertId();
        $inserted++;

        insertMenuLogicRows($pdo, 'FSG_MD_MenuOptionAvailabilityConditions', $optionId, arr($data['availabilityConditions'] ?? []));
        insertMenuLogicRows($pdo, 'FSG_MD_MenuOptionOnPressResults', $optionId, arr($data['onPressResults'] ?? []));
        insertMenuNamedChangeRows($pdo, 'FSG_MD_MenuOptionTimeOfDayChanges', 'time_name', $optionId, arr($data['timeOfDayChanges'] ?? []), 'time');
        insertMenuNamedChangeRows($pdo, 'FSG_MD_MenuOptionDayOfWeekChanges', 'day_name', $optionId, arr($data['dayOfWeekChanges'] ?? []), 'day');
        insertMenuNamedChangeRows($pdo, 'FSG_MD_MenuOptionSettingChanges', 'setting_name', $optionId, arr($data['settingChanges'] ?? []), 'setting');
        insertMenuOptionPuppets($pdo, 'FSG_MD_MenuOptionPuppets', 'option_id', $optionId, arr($data['puppets'] ?? []));
        insertMenuReplyPhases($pdo, $optionId, arr($data['replyPhases'] ?? []));
        $inserted += insertMenuOptionsRecursive($pdo, $workspaceId, $contextId, $characterId, $optionId, arr($data['subMenuOptions'] ?? []), $depth + 1);
    }

    return $inserted;
}

function insertMenuDesignerData(PDO $pdo, int $workspaceId, array $data): array
{
    $menuData = arr($data['menus'] ?? []);
    $dismissedChars = arr($data['dismissedChars'] ?? []);
    $counts = [
        'contexts' => 0,
        'characters' => 0,
        'options' => 0,
        'importedConversations' => 0,
    ];

    insertMenuImportedConversations($pdo, $workspaceId, arr($data['importedConvs'] ?? []));
    $counts['importedConversations'] = count(arr($data['importedConvs'] ?? []));

    $dismissedStmt = $pdo->prepare('INSERT INTO FSG_MD_DismissedCharacters (workspace_id, context_key, character_name) VALUES (?, ?, ?)');
    foreach ($dismissedChars as $contextKey => $characters) {
        foreach (array_values(arr($characters)) as $characterName) {
            $dismissedStmt->execute([$workspaceId, textValue($contextKey), textValue($characterName)]);
        }
    }

    $contextStmt = $pdo->prepare('INSERT INTO FSG_MD_MenuContexts (workspace_id, sort_order, context_key, context_title, raw_json) VALUES (?, ?, ?, ?, ?)');
    $characterStmt = $pdo->prepare('INSERT INTO FSG_MD_MenuCharacters (context_id, sort_order, character_name, is_dismissed, raw_json) VALUES (?, ?, ?, ?, ?)');

    foreach (array_values(array_keys($menuData)) as $contextIndex => $contextKey) {
        $contextMenus = arr($menuData[$contextKey] ?? []);
        $contextStmt->execute([
            $workspaceId,
            $contextIndex,
            textValue($contextKey),
            textValue($contextKey),
            jsonText($contextMenus),
        ]);
        $contextId = (int)$pdo->lastInsertId();
        $counts['contexts']++;

        foreach (array_values(array_keys($contextMenus)) as $characterIndex => $characterName) {
            $characterOptions = arr($contextMenus[$characterName] ?? []);
            $isDismissed = in_array(textValue($characterName), array_map('textValue', arr($dismissedChars[$contextKey] ?? [])), true);
            $characterStmt->execute([
                $contextId,
                $characterIndex,
                textValue($characterName),
                $isDismissed ? 1 : 0,
                jsonText(['options' => $characterOptions]),
            ]);
            $characterId = (int)$pdo->lastInsertId();
            $counts['characters']++;
            $counts['options'] += insertMenuOptionsRecursive($pdo, $workspaceId, $contextId, $characterId, null, $characterOptions, 0);
        }
    }

    $logicStmt = $pdo->prepare('INSERT INTO FSG_MD_ActiveProjectLogic (workspace_id, sort_order, logic_group, key_variable, operator, value_text, format_text, total_references, usage_classification, raw_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $logicIndex = 0;
    foreach ([
        'logic' => arr($data['Active Project Logic'] ?? []),
        'gameplay' => arr($data['Gameplay Values'] ?? []),
    ] as $logicGroup => $items) {
        foreach (array_values($items) as $item) {
            $row = is_array($item) ? $item : [];
            $logicStmt->execute([
                $workspaceId,
                $logicIndex++,
                $logicGroup,
                textValue($row['key'] ?? $row['variable'] ?? ''),
                textValue($row['operator'] ?? $row['op'] ?? ''),
                textValue($row['value'] ?? $row['val'] ?? ''),
                textValue($row['format'] ?? ''),
                (int)($row['totalReferences'] ?? 0),
                textValue($row['usageClassification'] ?? ''),
                jsonText($row),
            ]);
        }
    }

    return $counts;
}

function createSharedDialogueWorkspaceForMenuDesigner(PDO $pdo, string $workspaceId, string $sessionId, int $userId, array $data, string $rawJson): int
{
    $stmt = $pdo->prepare('INSERT INTO FSG_DD_Workspaces (workspace_uuid, session_id, user_id, version, current_language, available_languages_json, raw_json) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([
        $workspaceId,
        $sessionId,
        $userId,
        textValue($data['version'] ?? ''),
        textValue($data['currentLanguage'] ?? 'ENG') ?: 'ENG',
        jsonText(arr($data['availableLanguages'] ?? ['ENG'])),
        $rawJson,
    ]);
    $workspacePk = (int)$pdo->lastInsertId();

    $snapshotStmt = $pdo->prepare('INSERT INTO FSG_DD_RawJsonSnapshots (workspace_id, snapshot_label, raw_json) VALUES (?, ?, ?)');
    $snapshotStmt->execute([$workspacePk, 'MenuDesigner Shared Sidebar + Full Raw Save', $rawJson]);

    insertLanguages($pdo, $workspacePk, arr($data['availableLanguages'] ?? ['ENG']));
    insertCast($pdo, $workspacePk, arr($data['cast'] ?? $data['globalCast'] ?? []));
    insertGlobalTokens($pdo, $workspacePk, arr($data['globalTokens'] ?? []));
    insertNamedGlobals($pdo, $workspacePk, 'FSG_DD_GlobalStates', arr($data['globalStates'] ?? []));
    insertNamedGlobals($pdo, $workspacePk, 'FSG_DD_GlobalMoods', arr($data['globalMoods'] ?? []));
    insertNamedGlobals($pdo, $workspacePk, 'FSG_DD_GlobalSettings', arr($data['globalSettings'] ?? []));
    insertNamedGlobals($pdo, $workspacePk, 'FSG_DD_GlobalTimesOfDay', arr($data['globalTimesOfDay'] ?? $data['globalTimes'] ?? []));
    insertNamedGlobals($pdo, $workspacePk, 'FSG_DD_GlobalDaysOfWeek', arr($data['globalDaysOfWeek'] ?? $data['globalDays'] ?? []));
    insertNamedGlobals($pdo, $workspacePk, 'FSG_DD_GlobalMenuOptions', arr($data['globalMenuOptions'] ?? []));
    insertImageSequences($pdo, $workspacePk, arr($data['globalImageSequences'] ?? []));

    return $workspacePk;
}

function saveSuite(PDO $pdo, array $data): array
{
    ensureSharedDialogueTablesForMenuDesigner($pdo);
    ensureMenuDesignerTables($pdo);

    $workspaceId = textValue($data['workspaceId'] ?? $data['id'] ?? '') ?: uuidv4();
    $sessionId = textValue($data['serverSessionId'] ?? $data['sessionId'] ?? $_GET['sessionId'] ?? '');
    if ($sessionId === '') $sessionId = generateUniqueSessionId($pdo);
    $userId = currentUserId($pdo);
    if ($userId <= 0) {
        respondJson(['ok' => false, 'error' => 'You must be logged in before pushing Menu Designer data to the server.'], 401);
    }
    $rawJson = jsonText($data);

    $pdo->beginTransaction();
    try {
        $ddWorkspacePk = createSharedDialogueWorkspaceForMenuDesigner($pdo, $workspaceId, $sessionId, $userId, $data, $rawJson);

        $stmt = $pdo->prepare('INSERT INTO FSG_MD_Workspaces (
            workspace_uuid, dd_workspace_id, session_id, user_id, app_version, current_language, available_languages_json, global_max_options, active_context, active_character, raw_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            $workspaceId,
            $ddWorkspacePk,
            $sessionId,
            $userId,
            textValue($data['version'] ?? ''),
            textValue($data['currentLanguage'] ?? 'ENG') ?: 'ENG',
            jsonText(arr($data['availableLanguages'] ?? ['ENG'])),
            (int)($data['globalMaxOptions'] ?? 5),
            textValue($data['activeConv'] ?? $data['activeContext'] ?? 'ROOT'),
            textValue($data['activeChar'] ?? $data['activeCharacter'] ?? ''),
            $rawJson,
        ]);
        $mdWorkspacePk = (int)$pdo->lastInsertId();

        $menuCounts = insertMenuDesignerData($pdo, $mdWorkspacePk, $data);
        attachWorkspaceToUserSession($pdo, $sessionId, $userId);

        $pdo->commit();
        $account = authPayload($pdo);
        return [
            'workspaceId' => $workspaceId,
            'sessionId' => $sessionId,
            'databaseId' => $mdWorkspacePk,
            'menuDesignerDatabaseId' => $mdWorkspacePk,
            'sharedDialogueWorkspaceDatabaseId' => $ddWorkspacePk,
            'menuCounts' => $menuCounts,
            'attachedToUserId' => $userId,
            'account' => $account,
            'sessions' => $account['sessions'] ?? [],
        ];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function loadLatestSuite(PDO $pdo, string $sessionId = ''): array
{
    ensureSharedDialogueTablesForMenuDesigner($pdo);
    ensureMenuDesignerTables($pdo);

    $sessionId = trim($sessionId);
    if ($sessionId !== '') {
        $stmt = $pdo->prepare('SELECT workspace_uuid, session_id, raw_json, created_at, id AS md_workspace_id, dd_workspace_id FROM FSG_MD_Workspaces WHERE session_id = ? ORDER BY id DESC LIMIT 1');
        $stmt->execute([$sessionId]);
    } else {
        $stmt = $pdo->query('SELECT workspace_uuid, session_id, raw_json, created_at, id AS md_workspace_id, dd_workspace_id FROM FSG_MD_Workspaces ORDER BY id DESC LIMIT 1');
    }

    $row = $stmt->fetch();

    if (!$row) {
        // Backward compatibility: previous MenuDesigner saves were stored only as raw_json in FSG_DD_Workspaces.
        if ($sessionId !== '') {
            $fallback = $pdo->prepare('SELECT workspace_uuid, session_id, raw_json, created_at, id AS dd_workspace_id FROM FSG_DD_Workspaces WHERE session_id = ? ORDER BY id DESC LIMIT 1');
            $fallback->execute([$sessionId]);
        } else {
            $fallback = $pdo->query('SELECT workspace_uuid, session_id, raw_json, created_at, id AS dd_workspace_id FROM FSG_DD_Workspaces ORDER BY id DESC LIMIT 1');
        }
        $fallbackRow = $fallback ? $fallback->fetch() : null;
        if ($fallbackRow) {
            $fallbackData = json_decode($fallbackRow['raw_json'], true);
            if (is_array($fallbackData) && (($fallbackData['app'] ?? '') === 'MenuDesigner' || isset($fallbackData['menus']))) {
                touchUserSessionViewed($pdo, textValue($fallbackRow['session_id'] ?? $sessionId));
                $fallbackSessionId = textValue($fallbackRow['session_id'] ?? $sessionId);
                $fallbackDdWorkspaceId = (int)($fallbackRow['dd_workspace_id'] ?? $fallbackRow['id'] ?? 0);
                if ($fallbackDdWorkspaceId <= 0) $fallbackDdWorkspaceId = (int)($fallbackRow['dd_workspace_id'] ?? 0);
                $fallbackData = mergeSharedDialogueSidebarFromTables($pdo, $fallbackSessionId, (int)($fallbackRow['dd_workspace_id'] ?? $fallbackRow['id'] ?? 0), $fallbackData);
                return [
                    'workspaceId' => $fallbackRow['workspace_uuid'],
                    'sessionId' => $fallbackSessionId,
                    'createdAt' => $fallbackRow['created_at'],
                    'data' => $fallbackData,
                    'source' => 'legacy-fsg-dd-workspaces',
                    'sharedDialogueWorkspaceDatabaseId' => (int)($fallbackRow['dd_workspace_id'] ?? $fallbackRow['id'] ?? 0),
                    'sharedSidebarHydrated' => hasSharedSidebarData($fallbackData),
                ];
            }
        }

        $sharedOnlyData = loadSharedSidebarOnly($pdo, $sessionId);
        if (hasSharedSidebarData($sharedOnlyData)) {
            touchUserSessionViewed($pdo, $sessionId);
            return [
                'hasWorkspace' => true,
                'workspaceId' => '',
                'sessionId' => $sessionId,
                'createdAt' => '',
                'data' => $sharedOnlyData,
                'source' => 'fsg-dd-shared-sidebar-only',
                'sharedSidebarHydrated' => true,
                'message' => 'Loaded shared Dialogue Designer sidebar data for this session. No Menu Designer-specific workspace exists yet.'
            ];
        }

        return [
            'hasWorkspace' => false,
            'workspaceId' => '',
            'sessionId' => $sessionId,
            'createdAt' => '',
            'data' => null,
            'message' => $sessionId !== '' ? "No saved MenuDesigner workspace exists yet for this session." : "No saved MenuDesigner workspace exists yet."
        ];
    }

    $data = json_decode($row['raw_json'], true);
    if (!is_array($data)) {
        respondJson(['ok' => false, 'error' => 'Latest MenuDesigner workspace raw_json is not valid JSON.'], 500);
    }

    $loadedSessionId = textValue($row['session_id'] ?? $sessionId);
    $preferredDdWorkspaceId = (int)($row['dd_workspace_id'] ?? 0);
    $data = mergeSharedDialogueSidebarFromTables($pdo, $loadedSessionId, $preferredDdWorkspaceId, $data);

    touchUserSessionViewed($pdo, $loadedSessionId);

    return [
        'workspaceId' => $row['workspace_uuid'],
        'sessionId' => $loadedSessionId,
        'createdAt' => $row['created_at'],
        'data' => $data,
        'source' => 'fsg-md-workspaces',
        'menuDesignerDatabaseId' => (int)($row['md_workspace_id'] ?? 0),
        'sharedDialogueWorkspaceDatabaseId' => $preferredDdWorkspaceId,
        'sharedSidebarHydrated' => hasSharedSidebarData($data),
    ];
}

function listSavedSuites(PDO $pdo): array
{
    ensureMenuDesignerTables($pdo);
    $stmt = $pdo->query('SELECT id, workspace_uuid, dd_workspace_id, session_id, user_id, app_version, current_language, global_max_options, created_at, updated_at FROM FSG_MD_Workspaces ORDER BY id DESC LIMIT 100');
    return $stmt->fetchAll();
}

try {
    $action = $_GET['action'] ?? '';
    $body = requestBody();
    if ($action === '' && isset($body['action'])) {
        $action = textValue($body['action']);
    }
    if ($action === '') {
        $action = $_SERVER['REQUEST_METHOD'] === 'GET' ? 'health' : 'saveSuite';
    }

    $pdo = dbConnection();
    ensureAccountTables($pdo);
    ensureSharedDialogueTablesForMenuDesigner($pdo);
    ensureMenuDesignerTables($pdo);

    if ($action === 'health') {
        respondJson(['ok' => true, 'api' => 'MenuDesigner', 'database' => 'connected', 'menuTables' => 'FSG_MD_*', 'sharedSidebarTables' => 'FSG_DD_*']);
    }

    if ($action === 'authStatus') {
        respondJson(['ok' => true] + authPayload($pdo));
    }

    if ($action === 'register') {
        respondJson(['ok' => true] + registerAccount($pdo, $body));
    }

    if ($action === 'login') {
        respondJson(['ok' => true] + loginAccount($pdo, $body));
    }

    if ($action === 'logout') {
        if (function_exists('fsgAuth_logout')) fsgAuth_logout($pdo);
        else session_destroy();
        respondJson(['ok' => true, 'loggedIn' => false, 'user' => null, 'sessions' => []]);
    }

    if ($action === 'updateProfile') {
        respondJson(['ok' => true] + updateProfile($pdo, $body));
    }

    if ($action === 'changePassword') {
        respondJson(['ok' => true] + changePassword($pdo, $body));
    }

    if ($action === 'generateSessionId') {
        respondJson(['ok' => true, 'sessionId' => generateUniqueSessionId($pdo)]);
    }

    if ($action === 'saveSuite') {
        $data = isset($body['data']) && is_array($body['data']) ? $body['data'] : $body;
        if (!$data) {
            respondJson(['ok' => false, 'error' => 'No workspace JSON was sent.'], 400);
        }
        $saved = saveSuite($pdo, $data);
        respondJson(['ok' => true] + $saved);
    }

    if ($action === 'loadLatestSuite') {
        respondJson(['ok' => true] + loadLatestSuite($pdo, textValue($_GET['sessionId'] ?? $body['sessionId'] ?? '')));
    }

    if ($action === 'listSuites') {
        respondJson(['ok' => true, 'suites' => listSavedSuites($pdo)]);
    }

    respondJson(['ok' => false, 'error' => 'Unknown action.'], 404);
} catch (Throwable $e) {
    respondJson(['ok' => false, 'error' => $e->getMessage()], 500);
}
