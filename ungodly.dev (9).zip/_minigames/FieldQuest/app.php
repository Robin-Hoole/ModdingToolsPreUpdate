<?php
declare(strict_types=1);

/*
 * Fields Quest Browser RPG API
 *
 * Configure these environment variables in the PHP host:
 *   FSG_DB_HOST, FSG_DB_PORT, FSG_DB_NAME, FSG_DB_USER, FSG_DB_PASS
 *
 * Alternatively provide a PDO DSN through FSG_DB_DSN. The schema is installed
 * separately from schema.sql so credentials never need to be shipped in this
 * five-file export.
 */

const FSG_BROWSERRPG_GUEST_COOKIE = 'FSG_BROWSERRPG_GUEST';
const FSG_BROWSERRPG_MAX_PROGRESS_BYTES = 8388608;

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

function brpgJson(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function brpgText(mixed $value, int $maxLength = 255): string
{
    $text = trim((string)$value);
    if (function_exists('mb_substr')) {
        return mb_substr($text, 0, $maxLength, 'UTF-8');
    }
    return substr($text, 0, $maxLength);
}

function brpgInt(mixed $value, int $fallback = 0): int
{
    return is_numeric($value) ? (int)$value : $fallback;
}

function brpgFloat(mixed $value, float $fallback = 0): float
{
    return is_numeric($value) ? (float)$value : $fallback;
}

function brpgEncode(mixed $value): string
{
    $encoded = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($encoded === false) {
        throw new RuntimeException('A JSON value could not be encoded.');
    }
    return $encoded;
}

function brpgRequestBody(): array
{
    $raw = file_get_contents('php://input');
    if (!is_string($raw) || $raw === '') {
        return [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function brpgDatabase(): PDO
{
    $dsn = trim((string)(getenv('FSG_DB_DSN') ?: ''));
    $user = (string)(getenv('FSG_DB_USER') ?: '');
    $pass = (string)(getenv('FSG_DB_PASS') ?: '');

    if ($dsn === '') {
        $host = trim((string)(getenv('FSG_DB_HOST') ?: '127.0.0.1'));
        $port = trim((string)(getenv('FSG_DB_PORT') ?: '3306'));
        $name = trim((string)(getenv('FSG_DB_NAME') ?: ''));
        if ($name === '' || $user === '') {
            throw new RuntimeException(
                'Set FSG_DB_NAME and FSG_DB_USER, or provide FSG_DB_DSN.'
            );
        }
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            $host,
            $port,
            $name
        );
    }

    return new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function brpgIsHttps(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    return strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
}

function brpgGuestToken(): string
{
    $token = strtolower(trim((string)($_COOKIE[FSG_BROWSERRPG_GUEST_COOKIE] ?? '')));
    if (!preg_match('/^[a-f0-9]{48}$/', $token)) {
        $token = bin2hex(random_bytes(24));
        setcookie(FSG_BROWSERRPG_GUEST_COOKIE, $token, [
            'expires' => time() + 31536000,
            'path' => '/',
            'secure' => brpgIsHttps(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }
    return $token;
}

/**
 * @return array{guestId:int,ownerKey:string,sessionId:string,displayName:string}
 */
function brpgIdentity(PDO $pdo): array
{
    $token = brpgGuestToken();
    $hash = hash('sha256', 'fsg-browser-rpg:' . $token);
    $displayName = 'Guest_' .
        str_pad((string)(hexdec(substr($hash, 0, 8)) % 10000), 4, '0', STR_PAD_LEFT);

    $insert = $pdo->prepare(
        'INSERT INTO FSG_BROWSERRPG_Guests (token_hash, display_name)
         VALUES (?, ?)
         ON DUPLICATE KEY UPDATE
           display_name = VALUES(display_name),
           last_seen_at = CURRENT_TIMESTAMP'
    );
    $insert->execute([$hash, $displayName]);

    $lookup = $pdo->prepare(
        'SELECT guest_id FROM FSG_BROWSERRPG_Guests WHERE token_hash = ? LIMIT 1'
    );
    $lookup->execute([$hash]);
    $guestId = (int)$lookup->fetchColumn();
    if ($guestId < 1) {
        throw new RuntimeException('The guest identity could not be created.');
    }

    return [
        'guestId' => $guestId,
        'ownerKey' => 'guest:' . $guestId,
        'sessionId' => 'BRPG-G-' . strtoupper(substr($hash, 0, 24)),
        'displayName' => $displayName,
    ];
}

function brpgTouchSession(PDO $pdo, array $identity, bool $saved = false): void
{
    $lastSavedSql = $saved ? 'CURRENT_TIMESTAMP' : 'NULL';
    $lastSavedUpdateSql = $saved ? 'CURRENT_TIMESTAMP' : 'last_saved_at';
    $statement = $pdo->prepare(
        "INSERT INTO FSG_BROWSERRPG_Sessions
          (session_id, guest_id, owner_key, actor_type, display_name,
           created_at, last_seen_at, last_saved_at, is_active)
         VALUES (?, ?, ?, 'guest', ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, {$lastSavedSql}, 1)
         ON DUPLICATE KEY UPDATE
           guest_id = VALUES(guest_id),
           owner_key = VALUES(owner_key),
           display_name = VALUES(display_name),
           last_seen_at = CURRENT_TIMESTAMP,
           last_saved_at = {$lastSavedUpdateSql},
           is_active = 1"
    );
    $statement->execute([
        $identity['sessionId'],
        $identity['guestId'],
        $identity['ownerKey'],
        $identity['displayName'],
    ]);
}

function brpgLatestProgress(PDO $pdo, array $identity): ?array
{
    $statement = $pdo->prepare(
        'SELECT payload_json, updated_at
         FROM FSG_BROWSERRPG_PlayerProgress
         WHERE owner_key = ?
         ORDER BY (session_id = ?) DESC, updated_at DESC
         LIMIT 1'
    );
    $statement->execute([$identity['ownerKey'], $identity['sessionId']]);
    $row = $statement->fetch();
    if (!$row) {
        return null;
    }
    $state = json_decode((string)$row['payload_json'], true);
    return [
        'state' => is_array($state) ? $state : null,
        'updatedAt' => (string)$row['updated_at'],
    ];
}

function brpgDeleteProjectRows(PDO $pdo, string $ownerKey, string $projectId): void
{
    foreach ([
        'FSG_BROWSERRPG_StatCategories',
        'FSG_BROWSERRPG_StatDefinitions',
        'FSG_BROWSERRPG_CurrencyDefinitions',
        'FSG_BROWSERRPG_SkillDefinitions',
        'FSG_BROWSERRPG_Locations',
        'FSG_BROWSERRPG_Creatures',
        'FSG_BROWSERRPG_Assets',
    ] as $table) {
        $statement = $pdo->prepare("DELETE FROM {$table} WHERE owner_key = ? AND project_id = ?");
        $statement->execute([$ownerKey, $projectId]);
    }
}

function brpgWriteProjectRows(
    PDO $pdo,
    string $ownerKey,
    string $projectId,
    array $project
): void {
    brpgDeleteProjectRows($pdo, $ownerKey, $projectId);

    $categoryInsert = $pdo->prepare(
        'INSERT INTO FSG_BROWSERRPG_StatCategories
          (owner_key, project_id, category_id, name, color, description, sort_order, payload_json)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $statInsert = $pdo->prepare(
        'INSERT INTO FSG_BROWSERRPG_StatDefinitions
          (owner_key, project_id, category_id, stat_id, name, base_value, min_value,
           max_value, step_value, is_percentage, description, sort_order, payload_json)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    foreach (($project['categories'] ?? []) as $categoryOrder => $category) {
        if (!is_array($category)) {
            continue;
        }
        $categoryId = brpgText($category['id'] ?? ('category-' . $categoryOrder), 128);
        $categoryInsert->execute([
            $ownerKey,
            $projectId,
            $categoryId,
            brpgText($category['name'] ?? $categoryId),
            brpgText($category['color'] ?? '', 32),
            brpgText($category['description'] ?? '', 65535),
            (int)$categoryOrder,
            brpgEncode($category),
        ]);
        foreach (($category['stats'] ?? []) as $statOrder => $stat) {
            if (!is_array($stat)) {
                continue;
            }
            $statId = brpgText($stat['id'] ?? ('stat-' . $statOrder), 128);
            $statInsert->execute([
                $ownerKey,
                $projectId,
                $categoryId,
                $statId,
                brpgText($stat['name'] ?? $statId),
                brpgFloat($stat['base'] ?? 0),
                brpgFloat($stat['min'] ?? 0),
                brpgFloat($stat['max'] ?? 100),
                brpgFloat($stat['step'] ?? 1, 1),
                !empty($stat['percentage']) ? 1 : 0,
                brpgText($stat['description'] ?? '', 65535),
                (int)$statOrder,
                brpgEncode($stat),
            ]);
        }
    }

    $currencyInsert = $pdo->prepare(
        'INSERT INTO FSG_BROWSERRPG_CurrencyDefinitions
          (owner_key, project_id, currency_id, name, symbol, start_value, max_value,
           color, image_url, sort_order, payload_json)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    foreach (($project['currencies'] ?? []) as $order => $currency) {
        if (!is_array($currency)) {
            continue;
        }
        $currencyId = brpgText($currency['id'] ?? ('currency-' . $order), 128);
        $currencyInsert->execute([
            $ownerKey,
            $projectId,
            $currencyId,
            brpgText($currency['name'] ?? $currencyId),
            brpgText($currency['symbol'] ?? '', 32),
            brpgFloat($currency['start'] ?? 0),
            brpgFloat($currency['max'] ?? 0),
            brpgText($currency['color'] ?? '', 32),
            brpgText($currency['imageUrl'] ?? '', 65535),
            (int)$order,
            brpgEncode($currency),
        ]);
    }

    $skillInsert = $pdo->prepare(
        'INSERT INTO FSG_BROWSERRPG_SkillDefinitions
          (owner_key, project_id, skill_id, name, category, start_level, start_xp,
           xp_to_next, growth_rate, color, description, image_url, sort_order, payload_json)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    foreach (($project['skills'] ?? []) as $order => $skill) {
        if (!is_array($skill)) {
            continue;
        }
        $skillId = brpgText($skill['id'] ?? ('skill-' . $order), 128);
        $skillInsert->execute([
            $ownerKey,
            $projectId,
            $skillId,
            brpgText($skill['name'] ?? $skillId),
            brpgText($skill['category'] ?? '', 128),
            brpgInt($skill['startLevel'] ?? 1, 1),
            brpgInt($skill['startXp'] ?? 0),
            brpgInt($skill['xpToNext'] ?? 100, 100),
            brpgFloat($skill['growth'] ?? 1.35, 1.35),
            brpgText($skill['color'] ?? '', 32),
            brpgText($skill['description'] ?? '', 65535),
            brpgText($skill['imageUrl'] ?? '', 65535),
            (int)$order,
            brpgEncode($skill),
        ]);
    }

    $game = is_array($project['game'] ?? null) ? $project['game'] : [];
    $locationInsert = $pdo->prepare(
        'INSERT INTO FSG_BROWSERRPG_Locations
          (owner_key, project_id, location_id, name, subtitle, description, coordinate_x,
           coordinate_y, color, required_level, location_kind, creature_ids_json,
           sort_order, payload_json)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    foreach (($game['locations'] ?? []) as $order => $location) {
        if (!is_array($location)) {
            continue;
        }
        $locationId = brpgText($location['id'] ?? ('location-' . $order), 128);
        $locationInsert->execute([
            $ownerKey,
            $projectId,
            $locationId,
            brpgText($location['name'] ?? $locationId),
            brpgText($location['subtitle'] ?? ''),
            brpgText($location['description'] ?? '', 65535),
            brpgFloat($location['x'] ?? 0),
            brpgFloat($location['y'] ?? 0),
            brpgText($location['color'] ?? '', 32),
            brpgInt($location['requiredLevel'] ?? 1, 1),
            brpgText($location['kind'] ?? 'quest', 32),
            brpgEncode(is_array($location['creatureIds'] ?? null) ? $location['creatureIds'] : []),
            (int)$order,
            brpgEncode($location),
        ]);
    }

    $creatureInsert = $pdo->prepare(
        'INSERT INTO FSG_BROWSERRPG_Creatures
          (owner_key, project_id, creature_id, name, epithet, description, image_url,
           image_credit_url, emoji, locations_json, hp, attack_value, defense_value,
           difficulty, reward_xp, reward_currency, skill_id, sort_order, payload_json)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    foreach (($game['creatures'] ?? []) as $order => $creature) {
        if (!is_array($creature)) {
            continue;
        }
        $creatureId = brpgText($creature['id'] ?? ('creature-' . $order), 128);
        $creatureInsert->execute([
            $ownerKey,
            $projectId,
            $creatureId,
            brpgText($creature['name'] ?? $creatureId),
            brpgText($creature['epithet'] ?? ''),
            brpgText($creature['description'] ?? '', 65535),
            brpgText($creature['imageUrl'] ?? '', 65535),
            brpgText($creature['imageCreditUrl'] ?? '', 65535),
            brpgText($creature['emoji'] ?? '', 32),
            brpgEncode(is_array($creature['locations'] ?? null) ? $creature['locations'] : []),
            brpgInt($creature['hp'] ?? 1, 1),
            brpgInt($creature['attack'] ?? 0),
            brpgInt($creature['defense'] ?? 0),
            brpgInt($creature['difficulty'] ?? 1, 1),
            brpgInt($creature['rewardXp'] ?? 0),
            brpgFloat($creature['rewardCurrency'] ?? 0),
            brpgText($creature['skillId'] ?? '', 128),
            (int)$order,
            brpgEncode($creature),
        ]);
    }

    $assetInsert = $pdo->prepare(
        'INSERT INTO FSG_BROWSERRPG_Assets
          (owner_key, project_id, asset_id, asset_type, name, source_url,
           payload_json, sort_order)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    foreach (($project['assets'] ?? []) as $order => $asset) {
        if (!is_array($asset)) {
            continue;
        }
        $assetId = brpgText($asset['id'] ?? ('asset-' . $order), 128);
        $assetInsert->execute([
            $ownerKey,
            $projectId,
            $assetId,
            brpgText($asset['type'] ?? $asset['kind'] ?? '', 64),
            brpgText($asset['name'] ?? $assetId),
            brpgText($asset['url'] ?? $asset['sourceUrl'] ?? '', 65535),
            brpgEncode($asset),
            (int)$order,
        ]);
    }
}

function brpgWriteProgressRows(PDO $pdo, string $sessionId, array $progress): void
{
    foreach ([
        'FSG_BROWSERRPG_PlayerStats',
        'FSG_BROWSERRPG_PlayerCurrencies',
        'FSG_BROWSERRPG_PlayerSkills',
        'FSG_BROWSERRPG_Inventory',
        'FSG_BROWSERRPG_Journal',
    ] as $table) {
        $statement = $pdo->prepare("DELETE FROM {$table} WHERE session_id = ?");
        $statement->execute([$sessionId]);
    }

    $statInsert = $pdo->prepare(
        'INSERT INTO FSG_BROWSERRPG_PlayerStats (session_id, stat_id, current_value)
         VALUES (?, ?, ?)'
    );
    foreach (($progress['stats'] ?? []) as $statId => $value) {
        $statInsert->execute([$sessionId, brpgText($statId, 128), brpgFloat($value)]);
    }

    $currencyInsert = $pdo->prepare(
        'INSERT INTO FSG_BROWSERRPG_PlayerCurrencies
          (session_id, currency_id, current_value)
         VALUES (?, ?, ?)'
    );
    foreach (($progress['currencies'] ?? []) as $currencyId => $value) {
        $currencyInsert->execute([
            $sessionId,
            brpgText($currencyId, 128),
            brpgFloat($value),
        ]);
    }

    $skillInsert = $pdo->prepare(
        'INSERT INTO FSG_BROWSERRPG_PlayerSkills
          (session_id, skill_id, skill_level, skill_xp, xp_to_next)
         VALUES (?, ?, ?, ?, ?)'
    );
    foreach (($progress['skills'] ?? []) as $skillId => $skill) {
        if (!is_array($skill)) {
            continue;
        }
        $skillInsert->execute([
            $sessionId,
            brpgText($skillId, 128),
            brpgInt($skill['level'] ?? 1, 1),
            brpgInt($skill['xp'] ?? 0),
            brpgInt($skill['xpToNext'] ?? 100, 100),
        ]);
    }

    $game = is_array($progress['game'] ?? null) ? $progress['game'] : [];
    $equippedWeaponId = brpgText($game['equippedWeaponId'] ?? '', 128);
    $equippedArmorId = brpgText($game['equippedArmorId'] ?? '', 128);
    $inventoryInsert = $pdo->prepare(
        'INSERT INTO FSG_BROWSERRPG_Inventory
          (session_id, item_id, name, item_kind, description, icon, power_value,
           quantity, item_level, item_xp, durability, is_equipped_weapon,
           is_equipped_armor, sort_order, payload_json)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    foreach (($game['inventory'] ?? []) as $order => $item) {
        if (!is_array($item)) {
            continue;
        }
        $itemId = brpgText($item['id'] ?? ('item-' . $order), 128);
        $durability = isset($item['durability']) && is_numeric($item['durability'])
            ? (int)$item['durability']
            : null;
        $inventoryInsert->execute([
            $sessionId,
            $itemId,
            brpgText($item['name'] ?? $itemId),
            brpgText($item['kind'] ?? 'loot', 32),
            brpgText($item['description'] ?? '', 65535),
            brpgText($item['icon'] ?? '', 32),
            brpgFloat($item['power'] ?? 0),
            brpgInt($item['quantity'] ?? 0),
            brpgInt($item['itemLevel'] ?? 1, 1),
            brpgInt($item['itemXp'] ?? 0),
            $durability,
            $itemId !== '' && $itemId === $equippedWeaponId ? 1 : 0,
            $itemId !== '' && $itemId === $equippedArmorId ? 1 : 0,
            (int)$order,
            brpgEncode($item),
        ]);
    }

    $journalInsert = $pdo->prepare(
        'INSERT INTO FSG_BROWSERRPG_Journal (session_id, entry_order, entry_text)
         VALUES (?, ?, ?)'
    );
    foreach (($game['journal'] ?? []) as $order => $entry) {
        $journalInsert->execute([
            $sessionId,
            (int)$order,
            brpgText($entry, 65535),
        ]);
    }
}

try {
    $pdo = brpgDatabase();
    $action = strtolower(trim((string)($_GET['action'] ?? 'session')));

    if ($action === 'health') {
        $pdo->query('SELECT 1');
        brpgJson([
            'ok' => true,
            'service' => 'FieldsQuestBrowserRPG',
            'databasePrefix' => 'FSG_BROWSERRPG_',
        ]);
    }

    $identity = brpgIdentity($pdo);

    if ($action === 'session' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        brpgTouchSession($pdo, $identity);
        $stored = brpgLatestProgress($pdo, $identity);
        brpgJson([
            'ok' => true,
            'sessionId' => $identity['sessionId'],
            'actorType' => 'guest',
            'displayName' => $identity['displayName'],
            'officialAdmin' => false,
            'lastSavedAt' => $stored['updatedAt'] ?? '',
            'progress' => $stored['state'] ?? null,
        ]);
    }

    if ($action === 'progress' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        brpgTouchSession($pdo, $identity);
        $stored = brpgLatestProgress($pdo, $identity);
        brpgJson([
            'ok' => true,
            'progress' => $stored['state'] ?? null,
            'savedAt' => $stored['updatedAt'] ?? '',
        ]);
    }

    if ($action === 'progress' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $contentLength = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
        if ($contentLength > FSG_BROWSERRPG_MAX_PROGRESS_BYTES) {
            brpgJson(['ok' => false, 'error' => 'Progress payload is too large.'], 413);
        }

        $body = brpgRequestBody();
        if ((string)($body['sessionId'] ?? '') !== $identity['sessionId']) {
            brpgJson(['ok' => false, 'error' => 'Session ownership check failed.'], 403);
        }

        $projectId = brpgText($body['projectId'] ?? '', 128);
        $projectName = brpgText($body['projectName'] ?? '', 255);
        $state = $body['state'] ?? null;
        $project = is_array($state) && is_array($state['project'] ?? null)
            ? $state['project']
            : null;
        $progress = is_array($state) && is_array($state['progress'] ?? null)
            ? $state['progress']
            : null;
        if (
            $projectId === '' ||
            $projectName === '' ||
            !is_array($state) ||
            !is_array($project) ||
            !is_array($progress)
        ) {
            brpgJson(['ok' => false, 'error' => 'Project and progress state are required.'], 422);
        }

        $stateJson = brpgEncode($state);
        if (strlen($stateJson) > FSG_BROWSERRPG_MAX_PROGRESS_BYTES) {
            brpgJson(['ok' => false, 'error' => 'Progress payload is too large.'], 413);
        }
        $projectJson = brpgEncode($project);
        $game = is_array($progress['game'] ?? null) ? $progress['game'] : [];

        $pdo->beginTransaction();
        brpgTouchSession($pdo, $identity, true);

        $projectSave = $pdo->prepare(
            'INSERT INTO FSG_BROWSERRPG_Projects
              (owner_key, project_id, name, schema_version, payload_json,
               created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
             ON DUPLICATE KEY UPDATE
               name = VALUES(name),
               schema_version = VALUES(schema_version),
               payload_json = VALUES(payload_json),
               updated_at = CURRENT_TIMESTAMP'
        );
        $projectSave->execute([
            $identity['ownerKey'],
            $projectId,
            $projectName,
            brpgText($project['schemaVersion'] ?? '', 32),
            $projectJson,
        ]);

        $progressSave = $pdo->prepare(
            'INSERT INTO FSG_BROWSERRPG_PlayerProgress
              (session_id, owner_key, project_id, player_name, player_level,
               player_xp, xp_to_next, health, max_health, quests_remaining,
               day_number, payload_json, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
             ON DUPLICATE KEY UPDATE
               owner_key = VALUES(owner_key),
               project_id = VALUES(project_id),
               player_name = VALUES(player_name),
               player_level = VALUES(player_level),
               player_xp = VALUES(player_xp),
               xp_to_next = VALUES(xp_to_next),
               health = VALUES(health),
               max_health = VALUES(max_health),
               quests_remaining = VALUES(quests_remaining),
               day_number = VALUES(day_number),
               payload_json = VALUES(payload_json),
               updated_at = CURRENT_TIMESTAMP'
        );
        $progressSave->execute([
            $identity['sessionId'],
            $identity['ownerKey'],
            $projectId,
            brpgText($progress['playerName'] ?? 'New Adventurer'),
            brpgInt($progress['level'] ?? 1, 1),
            brpgInt($progress['xp'] ?? 0),
            brpgInt($progress['xpToNext'] ?? 100, 100),
            brpgInt($game['health'] ?? 0),
            brpgInt($game['maxHealth'] ?? 0),
            brpgInt($game['questsRemaining'] ?? 0),
            brpgInt($game['day'] ?? 1, 1),
            $stateJson,
        ]);

        brpgWriteProjectRows($pdo, $identity['ownerKey'], $projectId, $project);
        brpgWriteProgressRows($pdo, $identity['sessionId'], $progress);
        $pdo->commit();

        brpgJson(['ok' => true, 'savedAt' => gmdate('c')]);
    }

    brpgJson(['ok' => false, 'error' => 'Route not found.'], 404);
} catch (Throwable $error) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('Fields Quest Browser RPG error: ' . $error->getMessage());
    brpgJson([
        'ok' => false,
        'error' => 'The Browser RPG server could not complete that request.',
    ], 500);
}
