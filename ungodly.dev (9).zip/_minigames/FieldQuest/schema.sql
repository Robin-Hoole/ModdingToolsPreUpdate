-- Fields Quest Browser RPG - MySQL 5.7+/8.0 schema
-- Every application table uses the required FSG_BROWSERRPG_ prefix.
-- Import this file once, then configure the PHP environment variables described
-- at the top of app.php.

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_Guests (
  guest_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  token_hash CHAR(64) NOT NULL,
  display_name VARCHAR(64) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (guest_id),
  UNIQUE KEY uq_brpg_guest_token (token_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_Sessions (
  session_id VARCHAR(64) NOT NULL,
  guest_id BIGINT UNSIGNED NOT NULL,
  owner_key VARCHAR(96) NOT NULL,
  actor_type VARCHAR(16) NOT NULL DEFAULT 'guest',
  display_name VARCHAR(64) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_saved_at TIMESTAMP NULL DEFAULT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (session_id),
  KEY idx_brpg_session_guest (guest_id, last_seen_at),
  KEY idx_brpg_session_owner (owner_key, last_seen_at),
  CONSTRAINT fk_brpg_session_guest
    FOREIGN KEY (guest_id) REFERENCES FSG_BROWSERRPG_Guests (guest_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_Projects (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_key VARCHAR(96) NOT NULL,
  project_id VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  schema_version VARCHAR(32) NOT NULL DEFAULT '',
  payload_json LONGTEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_project_owner_id (owner_key, project_id),
  KEY idx_brpg_project_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_PlayerProgress (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id VARCHAR(64) NOT NULL,
  owner_key VARCHAR(96) NOT NULL,
  project_id VARCHAR(128) NOT NULL,
  player_name VARCHAR(255) NOT NULL,
  player_level INT NOT NULL DEFAULT 1,
  player_xp BIGINT NOT NULL DEFAULT 0,
  xp_to_next BIGINT NOT NULL DEFAULT 100,
  health INT NOT NULL DEFAULT 0,
  max_health INT NOT NULL DEFAULT 0,
  quests_remaining INT NOT NULL DEFAULT 0,
  day_number INT NOT NULL DEFAULT 1,
  payload_json LONGTEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_progress_session (session_id),
  KEY idx_brpg_progress_owner (owner_key, updated_at),
  KEY idx_brpg_progress_project (project_id, updated_at),
  CONSTRAINT fk_brpg_progress_session
    FOREIGN KEY (session_id) REFERENCES FSG_BROWSERRPG_Sessions (session_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_StatCategories (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_key VARCHAR(96) NOT NULL,
  project_id VARCHAR(128) NOT NULL,
  category_id VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  color VARCHAR(32) NOT NULL DEFAULT '',
  description TEXT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  payload_json LONGTEXT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_category (owner_key, project_id, category_id),
  KEY idx_brpg_category_sort (owner_key, project_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_StatDefinitions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_key VARCHAR(96) NOT NULL,
  project_id VARCHAR(128) NOT NULL,
  category_id VARCHAR(128) NOT NULL,
  stat_id VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  base_value DECIMAL(20,6) NOT NULL DEFAULT 0,
  min_value DECIMAL(20,6) NOT NULL DEFAULT 0,
  max_value DECIMAL(20,6) NOT NULL DEFAULT 100,
  step_value DECIMAL(20,6) NOT NULL DEFAULT 1,
  is_percentage TINYINT(1) NOT NULL DEFAULT 0,
  description TEXT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  payload_json LONGTEXT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_stat_definition (owner_key, project_id, stat_id),
  KEY idx_brpg_stat_category (owner_key, project_id, category_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_PlayerStats (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id VARCHAR(64) NOT NULL,
  stat_id VARCHAR(128) NOT NULL,
  current_value DECIMAL(20,6) NOT NULL DEFAULT 0,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_player_stat (session_id, stat_id),
  CONSTRAINT fk_brpg_player_stat_session
    FOREIGN KEY (session_id) REFERENCES FSG_BROWSERRPG_Sessions (session_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_CurrencyDefinitions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_key VARCHAR(96) NOT NULL,
  project_id VARCHAR(128) NOT NULL,
  currency_id VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  symbol VARCHAR(32) NOT NULL DEFAULT '',
  start_value DECIMAL(20,6) NOT NULL DEFAULT 0,
  max_value DECIMAL(20,6) NOT NULL DEFAULT 0,
  color VARCHAR(32) NOT NULL DEFAULT '',
  image_url TEXT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  payload_json LONGTEXT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_currency_definition (owner_key, project_id, currency_id),
  KEY idx_brpg_currency_sort (owner_key, project_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_PlayerCurrencies (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id VARCHAR(64) NOT NULL,
  currency_id VARCHAR(128) NOT NULL,
  current_value DECIMAL(20,6) NOT NULL DEFAULT 0,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_player_currency (session_id, currency_id),
  CONSTRAINT fk_brpg_player_currency_session
    FOREIGN KEY (session_id) REFERENCES FSG_BROWSERRPG_Sessions (session_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_SkillDefinitions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_key VARCHAR(96) NOT NULL,
  project_id VARCHAR(128) NOT NULL,
  skill_id VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  category VARCHAR(128) NOT NULL DEFAULT '',
  start_level INT NOT NULL DEFAULT 1,
  start_xp BIGINT NOT NULL DEFAULT 0,
  xp_to_next BIGINT NOT NULL DEFAULT 100,
  growth_rate DECIMAL(12,6) NOT NULL DEFAULT 1.35,
  color VARCHAR(32) NOT NULL DEFAULT '',
  description TEXT NULL,
  image_url TEXT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  payload_json LONGTEXT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_skill_definition (owner_key, project_id, skill_id),
  KEY idx_brpg_skill_sort (owner_key, project_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_PlayerSkills (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id VARCHAR(64) NOT NULL,
  skill_id VARCHAR(128) NOT NULL,
  skill_level INT NOT NULL DEFAULT 1,
  skill_xp BIGINT NOT NULL DEFAULT 0,
  xp_to_next BIGINT NOT NULL DEFAULT 100,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_player_skill (session_id, skill_id),
  CONSTRAINT fk_brpg_player_skill_session
    FOREIGN KEY (session_id) REFERENCES FSG_BROWSERRPG_Sessions (session_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_Locations (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_key VARCHAR(96) NOT NULL,
  project_id VARCHAR(128) NOT NULL,
  location_id VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  subtitle VARCHAR(255) NOT NULL DEFAULT '',
  description TEXT NULL,
  coordinate_x DECIMAL(10,4) NOT NULL DEFAULT 0,
  coordinate_y DECIMAL(10,4) NOT NULL DEFAULT 0,
  color VARCHAR(32) NOT NULL DEFAULT '',
  required_level INT NOT NULL DEFAULT 1,
  location_kind VARCHAR(32) NOT NULL DEFAULT 'quest',
  creature_ids_json LONGTEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  payload_json LONGTEXT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_location (owner_key, project_id, location_id),
  KEY idx_brpg_location_sort (owner_key, project_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_Creatures (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_key VARCHAR(96) NOT NULL,
  project_id VARCHAR(128) NOT NULL,
  creature_id VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  epithet VARCHAR(255) NOT NULL DEFAULT '',
  description TEXT NULL,
  image_url TEXT NULL,
  image_credit_url TEXT NULL,
  emoji VARCHAR(32) NOT NULL DEFAULT '',
  locations_json LONGTEXT NOT NULL,
  hp INT NOT NULL DEFAULT 1,
  attack_value INT NOT NULL DEFAULT 0,
  defense_value INT NOT NULL DEFAULT 0,
  difficulty INT NOT NULL DEFAULT 1,
  reward_xp BIGINT NOT NULL DEFAULT 0,
  reward_currency DECIMAL(20,6) NOT NULL DEFAULT 0,
  skill_id VARCHAR(128) NOT NULL DEFAULT '',
  sort_order INT NOT NULL DEFAULT 0,
  payload_json LONGTEXT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_creature (owner_key, project_id, creature_id),
  KEY idx_brpg_creature_sort (owner_key, project_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_Inventory (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id VARCHAR(64) NOT NULL,
  item_id VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  item_kind VARCHAR(32) NOT NULL,
  description TEXT NULL,
  icon VARCHAR(32) NOT NULL DEFAULT '',
  power_value DECIMAL(20,6) NOT NULL DEFAULT 0,
  quantity INT NOT NULL DEFAULT 0,
  item_level INT NOT NULL DEFAULT 1,
  item_xp BIGINT NOT NULL DEFAULT 0,
  durability INT NULL,
  is_equipped_weapon TINYINT(1) NOT NULL DEFAULT 0,
  is_equipped_armor TINYINT(1) NOT NULL DEFAULT 0,
  sort_order INT NOT NULL DEFAULT 0,
  payload_json LONGTEXT NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_inventory_item (session_id, item_id),
  KEY idx_brpg_inventory_sort (session_id, sort_order),
  CONSTRAINT fk_brpg_inventory_session
    FOREIGN KEY (session_id) REFERENCES FSG_BROWSERRPG_Sessions (session_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_Journal (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id VARCHAR(64) NOT NULL,
  entry_order INT NOT NULL DEFAULT 0,
  entry_text TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_journal_order (session_id, entry_order),
  KEY idx_brpg_journal_session (session_id, entry_order),
  CONSTRAINT fk_brpg_journal_session
    FOREIGN KEY (session_id) REFERENCES FSG_BROWSERRPG_Sessions (session_id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_BROWSERRPG_Assets (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_key VARCHAR(96) NOT NULL,
  project_id VARCHAR(128) NOT NULL,
  asset_id VARCHAR(128) NOT NULL,
  asset_type VARCHAR(64) NOT NULL DEFAULT '',
  name VARCHAR(255) NOT NULL DEFAULT '',
  source_url TEXT NULL,
  payload_json LONGTEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_brpg_asset (owner_key, project_id, asset_id),
  KEY idx_brpg_asset_sort (owner_key, project_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
