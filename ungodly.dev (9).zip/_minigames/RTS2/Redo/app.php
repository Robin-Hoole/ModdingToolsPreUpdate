<?php
declare(strict_types=1);

/**
 * Field & Sigil RTS persistence endpoint.
 *
 * The supplied private credentials remain outside the public application
 * folder. This endpoint reuses _private/AuthShared.php, which reads
 * databaseCredentials.php and returns the shared PDO connection.
 */

$authCandidates = [
    __DIR__ . '/_private/AuthShared.php',
    dirname(__DIR__) . '/_private/AuthShared.php',
    dirname(__DIR__, 2) . '/_private/AuthShared.php',
];
$authPath = null;
foreach ($authCandidates as $candidate) {
    if (is_file($candidate)) {
        $authPath = $candidate;
        break;
    }
}
if ($authPath === null) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok' => false,
        'error' => 'The private database helper could not be found. Place _private beside the battle-simulator folder.',
    ]);
    exit;
}

require_once $authPath;
fsgAuth_startSharedSession();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

const FSG_RTS_APP_KEY = 'FieldAndSigilRTS';
const FSG_RTS_GUEST_COOKIE = 'FSG_RTS_GUEST';
const FSG_RTS_MAX_PAYLOAD_BYTES = 8_388_608;

function rtsJson(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function rtsCookie(string $name, string $value): void
{
    setcookie($name, $value, [
        'expires' => time() + 31536000,
        'path' => '/',
        'domain' => fsgAuth_cookieDomain(),
        'secure' => fsgAuth_isHttpsRequest(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

/**
 * @return array{ownerKey:string,userId:int,actorType:string,displayName:string}
 */
function rtsIdentity(PDO $pdo): array
{
    $userId = fsgAuth_currentUserIdFromRequest($pdo);
    if ($userId > 0) {
        $user = fsgAuth_getUserById($pdo, $userId);
        return [
            'ownerKey' => 'user:' . $userId,
            'userId' => $userId,
            'actorType' => 'user',
            'displayName' => substr((string)($user['username'] ?? ('Player ' . $userId)), 0, 80),
        ];
    }

    $token = strtolower(trim((string)($_COOKIE[FSG_RTS_GUEST_COOKIE] ?? '')));
    if (!preg_match('/^[a-f0-9]{48}$/', $token)) {
        $token = bin2hex(random_bytes(24));
        rtsCookie(FSG_RTS_GUEST_COOKIE, $token);
    }
    $hash = hash('sha256', 'fsg-rts-owner:' . $token);

    return [
        'ownerKey' => 'guest:' . $hash,
        'userId' => 0,
        'actorType' => 'guest',
        'displayName' => 'Guest Commander ' . strtoupper(substr($hash, 0, 5)),
    ];
}

function rtsEnsureTables(PDO $pdo): void
{
    $userIdType = fsgAuth_sharedFsgUserIdSqlType($pdo);

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_RTS_Projects (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        owner_key VARCHAR(96) NOT NULL,
        user_id {$userIdType} NULL,
        project_id VARCHAR(128) NOT NULL,
        name VARCHAR(190) NOT NULL,
        schema_version VARCHAR(24) NOT NULL DEFAULT '1.0.0',
        snapshot_json LONGTEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_RTS_Projects_owner_project (owner_key, project_id),
        KEY idx_FSG_RTS_Projects_owner_updated (owner_key, updated_at),
        KEY idx_FSG_RTS_Projects_user_updated (user_id, updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_RTS_UnitTypes (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        project_db_id BIGINT UNSIGNED NOT NULL,
        unit_id VARCHAR(128) NOT NULL,
        name VARCHAR(190) NOT NULL,
        emoji VARCHAR(24) NOT NULL DEFAULT '',
        role_name VARCHAR(48) NOT NULL DEFAULT '',
        focus_mode VARCHAR(24) NOT NULL DEFAULT 'melee',
        data_json LONGTEXT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_RTS_UnitTypes_project_unit (project_db_id, unit_id),
        KEY idx_FSG_RTS_UnitTypes_project_sort (project_db_id, sort_order),
        CONSTRAINT fk_FSG_RTS_UnitTypes_project FOREIGN KEY (project_db_id)
            REFERENCES FSG_RTS_Projects(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_RTS_Formations (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        project_db_id BIGINT UNSIGNED NOT NULL,
        formation_id VARCHAR(128) NOT NULL,
        name VARCHAR(190) NOT NULL,
        row_count TINYINT UNSIGNED NOT NULL,
        column_count TINYINT UNSIGNED NOT NULL,
        slot_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
        data_json LONGTEXT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_RTS_Formations_project_formation (project_db_id, formation_id),
        KEY idx_FSG_RTS_Formations_project_sort (project_db_id, sort_order),
        CONSTRAINT fk_FSG_RTS_Formations_project FOREIGN KEY (project_db_id)
            REFERENCES FSG_RTS_Projects(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_RTS_Spells (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        project_db_id BIGINT UNSIGNED NOT NULL,
        spell_id VARCHAR(128) NOT NULL,
        name VARCHAR(190) NOT NULL,
        emoji VARCHAR(24) NOT NULL DEFAULT '',
        origin_mode VARCHAR(24) NOT NULL DEFAULT 'click',
        row_count TINYINT UNSIGNED NOT NULL,
        data_json LONGTEXT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_RTS_Spells_project_spell (project_db_id, spell_id),
        KEY idx_FSG_RTS_Spells_project_sort (project_db_id, sort_order),
        CONSTRAINT fk_FSG_RTS_Spells_project FOREIGN KEY (project_db_id)
            REFERENCES FSG_RTS_Projects(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_RTS_BuildingTypes (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        project_db_id BIGINT UNSIGNED NOT NULL,
        building_type_id VARCHAR(128) NOT NULL,
        name VARCHAR(190) NOT NULL,
        emoji VARCHAR(24) NOT NULL DEFAULT '',
        food_cost INT UNSIGNED NOT NULL DEFAULT 0,
        wood_cost INT UNSIGNED NOT NULL DEFAULT 0,
        gold_cost INT UNSIGNED NOT NULL DEFAULT 0,
        data_json LONGTEXT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_RTS_BuildingTypes_project_type (project_db_id, building_type_id),
        KEY idx_FSG_RTS_BuildingTypes_project_sort (project_db_id, sort_order),
        CONSTRAINT fk_FSG_RTS_BuildingTypes_project FOREIGN KEY (project_db_id)
            REFERENCES FSG_RTS_Projects(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_RTS_BuildingComplexes (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        project_db_id BIGINT UNSIGNED NOT NULL,
        complex_id VARCHAR(128) NOT NULL,
        name VARCHAR(190) NOT NULL,
        default_priority TINYINT UNSIGNED NOT NULL DEFAULT 3,
        building_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
        data_json LONGTEXT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_RTS_BuildingComplexes_project_complex (project_db_id, complex_id),
        KEY idx_FSG_RTS_BuildingComplexes_project_sort (project_db_id, sort_order),
        CONSTRAINT fk_FSG_RTS_BuildingComplexes_project FOREIGN KEY (project_db_id)
            REFERENCES FSG_RTS_Projects(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_RTS_Sessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        session_id VARCHAR(96) NOT NULL,
        owner_key VARCHAR(96) NOT NULL,
        user_id {$userIdType} NULL,
        actor_type VARCHAR(16) NOT NULL,
        display_name VARCHAR(80) NOT NULL,
        app_key VARCHAR(48) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_saved_at TIMESTAMP NULL DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_RTS_Sessions_session (session_id),
        KEY idx_FSG_RTS_Sessions_owner_seen (owner_key, last_seen_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function rtsTouchSession(PDO $pdo, array $identity, bool $saved = false): void
{
    $sessionId = 'RTS-' . strtoupper(substr(hash('sha256', session_id() . ':' . $identity['ownerKey']), 0, 36));
    $sql = "INSERT INTO FSG_RTS_Sessions
        (session_id, owner_key, user_id, actor_type, display_name, app_key, created_at, last_seen_at, last_saved_at)
        VALUES (?, ?, NULLIF(?, 0), ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, " .
        ($saved ? 'CURRENT_TIMESTAMP' : 'NULL') . ")
        ON DUPLICATE KEY UPDATE
            owner_key = VALUES(owner_key),
            user_id = VALUES(user_id),
            actor_type = VALUES(actor_type),
            display_name = VALUES(display_name),
            app_key = VALUES(app_key),
            last_seen_at = CURRENT_TIMESTAMP" .
        ($saved ? ', last_saved_at = CURRENT_TIMESTAMP' : '');
    $pdo->prepare($sql)->execute([
        $sessionId,
        $identity['ownerKey'],
        $identity['userId'],
        $identity['actorType'],
        $identity['displayName'],
        FSG_RTS_APP_KEY,
    ]);
}

function rtsReadBody(): array
{
    $length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > FSG_RTS_MAX_PAYLOAD_BYTES) {
        rtsJson(['ok' => false, 'error' => 'The battle save is larger than 8 MB.'], 413);
    }
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') {
        rtsJson(['ok' => false, 'error' => 'A JSON request body is required.'], 400);
    }
    $body = json_decode($raw, true);
    if (!is_array($body)) {
        rtsJson(['ok' => false, 'error' => 'The request body is not valid JSON.'], 400);
    }
    return $body;
}

function rtsSafeText(mixed $value, int $max): string
{
    $text = trim((string)$value);
    return function_exists('mb_substr') ? mb_substr($text, 0, $max) : substr($text, 0, $max);
}

function rtsValidateProject(array $project): void
{
    $projectId = rtsSafeText($project['projectId'] ?? '', 128);
    if ($projectId === '' || !preg_match('/^[A-Za-z0-9_-]+$/', $projectId)) {
        rtsJson(['ok' => false, 'error' => 'The project ID is missing or invalid.'], 422);
    }
    foreach (['units', 'formations', 'spells'] as $requiredList) {
        if (!isset($project[$requiredList]) || !is_array($project[$requiredList])) {
            rtsJson(['ok' => false, 'error' => "The {$requiredList} dataset is required."], 422);
        }
    }
    if (count($project['units']) > 500 || count($project['formations']) > 250 || count($project['spells']) > 250
        || count((array)($project['buildingTypes'] ?? [])) > 500
        || count((array)($project['buildingComplexes'] ?? [])) > 250) {
        rtsJson(['ok' => false, 'error' => 'This project exceeds the supported definition limits.'], 422);
    }
}

function rtsReplaceDefinitions(PDO $pdo, int $projectDbId, array $project): void
{
    $pdo->prepare('DELETE FROM FSG_RTS_UnitTypes WHERE project_db_id = ?')->execute([$projectDbId]);
    $pdo->prepare('DELETE FROM FSG_RTS_Formations WHERE project_db_id = ?')->execute([$projectDbId]);
    $pdo->prepare('DELETE FROM FSG_RTS_Spells WHERE project_db_id = ?')->execute([$projectDbId]);
    $pdo->prepare('DELETE FROM FSG_RTS_BuildingTypes WHERE project_db_id = ?')->execute([$projectDbId]);
    $pdo->prepare('DELETE FROM FSG_RTS_BuildingComplexes WHERE project_db_id = ?')->execute([$projectDbId]);

    $unitInsert = $pdo->prepare("INSERT INTO FSG_RTS_UnitTypes
        (project_db_id, unit_id, name, emoji, role_name, focus_mode, data_json, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($project['units'] as $index => $unit) {
        if (!is_array($unit)) {
            continue;
        }
        $unitInsert->execute([
            $projectDbId,
            rtsSafeText($unit['id'] ?? ('UNIT-' . $index), 128),
            rtsSafeText($unit['name'] ?? 'Unnamed Fighter', 190),
            rtsSafeText($unit['emoji'] ?? '', 24),
            rtsSafeText($unit['role'] ?? '', 48),
            rtsSafeText($unit['focus'] ?? 'melee', 24),
            json_encode($unit, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            (int)$index,
        ]);
    }

    $formationInsert = $pdo->prepare("INSERT INTO FSG_RTS_Formations
        (project_db_id, formation_id, name, row_count, column_count, slot_count, data_json, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($project['formations'] as $index => $formation) {
        if (!is_array($formation)) {
            continue;
        }
        $formationInsert->execute([
            $projectDbId,
            rtsSafeText($formation['id'] ?? ('FORM-' . $index), 128),
            rtsSafeText($formation['name'] ?? 'Untitled Formation', 190),
            max(1, min(9, (int)($formation['rows'] ?? 1))),
            max(1, min(9, (int)($formation['cols'] ?? 1))),
            min(81, count((array)($formation['slots'] ?? []))),
            json_encode($formation, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            (int)$index,
        ]);
    }

    $spellInsert = $pdo->prepare("INSERT INTO FSG_RTS_Spells
        (project_db_id, spell_id, name, emoji, origin_mode, row_count, data_json, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($project['spells'] as $index => $spell) {
        if (!is_array($spell)) {
            continue;
        }
        $spellInsert->execute([
            $projectDbId,
            rtsSafeText($spell['id'] ?? ('SPELL-' . $index), 128),
            rtsSafeText($spell['name'] ?? 'Untitled Spell', 190),
            rtsSafeText($spell['emoji'] ?? '', 24),
            rtsSafeText($spell['origin'] ?? 'click', 24),
            max(3, min(9, (int)($spell['size'] ?? 3))),
            json_encode($spell, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            (int)$index,
        ]);
    }

    $buildingTypeInsert = $pdo->prepare("INSERT INTO FSG_RTS_BuildingTypes
        (project_db_id, building_type_id, name, emoji, food_cost, wood_cost, gold_cost, data_json, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ((array)($project['buildingTypes'] ?? []) as $index => $building) {
        if (!is_array($building)) {
            continue;
        }
        $cost = is_array($building['cost'] ?? null) ? $building['cost'] : [];
        $buildingTypeInsert->execute([
            $projectDbId,
            rtsSafeText($building['id'] ?? ('BUILDING-' . $index), 128),
            rtsSafeText($building['name'] ?? 'Unnamed Building', 190),
            rtsSafeText($building['emoji'] ?? '', 24),
            max(0, (int)($cost['food'] ?? 0)),
            max(0, (int)($cost['wood'] ?? 0)),
            max(0, (int)($cost['gold'] ?? 0)),
            json_encode($building, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            (int)$index,
        ]);
    }

    $complexInsert = $pdo->prepare("INSERT INTO FSG_RTS_BuildingComplexes
        (project_db_id, complex_id, name, default_priority, building_count, data_json, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?)");
    foreach ((array)($project['buildingComplexes'] ?? []) as $index => $complex) {
        if (!is_array($complex)) {
            continue;
        }
        $complexInsert->execute([
            $projectDbId,
            rtsSafeText($complex['id'] ?? ('COMPLEX-' . $index), 128),
            rtsSafeText($complex['name'] ?? 'Untitled Complex', 190),
            max(1, min(4, (int)($complex['defaultPriority'] ?? 3))),
            min(500, count((array)($complex['items'] ?? []))),
            json_encode($complex, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            (int)$index,
        ]);
    }
}

try {
    fsgAuth_requireCredentials();
    $pdo = fsgAuth_dbConnection();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    rtsEnsureTables($pdo);
    $identity = rtsIdentity($pdo);
    rtsTouchSession($pdo, $identity);

    $action = strtolower(trim((string)($_GET['action'] ?? 'status')));

    if ($action === 'status') {
        rtsJson([
            'ok' => true,
            'service' => FSG_RTS_APP_KEY,
            'databasePrefix' => 'FSG_RTS_',
            'actor' => [
                'type' => $identity['actorType'],
                'displayName' => $identity['displayName'],
            ],
        ]);
    }

    if ($action === 'list') {
        $stmt = $pdo->prepare("SELECT project_id, name, schema_version, updated_at
            FROM FSG_RTS_Projects WHERE owner_key = ?
            ORDER BY updated_at DESC LIMIT 100");
        $stmt->execute([$identity['ownerKey']]);
        $projects = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $projects[] = [
                'projectId' => (string)$row['project_id'],
                'name' => (string)$row['name'],
                'schemaVersion' => (string)$row['schema_version'],
                'updatedAt' => (string)$row['updated_at'],
            ];
        }
        rtsJson(['ok' => true, 'projects' => $projects]);
    }

    if ($action === 'load') {
        $projectId = rtsSafeText($_GET['projectId'] ?? '', 128);
        $stmt = $pdo->prepare("SELECT snapshot_json FROM FSG_RTS_Projects
            WHERE owner_key = ? AND project_id = ? LIMIT 1");
        $stmt->execute([$identity['ownerKey'], $projectId]);
        $snapshot = $stmt->fetchColumn();
        if (!is_string($snapshot)) {
            rtsJson(['ok' => false, 'error' => 'That saved realm could not be found.'], 404);
        }
        $project = json_decode($snapshot, true);
        if (!is_array($project)) {
            rtsJson(['ok' => false, 'error' => 'That saved realm is damaged.'], 500);
        }
        rtsJson(['ok' => true, 'project' => $project]);
    }

    if ($action === 'save') {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            rtsJson(['ok' => false, 'error' => 'Save requests must use POST.'], 405);
        }
        $body = rtsReadBody();
        $project = $body['project'] ?? null;
        if (!is_array($project)) {
            rtsJson(['ok' => false, 'error' => 'A project object is required.'], 422);
        }
        rtsValidateProject($project);
        $projectId = rtsSafeText($project['projectId'], 128);
        $projectName = rtsSafeText($project['projectName'] ?? 'Untitled Realm', 190);
        $schemaVersion = rtsSafeText($project['schemaVersion'] ?? '1.0.0', 24);
        $snapshot = json_encode($project, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($snapshot === false || strlen($snapshot) > FSG_RTS_MAX_PAYLOAD_BYTES) {
            rtsJson(['ok' => false, 'error' => 'The project could not be encoded or is too large.'], 422);
        }

        $pdo->beginTransaction();
        try {
            $upsert = $pdo->prepare("INSERT INTO FSG_RTS_Projects
                (owner_key, user_id, project_id, name, schema_version, snapshot_json)
                VALUES (?, NULLIF(?, 0), ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    user_id = VALUES(user_id),
                    name = VALUES(name),
                    schema_version = VALUES(schema_version),
                    snapshot_json = VALUES(snapshot_json),
                    updated_at = CURRENT_TIMESTAMP");
            $upsert->execute([
                $identity['ownerKey'],
                $identity['userId'],
                $projectId,
                $projectName,
                $schemaVersion,
                $snapshot,
            ]);
            $lookup = $pdo->prepare("SELECT id FROM FSG_RTS_Projects
                WHERE owner_key = ? AND project_id = ? LIMIT 1");
            $lookup->execute([$identity['ownerKey'], $projectId]);
            $projectDbId = (int)$lookup->fetchColumn();
            rtsReplaceDefinitions($pdo, $projectDbId, $project);
            rtsTouchSession($pdo, $identity, true);
            $pdo->commit();
        } catch (Throwable $error) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $error;
        }

        rtsJson([
            'ok' => true,
            'projectId' => $projectId,
            'savedAt' => gmdate('c'),
            'counts' => [
                'unitTypes' => count($project['units']),
                'formations' => count($project['formations']),
                'spells' => count($project['spells']),
                'buildingTypes' => count((array)($project['buildingTypes'] ?? [])),
                'buildingComplexes' => count((array)($project['buildingComplexes'] ?? [])),
            ],
        ]);
    }

    if ($action === 'delete') {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            rtsJson(['ok' => false, 'error' => 'Delete requests must use POST.'], 405);
        }
        $body = rtsReadBody();
        $projectId = rtsSafeText($body['projectId'] ?? '', 128);
        $stmt = $pdo->prepare('DELETE FROM FSG_RTS_Projects WHERE owner_key = ? AND project_id = ?');
        $stmt->execute([$identity['ownerKey'], $projectId]);
        rtsJson(['ok' => true, 'deleted' => $stmt->rowCount() > 0]);
    }

    rtsJson(['ok' => false, 'error' => 'Unknown API action.'], 404);
} catch (Throwable $error) {
    error_log('FSG_RTS error: ' . $error->getMessage());
    rtsJson([
        'ok' => false,
        'error' => 'The battle service could not complete that request.',
    ], 500);
}
