(function () {
  "use strict";

  var $ = function (selector, root) { return (root || document).querySelector(selector); };
  var $$ = function (selector, root) { return Array.from((root || document).querySelectorAll(selector)); };
  var clamp = function (value, min, max) { return Math.max(min, Math.min(max, value)); };
  var clone = function (value) { return JSON.parse(JSON.stringify(value)); };
  var uid = function (prefix) {
    var time = Date.now().toString(36).toUpperCase();
    var random = Math.random().toString(36).slice(2, 7).toUpperCase();
    return prefix + "-" + time + "-" + random;
  };
  var escapeHtml = function (value) {
    return String(value).replace(/[&<>"']/g, function (char) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[char];
    });
  };
  var distance = function (a, b) { return Math.hypot(a.x - b.x, a.y - b.y); };
  var now = function () { return performance.now() / 1000; };

  var UNIT_EMOJIS = ["⚔️", "🏹", "🛡️", "🐎", "🔫", "🗡️", "🪓", "🎯", "🐘", "✨", "🗿", "🏇", "🛞", "🔥", "❄️", "🪨", "☠️", "🟤", "🧙", "👤", "🐺", "🦅", "🤖", "👹"];
  var PROJECTILE_EMOJIS = ["•", "➶", "➳", "✦", "🔥", "❄️", "🪨", "☄️", "🟢", "🟤", "⚡", "💫"];
  var SPELL_EMOJIS = ["🔥", "❄️", "⚡", "☠️", "🟤", "🪨", "✨", "💥", "🌪️", "🌿", "🌊", "🌙", "☀️", "🔮"];

  var unitSeeds = [
    ["Footman", "⚔️", "Core frontline melee infantry.", 115, 16, 8, 2.1, 28, 1.05, "melee", "chase", "Infantry", null],
    ["Archer", "🏹", "Mobile ranged infantry firing swift arrows.", 72, 13, 3, 2.45, 215, 1.25, "ranged", "keep-away", "Ranged", ["➶", "#d7c08a", 15]],
    ["Shieldbearer", "🛡️", "Heavy defensive infantry built to absorb attacks.", 178, 10, 16, 1.55, 26, 1.15, "melee", "ground", "Heavy", null],
    ["Knight", "🐎", "Armored cavalry with crushing charge damage.", 188, 25, 10, 3.8, 30, .9, "melee", "chase", "Cavalry", null],
    ["Musketeer", "🔫", "Long-range gunpowder unit with a punishing shot.", 78, 31, 2, 1.85, 285, 1.85, "ranged", "ground", "Ranged", ["•", "#f7d37a", 24]],
    ["Assassin", "🗡️", "Extremely fast skirmisher with high burst damage.", 66, 33, 3, 3.65, 26, .72, "melee", "chase", "Infantry", null],
    ["Berserker", "🪓", "Aggressive frontline attacker that thrives in chaos.", 128, 28, 4, 2.65, 28, .72, "melee", "chase", "Infantry", null],
    ["Crossbowman", "🎯", "Heavy ranged infantry firing armor-piercing bolts.", 92, 25, 5, 1.7, 245, 1.65, "ranged", "ground", "Ranged", ["➳", "#b7d2d0", 18]],
    ["War Elephant", "🐘", "Massive line-breaker with exceptional health.", 430, 39, 12, 1.35, 42, 1.55, "melee", "chase", "Heavy", null],
    ["Priest", "✨", "Support unit that restores nearby friendly fighters.", 76, 9, 4, 2.15, 175, 1.35, "support", "keep-away", "Support", ["✦", "#f5e9a9", 11]],
    ["Stone Golem", "🗿", "Ancient construct with extraordinary durability.", 520, 32, 19, 1.0, 34, 1.7, "melee", "ground", "Heavy", null],
    ["Dragoon", "🏇", "Versatile mounted fighter with a short-range firearm.", 168, 23, 8, 3.35, 145, 1.15, "ranged", "chase", "Cavalry", ["•", "#f1cb80", 20]],
    ["Ballista", "🛞", "Slow siege engine firing devastating heavy bolts.", 265, 50, 7, .72, 370, 2.7, "ranged", "ground", "Siege", ["➳", "#cbb48a", 13]],
    ["Pyromancer", "🔥", "Immortal elemental mage creating persistent fire.", 155, 22, 6, 2.2, 235, 1.5, "ranged", "chase", "Mage", ["🔥", "#ff6b32", 12]],
    ["Cryomancer", "❄️", "Immortal elemental mage slowing enemies with frost.", 160, 18, 7, 2.15, 225, 1.45, "ranged", "chase", "Mage", ["❄️", "#8be4ff", 12]],
    ["Geomancer", "🪨", "Immortal mage shaping walls from battlefield stone.", 180, 16, 10, 1.9, 210, 1.8, "ranged", "ground", "Mage", ["🪨", "#c39c68", 10]],
    ["Venomancer", "☠️", "Immortal caster spreading toxic damage zones.", 148, 20, 5, 2.3, 230, 1.4, "ranged", "keep-away", "Mage", ["🟢", "#93c952", 11]],
    ["Mudmancer", "🟤", "Immortal support mage raising movement-slowing pits.", 172, 14, 9, 1.95, 205, 1.6, "support", "ground", "Mage", ["🟤", "#8b6547", 9]]
  ];

  function createUnits() {
    return unitSeeds.map(function (seed, index) {
      return {
        id: "UNIT-" + seed[0].replace(/\s/g, "-").toUpperCase() + "-" + String(index + 1).padStart(3, "0"),
        name: seed[0],
        emoji: seed[1],
        description: seed[2],
        health: seed[3],
        attack: seed[4],
        defense: seed[5],
        speed: seed[6],
        range: seed[7],
        rate: seed[8],
        focus: seed[9],
        stance: seed[10],
        role: seed[11],
        projectile: seed[12] ? { enabled: true, emoji: seed[12][0], color: seed[12][1], speed: seed[12][2] } : { enabled: false, emoji: "•", color: "#d7c08a", speed: 12 },
        tiers: [
          { id: "TIER-LEVY", name: "Levy", health: .86, attack: .85, speed: .95 },
          { id: "TIER-VETERAN", name: "Veteran", health: 1.15, attack: 1.18, speed: 1.04 },
          { id: "TIER-ELITE", name: "Elite", health: 1.38, attack: 1.42, speed: 1.1 }
        ],
        activeTierId: "TIER-VETERAN"
      };
    });
  }

  function slot(row, col, unitId) { return { row: row, col: col, unitId: unitId }; }
  function createFormations(units) {
    var id = function (name) { return units.find(function (u) { return u.name === name; }).id; };
    return [
      {
        id: "FORM-VANGUARD-WALL", name: "Vanguard Wall", rows: 5, cols: 7,
        slots: [
          slot(0,0,id("Shieldbearer")),slot(0,1,id("Shieldbearer")),slot(0,2,id("Shieldbearer")),slot(0,3,id("Shieldbearer")),slot(0,4,id("Shieldbearer")),slot(0,5,id("Shieldbearer")),slot(0,6,id("Shieldbearer")),
          slot(1,0,id("Footman")),slot(1,1,id("Footman")),slot(1,2,id("Footman")),slot(1,3,id("Footman")),slot(1,4,id("Footman")),slot(1,5,id("Footman")),slot(1,6,id("Footman")),
          slot(2,1,id("Archer")),slot(2,2,id("Archer")),slot(2,3,id("Priest")),slot(2,4,id("Archer")),slot(2,5,id("Archer"))
        ]
      },
      {
        id: "FORM-IRON-ARROW", name: "Iron Arrowhead", rows: 7, cols: 7,
        slots: [
          slot(0,3,id("Knight")),slot(1,2,id("Knight")),slot(1,4,id("Knight")),slot(2,1,id("Footman")),slot(2,3,id("Berserker")),slot(2,5,id("Footman")),
          slot(3,0,id("Footman")),slot(3,2,id("Berserker")),slot(3,4,id("Berserker")),slot(3,6,id("Footman")),slot(4,2,id("Archer")),slot(4,3,id("Priest")),slot(4,4,id("Archer"))
        ]
      },
      {
        id: "FORM-TWIN-FLANKS", name: "Twin Flanks", rows: 6, cols: 9,
        slots: [
          slot(0,0,id("Knight")),slot(0,1,id("Dragoon")),slot(0,7,id("Dragoon")),slot(0,8,id("Knight")),
          slot(1,0,id("Knight")),slot(1,1,id("Assassin")),slot(1,7,id("Assassin")),slot(1,8,id("Knight")),
          slot(2,2,id("Footman")),slot(2,3,id("Archer")),slot(2,4,id("Priest")),slot(2,5,id("Archer")),slot(2,6,id("Footman")),
          slot(3,3,id("Crossbowman")),slot(3,4,id("Ballista")),slot(3,5,id("Crossbowman"))
        ]
      },
      {
        id: "FORM-CIRCLE-GUARD", name: "Circle Guard", rows: 7, cols: 7,
        slots: [
          slot(0,2,id("Shieldbearer")),slot(0,3,id("Shieldbearer")),slot(0,4,id("Shieldbearer")),slot(1,1,id("Footman")),slot(1,5,id("Footman")),
          slot(2,0,id("Shieldbearer")),slot(2,6,id("Shieldbearer")),slot(3,0,id("Footman")),slot(3,3,id("Geomancer")),slot(3,6,id("Footman")),
          slot(4,0,id("Shieldbearer")),slot(4,6,id("Shieldbearer")),slot(5,1,id("Footman")),slot(5,5,id("Footman")),
          slot(6,2,id("Shieldbearer")),slot(6,3,id("Priest")),slot(6,4,id("Shieldbearer"))
        ]
      },
      {
        id: "FORM-EMBER-SCREEN", name: "Ember Screen", rows: 6, cols: 8,
        slots: [
          slot(0,0,id("Footman")),slot(0,1,id("Footman")),slot(0,2,id("Shieldbearer")),slot(0,3,id("Shieldbearer")),slot(0,4,id("Shieldbearer")),slot(0,5,id("Shieldbearer")),slot(0,6,id("Footman")),slot(0,7,id("Footman")),
          slot(2,0,id("Archer")),slot(2,1,id("Archer")),slot(2,2,id("Crossbowman")),slot(2,3,id("Pyromancer")),slot(2,4,id("Cryomancer")),slot(2,5,id("Crossbowman")),slot(2,6,id("Archer")),slot(2,7,id("Archer")),
          slot(4,2,id("Ballista")),slot(4,3,id("Venomancer")),slot(4,4,id("Mudmancer")),slot(4,5,id("Ballista"))
        ]
      }
    ];
  }

  function radialSpell(size, inner, outer) {
    var cells = [];
    var center = (size - 1) / 2;
    for (var row = 0; row < size; row++) {
      for (var col = 0; col < size; col++) {
        var d = Math.hypot(row - center, col - center);
        if (d >= inner && d <= outer) cells.push(row * size + col);
      }
    }
    return cells;
  }

  function createSpells() {
    return [
      { id: "SPELL-EMBER-CROSS", name: "Ember Cross", emoji: "🔥", origin: "click", color: "#ff6034", duration: 2.8, expansion: 1.2, damage: 28, size: 7, cells: [3,10,17,21,22,23,24,25,26,27,31,38,45] },
      { id: "SPELL-FROST-RING", name: "Frost Ring", emoji: "❄️", origin: "caster", color: "#86ddff", duration: 3.4, expansion: .9, damage: 18, size: 7, cells: radialSpell(7, 2.5, 3.2) },
      { id: "SPELL-VENOM-SEAL", name: "Venom Seal", emoji: "☠️", origin: "click", color: "#91c94f", duration: 4.2, expansion: 1.5, damage: 22, size: 5, cells: [0,2,4,6,7,8,10,12,14,16,17,18,20,22,24] }
    ];
  }

  var BUILDING_DEFAULTS = [
    { id: "town-center", name: "Town Center", emoji: "🏰", cost: { food: 0, wood: 300, gold: 100 }, use: "Creates workers and stores resources", hp: 1500, width: 90, height: 74 },
    { id: "house", name: "House", emoji: "🏠", cost: { food: 0, wood: 80, gold: 0 }, use: "+10 population capacity", hp: 420, width: 56, height: 46 },
    { id: "mill", name: "Mill", emoji: "🌾", cost: { food: 0, wood: 110, gold: 0 }, use: "+3 food each economy tick", hp: 500, width: 62, height: 52 },
    { id: "lumber", name: "Lumber Camp", emoji: "🪵", cost: { food: 0, wood: 90, gold: 0 }, use: "+3 wood each economy tick", hp: 480, width: 64, height: 48 },
    { id: "mine", name: "Mining Camp", emoji: "⛏️", cost: { food: 0, wood: 100, gold: 0 }, use: "+2 gold each economy tick", hp: 480, width: 58, height: 48 },
    { id: "barracks", name: "Barracks", emoji: "🛖", cost: { food: 0, wood: 180, gold: 40 }, use: "Reinforces infantry", hp: 720, width: 78, height: 58 },
    { id: "range", name: "Archery Range", emoji: "🎯", cost: { food: 0, wood: 190, gold: 55 }, use: "Reinforces ranged units", hp: 680, width: 78, height: 54 },
    { id: "stable", name: "Stable", emoji: "🐴", cost: { food: 0, wood: 220, gold: 90 }, use: "Reinforces cavalry", hp: 760, width: 86, height: 58 },
    { id: "blacksmith", name: "Blacksmith", emoji: "⚒️", cost: { food: 0, wood: 160, gold: 120 }, use: "Unlocks weapon and armor research", hp: 660, width: 62, height: 54 },
    { id: "mage-tower", name: "Mage Tower", emoji: "🗼", cost: { food: 0, wood: 240, gold: 180 }, use: "Improves mages and rune spells", hp: 620, width: 52, height: 82 },
    { id: "workshop", name: "Siege Workshop", emoji: "⚙️", cost: { food: 0, wood: 280, gold: 150 }, use: "Produces siege improvements", hp: 800, width: 92, height: 64 },
    { id: "keep", name: "Keep", emoji: "🏯", cost: { food: 0, wood: 400, gold: 300 }, use: "Powerful defensive stronghold", hp: 1800, width: 100, height: 88 }
  ];

  function createBuildingComplexes() {
    return [
      {
        id: "COMPLEX-VILLAGE-CORE", name: "Village Core", defaultPriority: 2,
        items: [
          { id: uid("PLAN"), buildingTypeId: "town-center", x: 330, y: 210, rotation: 0, priority: 1 },
          { id: uid("PLAN"), buildingTypeId: "house", x: 180, y: 115, rotation: -15, priority: 2 },
          { id: uid("PLAN"), buildingTypeId: "house", x: 475, y: 120, rotation: 15, priority: 2 },
          { id: uid("PLAN"), buildingTypeId: "mill", x: 180, y: 310, rotation: 10, priority: 3 },
          { id: uid("PLAN"), buildingTypeId: "lumber", x: 475, y: 310, rotation: -10, priority: 3 }
        ]
      },
      {
        id: "COMPLEX-WAR-CAMPUS", name: "War Campus", defaultPriority: 2,
        items: [
          { id: uid("PLAN"), buildingTypeId: "barracks", x: 210, y: 145, rotation: 0, priority: 1 },
          { id: uid("PLAN"), buildingTypeId: "range", x: 430, y: 145, rotation: 0, priority: 2 },
          { id: uid("PLAN"), buildingTypeId: "stable", x: 210, y: 300, rotation: 0, priority: 2 },
          { id: uid("PLAN"), buildingTypeId: "workshop", x: 430, y: 300, rotation: 0, priority: 3 },
          { id: uid("PLAN"), buildingTypeId: "blacksmith", x: 320, y: 225, rotation: 45, priority: 1 }
        ]
      }
    ];
  }

  var RESEARCH = [
    { id: "forged-blades", name: "Forged Blades", note: "+12% attack to all fighters", cost: { food: 100, gold: 130 }, modifier: "attack", value: .12, done: false },
    { id: "plate-weave", name: "Plate Weave", note: "+2 defense to all fighters", cost: { wood: 120, gold: 110 }, modifier: "defense", value: 2, done: false },
    { id: "marching-drill", name: "Marching Drill", note: "+10% formation movement", cost: { food: 160, wood: 80 }, modifier: "speed", value: .10, done: false },
    { id: "wheelbarrow", name: "Wheelbarrow", note: "+25% worker gathering", cost: { food: 110, wood: 90 }, modifier: "economy", value: .25, done: false },
    { id: "runic-memory", name: "Runic Memory", note: "+20% mage damage", cost: { gold: 210 }, modifier: "magic", value: .20, done: false },
    { id: "masonry", name: "Masonry", note: "+30% building durability", cost: { wood: 180, gold: 60 }, modifier: "building", value: .30, done: false }
  ];

  var POWERS = [
    { id: "lightning", emoji: "⚡", name: "Sky Judgment", cost: 40, cooldown: 8 },
    { id: "heal", emoji: "✨", name: "Divine Mercy", cost: 45, cooldown: 10 },
    { id: "meteor", emoji: "☄️", name: "Meteor", cost: 70, cooldown: 15 },
    { id: "freeze", emoji: "❄️", name: "Winter Grasp", cost: 55, cooldown: 12 },
    { id: "forest", emoji: "🌳", name: "Wild Growth", cost: 35, cooldown: 9 },
    { id: "quake", emoji: "💥", name: "Earthquake", cost: 65, cooldown: 14 },
    { id: "plague", emoji: "☠️", name: "Plague", cost: 60, cooldown: 13 },
    { id: "wall", emoji: "🪨", name: "Divine Wall", cost: 40, cooldown: 8 },
    { id: "rune", emoji: "🔮", name: "Custom Rune", cost: 30, cooldown: 6 }
  ];

  function createProject() {
    var units = createUnits();
    return {
      schemaVersion: "1.0.0",
      projectId: uid("REALM"),
      projectName: "The Verdant Divide",
      units: units,
      formations: createFormations(units),
      spells: createSpells(),
      buildingTypes: clone(BUILDING_DEFAULTS),
      buildingComplexes: createBuildingComplexes(),
      resources: { food: 620, wood: 540, gold: 310, favor: 120 },
      research: clone(RESEARCH),
      economy: { workers: 18, foodWorkers: 7, woodWorkers: 7, goldWorkers: 4, populationCap: 90, era: 2 }
    };
  }

  var state = createProject();
  var runtime = {
    world: { width: 2400, height: 1800 },
    camera: { x: 1200, y: 900, zoom: .72 },
    canvasWidth: 1200,
    canvasHeight: 760,
    soldiers: [],
    companies: [],
    buildings: [],
    constructionQueue: [],
    nodes: [],
    workers: [],
    projectiles: [],
    effects: [],
    walls: [],
    paused: false,
    speed: 1,
    elapsed: 522,
    selectedCompanyId: null,
    buildMode: null,
    activePower: null,
    powerReady: {},
    dragging: false,
    dragStart: null,
    lastPointer: null,
    economyAccumulator: 0,
    lastFrame: performance.now(),
    activeUnitId: state.units[0].id,
    activeTierId: state.units[0].activeTierId,
    activeFormationId: state.formations[0].id,
    activeSpellId: state.spells[0].id,
    activeComplexId: state.buildingComplexes[0].id,
    activeBuildingTypeId: state.buildingTypes[0].id,
    selectedPlannedBuildingId: null,
    complexPlacement: null,
    draggingComplex: null,
    selectedComplexGroupId: null,
    pickerCell: -1
  };

  var canvas = $("#battlefield");
  var ctx = canvas.getContext("2d");
  var minimap = $("#minimap");
  var mapCtx = minimap.getContext("2d");

  function getUnit(id) { return state.units.find(function (unit) { return unit.id === id; }); }
  function getFormation(id) { return state.formations.find(function (formation) { return formation.id === id; }); }
  function getSpell(id) { return state.spells.find(function (spell) { return spell.id === id; }); }
  function getBuildingType(id) { return state.buildingTypes.find(function (building) { return building.id === id; }); }
  function getBuildingComplex(id) { return state.buildingComplexes.find(function (complex) { return complex.id === id; }); }
  function tiered(unit) {
    var tier = unit.tiers.find(function (item) { return item.id === unit.activeTierId; }) || { health: 1, attack: 1, speed: 1 };
    var atkResearch = state.research.filter(function (r) { return r.done && r.modifier === "attack"; }).reduce(function (sum, r) { return sum + r.value; }, 0);
    var speedResearch = state.research.filter(function (r) { return r.done && r.modifier === "speed"; }).reduce(function (sum, r) { return sum + r.value; }, 0);
    var defResearch = state.research.filter(function (r) { return r.done && r.modifier === "defense"; }).reduce(function (sum, r) { return sum + r.value; }, 0);
    var magicResearch = unit.role === "Mage" ? state.research.filter(function (r) { return r.done && r.modifier === "magic"; }).reduce(function (sum, r) { return sum + r.value; }, 0) : 0;
    return {
      health: unit.health * tier.health,
      attack: unit.attack * tier.attack * (1 + atkResearch + magicResearch),
      defense: unit.defense + defResearch,
      speed: unit.speed * tier.speed * (1 + speedResearch)
    };
  }

  function seededRandom(seed) {
    var value = Math.sin(seed * 999.91) * 43758.5453;
    return value - Math.floor(value);
  }

  function initializeWorld() {
    runtime.soldiers = [];
    runtime.companies = [];
    runtime.projectiles = [];
    runtime.effects = [];
    runtime.walls = [];
    runtime.nodes = [];
    runtime.constructionQueue = [];
    runtime.selectedComplexGroupId = null;
    runtime.buildings = [
      { id: uid("BLD"), type: "town-center", team: "black", x: 1200, y: 1605, rotation: 0, hp: 1500, maxHp: 1500 },
      { id: uid("BLD"), type: "house", team: "black", x: 1010, y: 1650, rotation: 0, hp: 420, maxHp: 420 },
      { id: uid("BLD"), type: "barracks", team: "black", x: 1390, y: 1650, rotation: 0, hp: 720, maxHp: 720 },
      { id: uid("BLD"), type: "town-center", team: "white", x: 1200, y: 195, rotation: 0, hp: 1500, maxHp: 1500 },
      { id: uid("BLD"), type: "house", team: "white", x: 1010, y: 150, rotation: 0, hp: 420, maxHp: 420 },
      { id: uid("BLD"), type: "barracks", team: "white", x: 1390, y: 150, rotation: 0, hp: 720, maxHp: 720 }
    ];
    for (var i = 0; i < 78; i++) {
      var kind = i % 5 === 0 ? "gold" : (i % 3 === 0 ? "food" : "wood");
      var cluster = i % 3;
      var angle = i * 2.399;
      var radius = 55 + seededRandom(i + 12) * 240;
      var centerX = cluster === 0 ? 600 : (cluster === 1 ? 1200 : 1810);
      var centerY = 890 + (cluster - 1) * 55;
      runtime.nodes.push({
        id: uid("NODE"), kind: kind,
        x: centerX + Math.cos(angle) * radius,
        y: centerY + Math.sin(angle) * radius * .62,
        amount: kind === "gold" ? 900 : 520,
        size: kind === "wood" ? 17 + seededRandom(i) * 8 : 12
      });
    }
    runtime.workers = [];
    for (var w = 0; w < state.economy.workers; w++) {
      runtime.workers.push({ x: 1050 + (w % 6) * 55, y: 1490 + Math.floor(w / 6) * 36, phase: w * .7, job: w < state.economy.foodWorkers ? "food" : (w < state.economy.foodWorkers + state.economy.woodWorkers ? "wood" : "gold") });
    }
    var blackOrigins = [{x:520,y:1380},{x:860,y:1490},{x:1200,y:1380},{x:1540,y:1490},{x:1880,y:1380}];
    var whiteOrigins = [{x:520,y:420},{x:860,y:310},{x:1200,y:420},{x:1540,y:310},{x:1880,y:420}];
    state.formations.slice(0, 5).forEach(function (formation, index) {
      spawnCompany("black", formation, blackOrigins[index], index);
      spawnCompany("white", formation, whiteOrigins[index], index);
    });
    runtime.selectedCompanyId = runtime.companies.find(function (c) { return c.team === "black"; }).id;
    updateSelectionUI();
    addEvent("The two hosts enter the Verdant Divide.");
  }

  function spawnCompany(team, formation, origin, index) {
    var company = {
      id: uid(team === "black" ? "BLACK" : "WHITE"),
      team: team,
      name: (team === "black" ? ["Iron Vanguard","Ashen Lancers","Night Blades","Ember Circle","Stone Watch"] : ["Ivory Guard","Dawn Riders","Pale Talons","Glacier Choir","Marble Host"])[index % 5],
      formationId: formation.id,
      formationIndex: state.formations.indexOf(formation),
      x: origin.x,
      y: origin.y,
      targetX: origin.x,
      targetY: team === "black" ? 540 : 1260,
      stance: index === 4 ? "ground" : "chase",
      focus: null,
      halted: false,
      patrol: false,
      flagOffset: team === "black" ? 42 : -42
    };
    runtime.companies.push(company);
    formation.slots.forEach(function (formationSlot, slotIndex) {
      var unit = getUnit(formationSlot.unitId) || state.units[0];
      var stats = tiered(unit);
      var spacing = 27;
      var offsetX = (formationSlot.col - (formation.cols - 1) / 2) * spacing;
      var offsetY = (formationSlot.row - (formation.rows - 1) / 2) * spacing * (team === "black" ? 1 : -1);
      runtime.soldiers.push({
        id: uid("FTR"), companyId: company.id, team: team, unitId: unit.id,
        x: origin.x + offsetX, y: origin.y + offsetY,
        offsetX: offsetX, offsetY: offsetY,
        hp: stats.health, maxHp: stats.health, cooldown: seededRandom(slotIndex + index * 20) * unit.rate,
        frozenUntil: 0, poisonUntil: 0, burnUntil: 0, flash: 0
      });
    });
    return company;
  }

  function canvasSize() {
    var rect = canvas.getBoundingClientRect();
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    runtime.canvasWidth = rect.width;
    runtime.canvasHeight = rect.height;
    canvas.width = Math.max(1, Math.floor(rect.width * dpr));
    canvas.height = Math.max(1, Math.floor(rect.height * dpr));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function toScreen(x, y) {
    return {
      x: (x - runtime.camera.x) * runtime.camera.zoom + runtime.canvasWidth / 2,
      y: (y - runtime.camera.y) * runtime.camera.zoom + runtime.canvasHeight / 2
    };
  }
  function toWorld(x, y) {
    return {
      x: (x - runtime.canvasWidth / 2) / runtime.camera.zoom + runtime.camera.x,
      y: (y - runtime.canvasHeight / 2) / runtime.camera.zoom + runtime.camera.y
    };
  }

  function drawMap() {
    var topLeft = toWorld(0, 0);
    var bottomRight = toWorld(runtime.canvasWidth, runtime.canvasHeight);
    ctx.fillStyle = "#657151";
    ctx.fillRect(0, 0, runtime.canvasWidth, runtime.canvasHeight);

    for (var gx = Math.floor(topLeft.x / 120) * 120; gx < bottomRight.x; gx += 120) {
      for (var gy = Math.floor(topLeft.y / 120) * 120; gy < bottomRight.y; gy += 120) {
        var screen = toScreen(gx, gy);
        var shade = seededRandom(gx * .01 + gy * .007) > .5 ? "rgba(225,220,168,.035)" : "rgba(21,35,20,.035)";
        ctx.fillStyle = shade;
        ctx.fillRect(screen.x, screen.y, 120 * runtime.camera.zoom, 120 * runtime.camera.zoom);
      }
    }

    drawWorldPath([[140,1650],[600,1420],[910,1190],[1180,940],[1480,690],[1820,410],[2280,170]], 78, "#817858");
    drawWorldPath([[0,900],[380,870],[690,930],[1050,875],[1410,930],[1740,865],[2400,905]], 105, "#536e65");
    drawWorldPath([[0,900],[380,870],[690,930],[1050,875],[1410,930],[1740,865],[2400,905]], 72, "#668a80");
    [520,1200,1880].forEach(function (bridgeX) {
      var p = toScreen(bridgeX, 900);
      ctx.fillStyle = "#8b7652";
      ctx.fillRect(p.x - 62 * runtime.camera.zoom, p.y - 47 * runtime.camera.zoom, 124 * runtime.camera.zoom, 94 * runtime.camera.zoom);
      ctx.strokeStyle = "#4f4635";
      ctx.lineWidth = 2;
      for (var line = -50; line <= 50; line += 15) {
        ctx.beginPath();
        ctx.moveTo(p.x + line * runtime.camera.zoom, p.y - 46 * runtime.camera.zoom);
        ctx.lineTo(p.x + line * runtime.camera.zoom, p.y + 46 * runtime.camera.zoom);
        ctx.stroke();
      }
    });

    ctx.strokeStyle = "rgba(228,218,175,.16)";
    ctx.lineWidth = 1;
    for (var x = Math.floor(topLeft.x / 200) * 200; x < bottomRight.x; x += 200) {
      var s1 = toScreen(x, topLeft.y);
      var s2 = toScreen(x, bottomRight.y);
      ctx.beginPath(); ctx.moveTo(s1.x, s1.y); ctx.lineTo(s2.x, s2.y); ctx.stroke();
    }
    for (var y = Math.floor(topLeft.y / 200) * 200; y < bottomRight.y; y += 200) {
      var sy1 = toScreen(topLeft.x, y);
      var sy2 = toScreen(bottomRight.x, y);
      ctx.beginPath(); ctx.moveTo(sy1.x, sy1.y); ctx.lineTo(sy2.x, sy2.y); ctx.stroke();
    }

    var borderA = toScreen(0, 0);
    var borderB = toScreen(runtime.world.width, runtime.world.height);
    ctx.strokeStyle = "#c2aa6844";
    ctx.lineWidth = 3;
    ctx.strokeRect(borderA.x, borderA.y, borderB.x - borderA.x, borderB.y - borderA.y);
  }

  function drawWorldPath(points, width, color) {
    ctx.beginPath();
    points.forEach(function (point, index) {
      var screen = toScreen(point[0], point[1]);
      if (index === 0) ctx.moveTo(screen.x, screen.y); else ctx.lineTo(screen.x, screen.y);
    });
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = color;
    ctx.lineWidth = width * runtime.camera.zoom;
    ctx.stroke();
  }

  function drawNodes() {
    runtime.nodes.forEach(function (node) {
      if (node.amount <= 0) return;
      var screen = toScreen(node.x, node.y);
      if (screen.x < -50 || screen.y < -50 || screen.x > runtime.canvasWidth + 50 || screen.y > runtime.canvasHeight + 50) return;
      var size = node.size * runtime.camera.zoom;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.font = Math.max(10, size * 1.55) + "px serif";
      ctx.globalAlpha = .9;
      ctx.fillText(node.kind === "wood" ? "♣" : (node.kind === "gold" ? "◆" : "●"), screen.x, screen.y);
      ctx.fillStyle = node.kind === "wood" ? "#28432b" : (node.kind === "gold" ? "#d2a24a" : "#a9473e");
      ctx.fillText(node.kind === "wood" ? "♣" : (node.kind === "gold" ? "◆" : "●"), screen.x, screen.y);
      ctx.globalAlpha = 1;
    });
  }

  function drawBuildings() {
    runtime.buildings.forEach(function (building) {
      var blueprint = getBuildingType(building.type) || state.buildingTypes[0];
      if (!blueprint) return;
      var p = toScreen(building.x, building.y);
      var scale = runtime.camera.zoom;
      var width = (blueprint.width || 58) * scale;
      var height = (blueprint.height || 46) * scale;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate((building.rotation || 0) * Math.PI / 180);
      ctx.fillStyle = building.team === "black" ? "#2a2b28" : "#d8d1bc";
      ctx.fillRect(-width / 2, -height / 2, width, height);
      ctx.strokeStyle = building.team === "black" ? "#c09953" : "#594f40";
      ctx.lineWidth = 2;
      ctx.strokeRect(-width / 2, -height / 2, width, height);
      ctx.beginPath();
      ctx.moveTo(-width * .58, -height / 2);
      ctx.lineTo(0, -height * .95);
      ctx.lineTo(width * .58, -height / 2);
      ctx.closePath();
      ctx.fillStyle = building.team === "black" ? "#5c4431" : "#8d6847";
      ctx.fill();
      ctx.font = Math.max(12, 22 * scale) + "px serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(blueprint.emoji, 0, 0);
      var hpRatio = building.hp / building.maxHp;
      ctx.fillStyle = "#331e18";
      ctx.fillRect(-width / 2, height / 2 + 5, width, 3);
      ctx.fillStyle = "#78915b";
      ctx.fillRect(-width / 2, height / 2 + 5, width * hpRatio, 3);
      ctx.restore();
    });
    drawConstructionQueue();
    drawSelectedComplex();
  }

  function drawConstructionQueue() {
    runtime.constructionQueue.forEach(function (planned) {
      var blueprint = getBuildingType(planned.type);
      if (!blueprint) return;
      var p = toScreen(planned.x, planned.y);
      var width = (blueprint.width || 58) * runtime.camera.zoom;
      var height = (blueprint.height || 46) * runtime.camera.zoom;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate((planned.rotation || 0) * Math.PI / 180);
      ctx.globalAlpha = .62;
      ctx.setLineDash([5, 4]);
      ctx.strokeStyle = planned.priority === 1 ? "#f1cd72" : "#c5b88f";
      ctx.lineWidth = 2;
      ctx.strokeRect(-width / 2, -height / 2, width, height);
      ctx.setLineDash([]);
      ctx.font = Math.max(11, 20 * runtime.camera.zoom) + "px serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(blueprint.emoji, 0, 0);
      ctx.restore();
    });
  }

  function complexGroupMembers(groupId) {
    return runtime.buildings.filter(function (building) { return building.groupId === groupId; })
      .concat(runtime.constructionQueue.filter(function (building) { return building.groupId === groupId; }));
  }

  function drawSelectedComplex() {
    if (!runtime.selectedComplexGroupId) return;
    var members = complexGroupMembers(runtime.selectedComplexGroupId);
    if (!members.length) return;
    var minX = Math.min.apply(null, members.map(function (item) { return item.x; })) - 65;
    var maxX = Math.max.apply(null, members.map(function (item) { return item.x; })) + 65;
    var minY = Math.min.apply(null, members.map(function (item) { return item.y; })) - 55;
    var maxY = Math.max.apply(null, members.map(function (item) { return item.y; })) + 55;
    var a = toScreen(minX, minY);
    var b = toScreen(maxX, maxY);
    ctx.save();
    ctx.strokeStyle = "rgba(241,205,114,.8)";
    ctx.lineWidth = 2;
    ctx.setLineDash([7, 5]);
    ctx.strokeRect(a.x, a.y, b.x - a.x, b.y - a.y);
    ctx.setLineDash([]);
    ctx.fillStyle = "rgba(20,22,18,.78)";
    ctx.fillRect(a.x, a.y - 18, Math.min(170, b.x - a.x), 17);
    ctx.fillStyle = "#f1cd72";
    ctx.font = "7px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText("DRAG COMPLEX TO REPOSITION", a.x + 5, a.y - 7);
    ctx.restore();
  }

  function drawWorkers() {
    runtime.workers.forEach(function (worker) {
      var target = nearestNode(worker.x, worker.y, worker.job);
      if (target) {
        var t = (Math.sin(runtime.elapsed * .32 + worker.phase) + 1) / 2;
        worker.x += (target.x - worker.x) * .0007;
        worker.y += (target.y - worker.y) * .0007;
        var wobbleX = Math.sin(runtime.elapsed + worker.phase) * 5;
        var wobbleY = Math.cos(runtime.elapsed * .8 + worker.phase) * 4;
        var p = toScreen(worker.x + wobbleX + t * 4, worker.y + wobbleY);
        ctx.font = Math.max(9, 14 * runtime.camera.zoom) + "px serif";
        ctx.textAlign = "center";
        ctx.fillText(worker.job === "wood" ? "🪓" : (worker.job === "gold" ? "⛏️" : "🧺"), p.x, p.y);
      }
    });
  }

  function nearestNode(x, y, kind) {
    var best = null;
    var bestDist = Infinity;
    runtime.nodes.forEach(function (node) {
      if (node.kind !== kind || node.amount <= 0) return;
      var d = Math.hypot(node.x - x, node.y - y);
      if (d < bestDist) { best = node; bestDist = d; }
    });
    return best;
  }

  function drawWalls() {
    runtime.walls.forEach(function (wall) {
      var p = toScreen(wall.x, wall.y);
      ctx.fillStyle = "#685b4a";
      ctx.strokeStyle = "#29251f";
      ctx.lineWidth = 2;
      ctx.fillRect(p.x - wall.width * runtime.camera.zoom / 2, p.y - 10 * runtime.camera.zoom, wall.width * runtime.camera.zoom, 20 * runtime.camera.zoom);
      ctx.strokeRect(p.x - wall.width * runtime.camera.zoom / 2, p.y - 10 * runtime.camera.zoom, wall.width * runtime.camera.zoom, 20 * runtime.camera.zoom);
      ctx.font = Math.max(10, 16 * runtime.camera.zoom) + "px serif";
      ctx.fillText("🪨 🪨 🪨", p.x, p.y);
    });
  }

  function drawCompaniesAndSoldiers() {
    var ordered = runtime.soldiers.slice().sort(function (a, b) { return a.y - b.y; });
    ordered.forEach(function (fighter) {
      if (fighter.hp <= 0) return;
      var unit = getUnit(fighter.unitId);
      if (!unit) return;
      var p = toScreen(fighter.x, fighter.y);
      if (p.x < -30 || p.y < -30 || p.x > runtime.canvasWidth + 30 || p.y > runtime.canvasHeight + 30) return;
      var radius = clamp(10 * runtime.camera.zoom, 5, 14);
      ctx.beginPath();
      ctx.arc(p.x, p.y + radius * .25, radius, 0, Math.PI * 2);
      ctx.fillStyle = fighter.team === "black" ? "rgba(18,20,18,.92)" : "rgba(232,226,210,.93)";
      ctx.fill();
      ctx.strokeStyle = fighter.team === "black" ? "#c99d4b" : "#686252";
      ctx.lineWidth = fighter.flash > 0 ? 3 : 1;
      ctx.stroke();
      if (fighter.frozenUntil > now()) {
        ctx.beginPath(); ctx.arc(p.x, p.y, radius + 3, 0, Math.PI * 2); ctx.strokeStyle = "#8be4ff"; ctx.stroke();
      }
      if (fighter.poisonUntil > now()) {
        ctx.beginPath(); ctx.arc(p.x, p.y, radius + 5, 0, Math.PI * 2); ctx.strokeStyle = "#91c94f"; ctx.stroke();
      }
      ctx.font = Math.max(10, clamp(17 * runtime.camera.zoom, 10, 21)) + "px serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(unit.emoji, p.x, p.y - 1);
      if (fighter.hp < fighter.maxHp) {
        ctx.fillStyle = "#3a211c";
        ctx.fillRect(p.x - radius, p.y + radius + 3, radius * 2, 2);
        ctx.fillStyle = "#91a66c";
        ctx.fillRect(p.x - radius, p.y + radius + 3, radius * 2 * (fighter.hp / fighter.maxHp), 2);
      }
    });

    runtime.companies.forEach(function (company) {
      var alive = companyFighters(company);
      if (!alive.length) return;
      var p = toScreen(company.x, company.y + company.flagOffset);
      var selected = company.id === runtime.selectedCompanyId;
      ctx.strokeStyle = company.team === "black" ? "#171917" : "#efe9d9";
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(p.x, p.y + 20 * runtime.camera.zoom); ctx.lineTo(p.x, p.y - 23 * runtime.camera.zoom); ctx.stroke();
      ctx.fillStyle = company.team === "black" ? "#222" : "#e9e2d0";
      ctx.strokeStyle = selected ? "#ffd875" : "#4c4437";
      ctx.lineWidth = selected ? 2 : 1;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y - 22 * runtime.camera.zoom);
      ctx.lineTo(p.x + 25 * runtime.camera.zoom, p.y - 15 * runtime.camera.zoom);
      ctx.lineTo(p.x, p.y - 6 * runtime.camera.zoom);
      ctx.closePath(); ctx.fill(); ctx.stroke();
      if (selected) {
        var c = toScreen(company.x, company.y);
        ctx.beginPath();
        ctx.ellipse(c.x, c.y, 90 * runtime.camera.zoom, 62 * runtime.camera.zoom, 0, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(244,202,100,.65)";
        ctx.setLineDash([5,5]); ctx.stroke(); ctx.setLineDash([]);
      }
    });
  }

  function drawProjectiles() {
    runtime.projectiles.forEach(function (projectile) {
      var p = toScreen(projectile.x, projectile.y);
      ctx.font = Math.max(9, 14 * runtime.camera.zoom) + "px serif";
      ctx.fillStyle = projectile.color;
      ctx.shadowColor = projectile.color;
      ctx.shadowBlur = 7;
      ctx.fillText(projectile.emoji, p.x, p.y);
      ctx.shadowBlur = 0;
    });
  }

  function drawEffects() {
    var time = now();
    runtime.effects.forEach(function (effect) {
      var age = time - effect.created;
      var progress = clamp(age / effect.duration, 0, 1);
      var p = toScreen(effect.x, effect.y);
      ctx.save();
      ctx.globalAlpha = 1 - progress;
      if (effect.type === "rune") {
        var spell = effect.spell;
        var center = (spell.size - 1) / 2;
        spell.cells.forEach(function (cellIndex) {
          var row = Math.floor(cellIndex / spell.size);
          var col = cellIndex % spell.size;
          var ring = Math.hypot(row - center, col - center);
          var revealAt = ring * .12 / Math.max(.1, spell.expansion);
          if (age < revealAt) return;
          var cx = p.x + (col - center) * 28 * runtime.camera.zoom;
          var cy = p.y + (row - center) * 28 * runtime.camera.zoom;
          ctx.shadowColor = spell.color;
          ctx.shadowBlur = 14;
          ctx.font = Math.max(12, 23 * runtime.camera.zoom) + "px serif";
          ctx.fillStyle = spell.color;
          ctx.fillText(spell.emoji, cx, cy);
        });
      } else if (effect.type === "lightning") {
        ctx.strokeStyle = "#f9ed9c";
        ctx.lineWidth = 5;
        ctx.beginPath(); ctx.moveTo(p.x + 20, p.y - 180); ctx.lineTo(p.x - 10, p.y - 80); ctx.lineTo(p.x + 12, p.y - 55); ctx.lineTo(p.x, p.y); ctx.stroke();
      } else if (effect.type === "meteor") {
        var radius = (30 + progress * 100) * runtime.camera.zoom;
        ctx.beginPath(); ctx.arc(p.x, p.y, radius, 0, Math.PI * 2); ctx.fillStyle = "rgba(216,79,38,.35)"; ctx.fill();
        ctx.font = Math.max(22, 46 * runtime.camera.zoom) + "px serif"; ctx.fillText("☄️", p.x, p.y - (1 - progress) * 150);
      } else {
        var base = effect.radius || 70;
        ctx.beginPath(); ctx.arc(p.x, p.y, base * (effect.expand ? progress : 1) * runtime.camera.zoom, 0, Math.PI * 2);
        ctx.fillStyle = effect.color || "rgba(255,255,255,.3)"; ctx.fill();
        if (effect.emoji) { ctx.font = Math.max(18, 36 * runtime.camera.zoom) + "px serif"; ctx.fillText(effect.emoji, p.x, p.y); }
      }
      ctx.restore();
    });
  }

  function render() {
    ctx.clearRect(0, 0, runtime.canvasWidth, runtime.canvasHeight);
    drawMap();
    drawNodes();
    drawWalls();
    drawBuildings();
    drawWorkers();
    drawEffects();
    drawCompaniesAndSoldiers();
    drawProjectiles();
    drawComplexPlacementPreview();
    renderMinimap();
  }

  function drawComplexPlacementPreview() {
    if (!runtime.complexPlacement || !runtime.complexPlacement.start || !runtime.complexPlacement.current) return;
    var start = toScreen(runtime.complexPlacement.start.x, runtime.complexPlacement.start.y);
    var current = toScreen(runtime.complexPlacement.current.x, runtime.complexPlacement.current.y);
    var x = Math.min(start.x, current.x);
    var y = Math.min(start.y, current.y);
    var width = Math.abs(current.x - start.x);
    var height = Math.abs(current.y - start.y);
    ctx.save();
    ctx.fillStyle = "rgba(204,166,82,.12)";
    ctx.strokeStyle = "#f1cd72";
    ctx.lineWidth = 2;
    ctx.setLineDash([8, 5]);
    ctx.fillRect(x, y, width, height);
    ctx.strokeRect(x, y, width, height);
    ctx.setLineDash([]);
    ctx.fillStyle = "#171914";
    ctx.fillRect(x, y - 20, Math.min(width || 190, 190), 18);
    ctx.fillStyle = "#f1cd72";
    ctx.font = "8px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText("DRAG TO SIZE BUILDING COMPLEX", x + 6, y - 8);
    ctx.restore();
  }

  function renderMinimap() {
    var w = minimap.width;
    var h = minimap.height;
    mapCtx.clearRect(0, 0, w, h);
    mapCtx.fillStyle = "#526347"; mapCtx.fillRect(0, 0, w, h);
    mapCtx.fillStyle = "#668a80"; mapCtx.fillRect(0, h * .48, w, h * .07);
    runtime.nodes.forEach(function (node) {
      if (node.amount <= 0) return;
      mapCtx.fillStyle = node.kind === "gold" ? "#d2a24a" : (node.kind === "food" ? "#a7493e" : "#2d4930");
      mapCtx.fillRect(node.x / runtime.world.width * w, node.y / runtime.world.height * h, 2, 2);
    });
    runtime.buildings.forEach(function (building) {
      mapCtx.fillStyle = building.team === "black" ? "#111" : "#f4efe1";
      mapCtx.fillRect(building.x / runtime.world.width * w - 2, building.y / runtime.world.height * h - 2, 5, 5);
    });
    runtime.constructionQueue.forEach(function (building) {
      mapCtx.strokeStyle = "#f1cd72";
      mapCtx.strokeRect(building.x / runtime.world.width * w - 2, building.y / runtime.world.height * h - 2, 4, 4);
    });
    runtime.companies.forEach(function (company) {
      if (!companyFighters(company).length) return;
      mapCtx.fillStyle = company.team === "black" ? "#080908" : "#fffaf0";
      mapCtx.beginPath();
      mapCtx.arc(company.x / runtime.world.width * w, company.y / runtime.world.height * h, 3, 0, Math.PI * 2);
      mapCtx.fill();
    });
    var viewWorldW = runtime.canvasWidth / runtime.camera.zoom;
    var viewWorldH = runtime.canvasHeight / runtime.camera.zoom;
    mapCtx.strokeStyle = "#f1c966";
    mapCtx.lineWidth = 1;
    mapCtx.strokeRect(
      (runtime.camera.x - viewWorldW / 2) / runtime.world.width * w,
      (runtime.camera.y - viewWorldH / 2) / runtime.world.height * h,
      viewWorldW / runtime.world.width * w,
      viewWorldH / runtime.world.height * h
    );
  }

  function companyFighters(company) {
    return runtime.soldiers.filter(function (fighter) { return fighter.companyId === company.id && fighter.hp > 0; });
  }

  function nearestEnemy(fighter, maxDistance) {
    var best = null;
    var bestDistance = maxDistance || Infinity;
    for (var i = 0; i < runtime.soldiers.length; i++) {
      var candidate = runtime.soldiers[i];
      if (candidate.team === fighter.team || candidate.hp <= 0) continue;
      var d = distance(fighter, candidate);
      if (d < bestDistance) { best = candidate; bestDistance = d; }
    }
    return best ? { fighter: best, distance: bestDistance } : null;
  }

  function updateCompanies(dt) {
    runtime.companies.forEach(function (company) {
      var alive = companyFighters(company);
      if (!alive.length) return;
      var avgX = alive.reduce(function (sum, f) { return sum + f.x; }, 0) / alive.length;
      var avgY = alive.reduce(function (sum, f) { return sum + f.y; }, 0) / alive.length;
      company.x += (avgX - company.x) * Math.min(1, dt * 2.2);
      company.y += (avgY - company.y) * Math.min(1, dt * 2.2);
      if (company.team === "white" && !company.halted) {
        var nearestBlack = runtime.companies.filter(function (c) { return c.team === "black" && companyFighters(c).length; }).sort(function (a,b) { return distance(company,a) - distance(company,b); })[0];
        if (nearestBlack) { company.targetX = nearestBlack.x; company.targetY = nearestBlack.y; }
      }
    });
  }

  function updateSoldiers(dt) {
    var time = now();
    runtime.soldiers.forEach(function (fighter) {
      if (fighter.hp <= 0) return;
      var unit = getUnit(fighter.unitId);
      var company = runtime.companies.find(function (c) { return c.id === fighter.companyId; });
      if (!unit || !company) return;
      var stats = tiered(unit);
      fighter.cooldown -= dt;
      fighter.flash = Math.max(0, fighter.flash - dt * 4);
      if (fighter.burnUntil > time) fighter.hp -= dt * 3;
      if (fighter.poisonUntil > time) fighter.hp -= dt * 2;
      var slow = fighter.frozenUntil > time ? .36 : 1;
      var desired = { x: company.x + fighter.offsetX, y: company.y + fighter.offsetY };
      var sight = unit.role === "Mage" ? 520 : Math.max(220, unit.range * 1.55);
      var enemyInfo = nearestEnemy(fighter, sight);

      if (unit.focus === "support" && fighter.cooldown <= 0) {
        var ally = runtime.soldiers.filter(function (f) { return f.team === fighter.team && f.hp > 0 && f.hp < f.maxHp; }).sort(function (a,b) { return distance(fighter,a) - distance(fighter,b); })[0];
        if (ally && distance(fighter, ally) < unit.range) {
          ally.hp = Math.min(ally.maxHp, ally.hp + Math.max(12, unit.attack * 1.8));
          fighter.cooldown = unit.rate;
          runtime.effects.push({ type: "pulse", x: ally.x, y: ally.y, radius: 32, color: "rgba(244,234,155,.36)", emoji: "✨", duration: .8, created: time });
        }
      } else if (enemyInfo) {
        var enemy = enemyInfo.fighter;
        var attackRange = Math.max(24, unit.range);
        if (enemyInfo.distance <= attackRange) {
          if (fighter.cooldown <= 0) attack(fighter, enemy, unit, stats);
          if ((company.stance === "keep-away" || unit.stance === "keep-away") && enemyInfo.distance < attackRange * .55) {
            moveAway(fighter, enemy, stats.speed * slow * dt * 22);
          }
        } else if (!company.halted && company.stance !== "ground") {
          moveToward(fighter, enemy, stats.speed * slow * dt * 22);
        } else {
          moveToward(fighter, desired, stats.speed * slow * dt * 13);
        }
      } else if (!company.halted) {
        var companyTarget = { x: company.targetX + fighter.offsetX, y: company.targetY + fighter.offsetY };
        if (distance(fighter, companyTarget) > 6) moveToward(fighter, companyTarget, stats.speed * slow * dt * 18);
        if (distance(company, {x:company.targetX,y:company.targetY}) > 20) {
          var anchorSpeed = Math.min(stats.speed, 2.3) * dt * 12;
          moveToward(company, {x:company.targetX,y:company.targetY}, anchorSpeed);
        }
      } else {
        moveToward(fighter, desired, stats.speed * slow * dt * 12);
      }
      fighter.x = clamp(fighter.x, 15, runtime.world.width - 15);
      fighter.y = clamp(fighter.y, 15, runtime.world.height - 15);
    });
    runtime.soldiers = runtime.soldiers.filter(function (fighter) { return fighter.hp > -20; });
  }

  function moveToward(actor, target, amount) {
    var dx = target.x - actor.x;
    var dy = target.y - actor.y;
    var d = Math.hypot(dx, dy);
    if (d <= .01) return;
    actor.x += dx / d * Math.min(amount, d);
    actor.y += dy / d * Math.min(amount, d);
  }
  function moveAway(actor, target, amount) {
    var dx = actor.x - target.x;
    var dy = actor.y - target.y;
    var d = Math.hypot(dx, dy) || 1;
    actor.x += dx / d * amount;
    actor.y += dy / d * amount;
  }

  function attack(attacker, target, unit, stats) {
    attacker.cooldown = unit.rate;
    if (unit.projectile && unit.projectile.enabled) {
      runtime.projectiles.push({
        x: attacker.x, y: attacker.y, targetId: target.id, team: attacker.team,
        damage: stats.attack, emoji: unit.projectile.emoji, color: unit.projectile.color,
        speed: unit.projectile.speed * 34, sourceUnitId: unit.id
      });
    } else {
      applyDamage(target, stats.attack);
      attacker.flash = .18;
      mageAftermath(unit, target.x, target.y, attacker.team);
    }
  }

  function applyDamage(target, amount) {
    var unit = getUnit(target.unitId);
    var defense = unit ? tiered(unit).defense : 0;
    var damage = Math.max(1, amount - defense * .55);
    target.hp -= damage;
    target.flash = .24;
  }

  function updateProjectiles(dt) {
    runtime.projectiles.forEach(function (projectile) {
      var target = runtime.soldiers.find(function (fighter) { return fighter.id === projectile.targetId && fighter.hp > 0; });
      if (!target) { projectile.dead = true; return; }
      var step = projectile.speed * dt;
      if (distance(projectile, target) <= step + 7) {
        applyDamage(target, projectile.damage);
        var sourceUnit = getUnit(projectile.sourceUnitId);
        mageAftermath(sourceUnit, target.x, target.y, projectile.team);
        projectile.dead = true;
      } else moveToward(projectile, target, step);
    });
    runtime.projectiles = runtime.projectiles.filter(function (projectile) { return !projectile.dead; });
  }

  function mageAftermath(unit, x, y, team) {
    if (!unit || unit.role !== "Mage") return;
    var time = now();
    var type = unit.name.toLowerCase();
    if (type === "pyromancer") {
      runtime.effects.push({ type: "hazard", hazard: "fire", x: x, y: y, radius: 48, color: "rgba(235,82,38,.28)", emoji: "🔥", duration: 4, created: time });
      affectRadius(x, y, 48, team, function (f) { f.burnUntil = time + 4; });
    } else if (type === "cryomancer") {
      runtime.effects.push({ type: "hazard", hazard: "ice", x: x, y: y, radius: 60, color: "rgba(109,210,241,.25)", emoji: "❄️", duration: 4, created: time });
      affectRadius(x, y, 60, team, function (f) { f.frozenUntil = time + 3; });
    } else if (type === "geomancer") {
      runtime.walls.push({ x: x, y: y, width: 90, team: team, expires: time + 8 });
    } else if (type === "venomancer") {
      runtime.effects.push({ type: "hazard", hazard: "poison", x: x, y: y, radius: 55, color: "rgba(105,152,50,.28)", emoji: "☠️", duration: 5, created: time });
      affectRadius(x, y, 55, team, function (f) { f.poisonUntil = time + 5; });
    } else if (type === "mudmancer") {
      runtime.effects.push({ type: "hazard", hazard: "mud", x: x, y: y, radius: 65, color: "rgba(96,65,40,.32)", emoji: "🟤", duration: 5, created: time });
      affectRadius(x, y, 65, team, function (f) { f.frozenUntil = time + 2.4; });
    }
  }

  function affectRadius(x, y, radius, friendlyTeam, callback, includeFriendly) {
    runtime.soldiers.forEach(function (fighter) {
      if (fighter.hp <= 0) return;
      if (!includeFriendly && fighter.team === friendlyTeam) return;
      if (Math.hypot(fighter.x - x, fighter.y - y) <= radius) callback(fighter);
    });
  }

  function updateEconomy(dt) {
    runtime.economyAccumulator += dt;
    if (runtime.economyAccumulator < 2) return;
    runtime.economyAccumulator = 0;
    var bonus = 1 + state.research.filter(function (r) { return r.done && r.modifier === "economy"; }).reduce(function (sum, r) { return sum + r.value; }, 0);
    var mills = runtime.buildings.filter(function (b) { return b.team === "black" && b.type === "mill"; }).length;
    var lumber = runtime.buildings.filter(function (b) { return b.team === "black" && b.type === "lumber"; }).length;
    var mines = runtime.buildings.filter(function (b) { return b.team === "black" && b.type === "mine"; }).length;
    state.resources.food += Math.round((state.economy.foodWorkers * 1.4 + mills * 3) * bonus);
    state.resources.wood += Math.round((state.economy.woodWorkers * 1.25 + lumber * 3) * bonus);
    state.resources.gold += Math.round((state.economy.goldWorkers * .85 + mines * 2) * bonus);
    updateResourceUI();
    processConstructionQueue();
  }

  function updateEffects() {
    var time = now();
    runtime.effects = runtime.effects.filter(function (effect) { return time - effect.created < effect.duration; });
    runtime.walls = runtime.walls.filter(function (wall) { return wall.expires > time; });
    Object.keys(runtime.powerReady).forEach(function (id) {
      if (runtime.powerReady[id] <= time) delete runtime.powerReady[id];
    });
  }

  function gameLoop(timestamp) {
    var dt = Math.min(.04, (timestamp - runtime.lastFrame) / 1000) * runtime.speed;
    runtime.lastFrame = timestamp;
    if (!runtime.paused) {
      runtime.elapsed += dt;
      updateCompanies(dt);
      updateSoldiers(dt);
      updateProjectiles(dt);
      updateEconomy(dt);
      updateEffects();
    }
    render();
    updateClock();
    requestAnimationFrame(gameLoop);
  }

  function updateClock() {
    var total = Math.floor(runtime.elapsed);
    $("#battleClock").textContent = String(Math.floor(total / 60)).padStart(2, "0") + ":" + String(total % 60).padStart(2, "0");
    var black = runtime.soldiers.filter(function (f) { return f.team === "black" && f.hp > 0; }).length;
    var white = runtime.soldiers.filter(function (f) { return f.team === "white" && f.hp > 0; }).length;
    $("#blackStrength").textContent = black;
    $("#whiteStrength").textContent = white;
  }

  function updateResourceUI() {
    $("#foodValue").textContent = Math.floor(state.resources.food);
    $("#woodValue").textContent = Math.floor(state.resources.wood);
    $("#goldValue").textContent = Math.floor(state.resources.gold);
    var alive = runtime.soldiers.filter(function (f) { return f.team === "black" && f.hp > 0; }).length + state.economy.workers;
    $("#popValue").textContent = alive + " / " + state.economy.populationCap;
  }

  function addEvent(message) {
    var total = Math.floor(runtime.elapsed);
    var time = String(Math.floor(total / 60)).padStart(2, "0") + ":" + String(total % 60).padStart(2, "0");
    var item = document.createElement("p");
    item.innerHTML = "<time>" + time + "</time>" + escapeHtml(message);
    $("#eventItems").prepend(item);
    while ($("#eventItems").children.length > 3) $("#eventItems").lastElementChild.remove();
  }

  function toast(message) {
    var el = $("#toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(toast.timer);
    toast.timer = setTimeout(function () { el.classList.remove("show"); }, 2300);
  }

  function renderBuildings() {
    $("#buildingList").innerHTML = state.buildingTypes.map(function (building) {
      var cost = Object.keys(building.cost).filter(function (key) { return building.cost[key] > 0; }).map(function (key) { return building.cost[key] + " " + key[0].toUpperCase(); }).join(" · ");
      return '<button class="blueprint" data-building="' + building.id + '" title="' + escapeHtml(building.use) + '"><span class="emoji">' + building.emoji + '</span><strong>' + escapeHtml(building.name) + '</strong><small>' + cost + '</small></button>';
    }).join("");
  }

  function renderArmyList() {
    var blackCompanies = runtime.companies.filter(function (c) { return c.team === "black"; });
    $("#armyList").innerHTML = blackCompanies.map(function (company) {
      var fighters = companyFighters(company);
      var first = fighters[0];
      var emoji = first ? getUnit(first.unitId).emoji : "☠️";
      return '<button class="army-row ' + (company.id === runtime.selectedCompanyId ? "selected" : "") + '" data-company="' + company.id + '"><span class="emoji">' + emoji + '</span><span><strong>' + escapeHtml(company.name) + '</strong><small>' + escapeHtml(getFormation(company.formationId).name) + '</small></span><b>' + fighters.length + '</b></button>';
    }).join("");
  }

  function renderResearch() {
    $("#researchList").innerHTML = state.research.map(function (research) {
      var cost = Object.keys(research.cost).map(function (key) { return research.cost[key] + " " + key.toUpperCase(); }).join(" · ");
      return '<div class="research-row"><span><strong>' + escapeHtml(research.name) + '</strong><small>' + escapeHtml(research.note) + '<br>' + cost + '</small></span><button data-research="' + research.id + '" ' + (research.done ? "disabled" : "") + '>' + (research.done ? "DONE" : "RESEARCH") + '</button></div>';
    }).join("");
  }

  function renderPowers() {
    $("#powerList").innerHTML = POWERS.map(function (power) {
      return '<button class="power" data-power="' + power.id + '" title="' + escapeHtml(power.name) + ' — ' + power.cost + ' favor"><span>' + power.emoji + '</span><small>' + power.cost + '</small></button>';
    }).join("");
  }

  function updatePowerButtons() {
    var time = now();
    $$(".power").forEach(function (button) {
      var id = button.dataset.power;
      button.classList.toggle("active", runtime.activePower === id);
      var ready = runtime.powerReady[id] || 0;
      button.classList.toggle("cooling", ready > time);
      var power = POWERS.find(function (p) { return p.id === id; });
      button.querySelector("small").textContent = ready > time ? Math.ceil(ready - time) : power.cost;
    });
  }

  function canAfford(cost) {
    return Object.keys(cost).every(function (key) { return state.resources[key] >= cost[key]; });
  }
  function spend(cost) {
    Object.keys(cost).forEach(function (key) { state.resources[key] -= cost[key]; });
    updateResourceUI();
  }

  function placeBuilding(type, position) {
    var blueprint = getBuildingType(type);
    if (!blueprint || !canAfford(blueprint.cost)) { toast("NOT ENOUGH RESOURCES"); return; }
    spend(blueprint.cost);
    var hpBonus = state.research.filter(function (r) { return r.done && r.modifier === "building"; }).reduce(function (sum, r) { return sum + r.value; }, 0);
    var hp = blueprint.hp * (1 + hpBonus);
    runtime.buildings.push({ id: uid("BLD"), type: type, team: "black", x: position.x, y: position.y, rotation: 0, hp: hp, maxHp: hp });
    if (type === "house") state.economy.populationCap += 10;
    runtime.buildMode = null;
    $$(".blueprint").forEach(function (button) { button.classList.remove("selected"); });
    canvas.classList.remove("targeting");
    addEvent(blueprint.name + " raised for the Black Company.");
    toast(blueprint.name.toUpperCase() + " BUILT");
    persistLocal();
  }

  function queueBuildingComplex(complex, start, end) {
    if (!complex || !complex.items.length) { toast("ADD BUILDINGS TO THIS COMPLEX FIRST"); return; }
    var minX = Math.min(start.x, end.x);
    var minY = Math.min(start.y, end.y);
    var width = Math.max(180, Math.abs(end.x - start.x));
    var height = Math.max(130, Math.abs(end.y - start.y));
    if (Math.abs(end.x - start.x) < 30) minX = start.x - width / 2;
    if (Math.abs(end.y - start.y) < 30) minY = start.y - height / 2;
    var groupId = uid("SITE");
    complex.items.forEach(function (item) {
      runtime.constructionQueue.push({
        id: uid("QUEUE"),
        groupId: groupId,
        complexId: complex.id,
        type: item.buildingTypeId,
        team: "black",
        x: clamp(minX + item.x / 640 * width, 30, runtime.world.width - 30),
        y: clamp(minY + item.y / 420 * height, 30, runtime.world.height - 30),
        rotation: item.rotation || 0,
        priority: item.priority || complex.defaultPriority || 3
      });
    });
    runtime.selectedComplexGroupId = groupId;
    runtime.complexPlacement = null;
    canvas.classList.remove("targeting");
    processConstructionQueue();
    updateConstructionQueueChip();
    addEvent(complex.name + " construction plan established.");
    toast("COMPLEX QUEUED BY BUILD PRIORITY");
    persistLocal();
  }

  function processConstructionQueue() {
    if (!runtime.constructionQueue.length) { updateConstructionQueueChip(); return; }
    runtime.constructionQueue.sort(function (a, b) { return a.priority - b.priority; });
    var completed = [];
    runtime.constructionQueue.forEach(function (planned) {
      var blueprint = getBuildingType(planned.type);
      if (!blueprint || !canAfford(blueprint.cost)) return;
      spend(blueprint.cost);
      var hpBonus = state.research.filter(function (r) { return r.done && r.modifier === "building"; }).reduce(function (sum, r) { return sum + r.value; }, 0);
      var hp = blueprint.hp * (1 + hpBonus);
      runtime.buildings.push({
        id: uid("BLD"), groupId: planned.groupId, complexId: planned.complexId,
        type: planned.type, team: "black", x: planned.x, y: planned.y,
        rotation: planned.rotation || 0, priority: planned.priority, hp: hp, maxHp: hp
      });
      if (planned.type === "house") state.economy.populationCap += 10;
      completed.push(planned.id);
      addEvent(blueprint.name + " completed from the priority queue.");
    });
    runtime.constructionQueue = runtime.constructionQueue.filter(function (planned) { return completed.indexOf(planned.id) < 0; });
    updateConstructionQueueChip();
  }

  function updateConstructionQueueChip() {
    var chip = $("#constructionQueueChip");
    if (!chip) return;
    chip.classList.toggle("hidden", runtime.constructionQueue.length === 0);
    chip.textContent = runtime.constructionQueue.length + " PLANNED BUILDING" + (runtime.constructionQueue.length === 1 ? "" : "S") + " WAITING FOR RESOURCES";
  }

  function performResearch(id) {
    var research = state.research.find(function (item) { return item.id === id; });
    if (!research || research.done) return;
    if (!canAfford(research.cost)) { toast("NOT ENOUGH RESOURCES"); return; }
    spend(research.cost);
    research.done = true;
    addEvent(research.name + " research completed.");
    toast(research.name.toUpperCase() + " COMPLETE");
    renderResearch();
    persistLocal();
  }

  function usePower(id, position) {
    var power = POWERS.find(function (p) { return p.id === id; });
    if (!power || runtime.powerReady[id] > now()) return;
    if (state.resources.favor < power.cost) { toast("NOT ENOUGH DIVINE FAVOR"); return; }
    state.resources.favor -= power.cost;
    runtime.powerReady[id] = now() + power.cooldown;
    runtime.activePower = null;
    canvas.classList.remove("targeting");
    var time = now();
    if (id === "lightning") {
      runtime.effects.push({ type: "lightning", x: position.x, y: position.y, duration: .7, created: time });
      affectRadius(position.x, position.y, 95, "black", function (f) { f.hp -= 85; });
    } else if (id === "heal") {
      runtime.effects.push({ type: "pulse", x: position.x, y: position.y, radius: 110, color: "rgba(241,222,126,.34)", emoji: "✨", duration: 1.3, expand: true, created: time });
      affectRadius(position.x, position.y, 120, "white", function (f) { f.hp = Math.min(f.maxHp, f.hp + 95); }, false);
    } else if (id === "meteor") {
      runtime.effects.push({ type: "meteor", x: position.x, y: position.y, duration: 1.5, created: time });
      affectRadius(position.x, position.y, 145, "black", function (f) { f.hp -= 130; });
    } else if (id === "freeze") {
      runtime.effects.push({ type: "pulse", x: position.x, y: position.y, radius: 135, color: "rgba(123,220,255,.28)", emoji: "❄️", duration: 2.2, created: time });
      affectRadius(position.x, position.y, 140, "black", function (f) { f.frozenUntil = time + 6; });
    } else if (id === "forest") {
      for (var i = 0; i < 16; i++) {
        var a = i * 2.399; var r = 25 + (i % 4) * 15;
        runtime.nodes.push({ id: uid("NODE"), kind: "wood", x: position.x + Math.cos(a) * r, y: position.y + Math.sin(a) * r, amount: 650, size: 19 });
      }
      runtime.effects.push({ type: "pulse", x: position.x, y: position.y, radius: 90, color: "rgba(55,115,51,.3)", emoji: "🌳", duration: 1.8, expand: true, created: time });
    } else if (id === "quake") {
      runtime.effects.push({ type: "pulse", x: position.x, y: position.y, radius: 170, color: "rgba(104,73,49,.4)", emoji: "💥", duration: 1.4, expand: true, created: time });
      affectRadius(position.x, position.y, 175, "black", function (f) { f.hp -= 60; });
      runtime.buildings.forEach(function (b) { if (b.team === "white" && Math.hypot(b.x-position.x,b.y-position.y) < 190) b.hp -= 220; });
    } else if (id === "plague") {
      runtime.effects.push({ type: "hazard", x: position.x, y: position.y, radius: 130, color: "rgba(91,139,42,.35)", emoji: "☠️", duration: 7, created: time });
      affectRadius(position.x, position.y, 135, "black", function (f) { f.poisonUntil = time + 9; });
    } else if (id === "wall") {
      for (var j = -2; j <= 2; j++) runtime.walls.push({ x: position.x + j * 75, y: position.y, width: 70, team: "black", expires: time + 18 });
      runtime.effects.push({ type: "pulse", x: position.x, y: position.y, radius: 75, color: "rgba(160,139,104,.25)", emoji: "🪨", duration: 1.2, created: time });
    } else if (id === "rune") {
      var activeSpell = getSpell(runtime.activeSpellId) || state.spells[0];
      var spellPosition = position;
      if (activeSpell && activeSpell.origin === "caster") {
        var company = selectedCompany();
        var mage = companyFighters(company || {}).find(function (fighter) {
          var mageUnit = getUnit(fighter.unitId);
          return mageUnit && mageUnit.role === "Mage";
        });
        if (mage) spellPosition = { x: mage.x, y: mage.y };
        else if (company) spellPosition = { x: company.x, y: company.y };
      }
      castSpell(activeSpell, spellPosition, "black");
    }
    addEvent(power.name + " descends upon the field.");
    updatePowerButtons();
  }

  function castSpell(spell, position, team) {
    if (!spell) return;
    runtime.effects.push({ type: "rune", spell: clone(spell), x: position.x, y: position.y, duration: spell.duration, created: now() });
    var radius = spell.size * 17;
    affectRadius(position.x, position.y, radius, team, function (fighter) { fighter.hp -= spell.damage; });
  }

  function selectCompany(id) {
    var company = runtime.companies.find(function (c) { return c.id === id && c.team === "black"; });
    if (!company) return;
    runtime.selectedCompanyId = id;
    updateSelectionUI();
    renderArmyList();
  }

  function selectedCompany() {
    return runtime.companies.find(function (company) { return company.id === runtime.selectedCompanyId; });
  }

  function updateSelectionUI() {
    var company = selectedCompany();
    if (!company) return;
    var fighters = companyFighters(company);
    var formation = getFormation(company.formationId) || state.formations[0];
    var firstUnit = fighters[0] ? getUnit(fighters[0].unitId) : state.units[0];
    var avgHp = fighters.length ? fighters.reduce(function (sum,f) { return sum + f.hp / f.maxHp; }, 0) / fighters.length : 0;
    var avgStats = fighters.length ? fighters.reduce(function (acc, fighter) {
      var stats = tiered(getUnit(fighter.unitId));
      acc.attack += stats.attack; acc.defense += stats.defense; acc.speed += stats.speed; return acc;
    }, {attack:0,defense:0,speed:0}) : {attack:0,defense:0,speed:0};
    $("#selectedEmoji").textContent = firstUnit.emoji;
    $("#selectedName").textContent = company.name.toUpperCase();
    $("#selectedMeta").textContent = fighters.length + " / " + formation.slots.length + " · " + formation.name;
    $("#selectedHealth").style.width = Math.round(avgHp * 100) + "%";
    $("#selectedDamage").textContent = fighters.length ? Math.round(avgStats.attack / fighters.length) : 0;
    $("#selectedArmor").textContent = fighters.length ? Math.round(avgStats.defense / fighters.length) : 0;
    $("#selectedSpeed").textContent = fighters.length ? (avgStats.speed / fighters.length).toFixed(1) : "0";
    $("#formationName").textContent = formation.name.toUpperCase();
    $("#formationCount").textContent = fighters.length + " fighters";
    $$("#stanceControls button").forEach(function (button) { button.classList.toggle("active", button.dataset.stance === company.stance); });
    renderFormationPreview(formation);
  }

  function renderFormationPreview(formation) {
    var preview = $("#formationPreview");
    preview.style.gridTemplateColumns = "repeat(" + formation.cols + ", 6px)";
    var occupied = {};
    formation.slots.forEach(function (s) { occupied[s.row + ":" + s.col] = true; });
    var html = "";
    for (var row = 0; row < formation.rows; row++) {
      for (var col = 0; col < formation.cols; col++) html += occupied[row + ":" + col] ? "<i></i>" : "<span></span>";
    }
    preview.innerHTML = html;
  }

  function cycleCompanyFormation(direction) {
    var company = selectedCompany();
    if (!company || !state.formations.length) return;
    var index = state.formations.findIndex(function (formation) { return formation.id === company.formationId; });
    index = (index + direction + state.formations.length) % state.formations.length;
    var newFormation = state.formations[index];
    if (!newFormation.slots.length) {
      toast("ADD FIGHTERS TO THIS FORMATION BEFORE FIELDING IT");
      return;
    }
    company.formationId = newFormation.id;
    company.formationIndex = index;
    var fighters = companyFighters(company);
    fighters.forEach(function (fighter, i) {
      var s = newFormation.slots[i % newFormation.slots.length];
      fighter.offsetX = (s.col - (newFormation.cols - 1) / 2) * 27;
      fighter.offsetY = (s.row - (newFormation.rows - 1) / 2) * 27;
      if (i < newFormation.slots.length) fighter.unitId = s.unitId;
    });
    if (fighters.length < newFormation.slots.length) {
      newFormation.slots.slice(fighters.length).forEach(function (s) {
        var unit = getUnit(s.unitId); var stats = tiered(unit);
        runtime.soldiers.push({ id: uid("FTR"), companyId: company.id, team: company.team, unitId: unit.id, x: company.x, y: company.y, offsetX:(s.col-(newFormation.cols-1)/2)*27, offsetY:(s.row-(newFormation.rows-1)/2)*27, hp:stats.health, maxHp:stats.health, cooldown:0, frozenUntil:0, poisonUntil:0, burnUntil:0, flash:0 });
      });
    }
    updateSelectionUI();
    renderArmyList();
    addEvent(company.name + " reforms into " + newFormation.name + ".");
  }

  function openDrawer(id) {
    $("#modalBackdrop").classList.remove("hidden");
    $$(".drawer, .load-dialog").forEach(function (drawer) { drawer.classList.add("hidden"); });
    $(id).classList.remove("hidden");
  }
  function closeDrawers() {
    $("#modalBackdrop").classList.add("hidden");
    $$(".drawer, .load-dialog").forEach(function (drawer) { drawer.classList.add("hidden"); });
    $("#formationDrawer .formation-layout").classList.remove("picker-open");
    $("#unitPicker").classList.add("hidden");
  }

  function populateEmojiSelect(select, items) {
    select.innerHTML = items.map(function (emoji) { return '<option value="' + emoji + '">' + emoji + '</option>'; }).join("");
  }

  function renderUnitCatalog(filter) {
    var term = (filter || "").trim().toLowerCase();
    $("#unitCatalog").innerHTML = state.units.filter(function (unit) {
      return !term || unit.name.toLowerCase().indexOf(term) >= 0 || unit.role.toLowerCase().indexOf(term) >= 0;
    }).map(function (unit) {
      return '<button class="catalog-item ' + (unit.id === runtime.activeUnitId ? "active" : "") + '" data-unit="' + unit.id + '"><span class="emoji">' + unit.emoji + '</span><span><strong>' + escapeHtml(unit.name) + '</strong><small>' + escapeHtml(unit.role) + ' · ' + escapeHtml(unit.focus) + '</small></span><small>' + unit.health + ' HP</small></button>';
    }).join("");
  }

  function loadUnitForm(id) {
    var unit = getUnit(id) || state.units[0];
    if (!unit) return;
    runtime.activeUnitId = unit.id;
    runtime.activeTierId = unit.activeTierId || unit.tiers[0].id;
    $("#unitName").value = unit.name;
    $("#unitId").textContent = unit.id;
    $("#unitDescription").value = unit.description;
    $("#unitEmoji").value = unit.emoji;
    $("#unitEmojiPreview").textContent = unit.emoji;
    $("#unitHealth").value = unit.health;
    $("#unitAttack").value = unit.attack;
    $("#unitDefense").value = unit.defense;
    $("#unitSpeed").value = unit.speed;
    $("#unitRange").value = unit.range;
    $("#unitRate").value = unit.rate;
    $("#unitFocus").value = unit.focus;
    $("#unitStance").value = unit.stance;
    $("#unitRole").value = unit.role;
    $("#projectileEnabled").checked = !!unit.projectile.enabled;
    $("#projectileEmoji").value = unit.projectile.emoji;
    $("#projectileColor").value = unit.projectile.color;
    $("#projectileSpeed").value = unit.projectile.speed;
    $(".projectile-section").classList.toggle("disabled", !unit.projectile.enabled);
    renderTierSelect(unit);
    loadTierFields(unit);
    renderUnitCatalog($("#unitSearch").value);
  }

  function renderTierSelect(unit) {
    $("#tierSelect").innerHTML = unit.tiers.map(function (tier) { return '<option value="' + tier.id + '">' + escapeHtml(tier.name) + '</option>'; }).join("");
    if (!unit.tiers.some(function (tier) { return tier.id === runtime.activeTierId; })) runtime.activeTierId = unit.tiers[0].id;
    $("#tierSelect").value = runtime.activeTierId;
  }
  function loadTierFields(unit) {
    var tier = unit.tiers.find(function (item) { return item.id === runtime.activeTierId; }) || unit.tiers[0];
    if (!tier) return;
    $("#tierName").value = tier.name;
    $("#tierHealth").value = tier.health;
    $("#tierAttack").value = tier.attack;
    $("#tierSpeed").value = tier.speed;
  }
  function syncTierFields() {
    var unit = getUnit(runtime.activeUnitId);
    var tier = unit && unit.tiers.find(function (item) { return item.id === runtime.activeTierId; });
    if (!tier) return;
    tier.name = $("#tierName").value.trim() || tier.name;
    tier.health = Number($("#tierHealth").value) || 1;
    tier.attack = Number($("#tierAttack").value) || 1;
    tier.speed = Number($("#tierSpeed").value) || 1;
    renderTierSelect(unit);
  }

  function saveUnitForm(event) {
    event.preventDefault();
    syncTierFields();
    var unit = getUnit(runtime.activeUnitId);
    if (!unit) return;
    unit.name = $("#unitName").value.trim() || "Unnamed Fighter";
    unit.description = $("#unitDescription").value.trim();
    unit.emoji = $("#unitEmoji").value;
    unit.health = Number($("#unitHealth").value) || 1;
    unit.attack = Number($("#unitAttack").value) || 0;
    unit.defense = Number($("#unitDefense").value) || 0;
    unit.speed = Number($("#unitSpeed").value) || 1;
    unit.range = Number($("#unitRange").value) || 0;
    unit.rate = Number($("#unitRate").value) || 1;
    unit.focus = $("#unitFocus").value;
    unit.stance = $("#unitStance").value;
    unit.role = $("#unitRole").value;
    unit.activeTierId = runtime.activeTierId;
    unit.projectile = { enabled: $("#projectileEnabled").checked, emoji: $("#projectileEmoji").value, color: $("#projectileColor").value, speed: Number($("#projectileSpeed").value) || 10 };
    renderUnitCatalog();
    renderFormationMatrix();
    persistLocal();
    toast("UNIT TYPE SAVED");
  }

  function renderFormationCatalog() {
    $("#formationCatalog").innerHTML = state.formations.map(function (formation) {
      return '<button class="formation-card ' + (formation.id === runtime.activeFormationId ? "active" : "") + '" data-formation="' + formation.id + '"><strong>' + escapeHtml(formation.name) + '</strong><small>' + formation.rows + " × " + formation.cols + ' · ' + formation.slots.length + ' fighters</small></button>';
    }).join("");
  }

  function renderFormationMatrix() {
    var formation = getFormation(runtime.activeFormationId) || state.formations[0];
    if (!formation) return;
    $("#matrixRows").value = formation.rows;
    $("#matrixCols").value = formation.cols;
    var matrix = $("#formationMatrix");
    matrix.style.gridTemplateColumns = "repeat(" + formation.cols + ", minmax(32px,1fr))";
    matrix.style.aspectRatio = formation.cols + " / " + formation.rows;
    var lookup = {};
    formation.slots.forEach(function (s) { lookup[s.row + ":" + s.col] = s; });
    var html = "";
    for (var row = 0; row < formation.rows; row++) {
      for (var col = 0; col < formation.cols; col++) {
        var s = lookup[row + ":" + col];
        var unit = s ? getUnit(s.unitId) : null;
        html += '<button class="matrix-cell ' + (unit ? "filled" : "") + '" data-cell="' + (row * formation.cols + col) + '" title="' + (unit ? escapeHtml(unit.name) : "Empty space") + '">' + (unit ? unit.emoji : "＋") + '</button>';
      }
    }
    matrix.innerHTML = html;
    renderFormationCatalog();
  }

  function showUnitPicker(cellIndex) {
    runtime.pickerCell = cellIndex;
    $("#unitPickerList").innerHTML = '<button class="picker-unit clear" data-picker-unit="">CLEAR THIS SPACE</button>' + state.units.map(function (unit) {
      return '<button class="picker-unit" data-picker-unit="' + unit.id + '"><span class="emoji">' + unit.emoji + '</span><span><strong>' + escapeHtml(unit.name) + '</strong><small>' + unit.health + ' HP · ' + unit.attack + ' ATK · ' + unit.defense + ' DEF · ' + unit.speed + ' SPD</small></span></button>';
    }).join("");
    $("#formationDrawer .formation-layout").classList.add("picker-open");
    $("#unitPicker").classList.remove("hidden");
  }

  function assignFormationCell(unitId) {
    var formation = getFormation(runtime.activeFormationId);
    if (!formation || runtime.pickerCell < 0) return;
    var row = Math.floor(runtime.pickerCell / formation.cols);
    var col = runtime.pickerCell % formation.cols;
    formation.slots = formation.slots.filter(function (s) { return s.row !== row || s.col !== col; });
    if (unitId) formation.slots.push(slot(row, col, unitId));
    renderFormationMatrix();
    $("#formationDrawer .formation-layout").classList.remove("picker-open");
    $("#unitPicker").classList.add("hidden");
    persistLocal();
  }

  function resizeFormation() {
    var formation = getFormation(runtime.activeFormationId);
    if (!formation) return;
    var rows = clamp(Number($("#matrixRows").value) || 3, 1, 9);
    var cols = clamp(Number($("#matrixCols").value) || 3, 1, 9);
    formation.rows = rows; formation.cols = cols;
    formation.slots = formation.slots.filter(function (s) { return s.row < rows && s.col < cols; });
    renderFormationMatrix();
    persistLocal();
  }

  function renderSpellCatalog() {
    $("#spellCatalog").innerHTML = state.spells.map(function (spell) {
      return '<button class="formation-card ' + (spell.id === runtime.activeSpellId ? "active" : "") + '" data-spell="' + spell.id + '"><strong>' + spell.emoji + " " + escapeHtml(spell.name) + '</strong><small>' + spell.size + " × " + spell.size + ' · ' + spell.origin + ' origin</small></button>';
    }).join("");
  }

  function loadSpellForm(id) {
    var spell = getSpell(id) || state.spells[0];
    if (!spell) return;
    runtime.activeSpellId = spell.id;
    $("#spellName").value = spell.name;
    $("#spellId").textContent = spell.id;
    $("#spellEmoji").value = spell.emoji;
    $("#spellEmojiPreview").textContent = spell.emoji;
    $("#spellOrigin").value = spell.origin;
    $("#spellColor").value = spell.color;
    $("#spellDuration").value = spell.duration;
    $("#spellExpansion").value = spell.expansion;
    $("#spellDamage").value = spell.damage;
    $("#spellSize").value = spell.size;
    renderSpellMatrix();
    renderSpellCatalog();
  }

  function renderSpellMatrix() {
    var spell = getSpell(runtime.activeSpellId);
    if (!spell) return;
    var matrix = $("#spellMatrix");
    matrix.style.setProperty("--spell-color", spell.color);
    matrix.style.gridTemplateColumns = "repeat(" + spell.size + ", minmax(28px,1fr))";
    var selected = {};
    spell.cells.forEach(function (index) { selected[index] = true; });
    var html = "";
    for (var i = 0; i < spell.size * spell.size; i++) html += '<button type="button" class="spell-cell ' + (selected[i] ? "on" : "") + '" data-spell-cell="' + i + '">' + (selected[i] ? spell.emoji : "") + '</button>';
    matrix.innerHTML = html;
  }

  function saveSpellForm(event) {
    event.preventDefault();
    var spell = getSpell(runtime.activeSpellId);
    if (!spell) return;
    spell.name = $("#spellName").value.trim() || "Untitled Rune";
    spell.emoji = $("#spellEmoji").value;
    spell.origin = $("#spellOrigin").value;
    spell.color = $("#spellColor").value;
    spell.duration = Number($("#spellDuration").value) || 2;
    spell.expansion = Number($("#spellExpansion").value) || 1;
    spell.damage = Number($("#spellDamage").value) || 0;
    $("#spellEmojiPreview").textContent = spell.emoji;
    renderSpellCatalog();
    renderSpellMatrix();
    persistLocal();
    toast("SPELL SAVED");
  }

  function resizeSpellGrid() {
    var spell = getSpell(runtime.activeSpellId);
    if (!spell) return;
    spell.size = clamp(Number($("#spellSize").value) || 5, 3, 9);
    spell.cells = [Math.floor(spell.size * spell.size / 2)];
    renderSpellMatrix();
  }

  function ensureProjectShape() {
    if (!Array.isArray(state.buildingTypes) || !state.buildingTypes.length) state.buildingTypes = clone(BUILDING_DEFAULTS);
    state.buildingTypes.forEach(function (building) {
      building.cost = Object.assign({ food: 0, wood: 0, gold: 0 }, building.cost || {});
      building.width = Number(building.width) || 58;
      building.height = Number(building.height) || 46;
    });
    if (!Array.isArray(state.buildingComplexes) || !state.buildingComplexes.length) state.buildingComplexes = createBuildingComplexes();
    if (!state.buildingComplexes.some(function (complex) { return complex.id === runtime.activeComplexId; })) runtime.activeComplexId = state.buildingComplexes[0].id;
    if (!state.buildingTypes.some(function (building) { return building.id === runtime.activeBuildingTypeId; })) runtime.activeBuildingTypeId = state.buildingTypes[0].id;
  }

  function activeComplex() { return getBuildingComplex(runtime.activeComplexId) || state.buildingComplexes[0]; }
  function selectedPlannedBuilding() {
    var complex = activeComplex();
    return complex && complex.items.find(function (item) { return item.id === runtime.selectedPlannedBuildingId; });
  }

  function renderBuildingPlanner() {
    ensureProjectShape();
    renderComplexCatalog();
    renderBuildingTypeCatalog();
    loadBuildingTypeForm(runtime.activeBuildingTypeId);
    renderComplexCanvas();
  }

  function renderComplexCatalog() {
    $("#complexCatalog").innerHTML = state.buildingComplexes.map(function (complex) {
      return '<button class="complex-card ' + (complex.id === runtime.activeComplexId ? "active" : "") + '" data-complex="' + complex.id + '"><b>' + complex.items.length + '</b><span><strong>' + escapeHtml(complex.name) + '</strong><small>Priority ' + complex.defaultPriority + ' · freeform plan</small></span></button>';
    }).join("");
  }

  function renderBuildingTypeCatalog() {
    $("#buildingTypeCatalog").innerHTML = state.buildingTypes.map(function (building) {
      var cost = ["food","wood","gold"].filter(function (key) { return building.cost[key] > 0; }).map(function (key) { return building.cost[key] + " " + key[0].toUpperCase(); }).join(" · ") || "FREE";
      return '<div class="building-type-card ' + (building.id === runtime.activeBuildingTypeId ? "active" : "") + '" draggable="true" data-building-type="' + building.id + '"><button type="button" class="type-main" data-select-building-type="' + building.id + '"><span>' + building.emoji + '</span><strong>' + escapeHtml(building.name) + '</strong><small>' + cost + '</small></button><button type="button" class="type-add" data-add-building="' + building.id + '" title="Add to complex">＋</button></div>';
    }).join("");
  }

  function renderComplexCanvas() {
    var complex = activeComplex();
    if (!complex) return;
    $("#complexName").value = complex.name;
    $("#complexDefaultPriority").value = String(complex.defaultPriority || 3);
    $("#complexCanvas").innerHTML = complex.items.map(function (item) {
      var building = getBuildingType(item.buildingTypeId);
      if (!building) return "";
      var width = clamp(building.width || 58, 38, 120);
      var height = clamp(building.height || 46, 34, 100);
      return '<div class="planned-building ' + (item.id === runtime.selectedPlannedBuildingId ? "selected" : "") + '" data-planned-building="' + item.id + '" style="left:calc(' + (item.x / 640 * 100) + '% - ' + (width / 2) + 'px);top:calc(' + (item.y / 420 * 100) + '% - ' + (height / 2) + 'px);width:' + width + 'px;height:' + height + 'px;transform:rotate(' + (item.rotation || 0) + 'deg)"><i class="rotation-mark"></i><span class="planned-emoji">' + building.emoji + '</span><small class="planned-name">' + escapeHtml(building.name) + '</small><b class="priority-badge">' + (item.priority || complex.defaultPriority || 3) + '</b></div>';
    }).join("");
    updatePlannedInspector();
    updateComplexCost();
    renderComplexCatalog();
  }

  function updatePlannedInspector() {
    var item = selectedPlannedBuilding();
    var building = item ? getBuildingType(item.buildingTypeId) : null;
    $("#placedBuildingInspector").classList.toggle("has-selection", !!item);
    $("#placedBuildingInspector > span").textContent = building ? building.emoji + " " + building.name.toUpperCase() + " · " + (item.rotation || 0) + "°" : "SELECT A BUILDING IN THE PLAN";
    $("#plannedBuildingPriority").disabled = !item;
    $("#rotateBuildingLeft").disabled = !item;
    $("#rotateBuildingRight").disabled = !item;
    $("#removePlannedBuilding").disabled = !item;
    if (item) $("#plannedBuildingPriority").value = String(item.priority || 3);
  }

  function updateComplexCost() {
    var complex = activeComplex();
    var total = { food: 0, wood: 0, gold: 0 };
    if (complex) complex.items.forEach(function (item) {
      var building = getBuildingType(item.buildingTypeId);
      if (!building) return;
      ["food","wood","gold"].forEach(function (key) { total[key] += Number(building.cost[key]) || 0; });
    });
    $("#complexCost").textContent = total.food + " FOOD · " + total.wood + " WOOD · " + total.gold + " GOLD";
  }

  function addBuildingToComplex(buildingTypeId, designX, designY) {
    var complex = activeComplex();
    var building = getBuildingType(buildingTypeId);
    if (!complex || !building) return;
    var item = {
      id: uid("PLAN"), buildingTypeId: building.id,
      x: clamp(designX == null ? 320 + (complex.items.length % 4) * 18 : designX, 35, 605),
      y: clamp(designY == null ? 210 + (complex.items.length % 3) * 18 : designY, 35, 385),
      rotation: 0, priority: complex.defaultPriority || 3
    };
    complex.items.push(item);
    runtime.selectedPlannedBuildingId = item.id;
    renderComplexCanvas();
    persistLocal();
  }

  function loadBuildingTypeForm(id) {
    var building = getBuildingType(id) || state.buildingTypes[0];
    if (!building) return;
    runtime.activeBuildingTypeId = building.id;
    $("#buildingTypeName").value = building.name;
    $("#buildingTypeEmoji").value = building.emoji;
    $("#buildingTypeId").textContent = building.id;
    $("#buildingTypeUse").value = building.use || "";
    $("#buildingTypeHp").value = building.hp;
    $("#buildingTypeWidth").value = building.width;
    $("#buildingTypeHeight").value = building.height;
    $("#buildingCostFood").value = building.cost.food || 0;
    $("#buildingCostWood").value = building.cost.wood || 0;
    $("#buildingCostGold").value = building.cost.gold || 0;
    renderBuildingTypeCatalog();
  }

  function saveBuildingType(event) {
    event.preventDefault();
    var building = getBuildingType(runtime.activeBuildingTypeId);
    if (!building) return;
    building.name = $("#buildingTypeName").value.trim() || "Unnamed Building";
    building.emoji = $("#buildingTypeEmoji").value.trim() || "🏠";
    building.use = $("#buildingTypeUse").value.trim();
    building.hp = Math.max(1, Number($("#buildingTypeHp").value) || 100);
    building.width = clamp(Number($("#buildingTypeWidth").value) || 58, 24, 220);
    building.height = clamp(Number($("#buildingTypeHeight").value) || 46, 24, 220);
    building.cost = {
      food: Math.max(0, Number($("#buildingCostFood").value) || 0),
      wood: Math.max(0, Number($("#buildingCostWood").value) || 0),
      gold: Math.max(0, Number($("#buildingCostGold").value) || 0)
    };
    renderBuildingPlanner();
    renderBuildings();
    persistLocal();
    toast("BUILDING TYPE SAVED");
  }

  function bindComplexCanvasDragging() {
    var workbench = $("#complexCanvas");
    var drag = null;
    workbench.addEventListener("pointerdown", function (event) {
      var element = event.target.closest("[data-planned-building]");
      if (!element) return;
      var complex = activeComplex();
      var item = complex.items.find(function (candidate) { return candidate.id === element.dataset.plannedBuilding; });
      if (!item) return;
      runtime.selectedPlannedBuildingId = item.id;
      var rect = workbench.getBoundingClientRect();
      drag = { item: item, pointerId: event.pointerId, rect: rect };
      workbench.setPointerCapture(event.pointerId);
      event.preventDefault();
      renderComplexCanvas();
    });
    workbench.addEventListener("pointermove", function (event) {
      if (!drag || drag.pointerId !== event.pointerId) return;
      drag.item.x = clamp((event.clientX - drag.rect.left) / drag.rect.width * 640, 25, 615);
      drag.item.y = clamp((event.clientY - drag.rect.top) / drag.rect.height * 420, 25, 395);
      var element = workbench.querySelector('[data-planned-building="' + drag.item.id + '"]');
      if (element) {
        var building = getBuildingType(drag.item.buildingTypeId);
        var width = clamp(building.width || 58, 38, 120);
        var height = clamp(building.height || 46, 34, 100);
        element.style.left = "calc(" + (drag.item.x / 640 * 100) + "% - " + (width / 2) + "px)";
        element.style.top = "calc(" + (drag.item.y / 420 * 100) + "% - " + (height / 2) + "px)";
      }
    });
    workbench.addEventListener("pointerup", function (event) {
      if (!drag || drag.pointerId !== event.pointerId) return;
      try { workbench.releasePointerCapture(event.pointerId); } catch (error) {}
      drag = null;
      renderComplexCanvas();
      persistLocal();
    });
    workbench.addEventListener("dragover", function (event) { event.preventDefault(); });
    workbench.addEventListener("drop", function (event) {
      event.preventDefault();
      var typeId = event.dataTransfer.getData("text/fsg-building-type");
      var rect = workbench.getBoundingClientRect();
      addBuildingToComplex(typeId, (event.clientX - rect.left) / rect.width * 640, (event.clientY - rect.top) / rect.height * 420);
    });
  }

  function bindDraggablePanels() {
    var stage = $("#battleStage");
    var stored = {};
    try { stored = JSON.parse(localStorage.getItem("fsg-rts-ui-layout") || "{}"); } catch (error) {}

    function placeStored(panel) {
      var saved = stored[panel.dataset.draggablePanel];
      if (!saved) return;
      var maxLeft = Math.max(0, stage.clientWidth - panel.offsetWidth);
      var maxTop = Math.max(0, stage.clientHeight - panel.offsetHeight);
      panel.style.left = clamp(saved.x * maxLeft, 0, maxLeft) + "px";
      panel.style.top = clamp(saved.y * maxTop, 0, maxTop) + "px";
      panel.style.right = "auto";
      panel.style.bottom = "auto";
      panel.style.transform = "none";
    }

    $$(".draggable-panel").forEach(function (panel) {
      placeStored(panel);
      panel.addEventListener("pointerdown", function (event) {
        if (!event.target.closest(".drag-handle") && panel.id !== "selectionCard") return;
        if (event.target.closest("button, canvas, input, select")) return;
        var stageRect = stage.getBoundingClientRect();
        var panelRect = panel.getBoundingClientRect();
        var offsetX = event.clientX - panelRect.left;
        var offsetY = event.clientY - panelRect.top;
        panel.style.left = (panelRect.left - stageRect.left) + "px";
        panel.style.top = (panelRect.top - stageRect.top) + "px";
        panel.style.right = "auto";
        panel.style.bottom = "auto";
        panel.style.transform = "none";
        panel.setPointerCapture(event.pointerId);

        var move = function (moveEvent) {
          var maxLeft = Math.max(0, stage.clientWidth - panel.offsetWidth);
          var maxTop = Math.max(0, stage.clientHeight - panel.offsetHeight);
          panel.style.left = clamp(moveEvent.clientX - stageRect.left - offsetX, 0, maxLeft) + "px";
          panel.style.top = clamp(moveEvent.clientY - stageRect.top - offsetY, 0, maxTop) + "px";
        };
        var up = function (upEvent) {
          panel.removeEventListener("pointermove", move);
          panel.removeEventListener("pointerup", up);
          try { panel.releasePointerCapture(upEvent.pointerId); } catch (error) {}
          var maxLeft = Math.max(1, stage.clientWidth - panel.offsetWidth);
          var maxTop = Math.max(1, stage.clientHeight - panel.offsetHeight);
          stored[panel.dataset.draggablePanel] = {
            x: clamp(parseFloat(panel.style.left) / maxLeft, 0, 1),
            y: clamp(parseFloat(panel.style.top) / maxTop, 0, 1)
          };
          localStorage.setItem("fsg-rts-ui-layout", JSON.stringify(stored));
        };
        panel.addEventListener("pointermove", move);
        panel.addEventListener("pointerup", up);
        event.preventDefault();
      });
    });
    window.addEventListener("resize", function () { $$(".draggable-panel").forEach(placeStored); });
  }

  function persistLocal() {
    try {
      var saved = {
        project: state,
        placedBuildings: runtime.buildings.filter(function (b) { return b.team === "black"; }),
        constructionQueue: runtime.constructionQueue
      };
      localStorage.setItem("fsg-rts-project", JSON.stringify(saved));
      $("#saveState").textContent = "LOCAL SAVED";
    } catch (error) {
      $("#saveState").textContent = "LOCAL FULL";
    }
  }

  function restoreLocal() {
    try {
      var value = localStorage.getItem("fsg-rts-project");
      if (!value) return false;
      var saved = JSON.parse(value);
      if (!saved.project || !saved.project.units || !saved.project.formations) return false;
      state = saved.project;
      ensureProjectShape();
      runtime.activeUnitId = state.units[0].id;
      runtime.activeTierId = state.units[0].activeTierId;
      runtime.activeFormationId = state.formations[0].id;
      runtime.activeSpellId = state.spells[0].id;
      runtime.activeComplexId = state.buildingComplexes[0].id;
      runtime.activeBuildingTypeId = state.buildingTypes[0].id;
      initializeWorld();
      if (saved.placedBuildings) {
        runtime.buildings = runtime.buildings.filter(function (b) { return b.team === "white"; }).concat(saved.placedBuildings);
      }
      runtime.constructionQueue = Array.isArray(saved.constructionQueue) ? saved.constructionQueue : [];
      updateConstructionQueueChip();
      return true;
    } catch (error) { return false; }
  }

  function projectPayload() {
    return {
      projectId: state.projectId,
      projectName: state.projectName,
      schemaVersion: state.schemaVersion,
      units: state.units,
      formations: state.formations,
      spells: state.spells,
      buildingTypes: state.buildingTypes,
      buildingComplexes: state.buildingComplexes,
      resources: state.resources,
      research: state.research,
      economy: state.economy,
      buildings: runtime.buildings.filter(function (b) { return b.team === "black"; }),
      constructionQueue: runtime.constructionQueue
    };
  }

  async function api(action, options) {
    var actionParts = String(action).split("&");
    var query = "action=" + encodeURIComponent(actionParts.shift());
    if (actionParts.length) query += "&" + actionParts.join("&");
    var response = await fetch("app.php?" + query, Object.assign({
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", "Accept": "application/json" }
    }, options || {}));
    var data = await response.json().catch(function () { return { ok: false, error: "The server returned an unreadable response." }; });
    if (!response.ok || data.ok === false) throw new Error(data.error || "Server request failed.");
    return data;
  }

  async function saveCloud() {
    var button = $("#cloudSaveButton");
    button.disabled = true; button.textContent = "SAVING…";
    try {
      await api("save", { method: "POST", body: JSON.stringify({ project: projectPayload() }) });
      $("#saveState").textContent = "MYSQL SAVED";
      toast("REALM SAVED TO MYSQL");
    } catch (error) {
      toast(error.message.toUpperCase());
      $("#saveState").textContent = "LOCAL ONLY";
    } finally {
      button.disabled = false; button.textContent = "SAVE REALM";
    }
  }

  async function showCloudLoads() {
    openDrawer("#loadDialog");
    $("#savedRealmList").innerHTML = "<p>Reading saved realms…</p>";
    try {
      var data = await api("list", { method: "GET" });
      $("#savedRealmList").innerHTML = data.projects.length ? data.projects.map(function (project) {
        return '<div class="saved-realm"><span><strong>' + escapeHtml(project.name) + '</strong><small>' + escapeHtml(project.projectId) + ' · updated ' + escapeHtml(project.updatedAt) + '</small></span><button data-load-realm="' + project.projectId + '">LOAD</button></div>';
      }).join("") : "<p>No server saves yet. Save this realm first.</p>";
    } catch (error) {
      $("#savedRealmList").innerHTML = "<p>" + escapeHtml(error.message) + "</p>";
    }
  }

  async function loadCloud(projectId) {
    try {
      var data = await api("load&projectId=" + encodeURIComponent(projectId), { method: "GET" });
      state = data.project;
      ensureProjectShape();
      runtime.activeUnitId = state.units[0].id;
      runtime.activeTierId = state.units[0].activeTierId;
      runtime.activeFormationId = state.formations[0].id;
      runtime.activeSpellId = state.spells[0].id;
      runtime.activeComplexId = state.buildingComplexes[0].id;
      runtime.activeBuildingTypeId = state.buildingTypes[0].id;
      initializeWorld();
      if (state.buildings) runtime.buildings = runtime.buildings.filter(function (b) { return b.team === "white"; }).concat(state.buildings);
      runtime.constructionQueue = Array.isArray(state.constructionQueue) ? state.constructionQueue : [];
      updateConstructionQueueChip();
      refreshAllUI();
      persistLocal();
      closeDrawers();
      toast("SAVED REALM LOADED");
    } catch (error) { toast(error.message.toUpperCase()); }
  }

  function refreshAllUI() {
    renderBuildings();
    renderArmyList();
    renderResearch();
    renderPowers();
    updateResourceUI();
    renderUnitCatalog();
    loadUnitForm(runtime.activeUnitId);
    renderFormationMatrix();
    loadSpellForm(runtime.activeSpellId);
    renderBuildingPlanner();
    updateSelectionUI();
  }

  function bindBattlefield() {
    canvas.addEventListener("pointerdown", function (event) {
      if (event.button === 2) return;
      var rect = canvas.getBoundingClientRect();
      var point = { x: event.clientX - rect.left, y: event.clientY - rect.top };
      var worldPoint = toWorld(point.x, point.y);
      if (runtime.buildMode) { placeBuilding(runtime.buildMode, worldPoint); return; }
      if (runtime.activePower) { usePower(runtime.activePower, worldPoint); return; }
      if (runtime.complexPlacement) {
        runtime.complexPlacement.start = worldPoint;
        runtime.complexPlacement.current = worldPoint;
        canvas.setPointerCapture(event.pointerId);
        return;
      }
      var complexHit = runtime.buildings.concat(runtime.constructionQueue).filter(function (building) {
        return building.team === "black" && building.groupId && Math.hypot(building.x - worldPoint.x, building.y - worldPoint.y) < 85;
      }).sort(function (a, b) { return distance(a, worldPoint) - distance(b, worldPoint); })[0];
      if (complexHit) {
        runtime.selectedComplexGroupId = complexHit.groupId;
        runtime.draggingComplex = { groupId: complexHit.groupId, last: worldPoint };
        canvas.setPointerCapture(event.pointerId);
        canvas.classList.add("dragging");
        return;
      }
      var nearest = runtime.companies.filter(function (c) { return c.team === "black" && companyFighters(c).length; }).sort(function (a,b) { return distance(a,worldPoint)-distance(b,worldPoint); })[0];
      if (nearest && distance(nearest, worldPoint) < 110) {
        selectCompany(nearest.id);
        return;
      }
      runtime.dragging = true;
      runtime.dragStart = point;
      runtime.lastPointer = point;
      canvas.setPointerCapture(event.pointerId);
      canvas.classList.add("dragging");
    });
    canvas.addEventListener("pointermove", function (event) {
      var rect = canvas.getBoundingClientRect();
      var point = { x: event.clientX - rect.left, y: event.clientY - rect.top };
      var worldPoint = toWorld(point.x, point.y);
      if (runtime.complexPlacement && runtime.complexPlacement.start) {
        runtime.complexPlacement.current = worldPoint;
        return;
      }
      if (runtime.draggingComplex) {
        var dx = worldPoint.x - runtime.draggingComplex.last.x;
        var dy = worldPoint.y - runtime.draggingComplex.last.y;
        complexGroupMembers(runtime.draggingComplex.groupId).forEach(function (building) {
          building.x = clamp(building.x + dx, 20, runtime.world.width - 20);
          building.y = clamp(building.y + dy, 20, runtime.world.height - 20);
        });
        runtime.draggingComplex.last = worldPoint;
        return;
      }
      if (!runtime.dragging) return;
      runtime.camera.x -= (point.x - runtime.lastPointer.x) / runtime.camera.zoom;
      runtime.camera.y -= (point.y - runtime.lastPointer.y) / runtime.camera.zoom;
      runtime.camera.x = clamp(runtime.camera.x, 0, runtime.world.width);
      runtime.camera.y = clamp(runtime.camera.y, 0, runtime.world.height);
      runtime.lastPointer = point;
    });
    canvas.addEventListener("pointerup", function (event) {
      if (runtime.complexPlacement && runtime.complexPlacement.start) {
        var complex = getBuildingComplex(runtime.complexPlacement.complexId);
        queueBuildingComplex(complex, runtime.complexPlacement.start, runtime.complexPlacement.current || runtime.complexPlacement.start);
        try { canvas.releasePointerCapture(event.pointerId); } catch (error) {}
        return;
      }
      if (runtime.draggingComplex) {
        runtime.draggingComplex = null;
        canvas.classList.remove("dragging");
        persistLocal();
        toast("BUILDING COMPLEX MOVED");
        try { canvas.releasePointerCapture(event.pointerId); } catch (error) {}
        return;
      }
      runtime.dragging = false;
      canvas.classList.remove("dragging");
      try { canvas.releasePointerCapture(event.pointerId); } catch (error) {}
    });
    canvas.addEventListener("contextmenu", function (event) {
      event.preventDefault();
      var company = selectedCompany();
      if (!company) return;
      var rect = canvas.getBoundingClientRect();
      var position = toWorld(event.clientX - rect.left, event.clientY - rect.top);
      company.targetX = clamp(position.x, 0, runtime.world.width);
      company.targetY = clamp(position.y, 0, runtime.world.height);
      company.halted = false;
      addEvent(company.name + " receives a new march order.");
    });
    canvas.addEventListener("wheel", function (event) {
      event.preventDefault();
      var before = toWorld(event.offsetX, event.offsetY);
      runtime.camera.zoom = clamp(runtime.camera.zoom * (event.deltaY > 0 ? .9 : 1.1), .38, 1.65);
      var after = toWorld(event.offsetX, event.offsetY);
      runtime.camera.x += before.x - after.x;
      runtime.camera.y += before.y - after.y;
      $("#zoomLabel").textContent = Math.round(runtime.camera.zoom * 100) + "%";
    }, { passive: false });
    minimap.addEventListener("pointerdown", function (event) {
      var rect = minimap.getBoundingClientRect();
      runtime.camera.x = (event.clientX - rect.left) / rect.width * runtime.world.width;
      runtime.camera.y = (event.clientY - rect.top) / rect.height * runtime.world.height;
    });
  }

  function bindUI() {
    $$(".rail-tabs button").forEach(function (button) {
      button.addEventListener("click", function () {
        $$(".rail-tabs button").forEach(function (b) { b.classList.toggle("active", b === button); });
        ["build","army","research"].forEach(function (tab) { $("#" + tab + "Panel").classList.toggle("hidden", tab !== button.dataset.railTab); });
        if (button.dataset.railTab === "army") renderArmyList();
      });
    });
    $("#buildingList").addEventListener("click", function (event) {
      var button = event.target.closest("[data-building]");
      if (!button) return;
      runtime.buildMode = runtime.buildMode === button.dataset.building ? null : button.dataset.building;
      runtime.activePower = null;
      $$(".blueprint").forEach(function (b) { b.classList.toggle("selected", b.dataset.building === runtime.buildMode); });
      canvas.classList.toggle("targeting", !!runtime.buildMode);
      if (runtime.buildMode) toast("CLICK THE MAP TO PLACE " + button.textContent.trim().toUpperCase());
    });
    $("#armyList").addEventListener("click", function (event) {
      var row = event.target.closest("[data-company]");
      if (row) selectCompany(row.dataset.company);
    });
    $("#researchList").addEventListener("click", function (event) {
      var button = event.target.closest("[data-research]");
      if (button) performResearch(button.dataset.research);
    });
    $("#powerList").addEventListener("click", function (event) {
      var button = event.target.closest("[data-power]");
      if (!button || button.classList.contains("cooling")) return;
      runtime.activePower = runtime.activePower === button.dataset.power ? null : button.dataset.power;
      runtime.buildMode = null;
      canvas.classList.toggle("targeting", !!runtime.activePower);
      updatePowerButtons();
      if (runtime.activePower) toast("CLICK THE BATTLEFIELD TO CAST");
    });
    setInterval(updatePowerButtons, 250);

    $("#pauseButton").addEventListener("click", function () {
      runtime.paused = !runtime.paused;
      this.textContent = runtime.paused ? "▶" : "Ⅱ";
      toast(runtime.paused ? "BATTLE PAUSED" : "BATTLE RESUMED");
    });
    $("#eraButton").addEventListener("click", function () {
      var cost = { food: 350, gold: 250 };
      if (!canAfford(cost)) { toast("ADVANCING REQUIRES 350 FOOD AND 250 GOLD"); return; }
      if (state.economy.era >= 4) { toast("FINAL ERA ALREADY REACHED"); return; }
      spend(cost); state.economy.era++; $(".commander-card small").textContent = "Era " + state.economy.era + (state.economy.era === 3 ? " · Castle" : " · Imperial"); addEvent("The Ashen Host advances to Era " + state.economy.era + ".");
    });
    $("#reinforceButton").addEventListener("click", function () {
      var company = selectedCompany();
      if (!company) return;
      var formation = getFormation(company.formationId);
      if (!canAfford({food:80,gold:25})) { toast("REINFORCEMENTS NEED 80 FOOD AND 25 GOLD"); return; }
      spend({food:80,gold:25});
      formation.slots.slice(0, 4).forEach(function (s) {
        var unit = getUnit(s.unitId); var stats = tiered(unit);
        runtime.soldiers.push({id:uid("FTR"),companyId:company.id,team:"black",unitId:unit.id,x:company.x,y:company.y,offsetX:(s.col-(formation.cols-1)/2)*27,offsetY:(s.row-(formation.rows-1)/2)*27,hp:stats.health,maxHp:stats.health,cooldown:0,frozenUntil:0,poisonUntil:0,burnUntil:0,flash:0});
      });
      addEvent("Four fighters reinforce " + company.name + ".");
      renderArmyList();
    });

    $("#prevFormation").addEventListener("click", function () { cycleCompanyFormation(-1); });
    $("#nextFormation").addEventListener("click", function () { cycleCompanyFormation(1); });
    $("#stanceControls").addEventListener("click", function (event) {
      var button = event.target.closest("[data-stance]");
      var company = selectedCompany();
      if (!button || !company) return;
      company.stance = button.dataset.stance;
      company.halted = company.stance === "ground";
      updateSelectionUI();
    });
    $("#stopCommand").addEventListener("click", function () { var c=selectedCompany(); if(c){c.halted=true;c.targetX=c.x;c.targetY=c.y;addEvent(c.name+" stands fast.");} });
    $("#patrolCommand").addEventListener("click", function () { var c=selectedCompany(); if(c){c.patrol=!c.patrol;c.halted=false;toast(c.patrol?"PATROL ENABLED":"PATROL DISABLED");} });
    $("#focusCommand").addEventListener("click", function () { var c=selectedCompany(); if(c){c.stance="chase";c.halted=false;updateSelectionUI();toast("FORMATION WILL SEEK NEAREST ENEMY");} });
    $("#disbandCommand").addEventListener("click", function () { var c=selectedCompany(); if(c && confirm("Disband " + c.name + "?")){runtime.soldiers.forEach(function(f){if(f.companyId===c.id)f.hp=0;});addEvent(c.name+" is disbanded.");} });

    var dock = $("#commandDock");
    var dockToggle = $("#formationCommandToggle");
    var setDockOpen = function (open) {
      dock.classList.toggle("open", open);
      dockToggle.classList.toggle("active", open);
      dockToggle.setAttribute("aria-expanded", open ? "true" : "false");
    };
    dockToggle.addEventListener("click", function () { setDockOpen(!dock.classList.contains("open")); });
    $("#closeCommandDock").addEventListener("click", function () { setDockOpen(false); });

    $("#unitDesignerButton").addEventListener("click", function () { openDrawer("#unitDrawer"); loadUnitForm(runtime.activeUnitId); });
    $("#formationDesignerButton").addEventListener("click", function () { openDrawer("#formationDrawer"); renderFormationMatrix(); });
    $("#spellDesignerButton").addEventListener("click", function () { openDrawer("#spellDrawer"); loadSpellForm(runtime.activeSpellId); });
    $("#buildingPlannerButton").addEventListener("click", function () { openDrawer("#buildingPlannerDrawer"); renderBuildingPlanner(); });
    $("#modalBackdrop").addEventListener("click", closeDrawers);
    $$("[data-close-drawer]").forEach(function (button) { button.addEventListener("click", closeDrawers); });
    document.addEventListener("keydown", function (event) { if (event.key === "Escape") { runtime.activePower=null;runtime.buildMode=null;runtime.complexPlacement=null;runtime.draggingComplex=null;canvas.classList.remove("targeting");closeDrawers(); } });

    $("#unitCatalog").addEventListener("click", function (event) { var item=event.target.closest("[data-unit]");if(item)loadUnitForm(item.dataset.unit); });
    $("#unitSearch").addEventListener("input", function () { renderUnitCatalog(this.value); });
    $("#unitEmoji").addEventListener("change", function () { $("#unitEmojiPreview").textContent=this.value; });
    $("#projectileEnabled").addEventListener("change", function () { $(".projectile-section").classList.toggle("disabled", !this.checked); });
    $("#unitForm").addEventListener("submit", saveUnitForm);
    $("#newUnitButton").addEventListener("click", function () {
      var unit={id:uid("UNIT"),name:"New Fighter",emoji:"⚔️",description:"A newly forged unit type.",health:100,attack:12,defense:5,speed:2,range:28,rate:1,focus:"melee",stance:"chase",role:"Infantry",projectile:{enabled:false,emoji:"•",color:"#d7c08a",speed:12},tiers:[{id:uid("TIER"),name:"Standard",health:1,attack:1,speed:1}],activeTierId:null};
      unit.activeTierId=unit.tiers[0].id;state.units.push(unit);runtime.activeUnitId=unit.id;loadUnitForm(unit.id);toast("NEW UNIT TYPE CREATED");
    });
    $("#regenerateUnitId").addEventListener("click", function () { var unit=getUnit(runtime.activeUnitId);if(unit){var old=unit.id;unit.id=uid("UNIT");state.formations.forEach(function(f){f.slots.forEach(function(s){if(s.unitId===old)s.unitId=unit.id;});});runtime.soldiers.forEach(function(s){if(s.unitId===old)s.unitId=unit.id;});runtime.activeUnitId=unit.id;$("#unitId").textContent=unit.id;} });
    $("#deleteUnitButton").addEventListener("click", function () {
      if(state.units.length<=1){toast("AT LEAST ONE UNIT TYPE IS REQUIRED");return;}
      var unit=getUnit(runtime.activeUnitId);if(!unit||!confirm("Delete "+unit.name+"?"))return;
      var replacement=state.units.find(function(u){return u.id!==unit.id;});state.formations.forEach(function(f){f.slots.forEach(function(s){if(s.unitId===unit.id)s.unitId=replacement.id;});});state.units=state.units.filter(function(u){return u.id!==unit.id;});runtime.activeUnitId=replacement.id;loadUnitForm(replacement.id);persistLocal();
    });
    $("#tierSelect").addEventListener("change", function () { syncTierFields();runtime.activeTierId=this.value;loadTierFields(getUnit(runtime.activeUnitId)); });
    $("#addTierButton").addEventListener("click", function () { syncTierFields();var unit=getUnit(runtime.activeUnitId);var tier={id:uid("TIER"),name:"New Tier",health:1,attack:1,speed:1};unit.tiers.push(tier);runtime.activeTierId=tier.id;renderTierSelect(unit);loadTierFields(unit); });
    $("#deleteTierButton").addEventListener("click", function () { var unit=getUnit(runtime.activeUnitId);if(!unit||unit.tiers.length<=1){toast("A UNIT NEEDS AT LEAST ONE TIER");return;}unit.tiers=unit.tiers.filter(function(t){return t.id!==runtime.activeTierId;});runtime.activeTierId=unit.tiers[0].id;renderTierSelect(unit);loadTierFields(unit); });

    $("#formationCatalog").addEventListener("click", function (event) { var item=event.target.closest("[data-formation]");if(item){runtime.activeFormationId=item.dataset.formation;renderFormationMatrix();} });
    $("#formationMatrix").addEventListener("click", function (event) { var cell=event.target.closest("[data-cell]");if(cell)showUnitPicker(Number(cell.dataset.cell)); });
    $("#unitPickerList").addEventListener("click", function (event) { var item=event.target.closest("[data-picker-unit]");if(item)assignFormationCell(item.dataset.pickerUnit); });
    $("#closeUnitPicker").addEventListener("click", function () { $("#formationDrawer .formation-layout").classList.remove("picker-open");$("#unitPicker").classList.add("hidden"); });
    $("#resizeMatrixButton").addEventListener("click", resizeFormation);
    $("#newFormationButton").addEventListener("click", function () { var f={id:uid("FORM"),name:"Fresh Formation",rows:5,cols:5,slots:[]};state.formations.push(f);runtime.activeFormationId=f.id;renderFormationMatrix(); });
    $("#duplicateFormationButton").addEventListener("click", function () { var source=getFormation(runtime.activeFormationId);if(!source)return;var copy=clone(source);copy.id=uid("FORM");copy.name=source.name+" Copy";state.formations.push(copy);runtime.activeFormationId=copy.id;renderFormationMatrix();persistLocal(); });
    $("#renameFormationButton").addEventListener("click", function () { var f=getFormation(runtime.activeFormationId);if(!f)return;var name=prompt("Formation name",f.name);if(name&&name.trim()){f.name=name.trim().slice(0,60);renderFormationMatrix();persistLocal();} });

    $("#spellCatalog").addEventListener("click", function (event) { var item=event.target.closest("[data-spell]");if(item)loadSpellForm(item.dataset.spell); });
    $("#spellEmoji").addEventListener("change", function () { $("#spellEmojiPreview").textContent=this.value; });
    $("#spellForm").addEventListener("submit", saveSpellForm);
    $("#generateSpellGrid").addEventListener("click", resizeSpellGrid);
    $("#spellMatrix").addEventListener("click", function (event) { var cell=event.target.closest("[data-spell-cell]");if(!cell)return;var spell=getSpell(runtime.activeSpellId);var index=Number(cell.dataset.spellCell);if(spell.cells.indexOf(index)>=0)spell.cells=spell.cells.filter(function(i){return i!==index;});else spell.cells.push(index);renderSpellMatrix(); });
    $("#newSpellButton").addEventListener("click", function () { var s={id:uid("SPELL"),name:"Untitled Rune",emoji:"✨",origin:"click",color:"#d9bc68",duration:2.5,expansion:1,damage:20,size:5,cells:[12]};state.spells.push(s);runtime.activeSpellId=s.id;loadSpellForm(s.id); });
    $("#deleteSpellButton").addEventListener("click", function () { if(state.spells.length<=1){toast("AT LEAST ONE SPELL IS REQUIRED");return;}var spell=getSpell(runtime.activeSpellId);if(spell&&confirm("Delete "+spell.name+"?")){state.spells=state.spells.filter(function(s){return s.id!==spell.id;});runtime.activeSpellId=state.spells[0].id;loadSpellForm(runtime.activeSpellId);persistLocal();} });

    $("#complexCatalog").addEventListener("click", function (event) {
      var card = event.target.closest("[data-complex]");
      if (!card) return;
      runtime.activeComplexId = card.dataset.complex;
      runtime.selectedPlannedBuildingId = null;
      renderComplexCanvas();
    });
    $("#complexName").addEventListener("change", function () {
      var complex = activeComplex();
      if (complex) { complex.name = this.value.trim() || "Untitled Complex"; renderComplexCatalog(); persistLocal(); }
    });
    $("#complexDefaultPriority").addEventListener("change", function () {
      var complex = activeComplex();
      if (complex) { complex.defaultPriority = Number(this.value) || 3; renderComplexCatalog(); persistLocal(); }
    });
    $("#newComplexButton").addEventListener("click", function () {
      var complex = { id: uid("COMPLEX"), name: "New Building Complex", defaultPriority: 3, items: [] };
      state.buildingComplexes.push(complex);
      runtime.activeComplexId = complex.id;
      runtime.selectedPlannedBuildingId = null;
      renderBuildingPlanner();
    });
    $("#duplicateComplexButton").addEventListener("click", function () {
      var source = activeComplex();
      if (!source) return;
      var copy = clone(source);
      copy.id = uid("COMPLEX");
      copy.name = source.name + " Copy";
      copy.items.forEach(function (item) { item.id = uid("PLAN"); });
      state.buildingComplexes.push(copy);
      runtime.activeComplexId = copy.id;
      runtime.selectedPlannedBuildingId = null;
      renderBuildingPlanner();
      persistLocal();
    });
    $("#deleteComplexButton").addEventListener("click", function () {
      var complex = activeComplex();
      if (!complex || state.buildingComplexes.length <= 1) { toast("AT LEAST ONE COMPLEX PLAN IS REQUIRED"); return; }
      if (!confirm("Delete " + complex.name + "?")) return;
      state.buildingComplexes = state.buildingComplexes.filter(function (item) { return item.id !== complex.id; });
      runtime.activeComplexId = state.buildingComplexes[0].id;
      runtime.selectedPlannedBuildingId = null;
      renderBuildingPlanner();
      persistLocal();
    });
    $("#buildingTypeCatalog").addEventListener("click", function (event) {
      var add = event.target.closest("[data-add-building]");
      if (add) { addBuildingToComplex(add.dataset.addBuilding); return; }
      var select = event.target.closest("[data-select-building-type]");
      if (select) loadBuildingTypeForm(select.dataset.selectBuildingType);
    });
    $("#buildingTypeCatalog").addEventListener("dragstart", function (event) {
      var card = event.target.closest("[data-building-type]");
      if (!card) return;
      event.dataTransfer.setData("text/fsg-building-type", card.dataset.buildingType);
      event.dataTransfer.effectAllowed = "copy";
    });
    $("#newBuildingTypeButton").addEventListener("click", function () {
      var building = { id: uid("BUILDING").toLowerCase(), name: "Custom Building", emoji: "🏠", use: "Describe this building's purpose.", hp: 500, width: 64, height: 52, cost: { food: 0, wood: 100, gold: 0 } };
      state.buildingTypes.push(building);
      runtime.activeBuildingTypeId = building.id;
      loadBuildingTypeForm(building.id);
      renderBuildings();
    });
    $("#buildingTypeForm").addEventListener("submit", saveBuildingType);
    $("#deleteBuildingTypeButton").addEventListener("click", function () {
      var building = getBuildingType(runtime.activeBuildingTypeId);
      if (!building || state.buildingTypes.length <= 1) { toast("AT LEAST ONE BUILDING TYPE IS REQUIRED"); return; }
      if (!confirm("Delete " + building.name + " from the library, complex plans, and battlefield?")) return;
      state.buildingTypes = state.buildingTypes.filter(function (item) { return item.id !== building.id; });
      state.buildingComplexes.forEach(function (complex) { complex.items = complex.items.filter(function (item) { return item.buildingTypeId !== building.id; }); });
      runtime.buildings = runtime.buildings.filter(function (item) { return item.type !== building.id; });
      runtime.constructionQueue = runtime.constructionQueue.filter(function (item) { return item.type !== building.id; });
      runtime.activeBuildingTypeId = state.buildingTypes[0].id;
      updateConstructionQueueChip();
      renderBuildingPlanner();
      renderBuildings();
      persistLocal();
    });
    $("#rotateBuildingLeft").addEventListener("click", function () { var item=selectedPlannedBuilding();if(item){item.rotation=((item.rotation||0)-15)%360;renderComplexCanvas();persistLocal();} });
    $("#rotateBuildingRight").addEventListener("click", function () { var item=selectedPlannedBuilding();if(item){item.rotation=((item.rotation||0)+15)%360;renderComplexCanvas();persistLocal();} });
    $("#plannedBuildingPriority").addEventListener("change", function () { var item=selectedPlannedBuilding();if(item){item.priority=Number(this.value)||3;renderComplexCanvas();persistLocal();} });
    $("#removePlannedBuilding").addEventListener("click", function () { var complex=activeComplex();var item=selectedPlannedBuilding();if(complex&&item){complex.items=complex.items.filter(function(candidate){return candidate.id!==item.id;});runtime.selectedPlannedBuildingId=null;renderComplexCanvas();persistLocal();} });
    $("#placeComplexButton").addEventListener("click", function () {
      var complex = activeComplex();
      if (!complex || !complex.items.length) { toast("ADD BUILDINGS TO THIS COMPLEX FIRST"); return; }
      runtime.complexPlacement = { complexId: complex.id, start: null, current: null };
      runtime.buildMode = null;
      runtime.activePower = null;
      closeDrawers();
      canvas.classList.add("targeting");
      toast("CLICK AND DRAG A FOOTPRINT FOR " + complex.name.toUpperCase());
    });
    bindComplexCanvasDragging();

    $("#cloudSaveButton").addEventListener("click", saveCloud);
    $("#cloudLoadButton").addEventListener("click", showCloudLoads);
    $("#savedRealmList").addEventListener("click", function (event) { var button=event.target.closest("[data-load-realm]");if(button)loadCloud(button.dataset.loadRealm); });
  }

  function init() {
    ensureProjectShape();
    populateEmojiSelect($("#unitEmoji"), UNIT_EMOJIS);
    populateEmojiSelect($("#projectileEmoji"), PROJECTILE_EMOJIS);
    populateEmojiSelect($("#spellEmoji"), SPELL_EMOJIS);
    renderBuildings();
    renderResearch();
    renderPowers();
    if (!restoreLocal()) initializeWorld();
    canvasSize();
    bindBattlefield();
    bindUI();
    refreshAllUI();
    requestAnimationFrame(bindDraggablePanels);
    window.addEventListener("resize", canvasSize);
    setInterval(function () { updateSelectionUI(); renderArmyList(); }, 1000);
    requestAnimationFrame(gameLoop);
  }

  init();
})();
