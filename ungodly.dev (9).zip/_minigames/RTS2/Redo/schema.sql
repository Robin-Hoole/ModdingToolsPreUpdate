-- Field & Sigil RTS
-- MySQL / MariaDB schema
-- Every application-owned table uses the required FSG_RTS_ prefix.

SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE IF NOT EXISTS FSG_RTS_Projects (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_key VARCHAR(96) NOT NULL,
    user_id BIGINT UNSIGNED NULL,
    project_id VARCHAR(128) NOT NULL,
    name VARCHAR(190) NOT NULL,
    schema_version VARCHAR(24) NOT NULL DEFAULT '1.0.0',
    snapshot_json LONGTEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_RTS_Projects_owner_project (owner_key, project_id),
    KEY idx_FSG_RTS_Projects_owner_updated (owner_key, updated_at),
    KEY idx_FSG_RTS_Projects_user_updated (user_id, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_RTS_UnitTypes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    project_db_id BIGINT UNSIGNED NOT NULL,
    unit_id VARCHAR(128) NOT NULL,
    name VARCHAR(190) NOT NULL,
    emoji VARCHAR(24) NOT NULL DEFAULT '',
    role_name VARCHAR(48) NOT NULL DEFAULT '',
    focus_mode VARCHAR(24) NOT NULL DEFAULT 'melee',
    data_json LONGTEXT NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_RTS_UnitTypes_project_unit (project_db_id, unit_id),
    KEY idx_FSG_RTS_UnitTypes_project_sort (project_db_id, sort_order),
    CONSTRAINT fk_FSG_RTS_UnitTypes_project
        FOREIGN KEY (project_db_id) REFERENCES FSG_RTS_Projects(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_RTS_Formations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    project_db_id BIGINT UNSIGNED NOT NULL,
    formation_id VARCHAR(128) NOT NULL,
    name VARCHAR(190) NOT NULL,
    row_count TINYINT UNSIGNED NOT NULL,
    column_count TINYINT UNSIGNED NOT NULL,
    slot_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    data_json LONGTEXT NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_RTS_Formations_project_formation (project_db_id, formation_id),
    KEY idx_FSG_RTS_Formations_project_sort (project_db_id, sort_order),
    CONSTRAINT fk_FSG_RTS_Formations_project
        FOREIGN KEY (project_db_id) REFERENCES FSG_RTS_Projects(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_RTS_Spells (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    project_db_id BIGINT UNSIGNED NOT NULL,
    spell_id VARCHAR(128) NOT NULL,
    name VARCHAR(190) NOT NULL,
    emoji VARCHAR(24) NOT NULL DEFAULT '',
    origin_mode VARCHAR(24) NOT NULL DEFAULT 'click',
    row_count TINYINT UNSIGNED NOT NULL,
    data_json LONGTEXT NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_RTS_Spells_project_spell (project_db_id, spell_id),
    KEY idx_FSG_RTS_Spells_project_sort (project_db_id, sort_order),
    CONSTRAINT fk_FSG_RTS_Spells_project
        FOREIGN KEY (project_db_id) REFERENCES FSG_RTS_Projects(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_RTS_BuildingTypes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    project_db_id BIGINT UNSIGNED NOT NULL,
    building_type_id VARCHAR(128) NOT NULL,
    name VARCHAR(190) NOT NULL,
    emoji VARCHAR(24) NOT NULL DEFAULT '',
    food_cost INT UNSIGNED NOT NULL DEFAULT 0,
    wood_cost INT UNSIGNED NOT NULL DEFAULT 0,
    gold_cost INT UNSIGNED NOT NULL DEFAULT 0,
    data_json LONGTEXT NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_RTS_BuildingTypes_project_type (project_db_id, building_type_id),
    KEY idx_FSG_RTS_BuildingTypes_project_sort (project_db_id, sort_order),
    CONSTRAINT fk_FSG_RTS_BuildingTypes_project
        FOREIGN KEY (project_db_id) REFERENCES FSG_RTS_Projects(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_RTS_BuildingComplexes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    project_db_id BIGINT UNSIGNED NOT NULL,
    complex_id VARCHAR(128) NOT NULL,
    name VARCHAR(190) NOT NULL,
    default_priority TINYINT UNSIGNED NOT NULL DEFAULT 3,
    building_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    data_json LONGTEXT NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_RTS_BuildingComplexes_project_complex (project_db_id, complex_id),
    KEY idx_FSG_RTS_BuildingComplexes_project_sort (project_db_id, sort_order),
    CONSTRAINT fk_FSG_RTS_BuildingComplexes_project
        FOREIGN KEY (project_db_id) REFERENCES FSG_RTS_Projects(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_RTS_Sessions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    session_id VARCHAR(96) NOT NULL,
    owner_key VARCHAR(96) NOT NULL,
    user_id BIGINT UNSIGNED NULL,
    actor_type VARCHAR(16) NOT NULL,
    display_name VARCHAR(80) NOT NULL,
    app_key VARCHAR(48) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_saved_at TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_RTS_Sessions_session (session_id),
    KEY idx_FSG_RTS_Sessions_owner_seen (owner_key, last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
