﻿'use strict';

const APP_VERSION = '1.9.0';
const PROJECT_ID = 'emberwake-dawnreach';
const SAVE_KEY = 'FSG_TIBIALIKE_EMBERWAKE_SAVE_V1';
const SETTINGS_KEY = 'FSG_TIBIALIKE_EMBERWAKE_SETTINGS_V1';
const SERVER_SESSION_KEY = 'FSG_ServerSessionId';
const SERVER_SESSION_PREEXISTED = Boolean(localStorage.getItem(SERVER_SESSION_KEY) || localStorage.getItem('FSG_DD_ServerSessionId'));
const TILE = 40;
const WORLD_W = 256;
const WORLD_H = 192;
const EQUIP_SLOTS = ['head', 'amulet', 'body', 'back', 'weapon', 'legs', 'shield', 'ring', 'feet', 'ammo'];
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const uid = (prefix = 'id') => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
const deepClone = value => JSON.parse(JSON.stringify(value));
const byId = (rows, id) => rows.find(row => row.id === id);
const nowIso = () => new Date().toISOString();
function createLocalServerSessionId() { return `EW-${Math.random().toString(36).slice(2,10).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`; }
function getServerSessionId() { let value = localStorage.getItem(SERVER_SESSION_KEY) || localStorage.getItem('FSG_DD_ServerSessionId') || ''; if (!value) { value = createLocalServerSessionId(); localStorage.setItem(SERVER_SESSION_KEY,value); localStorage.setItem('FSG_DD_ServerSessionId',value); } return value; }
function setServerSessionId(value) { const clean=String(value||'').trim(); if (!/^[A-Za-z0-9][A-Za-z0-9._:-]{5,95}$/.test(clean)) return false; localStorage.setItem(SERVER_SESSION_KEY,clean); localStorage.setItem('FSG_DD_ServerSessionId',clean); runtime.server.sessionId=clean; return true; }

const DATA = {
  meta: {
    id: PROJECT_ID,
    name: 'Emberwake',
    chapter: 'Dawnreach Isles',
    version: APP_VERSION,
    description: 'A data-driven, top-down adventure with a gentle starter archipelago and a dangerous mainland.',
    schemaPrefix: 'FSG_TIBIALIKE_',
    tileSize: 40,
    worldWidth: WORLD_W,
    worldHeight: WORLD_H
  },

  vocations: [
    { id: 'black_knight', name: 'Black Knight', promotion: 'ancient_knight', promotedName: 'Ancient Knight', icon: '♞', color: '#9da6ac', hpGain: 15, manaGain: 5, capGain: 25, speed: 1, resource: 'mana', role: 'Armored melee guardian', description: 'High health, strong shielding, and punishing close-range sweeps.' },
    { id: 'ancient_knight', name: 'Ancient Knight', base: 'black_knight', icon: '♜', color: '#c5ccd1', hpGain: 17, manaGain: 6, capGain: 28, speed: 1.03, resource: 'mana', role: 'Promoted armored guardian', description: 'A veteran Black Knight with improved sustain and command skills.' },
    { id: 'ranger', name: 'Ranger', promotion: 'court_ranger', promotedName: 'Court Ranger', icon: '➳', color: '#86c874', hpGain: 10, manaGain: 15, capGain: 20, speed: 1.05, resource: 'mana', role: 'Mobile ranged hunter', description: 'Distance combat, radiant shots, fieldcraft, and precise kiting.' },
    { id: 'court_ranger', name: 'Court Ranger', base: 'ranger', icon: '🏹', color: '#b4e58d', hpGain: 11, manaGain: 17, capGain: 22, speed: 1.08, resource: 'mana', role: 'Promoted royal scout', description: 'A decorated marksman who protects allies and controls long sight lines.' },
    { id: 'sprite', name: 'Sprite', promotion: 'dryad', promotedName: 'Dryad', icon: '❧', color: '#70d69b', hpGain: 5, manaGain: 30, capGain: 10, speed: 1, resource: 'mana', role: 'Nature and frost healer', description: 'Restores allies, commands roots, and shapes earth and ice.' },
    { id: 'dryad', name: 'Dryad', base: 'sprite', icon: '♧', color: '#a1e6a6', hpGain: 6, manaGain: 33, capGain: 12, speed: 1.03, resource: 'mana', role: 'Promoted nature keeper', description: 'A mature forest spirit with powerful group healing and battlefield control.' },
    { id: 'necromancer', name: 'Necromancer', promotion: 'lich', promotedName: 'Lich', icon: '☠', color: '#ad78d2', hpGain: 5, manaGain: 30, capGain: 10, speed: 1, resource: 'mana', role: 'Deathfire spellcaster', description: 'Channels ember, storm, and death magic into destructive area spells.' },
    { id: 'lich', name: 'Lich', base: 'necromancer', icon: '♚', color: '#d39ff3', hpGain: 6, manaGain: 34, capGain: 11, speed: 1.02, resource: 'mana', role: 'Promoted death mage', description: 'An immortal-grade caster with vast mana and screen-filling void magic.' },
    { id: 'priest', name: 'Priest', promotedName: 'High Luminary', icon: '✦', color: '#f0d77c', hpGain: 7, manaGain: 27, capGain: 12, speed: 1, resource: 'mana', role: 'Dedicated healer and reviver', description: 'Pure restoration, damage wards, resurrection, and light magic.' },
    { id: 'warhealer', name: 'Warhealer', promotedName: 'Dawn Marshal', icon: '✚', color: '#dfb94f', hpGain: 12, manaGain: 12, capGain: 21, speed: 1, resource: 'zeal', role: 'Melee support tank', description: 'Builds up to five Zeal by striking, then spends it on instant combat healing.' },
    { id: 'battlemage', name: 'Battlemage', promotedName: 'Spellblade Regent', icon: '⚔', color: '#68b8dc', hpGain: 11, manaGain: 20, capGain: 19, speed: 1.02, resource: 'mana', role: 'Heavy spellblade', description: 'Wears heavy armor and weaves elemental magic through a free short blade.' },
    { id: 'siege_operator', name: 'Siege Cannon Operator', promotedName: 'Grand Bombardier', icon: '♟', color: '#e58455', hpGain: 13, manaGain: 9, capGain: 30, speed: .88, resource: 'heat', role: 'Stationary artillery', description: 'Mounts up to travel, powers a cannon at reduced speed, anchors, then fires devastating shells.' }
  ],

  skills: [
    { id: 'swordsmanship', name: 'Swordsmanship', family: 'Combat', source: 'Emberwake', color: '#c7bd9a' },
    { id: 'clubcraft', name: 'Macecraft', family: 'Combat', source: 'Emberwake', color: '#c7bd9a' },
    { id: 'axecraft', name: 'Axecraft', family: 'Combat', source: 'Emberwake', color: '#c7bd9a' },
    { id: 'distance', name: 'Marksmanship', family: 'Combat', source: 'Emberwake', color: '#91cb78' },
    { id: 'shielding', name: 'Shielding', family: 'Combat', source: 'Emberwake', color: '#8ca4b2' },
    { id: 'magic', name: 'Spellcraft', family: 'Combat', source: 'Emberwake', color: '#9c81df' },
    { id: 'artillery', name: 'Siege Artillery', family: 'Combat', source: 'Emberwake', color: '#da8150' },
    { id: 'attack', name: 'Attack', family: 'Adventuring', source: 'RuneLite-derived skill contract', color: '#db6858' },
    { id: 'strength', name: 'Strength', family: 'Adventuring', source: 'RuneLite-derived skill contract', color: '#75b96f' },
    { id: 'defence', name: 'Defence', family: 'Adventuring', source: 'RuneLite-derived skill contract', color: '#738bc0' },
    { id: 'prayer', name: 'Devotion', family: 'Adventuring', source: 'RuneLite-derived skill contract', color: '#e4d58e' },
    { id: 'agility', name: 'Agility', family: 'Gathering', source: 'RuneLite-derived skill contract', color: '#8a94e0' },
    { id: 'herblore', name: 'Herblore', family: 'Artisan', source: 'RuneLite-derived skill contract', color: '#78bc71' },
    { id: 'thieving', name: 'Thieving', family: 'Gathering', source: 'RuneLite-derived skill contract', color: '#9e7aa5' },
    { id: 'crafting', name: 'Crafting', family: 'Artisan', source: 'RuneLite-derived skill contract', color: '#b58b68' },
    { id: 'fletching', name: 'Fletching', family: 'Artisan', source: 'RuneLite-derived skill contract', color: '#77aa79' },
    { id: 'slayer', name: 'Monster Lore', family: 'Adventuring', source: 'RuneLite-derived skill contract', color: '#8d6a5d' },
    { id: 'mining', name: 'Mining', family: 'Gathering', source: 'RuneLite-derived skill contract', color: '#87969b' },
    { id: 'smithing', name: 'Smithing', family: 'Artisan', source: 'RuneLite-derived skill contract', color: '#9f8a75' },
    { id: 'fishing', name: 'Fishing', family: 'Gathering', source: 'RuneLite-derived skill contract', color: '#5d9dc0' },
    { id: 'cooking', name: 'Cooking', family: 'Artisan', source: 'RuneLite-derived skill contract', color: '#b76f55' },
    { id: 'firemaking', name: 'Firemaking', family: 'Artisan', source: 'RuneLite-derived skill contract', color: '#d7824b' },
    { id: 'woodcutting', name: 'Woodcutting', family: 'Gathering', source: 'RuneLite-derived skill contract', color: '#678d5d' },
    { id: 'farming', name: 'Farming', family: 'Gathering', source: 'RuneLite-derived skill contract', color: '#82a65c' },
    { id: 'construction', name: 'Construction', family: 'Artisan', source: 'RuneLite-derived skill contract', color: '#b2906d' },
    { id: 'hunter', name: 'Hunting', family: 'Gathering', source: 'RuneLite-derived skill contract', color: '#8b7557' },
    { id: 'runecraft', name: 'Runecraft', family: 'Artisan', source: 'RuneLite-derived skill contract', color: '#8582ca' }
  ],

  items: [
    { id: 'gold_piece', name: 'Gold Piece', type: 'currency', icon: '●', weight: 0, buy: 1, sell: 1, stackable: true, description: 'The common trade coin of Emberwake.' },
    { id: 'apple', name: 'Harbor Apple', type: 'food', icon: '●', color: '#dc5547', weight: 1.2, buy: 4, sell: 1, heal: 12, stackable: true },
    { id: 'cheese', name: 'Cave Cheese', type: 'food', icon: '◒', color: '#e7cb63', weight: 2.1, buy: 6, sell: 2, heal: 18, stackable: true },
    { id: 'raw_meat', name: 'Raw Game Meat', type: 'material', icon: '◖', color: '#cc6a61', weight: 4, buy: 0, sell: 3, stackable: true },
    { id: 'cooked_meat', name: 'Roasted Game Meat', type: 'food', icon: '◖', color: '#b87746', weight: 3.8, buy: 10, sell: 5, heal: 32, stackable: true },
    { id: 'bread', name: 'Millstone Loaf', type: 'food', icon: '◓', color: '#c99852', weight: 3, buy: 8, sell: 3, heal: 25, stackable: true },
    { id: 'wheat', name: 'Sunwheat Bundle', type: 'material', icon: '♈', color: '#d1ad51', weight: 1.4, buy: 0, sell: 2, stackable: true },
    { id: 'flour', name: 'Stoneground Flour', type: 'material', icon: '◌', color: '#e6dfc7', weight: 1.5, buy: 4, sell: 2, stackable: true },
    { id: 'rope', name: 'Braided Climbing Rope', type: 'tool', icon: '§', color: '#c39558', weight: 18, buy: 35, sell: 8, action: 'rope' },
    { id: 'shovel', name: 'Trail Shovel', type: 'tool', icon: '♠', color: '#a8a093', weight: 22, buy: 45, sell: 10, action: 'dig' },
    { id: 'pickaxe', name: 'Crag Pick', type: 'tool', icon: '⚒', color: '#a4a9a6', weight: 28, buy: 55, sell: 12, action: 'mine' },
    { id: 'torch', name: 'Pitchwood Torch', type: 'light', icon: '♨', color: '#f0a54a', weight: 7, buy: 12, sell: 3, lightRadius: 6, duration: 600, stackable: true },
    { id: 'lantern', name: 'Glass Ember Lantern', type: 'light', icon: '⌑', color: '#f1c768', weight: 16, buy: 85, sell: 20, lightRadius: 9, duration: 0 },
    { id: 'minor_potion', name: 'Roseglass Tonic', type: 'potion', icon: '⚗', color: '#df6a75', weight: 2, buy: 25, sell: 6, heal: 65, stackable: true },
    { id: 'mana_potion', name: 'Blueglass Draught', type: 'potion', icon: '⚗', color: '#4ea9d7', weight: 2, buy: 28, sell: 7, mana: 70, stackable: true },
    { id: 'antidote', name: 'Verdant Antidote', type: 'potion', icon: '⚗', color: '#65c978', weight: 1.5, buy: 22, sell: 5, cure: 'poison', stackable: true },
    { id: 'wolf_paw', name: 'Frostwolf Paw', type: 'material', icon: '♣', color: '#b0b7ad', weight: 1, buy: 0, sell: 8, stackable: true },
    { id: 'venom_gland', name: 'Venom Gland', type: 'material', icon: '◉', color: '#77bc55', weight: .6, buy: 0, sell: 12, stackable: true },
    { id: 'honeycomb', name: 'Amber Honeycomb', type: 'material', icon: '⬡', color: '#e5b542', weight: 1.8, buy: 0, sell: 22, stackable: true },
    { id: 'ironwood_beam', name: 'Ironwood Beam', type: 'quest', icon: '═', color: '#926b3f', weight: 28, buy: 0, sell: 5, stackable: true },
    { id: 'crypt_fluid', name: 'Luminous Crypt Fluid', type: 'potion', icon: '⚗', color: '#a2e2bc', weight: 1.5, buy: 0, sell: 15, heal: 90, stackable: true },
    { id: 'radiant_shard', name: 'Radiant Shard', type: 'material', icon: '◆', color: '#f0df86', weight: .5, buy: 0, sell: 18, stackable: true },
    { id: 'sacred_relic', name: 'Tideworn Reliquary', type: 'quest', icon: '✥', color: '#e0c56f', weight: 4, buy: 0, sell: 0 },
    { id: 'iron_key', name: 'Gnarled Iron Key', type: 'key', icon: '⚿', color: '#b9b6a5', weight: .8, buy: 0, sell: 0 },
    { id: 'passage_token', name: 'Passage Token', type: 'quest', icon: '❖', color: '#e3c46a', weight: .1, buy: 0, sell: 0 },
    { id: 'sunstone', name: 'Cut Sunstone', type: 'loot', icon: '◆', color: '#efb852', weight: .8, buy: 0, sell: 20, stackable: true },
    { id: 'scarab_shell', name: 'Lacquered Scarab Shell', type: 'loot', icon: '⬟', color: '#6fa988', weight: 1, buy: 0, sell: 35, stackable: true },
    { id: 'dust_idol', name: 'Dustbound Idol', type: 'loot', icon: '♟', color: '#b89362', weight: 2.5, buy: 0, sell: 50, stackable: true },
    { id: 'spider_silk', name: 'Moon Spider Silk', type: 'material', icon: '⌁', color: '#d6d0dd', weight: .4, buy: 0, sell: 26, stackable: true },
    { id: 'giant_fang', name: 'Brood Tyrant Fang', type: 'loot', icon: '⌄', color: '#d2c8b9', weight: 2, buy: 0, sell: 140, stackable: true },
    { id: 'worm_hide', name: 'Tunnel Worm Hide', type: 'loot', icon: '∿', color: '#b38159', weight: 2, buy: 0, sell: 9, stackable: true },
    { id: 'troll_rope', name: 'Frayed Troll Rope', type: 'tool', icon: '§', color: '#8a785c', weight: 17, buy: 0, sell: 5, action: 'rope' },
    { id: 'spark_wand', name: 'Sparkwood Wand', type: 'weapon', slot: 'weapon', weaponSkill: 'magic', icon: '⌇', color: '#76c8e8', attack: 8, magicPower: 3, range: 5, element: 'energy', weight: 8, buy: 85, sell: 20, description: 'A starter wand whose attacks train Magic Level.' },
    { id: 'shore_bow', name: 'Shorewood Bow', type: 'weapon', slot: 'weapon', weaponSkill: 'distance', icon: '⌁', color: '#c69a5e', attack: 7, range: 6, ammoItemId: 'reed_arrow', weight: 18, buy: 75, sell: 18, description: 'A light bow that fires Reed Arrows from the backpack.' },
    { id: 'reed_arrow', name: 'Reed Arrow', type: 'ammo', slot: 'ammo', icon: '➶', color: '#d7c493', attack: 3, weight: .25, buy: 2, sell: 0, stackable: true, description: 'Ammunition automatically consumed by the Shorewood Bow.' },
    { id: 'harbor_spear', name: 'Harbor Practice Spear', type: 'weapon', slot: 'weapon', weaponSkill: 'distance', icon: '↟', color: '#b9a473', attack: 9, range: 4, weight: 12, buy: 42, sell: 10, stackable: true, description: 'A reusable ranged spear that trains Distance.' },
    { id: 'ember_rune', name: 'Emberburst Rune', type: 'rune', icon: '◆', color: '#e8784b', runeEffect: 'fire', power: 42, range: 6, weight: .2, buy: 18, sell: 4, stackable: true, description: 'Use to strike the nearest visible enemy and train Magic Level and Runecraft.' },
    { id: 'mending_rune', name: 'Mending Rune', type: 'rune', icon: '✚', color: '#74d59b', runeEffect: 'heal', power: 55, weight: .2, buy: 20, sell: 5, stackable: true, description: 'Use to restore health and train Magic Level and Runecraft.' },

    { id: 'soot_helm', name: 'Soot-Iron Helm', type: 'armor', slot: 'head', icon: '⌂', color: '#8d9291', armor: 1, weight: 24, buy: 20, sell: 5 },
    { id: 'worn_cloak', name: 'Worn Harbor Cloak', type: 'armor', slot: 'body', icon: '♙', color: '#776954', armor: 1, weight: 20, buy: 18, sell: 4 },
    { id: 'patched_trousers', name: 'Patched Trousers', type: 'armor', slot: 'legs', icon: '⋔', color: '#6d6655', armor: 1, weight: 14, buy: 14, sell: 3 },
    { id: 'dock_boots', name: 'Dockhand Boots', type: 'armor', slot: 'feet', icon: '∟', color: '#775a42', armor: 1, weight: 9, buy: 12, sell: 3 },
    { id: 'bent_sword', name: 'Bent Blackblade', type: 'weapon', slot: 'weapon', weaponSkill: 'swordsmanship', icon: '†', color: '#a3a5a2', attack: 7, weight: 24, buy: 28, sell: 7 },
    { id: 'plank_shield', name: 'Tarred Plank Shield', type: 'shield', slot: 'shield', icon: '◈', color: '#8d6941', defense: 6, weight: 28, buy: 24, sell: 6 },
    { id: 'frayed_pack', name: 'Frayed Field Pack', type: 'container', slot: 'back', icon: '▣', color: '#847258', capacity: 20, weight: 12, buy: 22, sell: 5 },
    { id: 'twine_amulet', name: 'Twine Charm', type: 'armor', slot: 'amulet', icon: '♢', color: '#ae9565', armor: 1, weight: 1, buy: 12, sell: 3 },
    { id: 'tin_ring', name: 'Tin Signet', type: 'armor', slot: 'ring', icon: '○', color: '#aaa99b', armor: 1, weight: .3, buy: 9, sell: 2 },
    { id: 'flint_pouch', name: 'Flint Pouch', type: 'ammo', slot: 'ammo', icon: '▪', color: '#9b9485', attack: 1, weight: 1, buy: 5, sell: 1 },

    { id: 'bronze_cap', name: 'Gilt Bronze Cap', type: 'armor', slot: 'head', icon: '⌂', color: '#c89d54', armor: 3, weight: 25, buy: 80, sell: 20 },
    { id: 'ringmail', name: 'Dawn Ringmail', type: 'armor', slot: 'body', icon: '♙', color: '#c1b37e', armor: 5, weight: 54, buy: 160, sell: 40 },
    { id: 'leather_legs', name: 'Bound Leather Greaves', type: 'armor', slot: 'legs', icon: '⋔', color: '#9d7247', armor: 3, weight: 27, buy: 90, sell: 22 },
    { id: 'trail_boots', name: 'Ironcap Trail Boots', type: 'armor', slot: 'feet', icon: '∟', color: '#a98d65', armor: 2, weight: 14, buy: 75, sell: 18 },
    { id: 'sun_mace', name: 'Sun-Headed Mace', type: 'weapon', slot: 'weapon', weaponSkill: 'clubcraft', icon: '⚒', color: '#d7b65e', attack: 16, holy: 3, weight: 31, buy: 180, sell: 45 },
    { id: 'iron_shield', name: 'Riveted Iron Shield', type: 'shield', slot: 'shield', icon: '◈', color: '#aeb5b0', defense: 13, weight: 42, buy: 145, sell: 36 },
    { id: 'trail_pack', name: 'Wayfarer Pack', type: 'container', slot: 'back', icon: '▣', color: '#9e7444', capacity: 24, weight: 14, buy: 80, sell: 20 },
    { id: 'sun_amulet', name: 'Morning Vow', type: 'armor', slot: 'amulet', icon: '♢', color: '#e5c261', armor: 2, weight: 1, buy: 70, sell: 17 },
    { id: 'bronze_ring', name: 'Bronze Oathring', type: 'armor', slot: 'ring', icon: '○', color: '#c99953', armor: 2, weight: .4, buy: 60, sell: 15 },
    { id: 'salve_case', name: 'Salve Case', type: 'ammo', slot: 'ammo', icon: '✚', color: '#e4d78d', attack: 2, weight: 2, buy: 45, sell: 11 },

    { id: 'dune_hood', name: 'Duneweave Hood', type: 'armor', slot: 'head', icon: '⌂', color: '#6ea7b6', armor: 5, weight: 18, buy: 280, sell: 70 },
    { id: 'scale_coat', name: 'Azure Scale Coat', type: 'armor', slot: 'body', icon: '♙', color: '#5796ae', armor: 8, weight: 49, buy: 440, sell: 110 },
    { id: 'guard_legs', name: 'Glassguard Chausses', type: 'armor', slot: 'legs', icon: '⋔', color: '#78a4ae', armor: 6, weight: 32, buy: 310, sell: 77 },
    { id: 'rune_boots', name: 'Runestep Boots', type: 'armor', slot: 'feet', icon: '∟', color: '#5e96ad', armor: 4, weight: 17, buy: 250, sell: 62 },
    { id: 'rune_dagger', name: 'Storm-Etched Dagger', type: 'weapon', slot: 'weapon', weaponSkill: 'swordsmanship', icon: '⚔', color: '#65c1e3', attack: 24, magicPower: 4, weight: 19, buy: 520, sell: 130 },
    { id: 'spell_focus', name: 'Freehand Spell Focus', type: 'focus', slot: 'shield', icon: '✧', color: '#71cce8', defense: 16, magicPower: 3, weight: 9, buy: 390, sell: 97 },
    { id: 'desert_pack', name: 'Merchant Satchel', type: 'container', slot: 'back', icon: '▣', color: '#c49b61', capacity: 28, weight: 13, buy: 180, sell: 45 },
    { id: 'storm_amulet', name: 'Stormglass Pendant', type: 'armor', slot: 'amulet', icon: '♢', color: '#77c5df', armor: 3, magicPower: 2, weight: 1, buy: 240, sell: 60 },
    { id: 'rune_ring', name: 'Glyph Ring', type: 'armor', slot: 'ring', icon: '○', color: '#88cce0', armor: 3, magicPower: 1, weight: .3, buy: 210, sell: 52 },
    { id: 'shard_case', name: 'Shard Case', type: 'ammo', slot: 'ammo', icon: '◆', color: '#83bed2', attack: 3, weight: 2, buy: 150, sell: 37 },

    { id: 'halo_cowl', name: 'Haloed Cowl', type: 'armor', slot: 'head', icon: '⌂', color: '#ebd883', armor: 8, magicPower: 4, weight: 21, buy: 900, sell: 225 },
    { id: 'luminary_robe', name: 'Luminary War-Robe', type: 'armor', slot: 'body', icon: '♙', color: '#e0ce88', armor: 12, magicPower: 5, weight: 45, buy: 1450, sell: 362 },
    { id: 'sunweave_legs', name: 'Sunweave Leggings', type: 'armor', slot: 'legs', icon: '⋔', color: '#d8c57a', armor: 9, magicPower: 2, weight: 29, buy: 980, sell: 245 },
    { id: 'pilgrim_boots', name: 'Radiant Pilgrim Boots', type: 'armor', slot: 'feet', icon: '∟', color: '#e4d699', armor: 6, speedBonus: .04, weight: 15, buy: 780, sell: 195 },
    { id: 'dawn_staff', name: 'Dawnwake Crozier', type: 'weapon', slot: 'weapon', weaponSkill: 'magic', icon: '⚕', color: '#f0d468', attack: 31, magicPower: 9, holy: 9, weight: 29, buy: 1850, sell: 462 },
    { id: 'aegis_tome', name: 'Aegis Tome', type: 'focus', slot: 'shield', icon: '▤', color: '#f0df9a', defense: 23, magicPower: 5, weight: 12, buy: 1370, sell: 342 },
    { id: 'relic_pack', name: 'Reliquary Pack', type: 'container', slot: 'back', icon: '▣', color: '#c8ab62', capacity: 32, weight: 16, buy: 620, sell: 155 },
    { id: 'grace_amulet', name: 'Amulet of Returning', type: 'armor', slot: 'amulet', icon: '♢', color: '#ffe293', armor: 5, magicPower: 3, weight: 1, buy: 1050, sell: 262 },
    { id: 'mercy_ring', name: 'Mercy Band', type: 'armor', slot: 'ring', icon: '○', color: '#f5d474', armor: 5, regen: 2, weight: .4, buy: 860, sell: 215 },
    { id: 'prayer_beads', name: 'Sun Prayer Beads', type: 'ammo', slot: 'ammo', icon: '⁙', color: '#e8d59a', attack: 4, magicPower: 2, weight: 1, buy: 510, sell: 127 },

    { id: 'bombardier_helm', name: 'Worldbreaker Visor', type: 'armor', slot: 'head', icon: '⌂', color: '#ef8c56', armor: 28, weight: 42, buy: 80000, sell: 20000 },
    { id: 'worldplate', name: 'Worldbreaker Plate', type: 'armor', slot: 'body', icon: '♙', color: '#df744d', armor: 45, weight: 92, buy: 160000, sell: 40000 },
    { id: 'siege_greaves', name: 'Worldbreaker Greaves', type: 'armor', slot: 'legs', icon: '⋔', color: '#cb6b47', armor: 34, weight: 68, buy: 110000, sell: 27500 },
    { id: 'stabilizer_boots', name: 'Titan Stabilizers', type: 'armor', slot: 'feet', icon: '∟', color: '#e48a58', armor: 24, weight: 52, buy: 90000, sell: 22500 },
    { id: 'grand_cannon', name: 'Cataclysm Field Cannon', type: 'weapon', slot: 'weapon', weaponSkill: 'artillery', icon: '☄', color: '#ff8054', attack: 120, range: 8, weight: 180, buy: 350000, sell: 87500 },
    { id: 'blast_shield', name: 'Blastwall Mantlet', type: 'shield', slot: 'shield', icon: '◈', color: '#d4764f', defense: 58, weight: 110, buy: 220000, sell: 55000 },
    { id: 'arsenal_rig', name: 'Bottomless Arsenal Rig', type: 'container', slot: 'back', icon: '▣', color: '#bb6848', capacity: 60, weight: 55, buy: 140000, sell: 35000 },
    { id: 'rangefinder', name: 'Dragon-Eye Rangefinder', type: 'armor', slot: 'amulet', icon: '♢', color: '#ff9a63', armor: 16, attackBonus: 12, weight: 4, buy: 125000, sell: 31250 },
    { id: 'anchor_ring', name: 'Unmoving Ring', type: 'armor', slot: 'ring', icon: '○', color: '#e78054', armor: 17, weight: 2, buy: 115000, sell: 28750 },
    { id: 'shell_bandolier', name: 'Infinite Shell Bandolier', type: 'ammo', slot: 'ammo', icon: '◉', color: '#f3925e', attack: 25, weight: 25, buy: 190000, sell: 47500 },

    { id: 'oak_chair', name: 'Dawn Oak Chair', type: 'furniture', icon: '♜', weight: 35, buy: 45, sell: 10, placeable: true },
    { id: 'reed_bed', name: 'Harbor Reed Bed', type: 'furniture', icon: '▬', weight: 70, buy: 110, sell: 25, placeable: true },
    { id: 'sea_chest', name: 'Saltwood Storage Chest', type: 'furniture', icon: '▰', weight: 65, buy: 85, sell: 20, placeable: true },
    { id: 'round_table', name: 'Round Ironwood Table', type: 'furniture', icon: '●', weight: 55, buy: 75, sell: 18, placeable: true },
    { id: 'wall_torch', name: 'Brass Wall Torch', type: 'furniture', icon: '♨', weight: 12, buy: 35, sell: 8, placeable: true, lightRadius: 7 },
    { id: 'woven_rug', name: 'Woven Tide Rug', type: 'furniture', icon: '▧', weight: 20, buy: 60, sell: 15, placeable: true },
    { id: 'training_dummy', name: 'House Training Dummy', type: 'furniture', icon: '♟', weight: 90, buy: 250, sell: 60, placeable: true },
    { id: 'bookcase', name: 'Archivist Bookcase', type: 'furniture', icon: '▥', weight: 80, buy: 130, sell: 30, placeable: true }
  ],

  spells: [
    { id: 'light_orb', name: 'Kindlelight', icon: '☀', incantation: 'Luma', group: 'utility', level: 1, mana: 12, cooldown: 1000, range: 0, effect: 'light', power: 8, visual: 'A warm gold orb expands and illuminates nearby cave tiles.', vocations: ['all'] },
    { id: 'mend', name: 'Gentle Mend', icon: '✚', incantation: 'Sana', group: 'healing', level: 1, mana: 18, cooldown: 1200, range: 0, effect: 'heal', power: 42, visual: 'Green-gold motes rise through a soft healing cross.', vocations: ['all'] },
    { id: 'haste', name: 'Windstep', icon: '≋', incantation: 'Vela', group: 'support', level: 4, mana: 28, cooldown: 8000, range: 0, effect: 'haste', power: .35, duration: 8000, visual: 'White gust ribbons sweep behind the caster’s boots.', vocations: ['all'] },
    { id: 'ropecall', name: 'Spectral Ropecall', icon: '§', incantation: 'Tera vey', group: 'utility', level: 8, mana: 35, cooldown: 2000, range: 0, effect: 'rope', power: 1, visual: 'A pale woven cord lifts the caster through a rope shaft.', vocations: ['all'] },
    { id: 'cleanse', name: 'Clearblood', icon: '✧', incantation: 'Pura', group: 'healing', level: 6, mana: 24, cooldown: 2500, range: 0, effect: 'cleanse', power: 1, visual: 'Color-coded sparks peel poison, flame, shock, bleeding, and curses away.', vocations: ['all'] },
    { id: 'magic_ward', name: 'Aether Ward', icon: '◯', incantation: 'Aegis aeth', group: 'support', level: 10, mana: 40, cooldown: 10000, range: 0, effect: 'shield', power: .35, duration: 10000, visual: 'A translucent blue-violet shell closes around the caster.', vocations: ['all'] },

    { id: 'iron_cyclone', name: 'Iron Cyclone', icon: '⚔', incantation: 'Ferrum orba', group: 'attack', level: 1, mana: 24, cooldown: 1800, range: 1, radius: 1, effect: 'physical', power: 1.25, visual: 'A white-red ring of steel slashes every adjacent tile.', vocations: ['black_knight', 'ancient_knight'] },
    { id: 'crimson_oath', name: 'Crimson Oath', icon: '♨', incantation: 'Ruva fortis', group: 'support', level: 8, mana: 40, cooldown: 12000, range: 0, effect: 'rage', power: .35, duration: 9000, visual: 'Dark-red heat pulses from the armor, trading defense for melee force.', vocations: ['black_knight', 'ancient_knight'] },
    { id: 'challenge', name: 'Graven Challenge', icon: '♜', incantation: 'Ad me', group: 'support', level: 12, mana: 35, cooldown: 6000, range: 5, radius: 4, effect: 'taunt', power: 1, visual: 'A bronze shock ring marks nearby enemies with the knight’s crest.', vocations: ['black_knight', 'ancient_knight'] },
    { id: 'stone_charge', name: 'Stone Charge', icon: '➤', incantation: 'Ruin rush', group: 'support', level: 20, mana: 55, cooldown: 9000, range: 0, effect: 'haste', power: .55, duration: 3500, visual: 'A compact trail of dust and sparks erupts behind the knight.', vocations: ['ancient_knight'] },

    { id: 'sunshot', name: 'Sunshot', icon: '➳', incantation: 'Sol pierce', group: 'attack', level: 1, mana: 18, cooldown: 900, range: 6, effect: 'holy', power: 1.15, visual: 'A narrow gold-white bolt flashes into the target.', vocations: ['ranger', 'court_ranger'] },
    { id: 'halo_volley', name: 'Halo Volley', icon: '✺', incantation: 'Sol rain', group: 'attack', level: 12, mana: 45, cooldown: 3500, range: 5, radius: 2, effect: 'holy', power: 1.05, visual: 'Concentric holy rings burst into a rain of radiant arrows.', vocations: ['ranger', 'court_ranger'] },
    { id: 'falcon_focus', name: 'Falcon Focus', icon: '⌖', incantation: 'Oculum', group: 'support', level: 18, mana: 38, cooldown: 12000, range: 0, effect: 'focus', power: .45, duration: 8500, visual: 'A precise golden crosshair settles over the ranger while movement slows.', vocations: ['ranger', 'court_ranger'] },
    { id: 'protect_company', name: 'Protect Company', icon: '◈', incantation: 'Aegis kin', group: 'support', level: 25, mana: 55, cooldown: 15000, range: 0, radius: 5, effect: 'party_defense', power: .18, duration: 12000, visual: 'Small shield sigils orbit every nearby ally.', vocations: ['court_ranger'] },

    { id: 'frost_seed', name: 'Frost Seed', icon: '❄', incantation: 'Friga sem', group: 'attack', level: 1, mana: 20, cooldown: 1000, range: 5, effect: 'ice', power: 1.1, visual: 'A blue seed crystal cracks into localized frost.', vocations: ['sprite', 'dryad'] },
    { id: 'verdant_mend', name: 'Verdant Mend', icon: '❧', incantation: 'Vita frond', group: 'healing', level: 8, mana: 35, cooldown: 1500, range: 4, effect: 'heal', power: 95, visual: 'Emerald leaves and gentle gold motes spiral upward.', vocations: ['sprite', 'dryad'] },
    { id: 'rootwall', name: 'Rootwall', icon: '♧', incantation: 'Radix wall', group: 'control', level: 14, mana: 50, cooldown: 7000, range: 4, effect: 'wall', power: 1, duration: 8000, visual: 'Knotted roots erupt from one tile and block movement.', vocations: ['sprite', 'dryad'] },
    { id: 'eternal_bloom', name: 'Eternal Bloom', icon: '✿', incantation: 'Hiberna vita', group: 'attack', level: 30, mana: 110, cooldown: 8000, range: 0, radius: 5, effect: 'ice', power: 1.65, visual: 'A wide blizzard blooms into jagged frost flowers across the screen.', vocations: ['dryad'] },

    { id: 'ember_lance', name: 'Ember Lance', icon: '♨', incantation: 'Fera ignis', group: 'attack', level: 1, mana: 20, cooldown: 900, range: 5, effect: 'fire', power: 1.2, visual: 'A compressed orange flame streaks into a sharp impact burst.', vocations: ['necromancer', 'lich'] },
    { id: 'grave_spark', name: 'Grave Spark', icon: '☠', incantation: 'Morta vis', group: 'attack', level: 7, mana: 28, cooldown: 1200, range: 5, effect: 'death', power: 1.3, visual: 'A black-violet skull spark detonates in cool smoke.', vocations: ['necromancer', 'lich'] },
    { id: 'arc_wave', name: 'Arc Wave', icon: 'ϟ', incantation: 'Fulgar hur', group: 'attack', level: 14, mana: 48, cooldown: 2600, range: 5, radius: 2, effect: 'energy', power: 1.2, visual: 'A jagged blue-yellow sheet of electricity surges forward.', vocations: ['necromancer', 'lich'] },
    { id: 'void_tempest', name: 'Void Tempest', icon: '☄', incantation: 'Morta caelum', group: 'attack', level: 30, mana: 120, cooldown: 8000, range: 0, radius: 5, effect: 'death', power: 1.75, visual: 'The view darkens while violet meteors and deathfire columns strike a huge area.', vocations: ['lich'] },

    { id: 'grace_touch', name: 'Grace Touch', icon: '✚', incantation: 'Gratia', group: 'healing', level: 1, mana: 16, cooldown: 950, range: 4, effect: 'heal', power: 110, visual: 'A brilliant gold-white cross dissolves into ascending sparks.', vocations: ['priest'] },
    { id: 'sanctuary_pulse', name: 'Sanctuary Pulse', icon: '✦', incantation: 'Sancta orba', group: 'healing', level: 18, mana: 65, cooldown: 4000, range: 0, radius: 3, effect: 'mass_heal', power: 145, visual: 'A warm circular wave restores every friendly creature nearby.', vocations: ['priest'] },
    { id: 'return_soul', name: 'Return Soul', icon: '☥', incantation: 'Anima redit', group: 'healing', level: 35, mana: 160, cooldown: 30000, range: 3, effect: 'revive', power: .5, visual: 'A gold thread reaches into a fading spirit and rebuilds its silhouette.', vocations: ['priest'] },
    { id: 'sun_smite', name: 'Sun Smite', icon: '☀', incantation: 'Sol judex', group: 'attack', level: 12, mana: 42, cooldown: 1600, range: 5, effect: 'holy', power: 1.35, visual: 'A vertical pillar of white-gold light scorches the target tile.', vocations: ['priest'] },
    { id: 'mercy_ward', name: 'Mercy Ward', icon: '◉', incantation: 'Misericord', group: 'support', level: 26, mana: 75, cooldown: 12000, range: 0, effect: 'shield', power: .55, duration: 9000, visual: 'Overlapping gold hexagons absorb incoming harm.', vocations: ['priest'] },

    { id: 'zeal_strike', name: 'Zeal Strike', icon: '⚒', incantation: '', group: 'attack', level: 1, mana: 0, zeal: 0, cooldown: 950, range: 1, effect: 'physical', power: 1.2, buildsZeal: 1, visual: 'A gold-edged melee blow adds one bright Zeal mote.', vocations: ['warhealer'] },
    { id: 'battle_salve', name: 'Battle Salve', icon: '✚', incantation: '', group: 'healing', level: 8, mana: 0, zeal: 2, cooldown: 1300, range: 0, effect: 'heal', power: 150, visual: 'Two Zeal motes collapse into an instant amber healing flare.', vocations: ['warhealer'] },
    { id: 'shared_vigor', name: 'Shared Vigor', icon: '✣', incantation: '', group: 'healing', level: 18, mana: 0, zeal: 3, cooldown: 3500, range: 4, radius: 3, effect: 'mass_heal', power: 115, visual: 'Amber ribbons join the Warhealer to nearby allies.', vocations: ['warhealer'] },
    { id: 'vow_of_iron', name: 'Vow of Iron', icon: '◈', incantation: '', group: 'support', level: 14, mana: 25, zeal: 1, cooldown: 9000, range: 0, effect: 'shield', power: .4, duration: 7000, visual: 'A heated iron lattice seals around the armor.', vocations: ['warhealer'] },

    { id: 'spellweave', name: 'Spellweave Cut', icon: '⚔', incantation: 'Tela ferrum', group: 'attack', level: 1, mana: 22, cooldown: 850, range: 1, effect: 'energy', power: 1.45, bladeWeave: true, visual: 'Blue runes trail the dagger and burst at the cut.', vocations: ['battlemage'] },
    { id: 'cinder_fan', name: 'Cinder Fan', icon: '♨', incantation: 'Cinis hur', group: 'attack', level: 12, mana: 44, cooldown: 2200, range: 4, radius: 2, effect: 'fire', power: 1.25, visual: 'A hand-fan of red cinders rolls outward from the blade.', vocations: ['battlemage'] },
    { id: 'shock_lunge', name: 'Shock Lunge', icon: 'ϟ', incantation: 'Fulgar ferrum', group: 'attack', level: 20, mana: 58, cooldown: 3200, range: 4, effect: 'energy', power: 1.6, visual: 'The Battlemage flashes forward as the blade releases blue lightning.', vocations: ['battlemage'] },
    { id: 'runic_plate', name: 'Runic Plate', icon: '⬡', incantation: 'Arma aeth', group: 'support', level: 16, mana: 50, cooldown: 9000, range: 0, effect: 'shield', power: .42, duration: 7000, visual: 'Luminous blue glyphs settle over each heavy armor plate.', vocations: ['battlemage'] },

    { id: 'power_cannon', name: 'Power Cannon', icon: '◉', incantation: '', group: 'stance', level: 1, mana: 0, cooldown: 1000, range: 0, effect: 'power_cannon', power: 1, visual: 'Gears flare orange; movement slows while the barrel charges.', vocations: ['siege_operator'] },
    { id: 'anchor_siege', name: 'Anchor Siege Mode', icon: '⌑', incantation: '', group: 'stance', level: 1, mana: 0, cooldown: 1200, range: 0, effect: 'siege', power: 1, visual: 'Four iron stabilizers slam down and halt all movement.', vocations: ['siege_operator'] },
    { id: 'breach_shell', name: 'Breach Shell', icon: '☄', incantation: '', group: 'attack', level: 1, mana: 18, cooldown: 1600, range: 8, radius: 1, effect: 'physical', power: 2.1, requiresSiege: true, visual: 'A bright shell streaks across the grid and explodes in stone splinters.', vocations: ['siege_operator'] },
    { id: 'mortar_rain', name: 'Mortar Rain', icon: '⁙', incantation: '', group: 'attack', level: 50, mana: 45, cooldown: 5000, range: 9, radius: 3, effect: 'fire', power: 2.5, requiresSiege: true, visual: 'Target circles flash before a clustered rain of flaming shells lands.', vocations: ['siege_operator'] },
    { id: 'flak_burst', name: 'Flak Burst', icon: '✹', incantation: '', group: 'attack', level: 25, mana: 30, cooldown: 3000, range: 0, radius: 2, effect: 'physical', power: 1.7, visual: 'Metal fragments burst outward in a point-blank ring.', vocations: ['siege_operator'] },
    { id: 'emergency_plating', name: 'Emergency Plating', icon: '▣', incantation: '', group: 'support', level: 70, mana: 40, cooldown: 12000, range: 0, effect: 'shield', power: .6, duration: 7000, visual: 'Orange-hot reserve plates unfold over the chassis.', vocations: ['siege_operator'] }
  ],

  monsters: [
    { id: 'mob_scavenger_rat', name: 'Scavenger Rat', icon: '♧', level: 1, hp: 24, attack: 3, defense: 0, xp: 12, speed: .85, range: 1, aggro: 3, element: 'physical', zone: 'Shoreward Green', traits: 'Timid scavenger', color: '#a78967' },
    { id: 'mob_cave_rat', name: 'Cave Rat', icon: '♧', level: 2, hp: 34, attack: 5, defense: 1, xp: 18, speed: 1, range: 1, aggro: 4, element: 'physical', zone: 'Low Caves', traits: 'Fast, food carrier', color: '#806d59' },
    { id: 'mob_plains_deer', name: 'Plains Deer', icon: '♈', level: 2, hp: 48, attack: 2, defense: 1, xp: 20, speed: 1.2, range: 1, aggro: 0, element: 'physical', zone: 'Shoreward Green', traits: 'Passive; flees', color: '#c69b6b' },
    { id: 'mob_stray_hound', name: 'Stray Hound', icon: '♣', level: 3, hp: 58, attack: 7, defense: 2, xp: 28, speed: 1.1, range: 1, aggro: 4, element: 'physical', zone: 'Harbor Fringe', traits: 'Alerts nearby beasts', color: '#a99572' },
    { id: 'mob_feral_boar', name: 'Feral Boar', icon: '♠', level: 4, hp: 88, attack: 10, defense: 3, xp: 42, speed: .9, range: 1, aggro: 3, element: 'physical', zone: 'Iron Canopy', traits: 'High health, rich meat', color: '#9b745c' },
    { id: 'mob_venom_spider', name: 'Venom Spider', icon: '✣', level: 4, hp: 54, attack: 8, defense: 1, xp: 45, speed: 1, range: 1, aggro: 5, element: 'poison', dot: 3, zone: 'Iron Canopy', traits: 'Applies poison', color: '#7caf56' },
    { id: 'mob_timber_wolf', name: 'Timber Wolf', icon: '♢', level: 5, hp: 76, attack: 13, defense: 2, xp: 60, speed: 1.25, range: 1, aggro: 6, element: 'physical', zone: 'Iron Canopy', traits: 'Pack hunter', color: '#a5ada9' },
    { id: 'mob_cave_beetle', name: 'Cave Beetle', icon: '⬢', level: 5, hp: 105, attack: 9, defense: 9, xp: 66, speed: .7, range: 1, aggro: 4, element: 'physical', zone: 'Iron Canopy', traits: 'Heavy shell', color: '#5e7662' },
    { id: 'mob_reed_viper', name: 'Reed Viper', icon: '∿', level: 6, hp: 70, attack: 14, defense: 6, xp: 76, speed: 1.15, range: 1, aggro: 5, element: 'poison', dot: 4, evasion: .14, zone: 'Iron Canopy', traits: 'Evasive venom', color: '#71a75e' },
    { id: 'mob_scrap_troll', name: 'Scrap Troll', icon: '♟', level: 6, hp: 118, attack: 16, defense: 6, xp: 92, speed: .85, range: 1, aggro: 5, element: 'physical', zone: 'Iron Canopy', traits: 'Carries tools and beams', color: '#6c9875' },
    { id: 'mob_feral_bear', name: 'Feral Bear', icon: '♜', level: 7, hp: 180, attack: 22, defense: 8, xp: 125, speed: .9, range: 1, aggro: 5, element: 'physical', zone: 'Iron Canopy', traits: 'Blocks narrow paths', color: '#765b4a' },
    { id: 'mob_mud_slime', name: 'Mud Slime', icon: '●', level: 7, hp: 98, attack: 13, defense: 4, xp: 110, speed: .65, range: 1, aggro: 4, element: 'earth', zone: 'Iron Canopy', traits: 'May split at half health', color: '#78945c' },
    { id: 'mob_goblin_slinger', name: 'Goblin Slinger', icon: '♟', level: 8, hp: 105, attack: 20, defense: 5, xp: 140, speed: 1, range: 5, aggro: 7, element: 'physical', zone: 'Crucible Reach', traits: 'Ranged; retreats', color: '#769268' },
    { id: 'mob_ash_raider', name: 'Ash Raider', icon: '♞', level: 9, hp: 165, attack: 28, defense: 10, xp: 190, speed: .95, range: 1, aggro: 6, element: 'physical', zone: 'Crucible Reach', traits: 'Heavy melee check', color: '#a86b50' },
    { id: 'mob_javelin_raider', name: 'Javelin Raider', icon: '➶', level: 9, hp: 125, attack: 24, defense: 7, xp: 185, speed: 1.1, range: 5, aggro: 7, element: 'physical', zone: 'Crucible Reach', traits: 'Kiting ranged attacker', color: '#b4835e' },
    { id: 'mob_crypt_scrapper', name: 'Crypt Scrapper', icon: '☠', level: 10, hp: 145, attack: 26, defense: 11, xp: 220, speed: .8, range: 1, aggro: 6, element: 'death', immune: 'poison,bleed', zone: 'Crucible Crypt', traits: 'Undead immunities', color: '#d1ceb6' },
    { id: 'mob_tunnel_worm', name: 'Tunnel Worm', icon: '∿', level: 12, hp: 210, attack: 31, defense: 12, xp: 310, speed: .75, range: 1, aggro: 5, element: 'earth', zone: 'Wormburrow', traits: 'Burrows from loose earth', color: '#b17855' },
    { id: 'mob_horned_brute', name: 'Horned Brute', icon: '♉', level: 14, hp: 340, attack: 42, defense: 20, xp: 520, speed: .8, range: 1, aggro: 6, element: 'physical', zone: 'Crucible Reach', traits: 'First major armor check', color: '#a45d4e' },
    { id: 'mob_killer_wasp', name: 'Killer Wasp', icon: '✥', level: 15, hp: 165, attack: 34, defense: 8, xp: 430, speed: 1.45, range: 1, aggro: 8, element: 'poison', dot: 7, zone: 'Crucible Reach', traits: 'Extremely fast poisoner', color: '#e2b948' },
    { id: 'mob_brute_mystic', name: 'Brute Mystic', icon: '♛', level: 20, hp: 720, attack: 55, defense: 18, xp: 1500, speed: .9, range: 6, aggro: 9, element: 'energy', boss: true, zone: 'Crucible Sanctum', traits: 'Island boss; magic ignores armor', color: '#b965c4' }
  ],

  zones: [
    { id: 'anchorage_harbor', name: 'Anchorage Harbor', floor: 0, minLevel: 1, maxLevel: 3, danger: 'safe', pz: true, bounds: 'x8–26, y39–53', biome: 'Harbor grassland', description: 'Protection-zone town, merchants, training, house, and gentle spawns.' },
    { id: 'shoreward_green', name: 'Shoreward Green', floor: 0, minLevel: 1, maxLevel: 3, danger: 'low', pz: false, bounds: 'first island', biome: 'Coastal meadow', description: 'The forgiving edge of the starter island.' },
    { id: 'iron_canopy', name: 'Iron Canopy', floor: 0, minLevel: 4, maxLevel: 7, danger: 'medium', pz: false, bounds: 'second island', biome: 'Dense wet woodland', description: 'Poison, packs, ranged threats, and the gear-check bridge.' },
    { id: 'crucible_reach', name: 'Crucible Reach', floor: 0, minLevel: 7, maxLevel: 12, danger: 'high', pz: false, bounds: 'third island', biome: 'Ash and broken stone', description: 'The final starter-island trials and ferryman.' },
    { id: 'wormburrow', name: 'Wormburrow', floor: -1, minLevel: 12, maxLevel: 24, danger: 'medium', pz: false, bounds: 'x7–25, y38–57', biome: 'Earthen cave', description: 'Tunnel Worm cave beneath the starter market; rope route verified.' },
    { id: 'sunscour_market', name: 'Sunscour Market', floor: 0, minLevel: 24, maxLevel: 38, danger: 'safe', pz: true, bounds: 'x72–91, y8–27', biome: 'Desert town', description: 'A warm sandstone settlement and profitable loot merchant.' },
    { id: 'silkfall_depths', name: 'Silkfall Depths', floor: -2, minLevel: 42, maxLevel: 65, danger: 'high', pz: false, bounds: 'x55–74, y5–27', biome: 'Tarantula cave', description: 'Five connected floors with Brood Tyrants at the top and bottom.' },
    { id: 'northroad', name: 'Long Southroad', floor: 0, minLevel: 15, maxLevel: 45, danger: 'medium', pz: false, bounds: 'mainland to Dawnreach', biome: 'Mixed wilderness', description: 'A long, clear route south from Silkfall to the first island.' },
    { id: 'crucible_sanctum', name: 'Crucible Sanctum', floor: 0, minLevel: 10, maxLevel: 20, danger: 'boss', pz: false, bounds: 'east isle vault', biome: 'Ruined sanctum', description: 'Home of the Brute Mystic and the Passage Token.' }
  ]
};

DATA.dropTables = [
  { id: 'drop_scavenger_rat', monsterId: 'mob_scavenger_rat', rolls: 1, nothingWeight: 8, entries: [{ itemId: 'gold_piece', tier: 'always', weight: 100, min: 1, max: 3 }, { itemId: 'apple', tier: 'common', weight: 18, min: 1, max: 1 }] },
  { id: 'drop_cave_rat', monsterId: 'mob_cave_rat', rolls: 1, nothingWeight: 5, entries: [{ itemId: 'gold_piece', tier: 'always', weight: 100, min: 2, max: 5 }, { itemId: 'cheese', tier: 'common', weight: 35, min: 1, max: 1 }] },
  { id: 'drop_plains_deer', monsterId: 'mob_plains_deer', rolls: 1, nothingWeight: 0, entries: [{ itemId: 'raw_meat', tier: 'always', weight: 100, min: 1, max: 2 }, { itemId: 'gold_piece', tier: 'tertiary', weight: 8, min: 2, max: 6 }] },
  { id: 'drop_stray_hound', monsterId: 'mob_stray_hound', rolls: 1, nothingWeight: 25, entries: [{ itemId: 'raw_meat', tier: 'common', weight: 45, min: 1, max: 1 }, { itemId: 'gold_piece', tier: 'common', weight: 35, min: 2, max: 6 }] },
  { id: 'drop_feral_boar', monsterId: 'mob_feral_boar', rolls: 2, nothingWeight: 4, entries: [{ itemId: 'raw_meat', tier: 'always', weight: 100, min: 2, max: 4 }, { itemId: 'gold_piece', tier: 'common', weight: 40, min: 4, max: 9 }] },
  { id: 'drop_venom_spider', monsterId: 'mob_venom_spider', rolls: 1, nothingWeight: 12, entries: [{ itemId: 'venom_gland', tier: 'common', weight: 44, min: 1, max: 2 }, { itemId: 'gold_piece', tier: 'common', weight: 28, min: 3, max: 8 }, { itemId: 'antidote', tier: 'rare', weight: 3, min: 1, max: 1 }] },
  { id: 'drop_timber_wolf', monsterId: 'mob_timber_wolf', rolls: 1, nothingWeight: 10, entries: [{ itemId: 'wolf_paw', tier: 'common', weight: 48, min: 1, max: 1 }, { itemId: 'raw_meat', tier: 'common', weight: 38, min: 1, max: 2 }, { itemId: 'gold_piece', tier: 'common', weight: 30, min: 3, max: 8 }] },
  { id: 'drop_cave_beetle', monsterId: 'mob_cave_beetle', rolls: 1, nothingWeight: 18, entries: [{ itemId: 'ironwood_beam', tier: 'common', weight: 30, min: 1, max: 1 }, { itemId: 'radiant_shard', tier: 'rare', weight: 5, min: 1, max: 1 }, { itemId: 'gold_piece', tier: 'common', weight: 42, min: 4, max: 10 }] },
  { id: 'drop_reed_viper', monsterId: 'mob_reed_viper', rolls: 1, nothingWeight: 8, entries: [{ itemId: 'venom_gland', tier: 'common', weight: 64, min: 1, max: 2 }, { itemId: 'gold_piece', tier: 'common', weight: 38, min: 5, max: 12 }] },
  { id: 'drop_scrap_troll', monsterId: 'mob_scrap_troll', rolls: 2, nothingWeight: 5, entries: [{ itemId: 'ironwood_beam', tier: 'common', weight: 58, min: 1, max: 2 }, { itemId: 'troll_rope', tier: 'common', weight: 22, min: 1, max: 1 }, { itemId: 'gold_piece', tier: 'always', weight: 100, min: 7, max: 15 }, { itemId: 'bent_sword', tier: 'rare', weight: 4, min: 1, max: 1 }] },
  { id: 'drop_feral_bear', monsterId: 'mob_feral_bear', rolls: 2, nothingWeight: 4, entries: [{ itemId: 'raw_meat', tier: 'always', weight: 100, min: 3, max: 6 }, { itemId: 'gold_piece', tier: 'common', weight: 55, min: 8, max: 18 }, { itemId: 'iron_shield', tier: 'rare', weight: 2, min: 1, max: 1 }] },
  { id: 'drop_mud_slime', monsterId: 'mob_mud_slime', rolls: 1, nothingWeight: 8, entries: [{ itemId: 'radiant_shard', tier: 'common', weight: 27, min: 1, max: 2 }, { itemId: 'gold_piece', tier: 'common', weight: 52, min: 6, max: 14 }, { itemId: 'minor_potion', tier: 'rare', weight: 4, min: 1, max: 1 }] },
  { id: 'drop_goblin_slinger', monsterId: 'mob_goblin_slinger', rolls: 2, nothingWeight: 6, entries: [{ itemId: 'gold_piece', tier: 'always', weight: 100, min: 10, max: 24 }, { itemId: 'flint_pouch', tier: 'common', weight: 25, min: 1, max: 1 }, { itemId: 'iron_key', tier: 'rare', weight: 2, min: 1, max: 1 }] },
  { id: 'drop_ash_raider', monsterId: 'mob_ash_raider', rolls: 2, nothingWeight: 5, entries: [{ itemId: 'gold_piece', tier: 'always', weight: 100, min: 14, max: 30 }, { itemId: 'radiant_shard', tier: 'common', weight: 22, min: 1, max: 2 }, { itemId: 'bent_sword', tier: 'rare', weight: 6, min: 1, max: 1 }] },
  { id: 'drop_javelin_raider', monsterId: 'mob_javelin_raider', rolls: 2, nothingWeight: 5, entries: [{ itemId: 'gold_piece', tier: 'always', weight: 100, min: 12, max: 28 }, { itemId: 'flint_pouch', tier: 'common', weight: 35, min: 1, max: 2 }, { itemId: 'wolf_paw', tier: 'rare', weight: 5, min: 1, max: 2 }] },
  { id: 'drop_crypt_scrapper', monsterId: 'mob_crypt_scrapper', rolls: 2, nothingWeight: 3, entries: [{ itemId: 'gold_piece', tier: 'always', weight: 100, min: 16, max: 36 }, { itemId: 'crypt_fluid', tier: 'common', weight: 35, min: 1, max: 2 }, { itemId: 'sacred_relic', tier: 'rare', weight: 3, min: 1, max: 1 }] },
  { id: 'drop_tunnel_worm', monsterId: 'mob_tunnel_worm', rolls: 2, nothingWeight: 3, entries: [{ itemId: 'gold_piece', tier: 'always', weight: 100, min: 20, max: 46 }, { itemId: 'worm_hide', tier: 'common', weight: 60, min: 1, max: 3 }, { itemId: 'raw_meat', tier: 'common', weight: 28, min: 1, max: 2 }, { itemId: 'sun_mace', tier: 'rare', weight: 2, min: 1, max: 1 }] },
  { id: 'drop_horned_brute', monsterId: 'mob_horned_brute', rolls: 3, nothingWeight: 2, entries: [{ itemId: 'gold_piece', tier: 'always', weight: 100, min: 28, max: 70 }, { itemId: 'ironwood_beam', tier: 'common', weight: 35, min: 1, max: 3 }, { itemId: 'radiant_shard', tier: 'common', weight: 22, min: 1, max: 2 }, { itemId: 'sun_mace', tier: 'rare', weight: 4, min: 1, max: 1 }] },
  { id: 'drop_killer_wasp', monsterId: 'mob_killer_wasp', rolls: 2, nothingWeight: 2, entries: [{ itemId: 'honeycomb', tier: 'always', weight: 100, min: 1, max: 2 }, { itemId: 'gold_piece', tier: 'common', weight: 62, min: 18, max: 42 }, { itemId: 'antidote', tier: 'rare', weight: 7, min: 1, max: 2 }] },
  { id: 'drop_brute_mystic', monsterId: 'mob_brute_mystic', rolls: 4, nothingWeight: 0, entries: [{ itemId: 'passage_token', tier: 'always', weight: 100, min: 1, max: 1 }, { itemId: 'gold_piece', tier: 'always', weight: 100, min: 150, max: 250 }, { itemId: 'radiant_shard', tier: 'common', weight: 70, min: 2, max: 5 }, { itemId: 'storm_amulet', tier: 'rare', weight: 7, min: 1, max: 1 }] },
  { id: 'drop_brood_tyrant', monsterId: 'boss_brood_tyrant', rolls: 3, nothingWeight: 0, entries: [{ itemId: 'giant_fang', tier: 'always', weight: 100, min: 1, max: 1 }, { itemId: 'spider_silk', tier: 'common', weight: 70, min: 2, max: 5 }, { itemId: 'gold_piece', tier: 'always', weight: 100, min: 120, max: 260 }, { itemId: 'grace_amulet', tier: 'rare', weight: 3, min: 1, max: 1 }] }
];

DATA.npcs = [
  { id: 'npc_aster', name: 'Aster Vale', role: 'Harbormaster & tutorial guide', icon: '⚓', x: 18, y: 46, z: 0, zoneId: 'anchorage_harbor', quests: ['Q_01', 'Q_04', 'Q_20'], shop: null, description: 'Offers button-driven guidance and tracks passage readiness.' },
  { id: 'npc_lyra', name: 'Lyra Moss', role: 'Healer & apothecary', icon: '✚', x: 20, y: 47, z: 0, zoneId: 'anchorage_harbor', quests: ['Q_03', 'Q_06', 'Q_11'], shop: 'apothecary', description: 'Sells remedies and restores injured newcomers.' },
  { id: 'npc_nilo', name: 'Nilo Wick', role: 'Lamplighter & spell tutor', icon: '☀', x: 21, y: 45, z: 0, zoneId: 'anchorage_harbor', quests: ['Q_03'], shop: 'magic', description: 'Sells torches, lanterns, potions, and utility instruction.' },
  { id: 'npc_bram', name: 'Bram Hollow', role: 'Cave-haul trader', icon: '⚖', x: 16, y: 35, z: 0, zoneId: 'northroad', quests: ['Q_04'], shop: 'general', description: 'The shortest safe sell route from the Wormburrow rope spot.' },
  { id: 'npc_mira', name: 'Mira Grain', role: 'Miller & baker', icon: '♨', x: 14, y: 45, z: 0, zoneId: 'anchorage_harbor', quests: ['Q_02'], shop: 'bakery', description: 'Operates the millstone and bread oven.' },
  { id: 'npc_edda', name: 'Edda Hearth', role: 'House broker', icon: '⌂', x: 22, y: 39, z: 0, zoneId: 'anchorage_harbor', quests: ['Q_16'], shop: null, description: 'Sells the Tideglass Cottage next door.' },
  { id: 'npc_tovin', name: 'Tovin Peg', role: 'Furniture merchant', icon: '♜', x: 24, y: 38, z: 0, zoneId: 'anchorage_harbor', quests: ['Q_17'], shop: 'furniture', description: 'Every item can be placed in an owned house.' },
  { id: 'npc_orin', name: 'Orin Flint', role: 'Iron Canopy smith', icon: '⚒', x: 41, y: 44, z: 0, zoneId: 'iron_canopy', quests: ['Q_08', 'Q_19'], shop: 'smith', description: 'Trades ore, beams, armor, tools, and bridge work.' },
  { id: 'npc_wren', name: 'Wren Alder', role: 'Canopy scout', icon: '➳', x: 38, y: 48, z: 0, zoneId: 'iron_canopy', quests: ['Q_05', 'Q_09'], shop: 'hunter', description: 'Pays for wolf paws and honeycomb.' },
  { id: 'npc_solenne', name: 'Solenne Reed', role: 'Shrine keeper', icon: '✦', x: 58, y: 46, z: 0, zoneId: 'crucible_reach', quests: ['Q_10', 'Q_14'], shop: 'shrine', description: 'Guards the Shrine of First Light.' },
  { id: 'npc_ferryman', name: 'Ferryman Ivo', role: 'Mainland passage', icon: '⚑', x: 70, y: 45, z: 0, zoneId: 'crucible_reach', quests: ['Q_20'], shop: null, description: 'Accepts the Passage Token and opens the mainland route.' },
  { id: 'npc_sahir', name: 'Sahir Brass', role: 'Sunscour valuables merchant', icon: '◆', x: 79, y: 17, z: 0, zoneId: 'sunscour_market', quests: ['Q_15'], shop: 'desert_merchant', description: 'Buys the level-30 showcase backpack for exactly 1,000 gp.' },
  { id: 'npc_vesper', name: 'Vesper Quill', role: 'Desert archivist', icon: '▤', x: 76, y: 14, z: 0, zoneId: 'sunscour_market', quests: ['Q_19'], shop: 'archive', description: 'Collects expedition logs and sells maps.' }
];

DATA.shops = [
  { id: 'general', name: 'Hollow Haul & Trade', buys: ['worm_hide', 'raw_meat', 'cheese', 'bent_sword', 'sun_mace', 'iron_shield', 'spider_silk', 'giant_fang'], sells: ['rope', 'shovel', 'pickaxe', 'torch', 'apple', 'bread', 'frayed_pack'] },
  { id: 'apothecary', name: 'Moss Remedies', buys: ['venom_gland', 'crypt_fluid', 'radiant_shard'], sells: ['minor_potion', 'mana_potion', 'antidote'] },
  { id: 'magic', name: 'Wick & Wonder', buys: ['radiant_shard', 'spark_wand', 'ember_rune', 'mending_rune'], sells: ['torch', 'lantern', 'mana_potion', 'antidote', 'spark_wand', 'ember_rune', 'mending_rune'] },
  { id: 'bakery', name: 'Grain & Glow', buys: ['wheat', 'flour', 'raw_meat'], sells: ['bread', 'cooked_meat', 'apple'] },
  { id: 'furniture', name: 'Peg & Hearth Furnishings', buys: ['oak_chair', 'reed_bed', 'sea_chest', 'round_table', 'wall_torch', 'woven_rug', 'training_dummy', 'bookcase'], sells: ['oak_chair', 'reed_bed', 'sea_chest', 'round_table', 'wall_torch', 'woven_rug', 'training_dummy', 'bookcase'] },
  { id: 'smith', name: 'Flint Ironworks', buys: ['ironwood_beam', 'bent_sword', 'sun_mace', 'iron_shield'], sells: ['bent_sword', 'plank_shield', 'sun_mace', 'iron_shield', 'pickaxe', 'ringmail'] },
  { id: 'hunter', name: 'Alder Trail Goods', buys: ['wolf_paw', 'honeycomb', 'raw_meat', 'venom_gland', 'shore_bow', 'reed_arrow', 'harbor_spear'], sells: ['rope', 'torch', 'trail_pack', 'trail_boots', 'antidote', 'shore_bow', 'reed_arrow', 'harbor_spear'] },
  { id: 'shrine', name: 'First Light Offerings', buys: ['crypt_fluid', 'radiant_shard'], sells: ['minor_potion', 'mana_potion', 'sun_amulet', 'sacred_relic'] },
  { id: 'desert_merchant', name: 'Brass Exchange', buys: ['sunstone', 'scarab_shell', 'dust_idol', 'spider_silk', 'giant_fang', 'radiant_shard'], sells: ['desert_pack', 'minor_potion', 'mana_potion', 'lantern'] },
  { id: 'archive', name: 'Quill Cartography', buys: ['dust_idol', 'sacred_relic'], sells: ['bookcase', 'lantern', 'rope'] }
];

DATA.houses = [
  { id: 'house_tideglass', name: 'Tideglass Cottage', x: 21, y: 36, z: 0, width: 5, height: 4, town: 'Anchorage Harbor', price: 500, rent: 50, doorX: 23, doorY: 39, ownerCharacterId: null, description: 'A bright starter cottage between the cave trader and furniture shop.' },
  { id: 'house_sunscour', name: 'Saffron Courtyard', x: 83, y: 11, z: 0, width: 6, height: 5, town: 'Sunscour Market', price: 5000, rent: 350, doorX: 85, doorY: 16, ownerCharacterId: null, description: 'A larger sandstone home near the desert market.' }
];

DATA.furniture = DATA.items.filter(item => item.type === 'furniture').map(item => ({ id: item.id, name: item.name, icon: item.icon, buy: item.buy, lightRadius: item.lightRadius || 0, footprint: '1x1', category: item.id.includes('torch') ? 'lighting' : item.id.includes('bed') ? 'comfort' : item.id.includes('dummy') ? 'training' : 'decor' }));

DATA.buildings = [
  { id: 'build_harbor_hall', name: 'Harbor Hall', type: 'civic', x: 16, y: 43, z: 0, width: 5, height: 4, npcIds: ['npc_aster'], collision: 'walls with south door' },
  { id: 'build_mill', name: 'Grain & Glow Mill', type: 'shop', x: 12, y: 42, z: 0, width: 4, height: 4, npcIds: ['npc_mira'], collision: 'walls with east door' },
  { id: 'build_magic_shop', name: 'Wick & Wonder', type: 'shop', x: 20, y: 43, z: 0, width: 4, height: 3, npcIds: ['npc_nilo', 'npc_lyra'], collision: 'walls with south door' },
  { id: 'build_haul_trader', name: 'Hollow Haul & Trade', type: 'shop', x: 13, y: 33, z: 0, width: 5, height: 3, npcIds: ['npc_bram'], collision: 'open counter' },
  { id: 'build_furniture_shop', name: 'Peg & Hearth', type: 'shop', x: 23, y: 35, z: 0, width: 5, height: 4, npcIds: ['npc_tovin'], collision: 'open south door' },
  { id: 'build_tideglass', name: 'Tideglass Cottage', type: 'house', x: 21, y: 36, z: 0, width: 5, height: 4, npcIds: ['npc_edda'], collision: 'owner door' },
  { id: 'build_canopy_smith', name: 'Flint Ironworks', type: 'shop', x: 39, y: 41, z: 0, width: 5, height: 4, npcIds: ['npc_orin'], collision: 'open counter' },
  { id: 'build_desert_exchange', name: 'Brass Exchange', type: 'shop', x: 77, y: 14, z: 0, width: 5, height: 4, npcIds: ['npc_sahir'], collision: 'open west door' },
  { id: 'build_archive', name: 'Vesper Archive', type: 'shop', x: 73, y: 11, z: 0, width: 5, height: 4, npcIds: ['npc_vesper'], collision: 'open south door' }
];

DATA.placements = [
  { id: 'place_rope_cave', type: 'rope_spot', entityId: 'rope_spot', x: 16, y: 40, z: -1, targetX: 16, targetY: 36, targetZ: 0, label: 'Wormburrow rope shaft' },
  { id: 'place_hole_surface', type: 'hole', entityId: 'worm_hole', x: 16, y: 36, z: 0, targetX: 16, targetY: 40, targetZ: -1, label: 'Loose-earth cave hole' },
  { id: 'place_bag_weapons', type: 'ground_bag', entityId: 'haul_bag', x: 17, y: 48, z: -1, profileId: 'char_2', label: 'Bag of swords and maces' },
  { id: 'place_wheat', type: 'harvest', entityId: 'wheat_patch', x: 13, y: 48, z: 0, label: 'Sunwheat patch' },
  { id: 'place_millstone', type: 'craft', entityId: 'millstone', x: 14, y: 44, z: 0, label: 'Millstone' },
  { id: 'place_oven', type: 'craft', entityId: 'bread_oven', x: 15, y: 44, z: 0, label: 'Bread oven' },
  { id: 'place_training_dummy', type: 'training', entityId: 'training_dummy', x: 19, y: 49, z: 0, label: 'Training dummy' },
  { id: 'place_dead_tree', type: 'secret', entityId: 'dead_tree', x: 35, y: 50, z: 0, label: 'Hollow dead tree' },
  { id: 'place_bridge_repair', type: 'bridge', entityId: 'broken_bridge', x: 53, y: 45, z: 0, label: 'Broken Crucible bridge' },
  { id: 'place_shrine', type: 'shrine', entityId: 'light_shrine', x: 59, y: 47, z: 0, label: 'Shrine of First Light' },
  { id: 'place_fallen_scout', type: 'injured_npc', entityId: 'fallen_scout', x: 46, y: 49, z: 0, label: 'Fallen canopy scout' },
  { id: 'place_log_1', type: 'readable', entityId: 'captain_log_1', x: 36, y: 40, z: 0, label: 'Captain’s log I' },
  { id: 'place_log_2', type: 'readable', entityId: 'captain_log_2', x: 64, y: 40, z: 0, label: 'Captain’s log II' },
  { id: 'place_log_3', type: 'readable', entityId: 'captain_log_3', x: 74, y: 22, z: 0, label: 'Captain’s log III' },
  { id: 'place_tara_up_bottom', type: 'stairs_up', entityId: 'stairs', x: 60, y: 15, z: -4, targetX: 60, targetY: 15, targetZ: -3, label: 'Silkfall ascent' },
  { id: 'place_tara_down_3', type: 'stairs_down', entityId: 'stairs', x: 60, y: 15, z: -3, targetX: 60, targetY: 15, targetZ: -4, label: 'Silkfall descent' },
  { id: 'place_tara_up_3', type: 'stairs_up', entityId: 'stairs', x: 64, y: 15, z: -3, targetX: 64, targetY: 15, targetZ: -2, label: 'Silkfall ascent' },
  { id: 'place_tara_down_mid', type: 'stairs_down', entityId: 'stairs', x: 64, y: 15, z: -2, targetX: 64, targetY: 15, targetZ: -3, label: 'Silkfall descent' },
  { id: 'place_tara_up_mid', type: 'stairs_up', entityId: 'stairs', x: 68, y: 15, z: -2, targetX: 68, targetY: 15, targetZ: -1, label: 'Silkfall ascent' },
  { id: 'place_tara_down_1', type: 'stairs_down', entityId: 'stairs', x: 68, y: 15, z: -1, targetX: 68, targetY: 15, targetZ: -2, label: 'Silkfall descent' },
  { id: 'place_tara_up_1', type: 'stairs_up', entityId: 'stairs', x: 70, y: 15, z: -1, targetX: 70, targetY: 15, targetZ: 0, label: 'Silkfall top ascent' },
  { id: 'place_tara_down_top', type: 'stairs_down', entityId: 'stairs', x: 70, y: 15, z: 0, targetX: 70, targetY: 15, targetZ: -1, label: 'Silkfall descent' },
  { id: 'place_cave_exit', type: 'door', entityId: 'silkfall_exit', x: 69, y: 26, z: 0, targetX: 69, targetY: 28, targetZ: 0, label: 'Top-floor south exit' },
  { id: 'place_house_door', type: 'house_door', entityId: 'house_tideglass', x: 23, y: 39, z: 0, label: 'Tideglass Cottage door' }
];

DATA.quests = [
  { id: 'Q_01', name: 'Below the Boardwalk', giverId: 'npc_aster', recommendedLevel: 1, solo: true, prerequisite: [], description: 'Clear three Scavenger Rats from the harbor edge.', objectives: [{ id: 'kill_rats', type: 'kill', targetId: 'mob_scavenger_rat', amount: 3, label: 'Scavenger Rats defeated' }], rewards: { xp: 60, gold: 20, items: [{ id: 'apple', qty: 2 }] } },
  { id: 'Q_02', name: 'Grain, Stone, Flame', giverId: 'npc_mira', recommendedLevel: 1, solo: true, prerequisite: [], description: 'Harvest wheat, grind flour, and bake a loaf.', objectives: [{ id: 'harvest_wheat', type: 'interact', targetId: 'wheat_patch', amount: 1, label: 'Harvest Sunwheat' }, { id: 'mill_flour', type: 'interact', targetId: 'millstone', amount: 1, label: 'Grind flour at the millstone' }, { id: 'bake_bread', type: 'interact', targetId: 'bread_oven', amount: 1, label: 'Bake a Millstone Loaf' }], rewards: { xp: 75, gold: 12, items: [{ id: 'bread', qty: 4 }] } },
  { id: 'Q_03', name: 'A Light Below', giverId: 'npc_nilo', recommendedLevel: 1, solo: true, prerequisite: [], description: 'Equip a torch and cast Kindlelight inside a cave.', objectives: [{ id: 'use_torch', type: 'use', targetId: 'torch', amount: 1, label: 'Light a Pitchwood Torch' }, { id: 'cast_light', type: 'cast', targetId: 'light_orb', amount: 1, label: 'Cast Kindlelight below ground' }], rewards: { xp: 90, gold: 15, items: [{ id: 'torch', qty: 3 }] } },
  { id: 'Q_04', name: 'The Rope Remembers', giverId: 'npc_aster', recommendedLevel: 2, solo: true, prerequisite: ['Q_01'], description: 'Descend the Wormburrow and use a rope or Ropecall to return.', objectives: [{ id: 'visit_worm', type: 'visit', targetId: 'wormburrow', amount: 1, label: 'Enter Wormburrow' }, { id: 'rope_out', type: 'interact', targetId: 'rope_spot', amount: 1, label: 'Rope up to Bram’s trader' }], rewards: { xp: 120, gold: 30, items: [{ id: 'rope', qty: 1 }] } },
  { id: 'Q_05', name: 'Paws in the Ferns', giverId: 'npc_wren', recommendedLevel: 4, solo: true, prerequisite: [], description: 'Cull Timber Wolves and bring their paws to Wren.', objectives: [{ id: 'kill_wolves', type: 'kill', targetId: 'mob_timber_wolf', amount: 5, label: 'Timber Wolves defeated' }, { id: 'collect_paws', type: 'collect', targetId: 'wolf_paw', amount: 5, label: 'Frostwolf Paws collected' }], rewards: { xp: 300, gold: 65, items: [{ id: 'sun_amulet', qty: 1 }] } },
  { id: 'Q_06', name: 'Green in the Veins', giverId: 'npc_lyra', recommendedLevel: 4, solo: true, prerequisite: [], description: 'Experience poison, then cleanse it with an antidote or Clearblood.', objectives: [{ id: 'poisoned', type: 'status', targetId: 'poison', amount: 1, label: 'Become poisoned' }, { id: 'cured', type: 'cure', targetId: 'poison', amount: 1, label: 'Cure the poison' }], rewards: { xp: 180, gold: 25, items: [{ id: 'antidote', qty: 3 }] } },
  { id: 'Q_07', name: 'The Hollow Gives', giverId: 'npc_wren', recommendedLevel: 4, solo: true, prerequisite: [], description: 'Search the dead tree on the western Iron Canopy shore.', objectives: [{ id: 'dead_tree', type: 'interact', targetId: 'dead_tree', amount: 1, label: 'Search the hollow tree' }], rewards: { xp: 160, gold: 0, items: [{ id: 'iron_shield', qty: 1 }] } },
  { id: 'Q_08', name: 'Three Beams to Dawn', giverId: 'npc_orin', recommendedLevel: 5, solo: true, prerequisite: [], description: 'Collect Ironwood Beams and repair the Crucible bridge.', objectives: [{ id: 'collect_beams', type: 'collect', targetId: 'ironwood_beam', amount: 3, label: 'Ironwood Beams collected' }, { id: 'repair_bridge', type: 'interact', targetId: 'broken_bridge', amount: 1, label: 'Repair the Crucible bridge' }], rewards: { xp: 450, gold: 80, items: [{ id: 'ringmail', qty: 1 }] } },
  { id: 'Q_09', name: 'Amber Wings', giverId: 'npc_wren', recommendedLevel: 7, solo: true, prerequisite: [], description: 'Harvest honeycomb from Killer Wasps without becoming trapped.', objectives: [{ id: 'kill_wasps', type: 'kill', targetId: 'mob_killer_wasp', amount: 3, label: 'Killer Wasps defeated' }, { id: 'honeycomb', type: 'collect', targetId: 'honeycomb', amount: 3, label: 'Amber Honeycomb collected' }], rewards: { xp: 550, gold: 110, items: [{ id: 'haste_charm', qty: 0 }] } },
  { id: 'Q_10', name: 'Quiet the Bone Choir', giverId: 'npc_solenne', recommendedLevel: 8, solo: true, prerequisite: [], description: 'Destroy Crypt Scrappers and recover luminous fluid.', objectives: [{ id: 'kill_crypt', type: 'kill', targetId: 'mob_crypt_scrapper', amount: 8, label: 'Crypt Scrappers defeated' }, { id: 'crypt_fluid', type: 'collect', targetId: 'crypt_fluid', amount: 2, label: 'Luminous Crypt Fluid collected' }], rewards: { xp: 700, gold: 130, items: [{ id: 'sacred_relic', qty: 1 }] } },
  { id: 'Q_11', name: 'The Scout Breathes', giverId: 'npc_lyra', recommendedLevel: 6, solo: true, prerequisite: [], description: 'Find the fallen scout and restore them with a healing spell or tonic.', objectives: [{ id: 'heal_scout', type: 'interact', targetId: 'fallen_scout', amount: 1, label: 'Restore the fallen scout' }], rewards: { xp: 320, gold: 55, items: [{ id: 'minor_potion', qty: 3 }] } },
  { id: 'Q_12', name: 'Five Sparks of Zeal', giverId: 'npc_aster', recommendedLevel: 1, solo: true, prerequisite: [], vocationFocus: 'warhealer', description: 'Build five Zeal on the training dummy; other vocations may train five weapon strikes.', objectives: [{ id: 'dummy_hits', type: 'interact', targetId: 'training_dummy', amount: 5, label: 'Training strikes landed' }], rewards: { xp: 220, gold: 30, items: [{ id: 'minor_potion', qty: 2 }] } },
  { id: 'Q_13', name: 'Steel Carries Storm', giverId: 'npc_orin', recommendedLevel: 12, solo: true, prerequisite: [], vocationFocus: 'battlemage', description: 'Strike an enemy with Spellweave Cut, or use an elemental combat spell.', objectives: [{ id: 'blade_weave', type: 'cast_group', targetId: 'elemental_attack', amount: 3, label: 'Elemental weapon spells cast' }], rewards: { xp: 430, gold: 70, items: [{ id: 'mana_potion', qty: 3 }] } },
  { id: 'Q_14', name: 'The Weight of Light', giverId: 'npc_solenne', recommendedLevel: 18, solo: true, prerequisite: [], vocationFocus: 'priest', description: 'Bless the shrine with the Tideworn Reliquary and restore yourself nearby.', objectives: [{ id: 'bless_shrine', type: 'interact', targetId: 'light_shrine', amount: 1, label: 'Bless the Shrine of First Light' }, { id: 'holy_heal', type: 'cast_group', targetId: 'healing', amount: 1, label: 'Cast a healing spell' }], rewards: { xp: 620, gold: 90, items: [{ id: 'grace_amulet', qty: 1 }] } },
  { id: 'Q_15', name: 'A Thousand in the Sun', giverId: 'npc_sahir', recommendedLevel: 30, solo: true, prerequisite: [], description: 'Sell valuables worth a total of 1,000 gp at the Brass Exchange.', objectives: [{ id: 'sell_1000', type: 'sell_value', targetId: 'desert_merchant', amount: 1000, label: 'Gold value sold to Sahir' }], rewards: { xp: 1000, gold: 100, items: [] } },
  { id: 'Q_16', name: 'A Door of Your Own', giverId: 'npc_edda', recommendedLevel: 12, solo: true, prerequisite: [], description: 'Purchase Tideglass Cottage for 500 gp.', objectives: [{ id: 'buy_house', type: 'own', targetId: 'house_tideglass', amount: 1, label: 'Own Tideglass Cottage' }], rewards: { xp: 500, gold: 0, items: [{ id: 'oak_chair', qty: 1 }] } },
  { id: 'Q_17', name: 'Make It a Home', giverId: 'npc_tovin', recommendedLevel: 12, solo: true, prerequisite: ['Q_16'], description: 'Buy or receive furniture, enter your cottage, and place it.', objectives: [{ id: 'place_furniture', type: 'place', targetId: 'furniture', amount: 1, label: 'Furniture placed in your house' }], rewards: { xp: 380, gold: 45, items: [{ id: 'wall_torch', qty: 1 }] } },
  { id: 'Q_18', name: 'Silk Above, Silk Below', giverId: 'npc_vesper', recommendedLevel: 50, solo: true, prerequisite: [], description: 'Climb two floors up and two down from the middle, defeating both Brood Tyrants.', objectives: [{ id: 'top_tyrant', type: 'kill', targetId: 'boss_brood_tyrant_top', amount: 1, label: 'Top-floor Brood Tyrant defeated' }, { id: 'bottom_tyrant', type: 'kill', targetId: 'boss_brood_tyrant_bottom', amount: 1, label: 'Bottom-floor Brood Tyrant defeated' }, { id: 'exit_south', type: 'interact', targetId: 'silkfall_exit', amount: 1, label: 'Leave through the top south exit' }], rewards: { xp: 5000, gold: 700, items: [{ id: 'giant_fang', qty: 2 }] } },
  { id: 'Q_19', name: 'Pages Along the Road', giverId: 'npc_vesper', recommendedLevel: 8, solo: true, prerequisite: [], description: 'Read all three expedition logs from Canopy to Sunscour.', objectives: [{ id: 'log_1', type: 'interact', targetId: 'captain_log_1', amount: 1, label: 'Read expedition log I' }, { id: 'log_2', type: 'interact', targetId: 'captain_log_2', amount: 1, label: 'Read expedition log II' }, { id: 'log_3', type: 'interact', targetId: 'captain_log_3', amount: 1, label: 'Read expedition log III' }], rewards: { xp: 800, gold: 120, items: [{ id: 'bookcase', qty: 1 }] } },
  { id: 'Q_20', name: 'The Dawnreach Rite', giverId: 'npc_ferryman', recommendedLevel: 8, solo: true, prerequisite: ['Q_08'], description: 'Defeat the Brute Mystic, claim its Passage Token, and return to Ferryman Ivo.', objectives: [{ id: 'mystic', type: 'kill', targetId: 'mob_brute_mystic', amount: 1, label: 'Brute Mystic defeated' }, { id: 'token', type: 'collect', targetId: 'passage_token', amount: 1, label: 'Passage Token recovered' }, { id: 'ferry', type: 'interact', targetId: 'npc_ferryman', amount: 1, label: 'Present the token to Ivo' }], rewards: { xp: 2500, gold: 250, items: [{ id: 'lantern', qty: 1 }] } }
];

// -----------------------------------------------------------------------------
// THE GREAT MAINLAND EXPANSION
// This keeps the hand-authored Dawnreach onboarding intact while expanding the
// explorable surface to 256×192 tiles and adding seven towns, six deep dungeon
// complexes, field landmarks, hunting regions, shops, and quest lines.
// -----------------------------------------------------------------------------

DATA.zones.push(
  { id: 'greenhollow_vale', name: 'Greenhollow Vale', floor: 0, minLevel: 12, maxLevel: 28, danger: 'low', pz: false, bounds: 'x75–115, y40–75', biome: 'Ancient broadleaf forest', description: 'A broad forest of clearings, lumber camps, faun stones, and Underroot entrances.' },
  { id: 'greenhollow_town', name: 'Greenhollow', floor: 0, minLevel: 1, maxLevel: 200, danger: 'safe', pz: true, bounds: 'x91–103, y51–63', biome: 'Forest town', description: 'Timber-framed town with a sawmill, inn, herbalist, ranger lodge, market, and depot.' },
  { id: 'underroot_deeps', name: 'Underroot Deeps', floor: -1, minLevel: 22, maxLevel: 58, danger: 'high', pz: false, bounds: 'x91–122, y45–73, z-1 to z-6', biome: 'Rootbound cavern', description: 'Six underground levels twisting beneath Greenhollow.' },
  { id: 'mirewatch_fen', name: 'Mirewatch Fen', floor: 0, minLevel: 28, maxLevel: 52, danger: 'medium', pz: false, bounds: 'x105–151, y70–105', biome: 'Luminous marsh', description: 'Boardwalks, reed islands, flooded ruins, and dangerous night fauna.' },
  { id: 'mirewatch_town', name: 'Mirewatch', floor: 0, minLevel: 1, maxLevel: 200, danger: 'safe', pz: true, bounds: 'x116–129, y81–93', biome: 'Stilt town', description: 'A raised settlement of alchemists, eel fishers, ferrymen, and relic hunters.' },
  { id: 'drowned_catacombs', name: 'Drowned Catacombs', floor: -1, minLevel: 40, maxLevel: 82, danger: 'high', pz: false, bounds: 'x112–145, y76–104, z-1 to z-5', biome: 'Flooded tomb', description: 'Five flooded burial tiers ending at the Bell of the Drowned Court.' },
  { id: 'stoneheart_highlands', name: 'Stoneheart Highlands', floor: 0, minLevel: 45, maxLevel: 75, danger: 'high', pz: false, bounds: 'x145–193, y28–70', biome: 'Mountain plateau', description: 'Quarries, cliff roads, gryphon nests, and abandoned siege keeps.' },
  { id: 'stoneheart_bastion', name: 'Stoneheart Bastion', floor: 0, minLevel: 1, maxLevel: 200, danger: 'safe', pz: true, bounds: 'x160–174, y43–55', biome: 'Fortified city', description: 'A large walled city with guild halls, armorers, artillery yards, and deep mines.' },
  { id: 'emberdeep_mines', name: 'Emberdeep Mines', floor: -1, minLevel: 55, maxLevel: 105, danger: 'high', pz: false, bounds: 'x151–188, y88–118, z-1 to z-7', biome: 'Volcanic mine', description: 'Seven increasingly hot levels filled with ore seams and living furnace beasts.' },
  { id: 'frostmarch', name: 'Frostmarch', floor: 0, minLevel: 65, maxLevel: 105, danger: 'high', pz: false, bounds: 'x187–247, y7–61', biome: 'Snowfield and glacier', description: 'Wind-cut tundra surrounding Frostgate and the eight-level ice vault.' },
  { id: 'frostgate', name: 'Frostgate', floor: 0, minLevel: 1, maxLevel: 200, danger: 'safe', pz: true, bounds: 'x204–218, y29–42', biome: 'Glacial city', description: 'A heated stone city offering furs, runes, sled mounts, and cold-weather equipment.' },
  { id: 'frostvault', name: 'Frostvault', floor: -1, minLevel: 80, maxLevel: 140, danger: 'boss', pz: false, bounds: 'x195–229, y22–53, z-1 to z-8', biome: 'Ancient ice vault', description: 'Eight descending vaults built around a frozen star.' },
  { id: 'emberwild_savanna', name: 'Emberwild Savanna', floor: 0, minLevel: 55, maxLevel: 95, danger: 'high', pz: false, bounds: 'x151–210, y76–128', biome: 'Red-grass savanna', description: 'Open hunting country with stampedes, raider camps, and charred baobabs.' },
  { id: 'emberfall', name: 'Emberfall', floor: 0, minLevel: 1, maxLevel: 200, danger: 'safe', pz: true, bounds: 'x168–181, y98–111', biome: 'Savanna city', description: 'A red-stone trading city known for beast gear, food markets, and caravan contracts.' },
  { id: 'starfall_basin', name: 'Starfall Basin', floor: 0, minLevel: 70, maxLevel: 115, danger: 'high', pz: false, bounds: 'x72–116, y108–151', biome: 'Crater lakes and crystal scrub', description: 'A meteor-scarred basin containing observatories and resonant crystal beasts.' },
  { id: 'starfall_crossing', name: 'Starfall Crossing', floor: 0, minLevel: 1, maxLevel: 200, danger: 'safe', pz: true, bounds: 'x87–100, y124–136', biome: 'Observatory town', description: 'A scholarly crossroads with rune shops, telescope towers, and caravan services.' },
  { id: 'coralreach_isles', name: 'Coralreach Isles', floor: 0, minLevel: 38, maxLevel: 75, danger: 'medium', pz: false, bounds: 'x20–78, y112–160', biome: 'Tropical islands', description: 'A southern island chain of beaches, reefs, pirate ruins, and sinkholes.' },
  { id: 'coralhaven', name: 'Coralhaven', floor: 0, minLevel: 1, maxLevel: 200, danger: 'safe', pz: true, bounds: 'x45–59, y130–143', biome: 'Island port', description: 'A lively port with fisheries, shipwrights, treasure maps, and furniture imports.' },
  { id: 'coral_grotto', name: 'Coral Grotto', floor: -1, minLevel: 45, maxLevel: 88, danger: 'high', pz: false, bounds: 'x34–72, y119–152, z-1 to z-4', biome: 'Tidal cavern', description: 'Four submerged-looking but walkable cavern tiers beneath Coralhaven.' },
  { id: 'nightglass_waste', name: 'Nightglass Waste', floor: 0, minLevel: 105, maxLevel: 170, danger: 'extreme', pz: false, bounds: 'x188–249, y125–183', biome: 'Obsidian desert', description: 'Black dunes, glass storms, abyssal towers, and the hardest surface hunting in the chapter.' },
  { id: 'nightglass_refuge', name: 'Nightglass Refuge', floor: 0, minLevel: 1, maxLevel: 200, danger: 'safe', pz: true, bounds: 'x212–226, y148–161', biome: 'Obsidian refuge', description: 'The last safe settlement before the abyss, stocked for endgame expeditions.' },
  { id: 'blackglass_abyss', name: 'Blackglass Abyss', floor: -1, minLevel: 125, maxLevel: 220, danger: 'boss', pz: false, bounds: 'x203–240, y138–176, z-1 to z-8', biome: 'Abyssal glass dungeon', description: 'Eight brutal floors culminating at the World Mirror.' },
  { id: 'silverriver', name: 'Silverriver Corridor', floor: 0, minLevel: 20, maxLevel: 80, danger: 'medium', pz: false, bounds: 'winding north-south river', biome: 'Riverbanks and bridges', description: 'A navigational spine with three major bridges, fishing camps, and ambush sites.' }
);

const expansionItems = [
  ['moonleaf', 'Moonleaf Bundle', '❧', '#87d89b', 'material', 18, 1], ['root_amber', 'Root Amber', '◆', '#d59a55', 'material', 32, .7], ['fen_eel', 'Silver Fen Eel', '∿', '#71b6bf', 'food', 24, 3],
  ['bog_pearl', 'Bog Pearl', '●', '#a1d6bc', 'loot', 55, .4], ['grave_reed', 'Grave Reed', '〽', '#839a75', 'material', 28, 1], ['highland_ore', 'Highland Iron Ore', '⬟', '#9ea5a2', 'material', 40, 5],
  ['gryphon_feather', 'Gryphon Flight Feather', '⌁', '#d5cda8', 'loot', 70, .4], ['ember_ore', 'Ember Ore', '⬢', '#de7650', 'material', 65, 6], ['furnace_core', 'Furnace Core', '◉', '#ff7b4c', 'loot', 120, 4],
  ['winter_pelt', 'Winter Pelt', '▰', '#dce4e3', 'material', 85, 4], ['star_ice', 'Star Ice', '◆', '#8ed8ef', 'loot', 140, 2], ['savanna_hide', 'Sunmane Hide', '▰', '#c8874c', 'material', 72, 5],
  ['red_salt', 'Red Savanna Salt', '⁙', '#dc8066', 'material', 46, 1], ['meteor_glass', 'Meteor Glass', '◇', '#8ab2df', 'loot', 115, 2], ['resonant_crystal', 'Resonant Crystal', '◆', '#ac8ce0', 'material', 90, 2],
  ['coral_chunk', 'Living Coral Chunk', '♧', '#ef7c7c', 'material', 52, 3], ['pirate_medal', 'Salt-Cut Pirate Medal', '❖', '#d6b85d', 'loot', 95, .4], ['tide_pearl', 'Tide Pearl', '●', '#dcecd9', 'loot', 135, .5],
  ['nightglass_shard', 'Nightglass Shard', '◆', '#9b76c9', 'material', 180, 2], ['abyss_scale', 'Abyss Scale', '⬟', '#6b5987', 'loot', 260, 4], ['mirror_fragment', 'World Mirror Fragment', '◇', '#d9c7f0', 'loot', 500, 1],
  ['greater_tonic', 'Crimson Restoration Flask', '⚗', '#e35f65', 'potion', 22, 2], ['greater_mana', 'Deep-Azure Mana Flask', '⚗', '#4b9ee4', 'potion', 24, 2], ['focus_elixir', 'Gilded Focus Elixir', '⚗', '#e4c65d', 'potion', 38, 2],
  ['coldward_draught', 'Coldward Draught', '⚗', '#82cce3', 'potion', 42, 2], ['fireward_draught', 'Fireward Draught', '⚗', '#e58558', 'potion', 42, 2], ['glassward_draught', 'Glassward Draught', '⚗', '#ac88d0', 'potion', 65, 2],
  ['fishing_rod', 'Silverriver Fishing Rod', '⌁', '#a98a5c', 'tool', 18, 16], ['woodcut_axe', 'Greenhollow Felling Axe', '⚒', '#8eaa72', 'tool', 24, 28], ['mining_drill', 'Emberdeep Hand Drill', '⚙', '#d47750', 'tool', 48, 45],
  ['tide_compass', 'Coralhaven Tide Compass', '⌖', '#72c4c2', 'tool', 55, 2], ['climbing_hooks', 'Highland Climbing Hooks', '⌁', '#b0aaa0', 'tool', 30, 12], ['snow_lantern', 'Frostgate Blue Lantern', '⌑', '#8fd9ef', 'light', 48, 14]
].map(([id, name, icon, color, type, sell, weight]) => ({ id, name, icon, color, type, weight, buy: Math.max(1, sell * 4), sell, stackable: ['material', 'loot', 'food', 'potion'].includes(type), heal: id === 'greater_tonic' ? 320 : id === 'fen_eel' ? 70 : 0, mana: id === 'greater_mana' ? 360 : 0, lightRadius: id === 'snow_lantern' ? 12 : 0, description: `${name}, sourced from the expanded mainland.` }));

const expansionGear = [
  ['rootwarden_helm', 'Rootwarden Helm', 'head', '⌂', '#759766', 12, 0, 0, 750], ['rootwarden_mail', 'Rootwarden Mail', 'body', '♙', '#6e8b61', 18, 0, 0, 1250], ['rootblade', 'Amber-Root Blade', 'weapon', '⚔', '#d29b57', 0, 38, 0, 1600], ['rootguard', 'Living Bark Guard', 'shield', '◈', '#8a6c49', 0, 0, 28, 1400],
  ['fen_cowl', 'Fen-Seer Cowl', 'head', '⌂', '#6fa99b', 16, 0, 0, 1800], ['fen_robe', 'Fen-Seer Robe', 'body', '♙', '#64968d', 24, 0, 0, 2800], ['reed_spear', 'Silverreed Spear', 'weapon', '➶', '#86bfc0', 0, 51, 0, 3200], ['bog_tome', 'Boglight Tome', 'shield', '▤', '#83bca8', 0, 0, 36, 3000],
  ['highland_visor', 'Highland Siege Visor', 'head', '⌂', '#9b9991', 22, 0, 0, 4200], ['highland_plate', 'Highland Siege Plate', 'body', '♙', '#8f8e89', 34, 0, 0, 6800], ['gryphon_bow', 'Gryphon-Wing Bow', 'weapon', '➳', '#d2bf82', 0, 69, 0, 7600], ['cliffwall', 'Cliffwall Shield', 'shield', '◈', '#9c927b', 0, 0, 49, 7200],
  ['frost_crown', 'Starfrost Crown', 'head', '⌂', '#8fcde3', 30, 0, 0, 10500], ['frost_mantle', 'Starfrost Mantle', 'body', '♙', '#8abfd1', 45, 0, 0, 16000], ['icebrand', 'Frozen-Star Brand', 'weapon', '⚔', '#72d2ef', 0, 88, 0, 19000], ['vault_aegis', 'Frostvault Aegis', 'shield', '◈', '#91d6e8', 0, 0, 65, 17500],
  ['embermane_helm', 'Embermane Helm', 'head', '⌂', '#d8794d', 38, 0, 0, 17000], ['embermane_plate', 'Embermane Plate', 'body', '♙', '#ca6e49', 57, 0, 0, 26000], ['sunmaul', 'Savanna Sunmaul', 'weapon', '⚒', '#e29a4e', 0, 103, 0, 31000], ['caravan_bulwark', 'Caravan Bulwark', 'shield', '◈', '#b87848', 0, 0, 78, 28500],
  ['nightglass_mask', 'Nightglass Mask', 'head', '⌂', '#8063a6', 52, 0, 0, 48000], ['nightglass_carapace', 'Nightglass Carapace', 'body', '♙', '#745790', 76, 0, 0, 72000], ['mirror_scythe', 'World-Mirror Scythe', 'weapon', '☽', '#b593d8', 0, 138, 0, 90000], ['abyss_mantlet', 'Abyss Mantlet', 'shield', '◈', '#6a527f', 0, 0, 104, 82000]
].map(([id, name, slot, icon, color, armor, attack, defense, buy]) => ({ id, name, type: slot === 'weapon' ? 'weapon' : slot === 'shield' ? 'shield' : 'armor', slot, icon, color, armor, attack, defense, weight: slot === 'body' ? 60 : slot === 'weapon' || slot === 'shield' ? 48 : 26, buy, sell: Math.floor(buy / 4), weaponSkill: slot === 'weapon' ? (id.includes('bow') || id.includes('spear') ? 'distance' : id.includes('maul') ? 'clubcraft' : 'swordsmanship') : undefined, description: `${name}, an advanced mainland equipment piece.` }));

const expansionFurniture = [
  ['canopy_bed', 'Greenhollow Canopy Bed', '▬', 280], ['herb_rack', 'Hanging Herb Rack', '♧', 140], ['fen_aquarium', 'Fenlight Aquarium', '▣', 420], ['stilt_table', 'Mirewatch Stilt Table', '●', 190],
  ['stone_throne', 'Stoneheart Throne', '♜', 680], ['weapon_rack', 'Highland Weapon Rack', '‡', 330], ['frost_brazier', 'Frostgate Blue Brazier', '♨', 520], ['ice_sculpture', 'Carved Ice Gryphon', '♞', 740],
  ['caravan_cot', 'Emberfall Caravan Cot', '▬', 250], ['star_telescope', 'Starfall House Telescope', '⌕', 950], ['coral_fountain', 'Living Coral Fountain', '♒', 860], ['nightglass_pedestal', 'Nightglass Display Pedestal', '◆', 1200]
].map(([id, name, icon, buy]) => ({ id, name, type: 'furniture', icon, color: '#d8b56b', weight: 45, buy, sell: Math.floor(buy / 4), placeable: true, lightRadius: id.includes('brazier') ? 10 : 0, description: `${name}, placeable in any owned house.` }));

DATA.items.push(...expansionItems, ...expansionGear, ...expansionFurniture);
DATA.furniture.push(...expansionFurniture.map(item => ({
  id: item.id, name: item.name, icon: item.icon, buy: item.buy,
  lightRadius: item.lightRadius || 0, footprint: '1x1',
  category: item.id.includes('brazier') ? 'lighting' : item.id.includes('bed') || item.id.includes('cot') ? 'comfort' : 'decor'
})));

const newMonsterRows = [
  ['mob_brambleling', 'Brambleling', '♧', 14, 240, 30, 12, 420, 'earth', 'greenhollow_vale'], ['mob_bark_stag', 'Bark Stag', '♈', 17, 330, 38, 15, 560, 'physical', 'greenhollow_vale'], ['mob_moon_owl', 'Moon Owl', '♢', 19, 275, 44, 13, 610, 'energy', 'greenhollow_vale'], ['mob_root_guardian', 'Root Guardian', '♜', 25, 620, 58, 30, 1100, 'earth', 'underroot_deeps'],
  ['mob_fen_leech', 'Fen Leech', '∿', 29, 430, 59, 18, 970, 'poison', 'mirewatch_fen'], ['mob_reed_witch', 'Reed Witch', '♛', 34, 510, 72, 22, 1280, 'earth', 'mirewatch_fen'], ['mob_bog_lurker', 'Bog Lurker', '♣', 38, 760, 82, 35, 1700, 'physical', 'mirewatch_fen'], ['mob_drowned_guard', 'Drowned Guard', '☠', 46, 980, 96, 44, 2400, 'death', 'drowned_catacombs'],
  ['mob_cliff_ram', 'Cliff Ram', '♈', 45, 850, 88, 42, 2100, 'physical', 'stoneheart_highlands'], ['mob_granite_golem', 'Granite Golem', '♜', 53, 1400, 112, 72, 3500, 'earth', 'stoneheart_highlands'], ['mob_gryphon', 'Highland Gryphon', '♞', 59, 1120, 128, 55, 3900, 'energy', 'stoneheart_highlands'], ['mob_keep_revenant', 'Keep Revenant', '☠', 67, 1550, 146, 78, 5200, 'death', 'stoneheart_highlands'],
  ['mob_cinder_mole', 'Cinder Mole', '♣', 58, 920, 122, 50, 3300, 'fire', 'emberdeep_mines'], ['mob_ore_elemental', 'Ore Elemental', '⬢', 66, 1600, 145, 85, 5200, 'earth', 'emberdeep_mines'], ['mob_furnace_hound', 'Furnace Hound', '♞', 74, 1380, 168, 64, 6100, 'fire', 'emberdeep_mines'], ['mob_magma_colossus', 'Magma Colossus', '♜', 92, 3100, 220, 128, 12800, 'fire', 'emberdeep_mines'],
  ['mob_snow_jackal', 'Snow Jackal', '♢', 68, 1050, 148, 48, 4800, 'ice', 'frostmarch'], ['mob_rime_troll', 'Rime Troll', '♟', 77, 1750, 180, 82, 7200, 'ice', 'frostmarch'], ['mob_ice_wyrm', 'Ice Wyrm', '∿', 89, 2400, 218, 104, 10500, 'ice', 'frostvault'], ['mob_frozen_oracle', 'Frozen Oracle', '♛', 104, 2800, 254, 120, 14500, 'energy', 'frostvault'],
  ['mob_sunmane_lion', 'Sunmane Lion', '♌', 60, 1180, 132, 52, 4100, 'physical', 'emberwild_savanna'], ['mob_redhorn_rhino', 'Redhorn Rhino', '♉', 70, 2200, 176, 100, 6800, 'physical', 'emberwild_savanna'], ['mob_dust_shaman', 'Dust Shaman', '♛', 78, 1650, 198, 76, 7900, 'fire', 'emberwild_savanna'], ['mob_caravan_reaver', 'Caravan Reaver', '♞', 85, 1900, 214, 88, 9100, 'physical', 'emberwild_savanna'],
  ['mob_crystal_crab', 'Crystal Crab', '♋', 72, 1500, 165, 92, 6400, 'earth', 'starfall_basin'], ['mob_star_moth', 'Star Moth', '✥', 80, 1280, 194, 64, 7200, 'energy', 'starfall_basin'], ['mob_crater_behemoth', 'Crater Behemoth', '♜', 96, 3400, 242, 138, 13200, 'physical', 'starfall_basin'],
  ['mob_reef_crawler', 'Reef Crawler', '♋', 42, 720, 92, 40, 1900, 'physical', 'coralreach_isles'], ['mob_salt_corsair', 'Salt Corsair', '⚔', 50, 940, 118, 48, 2800, 'physical', 'coralreach_isles'], ['mob_tide_serpent', 'Tide Serpent', '∿', 63, 1500, 154, 62, 4800, 'ice', 'coral_grotto'],
  ['mob_glass_scorpion', 'Glass Scorpion', '♏', 112, 2600, 276, 112, 15500, 'poison', 'nightglass_waste'], ['mob_void_jackal', 'Void Jackal', '♢', 124, 2900, 304, 120, 18500, 'death', 'nightglass_waste'], ['mob_mirror_wraith', 'Mirror Wraith', '♛', 145, 4200, 352, 168, 28000, 'death', 'blackglass_abyss'], ['mob_abyss_drake', 'Abyss Drake', '♜', 170, 6800, 430, 220, 48000, 'fire', 'blackglass_abyss'],
  ['boss_underroot_heart', 'Heart Below Roots', '✿', 58, 5200, 178, 110, 22000, 'earth', 'underroot_deeps'], ['boss_drowned_bell', 'Bell-Keeper of Mirewatch', '♛', 82, 7200, 228, 142, 31000, 'death', 'drowned_catacombs'], ['boss_frozen_star', 'The Frozen Star', '✦', 140, 12500, 365, 205, 72000, 'ice', 'frostvault'], ['boss_world_mirror', 'The World Mirror', '◇', 220, 24000, 560, 310, 180000, 'death', 'blackglass_abyss']
].map(([id, name, icon, level, hp, attack, defense, xp, element, zone]) => ({ id, name, icon, level, hp, attack, defense, xp, speed: id.includes('jackal') || id.includes('owl') ? 1.25 : id.includes('golem') || id.includes('colossus') ? .7 : 1, range: ['energy', 'death'].includes(element) ? 5 : 1, aggro: 7, element, zone, traits: `${zone.replaceAll('_', ' ')} hunter`, color: element === 'fire' ? '#e27b50' : element === 'ice' ? '#86cfe6' : element === 'death' ? '#a279c3' : element === 'earth' ? '#7da16b' : '#c0ad8c', boss: id.startsWith('boss_'), dot: element === 'poison' ? Math.ceil(level / 10) : 0 }));
DATA.monsters.push(...newMonsterRows);

const towns = [
  { id: 'greenhollow', name: 'Greenhollow', x: 96, y: 57, zoneId: 'greenhollow_town', shops: ['green_provisions', 'green_woodworks', 'green_armory', 'green_apothecary'], npcs: [['warden', 'Warden Elowen', 'Town warden', '⚑'], ['merchant', 'Perrin Moss', 'Forest merchant', '⚖'], ['herbalist', 'Sera Moonleaf', 'Herbalist', '❧'], ['delver', 'Old Root Marr', 'Underroot delver', '⌄'], ['innkeeper', 'Tamsin Hearth', 'Innkeeper', '⌂']] },
  { id: 'mirewatch', name: 'Mirewatch', x: 122, y: 87, zoneId: 'mirewatch_town', shops: ['fen_market', 'fen_alchemy', 'fen_fishery', 'fen_relics'], npcs: [['reeve', 'Reeve Ossa', 'Boardwalk reeve', '⚑'], ['alchemist', 'Kel Fen', 'Fen alchemist', '⚗'], ['fisher', 'Neri Eelhand', 'Fisher', '∿'], ['relic', 'Sister Brine', 'Catacomb keeper', '✦'], ['boatman', 'Doro Pike', 'Boatman', '⚓']] },
  { id: 'stoneheart', name: 'Stoneheart Bastion', x: 167, y: 49, zoneId: 'stoneheart_bastion', shops: ['stone_armory', 'stone_tools', 'stone_artillery', 'stone_market'], npcs: [['marshal', 'Marshal Kael', 'Bastion marshal', '♜'], ['smith', 'Varda Anvil', 'Master smith', '⚒'], ['gunner', 'Bombardier Pell', 'Artillery tutor', '☄'], ['climber', 'Rusk Highstep', 'Cliff guide', '⌁'], ['quartermaster', 'Mina Slate', 'Quartermaster', '▣']] },
  { id: 'frostgate', name: 'Frostgate', x: 211, y: 35, zoneId: 'frostgate', shops: ['frost_furs', 'frost_runes', 'frost_provisions', 'frost_mounts'], npcs: [['thane', 'Thane Isolde', 'Frostgate thane', '♛'], ['furrier', 'Yorr Whitepelt', 'Furrier', '▰'], ['runekeeper', 'Astra Rime', 'Rune keeper', '✧'], ['vaultkeeper', 'Eirik Starlock', 'Vault keeper', '⚿'], ['cook', 'Mara Broth', 'Winter cook', '♨']] },
  { id: 'emberfall', name: 'Emberfall', x: 174, y: 104, zoneId: 'emberfall', shops: ['ember_beastgear', 'ember_food', 'ember_oretrade', 'ember_caravan'], npcs: [['speaker', 'Speaker Jali', 'City speaker', '⚑'], ['beastmaster', 'Oru Sunmane', 'Beast master', '♌'], ['chef', 'Kavi Redpot', 'Market chef', '♨'], ['miner', 'Del Emberhand', 'Mine foreman', '⚒'], ['caravaner', 'Tala Roads', 'Caravan master', '♞']] },
  { id: 'starfall', name: 'Starfall Crossing', x: 93, y: 130, zoneId: 'starfall_crossing', shops: ['star_runes', 'star_lenses', 'star_market', 'star_furniture'], npcs: [['provost', 'Provost Lumen', 'Observatory provost', '✦'], ['astronomer', 'Cira Lens', 'Astronomer', '⌕'], ['runewright', 'Toren Chime', 'Runewright', '◆'], ['merchant', 'Una Crossing', 'Crossroads merchant', '⚖'], ['builder', 'Pavo Brass', 'Instrument maker', '⚙']] },
  { id: 'coralhaven', name: 'Coralhaven', x: 52, y: 136, zoneId: 'coralhaven', shops: ['coral_fishery', 'coral_treasure', 'coral_shipwright', 'coral_furniture'], npcs: [['captain', 'Captain Maela', 'Harbor captain', '⚓'], ['fisher', 'Beno Net', 'Master fisher', '∿'], ['diver', 'Kora Tide', 'Grotto diver', '♒'], ['shipwright', 'Hobb Keel', 'Shipwright', '⚒'], ['decorator', 'Lysa Coral', 'Island decorator', '♧']] },
  { id: 'nightglass', name: 'Nightglass Refuge', x: 219, y: 154, zoneId: 'nightglass_refuge', shops: ['glass_armory', 'glass_alchemy', 'glass_relics', 'glass_provisions'], npcs: [['warden', 'Warden Nox', 'Refuge warden', '⚑'], ['smith', 'Veyra Glass', 'Glass smith', '⚒'], ['oracle', 'Mute Orin', 'Abyss oracle', '◇'], ['delver', 'Cass Voidstep', 'Abyss delver', '⌄'], ['provisioner', 'Elo Blackcart', 'Endgame provisioner', '▣']] }
];

const shopItemSets = {
  green_provisions: ['bread', 'cooked_meat', 'apple', 'moonleaf', 'greater_tonic', 'torch', 'fishing_rod'], green_woodworks: ['woodcut_axe', 'root_amber', 'rootblade', 'rootguard', 'canopy_bed', 'herb_rack'], green_armory: ['rootwarden_helm', 'rootwarden_mail', 'rootblade', 'rootguard', 'climbing_hooks'], green_apothecary: ['moonleaf', 'root_amber', 'greater_tonic', 'greater_mana', 'focus_elixir', 'antidote'],
  fen_market: ['fen_eel', 'bog_pearl', 'grave_reed', 'greater_tonic', 'lantern', 'fen_cowl'], fen_alchemy: ['grave_reed', 'bog_pearl', 'greater_mana', 'focus_elixir', 'coldward_draught', 'antidote'], fen_fishery: ['fishing_rod', 'fen_eel', 'cooked_meat', 'tide_compass'], fen_relics: ['fen_cowl', 'fen_robe', 'reed_spear', 'bog_tome', 'sacred_relic'],
  stone_armory: ['highland_visor', 'highland_plate', 'gryphon_bow', 'cliffwall', 'sun_mace'], stone_tools: ['pickaxe', 'mining_drill', 'climbing_hooks', 'rope', 'highland_ore'], stone_artillery: ['grand_cannon', 'shell_bandolier', 'blast_shield', 'highland_visor'], stone_market: ['highland_ore', 'gryphon_feather', 'greater_tonic', 'greater_mana', 'weapon_rack'],
  frost_furs: ['winter_pelt', 'frost_crown', 'frost_mantle', 'vault_aegis', 'ice_sculpture'], frost_runes: ['star_ice', 'icebrand', 'greater_mana', 'coldward_draught', 'snow_lantern'], frost_provisions: ['cooked_meat', 'bread', 'greater_tonic', 'coldward_draught', 'snow_lantern'], frost_mounts: ['winter_pelt', 'climbing_hooks', 'lantern'],
  ember_beastgear: ['savanna_hide', 'embermane_helm', 'embermane_plate', 'sunmaul', 'caravan_bulwark'], ember_food: ['red_salt', 'cooked_meat', 'bread', 'greater_tonic', 'fireward_draught'], ember_oretrade: ['ember_ore', 'furnace_core', 'mining_drill', 'highland_ore'], ember_caravan: ['caravan_cot', 'tide_compass', 'rope', 'lantern', 'greater_mana'],
  star_runes: ['meteor_glass', 'resonant_crystal', 'greater_mana', 'focus_elixir', 'rune_dagger'], star_lenses: ['meteor_glass', 'star_telescope', 'rangefinder', 'tide_compass'], star_market: ['resonant_crystal', 'greater_tonic', 'greater_mana', 'bookcase'], star_furniture: ['star_telescope', 'bookcase', 'round_table', 'wall_torch'],
  coral_fishery: ['fishing_rod', 'fen_eel', 'cooked_meat', 'tide_pearl'], coral_treasure: ['pirate_medal', 'tide_pearl', 'coral_chunk', 'tide_compass', 'greater_tonic'], coral_shipwright: ['rope', 'woodcut_axe', 'climbing_hooks', 'sea_chest'], coral_furniture: ['coral_fountain', 'woven_rug', 'sea_chest', 'canopy_bed'],
  glass_armory: ['nightglass_mask', 'nightglass_carapace', 'mirror_scythe', 'abyss_mantlet'], glass_alchemy: ['nightglass_shard', 'abyss_scale', 'glassward_draught', 'greater_tonic', 'greater_mana'], glass_relics: ['mirror_fragment', 'nightglass_pedestal', 'worldplate', 'rangefinder'], glass_provisions: ['greater_tonic', 'greater_mana', 'glassward_draught', 'snow_lantern', 'rope']
};

for (const [id, items] of Object.entries(shopItemSets)) DATA.shops.push({ id, name: id.split('_').map(word => word[0].toUpperCase() + word.slice(1)).join(' '), buys: items, sells: items });

for (const town of towns) {
  town.npcs.forEach((row, index) => DATA.npcs.push({ id: `npc_${town.id}_${row[0]}`, name: row[1], role: row[2], icon: row[3], x: town.x + (index % 3) * 2 - 2, y: town.y + Math.floor(index / 3) * 3 - 1, z: 0, zoneId: town.zoneId, quests: [], shop: town.shops[index % town.shops.length], description: `${row[1]} serves travelers in ${town.name}.` }));
  const buildingTypes = [['hall', 'Civic Hall'], ['inn', 'Wayfarer Inn'], ['market', 'Covered Market'], ['smithy', 'Workshop'], ['depot', 'Depot & Bank'], ['home', 'Residential House']];
  buildingTypes.forEach((row, index) => DATA.buildings.push({ id: `build_${town.id}_${row[0]}`, name: `${town.name} ${row[1]}`, type: row[0] === 'home' ? 'house' : row[0], x: town.x - 7 + (index % 3) * 6, y: town.y - 7 + Math.floor(index / 3) * 6, z: 0, width: 5, height: 4, npcIds: DATA.npcs.filter(npc => npc.id.startsWith(`npc_${town.id}_`)).slice(index, index + 1).map(npc => npc.id), collision: 'walls with street-facing door' }));
}

const depthComplexes = [
  ['underroot', 104, 60, 6, 'Underroot'], ['drowned', 132, 91, 5, 'Drowned Catacombs'], ['emberdeep', 168, 108, 7, 'Emberdeep'],
  ['frostvault', 214, 43, 8, 'Frostvault'], ['coralgrotto', 58, 144, 4, 'Coral Grotto'], ['blackglass', 226, 166, 8, 'Blackglass Abyss']
];
for (const [id, x, y, depth, label] of depthComplexes) {
  DATA.placements.push({ id: `place_${id}_entrance`, type: 'stairs_down', entityId: `${id}_entrance`, x, y, z: 0, targetX: x, targetY: y, targetZ: -1, label: `${label} entrance` });
  DATA.placements.push({ id: `place_${id}_surface_return`, type: 'stairs_up', entityId: `${id}_surface_return`, x, y, z: -1, targetX: x, targetY: y, targetZ: 0, label: `${label} surface return` });
  for (let floor = 1; floor < depth; floor++) {
    const stairX = x + (floor % 2 ? 4 : -4); const stairY = y + (floor % 3 - 1) * 3;
    DATA.placements.push({ id: `place_${id}_down_${floor}`, type: 'stairs_down', entityId: `${id}_stairs_down_${floor}`, x: stairX, y: stairY, z: -floor, targetX: stairX, targetY: stairY, targetZ: -(floor + 1), label: `${label} descent ${floor + 1}` });
    DATA.placements.push({ id: `place_${id}_up_${floor + 1}`, type: 'stairs_up', entityId: `${id}_stairs_up_${floor + 1}`, x: stairX, y: stairY, z: -(floor + 1), targetX: stairX, targetY: stairY, targetZ: -floor, label: `${label} ascent ${floor}` });
  }
  DATA.placements.push({ id: `place_${id}_relic`, type: 'relic', entityId: `${id}_deep_relic`, x: x + 2, y: y - 4, z: -depth, label: `${label} deep relic` });
}

const townLandmarks = [
  ['greenhollow_moonwell', 99, 59, 'Greenhollow Moonwell'], ['mirewatch_bell', 124, 89, 'Mirewatch Warning Bell'], ['stoneheart_memorial', 169, 51, 'Stoneheart Siege Memorial'],
  ['frostgate_hearth', 213, 37, 'Frostgate Great Hearth'], ['emberfall_caravan_board', 176, 106, 'Emberfall Caravan Board'], ['starfall_telescope', 95, 132, 'Starfall Grand Telescope'],
  ['coralhaven_tidebell', 54, 138, 'Coralhaven Tide Bell'], ['nightglass_obelisk', 221, 156, 'Nightglass Refuge Obelisk']
];
for (const [id, x, y, label] of townLandmarks) DATA.placements.push({ id: `place_${id}`, type: 'landmark', entityId: id, x, y, z: 0, label });

const expansionSpawns = [
  ['mob_brambleling', 84, 58, 4], ['mob_bark_stag', 91, 67, 3], ['mob_moon_owl', 108, 51, 3], ['mob_root_guardian', 104, 60, 4, -2], ['boss_underroot_heart', 106, 56, 1, -6],
  ['mob_fen_leech', 111, 82, 4], ['mob_reed_witch', 139, 87, 3], ['mob_bog_lurker', 142, 101, 3], ['mob_drowned_guard', 132, 91, 4, -3], ['boss_drowned_bell', 134, 87, 1, -5],
  ['mob_cliff_ram', 151, 43, 4], ['mob_granite_golem', 179, 60, 3], ['mob_gryphon', 184, 36, 3], ['mob_keep_revenant', 158, 62, 3],
  ['mob_cinder_mole', 168, 108, 4, -1], ['mob_ore_elemental', 172, 105, 4, -3], ['mob_furnace_hound', 164, 111, 3, -5], ['mob_magma_colossus', 170, 104, 2, -7],
  ['mob_snow_jackal', 196, 48, 4], ['mob_rime_troll', 229, 33, 3], ['mob_ice_wyrm', 214, 43, 4, -4], ['mob_frozen_oracle', 218, 39, 3, -7], ['boss_frozen_star', 216, 39, 1, -8],
  ['mob_sunmane_lion', 157, 91, 4], ['mob_redhorn_rhino', 188, 119, 3], ['mob_dust_shaman', 201, 92, 3], ['mob_caravan_reaver', 158, 121, 3],
  ['mob_crystal_crab', 79, 121, 4], ['mob_star_moth', 106, 142, 4], ['mob_crater_behemoth', 82, 147, 3],
  ['mob_reef_crawler', 34, 132, 4], ['mob_salt_corsair', 67, 124, 4], ['mob_tide_serpent', 58, 144, 4, -3],
  ['mob_glass_scorpion', 198, 145, 4], ['mob_void_jackal', 238, 154, 4], ['mob_mirror_wraith', 226, 166, 4, -5], ['mob_abyss_drake', 230, 161, 3, -8], ['boss_world_mirror', 228, 162, 1, -8]
];
const expansionSpawnRows = expansionSpawns.map(([monsterId, x, y, count, z = 0], index) => ({ id: `spawn_${String(index + 21).padStart(2, '0')}`, monsterId, x, y, z, count, radius: 4, respawnSeconds: monsterId.startsWith('boss_') ? 60 : 18, dangerBand: Math.ceil((byId(DATA.monsters, monsterId)?.level || 1) / 35) }));

const materialByZone = { greenhollow_vale: 'root_amber', underroot_deeps: 'root_amber', mirewatch_fen: 'bog_pearl', drowned_catacombs: 'grave_reed', stoneheart_highlands: 'highland_ore', emberdeep_mines: 'ember_ore', frostmarch: 'winter_pelt', frostvault: 'star_ice', emberwild_savanna: 'savanna_hide', starfall_basin: 'resonant_crystal', coralreach_isles: 'coral_chunk', coral_grotto: 'tide_pearl', nightglass_waste: 'nightglass_shard', blackglass_abyss: 'abyss_scale' };
for (const monster of newMonsterRows) {
  const material = materialByZone[monster.zone] || 'gold_piece';
  DATA.dropTables.push({ id: `drop_${monster.id.replace(/^(mob|boss)_/, '')}`, monsterId: monster.id, rolls: monster.boss ? 4 : 2, nothingWeight: monster.boss ? 0 : 6, entries: [
    { itemId: 'gold_piece', tier: 'always', weight: 100, min: Math.max(4, monster.level), max: Math.max(10, monster.level * 3) },
    { itemId: material, tier: monster.boss ? 'always' : 'common', weight: monster.boss ? 100 : 55, min: 1, max: monster.boss ? 5 : 2 },
    { itemId: monster.level >= 100 ? 'greater_mana' : 'greater_tonic', tier: 'rare', weight: 8, min: 1, max: 2 },
    ...(monster.id === 'boss_world_mirror' ? [{ itemId: 'mirror_fragment', tier: 'always', weight: 100, min: 1, max: 2 }] : [])
  ] });
}

const expansionQuestSpecs = [
  ['Q_21', 'Bramble at the Gate', 'npc_greenhollow_warden', 14, 'kill', 'mob_brambleling', 8, 'Bramblelings cleared'], ['Q_22', 'The Walking Bark', 'npc_greenhollow_delver', 18, 'kill', 'mob_bark_stag', 6, 'Bark Stags defeated'], ['Q_23', 'Eyes in Moonlight', 'npc_greenhollow_herbalist', 19, 'kill', 'mob_moon_owl', 5, 'Moon Owls calmed'], ['Q_24', 'Guardians Underfoot', 'npc_greenhollow_delver', 25, 'kill', 'mob_root_guardian', 8, 'Root Guardians defeated'],
  ['Q_25', 'Leeches on the Walk', 'npc_mirewatch_reeve', 29, 'kill', 'mob_fen_leech', 10, 'Fen Leeches removed'], ['Q_26', 'The Reed Witches', 'npc_mirewatch_alchemist', 34, 'kill', 'mob_reed_witch', 7, 'Reed Witches defeated'], ['Q_27', 'Something in the Mud', 'npc_mirewatch_relic', 38, 'kill', 'mob_bog_lurker', 6, 'Bog Lurkers defeated'], ['Q_28', 'Drowned Guard Rotation', 'npc_mirewatch_relic', 46, 'kill', 'mob_drowned_guard', 10, 'Drowned Guards broken'],
  ['Q_29', 'Cliff-Ram Season', 'npc_stoneheart_climber', 45, 'kill', 'mob_cliff_ram', 8, 'Cliff Rams hunted'], ['Q_30', 'Gryphons Over the Walls', 'npc_stoneheart_marshal', 59, 'kill', 'mob_gryphon', 6, 'Highland Gryphons defeated'],
  ['Q_31', 'Amber in the Roots', 'npc_greenhollow_merchant', 16, 'collect', 'root_amber', 8, 'Root Amber collected'], ['Q_32', 'A Herbalist’s Moon', 'npc_greenhollow_herbalist', 14, 'collect', 'moonleaf', 12, 'Moonleaf Bundles collected'], ['Q_33', 'Pearls of Bad Water', 'npc_mirewatch_alchemist', 32, 'collect', 'bog_pearl', 8, 'Bog Pearls collected'], ['Q_34', 'Reeds for the Dead', 'npc_mirewatch_relic', 42, 'collect', 'grave_reed', 10, 'Grave Reeds collected'],
  ['Q_35', 'The Bastion’s Ore', 'npc_stoneheart_smith', 48, 'collect', 'highland_ore', 12, 'Highland Ore collected'], ['Q_36', 'Feathers for Fletching', 'npc_stoneheart_quartermaster', 58, 'collect', 'gryphon_feather', 8, 'Gryphon Feathers collected'], ['Q_37', 'Heat That Can Be Held', 'npc_emberfall_miner', 65, 'collect', 'furnace_core', 6, 'Furnace Cores collected'], ['Q_38', 'Pelts Against the Gale', 'npc_frostgate_furrier', 70, 'collect', 'winter_pelt', 10, 'Winter Pelts collected'],
  ['Q_39', 'The Star in Pieces', 'npc_frostgate_runekeeper', 90, 'collect', 'star_ice', 8, 'Star Ice collected'], ['Q_40', 'Salt of the Red Grass', 'npc_emberfall_chef', 60, 'collect', 'red_salt', 14, 'Red Salt gathered'],
  ['Q_41', 'At the Root of It', 'npc_greenhollow_delver', 45, 'interact', 'underroot_deep_relic', 1, 'Underroot deep relic reached'], ['Q_42', 'Ring the Sunken Bell', 'npc_mirewatch_relic', 68, 'interact', 'drowned_deep_relic', 1, 'Drowned relic reached'], ['Q_43', 'The Seventh Furnace', 'npc_emberfall_miner', 92, 'interact', 'emberdeep_deep_relic', 1, 'Emberdeep relic reached'], ['Q_44', 'Eight Locks of Ice', 'npc_frostgate_vaultkeeper', 125, 'interact', 'frostvault_deep_relic', 1, 'Frostvault relic reached'], ['Q_45', 'The Lowest Tide', 'npc_coralhaven_diver', 70, 'interact', 'coralgrotto_deep_relic', 1, 'Coral Grotto relic reached'], ['Q_46', 'Stand Before the Mirror', 'npc_nightglass_oracle', 200, 'interact', 'blackglass_deep_relic', 1, 'Blackglass relic reached'],
  ['Q_47', 'Road to Greenhollow', 'npc_greenhollow_innkeeper', 12, 'visit', 'greenhollow_vale', 1, 'Greenhollow Vale visited'], ['Q_48', 'Boardwalk Horizon', 'npc_mirewatch_boatman', 28, 'visit', 'mirewatch_fen', 1, 'Mirewatch Fen visited'], ['Q_49', 'Highland Switchbacks', 'npc_stoneheart_climber', 45, 'visit', 'stoneheart_highlands', 1, 'Stoneheart Highlands visited'], ['Q_50', 'Into Frostmarch', 'npc_frostgate_thane', 65, 'visit', 'frostmarch', 1, 'Frostmarch visited'], ['Q_51', 'Across the Red Grass', 'npc_emberfall_caravaner', 55, 'visit', 'emberwild_savanna', 1, 'Emberwild visited'], ['Q_52', 'The Southern Isles', 'npc_coralhaven_captain', 38, 'visit', 'coralreach_isles', 1, 'Coralreach visited'], ['Q_53', 'Black Sand Underfoot', 'npc_nightglass_warden', 105, 'visit', 'nightglass_waste', 1, 'Nightglass Waste visited'],
  ['Q_54', 'Drink at the Moonwell', 'npc_greenhollow_warden', 12, 'interact', 'greenhollow_moonwell', 1, 'Moonwell inspected'], ['Q_55', 'Sound the Fen Bell', 'npc_mirewatch_reeve', 30, 'interact', 'mirewatch_bell', 1, 'Mirewatch bell sounded'], ['Q_56', 'Names on the Bastion', 'npc_stoneheart_marshal', 48, 'interact', 'stoneheart_memorial', 1, 'Siege memorial read'], ['Q_57', 'Warmth at World’s Edge', 'npc_frostgate_cook', 68, 'interact', 'frostgate_hearth', 1, 'Great Hearth visited'], ['Q_58', 'A Caravan Worth Taking', 'npc_emberfall_caravaner', 60, 'interact', 'emberfall_caravan_board', 1, 'Caravan contract taken'], ['Q_59', 'Measure the Fallen Star', 'npc_starfall_astronomer', 72, 'interact', 'starfall_telescope', 1, 'Grand Telescope used'], ['Q_60', 'The Tide Bell’s Answer', 'npc_coralhaven_captain', 42, 'interact', 'coralhaven_tidebell', 1, 'Tide Bell sounded']
];
for (const [id, name, giverId, level, type, targetId, amount, label] of expansionQuestSpecs) {
  const quest = { id, name, giverId, recommendedLevel: level, solo: true, prerequisite: [], description: `${label} in the expanded mainland.`, objectives: [{ id: `${id}_objective`, type, targetId, amount, label }], rewards: { xp: level * 85, gold: level * 9, items: level >= 60 ? [{ id: 'greater_tonic', qty: 2 }] : [] } };
  DATA.quests.push(quest);
  const npc = byId(DATA.npcs, giverId); if (npc) npc.quests.push(id);
}


const baseSkills = level => Object.fromEntries(DATA.skills.map(skill => [skill.id, { level: Math.max(1, Math.round(level * (skill.family === 'Combat' ? .72 : .42))), xp: 0, next: Math.max(100, level * 120) }]));
const makeQuestStates = activeId => Object.fromEntries(DATA.quests.map(quest => [quest.id, {
  status: quest.id === activeId ? 'active' : 'available',
  progress: Object.fromEntries(quest.objectives.map(objective => [objective.id, 0])),
  acceptedAt: quest.id === activeId ? nowIso() : null,
  completedAt: null
}]));

DATA.characters = [
  {
    id: 'char_1', slot: 1, name: 'Morrow Vane', vocationId: 'black_knight', level: 1, xp: 0, xpNext: 120,
    hp: 150, maxHp: 150, mana: 50, maxMana: 50, zeal: 0, maxZeal: 5, heat: 0, gold: 36, capMax: 420,
    x: 17, y: 49, z: 0, facing: 'north', mounted: false, location: 'Anchorage Harbor', scenario: 'First Landing',
    scenarioText: 'A true level-one beginning on the safe tutorial island. Meet Aster, hunt gentle shore creatures, learn light, trade, gear up, repair the bridge, and earn passage.',
    equipment: { head: 'soot_helm', amulet: 'twine_amulet', body: 'worn_cloak', back: 'frayed_pack', weapon: 'bent_sword', legs: 'patched_trousers', shield: 'plank_shield', ring: 'tin_ring', feet: 'dock_boots', ammo: 'flint_pouch' },
    inventory: [{ id: 'apple', qty: 2 }, { id: 'torch', qty: 2 }, { id: 'rope', qty: 1 }, { id: 'minor_potion', qty: 1 }],
    spells: ['iron_cyclone', 'mend', 'light_orb', 'haste', 'cleanse', 'ropecall', 'crimson_oath', 'challenge'],
    skills: { ...baseSkills(1), swordsmanship: { level: 10, xp: 0, next: 160 }, shielding: { level: 10, xp: 0, next: 160 }, attack: { level: 1, xp: 0, next: 100 }, strength: { level: 1, xp: 0, next: 100 }, defence: { level: 1, xp: 0, next: 100 } },
    quests: makeQuestStates('Q_01'), statuses: {}, cooldowns: {}, flags: { tutorialSeen: false, bridgeRepaired: false }, houseIds: [], furniturePlacements: [], killCounts: {}, deathCount: 0
  },
  {
    id: 'char_2', slot: 2, name: 'Sable Mercy', vocationId: 'warhealer', level: 20, xp: 1800, xpNext: 2400,
    hp: 445, maxHp: 445, mana: 215, maxMana: 215, zeal: 2, maxZeal: 5, heat: 0, gold: 680, capMax: 760,
    x: 16, y: 48, z: -1, facing: 'north', mounted: false, location: 'Wormburrow', scenario: 'The Cave Haul',
    scenarioText: 'Standing beside a dropped bag of swords and maces. Loot it, walk to the rope spot, climb out, sell to Bram, then reach the cottage broker and furniture shop without obstruction.',
    equipment: { head: 'bronze_cap', amulet: 'sun_amulet', body: 'ringmail', back: 'trail_pack', weapon: 'sun_mace', legs: 'leather_legs', shield: 'iron_shield', ring: 'bronze_ring', feet: 'trail_boots', ammo: 'salve_case' },
    inventory: [{ id: 'rope', qty: 1 }, { id: 'torch', qty: 4 }, { id: 'minor_potion', qty: 5 }, { id: 'antidote', qty: 3 }, { id: 'worm_hide', qty: 10 }],
    spells: ['zeal_strike', 'battle_salve', 'shared_vigor', 'vow_of_iron', 'light_orb', 'haste', 'cleanse', 'ropecall'],
    skills: { ...baseSkills(20), clubcraft: { level: 38, xp: 50, next: 2400 }, shielding: { level: 34, xp: 430, next: 2100 }, magic: { level: 14, xp: 120, next: 940 }, prayer: { level: 22, xp: 300, next: 1550 } },
    quests: makeQuestStates('Q_04'), statuses: {}, cooldowns: {}, flags: { tutorialSeen: true, bridgeRepaired: true, haulBagLooted: false }, houseIds: [], furniturePlacements: [], killCounts: {}, deathCount: 0
  },
  {
    id: 'char_3', slot: 3, name: 'Ilyra Glass', vocationId: 'battlemage', level: 30, xp: 3500, xpNext: 4200,
    hp: 610, maxHp: 610, mana: 560, maxMana: 560, zeal: 0, maxZeal: 5, heat: 0, gold: 420, capMax: 980,
    x: 78, y: 17, z: 0, facing: 'east', mounted: false, location: 'Sunscour Market', scenario: 'The Thousand-Gold Sale',
    scenarioText: 'At Sahir Brass with a backpack of desert valuables. The marked stacks sell for exactly 1,000 gp and immediately demonstrate merchant transactions and quest progress.',
    equipment: { head: 'dune_hood', amulet: 'storm_amulet', body: 'scale_coat', back: 'desert_pack', weapon: 'rune_dagger', legs: 'guard_legs', shield: 'spell_focus', ring: 'rune_ring', feet: 'rune_boots', ammo: 'shard_case' },
    inventory: [{ id: 'sunstone', qty: 20 }, { id: 'scarab_shell', qty: 10 }, { id: 'dust_idol', qty: 5 }, { id: 'mana_potion', qty: 8 }, { id: 'torch', qty: 5 }, { id: 'rope', qty: 1 }],
    spells: ['spellweave', 'cinder_fan', 'shock_lunge', 'runic_plate', 'light_orb', 'mend', 'haste', 'cleanse'],
    skills: { ...baseSkills(30), swordsmanship: { level: 48, xp: 800, next: 3800 }, magic: { level: 42, xp: 600, next: 3400 }, crafting: { level: 36, xp: 200, next: 2700 }, runecraft: { level: 39, xp: 400, next: 3000 } },
    quests: makeQuestStates('Q_15'), statuses: {}, cooldowns: {}, flags: { tutorialSeen: true, bridgeRepaired: true }, houseIds: [], furniturePlacements: [], killCounts: {}, deathCount: 0
  },
  {
    id: 'char_4', slot: 4, name: 'Calder Lux', vocationId: 'priest', level: 50, xp: 8900, xpNext: 10400,
    hp: 820, maxHp: 820, mana: 1340, maxMana: 1340, zeal: 0, maxZeal: 5, heat: 0, gold: 2200, capMax: 1210,
    x: 62, y: 16, z: -2, facing: 'east', mounted: false, location: 'Silkfall Depths · Middle', scenario: 'Five Floors of Silk',
    scenarioText: 'On the middle of five Tarantula cave floors. There are two stair levels above and below; the top and bottom each hold a Brood Tyrant. The top exits south to the long road home.',
    equipment: { head: 'halo_cowl', amulet: 'grace_amulet', body: 'luminary_robe', back: 'relic_pack', weapon: 'dawn_staff', legs: 'sunweave_legs', shield: 'aegis_tome', ring: 'mercy_ring', feet: 'pilgrim_boots', ammo: 'prayer_beads' },
    inventory: [{ id: 'minor_potion', qty: 12 }, { id: 'mana_potion', qty: 16 }, { id: 'antidote', qty: 8 }, { id: 'torch', qty: 8 }, { id: 'rope', qty: 1 }, { id: 'sacred_relic', qty: 1 }],
    spells: ['grace_touch', 'sun_smite', 'sanctuary_pulse', 'mercy_ward', 'return_soul', 'light_orb', 'haste', 'cleanse'],
    skills: { ...baseSkills(50), magic: { level: 68, xp: 1600, next: 6800 }, prayer: { level: 72, xp: 1100, next: 7600 }, herblore: { level: 49, xp: 900, next: 4400 }, defence: { level: 45, xp: 400, next: 3900 } },
    quests: makeQuestStates('Q_18'), statuses: {}, cooldowns: {}, flags: { tutorialSeen: true, bridgeRepaired: true }, houseIds: [], furniturePlacements: [], killCounts: {}, deathCount: 0
  },
  {
    id: 'char_5', slot: 5, name: 'Ordnance Rex', vocationId: 'siege_operator', level: 200, xp: 98000, xpNext: 120000,
    hp: 4650, maxHp: 4650, mana: 1850, maxMana: 1850, zeal: 0, maxZeal: 5, heat: 0, gold: 250000, capMax: 7200,
    x: 62, y: 46, z: 0, facing: 'east', mounted: true, mountId: 'mount_ironhart', location: 'Crucible Reach', scenario: 'The Grand Bombardier',
    scenarioText: 'Mounted in best-in-slot Worldbreaker gear. Travel quickly, power the cannon to slow down, anchor completely, then fire Breach Shells or Mortar Rain at the island’s strongest targets.',
    equipment: { head: 'bombardier_helm', amulet: 'rangefinder', body: 'worldplate', back: 'arsenal_rig', weapon: 'grand_cannon', legs: 'siege_greaves', shield: 'blast_shield', ring: 'anchor_ring', feet: 'stabilizer_boots', ammo: 'shell_bandolier' },
    inventory: [{ id: 'minor_potion', qty: 100 }, { id: 'mana_potion', qty: 100 }, { id: 'antidote', qty: 50 }, { id: 'lantern', qty: 1 }, { id: 'rope', qty: 1 }, { id: 'giant_fang', qty: 10 }, { id: 'radiant_shard', qty: 50 }],
    spells: ['power_cannon', 'anchor_siege', 'breach_shell', 'mortar_rain', 'flak_burst', 'emergency_plating', 'light_orb', 'haste'],
    skills: Object.fromEntries(DATA.skills.map(skill => [skill.id, { level: skill.id === 'artillery' ? 125 : Math.max(70, Math.round(80 + Math.random() * 25)), xp: 5000, next: 15000 }])),
    quests: makeQuestStates('Q_20'), statuses: {}, cooldowns: {}, flags: { tutorialSeen: true, bridgeRepaired: true, cannonPowered: false, siegeMode: false, passageUnlocked: true }, houseIds: ['house_tideglass', 'house_sunscour'], furniturePlacements: [], killCounts: {}, deathCount: 0
  }
];

if(!byId(DATA.skills,'luck'))DATA.skills.push({id:'luck',name:'Luck',family:'Fortune',source:'Ungodly Backend',color:'#ff4ca0',description:'Improves rare rewards, favorable outcomes and Vagabond discovery rolls.'});
const skillFamilyCorrections={attack:'Combat',strength:'Combat',defence:'Combat',prayer:'Mystic',agility:'Movement',thieving:'Subterfuge',slayer:'Hunting',hunter:'Hunting',fishing:'Gathering',mining:'Gathering',woodcutting:'Gathering',farming:'Gathering',herblore:'Crafting',crafting:'Crafting',fletching:'Crafting',smithing:'Crafting',cooking:'Crafting',firemaking:'Survival',construction:'Building',runecraft:'Mystic',magic:'Mystic',luck:'Fortune'};for(const skill of DATA.skills)if(skillFamilyCorrections[skill.id])skill.family=skillFamilyCorrections[skill.id];
DATA.vocations.push(
  {id:'vagabond',name:'Vagabond',promotion:'fortune_walker',promotedName:'Fortune Walker',icon:'🃏',color:'#ff4ca0',hpGain:9,manaGain:13,capGain:18,speed:1.08,resource:'mana',role:'Lucky adaptable wanderer',luckPerLevel:1.8,description:'A highly fortunate generalist whose discoveries and branching upgrades can move toward any play style.'},
  {id:'fortune_walker',name:'Fortune Walker',base:'vagabond',promotion:'',icon:'🎴',color:'#ff79bd',hpGain:11,manaGain:16,capGain:22,speed:1.12,resource:'mana',role:'Promoted lucky wanderer',luckPerLevel:2.2,description:'A seasoned Vagabond who bends rare outcomes toward opportunity.'},
  {id:'grove_druid',name:'Grove Druid',promotion:'dryad',icon:'🌿',color:'#32d6a1',hpGain:6,manaGain:31,capGain:12,speed:1.03,resource:'mana',role:'Nature healer and battlefield controller',description:'A distinct nature-caster path designed for four-role group synergy.'},
  {id:'royal_scout',name:'Royal Scout',promotion:'court_ranger',icon:'🏹',color:'#00c8ff',hpGain:10,manaGain:17,capGain:21,speed:1.1,resource:'mana',role:'Ranged support scout',description:'A decorated ranged path that supports the frontline while delivering sustained distance damage.'},
  {id:'warlock',name:'Warlock',promotion:'lich',icon:'🜏',color:'#bd5cff',hpGain:7,manaGain:35,capGain:12,speed:1.03,resource:'mana',role:'Curses and destructive pact magic',magicPowerPerMagicLevel:.9,magicPowerPerCharacterLevel:.42,description:'A high-level offensive caster using deathfire, curses, storm magic and void control.'}
);
for(const character of DATA.characters)character.presetTemplate=true;
const showcaseCharacters=[
  {...deepClone(DATA.characters[3]),id:'preset_priest_100',slot:6,name:'Malachar Voss',vocationId:'warlock',level:100,xp:24000,xpNext:30000,hp:1420,maxHp:1420,mana:3550,maxMana:3550,gold:18000,location:'Starveil Tower',scenario:'Warlock Pact Arsenal',scenarioText:'A level-100 Warlock configured for curses, deathfire, storm magic and destructive area control.',equipment:{...deepClone(DATA.characters[3].equipment),weapon:'nightglass_staff',shield:'bog_tome',ring:'rune_ring'},spells:['ember_lance','grave_spark','arc_wave','void_tempest','cinder_fan','magic_ward','light_orb','cleanse'],presetTemplate:true},
  {...deepClone(DATA.characters[3]),id:'preset_druid_35',slot:7,name:'Thalia Moss',vocationId:'grove_druid',level:35,xp:4800,xpNext:6200,hp:560,maxHp:560,mana:1120,maxMana:1120,gold:1450,location:'Greenhollow',scenario:'Grove Druid Control',scenarioText:'A level-35 nature caster configured for healing, roots and elemental control.',spells:['frost_seed','verdant_mend','rootwall','light_orb','mend','haste','cleanse','ropecall'],presetTemplate:true},
  {...deepClone(DATA.characters[2]),id:'preset_scout_125',slot:8,name:'Aurel Farshot',vocationId:'royal_scout',level:125,xp:41000,xpNext:52000,hp:1780,maxHp:1780,mana:2200,maxMana:2200,gold:32000,location:'Dawnroad Overlook',scenario:'Royal Scout Vanguard',scenarioText:'A level-125 ranged support specialist equipped for precision, kiting and party protection.',equipment:{...deepClone(DATA.characters[2].equipment),weapon:'gryphon_bow',shield:'cliffwall',ammo:'reed_arrow'},spells:['sunshot','halo_volley','falcon_focus','protect_company','light_orb','mend','haste','cleanse'],presetTemplate:true}
];
for(const character of showcaseCharacters){character.skills=baseSkills(character.level);character.quests=makeQuestStates('Q_01');character.lastPlayedAt=null;if(!byId(DATA.characters,character.id))DATA.characters.push(character);}
if(!itemOf('nightglass_staff'))DATA.items.push({id:'nightglass_staff',name:'Nightglass Pact Staff',type:'weapon',slot:'weapon',weaponSkill:'magic',icon:'🪄',color:'#b45cff',attack:58,magicPower:24,element:'death',weight:26,buy:14500,sell:3625,description:'A level-100 Warlock focus for curses, deathfire and void magic.'});

// Gear growth, social simulation, personality, reputation, guild-hall and shared-store definitions.
DATA.gearLevelCurves = [
  { id: 'curve_weapon_standard', name: 'Weapon Mastery Curve', itemTypes: ['weapon','wand'], baseXp: 90, exponent: 1.32, maxLevel: 100, statGainPerLevel: .012, gearScorePerLevel: 2, paidUpgradeGoldBase: 80, paidUpgradeGoldExponent: 1.2, useXpAttack: 14, useXpSpell: 10, description: 'Weapons level from successful attacks and spellcasting. Every item may override any value.' },
  { id: 'curve_armor_standard', name: 'Armor Familiarity Curve', itemTypes: ['armor'], baseXp: 110, exponent: 1.35, maxLevel: 100, statGainPerLevel: .009, gearScorePerLevel: 2, paidUpgradeGoldBase: 95, paidUpgradeGoldExponent: 1.22, useXpDefense: 7, description: 'Armor gains familiarity while equipped when its wearer takes damage.' },
  { id: 'curve_guard_standard', name: 'Shield & Focus Curve', itemTypes: ['shield'], baseXp: 100, exponent: 1.34, maxLevel: 100, statGainPerLevel: .011, gearScorePerLevel: 2, paidUpgradeGoldBase: 90, paidUpgradeGoldExponent: 1.21, useXpDefense: 9, useXpSpell: 8, description: 'Shields and magical focuses improve through defense and spell use.' },
  { id: 'curve_accessory_standard', name: 'Accessory Bond Curve', itemTypes: ['amulet','ring','container','ammo'], baseXp: 125, exponent: 1.38, maxLevel: 75, statGainPerLevel: .007, gearScorePerLevel: 1, paidUpgradeGoldBase: 120, paidUpgradeGoldExponent: 1.24, useXpDefense: 3, useXpSpell: 4, description: 'Accessories bond slowly during any combat activity.' }
];
DATA.itemUpgradeServices = [
  { id: 'upgrade_harbor_forge', name: 'Anchorage Item Tempering', npcId: 'npc_orin', currency: 'gold', allowedCurveIds: DATA.gearLevelCurves.map(row=>row.id), maximumPaidLevel: 100, costMultiplier: 1, description: 'Pays for one immediate item level without replacing natural use-based growth.' },
  { id: 'upgrade_admin_budget', name: 'Admin Gearscore Budget', npcId: '', currency: 'gearScoreBudget', allowedCurveIds: DATA.gearLevelCurves.map(row=>row.id), maximumPaidLevel: 100, costMultiplier: 1, description: 'Admin starter characters may spend their supplied gear-score budget on equipped item levels.' }
];
for (const item of DATA.items) {
  if (!item.slot && !['weapon','armor','shield','wand'].includes(item.type)) continue;
  item.gearScoreBase = Number(item.gearScoreBase ?? Math.max(1, Math.round(Number(item.attack||0)*2.5 + Number(item.armor||0)*2 + Number(item.defense||0)*2 + Number(item.magicPower||0)*2.5 + Math.sqrt(Math.max(0,Number(item.buy||0)))/3)));
  item.gearCurveId = item.gearCurveId || (item.type === 'weapon' || item.type === 'wand' ? 'curve_weapon_standard' : item.type === 'shield' ? 'curve_guard_standard' : ['ring','amulet','container','ammo'].includes(item.slot) ? 'curve_accessory_standard' : 'curve_armor_standard');
  item.minimumItemLevel = Number(item.minimumItemLevel || 1); item.maximumItemLevel = Number(item.maximumItemLevel || 100);
}

DATA.socialStats = ['charisma','likeability','fame','infamy','friendliness','sociability'].map((id,index)=>({ id, name:id[0].toUpperCase()+id.slice(1), minimum:-100, maximum:100, defaultValue:[8,10,0,0,12,9][index], interplay: ({charisma:['likeability','sociability'],likeability:['friendliness','fame'],fame:['charisma','likeability'],infamy:['fame','friendliness'],friendliness:['likeability','sociability'],sociability:['charisma','friendliness']})[id], description:`Persistent ${id} value used by events, conversations, quests, reputations and leaderboards.` }));
DATA.socialEventDefinitions = [
  { id:'event_helpful_quest',name:'Helpful Deed',trigger:'quest_complete',effects:{fame:3,friendliness:3,likeability:2,sociability:1,infamy:-1},interplayScale:.12 },
  { id:'event_heroic_kill',name:'Visible Heroism',trigger:'monster_kill',effects:{fame:1,charisma:.25},interplayScale:.08 },
  { id:'event_friendly_conversation',name:'Friendly Conversation',trigger:'npc_talk',effects:{friendliness:.35,sociability:.65,likeability:.2},interplayScale:.1 },
  { id:'event_public_threat',name:'Public Threat',trigger:'choice',effects:{infamy:8,fame:2,friendliness:-5,likeability:-6},interplayScale:.15 },
  { id:'event_generous_trade',name:'Generous Trade',trigger:'village_store_deposit',effects:{friendliness:1,likeability:1,fame:.25},interplayScale:.08 }
];
DATA.archetypes = [
  { id:'archetype_guardian',name:'Guardian',traits:{bravery:78,empathy:68,discipline:82,curiosity:35},aspirationIds:['asp_protect_harbor','asp_earn_respect'],fearIds:['fear_failing_others'],preferenceIds:['pref_order','pref_honest_people'] },
  { id:'archetype_wanderer',name:'Wanderer',traits:{bravery:62,empathy:48,discipline:38,curiosity:92},aspirationIds:['asp_chart_unknown','asp_find_home'],fearIds:['fear_confinement'],preferenceIds:['pref_open_roads','pref_strange_places'] },
  { id:'archetype_scholar',name:'Scholar',traits:{bravery:38,empathy:55,discipline:74,curiosity:96},aspirationIds:['asp_master_magic','asp_preserve_knowledge'],fearIds:['fear_forgetting'],preferenceIds:['pref_books','pref_curious_people'] },
  { id:'archetype_maverick',name:'Maverick',traits:{bravery:86,empathy:30,discipline:25,curiosity:75},aspirationIds:['asp_break_limits','asp_become_legend'],fearIds:['fear_insignificance'],preferenceIds:['pref_risk','pref_bold_people'] }
];
DATA.aspirations = [
  ['asp_protect_harbor','Protect the Harbor','community','Keep Anchorage safe from escalating threats.',100],['asp_earn_respect','Earn Lasting Respect','social','Become trusted without relying on fear.',80],['asp_chart_unknown','Chart the Unknown','exploration','Visit every dangerous depth and hidden landmark.',120],['asp_find_home','Find a True Home','personal','Own and furnish a place that feels safe.',75],['asp_master_magic','Master Living Magic','progression','Reach exceptional magic skill and learn rare spells.',150],['asp_preserve_knowledge','Preserve Lost Knowledge','scholarship','Recover archives, scrolls and expedition records.',110],['asp_break_limits','Break Every Limit','progression','Surpass expected class and equipment limits.',140],['asp_become_legend','Become a Legend','fame','Reach overwhelming fame or infamy.',200]
].map(([id,name,category,description,target])=>({id,name,category,description,target,cloneSourceId:'',completionEffects:{fame:10,likeability:3}}));
DATA.fears = [
  {id:'fear_failing_others',name:'Failing Those Who Depend on Me',triggerTags:['ally_down','quest_failed'],severity:72,response:'protective_overdrive'},
  {id:'fear_confinement',name:'Confinement',triggerTags:['locked_room','deep_cave'],severity:58,response:'seek_exit'},
  {id:'fear_forgetting',name:'Lost Memory',triggerTags:['death','mind_magic'],severity:65,response:'record_everything'},
  {id:'fear_insignificance',name:'Being Insignificant',triggerTags:['ignored','low_fame'],severity:80,response:'take_risk'},
  {id:'fear_spiders',name:'Giant Spiders',triggerTags:['spider','webbed'],severity:45,response:'keep_distance'},
  {id:'fear_deep_water',name:'Deep Water',triggerTags:['ocean','drowning'],severity:50,response:'avoid'}
];
DATA.preferences = [
  ['pref_order','Orderly places','place','order',72],['pref_open_roads','Open roads','place','freedom',86],['pref_strange_places','Strange places','place','curiosity',78],['pref_books','Old books','item','fondness',92],['pref_risk','Dangerous wagers','activity','excitement',75],['pref_honest_people','Honest people','person_tag','trust',88],['pref_curious_people','Curious people','person_tag','interest',82],['pref_bold_people','Bold people','person_tag','admiration',77],['pref_warm_food','Warm food','item_tag','comfort',65],['pref_night_rain','Rain at night','weather','calm',55],['pref_orc_citadels','Orc citadels','place_tag','hostility',-85],['pref_generosity','Generosity','behavior','admiration',90]
].map(([id,name,subjectType,feeling,value])=>({id,name,subjectType,subjectId:id.replace('pref_',''),feeling,value,description:`A ${feeling} relationship toward ${name.toLowerCase()}.`}));
DATA.feelingRelationships = [];
DATA.personalities = [];
const personalityOwners=[...DATA.characters.map(row=>({id:row.id,name:row.name,type:'character',vocationId:row.vocationId})),...DATA.npcs.map(row=>({id:row.id,name:row.name,type:'npc',vocationId:row.role}))];
personalityOwners.forEach((owner,index)=>{const archetype=DATA.archetypes[index%DATA.archetypes.length];const personality={id:`personality_${owner.id}`,name:`${owner.name} Personality`,ownerType:owner.type,ownerId:owner.id,archetypeId:archetype.id,cloneSourceId:'',traits:deepClone(archetype.traits),aspirationIds:deepClone(archetype.aspirationIds),fearIds:[...archetype.fearIds,...(index%5===0?['fear_spiders']:[])],preferenceIds:[...archetype.preferenceIds,'pref_warm_food'],values:index%2?['independence','knowledge']:['loyalty','service'],speechStyle:index%3===0?'measured':index%3===1?'warm':'direct'};DATA.personalities.push(personality);for(const preferenceId of personality.preferenceIds)DATA.feelingRelationships.push({id:`feeling_${owner.id}_${preferenceId}`,name:`${owner.name} → ${byId(DATA.preferences,preferenceId)?.name}`,sourceType:owner.type,sourceId:owner.id,targetType:'preference',targetId:preferenceId,feeling:byId(DATA.preferences,preferenceId)?.feeling||'neutral',value:byId(DATA.preferences,preferenceId)?.value||0,contextTags:[owner.vocationId]});});
DATA.reputations = [
  {id:'rep_anchorage',name:'Anchorage Harbor',stakeholderType:'village',stakeholderId:'village_anchorage',minimum:-1000,maximum:1000,tiers:[[-500,'Enemy'],[-100,'Distrusted'],[0,'Unknown'],[100,'Friend'],[400,'Champion']]},
  {id:'rep_first_light',name:'First Light Covenant',stakeholderType:'god',stakeholderId:'god_first_light',minimum:-1000,maximum:1000,competingReputationId:'rep_ashen_crown',goalIds:['goal_protect_mortals','goal_preserve_light']},
  {id:'rep_ashen_crown',name:'Ashen Crown',stakeholderType:'god',stakeholderId:'god_ashen_crown',minimum:-1000,maximum:1000,competingReputationId:'rep_first_light',goalIds:['goal_spread_fear','goal_break_harbor']}
];
DATA.reputationGoals = [
  {id:'goal_protect_mortals',name:'Protect Mortal Settlements',godId:'god_first_light',interestTags:['rescue','defense','healing'],opposedGoalIds:['goal_break_harbor'],successReputation:15},
  {id:'goal_preserve_light',name:'Preserve Sacred Light',godId:'god_first_light',interestTags:['light','knowledge'],opposedGoalIds:['goal_spread_fear'],successReputation:12},
  {id:'goal_spread_fear',name:'Spread Fear',godId:'god_ashen_crown',interestTags:['infamy','threat'],opposedGoalIds:['goal_preserve_light'],successReputation:15},
  {id:'goal_break_harbor',name:'Break Anchorage',godId:'god_ashen_crown',interestTags:['destruction','orc'],opposedGoalIds:['goal_protect_mortals'],successReputation:20}
];
DATA.leaderboardDefinitions = [
  {id:'leader_level',name:'Highest Level',valuePath:'level',direction:'descending',tagFilter:'',displayFields:['name','vocationId','level','gearScore']},
  {id:'leader_gear',name:'Gear Score',valuePath:'gearScore',direction:'descending',tagFilter:'',displayFields:['name','vocationId','gearScore','level']},
  {id:'leader_fame',name:'Fame',valuePath:'socialStats.fame',direction:'descending',tagFilter:'hero',displayFields:['name','tags','fame','likeability']},
  {id:'leader_infamy',name:'Infamy',valuePath:'socialStats.infamy',direction:'descending',tagFilter:'',displayFields:['name','tags','infamy','fame']},
  {id:'leader_playtime',name:'Playtime',valuePath:'playSeconds',direction:'descending',tagFilter:'',displayFields:['name','playSeconds','lastPlayedAt']}
];
DATA.characterTags = [];
for (const character of DATA.characters) { character.tags=[...new Set(character.tags||[character.vocationId,'playable',character.level>=50?'veteran':'adventurer'])];character.socialStats=character.socialStats||Object.fromEntries(DATA.socialStats.map(stat=>[stat.id,stat.defaultValue]));character.reputations=character.reputations||Object.fromEntries(DATA.reputations.map(rep=>[rep.id,0]));character.itemProgress=character.itemProgress||{};character.playSeconds=Number(character.playSeconds||0);character.lastPlayedAt=character.lastPlayedAt||null;DATA.characterTags.push({id:`tags_${character.id}`,name:`${character.name} Tags`,characterId:character.id,tags:character.tags}); }
for (const npc of DATA.npcs) { npc.tags=[...new Set(npc.tags||['npc',npc.role?.split(/\s|&/)[0]?.toLowerCase()].filter(Boolean))];npc.socialStats=npc.socialStats||Object.fromEntries(DATA.socialStats.map(stat=>[stat.id,Math.round(stat.defaultValue+(Math.random()-.5)*12)])); }
DATA.guildHalls = [{id:'guildhall_dawnroad',name:'Dawnroad Guildhall',guildId:'guild_dawnroad',buildingId:'build_dawnroad_guild',houseId:'house_dawnroad_guild',roomIds:['great_hall','quartermaster','craft_hall','library','bunks','arena'],shopIds:['guild_provisions','guild_armory'],arenaCages:8,memberStorage:'shared_guild_store',rankPermissions:{master:['all'],officer:['store_withdraw','invite','arena'],member:['store_deposit','arena']},description:'Complete modular definition for the southern guild compound, rooms, shops, storage and arena.'}];
DATA.villageStores = [{id:'store_anchorage_commons',name:'Anchorage Commons Store',villageId:'village_anchorage',npcId:'npc_commons_keeper',buildingId:'build_commons_store',access:'all_accounts',depositAllowed:true,withdrawAllowed:true,maxPerItem:999999,defaultStock:{apple:30,bread:20,torch:15,rope:5,minor_potion:8},description:'A session-shared village store. Every approved account may deposit or withdraw items.'}];
DATA.npcs.push({id:'npc_commons_keeper',name:'Pella Commonhand',role:'Village commons keeper',icon:'▣',x:8,y:47,z:0,zoneId:'anchorage_harbor',quests:['Q_61','Q_62'],shop:null,tags:['npc','civic','storekeeper'],socialStats:{charisma:35,likeability:55,fame:10,infamy:0,friendliness:72,sociability:68},description:'Manages the Anchorage Commons Store shared by every account in this server session.'});
DATA.personalities.push({id:'personality_npc_commons_keeper',name:'Pella Commonhand Personality',ownerType:'npc',ownerId:'npc_commons_keeper',archetypeId:'archetype_guardian',cloneSourceId:'',traits:{bravery:55,empathy:88,discipline:75,curiosity:50},aspirationIds:['asp_protect_harbor','asp_earn_respect'],fearIds:['fear_failing_others'],preferenceIds:['pref_order','pref_honest_people','pref_generosity'],values:['community','fairness'],speechStyle:'warm'});
DATA.buildings.push({id:'build_commons_store',name:'Anchorage Commons Storehouse',type:'village_store',x:6,y:43,z:0,width:5,height:4,npcIds:['npc_commons_keeper'],collision:'open south door',sharedStoreId:'store_anchorage_commons',description:'A public timber storehouse with account-shared stock.'});
const socialQuests=[
  {id:'Q_61',name:'A Neighborly Face',giverId:'npc_commons_keeper',recommendedLevel:1,solo:true,prerequisite:[],socialRequirements:{friendliness:10,sociability:8},description:'Speak kindly around Anchorage and contribute supplies to the commons.',objectives:[{id:'Q61_talk',type:'social_event',targetId:'event_friendly_conversation',amount:3,label:'Friendly conversations'},{id:'Q61_store',type:'social_event',targetId:'event_generous_trade',amount:1,label:'Commons contribution'}],rewards:{xp:180,gold:90,items:[{id:'bread',qty:3}]},socialEffects:{fame:4,likeability:5,friendliness:5}},
  {id:'Q_62',name:'A Name Worth Knowing',giverId:'npc_commons_keeper',recommendedLevel:5,solo:true,prerequisite:['Q_61'],socialRequirements:{fame:3,likeability:12},description:'Build enough public trust that the harbor asks you to represent it.',objectives:[{id:'Q62_heroism',type:'social_event',targetId:'event_heroic_kill',amount:5,label:'Visible heroic acts'}],rewards:{xp:600,gold:240,items:[{id:'sun_amulet',qty:1}]},socialEffects:{fame:12,charisma:5,likeability:4}},
  {id:'Q_63',name:'The Price of a Reputation',giverId:'npc_vesper',recommendedLevel:20,solo:true,prerequisite:[],socialRequirementsAny:[{fame:20},{infamy:20}],description:'Vesper records whether your name inspires hope or dread.',objectives:[{id:'Q63_reputation',type:'social_threshold',targetId:'fame_or_infamy',amount:20,label:'Reach 20 Fame or Infamy'}],rewards:{xp:1800,gold:500,items:[]},socialEffects:{charisma:6,sociability:3}}
];
DATA.quests.push(...socialQuests);byId(DATA.npcs,'npc_vesper')?.quests.push('Q_63');for(const character of DATA.characters)for(const quest of socialQuests)character.quests[quest.id]={status:'available',progress:Object.fromEntries(quest.objectives.map(objective=>[objective.id,0])),acceptedAt:null,completedAt:null};

DATA.mounts = [
  { id: 'mount_ironhart', name: 'Ironhart Courser', icon: '♞', speedBonus: .5, usableBy: ['siege_operator'], description: 'A reinforced mechanical courser that offsets the artillery vocation’s travel penalty.' },
  { id: 'mount_mosselk', name: 'Moss Elk', icon: '♘', speedBonus: .35, usableBy: ['all'], description: 'A sure-footed mainland mount.' }
];

DATA.spawns = [
  { id: 'spawn_01', monsterId: 'mob_scavenger_rat', x: 10, y: 50, z: 0, count: 2, radius: 2, respawnSeconds: 7, dangerBand: 1 },
  { id: 'spawn_02', monsterId: 'mob_cave_rat', x: 10, y: 45, z: 0, count: 2, radius: 2, respawnSeconds: 8, dangerBand: 1 },
  { id: 'spawn_03', monsterId: 'mob_plains_deer', x: 12, y: 41, z: 0, count: 2, radius: 3, respawnSeconds: 10, dangerBand: 1 },
  { id: 'spawn_04', monsterId: 'mob_stray_hound', x: 26, y: 48, z: 0, count: 2, radius: 2, respawnSeconds: 10, dangerBand: 1 },
  { id: 'spawn_05', monsterId: 'mob_feral_boar', x: 34, y: 47, z: 0, count: 2, radius: 2, respawnSeconds: 12, dangerBand: 2 },
  { id: 'spawn_06', monsterId: 'mob_venom_spider', x: 38, y: 51, z: 0, count: 3, radius: 3, respawnSeconds: 10, dangerBand: 2 },
  { id: 'spawn_07', monsterId: 'mob_timber_wolf', x: 43, y: 49, z: 0, count: 3, radius: 3, respawnSeconds: 12, dangerBand: 2 },
  { id: 'spawn_08', monsterId: 'mob_cave_beetle', x: 46, y: 42, z: 0, count: 2, radius: 2, respawnSeconds: 13, dangerBand: 2 },
  { id: 'spawn_09', monsterId: 'mob_reed_viper', x: 38, y: 39, z: 0, count: 2, radius: 3, respawnSeconds: 11, dangerBand: 2 },
  { id: 'spawn_10', monsterId: 'mob_scrap_troll', x: 47, y: 47, z: 0, count: 2, radius: 2, respawnSeconds: 14, dangerBand: 2 },
  { id: 'spawn_11', monsterId: 'mob_feral_bear', x: 46, y: 38, z: 0, count: 1, radius: 1, respawnSeconds: 18, dangerBand: 2 },
  { id: 'spawn_12', monsterId: 'mob_mud_slime', x: 42, y: 52, z: 0, count: 2, radius: 2, respawnSeconds: 13, dangerBand: 2 },
  { id: 'spawn_13', monsterId: 'mob_goblin_slinger', x: 57, y: 50, z: 0, count: 3, radius: 3, respawnSeconds: 14, dangerBand: 3 },
  { id: 'spawn_14', monsterId: 'mob_ash_raider', x: 62, y: 52, z: 0, count: 3, radius: 3, respawnSeconds: 15, dangerBand: 3 },
  { id: 'spawn_15', monsterId: 'mob_javelin_raider', x: 67, y: 50, z: 0, count: 2, radius: 2, respawnSeconds: 15, dangerBand: 3 },
  { id: 'spawn_16', monsterId: 'mob_crypt_scrapper', x: 22, y: 45, z: -1, count: 3, radius: 2, respawnSeconds: 16, dangerBand: 3 },
  { id: 'spawn_17', monsterId: 'mob_tunnel_worm', x: 13, y: 49, z: -1, count: 4, radius: 4, respawnSeconds: 13, dangerBand: 3 },
  { id: 'spawn_18', monsterId: 'mob_horned_brute', x: 61, y: 41, z: 0, count: 2, radius: 2, respawnSeconds: 20, dangerBand: 3 },
  { id: 'spawn_19', monsterId: 'mob_killer_wasp', x: 68, y: 39, z: 0, count: 3, radius: 3, respawnSeconds: 14, dangerBand: 3 },
  { id: 'spawn_20', monsterId: 'mob_brute_mystic', x: 66, y: 46, z: 0, count: 1, radius: 0, respawnSeconds: 35, dangerBand: 4 }
];
DATA.spawns.push(...expansionSpawnRows);

// Dawnreach frontier expansion: mount markets, shared depots, wild habitats, and the Orcrown Citadel.
byId(DATA.mounts, 'mount_ironhart').price = 18000;
byId(DATA.mounts, 'mount_mosselk').price = 2200;
DATA.mounts.push({ id: 'mount_dune_strider', name: 'Dune Strider', icon: '♘', speedBonus: .44, price: 4800, usableBy: ['all'], description: 'A long-legged desert courser bred for hot stone roads.' });

DATA.items.push(
  {id:'small_bones',name:'Small Bones',type:'material',icon:'🦴',color:'#ddd2b5',weight:1,buy:3,sell:1,stackable:true,description:'Remains from a small creature.'},
  {id:'sturdy_bones',name:'Sturdy Bones',type:'material',icon:'🦴',color:'#c8b68e',weight:3,buy:14,sell:4,stackable:true,description:'Dense remains from a strong creature.'},
  {id:'raw_game_meat',name:'Raw Game Meat',type:'food',icon:'🥩',color:'#c85c59',weight:2,buy:10,sell:3,heal:2,nutrition:5,stackable:true,description:'Uncooked meat gathered from wildlife.'},
  { id: 'depot_box', name: 'House Depot Box', type: 'furniture', icon: '▣', color: '#91aeb3', weight: 85, buy: 650, sell: 160, placeable: true, storage: 'depot', description: 'A placeable house box linked to this character’s persistent depot.' },
  { id: 'wild_claw', name: 'Frontier Claw', type: 'loot', icon: '⌁', color: '#c9b18b', weight: 2, buy: 0, sell: 24, stackable: true, description: 'A hard claw taken from a mainland predator.' },
  { id: 'aether_feather', name: 'Aether Feather', type: 'loot', icon: '≋', color: '#9ed8e9', weight: .4, buy: 0, sell: 48, stackable: true, description: 'A feather that holds a faint charge.' },
  { id: 'shadow_ichor', name: 'Shadow Ichor', type: 'loot', icon: '●', color: '#9a75bb', weight: 1.5, buy: 0, sell: 70, stackable: true, description: 'Unstable ichor from a deep frontier beast.' },
  { id: 'orc_bone_token', name: 'Citadel Bone Token', type: 'loot', icon: '◇', color: '#d6c39b', weight: 1, buy: 0, sell: 90, stackable: true, description: 'A rank token carved by the Orcrown host.' },
  { id: 'war_banner_scrap', name: 'War Banner Scrap', type: 'loot', icon: '⚑', color: '#b75345', weight: 3, buy: 0, sell: 145, stackable: true, description: 'A torn scrap from an Orcrown battle standard.' }
);
DATA.furniture.push({ id: 'depot_box', name: 'House Depot Box', icon: '▣', buy: 650, lightRadius: 0, footprint: '1x1', category: 'storage' });
const furnitureShop = byId(DATA.shops, 'furniture');
if (furnitureShop) { furnitureShop.buys.push('depot_box'); furnitureShop.sells.push('depot_box'); }

const kenshiInspiredSkills = [
  ['toughness', 'Toughness', 'Combat', '#b36d5f', 'Grows whenever damage is endured or a knockout is survived; reduces incoming damage.'],
  ['dexterity', 'Dexterity', 'Combat', '#c19a72', 'Grows through fast weapon use and improves weapon handling.'],
  ['athletics', 'Athletics', 'Movement', '#70a9c2', 'Grows through walking and improves movement speed.'],
  ['labouring', 'Labouring', 'Work', '#a88965', 'Grows alongside mining, woodcutting, and other physical jobs.'],
  ['martial_arts', 'Martial Arts', 'Combat', '#d19b65', 'Unarmed combat technique.'], ['melee_defence', 'Melee Defence', 'Combat', '#7e96aa', 'Deflecting close-range attacks.'],
  ['dodge', 'Dodge', 'Combat', '#8eb3a0', 'Avoiding attacks without a shield.'], ['katanas', 'Curved Blades', 'Combat', '#c7b98b', 'Fast curved-blade handling.'],
  ['sabres', 'Sabres', 'Combat', '#c7a26e', 'Defensive sabre handling.'], ['hackers', 'Cleavers', 'Combat', '#b98666', 'Armor-splitting cleaver handling.'],
  ['heavy_weapons', 'Heavy Weapons', 'Combat', '#a16c55', 'Oversized two-handed weapon handling.'], ['polearms', 'Polearms', 'Combat', '#a5a06c', 'Long-reach polearm handling.'],
  ['turrets', 'Turrets', 'Combat', '#c06f4c', 'Mounted weapon operation.'], ['precision_shooting', 'Precision Shooting', 'Combat', '#7ca88b', 'Avoiding friendly fire and placing shots.'],
  ['perception', 'Perception', 'Combat', '#8fc1b2', 'Spotting distant threats and hidden resources.'], ['crossbows', 'Crossbows', 'Combat', '#88a56f', 'Mechanical ranged weapons.'],
  ['assassination', 'Subdual', 'Stealth', '#806b92', 'Silently disabling enemies.'], ['lockpicking', 'Lockpicking', 'Stealth', '#9a8466', 'Opening mechanical locks.'],
  ['stealth', 'Sneaking', 'Stealth', '#657e72', 'Moving without drawing attention; directly reduces detection range while sneaking.'], ['swimming', 'Swimming', 'Movement', '#5f9fb5', 'Moving through shallow water.'],
  ['engineering', 'Engineering', 'Work', '#a49b83', 'Building and repairing structures.'], ['weapon_smithing', 'Weapon Smithing', 'Work', '#a5785f', 'Forging weapons.'],
  ['armour_smithing', 'Armor Smithing', 'Work', '#888e91', 'Forging protective gear.'], ['first_aid', 'First Aid', 'Medicine', '#79aa85', 'Treating organic injuries.'],
  ['robotics', 'Robotics', 'Medicine', '#7b9eaa', 'Repairing mechanical bodies and mounts.'], ['science', 'Science', 'Research', '#8d86b5', 'Research and ancient technology.']
].map(([id, name, family, color, description]) => ({ id, name, family, source: 'Kenshi-inspired addition', color, description }));
for (const skill of kenshiInspiredSkills) if (!byId(DATA.skills, skill.id)) DATA.skills.push(skill);
for (const character of DATA.characters) for (const skill of kenshiInspiredSkills) if (!character.skills[skill.id]) character.skills[skill.id] = { level: Math.max(1, Math.round(character.level * .35)), xp: 0, next: Math.max(100, character.level * 115) };

const resourceItems = [
  ['copper_chunk', 'Copper Ore Chunk', '◆', '#bd7952', 8], ['iron_ore', 'Iron Ore', '◆', '#899292', 14], ['coal_chunk', 'Coal Chunk', '◆', '#555554', 11],
  ['highland_silver', 'Highland Silver Ore', '◇', '#bac3c2', 34], ['hardwood_log', 'Hardwood Log', '▬', '#876344', 9], ['moonwood_log', 'Moonwood Log', '▬', '#7c8fa8', 26],
  ['frostpine_log', 'Frostpine Log', '▬', '#9eb5b2', 38], ['nightwood_log', 'Nightwood Log', '▬', '#675878', 62]
].map(([id, name, icon, color, sell]) => ({ id, name, type: 'material', icon, color, weight: 7, buy: sell * 4, sell, stackable: true, description: `${name}, gathered from a renewable world resource node.` }));
DATA.items.push(...resourceItems);
for (const character of DATA.characters) {
  if (!character.inventory.some(stack => stack.id === 'pickaxe')) character.inventory.push({ id: 'pickaxe', qty: 1 });
  if (!character.inventory.some(stack => stack.id === 'woodcut_axe')) character.inventory.push({ id: 'woodcut_axe', qty: 1 });
}

DATA.shops.push(
  { id: 'harbor_stables', name: 'Harbor Moss Stables', buys: [], sells: ['apple', 'raw_meat'], mounts: ['mount_mosselk'] },
  { id: 'harbor_striders', name: 'Suntrail Strider Yard', buys: [], sells: ['apple', 'bread'], mounts: ['mount_dune_strider'] }
);
DATA.npcs.push(
  { id: 'npc_renn', name: 'Renn Greenrein', role: 'Moss Elk stablemaster', icon: '♘', x: 10, y: 46, z: 0, zoneId: 'anchorage_harbor', quests: [], shop: 'harbor_stables', description: 'Keeps gentle Moss Elk at the western end of Anchorage Harbor.' },
  { id: 'npc_sava', name: 'Sava Longstep', role: 'Dune Strider breeder', icon: '♞', x: 27, y: 46, z: 0, zoneId: 'anchorage_harbor', quests: [], shop: 'harbor_striders', description: 'Sells faster Dune Striders at the eastern paddock across the city.' }
);
DATA.buildings.push(
  { id: 'build_moss_stable', name: 'Harbor Moss Stables', type: 'stable', x: 8, y: 43, z: 0, width: 4, height: 3, npcIds: ['npc_renn'], collision: 'open paddock' },
  { id: 'build_strider_yard', name: 'Suntrail Strider Yard', type: 'stable', x: 26, y: 43, z: 0, width: 4, height: 3, npcIds: ['npc_sava'], collision: 'open paddock' },
  { id: 'build_orcrown_gatehouse', name: 'Orcrown Gatehouse', type: 'castle', x: 166, y: 158, z: 0, width: 9, height: 5, npcIds: [], collision: 'fortified gate' },
  { id: 'build_orcrown_keep', name: 'Orcrown Great Keep', type: 'castle', x: 164, y: 141, z: 0, width: 13, height: 11, npcIds: [], collision: 'inner keep' },
  { id: 'build_orcrown_west_tower', name: 'West Fang Tower', type: 'tower', x: 156, y: 138, z: 0, width: 5, height: 5, npcIds: [], collision: 'tower' },
  { id: 'build_orcrown_east_tower', name: 'East Fang Tower', type: 'tower', x: 180, y: 138, z: 0, width: 5, height: 5, npcIds: [], collision: 'tower' },
  { id: 'build_orcrown_barracks', name: 'Red Tusk Barracks', type: 'barracks', x: 156, y: 149, z: 0, width: 7, height: 6, npcIds: [], collision: 'open barracks' },
  { id: 'build_orcrown_arsenal', name: 'Black Arrow Arsenal', type: 'barracks', x: 179, y: 149, z: 0, width: 6, height: 6, npcIds: [], collision: 'open arsenal' },
  { id: 'build_orcrown_forge', name: 'Skullfire Forge', type: 'smithy', x: 156, y: 157, z: 0, width: 6, height: 5, npcIds: [], collision: 'war forge' }
);

const frontierMonsterSpecs = [
  ['mob_thornback_boar', 'Thornback Boar', '♈', 16, 310, 39, 14, 540, 'physical', 1, 'greenhollow_vale', 'Charges from bramble pens'],
  ['mob_glade_panther', 'Glade Panther', '♣', 23, 470, 58, 20, 870, 'physical', 1, 'greenhollow_vale', 'Stalks hunter camps'],
  ['mob_marsh_snapper', 'Marsh Snapper', '♒', 31, 650, 74, 32, 1380, 'physical', 1, 'mirewatch_fen', 'Armored nest guardian'],
  ['mob_spore_wisp', 'Spore Wisp', '✦', 36, 480, 84, 19, 1620, 'earth', 4, 'mirewatch_fen', 'Ranged spore volleys'],
  ['mob_crag_vulture', 'Crag Vulture', '♢', 48, 820, 103, 37, 2450, 'physical', 4, 'stoneheart_highlands', 'Ranged feather darts'],
  ['mob_stone_manticore', 'Stone Manticore', '♞', 61, 1480, 142, 64, 5100, 'earth', 3, 'stoneheart_highlands', 'Tail-spike barrage'],
  ['mob_whitehorn_elk', 'Whitehorn Elk', '♘', 68, 1700, 151, 70, 5900, 'ice', 1, 'frostmarch', 'Defends frozen feeding grounds'],
  ['mob_gale_harrier', 'Gale Harrier', '♢', 78, 1320, 171, 56, 7200, 'energy', 5, 'frostmarch', 'Hunts from wind perches'],
  ['mob_redgrass_hyena', 'Redgrass Hyena', '♣', 58, 1160, 133, 48, 4300, 'physical', 1, 'emberwild_savanna', 'Pack hunter around bone dens'],
  ['mob_sunscale_drake', 'Sunscale Drake', '♜', 82, 2150, 194, 88, 9100, 'fire', 4, 'emberwild_savanna', 'Guards scorched roosts'],
  ['mob_crater_stalker', 'Crater Stalker', '☽', 74, 1810, 166, 76, 7600, 'death', 1, 'starfall_basin', 'Burrows beneath crystal fields'],
  ['mob_comet_ray', 'Comet Ray', '◇', 91, 1960, 212, 82, 11200, 'energy', 5, 'starfall_basin', 'Long-range star bolts'],
  ['mob_mangrove_ape', 'Mangrove Ape', '♟', 46, 980, 108, 43, 3200, 'physical', 1, 'coralreach_isles', 'Builds branch barricades'],
  ['mob_reef_wyvern', 'Reef Wyvern', '♞', 88, 2380, 205, 94, 10500, 'ice', 4, 'coralreach_isles', 'Tide-breath from coral nests'],
  ['mob_glass_hyena', 'Glass Hyena', '♣', 108, 2750, 242, 110, 14500, 'physical', 1, 'nightglass_waste', 'Pack hunter among black obelisks'],
  ['mob_eclipse_witch', 'Eclipse Witch', '♛', 132, 2900, 285, 102, 19300, 'death', 6, 'nightglass_waste', 'Casts void lances'],
  ['mob_rift_tortoise', 'Rift Tortoise', '♜', 145, 5200, 255, 188, 24800, 'earth', 1, 'nightglass_waste', 'Immovable shell fortress'],
  ['mob_storm_roc', 'Storm Roc', '♞', 158, 4300, 322, 144, 31500, 'energy', 7, 'stoneheart_highlands', 'Rules a fortified sky roost'],
  ['orc_tusk_grunt', 'Tusk Grunt', '♟', 82, 2050, 185, 82, 8500, 'physical', 1, 'orcrown_citadel', 'Disciplined melee guard'],
  ['orc_redshield', 'Redshield Guard', '♜', 94, 2750, 202, 126, 11000, 'physical', 1, 'orcrown_citadel', 'Shield-wall defender'],
  ['orc_blackarrow', 'Blackarrow Hunter', '➳', 99, 1900, 232, 76, 11900, 'physical', 6, 'orcrown_citadel', 'Long-range armor-piercing arrows'],
  ['orc_bonecaster', 'Bonecaster', '♛', 108, 2100, 258, 84, 14200, 'death', 6, 'orcrown_citadel', 'Death magic and bone hexes'],
  ['orc_ember_seer', 'Ember Seer', '✦', 118, 2350, 281, 91, 16300, 'fire', 6, 'orcrown_citadel', 'Fire fields from the battlements'],
  ['orc_warg_rider', 'Warg Rider', '♞', 121, 3300, 274, 112, 17400, 'physical', 1, 'orcrown_citadel', 'Fast courtyard cavalry'],
  ['orc_chain_hurler', 'Chain Hurler', '⌁', 132, 3700, 298, 126, 19500, 'physical', 4, 'orcrown_citadel', 'Heavy ranged chains'],
  ['orc_skullsmith', 'Skullsmith', '⚒', 141, 4600, 310, 158, 22800, 'fire', 2, 'orcrown_citadel', 'Forge hammer and flame burst'],
  ['orc_dreadmaul', 'Dreadmaul Crusher', '♜', 170, 6200, 405, 176, 39000, 'physical', 1, 'orcrown_citadel', 'Extremely hard-hitting melee elite'],
  ['orc_stormcaller', 'Stormcaller', '♛', 156, 3900, 352, 139, 31000, 'energy', 7, 'orcrown_citadel', 'Battlement lightning'],
  ['orc_gate_captain', 'Gate Captain', '♚', 178, 7800, 388, 210, 52000, 'physical', 2, 'orcrown_citadel', 'Elite commander with sweeping blows'],
  ['boss_orcrown_warlord', 'Orcrown Warlord', '♚', 205, 18500, 455, 265, 140000, 'physical', 2, 'orcrown_citadel', 'Citadel ruler; crushing melee and war cries']
];
for (const [id, name, icon, level, hp, attack, defense, xp, element, range, zone, traits] of frontierMonsterSpecs) {
  DATA.monsters.push({ id, name, icon, level, hp, attack, defense, xp, speed: level > 150 ? 1.12 : 1, range, aggro: Math.min(12, 5 + Math.floor(level / 30)), element, dot: ['death', 'fire'].includes(element) ? Math.floor(level / 9) : 0, boss: id.startsWith('boss_'), zone, traits, color: id.startsWith('orc_') || id.startsWith('boss_orc') ? '#a96c45' : '#7ca68d' });
  const orc = id.startsWith('orc_') || id.startsWith('boss_orc');
  DATA.dropTables.push({ id: `drop_${id.replace(/^(mob|orc|boss)_/, '')}`, monsterId: id, rolls: id.startsWith('boss_') ? 5 : 2, nothingWeight: id.startsWith('boss_') ? 0 : 5, entries: [
    { itemId: 'gold_piece', tier: 'always', weight: 100, min: level, max: level * 3 },
    { itemId: orc ? 'orc_bone_token' : element === 'energy' ? 'aether_feather' : element === 'death' ? 'shadow_ichor' : 'wild_claw', tier: 'common', weight: 58, min: 1, max: 3 },
    ...(orc ? [{ itemId: 'war_banner_scrap', tier: id.startsWith('boss_') ? 'always' : 'rare', weight: id.startsWith('boss_') ? 100 : 8, min: 1, max: 2 }] : []),
    { itemId: level >= 100 ? 'greater_tonic' : 'minor_potion', tier: 'rare', weight: 6, min: 1, max: 1 }
  ] });
}

const frontierSpawns = [
  ['mob_thornback_boar', 82, 69, 4], ['mob_glade_panther', 113, 64, 4], ['mob_marsh_snapper', 118, 101, 4], ['mob_spore_wisp', 145, 79, 4],
  ['mob_crag_vulture', 148, 57, 4], ['mob_stone_manticore', 187, 68, 3], ['mob_whitehorn_elk', 203, 59, 4], ['mob_gale_harrier', 238, 57, 4],
  ['mob_redgrass_hyena', 153, 111, 5], ['mob_sunscale_drake', 206, 106, 4], ['mob_crater_stalker', 74, 142, 4], ['mob_comet_ray', 113, 130, 4],
  ['mob_mangrove_ape', 31, 151, 5], ['mob_reef_wyvern', 67, 159, 4], ['mob_glass_hyena', 194, 171, 5], ['mob_eclipse_witch', 242, 139, 4],
  ['mob_rift_tortoise', 214, 181, 3], ['mob_storm_roc', 184, 29, 3],
  ['orc_tusk_grunt', 159, 161, 5], ['orc_redshield', 181, 160, 4], ['orc_blackarrow', 158, 143, 4], ['orc_bonecaster', 183, 143, 4],
  ['orc_ember_seer', 169, 159, 3], ['orc_warg_rider', 174, 157, 4], ['orc_chain_hurler', 159, 151, 3], ['orc_skullsmith', 183, 157, 3],
  ['orc_dreadmaul', 166, 148, 2], ['orc_stormcaller', 175, 148, 3], ['orc_gate_captain', 170, 143, 1], ['boss_orcrown_warlord', 170, 147, 1],
  ['mob_thornback_boar', 86, 64, 3, -1], ['mob_marsh_snapper', 142, 96, 3, -1], ['mob_stone_manticore', 181, 57, 2, -1], ['mob_gale_harrier', 232, 46, 2, -1],
  ['mob_sunscale_drake', 193, 113, 2, -1], ['mob_crater_stalker', 81, 139, 3, -1], ['mob_reef_wyvern', 35, 143, 2, -1], ['mob_eclipse_witch', 238, 166, 2, -1]
];
DATA.spawns.push(...frontierSpawns.map(([monsterId, x, y, count, z = 0], index) => ({ id: `spawn_${String(index + 59).padStart(3, '0')}`, monsterId, x, y, z, count, radius: 5, respawnSeconds: monsterId.startsWith('boss_') ? 240 : 75, dangerBand: Math.ceil((byId(DATA.monsters, monsterId)?.level || 1) / 30), huntingSpot: true })));

const habitats = [
  ['thornback_wallows', 82, 68, 'Thornback mud wallows'], ['panther_hide', 113, 63, 'Glade Panther hunter blind'], ['snapper_nests', 118, 100, 'Marsh Snapper egg nests'], ['spore_circles', 145, 78, 'Spore Wisp mushroom circle'],
  ['vulture_perches', 148, 56, 'Crag Vulture perches'], ['manticore_den', 187, 67, 'Stone Manticore den'], ['elk_feeders', 203, 58, 'Whitehorn winter feeders'], ['harrier_towers', 238, 56, 'Gale Harrier wind towers'],
  ['hyena_bone_den', 153, 110, 'Redgrass Hyena bone den'], ['drake_roost', 206, 105, 'Sunscale Drake roost'], ['stalker_burrows', 74, 141, 'Crater Stalker burrows'], ['ray_observatory', 113, 129, 'Comet Ray observatory'],
  ['ape_barricade', 31, 150, 'Mangrove Ape barricade'], ['wyvern_coral_nest', 67, 158, 'Reef Wyvern coral nest'], ['glass_den', 194, 170, 'Glass Hyena shard den'], ['witch_ritual', 242, 138, 'Eclipse Witch ritual stones'],
  ['tortoise_rift', 214, 180, 'Rift Tortoise stone ring'], ['roc_roost', 184, 28, 'Storm Roc fortified roost']
];
for (const [id, x, y, label] of habitats) DATA.placements.push({ id: `place_${id}`, type: 'habitat', entityId: id, x, y, z: 0, label });

const resourceNodes = [
  ['harbor_copper_1', 34, 45, 'Copper seam', 'mining', 'copper_chunk', 'pickaxe'], ['canopy_iron_1', 47, 42, 'Ironwood iron seam', 'mining', 'iron_ore', 'pickaxe'],
  ['greenhollow_copper', 92, 55, 'Greenhollow copper seam', 'mining', 'copper_chunk', 'pickaxe'], ['mirewatch_coal', 128, 99, 'Fen coal outcrop', 'mining', 'coal_chunk', 'pickaxe'],
  ['highland_silver_1', 176, 62, 'Highland silver vein', 'mining', 'highland_silver', 'pickaxe'], ['frost_iron', 222, 51, 'Frozen iron vein', 'mining', 'iron_ore', 'pickaxe'],
  ['starfall_crystal_mine', 98, 146, 'Crater ore seam', 'mining', 'highland_silver', 'pickaxe'], ['nightglass_mine', 220, 174, 'Nightglass ore seam', 'mining', 'nightglass_shard', 'pickaxe'],
  ['harbor_hardwood_1', 34, 48, 'Young hardwood tree', 'woodcutting', 'hardwood_log', 'woodcut_axe'], ['greenhollow_tree_1', 89, 65, 'Mature hardwood tree', 'woodcutting', 'hardwood_log', 'woodcut_axe'],
  ['greenhollow_moonwood', 109, 58, 'Moonwood tree', 'woodcutting', 'moonwood_log', 'woodcut_axe'], ['fen_tree_1', 120, 81, 'Fen cypress', 'woodcutting', 'hardwood_log', 'woodcut_axe'],
  ['frostpine_1', 208, 54, 'Frostpine tree', 'woodcutting', 'frostpine_log', 'woodcut_axe'], ['savanna_tree_1', 173, 118, 'Redgrass acacia', 'woodcutting', 'hardwood_log', 'woodcut_axe'],
  ['coral_mangrove', 49, 149, 'Tidal mangrove', 'woodcutting', 'moonwood_log', 'woodcut_axe'], ['nightwood_1', 205, 164, 'Nightwood tree', 'woodcutting', 'nightwood_log', 'woodcut_axe']
];
for (const [id, x, y, label, skillId, yieldItemId, toolId] of resourceNodes) DATA.placements.push({ id: `place_${id}`, type: 'resource', entityId: id, x, y, z: 0, label, skillId, yieldItemId, toolId, respawnSeconds: 20 });

const OVERWORLD_HOLLOWS = [
  ['greenhollow_sink', 86, 64, 'Greenhollow Burrow'], ['fen_sink', 142, 96, 'Fen Silt Hollow'], ['highland_sink', 181, 57, 'Manticore Underden'],
  ['frost_sink', 232, 46, 'Gale-Ice Crevasse'], ['savanna_sink', 193, 113, 'Sunscale Lava Tube'], ['starfall_sink', 81, 139, 'Crater Undercroft'],
  ['coral_sink', 35, 143, 'Coral Tidal Shaft'], ['nightglass_sink', 238, 166, 'Eclipse Hollow'], ['orcrown_sink', 181, 159, 'Orcrown Escape Shaft'], ['oldwood_sink', 111, 54, 'Oldwood Root Drop']
];
for (const [id, x, y, label] of OVERWORLD_HOLLOWS) {
  DATA.placements.push({ id: `place_${id}_down`, type: 'hole', entityId: id, x, y, z: 0, targetX: x, targetY: y, targetZ: -1, label });
  DATA.placements.push({ id: `place_${id}_up`, type: 'rope_spot', entityId: `${id}_rope`, x, y, z: -1, targetX: x, targetY: y, targetZ: 0, label: `${label} rope point` });
}

DATA.zones.push({ id: 'orcrown_citadel', name: 'Orcrown Citadel', floor: 0, minLevel: 80, maxLevel: 220, danger: 'extreme', pz: false, color: '#91493c', description: 'A huge moated war castle with ranged battlements, ritual towers, barracks, forge, and a lethal inner keep.' });
DATA.placements.push(
  { id: 'place_harbor_depot', type: 'depot', entityId: 'harbor_depot', x: 19, y: 41, z: 0, label: 'Anchorage public depot' },
  { id: 'place_orcrown_drum', type: 'infrastructure', entityId: 'orcrown_war_drum', x: 169, y: 158, z: 0, label: 'Orcrown war drum' },
  { id: 'place_orcrown_ballista_w', type: 'infrastructure', entityId: 'orcrown_ballista', x: 158, y: 140, z: 0, label: 'West wall ballista' },
  { id: 'place_orcrown_ballista_e', type: 'infrastructure', entityId: 'orcrown_ballista', x: 183, y: 140, z: 0, label: 'East wall ballista' },
  { id: 'place_orcrown_forge', type: 'infrastructure', entityId: 'orcrown_forge', x: 159, y: 159, z: 0, label: 'Skullfire war forge' },
  { id: 'place_orcrown_cages', type: 'infrastructure', entityId: 'orcrown_cages', x: 182, y: 153, z: 0, label: 'Orcrown prison cages' },
  { id: 'place_orcrown_banner', type: 'infrastructure', entityId: 'orcrown_banner', x: 170, y: 141, z: 0, label: 'Warlord’s battle standard' }
);

DATA.tilePalette = [
  ['water', 'Deep Water', '#173f50', false, false, true], ['void', 'Void', '#07100e', false, false, false], ['grass', 'Harbor Grass', '#426747', true, false, false], ['town', 'Town Green', '#d0ad69', true, false, false],
  ['canopy_town', 'Canopy Town', '#55724c', true, false, false], ['bridge', 'Timber Bridge', '#a37a49', true, false, false], ['desert', 'Desert Sand', '#b78c5c', true, false, false], ['mountain_cave', 'Mountain Stone', '#4c4841', true, false, false],
  ['road', 'Packed Road', '#927958', true, false, false], ['house_floor', 'House Floor', '#8c7654', true, false, false], ['earth_cave', 'Earth Cave', '#5b4435', true, false, false], ['silk_cave', 'Silk Cave', '#51404f', true, false, false],
  ['forest', 'Forest', '#276043', true, false, false], ['fen', 'Fen', '#3d665c', true, false, false], ['highland', 'Highland', '#747469', true, false, false], ['snow', 'Snow', '#bddadd', true, false, false],
  ['savanna', 'Savanna', '#9a6542', true, false, false], ['starfall', 'Starfall Stone', '#50687d', true, false, false], ['tropical', 'Tropical Ground', '#3e8064', true, false, false], ['nightglass', 'Nightglass', '#49385d', true, false, false],
  ['root_cave', 'Root Cave', '#48543a', true, false, false], ['flooded_cave', 'Flooded Cave', '#385b61', true, false, false], ['volcanic_cave', 'Volcanic Cave', '#713b2d', true, false, false], ['ice_cave', 'Ice Cave', '#527b8c', true, false, false],
  ['coral_cave', 'Coral Cave', '#744f5a', true, false, false], ['abyss_cave', 'Abyss Cave', '#443254', true, false, false], ['fortress_floor', 'Fortress Flagstone', '#65574c', true, false, false], ['castle_wall', 'Castle Wall', '#332f2c', false, true, false],
  ['moat', 'Castle Moat', '#203d48', false, false, true], ['marble', 'Moon Marble', '#aaa9a2', true, false, false], ['lava', 'Lava', '#b74327', false, false, false], ['swamp_water', 'Swamp Water', '#314c3e', false, false, true],
  ['cobblestone', 'Cobblestone', '#77716a', true, false, false], ['farmland', 'Farmland', '#72583a', true, false, false], ['moss_stone', 'Moss Stone', '#526249', true, false, false], ['crystal_floor', 'Crystal Floor', '#6872a0', true, false, false],
  ['ash', 'Ash Ground', '#54504d', true, false, false], ['golden_sand', 'Golden Sand', '#c9a35d', true, false, false], ['wood_floor', 'Plank Floor', '#82613f', true, false, false], ['ice_bridge', 'Ice Bridge', '#8ebbc4', true, false, false]
].map(([id, name, color, walkable, wall, water]) => ({ id, name, terrain: id, color, walkable, wall, water, description: `${name} level-editor brush.` }));
DATA.levelTiles = [];
for (let y = 136; y <= 166; y++) for (let x = 154; x <= 186; x++) DATA.levelTiles.push({ id: `castle_floor_${x}_${y}`, x, y, z: 0, terrain: 'fortress_floor', color: '#65574c', walkable: true, wall: false, water: false });
const castleGate = (x, y) => ((x === 169 || x === 170) && (y === 136 || y === 166)) || ((y === 151 || y === 152) && (x === 154 || x === 186));
for (let y = 136; y <= 166; y++) for (let x = 154; x <= 186; x++) if ((x === 154 || x === 186 || y === 136 || y === 166) && !castleGate(x, y)) DATA.levelTiles.push({ id: `castle_wall_${x}_${y}`, x, y, z: 0, terrain: 'castle_wall', color: '#332f2c', walkable: false, wall: true, water: false });
for (let y = 135; y <= 167; y++) for (let x = 153; x <= 187; x++) if ((x === 153 || x === 187 || y === 135 || y === 167) && !(((x === 169 || x === 170) && (y === 135 || y === 167)) || ((y === 151 || y === 152) && (x === 153 || x === 187)))) DATA.levelTiles.push({ id: `castle_moat_${x}_${y}`, x, y, z: 0, terrain: 'moat', color: '#203d48', walkable: false, wall: false, water: true });
for (let y = 143; y <= 154; y++) for (let x = 163; x <= 177; x++) if ((x === 163 || x === 177 || y === 143 || y === 154) && !(y === 154 && (x === 169 || x === 170))) DATA.levelTiles.push({ id: `keep_wall_${x}_${y}`, x, y, z: 0, terrain: 'castle_wall', color: '#2b2927', walkable: false, wall: true, water: false });

// Grimfang Castle fills the broad northern mainland above the starter harbor.
DATA.zones.push({ id: 'grimfang_castle', name: 'Grimfang Castle', floor: 0, minLevel: 55, maxLevel: 145, danger: 'extreme', pz: false, color: '#7d4438', description: 'A huge northern Orc fortress of towers, barracks, kennels, siege yards, and a walled inner keep.' });
const northernOrcSpecs = [
  ['orc_grimfang_pikeman', 'Grimfang Pikeman', '‡', 62, 1450, 142, 68, 5200, 'physical', 2, 'Long-reach gate formation'],
  ['orc_grimfang_crossbow', 'Grimfang Crossbowman', '➳', 68, 1280, 164, 58, 6100, 'physical', 6, 'Battlement crossbow fire'],
  ['orc_grimfang_hexcaller', 'Grimfang Hexcaller', '♛', 76, 1540, 188, 62, 7500, 'death', 6, 'Ranged curses and shadow bolts'],
  ['orc_grimfang_berserker', 'Grimfang Berserker', '⚔', 84, 2350, 225, 86, 9400, 'physical', 1, 'Fast, hard-hitting melee assault'],
  ['orc_grimfang_warpriest', 'Grimfang War Priest', '✦', 91, 2600, 238, 104, 10800, 'fire', 5, 'Fire rites and war chants'],
  ['orc_grimfang_ogre', 'Grimfang Ogre Guard', '♜', 112, 4800, 315, 152, 18500, 'physical', 1, 'Extremely heavy keep defender']
];
for (const [id, name, icon, level, hp, attack, defense, xp, element, range, traits] of northernOrcSpecs) {
  DATA.monsters.push({ id, name, icon, level, hp, attack, defense, xp, speed: id.includes('berserker') ? 1.18 : .98, range, aggro: 9, element, dot: ['death', 'fire'].includes(element) ? Math.floor(level / 10) : 0, zone: 'grimfang_castle', traits, color: '#aa7046' });
  DATA.dropTables.push({ id: `drop_${id.replace('orc_', '')}`, monsterId: id, rolls: 2, nothingWeight: 4, entries: [
    { itemId: 'gold_piece', tier: 'always', weight: 100, min: level, max: level * 3 }, { itemId: 'orc_bone_token', tier: 'common', weight: 62, min: 1, max: 3 },
    { itemId: 'war_banner_scrap', tier: 'rare', weight: 9, min: 1, max: 2 }, { itemId: level >= 90 ? 'greater_tonic' : 'minor_potion', tier: 'rare', weight: 7, min: 1, max: 1 }
  ] });
}
DATA.buildings.push(
  { id: 'build_grimfang_gatehouse', name: 'Grimfang Gatehouse', type: 'castle', x: 35, y: 22, z: 0, width: 8, height: 5, npcIds: [], collision: 'fortified south gate' },
  { id: 'build_grimfang_keep', name: 'Grimfang Inner Keep', type: 'castle', x: 33, y: 8, z: 0, width: 12, height: 10, npcIds: [], collision: 'inner keep' },
  { id: 'build_grimfang_west_tower', name: 'Grimfang West Tower', type: 'tower', x: 26, y: 6, z: 0, width: 5, height: 5, npcIds: [], collision: 'tower' },
  { id: 'build_grimfang_east_tower', name: 'Grimfang East Tower', type: 'tower', x: 47, y: 6, z: 0, width: 5, height: 5, npcIds: [], collision: 'tower' },
  { id: 'build_grimfang_red_barracks', name: 'Red Pike Barracks', type: 'barracks', x: 26, y: 13, z: 0, width: 7, height: 6, npcIds: [], collision: 'open barracks' },
  { id: 'build_grimfang_black_barracks', name: 'Black Bolt Barracks', type: 'barracks', x: 46, y: 13, z: 0, width: 6, height: 6, npcIds: [], collision: 'open barracks' },
  { id: 'build_grimfang_kennels', name: 'Warg Kennels', type: 'stable', x: 26, y: 20, z: 0, width: 7, height: 5, npcIds: [], collision: 'reinforced kennels' },
  { id: 'build_grimfang_ritual_hall', name: 'Hexcaller Ritual Hall', type: 'hall', x: 45, y: 20, z: 0, width: 7, height: 5, npcIds: [], collision: 'ritual hall' }
);
DATA.placements.push(
  { id: 'place_tideglass_well', type: 'well', entityId: 'tideglass_well', x: 20, y: 38, z: 0, label: 'Tideglass Cottage well' },
  { id: 'place_tideglass_depot_box', type: 'depot', entityId: 'tideglass_depot_box', x: 22, y: 37, z: 0, label: 'Tideglass endless depot box' },
  { id: 'place_tideglass_training_dummy', type: 'training', entityId: 'tideglass_training_dummy', x: 24, y: 37, z: 0, label: 'Tideglass private training dummy', requiresHouseId: 'house_tideglass' },
  { id: 'place_harbor_rest_cot', type: 'rest', entityId: 'harbor_rest_cot', x: 18, y: 42, z: 0, label: 'Harbor rest cot' },
  { id: 'place_grimfang_drum', type: 'infrastructure', entityId: 'grimfang_war_drum', x: 38, y: 23, z: 0, label: 'Grimfang war drum' },
  { id: 'place_grimfang_ballista_w', type: 'infrastructure', entityId: 'grimfang_ballista', x: 28, y: 7, z: 0, label: 'West tower ballista' },
  { id: 'place_grimfang_ballista_e', type: 'infrastructure', entityId: 'grimfang_ballista', x: 49, y: 7, z: 0, label: 'East tower ballista' },
  { id: 'place_grimfang_kennel', type: 'infrastructure', entityId: 'grimfang_kennels', x: 29, y: 22, z: 0, label: 'Armored Warg kennels' },
  { id: 'place_grimfang_totem', type: 'infrastructure', entityId: 'grimfang_hex_totem', x: 48, y: 22, z: 0, label: 'Hexcaller bone totem' },
  { id: 'place_grimfang_forge', type: 'infrastructure', entityId: 'grimfang_forge', x: 30, y: 12, z: 0, label: 'Grimfang field forge' },
  { id: 'place_grimfang_banner', type: 'infrastructure', entityId: 'grimfang_banner', x: 39, y: 9, z: 0, label: 'Grimfang battle standard' }
);
DATA.npcs.push({ id: 'npc_tideglass_butler', name: 'Merrin Vale', role: 'Cottage butler', icon: '♙', x: 23, y: 37, z: 0, zoneId: 'anchorage_harbor', quests: [], shop: null, requiresHouseId: 'house_tideglass', inventory: ['bread', 'minor_potion'], description: 'Your Tideglass Cottage butler keeps the home orderly and watches over its depot.' });
DATA.butlers = DATA.butlers || [];
DATA.butlers.push({ id: 'butler_tideglass', name: 'Merrin Vale', houseId: 'house_tideglass', npcId: 'npc_tideglass_butler', inventory: ['bread', 'minor_potion'], shopId: null, cashBalance: 0, sourceSystem: 'emberwake' });
for (let y = 5; y <= 27; y++) for (let x = 25; x <= 52; x++) DATA.levelTiles.push({ id: `grimfang_floor_${x}_${y}`, x, y, z: 0, terrain: 'fortress_floor', color: '#5d5148', walkable: true, wall: false, water: false });
const grimfangGate = (x, y) => y === 27 && (x === 38 || x === 39);
for (let y = 5; y <= 27; y++) for (let x = 25; x <= 52; x++) if ((x === 25 || x === 52 || y === 5 || y === 27) && !grimfangGate(x, y)) DATA.levelTiles.push({ id: `grimfang_wall_${x}_${y}`, x, y, z: 0, terrain: 'castle_wall', color: '#302d2a', walkable: false, wall: true, water: false });
for (let y = 4; y <= 28; y++) for (let x = 24; x <= 53; x++) if ((x === 24 || x === 53 || y === 4 || y === 28) && !(y === 28 && (x === 38 || x === 39))) DATA.levelTiles.push({ id: `grimfang_moat_${x}_${y}`, x, y, z: 0, terrain: 'moat', color: '#203d48', walkable: false, wall: false, water: true });
for (let y = 9; y <= 18; y++) for (let x = 32; x <= 45; x++) if ((x === 32 || x === 45 || y === 9 || y === 18) && !(y === 18 && (x === 38 || x === 39))) DATA.levelTiles.push({ id: `grimfang_keep_wall_${x}_${y}`, x, y, z: 0, terrain: 'castle_wall', color: '#272624', walkable: false, wall: true, water: false });
for (let x = 18; x <= 39; x++) DATA.levelTiles.push({ id: `grimfang_approach_${x}`, x, y: 28, z: 0, terrain: 'road', color: '#927958', walkable: true, wall: false, water: false });
const northernOrcSpawns = [
  ['orc_grimfang_pikeman', 36, 24, 6], ['orc_grimfang_pikeman', 41, 24, 6], ['orc_grimfang_crossbow', 28, 8, 5], ['orc_grimfang_crossbow', 49, 8, 5],
  ['orc_grimfang_hexcaller', 47, 21, 5], ['orc_grimfang_hexcaller', 43, 12, 4], ['orc_grimfang_berserker', 30, 16, 5], ['orc_grimfang_berserker', 48, 16, 5],
  ['orc_grimfang_warpriest', 35, 14, 4], ['orc_grimfang_warpriest', 42, 14, 4], ['orc_grimfang_ogre', 35, 11, 3], ['orc_grimfang_ogre', 42, 11, 3],
  ['orc_tusk_grunt', 28, 23, 6], ['orc_redshield', 49, 23, 5], ['orc_blackarrow', 27, 12, 5], ['orc_bonecaster', 50, 12, 4],
  ['orc_warg_rider', 31, 23, 5], ['orc_gate_captain', 39, 20, 2]
];
DATA.spawns.push(...northernOrcSpawns.map(([monsterId, x, y, count], index) => ({ id: `spawn_${String(index + 97).padStart(3, '0')}`, monsterId, x, y, z: 0, count, radius: 3, respawnSeconds: 90, dangerBand: Math.ceil((byId(DATA.monsters, monsterId)?.level || 1) / 30), huntingSpot: true })));

for (const spawn of DATA.spawns) spawn.respawnSeconds = Math.max(45, Math.round(Number(spawn.respawnSeconds || 15) * 3));

DATA.questGivers = DATA.npcs.flatMap(npc => npc.quests.map(questId => ({ id: `${npc.id}_${questId}`, npcId: npc.id, questId, x: npc.x, y: npc.y, z: npc.z, interaction: 'button_modal', maxDistance: 1 })));

DATA.items.push({ id: 'spellbook', name: 'Vocation Spellbook', type: 'spellbook', icon: '▤', color: '#d8b86a', weight: 8, buy: 0, sell: 0, description: 'Opens the learned-spell index and assigns spells to hotbar slots 1–8.' });
for (const character of DATA.characters) {
  character.learnedSpells = [...character.spells];
  if (!character.inventory.some(stack => stack.id === 'spellbook')) character.inventory.unshift({ id: 'spellbook', qty: 1 });
  character.depot = character.depot || [];
  character.ownedMounts = character.ownedMounts || (character.mountId ? [character.mountId] : []);
}

const aster = byId(DATA.npcs, 'npc_aster');
if (aster && !aster.quests.includes('Q_12')) aster.quests.push('Q_12');
for (const [npcId, questId] of [['npc_wren', 'Q_07'], ['npc_orin', 'Q_13'], ['npc_vesper', 'Q_18']]) {
  const npc = byId(DATA.npcs, npcId); if (npc && !npc.quests.includes(questId)) npc.quests.push(questId);
}
DATA.questGivers = DATA.npcs.flatMap(npc => npc.quests.map(questId => ({ id: `${npc.id}_${questId}`, npcId: npc.id, questId, x: npc.x, y: npc.y, z: npc.z, interaction: 'button_modal', maxDistance: 1 })));

DATA.monsters.push(
  { id: 'mob_silk_tarantula', name: 'Silkfall Tarantula', icon: '✣', level: 44, hp: 620, attack: 68, defense: 26, xp: 1250, speed: 1.05, range: 1, aggro: 6, element: 'poison', dot: 10, zone: 'Silkfall Depths', traits: 'Web slow and poison', color: '#a879ae' },
  { id: 'boss_brood_tyrant', name: 'Brood Tyrant', icon: '✣', level: 58, hp: 2200, attack: 105, defense: 42, xp: 6500, speed: .95, range: 2, aggro: 9, element: 'poison', dot: 16, boss: true, zone: 'Silkfall Depths', traits: 'Giant spider; web burst', color: '#d25982' }
);

const vocationMagicRules = {
  black_knight: [.16, .08, 1.42, 1.16, .82], ancient_knight: [.2, .1, 1.35, 1.15, .86], ranger: [.38, .16, 1.2, 1.14, .95], court_ranger: [.46, .2, 1.12, 1.13, 1.02],
  sprite: [1.16, .58, .82, 1.1, 1.3], dryad: [1.3, .68, .76, 1.09, 1.42], necromancer: [1.38, .72, .78, 1.09, 1.45], lich: [1.55, .82, .7, 1.08, 1.58],
  priest: [1.24, .65, .8, 1.09, 1.38], warhealer: [.48, .22, 1.15, 1.14, 1], battlemage: [1.02, .5, .9, 1.11, 1.22], siege_operator: [.2, .08, 1.5, 1.17, .75]
};
for (const vocation of DATA.vocations) {
  const [perMagic, perCharacter, cost, growth, training] = vocationMagicRules[vocation.id] || [.5, .25, 1, 1.13, 1];
  Object.assign(vocation, { magicPowerPerMagicLevel: perMagic, magicPowerPerCharacterLevel: perCharacter, magicXpCostMultiplier: cost, magicXpGrowth: growth, magicTrainingRate: training });
}

DATA.gameRules = [
  { id: 'progression_rules', name: 'Progression & Recovery Rules', levelSpeedPerLevel: .0033, levelSpeedCap: .7, athleticsSpeedPerLevel: .0035, athleticsSpeedCap: .4, sneakSpeedMultiplier: .58, deathXpLossFraction: .1, proneRapidHealUntilFraction: .2, proneRapidHealPerSecondFraction: .035, toughnessDamageReductionPerLevel: .0032, toughnessDamageReductionCap: .38, strengthTrainingLoadThreshold: .2, description: 'Live global progression, defeat, speed, and training controls.' },
  { id: 'world_rules', name: 'World & Spawn Rules', minimumRespawnSeconds: 45, autoLootRadius: 1, cameraZoomMinimum: .35, cameraZoomMaximum: 2.4, minimapZoomMinimum: 1, minimapZoomMaximum: 3, description: 'Live world interaction and camera limits.' },
  { id: 'survival_rules', name: 'Hunger, Thirst & Rest Rules', hungerSecondsPerPoint: 180, thirstSecondsPerPoint: 120, restSecondsPerPoint: 150, hungerHealthFloor: 20, thirstHealthFloor: 5, tiredSpeedMultiplier: .5, tiredXpMultiplier: .5, wellThirstRestore: 100, restRestore: 100, description: 'Slow active-time survival drains and their live penalties.' }
];

// Cross-game authoring contract. These are definitions only: live objects keep stable keys,
// while saves persist snapshots and integration namespaces without serialising runtime pointers.
DATA.integrationSystems = [
  { id: 'emberwake', name: 'Emberwake', authority: 'movement, inventory, equipment, provenance, happiness, social simulation, personality, reputation, quests and modular authoring', schemaVersion: 19, contentVersion: 19, tablePrefix: 'FSG_TIBIALIKE_', ownership: 'account + server session + project + hierarchy filters', conflictPolicy: 'optimistic revision; stable IDs; merge unknown fields', status: 'source-of-truth' },
  { id: 'sovereign_aegis', name: 'Sovereign Aegis', authority: 'god-view definitions, buildings, creatures, jobs, research and realm simulation', schemaVersion: 1, contentVersion: 1, tablePrefix: 'FSG_GODSIM_', ownership: 'user scoped definitions; save scoped runtime', conflictPolicy: 'definition key wins; runtime def pointers are re-resolved', status: 'mapped' },
  { id: 'runelite_primitive_realm', name: 'Primitive Realm', authority: '32-skill player contract, 28-slot inventory, crafting, actors and revisioned player saves', schemaVersion: 10, contentVersion: 6, tablePrefix: 'FSG_Runelite_', ownership: 'owner_key + character_name', conflictPolicy: 'revision must match; HTTP 409 on stale save', status: 'mapped' },
  { id: 'stat_system_designer', name: 'Stat System Designer', authority: 'numeric stats, currencies, skills, encounters and XP rules', schemaVersion: 1, contentVersion: 1, tablePrefix: 'FSG_TIBIALIKE_', ownership: 'project definition + player progress', conflictPolicy: 'stat numeric authority after aliases', status: 'mapped' },
  { id: 'gameplay_designer', name: 'Gameplay Designer', authority: 'dialogue, inventory relationships, maps, sequences, graphs and Unity bindings', schemaVersion: 1, contentVersion: 1, tablePrefix: 'FSG_TIBIALIKE_', ownership: 'project topology and authored bindings', conflictPolicy: 'Unity bindings outrank topology; unknown components round-trip', status: 'mapped' },
  { id: 'field_sigil_rts', name: 'Field & Sigil RTS', authority: 'units, companies, formations, spells, buildings, economy, construction and research', schemaVersion: 1, contentVersion: 1, tablePrefix: 'FSG_TIBIALIKE_', ownership: 'project snapshot + normalized mirrors', conflictPolicy: 'opaque IDs; definitions separate from runtime fighters', status: 'mapped' }
];

DATA.worlds = [
  { id: 'world_emberwake', name: 'Emberwake Shared World', continentId: 'continent_dawnreach', sourceSystem: 'emberwake', active: true },
  { id: 'world_sovereign', name: 'Sovereign Aegis Realm', continentId: 'continent_dawnreach', sourceSystem: 'sovereign_aegis', active: true }
];
DATA.continents = [
  { id: 'continent_dawnreach', name: 'Dawnreach', worldId: 'world_emberwake', sourceSystem: 'emberwake' },
  { id: 'continent_crownstone', name: 'Crownstone Expanse', worldId: 'world_emberwake', sourceSystem: 'runelite_primitive_realm' }
];
DATA.villages = [
  { id: 'village_anchorage', name: 'Anchorage Harbor', worldId: 'world_emberwake', continentId: 'continent_dawnreach', zoneId: 'anchorage_harbor' },
  { id: 'village_crownstone', name: 'Crownstone City', worldId: 'world_emberwake', continentId: 'continent_crownstone', zoneId: 'runelite_city' },
  { id: 'village_aegis_keep', name: 'Aegis Keep', worldId: 'world_sovereign', continentId: 'continent_dawnreach', zoneId: 'aegis_player_ground' }
];
DATA.gameModes = [
  { id: 'hero', name: 'Villager to Hero', controlLayer: 'character' },
  { id: 'sovereign', name: 'Sovereign Command', controlLayer: 'god' },
  { id: 'simulation', name: 'Mechanical Test', controlLayer: 'developer' }
];

DATA.entityFamilies = [
  ['folk', 'Direct worker', 'villagerStep'], ['hero', 'Indirect hero', 'heroStep'], ['soldier', 'Banner soldier', 'soldierStep'],
  ['beast', 'Wild flock', 'beastStep'], ['monster', 'Hostile raider', 'monsterStep'], ['creature', 'Growing companion', 'creatureStep']
].map(([id, name, aiFunction]) => ({ id, name, aiFunction, definitionKey: 'classId', runtimeKey: 'entityId', persistenceRule: 'Store the stable class ID and re-resolve the live definition pointer after load.', sourceSystem: 'sovereign_aegis' }));

const aegisClassRows = [
  ['villager', 'Villager', 'folk'], ['warrior', 'Warrior', 'hero'], ['ranger', 'Ranger', 'hero'], ['druid', 'Druid', 'hero'], ['rogue', 'Rogue', 'hero'], ['wizard', 'Wizard', 'hero'], ['barbarian', 'Barbarian', 'hero'], ['priestess', 'Priestess', 'hero'], ['dwarf', 'Dwarf', 'hero'], ['elf', 'Elf', 'hero'], ['gnome', 'Gnome', 'hero'],
  ['pikeman', 'Pikeman', 'soldier'], ['swordsman', 'Swordsman', 'soldier'], ['archer', 'Archer', 'soldier'], ['scout', 'Scout', 'soldier'], ['ram', 'Battering Ram', 'soldier'],
  ['sheep', 'Sheep', 'beast'], ['deer', 'Deer', 'beast'], ['gnoll', 'Gnoll', 'monster'], ['ogre', 'Ogre', 'monster'], ['wraith', 'Wraith', 'monster'],
  ['source_slot_22', 'Unspecified Source Archetype', 'unresolved']
];
DATA.externalClasses = aegisClassRows.map(([id, name, family]) => ({ id, name, family, sourceSystem: 'sovereign_aegis', sourceStatus: id === 'source_slot_22' ? 'The supplied contract reports 22 classes but names 21; retained as an explicit unresolved source slot.' : 'verified', hp: 1, mp: 0, speed: 1, radius: .45, height: 1.7, attackRange: 0, attackSpeed: 1.25, damage: 0, baseSkills: {} }));

const aegisItemRows = [
  ['shortsword', 'Shortsword', 'weapon'], ['leather', 'Leather', 'armour'], ['longsword', 'Longsword', 'weapon'], ['chain', 'Chain Armour', 'armour'], ['greatsword', 'Greatsword', 'weapon'], ['plate', 'Plate Armour', 'armour'], ['shortbow', 'Shortbow', 'weapon'], ['yewbow', 'Yew Bow', 'weapon'], ['runeplate', 'Rune Plate', 'armour'], ['staff', 'Staff', 'weapon'], ['elderstaff', 'Elder Staff', 'weapon'], ['hammer', 'Hammer', 'tool'],
  ['source_item_13', 'Unspecified Source Item 13', 'unresolved'], ['source_item_14', 'Unspecified Source Item 14', 'unresolved'], ['source_item_15', 'Unspecified Source Item 15', 'unresolved'], ['source_item_16', 'Unspecified Source Item 16', 'unresolved'], ['source_item_17', 'Unspecified Source Item 17', 'unresolved']
];
DATA.externalItems = aegisItemRows.map(([id, name, kind]) => ({ id, name, kind, sourceSystem: 'sovereign_aegis', sourceStatus: kind === 'unresolved' ? 'Count-preserving source slot; definition was not enumerated in the supplied contract.' : 'verified', value: 0, attack: 0, defense: 0, heal: 0, skillId: '', bonus: 0, ranged: id.includes('bow'), magic: id.includes('staff') }));

DATA.jobs = [
  ['idle', '', 'Wanders near the keep'], ['forester', 'woodcutting', 'Fells trees into wood'], ['miner', 'mining', 'Works seams and veins into stone or gold'], ['builder', 'construction', 'Hauls timber, raises, repairs and sites houses'], ['farmer', 'farming', 'Works farmsteads into food'], ['forager', 'farming', 'Strips berry bushes into food'], ['hunter', 'ranged', 'Kills beasts and carries meat'], ['acolyte', 'prayer', 'Worships into spell energy'], ['worshipper', 'prayer', 'Temple-bound double-yield worship'], ['artisan', 'smithing', 'Staffs converter buildings'], ['breeder', 'breeding', 'Raises children and expands housing']
].map(([id, skillId, behavior]) => ({ id, name: id[0].toUpperCase() + id.slice(1), skillId, behavior, sourceSystem: 'sovereign_aegis' }));

DATA.research = [
  ['forging', 'Forging', 'blacksmith', 1, '', '120 gold, 60 stone', 'meleeDamage +2'], ['ironCasting', 'Iron Casting', 'blacksmith', 2, 'forging', '240 gold, 120 stone', 'meleeDamage +3'], ['scaleMail', 'Scale Mail', 'blacksmith', 1, '', '140 gold, 80 stone', 'armour +2'], ['chainMail', 'Chain Mail', 'blacksmith', 2, 'scaleMail', '260 gold, 140 stone', 'armour +3'], ['fletching', 'Fletching', 'blacksmith', 1, '', '130 gold, 120 wood', 'rangedDamage +2, range +1'], ['bodkinArrow', 'Bodkin Arrows', 'blacksmith', 2, 'fletching', '250 gold, 220 wood', 'rangedDamage +3, range +1'], ['masonry', 'Masonry', 'university', 2, '', '180 stone, 100 gold', 'buildingHp +30%'], ['architecture', 'Architecture', 'university', 3, 'masonry', '300 stone, 200 gold', 'buildingHp +30%, buildRate +33%'], ['doubleBitAxe', 'Double-Bit Axe', 'university', 1, '', '150 wood, 80 gold', 'woodRate +35%'], ['stoneMining', 'Stone Mining', 'university', 1, '', '130 wood, 80 gold', 'oreRate +35%'], ['wheelbarrow', 'Wheelbarrow', 'university', 2, '', '180 wood, 140 gold', 'folkSpeed +25%, carry +50%'], ['theocracy', 'Theocracy', 'university', 2, '', '260 gold, 120 stone', 'prayerRate +60%'], ['heraldry', 'Heraldry', 'university', 2, '', '300 gold', 'bountyDiscount 20%'], ['ballistics', 'Ballistics', 'university', 3, '', '200 wood, 180 gold', 'towerRate +40%, towerRange +25%']
].map(([id, name, buildingId, age, requiresResearchId, costText, effectText]) => ({ id, name, buildingId, age, requiresResearchId, costText, effectText, sourceSystem: 'sovereign_aegis' }));

DATA.effectTypes = [
  ['stat', 'number', 'Modify a numeric stat'], ['currency', 'number', 'Modify a currency'], ['skillXp', 'number', 'Award skill experience'], ['playerXp', 'number', 'Award player experience'],
  ['popCap', 'number', 'Raise population cap'], ['recruits', 'number', 'Attract guild heroes'], ['gatherBonus', 'ratio', 'Speed nearby gathering'], ['produces', 'resourceRate', 'Passive resource production'], ['converts', 'conversion', 'Worker-fed resource conversion'], ['appeal', 'number', 'Modify town appeal'], ['heal', 'rate', 'Heal nearby friendlies'], ['garrison', 'classCount', 'Maintain defenders'], ['range', 'number', 'Attack or vision range'], ['damage', 'number', 'Attack damage'], ['rate', 'seconds', 'Action interval'], ['energyBonus', 'number', 'Raise spell-energy ceiling'], ['energyCap', 'number', 'Set base spell-energy ceiling'], ['prayerRate', 'ratio', 'Worship yield'], ['gearTier', 'number', 'Cap hero gear ladder'], ['taxRate', 'ratio', 'Crown share of spending'], ['research', 'boolean', 'Sell research'], ['unlocks', 'classId', 'Unlock a recruit'], ['dropOff', 'boolean', 'Accept gathered resources'], ['storage', 'number', 'Storage scale'], ['buildRate', 'ratio', 'Global construction bonus'], ['attackBonus', 'ratio', 'Realm attack multiplier'], ['defenceBonus', 'ratio', 'Realm defence multiplier'], ['breedBonus', 'ratio', 'Shorten birth interval'], ['lifespanBonus', 'number', 'Add years to lives'], ['trainHeroes', 'number', 'Grant combat XP'], ['alignDrift', 'rate', 'Shift alignment'], ['crime', 'ratio', 'Modify crime'], ['distraction', 'ratio', 'Modify distraction'], ['wonder', 'boolean', 'Victory monument'], ['vision', 'number', 'Sight radius'], ['onHitEffect', 'effectId', 'RTS hit effect'], ['status', 'effectId', 'Timed status'], ['teleport', 'areaId', 'Move to area']
].map(([id, valueType, behavior]) => ({ id, name: id, valueType, behavior, sourceSystem: id === 'stat' || id === 'currency' || id === 'skillXp' || id === 'playerXp' ? 'stat_system_designer' : 'sovereign_aegis' }));

DATA.idAliases = [
  ['skills.fists', 'skills.fists_skin'], ['currencies.build', 'currencies.build_points'], ['player.experience', 'player.xp'], ['player.experienceToLevel', 'player.xpToNext'], ['bronze_axe', 'bronze_hatchet'], ['bronze_platebody', 'bronze_body'], ['bronze_platelegs', 'bronze_legs']
].map(([fromId, toId]) => ({ id: `alias_${fromId.replace(/[^a-z0-9]+/gi, '_')}`, name: `${fromId} → ${toId}`, fromId, toId, migration: 'resolve on import; persist canonical stable ID', sourceSystem: 'shared' }));

DATA.relationships = [
  ['rel_world_continent', 'worlds', 'world_emberwake', 'continents', 'continent_dawnreach', 'contains', 'one-to-many'],
  ['rel_continent_village', 'continents', 'continent_dawnreach', 'villages', 'village_anchorage', 'contains', 'one-to-many'],
  ['rel_quest_giver', 'quests', 'Q_01', 'npcs', 'npc_aster', 'given-by', 'many-to-one'],
  ['rel_shop_stock', 'shops', 'magic', 'items', 'spark_wand', 'sells', 'many-to-many'],
  ['rel_drop_item', 'dropTables', 'drop_brood_tyrant', 'items', 'spider_silk', 'drops', 'many-to-many'],
  ['rel_class_family', 'externalClasses', 'warrior', 'entityFamilies', 'hero', 'dispatches-through', 'many-to-one'],
  ['rel_research_building', 'research', 'forging', 'externalBuildings', 'blacksmith', 'sold-at', 'many-to-one'],
  ['rel_definition_instance', 'vocations', 'black_knight', 'characters', 'char_1', 'defines', 'one-to-many']
].map(([id, sourceCategory, sourceId, targetCategory, targetId, relationshipType, cardinality]) => ({ id, name: relationshipType, sourceCategory, sourceId, targetCategory, targetId, relationshipType, cardinality, cascade: 'restrict', sourceSystem: 'shared' }));

DATA.formulaDefinitions = [
  { id: 'runelite_xp_curve', name: 'RuneLite XP Curve', sourceSystem: 'runelite_primitive_realm', expression: 'floor(sum(level + 300 * 2^(level / 7)) / 4)', inputs: ['level'], output: 'requiredXp', derived: true },
  { id: 'overall_magic', name: 'Overall Magic', sourceSystem: 'runelite_primitive_realm', expression: 'floor((magic + runecrafting + rune_shooting) / 3)', inputs: ['magic', 'runecrafting', 'rune_shooting'], output: 'overall_magic', derived: true },
  { id: 'carry_capacity', name: 'Carry Capacity', sourceSystem: 'runelite_primitive_realm', expression: '45 + strength * 2.25', inputs: ['strength'], output: 'carryCapacity', derived: true },
  { id: 'aegis_attack_power', name: 'Aegis Attack Power', sourceSystem: 'sovereign_aegis', expression: 'damage + skill * .8 + equipAttack * .6 + technology', inputs: ['damage', 'skill', 'equipAttack', 'technology'], output: 'attackPower', derived: true },
  { id: 'aegis_tier_cost', name: 'Building Tier Cost', sourceSystem: 'sovereign_aegis', expression: 'baseCost * tier * 1.7', inputs: ['baseCost', 'tier'], output: 'upgradeCost', derived: true },
  { id: 'rts_tier_stat', name: 'RTS Tier Stat', sourceSystem: 'field_sigil_rts', expression: 'baseValue * tierMultiplier', inputs: ['baseValue', 'tierMultiplier'], output: 'tierValue', derived: true }
];

DATA.apiActions = [
  ['health', 'GET', false, 'Connectivity and schema probe'], ['status', 'GET', false, 'Identity, revision and server status'], ['session', 'GET', false, 'Session bootstrap plus current account-private save'], ['register', 'POST', false, 'Create shared suite account'], ['login', 'POST', false, 'Open shared suite account session'], ['logout', 'POST', false, 'Close shared account session'], ['listServerSessions', 'GET', true, 'List approved Emberwake server sessions'], ['adminPanel', 'GET', true, 'Read accounts, access requests, roles, and guild tags'], ['requestSessionAccess', 'POST', true, 'Request access from the immutable original admin'], ['reviewSessionAccess', 'POST', true, 'Original admin approval, denial, or revocation'], ['setMemberRole', 'POST', true, 'Apply bounded moderator and authoring roles'], ['setGuildMemberTag', 'POST', true, 'Assign guild rank, title, and guild-moderator tags'], ['villageStore','GET',true,'Read the session-shared civic item store'], ['transferVillageStore','POST',true,'Deposit to or withdraw from the session-shared civic item store'], ['listSaves', 'GET', true, 'List account-owned save heads'], ['save', 'POST', false, 'Revisioned player state and authorized catalog transaction'], ['load', 'GET', false, 'Load current account and session project save'], ['deleteSave', 'POST', true, 'Delete the account-owned project snapshot'], ['saveContent', 'POST', true, 'Publish authorized revisioned definitions'], ['loadContent', 'GET', false, 'Load latest session definitions'], ['listEvents', 'GET', false, 'Read account-private deduplicated gameplay events'], ['logEvents', 'POST', false, 'Append account-private gameplay events'], ['listCatalog', 'GET', false, 'List session-authoritative authored categories'], ['validate', 'POST', false, 'Validate IDs and references without saving']
].map(([id, method, requiresAuth, description]) => ({ id, name: id, method, requiresAuth, path: `app.php?action=${id}`, requestType: 'application/json', responseShape: '{status,message,...}', description }));

const aegisSqlTables = ['saves', 'world_state', 'resources', 'units', 'unit_skills', 'unit_items', 'buildings', 'nodes', 'flags', 'squads', 'lairs', 'research', 'missions', 'creature', 'creature_skills', 'creature_spells', 'models', 'parts', 'scenarios', 'events', 'player_stats'];
const runeliteSqlTables = ['ContentVersions', 'PlayerSaves', 'PlayerEvents', 'WorldInstances', 'AuditLog', 'ServerLocks'];
const emberwakeSessionTables = ['ServerSessions', 'ServerSessionMembers', 'SessionAccessRequests', 'GuildMemberTags', 'VillageStoreItems'];
DATA.externalTables = [
  ...aegisSqlTables.map((name, index) => ({ id: `FSG_GODSIM_${name}`, name: `FSG_GODSIM_${name}`, sourceSystem: 'sovereign_aegis', ordinal: index + 1, grain: 'See source payload; stable definition keys and save-scoped runtime IDs', storage: 'normalized mirror plus JSON where required' })),
  ...runeliteSqlTables.map((name, index) => ({ id: `FSG_Runelite_${name}`, name: `FSG_Runelite_${name}`, sourceSystem: 'runelite_primitive_realm', ordinal: index + 1, grain: name === 'PlayerSaves' ? 'owner_key + character_name' : 'source-defined', storage: 'server-authoritative persistence' })),
  ...emberwakeSessionTables.map((name, index) => ({ id: `FSG_TIBIALIKE_${name}`, name: `FSG_TIBIALIKE_${name}`, sourceSystem: 'emberwake', ordinal: index + 1, grain: name === 'ServerSessions' ? 'project_id + session_id; immutable admin_id' : 'project_id + session_id + account or guild key', storage: 'session-correlated authorization and account isolation' }))
];

const runeliteRootFields = ['schemaVersion', 'name', 'color', 'area', 'position', 'target', 'hp', 'maxHp', 'mp', 'maxMp', 'prayer', 'maxPrayer', 'runEnergy', 'runEnabled', 'skills', 'inventory', 'equipment', 'ammoQty', 'bank', 'spellbook', 'hotbar', 'quests', 'collection', 'kills', 'crafted', 'flags', 'achievements', 'adoptedPets', 'minigames', 'preferences', 'buffs', 'training', 'cottage', 'slayerTask', 'combatTarget', 'attackCooldown', 'combatStyle', 'wanted', 'poison', 'farm', 'sneaking', 'stealthDetected', 'deaths', 'recentLevels', 'playSeconds', 'saveRevision', 'lastSavedAt', 'integrations'];
const aegisWorldFields = ['godName', 'worldName', 'continentName', 'villageName', 'creatureKind', 'creatureName', 'gameMode', 'age', 'align', 'energy', 'time', 'kills', 'res', 'researched', 'clock', 'time_settings', 'threats', 'units', 'buildings', 'nodes', 'flags', 'squads', 'missions', 'lairs', 'creature'];
const rtsProjectFields = ['schemaVersion', 'projectId', 'projectName', 'units', 'formations', 'spells', 'buildingTypes', 'buildingComplexes', 'resources', 'research', 'economy', 'buildings', 'constructionQueue'];
DATA.schemaFields = [
  ...runeliteRootFields.map(path => ({ id: `runelite_${path}`, name: path, sourceSystem: 'runelite_primitive_realm', scope: 'player', path, valueType: ['inventory', 'hotbar', 'bank', 'recentLevels'].includes(path) ? 'array' : ['skills', 'equipment', 'spellbook', 'quests', 'flags', 'integrations'].includes(path) ? 'object' : 'scalar', persistence: 'player save', derived: ['target', 'combatTarget'].includes(path) ? 'reset-on-load' : 'stored', mergeRule: ['skills', 'quests', 'flags', 'collection', 'kills', 'achievements', 'integrations'].includes(path) ? 'deep-merge' : 'replace' })),
  ...aegisWorldFields.map(path => ({ id: `aegis_world_${path}`, name: path, sourceSystem: 'sovereign_aegis', scope: 'world', path: `world.${path}`, valueType: ['units', 'buildings', 'nodes', 'squads', 'missions', 'lairs'].includes(path) ? 'array' : 'value', persistence: 'world snapshot', derived: path === 'clock' ? 'derived-and-stored' : 'stored', mergeRule: 'stable-key merge' })),
  ...rtsProjectFields.map(path => ({ id: `rts_${path}`, name: path, sourceSystem: 'field_sigil_rts', scope: 'project', path, valueType: path === 'schemaVersion' ? 'number' : 'value', persistence: 'project snapshot', derived: false, mergeRule: 'opaque-ID merge' }))
];

DATA.categorySchemas = [
  ['character', 'characters', ['id', 'name', 'vocationId', 'level', 'skills', 'inventory', 'equipment', 'quests', 'flags']], ['item', 'items', ['id', 'name', 'type', 'weight', 'stackable', 'slot', 'stats']], ['class', 'externalClasses', ['id', 'name', 'family', 'hp', 'mp', 'speed', 'damage', 'baseSkills']], ['building', 'externalBuildings', ['id', 'name', 'age', 'costText', 'work', 'hp', 'width', 'depth', 'height', 'effectsText']], ['quest', 'quests', ['id', 'name', 'giverId', 'requirements', 'objectives', 'rewards']], ['npc', 'npcs', ['id', 'name', 'role', 'shop', 'quests', 'inventory', 'spellbook']], ['relationship', 'relationships', ['id', 'sourceCategory', 'sourceId', 'targetCategory', 'targetId', 'relationshipType', 'cardinality']], ['unityBinding', 'externalRecords', ['id', 'fileId', 'globalObjectId', 'name', 'payload']], ['formation', 'externalRecords', ['id', 'name', 'slots', 'stance', 'payload']], ['dialogue', 'externalRecords', ['id', 'name', 'conditions', 'actions', 'payload']]
].map(([id, category, fields]) => ({ id, name: id, category, fields, stableIdRequired: true, metadataFields: ['iconDirectory', 'modelDirectory', 'description', 'tooltip'], unknownFields: 'preserve' }));

DATA.externalRecords = [
  { id: 'dialogue_globals', name: 'Dialogue Globals', sourceSystem: 'gameplay_designer', category: 'dialogue', payload: { languages: [], cast: [], typedTokens: [], states: [], moods: [], settings: [], times: [], days: [], menuOptions: [], imageSequences: [] } },
  { id: 'unity_bindings', name: 'Unity Bindings', sourceSystem: 'gameplay_designer', category: 'unityBinding', payload: { components: [], bindings: [], preserveUnknown: true } },
  { id: 'rts_project', name: 'RTS Project Envelope', sourceSystem: 'field_sigil_rts', category: 'formation', payload: { units: [], formations: [], spells: [], buildingTypes: [], buildingComplexes: [], resources: [], research: [], economy: {}, buildings: [], constructionQueue: [] } },
  { id: 'stat_project', name: 'Stat Designer Envelope', sourceSystem: 'stat_system_designer', category: 'stats', payload: { categories: [], currencies: [], skills: [], map: {}, encounters: [], assets: [], testLayer: {} } }
];

const AEGIS_BUILDING_CATALOG = `keep|Keep|Dark|wood:220,stone:220|0|900|6x6x7||popCap:6
house|House|Dark|wood:45|7|110|2.4x2.4x2.6||popCap:4
hut|Hut|Dark|wood:35|5|90|2x2x2.4||popCap:4
store|Village Store|Dark|wood:80|11|240|3.4x3.4x3.2||
wall|Wall|Dark|stone:14|0|220|2x2x2.6||blocks:1
gate|Gate|Dark|wood:40,stone:20|4|260|2x2x3||blocks:2
tower|Watchtower|Feudal|wood:60,stone:90|12|340|2.4x2.4x6.5||range:16,damage:14,rate:1.2
lumber|Lumber Camp|Dark|wood:75|12|220|3.6x3.6x2.8||gatherBonus:.3
mine|Mining Camp|Dark|wood:60,stone:25|12|220|3.6x3.6x2.8||gatherBonus:.3
farm|Farmstead|Dark|wood:70|10|180|4x4x2.2||foodRate:1.4
mill|Mill|Dark|wood:85|11|200|3.2x3.2x5.4||gatherBonus:.35,foodTithe:.5
blacksmith|Blacksmith|Feudal|wood:110,stone:70|16|280|4x4x3.2||attackBonus:.12,defenceBonus:.12
stable|Stable|Feudal|wood:130,food:40|16|280|4.6x4.6x3||unlocks:scout
siege|Siege Workshop|Castle|wood:180,stone:100|20|320|5x5x3.4||unlocks:ram
mageTower|Mage Tower|Castle|wood:150,stone:130,gold:120|20|300|3.6x3.6x9.5||energyBonus:60,range:18,damage:22,rate:2.2
university|University|Castle|wood:180,stone:140,gold:80|22|340|5x5x6||research:true
torch|Torch|Dark|wood:12|0|40|1x1x3.2||light:14,ward:5
market|Marketplace|Feudal|wood:120,stone:60|16|260|4.4x4.4x3.4||gearTier:2,taxRate:.5
tavern|Tavern|Dark|wood:95|14|230|4x4x3.2||taxRate:.5
temple|Godly Temple|Dark|wood:260,stone:220|34|900|11x11x20||prayerRate:1,energyCap:120
barracks|Barracks|Feudal|wood:130,stone:70|18|340|5x5x3.6||squads:1
warriorGuild|Warrior's Guild|Dark|wood:120,stone:70|18|300|4.4x4.4x4.2|warrior|recruits:1
rangerLodge|Ranger's Lodge|Feudal|wood:110,stone:45|16|260|4.4x4.4x4|ranger|recruits:1
druidGrove|Druid Grove|Feudal|wood:130,stone:50|18|280|4.4x4.4x4.6|druid|recruits:1
rogueDen|Rogues' Den|Castle|wood:140,stone:60,gold:110|20|260|4.2x4.2x3.6|rogue|recruits:1
conclave|Wizard Conclave|Imperial|wood:170,stone:140,gold:180|26|280|4.6x4.6x7|wizard|recruits:1
archery|Archery Range|Feudal|wood:120,stone:30|16|250|4.6x4.6x3.2||unlocks:archer,rangedBonus:.1
outpost|Outpost|Dark|wood:20,stone:10|4|120|1.6x1.6x5||vision:34
palisade|Palisade|Dark|wood:6|0|70|2x2x2||blocks:1
dock|Dock|Dark|wood:130|14|240|5x5x3||produces:food .7,appeal:2
feitoria|Feitoria|Imperial|wood:300,stone:250,gold:300|30|420|5x5x4.4||produces:wood .35 stone .35 gold .5 food .35
wonder|Wonder|Imperial|wood:900,stone:900,gold:800,iron:150|90|2000|14x14x26||wonder:true,appeal:40,popCap:20
guardhouse|Guardhouse|Dark|wood:70,stone:50|12|280|3.4x3.4x3.4||garrison:pikeman x2,range:12,damage:8,rate:1.6
ballista|Ballista Tower|Castle|wood:110,stone:80,iron:20|16|360|2.6x2.6x7.5||range:22,damage:34,rate:2.4
library|Library|Feudal|wood:130,stone:90,gold:60|18|250|4.2x4.2x4||research:true,spellDiscount:.15,appeal:4
fairgrounds|Fairgrounds|Feudal|wood:150,gold:80|16|200|6x6x2.6||trainHeroes:.6,appeal:8
gardens|Royal Gardens|Feudal|wood:90,stone:60,gold:40|12|160|5x5x2.2||heal:5,appeal:12
bazaar|Magic Bazaar|Castle|wood:110,gold:120|16|220|4x4x3.4||taxRate:.55,heroPotions:true,appeal:3
gambling|Gambling Hall|Castle|wood:120,gold:90|16|220|4.4x4.4x3.4||produces:gold 1.6,distraction:.35,appeal:5
tradingPost|Trading Post|Feudal|wood:120,stone:40|14|230|4x4x3.2||produces:gold 1.1,caravan:true
graveyard|Graveyard|Dark|wood:50,stone:60|10|180|4x4x1.8||burial:true,appeal:-3,hauntChance:.02
barbarianHall|Barbarian Hall|Feudal|wood:150,stone:60|20|320|5x5x4.2|barbarian|recruits:1
crypt|Crypt of Krypta|Castle|wood:140,stone:120,gold:100|22|300|4.6x4.6x5|priestess|recruits:1,alignDrift:-.02
dwarfHall|Dwarven Settlement|Feudal|wood:130,stone:150,gold:80|22|400|5x5x3.6|dwarf|recruits:1,buildRate:.25
elvenLounge|Elven Lounge|Castle|wood:160,gold:140|20|260|4.6x4.6x4.4|elf|recruits:1,produces:gold 1.4,crime:.2
gnomeHovel|Gnome Hovel|Dark|wood:60|8|140|3x3x2.2|gnome|recruits:2,buildRate:.15
workshop|Scaffold Workshop|Dark|wood:90|14|220|4.4x4.4x3.4||converts:wood8 to goods2 every5,buildRate:.2
creche|Creche|Dark|wood:70|10|170|3.6x3.6x2.6||breedBonus:.5,appeal:6
cemetery|Cemetery|Dark|stone:90|12|220|4.4x4.4x2||burial:true,appeal:4
dispenser|Miracle Dispenser|Castle|stone:120,gold:150|18|240|2.6x2.6x4||produces:energy 1.2,energyBonus:40
villa|Villa|Feudal|wood:110,stone:70|14|200|3.4x3.4x3.6||popCap:8,appeal:9
manor|Manor|Castle|wood:200,stone:160,gold:90|22|320|5x5x5.4||popCap:14,appeal:20
amphitheatre|Amphitheatre|Castle|wood:180,stone:220|26|380|7x7x4||appeal:26
baths|Baths|Feudal|wood:110,stone:130|18|260|5x5x2.8||heal:3,appeal:14
hospital|Hospital|Castle|wood:150,stone:110,gold:70|22|300|5x5x3.6||heal:9,lifespanBonus:8,appeal:10
prison|Prison|Castle|wood:120,stone:180,iron:30|22|420|5x5x4||appeal:-14,crime:-.6,alignDrift:-.03
smelter|Smelter|Feudal|wood:120,stone:140|20|300|4.4x4.4x4.4||converts:stone6 to iron2 every6
storehouse|Storehouse|Dark|wood:120,stone:40|16|280|5x5x3.4||storage:600,dropOff:true
armory|Armory|Feudal|wood:130,stone:90,iron:20|18|320|4.6x4.6x3.4||unlocks:swordsman,armourBonus:.1
gatherHut|Gathering Hut|Dark|wood:35|6|130|2.6x2.6x2.4||produces:food .45,gatherBonus:.2
fisher|Fisher's Hut|Dark|wood:60|9|150|3x3x2.6||produces:food .8
hunterHut|Hunter's Hut|Dark|wood:55|9|150|3x3x2.6||gatherBonus:.35,produces:food .3
stonecutter|Stonecutter Camp|Dark|wood:70|11|200|3.6x3.6x2.8||gatherBonus:.3,converts:stone10 to goods2 every7
bakery|Bakery|Feudal|wood:90,stone:40|14|200|3.6x3.6x3||converts:food6 to food11 every6,appeal:5
brewery|Brewery|Feudal|wood:110,stone:40|16|220|4x4x3.4||converts:food8 to goods3 every7,appeal:12
weaver|Weaver's Hut|Dark|wood:80|12|180|3.4x3.4x2.8||converts:food4 to goods2 every6
jeweler|Jeweller's Workshop|Castle|wood:110,stone:70,gold:60|18|220|3.6x3.6x3.2||converts:gold10 to goods4 every7,appeal:6
weaponsmith|Weaponsmith|Castle|wood:110,stone:80,iron:20|18|280|4x4x3.2||converts:iron3 to goods3 every6,attackBonus:.08
well|Well|Dark|stone:35|5|120|1.8x1.8x1.8||appeal:6,heal:1.5,lifespanBonus:3
warehouse|Warehouse|Feudal|wood:150,stone:60|18|320|5.4x5.4x3.8||storage:900,dropOff:true,converts:goods3 to gold26 every8
chapel|Chapel|Dark|wood:90,stone:90|16|240|3.6x3.6x5.4||prayerRate:.4,energyBonus:15`;

DATA.externalBuildings = AEGIS_BUILDING_CATALOG.trim().split('\n').map(line => {
  const [id, name, age, costText, work, hp, dimensions, guildId, effectsText] = line.split('|');
  const [width, depth, height] = dimensions.split('x').map(Number);
  return { id, name, age, costText, work: Number(work), hp: Number(hp), width, depth, height, guildId, effectsText, tiers: 4, collider: { width, depth, height }, parts: [], iconDirectory: '/assets/icons/externalBuildings/', modelDirectory: '/assets/models/externalBuildings/', description: `${name} definition imported from the Sovereign Aegis contract.`, tooltip: `${name} · ${age} age · ${hp} HP · ${effectsText || 'no generic effects'}`, sourceSystem: 'sovereign_aegis' };
});

if (!byId(DATA.skills, 'tailoring')) DATA.skills.push({ id: 'tailoring', name: 'Tailoring', family: 'Artisan', source: 'Shared crafting addition', color: '#a98dcc', description: 'Turns creature cloth and inexpensive reagents into caster equipment. Level 50 unlocks concealment; level 100 unlocks best-in-slot robes.' });
DATA.items.push(
  { id: 'tailoring_kit', name: 'Foldsteel Tailoring Kit', type: 'tool', icon: '✂', color: '#c7a5d7', weight: 6, buy: 25, sell: 5, action: 'tailoring', description: 'Opens the Tailoring workbench anywhere.' },
  { id: 'coarse_cloth', name: 'Coarse Beastcloth', type: 'material', icon: '▧', color: '#aa9678', weight: .5, buy: 3, sell: 1, stackable: true, description: 'Common cloth recovered from local humanoids and nests.' },
  { id: 'linen_roll', name: 'Harbor Linen Roll', type: 'material', icon: '▤', color: '#ded4b7', weight: 1, buy: 7, sell: 2, stackable: true, description: 'Cheap prepared cloth sold by harbor tailors.' },
  { id: 'silken_thread', name: 'Silken Thread', type: 'material', icon: '⌁', color: '#dbcce1', weight: .1, buy: 2, sell: 0, stackable: true, description: 'Cheap binding reagent for tailored equipment.' },
  { id: 'moonweave_bolt', name: 'Moonweave Bolt', type: 'material', icon: '▥', color: '#bba9dc', weight: 1.2, buy: 0, sell: 35, stackable: true, description: 'Refined spider silk used in master tailoring.' },
  { id: 'apprentice_robe', name: 'Harbor Apprentice Robe', type: 'armor', slot: 'body', icon: '♙', color: '#879aca', armor: 3, magicPower: 2, weight: 13, buy: 90, sell: 22, description: 'A practical first tailored caster robe.' },
  { id: 'veilcloak', name: 'Veilstep Cloak', type: 'armor', slot: 'body', icon: '◒', color: '#6f6385', armor: 8, magicPower: 8, stealthBonus: .35, weight: 9, buy: 2200, sell: 550, description: 'Tailoring 50 cloak that greatly reduces detection while sneaking.' },
  { id: 'luminary_bis_robe', name: 'Sovereign Luminary Vestment', type: 'armor', slot: 'body', icon: '✦', color: '#ead98f', armor: 24, magicPower: 32, healingPower: .25, weight: 12, buy: 18000, sell: 4500, bestInSlot: ['priest', 'sprite', 'dryad'], description: 'Tailoring 100 best-in-slot vestment for priests and restorative casters.' },
  { id: 'nightweave_bis_robe', name: 'Nightweave Lich Mantle', type: 'armor', slot: 'body', icon: '♛', color: '#9a75c2', armor: 22, magicPower: 38, deathPower: .25, weight: 11, buy: 19000, sell: 4750, bestInSlot: ['necromancer', 'lich', 'battlemage'], description: 'Tailoring 100 best-in-slot mantle for destructive casters.' },
  { id: 'satchel_bag', name: 'Sixteen-Pocket Satchel', type: 'container', slot: null, icon: '▣', color: '#9a774d', capacity: 16, acceptsContainers: true, weight: 8, buy: 140, sell: 35, description: 'A movable container that can hold items and smaller bags. Contents add to carried weight.' },
  { id: 'pocket_pouch', name: 'Nested Pocket Pouch', type: 'container', slot: null, icon: '▪', color: '#b08b5f', capacity: 8, acceptsContainers: true, weight: 3, buy: 55, sell: 13, description: 'A small bag that may be placed inside a larger bag.' }
);

DATA.tailoringRecipes = [
  { id: 'tailor_coarse_linen', name: 'Bind Coarse Linen', skillId: 'tailoring', level: 1, inputs: { coarse_cloth: 2, silken_thread: 1 }, outputs: { linen_roll: 1 }, xp: 18, station: 'tailoring_kit' },
  { id: 'tailor_apprentice_robe', name: 'Harbor Apprentice Robe', skillId: 'tailoring', level: 10, inputs: { linen_roll: 4, silken_thread: 3 }, outputs: { apprentice_robe: 1 }, xp: 90, station: 'tailoring_kit' },
  { id: 'tailor_moonweave', name: 'Weave Mooncloth', skillId: 'tailoring', level: 35, inputs: { spider_silk: 4, silken_thread: 2 }, outputs: { moonweave_bolt: 1 }, xp: 180, station: 'tailoring_kit' },
  { id: 'tailor_veilcloak', name: 'Veilstep Cloak', skillId: 'tailoring', level: 50, inputs: { moonweave_bolt: 6, shadow_ichor: 2, silken_thread: 8 }, outputs: { veilcloak: 1 }, xp: 650, station: 'tailoring_kit' },
  { id: 'tailor_luminary', name: 'Sovereign Luminary Vestment', skillId: 'tailoring', level: 100, inputs: { moonweave_bolt: 14, radiant_shard: 8, sacred_relic: 1, silken_thread: 20 }, outputs: { luminary_bis_robe: 1 }, xp: 3000, station: 'tailoring_kit' },
  { id: 'tailor_nightweave', name: 'Nightweave Lich Mantle', skillId: 'tailoring', level: 100, inputs: { moonweave_bolt: 14, shadow_ichor: 10, crypt_fluid: 4, silken_thread: 20 }, outputs: { nightweave_bis_robe: 1 }, xp: 3000, station: 'tailoring_kit' }
];

DATA.mageTowerFloors = Array.from({ length: 5 }, (_, index) => ({
  id: `mage_tower_floor_${index + 1}`, name: `Starveil Tower Room ${index + 1}`, floorNumber: index + 1, price: 1500 + index * 500,
  butlerId: `tower_butler_${index + 1}`, mailboxId: `tower_mailbox_${index + 1}`, trainingDummyId: `tower_dummy_${index + 1}`, petId: `tower_pet_${index + 1}`,
  runeIntervalSeconds: [30, 30, 30, 80, 180][index], sourceSystem: 'emberwake', description: 'A separately owned tower residence with an endless depot, bed, mailbox, personal butler, training dummy and room-bound pet.'
}));
DATA.runeDispensers = [
  { id: 'tower_dispenser_1', name: 'Great Emberburst Dispenser', floorId: 'mage_tower_floor_1', intervalSeconds: 30, outputs: { great_emberburst_rune: 1 }, maxStack: 999 },
  { id: 'tower_dispenser_2', name: 'Sovereign Mending Dispenser', floorId: 'mage_tower_floor_2', intervalSeconds: 30, outputs: { sovereign_mending_rune: 1 }, maxStack: 999 },
  { id: 'tower_dispenser_3', name: 'Arcane Wall Dispenser', floorId: 'mage_tower_floor_3', intervalSeconds: 30, outputs: { arcane_wall_rune: 1 }, maxStack: 999 },
  { id: 'tower_dispenser_4', name: 'Seven-Sigil Dispenser', floorId: 'mage_tower_floor_4', intervalSeconds: 80, outputs: { heavy_arcane_missile_rune: 1, light_arcane_missile_rune: 1, fireball_rune: 1, ice_bolt_rune: 1, poison_sigil_rune: 1, destroy_field_rune: 1, fire_field_rune: 1 }, maxStack: 999 },
  { id: 'tower_dispenser_5', name: 'Grand Rune Press', floorId: 'mage_tower_floor_5', intervalSeconds: 180, outputs: { sovereign_mending_rune: 10, sudden_death_rune: 10, great_emberburst_rune: 10, avalanche_rune: 10 }, maxStack: 999 }
];
DATA.butlers = [...(DATA.butlers || []), ...DATA.mageTowerFloors.map((floor, index) => ({ id: floor.butlerId, name: ['Oris Quill', 'Mira Star', 'Tallow Venn', 'Sera Glyph', 'Aldren Zenith'][index], floorId: floor.id, inventory: ['bread', 'mana_potion', 'silken_thread'], shopId: `tower_butler_shop_${index + 1}`, cashBalance: 0, sourceSystem: 'emberwake' }))];

const runeItemSpecs = [
  ['great_emberburst_rune', 'Great Emberburst Rune', 'fire', 95], ['sovereign_mending_rune', 'Sovereign Mending Rune', 'heal', 130], ['arcane_wall_rune', 'Arcane Wall Rune', 'wall', 0], ['heavy_arcane_missile_rune', 'Heavy Arcane Missile Rune', 'energy', 115], ['light_arcane_missile_rune', 'Light Arcane Missile Rune', 'energy', 55], ['fireball_rune', 'Fireball Rune', 'fire', 70], ['ice_bolt_rune', 'Ice Bolt Rune', 'ice', 65], ['poison_sigil_rune', 'Poison Sigil Rune', 'poison', 45], ['destroy_field_rune', 'Destroy Field Rune', 'destroy_field', 0], ['fire_field_rune', 'Fire Field Rune', 'fire_field', 40], ['sudden_death_rune', 'Sudden Eclipse Rune', 'death', 150], ['avalanche_rune', 'Avalanche Rune', 'ice', 105]
];
for (const [id, name, runeEffect, power] of runeItemSpecs) if (!itemOf(id)) DATA.items.push({ id, name, type: 'rune', icon: '◆', color: ({ fire: '#e97a4e', heal: '#71d493', wall: '#72aa72', energy: '#70bce8', ice: '#83d0e7', poison: '#85ad5e', death: '#a875d0' })[runeEffect] || '#c9b5d9', runeEffect, power, range: 7, weight: .2, buy: Math.max(18, Math.round(power * .65)), sell: Math.max(4, Math.round(power * .15)), stackable: true, description: `${name} produced by Starveil Tower.` });

DATA.shops.push(
  { id: 'tailor_supply', name: 'Vellum & Thread', buys: ['coarse_cloth', 'spider_silk', 'moonweave_bolt', 'apprentice_robe', 'veilcloak', 'luminary_bis_robe', 'nightweave_bis_robe'], sells: ['tailoring_kit', 'linen_roll', 'silken_thread', 'satchel_bag', 'pocket_pouch'] },
  ...DATA.mageTowerFloors.map((floor, index) => ({ id: `tower_butler_shop_${index + 1}`, name: `${DATA.butlers[index].name}'s Room Stock`, buys: ['coarse_cloth', 'spider_silk', 'radiant_shard'], sells: ['bread', 'mana_potion', 'silken_thread', 'ember_rune', 'mending_rune'] }))
);
DATA.npcs.push(
  { id: 'npc_tailor_maeve', name: 'Maeve Spindle', role: 'Master tailor', icon: '✂', x: 28, y: 43, z: 0, zoneId: 'anchorage_harbor', quests: [], shop: 'tailor_supply', description: 'Sells inexpensive reagents and teaches a complete path from scrap cloth to master vestments.' },
  { id: 'npc_tower_steward', name: 'Steward Novan', role: 'Starveil Tower property steward', icon: '⌂', x: 31, y: 35, z: 0, zoneId: 'northroad', quests: [], shop: null, description: 'Sells five separately owned rooms and manages the tower rune presses.' },
  { id: 'npc_guild_factor', name: 'Factor Brindle', role: 'Dawnroad Guild factor', icon: '⚑', x: 26, y: 56, z: 0, zoneId: 'southroad', quests: [], shop: null, description: 'Sells the guildhall only after all five Starveil Tower rooms have owners.' },
  { id: 'npc_guard_hale', name: 'Guard Hale', role: 'Wandering harbor guard', icon: '♜', x: 13, y: 44, z: 0, zoneId: 'anchorage_harbor', quests: [], shop: null, patrol: [[13,44],[18,44],[18,48],[13,48]], description: 'Patrols the western harbor and assists citizens.' },
  { id: 'npc_guard_nessa', name: 'Guard Nessa', role: 'Wandering tower guard', icon: '♜', x: 30, y: 39, z: 0, zoneId: 'northroad', quests: [], shop: null, patrol: [[30,39],[34,39],[34,33],[30,33]], description: 'Patrols Starveil Tower and watches its sealed archive.' }
);
DATA.buildings.push(
  { id: 'build_tailor_shop', name: 'Vellum & Thread', type: 'shop', x: 26, y: 41, z: 0, width: 5, height: 4, npcIds: ['npc_tailor_maeve'], collision: 'open south door' },
  { id: 'build_starveil_tower', name: 'Starveil Mage Tower', type: 'tower', x: 29, y: 30, z: 0, width: 7, height: 9, npcIds: ['npc_tower_steward', 'npc_guard_nessa'], collision: 'open south vestibule', floors: 5, basementFloors: 1 },
  { id: 'build_dawnroad_guild', name: 'Dawnroad Guildhall', type: 'hall', x: 22, y: 54, z: 0, width: 12, height: 9, npcIds: ['npc_guild_factor'], collision: 'open north gate', arena: { floor: -1, cages: 8, leverPerCage: true } }
);
DATA.placements.push(
  { id: 'place_tailoring_station', type: 'tailoring', entityId: 'tailoring_station', x: 28, y: 42, z: 0, label: 'Maeve Spindle tailoring table' },
  { id: 'place_starveil_door', type: 'mage_tower', entityId: 'starveil_tower', x: 32, y: 39, z: 0, label: 'Starveil Tower rooms and archive' },
  { id: 'place_starveil_fountain', type: 'tower_fountain', entityId: 'starveil_fountain', x: 28, y: 38, z: 0, label: 'Starveil owner fountain', healPerUse: 5 },
  { id: 'place_guild_door', type: 'guildhall', entityId: 'dawnroad_guild', x: 27, y: 54, z: 0, label: 'Dawnroad Guildhall' }
);
for (const floor of DATA.mageTowerFloors) {
  const z = -floor.floorNumber; const dispenser = DATA.runeDispensers.find(row => row.floorId === floor.id); const butler = DATA.butlers.find(row => row.floorId === floor.id);
  DATA.placements.push(
    { id: `place_tower_bed_${floor.floorNumber}`, type: 'rest', entityId: `tower_bed_${floor.floorNumber}`, x: 30, y: 32, z, label: `${floor.name} bed`, requiresHouseId: floor.id },
    { id: `place_tower_depot_${floor.floorNumber}`, type: 'depot', entityId: `tower_depot_${floor.floorNumber}`, x: 34, y: 32, z, label: `${floor.name} endless depot`, requiresHouseId: floor.id },
    { id: `place_tower_mail_${floor.floorNumber}`, type: 'mailbox', entityId: floor.mailboxId, x: 30, y: 35, z, label: `${floor.name} mailbox`, requiresHouseId: floor.id },
    { id: `place_tower_dummy_${floor.floorNumber}`, type: 'training', entityId: floor.trainingDummyId, x: 34, y: 35, z, label: `${floor.name} training dummy`, requiresHouseId: floor.id },
    { id: `place_tower_pet_${floor.floorNumber}`, type: 'room_pet', entityId: floor.petId, x: 32, y: 34, z, label: `${floor.name} room pet`, requiresHouseId: floor.id },
    { id: `place_tower_press_${floor.floorNumber}`, type: 'rune_dispenser', entityId: dispenser.id, x: 32, y: 31, z, label: dispenser.name, requiresHouseId: floor.id }
  );
  if (floor.floorNumber === 1) {
    DATA.placements.push({ id: 'place_tower_exit', type: 'door', entityId: 'starveil_exit', x: 32, y: 38, z, targetX: 32, targetY: 39, targetZ: 0, label: 'Exit Starveil Tower' });
    DATA.placements.push({ id: 'place_tower_archive_down', type: 'stairs_down', entityId: 'tower_archive_down', x: 30, y: 37, z, targetX: 30, targetY: 37, targetZ: -6, label: 'Stairs to the guarded archive' });
  }
  if (floor.floorNumber < 5) DATA.placements.push({ id: `place_tower_down_${floor.floorNumber}`, type: 'stairs_down', entityId: `tower_down_${floor.floorNumber}`, x: 34, y: 37, z, targetX: 34, targetY: 37, targetZ: z - 1, label: `Stairs to tower room ${floor.floorNumber + 1}` });
  if (floor.floorNumber > 1) DATA.placements.push({ id: `place_tower_up_${floor.floorNumber}`, type: 'stairs_up', entityId: `tower_up_${floor.floorNumber}`, x: 33, y: 37, z, targetX: 33, targetY: 37, targetZ: z + 1, label: `Stairs to tower room ${floor.floorNumber - 1}` });
  DATA.npcs.push({ id: butler.id, name: butler.name, role: `${floor.name} butler`, icon: '♙', x: 31, y: 33, z, zoneId: 'northroad', quests: [], shop: butler.shopId, inventory: butler.inventory, description: `Personal butler for ${floor.name}, with separate stock and inventory.` });
}
DATA.placements.push(
  { id: 'place_tower_archive_up', type: 'stairs_up', entityId: 'tower_archive_up', x: 30, y: 37, z: -6, targetX: 30, targetY: 37, targetZ: -1, label: 'Stairs to tower room 1' },
  { id: 'place_tower_archive_chest', type: 'tower_archive', entityId: 'tower_archive_chest', x: 32, y: 32, z: -6, label: 'Owner rune and scroll archive' },
  { id: 'place_tower_lockbox_1', type: 'tower_lockbox', entityId: 'tower_lockbox_1', x: 34, y: 33, z: -6, label: 'Guarded practice lockbox' },
  { id: 'place_tower_lockbox_2', type: 'tower_lockbox', entityId: 'tower_lockbox_2', x: 30, y: 34, z: -6, label: 'Guarded practice strongbox' },
  { id: 'place_tower_archive_dummy', type: 'training', entityId: 'tower_archive_dummy', x: 34, y: 35, z: -6, label: 'Archive spell-training dummy' },
  { id: 'place_tower_archive_portal', type: 'tower_portal', entityId: 'tower_archive_portal', x: 32, y: 36, z: -6, label: 'Town-return portal' }
);
DATA.npcs.push(
  { id: 'npc_archive_guard_1', name: 'Warden Pell', role: 'Starveil archive guard', icon: '♜', x: 29, y: 31, z: -6, zoneId: 'northroad', quests: [], shop: null, patrol: [[29,31],[35,31],[35,36],[29,36]], description: 'Patrols the archive and ejects detected thieves.' },
  { id: 'npc_archive_guard_2', name: 'Warden Isa', role: 'Starveil archive guard', icon: '♜', x: 35, y: 34, z: -6, zoneId: 'northroad', quests: [], shop: null, patrol: [[35,34],[30,34],[30,32],[35,32]], description: 'Watches the rune shelves and practice lockboxes.' }
);
DATA.houses.push(
  ...DATA.mageTowerFloors.map((floor, index) => ({ id: floor.id, name: floor.name, x: 30, y: 31, z: 0, width: 5, height: 7, town: 'Anchorage Harbor', price: floor.price, rent: 0, towerFloor: index + 1, ownerCharacterId: null, description: floor.description })),
  { id: 'house_dawnroad_guild', name: 'Dawnroad Guildhall', x: 22, y: 54, z: 0, width: 12, height: 9, town: 'South Road', price: 50000, rent: 0, requiresAllProperties: DATA.mageTowerFloors.map(floor => floor.id), ownerCharacterId: null, description: 'A large guild compound with rooms, shops and a lever-operated basement arena.' }
);

for (const table of DATA.dropTables.filter(table => ['mob_goblin_slinger', 'mob_ash_raider', 'mob_javelin_raider', 'mob_crypt_scrapper', 'mob_venom_spider', 'boss_brood_tyrant'].includes(table.monsterId))) {
  if (!table.entries.some(entry => entry.itemId === 'coarse_cloth')) table.entries.push({ itemId: table.monsterId.includes('spider') || table.monsterId.includes('brood') ? 'spider_silk' : 'coarse_cloth', tier: 'common', weight: 32, min: 1, max: 3 });
}
for (const character of DATA.characters) {
  if (!character.skills.tailoring) character.skills.tailoring = { level: Math.max(1, Math.round(character.level * .28)), xp: 0, next: Math.max(100, character.level * 105) };
  character.itemInstances = character.itemInstances || {};
  character.containerContents = character.containerContents || {};
}
Object.assign(DATA.characters[0], { level: 5, gold: 125, xpNext: 300, scenario: 'First Landing · Level Five', scenarioText: 'A level-five beginning with 125 gold on the safe tutorial island. Learn movement, light, tailoring, trading and the first harbor quests before entering the dangerous frontier.' });
if (!DATA.characters[0].inventory.some(stack => stack.id === 'tailoring_kit')) DATA.characters[0].inventory.push({ id: 'tailoring_kit', qty: 1 });
if (!DATA.characters[0].inventory.some(stack => stack.id === 'satchel_bag')) DATA.characters[0].inventory.push({ id: 'satchel_bag', qty: 1, instanceId: 'starter_satchel' });
DATA.characters[0].containerContents.starter_satchel = DATA.characters[0].containerContents.starter_satchel || [{ id: 'coarse_cloth', qty: 4 }, { id: 'silken_thread', qty: 4 }, { id: 'pocket_pouch', qty: 1, instanceId: 'starter_pouch' }];
DATA.characters[0].containerContents.starter_pouch = DATA.characters[0].containerContents.starter_pouch || [{ id: 'linen_roll', qty: 2 }];

for (const item of DATA.items.filter(item => item.type === 'food')) if (!Number.isFinite(item.nutrition)) item.nutrition = clamp(Math.round(Number(item.heal || 30) * .65), 8, 45);
for (const character of DATA.characters) character.survival = character.survival || { hunger: 100, thirst: 100, rest: 100, lastUpdatedAt: Date.now(), lastHungerDamageAt: 0, lastThirstDamageAt: 0 };

// Deep cross-application authoring registries.  These are first-class editable
// definitions instead of opaque notes, so every source contract can be changed,
// exported and persisted by the same five-file engine.
const primitiveSkillRows = `attack|Attack|combat
strength|Strength|combat
defence|Defence|combat
ranged|Ranged|combat
magic|Spellcasting|magic
overall_magic|Overall Magic|derived
runecrafting|Rune Crafting|magic
rune_shooting|Rune Shooting|magic
prayer|Prayer|combat
hitpoints|Hitpoints|combat
woodcutting|Woodcutting|gathering
firemaking|Firemaking|artisan
fishing|Fishing|gathering
cooking|Cooking|artisan
mining|Mining|gathering
smithing|Smithing|artisan
farming|Farming|gathering
thieving|Thieving|utility
crafting|Crafting|artisan
fletching|Fletching|artisan
slayer|Slayer|combat
athletics|Athletics|physical
laboring|Laboring|physical
toughness|Toughness|physical
stealth|Stealth|utility
swordsmanship|Swordsmanship|weapon
axe_fighting|Axe Fighting|weapon
staff_fighting|Staff Fighting|weapon
shielding|Shielding|weapon
lockpicking|Lockpicking|utility
medicine|Medicine|utility
dodge|Dodge|physical`;
DATA.primitiveSkills = primitiveSkillRows.split('\n').map(line => {
  const [id, name, family] = line.split('|');
  return { id, name, family, startLevel: id === 'hitpoints' ? 10 : 1, startXp: 0, maxLevel: 99, xpFormulaId: 'runelite_xp_curve', derived: id === 'overall_magic', sourceSystem: 'runelite_primitive_realm' };
});

const primitiveItemRows = `coins|Coins|currency
spellbook|Personal Spellbook|spellbook
bronze_arrow|Bronze Arrow|ammo
iron_arrow|Iron Arrow|ammo
steel_arrow|Steel Arrow|ammo
air_rune|Air Rune|rune
body_rune|Body Rune|rune
chaos_rune|Chaos Rune|rune
death_rune|Death Rune|rune
earth_rune|Earth Rune|rune
fire_rune|Fire Rune|rune
law_rune|Law Rune|rune
mind_rune|Mind Rune|rune
nature_rune|Nature Rune|rune
water_rune|Water Rune|rune
bucket|Bucket|tool
chisel|Chisel|tool
fishing_rod|Fishing Rod|tool
hammer|Hammer|tool
knife|Knife|tool
needle|Needle|tool
rope|Rope|tool
shears|Shears|tool
small_fishing_net|Small Fishing Net|tool
tinderbox|Tinderbox|tool
basic_staff|Staff of Air|weapon
fire_staff|Staff of Fire|weapon
bronze_axe|Bronze Axe|weapon
bronze_battleaxe|Bronze Battleaxe|weapon
bronze_dagger|Bronze Dagger|weapon
bronze_hatchet|Bronze Hatchet|tool
bronze_longsword|Bronze Longsword|weapon
bronze_pickaxe|Bronze Pickaxe|tool
bronze_sword|Bronze Sword|weapon
iron_battleaxe|Iron Battleaxe|weapon
iron_dagger|Iron Dagger|weapon
iron_hatchet|Iron Hatchet|tool
iron_longsword|Iron Longsword|weapon
iron_pickaxe|Iron Pickaxe|tool
iron_sword|Iron Sword|weapon
steel_battleaxe|Steel Battleaxe|weapon
steel_dagger|Steel Dagger|weapon
steel_hatchet|Steel Hatchet|tool
steel_longsword|Steel Longsword|weapon
steel_pickaxe|Steel Pickaxe|tool
steel_sword|Steel Sword|weapon
mithril_battleaxe|Mithril Battleaxe|weapon
mithril_dagger|Mithril Dagger|weapon
mithril_hatchet|Mithril Hatchet|tool
mithril_longsword|Mithril Longsword|weapon
mithril_pickaxe|Mithril Pickaxe|tool
mithril_sword|Mithril Sword|weapon
normal_shortbow|Normal Shortbow|weapon
normal_longbow|Normal Longbow|weapon
oak_shortbow|Oak Shortbow|weapon
oak_longbow|Oak Longbow|weapon
willow_shortbow|Willow Shortbow|weapon
willow_longbow|Willow Longbow|weapon
maple_shortbow|Maple Shortbow|weapon
maple_longbow|Maple Longbow|weapon
yew_shortbow|Yew Shortbow|weapon
yew_longbow|Yew Longbow|weapon
sewer_king_blade|Sewer King Blade|weapon
dragonfire_blade|Dragonfire Blade|weapon
bronze_helm|Bronze Helm|armor
bronze_body|Bronze Platebody|armor
bronze_legs|Bronze Platelegs|armor
bronze_platebody|Bronze Platebody (Legacy Alias)|armor
bronze_platelegs|Bronze Platelegs (Legacy Alias)|armor
bronze_boots|Bronze Boots|armor
bronze_gloves|Bronze Gloves|armor
bronze_shield|Bronze Kiteshield|armor
iron_helm|Iron Helm|armor
iron_body|Iron Platebody|armor
iron_legs|Iron Platelegs|armor
iron_boots|Iron Boots|armor
iron_gloves|Iron Gloves|armor
iron_shield|Iron Kiteshield|armor
steel_helm|Steel Helm|armor
steel_body|Steel Platebody|armor
steel_legs|Steel Platelegs|armor
steel_boots|Steel Boots|armor
steel_gloves|Steel Gloves|armor
steel_shield|Steel Kiteshield|armor
mithril_helm|Mithril Helm|armor
mithril_body|Mithril Platebody|armor
mithril_legs|Mithril Platelegs|armor
mithril_boots|Mithril Boots|armor
mithril_gloves|Mithril Gloves|armor
mithril_shield|Mithril Kiteshield|armor
leather_cowl|Leather Cowl|armor
leather_body|Leather Body|armor
leather_chaps|Leather Chaps|armor
leather_boots|Leather Boots|armor
leather_gloves|Leather Gloves|armor
leather_vambraces|Leather Vambraces|armor
studded_body|Studded Leather Body|armor
studded_chaps|Studded Leather Chaps|armor
plagueguard_body|Plagueguard Chestpiece|armor
apple|Garden Apple|food
berry_tea|Sunberry Tea|food
bread|Bread|food
cabbage|Cabbage|food
carrot|Garden Carrot|food
cooked_beef|Cooked Meat|food
cooked_rat_meat|Cooked Rat Meat|food
cooked_shrimp|Cooked Shrimp|food
cooked_trout|Cooked Trout|food
garden_berries|Sunberries|food
hearty_stew|Butler's Hearty Stew|food
raw_beef|Raw Beef|food
raw_rat_meat|Raw Rat Meat|food
raw_shrimp|Raw Shrimp|food
raw_trout|Raw Trout|food
spring_water|Spring Water|food
barley_seed|Barley Seed|seed
cabbage_seed|Cabbage Seed|seed
sewer_key|Sewer Key|quest
warehouse_key|Warehouse Key|quest
dragon_pet|Baby Dragon Pet|pet
king_rat_pet|King Rat Pet|pet
arcane_lens|Arcane Lens|resource
arrow_shafts|Arrow Shafts|resource
ball_of_wool|Ball of Wool|resource
barley|Barley|resource
bear_fur|Bear Fur|resource
big_bones|Big Bones|resource
bones|Bones|resource
bowstring|Bow String|resource
bronze_arrowtips|Bronze Arrowtips|resource
bronze_bar|Bronze Bar|resource
cave_fang|Cave Fang|resource
coal_ore|Coal Ore|resource
copper_ore|Copper Ore|resource
cow_horn_trophy|Polished Cow Horn Trophy|resource
cowhide|Cowhide|resource
dark_essence|Dark Essence|resource
dragon_bones|Dragon Bones|resource
dragon_spar_scale|Sparring Dragon Scale|resource
feather|Feather|resource
flax|Flax|resource
flour|Pot of Flour|resource
garden_herbs|Fresh Garden Herbs|resource
gold_bar|Gold Bar|resource
gold_ore|Gold Ore|resource
golem_core|Golem Core|resource
green_dragonhide|Green Dragonhide|resource
hard_leather|Hard Leather|resource
headless_arrows|Headless Arrows|resource
iron_arrowtips|Iron Arrowtips|resource
iron_bar|Iron Bar|resource
iron_ore|Iron Ore|resource
leather|Leather|resource
maple_logs|Maple Logs|resource
maple_unstrung_bow|Maple Unstrung Bow|resource
milk|Bucket of Milk|resource
mithril_bar|Mithril Bar|resource
mithril_ore|Mithril Ore|resource
normal_logs|Normal Logs|resource
normal_unstrung_bow|Normal Unstrung Bow|resource
oak_logs|Oak Logs|resource
oak_plank|Oak Plank|resource
oak_unstrung_bow|Oak Unstrung Bow|resource
pet_bedding|Soft Pet Bedding|resource
rat_tail|Rat Tail|resource
rune_essence|Rune Essence|resource
silk|Silk|resource
silver_bar|Silver Bar|resource
silver_ore|Silver Ore|resource
slime_core|Slime Core|resource
steel_arrowtips|Steel Arrowtips|resource
steel_bar|Steel Bar|resource
steel_nails|Steel Nails|resource
thread|Thread|resource
tin_ore|Tin Ore|resource
wheat|Wheat|resource
willow_logs|Willow Logs|resource
willow_unstrung_bow|Willow Unstrung Bow|resource
wolf_pelt|Wolf Pelt|resource
wool|Wool|resource
yew_logs|Yew Logs|resource
yew_unstrung_bow|Yew Unstrung Bow|resource
burnt_food|Burnt Food|trash`;
DATA.primitiveItems = primitiveItemRows.split('\n').map(line => {
  const [id, name, type] = line.split('|');
  const aliases = { bronze_axe: 'bronze_hatchet', bronze_platebody: 'bronze_body', bronze_platelegs: 'bronze_legs' };
  return { id, name, type, value: 0, weight: 0, stackable: ['currency', 'ammo', 'rune', 'resource', 'food', 'seed'].includes(type), action: type === 'food' ? 'Eat' : '', bound: id === 'spellbook', rare: ['sewer_king_blade', 'dragonfire_blade', 'dragon_pet', 'king_rat_pet'].includes(id), slot: '', tier: 0, color: '', combatStyle: '', toolType: '', stats: {}, legacyAliasFor: aliases[id] || '', sourceSystem: 'runelite_primitive_realm' };
});

DATA.primitiveRecipeGroups = [
  ['smithing', 58, 'anvil/furnace', 'ore -> bars -> tools, weapons, armor, shields, arrowtips and nails'],
  ['fletching', 20, 'fletching_bench', 'logs -> bows; shafts + feathers + arrowtips -> arrows'],
  ['crafting', 15, 'crafting_table/tannery/spinning_wheel/sawmill', 'hides, leather, cloth, wool, planks and room materials'],
  ['cooking', 6, 'range/mill', 'raw food and grain into edible food'],
  ['firemaking', 5, 'any', 'log tiers into fires'],
  ['runecrafting', 5, 'runecrafting_altar', 'rune essence into elemental and mind runes']
].map(([id, sourceCount, stations, productionChain]) => ({ id, name: `${id[0].toUpperCase()}${id.slice(1)} Recipes`, sourceCount, stations, productionChain, fields: ['id', 'name', 'icon', 'skill', 'level', 'station', 'inputs', 'outputs', 'xp', 'successChance'], sourceSystem: 'runelite_primitive_realm' }));

DATA.statCategories = [
  { id: 'core', name: 'Core Attributes', color: '#00edff', stats: ['guts', 'wits', 'charm'], sourceSystem: 'stat_system_designer' },
  { id: 'vitals', name: 'Vitals', color: '#ff1970', stats: ['health', 'composure'], sourceSystem: 'stat_system_designer' }
];
DATA.statDefinitions = [
  ['guts', 'Guts', 'core', 4, 0, 20, 1, false, 'Courage, nerve, and physical resolve.'], ['wits', 'Wits', 'core', 4, 0, 20, 1, false, 'Reasoning, perception, and clever solutions.'], ['charm', 'Charm', 'core', 4, 0, 20, 1, false, 'Influence, presentation, and social control.'],
  ['health', 'Health', 'vitals', 100, 0, 100, 5, false, 'Current survivability.'], ['composure', 'Composure', 'vitals', 70, 0, 100, 5, true, 'Resistance to panic and pressure.']
].map(([id, name, categoryId, base, min, max, step, percentage, description]) => ({ id, name, categoryId, base, min, max, step, percentage, description, sourceSystem: 'stat_system_designer' }));
DATA.currencyDefinitions = [
  ['cash', 'Cash', '$', 19, 999999, '#23e889'], ['build_points', 'Build Points', 'BP', 20, 9999, '#ffc13d'], ['favor', 'Favor', 'FV', 3, 9999, '#a778ff']
].map(([id, name, symbol, start, max, color]) => ({ id, name, symbol, start, max, color, imageUrl: '', sourceSystem: 'stat_system_designer' }));
DATA.statDesignerSkills = [
  ['fists_skin', 'Fists & Skin', 'Combat', 1, 0, 75, 1.35, '#ff1970'], ['engineering', 'Engineering', 'Fieldcraft', 1, 18, 80, 1.4, '#ff9000'], ['streetwise', 'Streetwise', 'Social', 1, 30, 90, 1.3, '#00edff']
].map(([id, name, category, startLevel, startXp, xpToNext, growth, color]) => ({ id, name, category, startLevel, startXp, xpToNext, growth, color, imageUrl: '', sourceSystem: 'stat_system_designer' }));
DATA.encounters = [
  { id: 'old-windmill', name: 'Fields Quest', subtitle: 'A tired stranger and a broken windmill', description: 'Help repair the windmill, attack, or leave.', choices: [{ id: 'repair', effects: [{ kind: 'skillXp', targetId: 'engineering', amount: 35 }, { kind: 'playerXp', targetId: '', amount: 20 }, { kind: 'currency', targetId: 'favor', amount: 2 }] }, { id: 'attack', effects: [{ kind: 'stat', targetId: 'guts', amount: 1 }, { kind: 'skillXp', targetId: 'fists_skin', amount: 20 }] }, { id: 'leave', effects: [] }], sourceSystem: 'stat_system_designer' },
  { id: 'gerbil-ambush', name: 'Gerbil Ambush', subtitle: 'Yellow Teeth - Mangy Fur', description: 'Fight or retreat.', choices: [{ id: 'fight', effects: [{ kind: 'stat', targetId: 'health', amount: -10 }, { kind: 'skillXp', targetId: 'fists_skin', amount: 30 }, { kind: 'playerXp', targetId: '', amount: 15 }] }, { id: 'run', effects: [{ kind: 'stat', targetId: 'wits', amount: 1 }] }], sourceSystem: 'stat_system_designer' }
];
DATA.mapDefinitions = [{ id: 'fields_near_salamander', name: 'The Fields near Salamander Township', coordinateSpace: 'normalized-percent', canvasWidth: 100, canvasHeight: 100, backgroundUrl: '', sourceSystem: 'stat_system_designer' }];
DATA.mapNodes = [
  ['towne-road', 'Towne Road', 18, 25, '', 1], ['goblin-mound', '(1) Goblin Mound', 48, 19, 'gerbil-ambush', 1], ['healers-tower', "Healer's Tower", 79, 28, '', 1], ['quest', '(1) Quest!', 45, 57, 'old-windmill', 1], ['forest-road', 'Forest Road', 20, 72, 'gerbil-ambush', 1]
].map(([id, name, x, y, encounterId, requiredLevel]) => ({ id, name, mapId: 'fields_near_salamander', x, y, encounterId, requiredLevel, imageUrl: '', color: '#00edff', sourceSystem: 'stat_system_designer' }));

DATA.dialogueGlobals = [
  ['languages', 'Languages', 'array', []], ['currentLanguage', 'Current Language', 'string', 'English'], ['cast', 'Cast', 'array', []], ['tokens', 'Typed Tokens', 'object', {}], ['states', 'World States', 'array', []], ['moods', 'Moods', 'array', []], ['settings', 'Settings', 'array', []], ['times', 'Times', 'array', []], ['days', 'Days', 'array', []], ['menuOptions', 'Menu Options', 'array', []], ['imageSequences', 'Image Sequences', 'array', []]
].map(([id, name, valueType, defaultValue]) => ({ id, name, valueType, defaultValue, sourceSystem: 'gameplay_designer' }));
DATA.conditionOperators = ['equals', 'notEquals', 'greaterThan', 'greaterThanOrEqual', 'lessThan', 'lessThanOrEqual', 'exists', 'missing', 'contains'].map(id => ({ id, name: id, operands: ['exists', 'missing'].includes(id) ? 1 : 2, sourceSystem: 'shared' }));
DATA.mutationTypes = [
  ['add', 'Add a delta'], ['set', 'Replace a value'], ['clamp', 'Constrain a value'], ['consume', 'Remove inventory quantity'], ['equip', 'Assign equipment'], ['unequip', 'Clear equipment'], ['visit', 'Mark a location visited'], ['complete', 'Mark an objective complete'], ['enable', 'Enable a flag or object'], ['disable', 'Disable a flag or object'], ['spawn', 'Create a runtime instance'], ['despawn', 'Remove a runtime instance'], ['runSequence', 'Start an authored sequence'], ['teleport', 'Move to a stable map or area target'], ['awardXp', 'Award XP through the target skill curve']
].map(([id, description]) => ({ id, name: id, description, targetPath: '', amountType: 'typed', validation: 'schema-and-authority', sourceSystem: 'shared' }));

const gameplayItemRows = `130268866|Two Coins|2 Coins|valuable|1|1|0|0|1|1|0|0|1684715558|
873239592|Penny and Button|Penny And Button|valuable|1|1|0|0|1|1|0|0|19121221|
1796015664|Four Pennies|4 Coins|miscellaneous|1|1|0|0|0|1|0|0|1604261105|
1654055676|Candy|Candy1|consumable|1|1|0|0|0|1|1|0|1297786336|
702838269|Twist Ties|Twistties|miscellaneous|1|1|0|0|0|1|0|0|577304711|
365814633|Screws|Screws|tool|1|1|0|0|1|1|1|0|875383294|
934192006|Candies|Candy2|miscellaneous|1|1|0|0|0|1|0|0|2095961925|
1523451421|AA Battery|Single Battery1|miscellaneous|1|1|0|0|0|1|0|0|142402622|
2147055100|AA Battery|Single Battery2|miscellaneous|1|1|0|0|0|1|0|0|200520712|
488519556|Hair Tie|Hair Tie|wearable|1|1|0|0|0|1|0|1|1124167983|
591747812|Domino|Domino|miscellaneous|1|1|0|0|0|1|0|0|907567027|
360186533|Eraser|Eraser|miscellaneous|1|1|0|0|0|1|0|0|77653381|
838040892|Chap Stick|Chap Stick|consumable|1|1|0|0|0|1|1|0|1938257840|
447043300|Pencil Sharpener|Pencil Sharpener|miscellaneous|1|1|0|0|0|1|0|0|831032459|
864136324|Button|Single Button|miscellaneous|1|1|0|0|0|1|0|0|1661607954|
591575343|Alen Wrench|Allen Wrench|miscellaneous|1|1|0|0|0|1|0|0|1936757785|
1088280825|Blue Pen|Storage Key|miscellaneous|1|1|0|0|0|1|0|0|2010423448|
1639667180|Storage Unit Key|Red Pen|tool|1|1|0|0|1|1|1|0|1328281653|unlock
1394708722|Red Pen|Paper Clip|miscellaneous|1|1|0|0|0|1|0|0|731622048|
2089799679|Paper Clip|Assorted Coins|miscellaneous|1|1|0|0|0|1|0|0|502128744|
167991825|Assorted Coins|Army Toy|valuable|1|1|0|0|1|1|0|0|930215630|
899586229|Toy Soldier|Audio Cables|miscellaneous|1|1|0|0|0|1|0|0|487537525|
116590424|Audio Cables|House Keys|miscellaneous|1|1|0|0|0|1|0|0|1837857132|
2118607321|Apartment Keys|Paper Clip Heavy Duty|tool|1|1|0|0|1|1|1|0|545343230|unlock
1490383240|Thick Paper Clip|U S B Drive|miscellaneous|1|1|0|0|0|1|0|0|168040960|
665921230|USB Drive|Paper Clips|story|1|1|0|0|0|1|0|0|300688147|
786529888|Paper Clips|Sewing Kit|miscellaneous|1|1|0|0|0|1|0|0|1226870014|
1852456480|Sewing Kit|Super Glue|miscellaneous|1|1|0|0|0|1|0|0|1715045084|
1475127958|Super Glue|Rubber Bands|tool|1|1|0|0|1|1|1|0|414218342|
197290569|Rubber Bands|Washer|miscellaneous|1|1|0|0|0|1|0|0|1204022011|
1602562300|Washer|Watch Batteries|miscellaneous|1|1|0|0|0|1|0|0|718322897|
417832483|Watch Batteries|Sailing Patch|valuable|1|1|0|0|1|1|0|0|1845632674|
2038827363|Sailing Patch|Old Receipt|miscellaneous|1|1|0|0|0|1|0|0|240791251|
568431942|Old Recipt|Push Pin|miscellaneous|1|1|0|0|0|1|0|0|1800459725|
822668864|Push Pin|Black Sharpie|tool|1|1|0|0|1|1|1|0|861858058|
554636317|Black Sharpie|Pocket Watch|miscellaneous|1|1|0|0|0|1|0|0|1823572259|
1044369051|Pocket Watch|Tiny Screw Driver|valuable|1|1|0|0|1|1|0|0|1180987757|
1665329162|Tiny Screwdriver|Red Blue Buttons|tool|1|1|0|0|1|1|1|0|1529900224|
819064433|Buttons|Bobby Pin|miscellaneous|1|1|0|0|0|1|0|0|60523882|
1168337236|Bobby Pin|Old Letters|tool|1|1|0|0|1|1|1|0|327630613|transform
970019314|Old Letters|Head Phones|story|1|1|0|0|0|1|0|0|909471620|
1250056126|Headphones|Pad Lock|miscellaneous|1|1|0|0|0|1|0|0|1952813779|
801718425|Padlock|Vial|miscellaneous|1|1|0|0|0|1|0|0|1609170091|
1300443663|Vial|Thimble|consumable|1|1|0|0|0|1|1|0|2057036166|
973826586|Thimble|Screwdriver|miscellaneous|1|1|0|0|0|1|0|0|1059041722|
810607498|Screwdriver|Hammer|tool|1|1|0|0|1|1|1|0|74840647|
256103575|Hammer|Sunglasses|tool|1|1|0|0|1|1|1|0|1908051371|
2129651429|Sunglasses|Gold Watch|wearable|1|1|0|0|0|1|0|1|2142723785|
1658380017|Gold Watch|Blue Pen|valuable|1|1|0|0|1|1|0|0|97054890|
152342181|Bent Bobbypin|Bent Bobbypin|tool|1|1|0|0|1|1|1|0|1355080593|unlock`;
DATA.gameplayInventory = gameplayItemRows.split('\n').map(line => {
  const [fileId, displayName, internalName, category, quantity, maximumStackSize, inInventory, consumed, canPawn, canDrop, canConsume, canEquip, inventoryFileId, action] = line.split('|');
  const globalObjectId = `GlobalObjectId_V1-2-7d8ccfe86450c084db2c2f6d3c13d0d1-${fileId}-0`;
  return { id: `gd_item_${fileId}`, name: displayName, itemId: globalObjectId, displayName, internalName, category, quantity: Number(quantity), maximumStackSize: Number(maximumStackSize), inInventory: inInventory === '1', consumed: consumed === '1', canPawn: canPawn === '1', canDrop: canDrop === '1', canConsume: canConsume === '1', canEquip: canEquip === '1', worldBinding: { fileId, name: `${internalName} (Uninventoried)`, globalObjectId }, inventoryBinding: { fileId: inventoryFileId, name: `${internalName} (Inventory)`, globalObjectId: `GlobalObjectId_V1-2-7d8ccfe86450c084db2c2f6d3c13d0d1-${inventoryFileId}-0` }, sequenceId: 'GlobalObjectId_V1-2-7d8ccfe86450c084db2c2f6d3c13d0d1-2060995682-0', sequenceName: '_RookiesApartment', actions: action ? [{ type: action, target: '' }] : [], sourceSystem: 'gameplay_designer' };
});
DATA.inventorySlotSets = [{ id: 'rookies_apartment_slots', name: 'Rookies Apartment Inventory', componentId: 'GlobalObjectId_V1-2-7d8ccfe86450c084db2c2f6d3c13d0d1-2060995691-0', sequenceName: '_RookiesApartment', capacity: 8, slots: Array.from({ length: 8 }, (_, index) => ({ slotId: `GlobalObjectId_V1-2-7d8ccfe86450c084db2c2f6d3c13d0d1-2060995691-0:slot:${index}`, displayName: `Slot ${index + 1}`, occupied: false })), sourceSystem: 'gameplay_designer' }];
DATA.unityComponentTypes = ['InventoryDragAndDrop', 'TooltipsOnButtons', 'ClickAndDragButtons', 'DragGameObjectByButton', 'InspectItemInInventory', 'ApartmentControl', 'ToggleObjectConditionAndChangeGameState', 'ToggleBasedOnTwoButtons', 'EnableDisableOnCondition', 'ButtonLogsCondition', 'ActivateObjectOnCondition', 'MapSwitcher', 'AspectRatioMaintainer', 'MapBuildingInspection', 'BusRoutesMenu', 'CanvasGroup', 'DisableOnCondition'].map(id => ({ id, name: id.replace(/([a-z])([A-Z])/g, '$1 $2'), fileId: '', globalObjectId: '', scene: '', hierarchyPath: '', unknownFields: 'preserve', sourceSystem: 'gameplay_designer' }));
DATA.sequenceDefinitions = [{ id: 'rookies_apartment', name: '_RookiesApartment', scene: '', hierarchyPath: '', entryNodeId: '', componentIds: DATA.unityComponentTypes.slice(0, 10).map(row => row.id), sourceSystem: 'gameplay_designer' }, { id: 'map_manager', name: 'MapManager', scene: '', hierarchyPath: '', entryNodeId: '', componentIds: DATA.unityComponentTypes.slice(10).map(row => row.id), sourceSystem: 'gameplay_designer' }];
DATA.sequenceNodes = [];
DATA.sequenceEdges = [];

const rtsUnitRows = [
  ['footman', 'Footman', 115, 16, 8, 2.1, 28, 1.05, 'melee', 'chase', 'Infantry'], ['archer', 'Archer', 72, 13, 3, 2.45, 215, 1.25, 'ranged', 'keep-away', 'Ranged'], ['shieldbearer', 'Shieldbearer', 178, 10, 16, 1.55, 26, 1.15, 'melee', 'ground', 'Heavy'], ['knight', 'Knight', 188, 25, 10, 3.8, 30, .9, 'melee', 'chase', 'Cavalry'], ['musketeer', 'Musketeer', 78, 31, 2, 1.85, 285, 1.85, 'ranged', 'ground', 'Ranged'], ['assassin', 'Assassin', 66, 33, 3, 3.65, 26, .72, 'melee', 'chase', 'Infantry'], ['berserker', 'Berserker', 128, 28, 4, 2.65, 28, .72, 'melee', 'chase', 'Infantry'], ['crossbowman', 'Crossbowman', 92, 25, 5, 1.7, 245, 1.65, 'ranged', 'ground', 'Ranged'], ['war_elephant', 'War Elephant', 430, 39, 12, 1.35, 42, 1.55, 'melee', 'chase', 'Heavy'], ['priest', 'Priest', 76, 9, 4, 2.15, 175, 1.35, 'support', 'keep-away', 'Support'], ['stone_golem', 'Stone Golem', 520, 32, 19, 1, 34, 1.7, 'melee', 'ground', 'Heavy'], ['dragoon', 'Dragoon', 168, 23, 8, 3.35, 145, 1.15, 'ranged', 'chase', 'Cavalry'], ['ballista', 'Ballista', 265, 50, 7, .72, 370, 2.7, 'ranged', 'ground', 'Siege'], ['pyromancer', 'Pyromancer', 155, 22, 6, 2.2, 235, 1.5, 'ranged', 'chase', 'Mage'], ['cryomancer', 'Cryomancer', 160, 18, 7, 2.15, 225, 1.45, 'ranged', 'chase', 'Mage'], ['geomancer', 'Geomancer', 180, 16, 10, 1.9, 210, 1.8, 'ranged', 'ground', 'Mage'], ['venomancer', 'Venomancer', 148, 20, 5, 2.3, 230, 1.4, 'ranged', 'keep-away', 'Mage'], ['mudmancer', 'Mudmancer', 172, 14, 9, 1.95, 205, 1.6, 'support', 'ground', 'Mage']
];
const mageEffects = { pyromancer: { type: 'burn', radius: 48, duration: 4, damagePerSecond: 3 }, cryomancer: { type: 'freeze', radius: 60, duration: 3, movementMultiplier: .36 }, geomancer: { type: 'wall', radius: 90, duration: 8 }, venomancer: { type: 'poison', radius: 55, duration: 5, damagePerSecond: 2 }, mudmancer: { type: 'slow', radius: 65, duration: 2.4, movementMultiplier: .5 } };
DATA.rtsUnitTypes = rtsUnitRows.map(([id, name, health, attack, defense, speed, range, rate, focus, stance, role]) => ({ id, name, emoji: '', description: `${role} unit`, health, attack, defense, speed, range, rate, focus, stance, role, projectile: { enabled: ['ranged', 'support'].includes(focus), emoji: '', color: '#d7c08a', speed: 15 }, tiers: [{ id: 'tier_1', name: 'Tier 1', health: 1, attack: 1, speed: 1 }], activeTierId: 'tier_1', onHitEffect: mageEffects[id] || null, sourceSystem: 'field_sigil_rts' }));
DATA.rtsFormations = [
  ['vanguard_wall', 'Vanguard Wall', 5, 7, { shieldbearer: 7, footman: 7, archer: 4, priest: 1 }], ['iron_arrowhead', 'Iron Arrowhead', 7, 7, { knight: 3, footman: 4, berserker: 3, archer: 2, priest: 1 }], ['twin_flanks', 'Twin Flanks', 6, 9, { knight: 4, dragoon: 2, assassin: 2, footman: 2, archer: 2, priest: 1, crossbowman: 2, ballista: 1 }], ['circle_guard', 'Circle Guard', 7, 7, { shieldbearer: 9, footman: 6, geomancer: 1, priest: 1 }], ['ember_screen', 'Ember Screen', 6, 8, { footman: 4, shieldbearer: 4, archer: 4, crossbowman: 2, ballista: 2, pyromancer: 1, cryomancer: 1, venomancer: 1, mudmancer: 1 }]
].map(([id, name, rows, cols, composition]) => ({ id, name, rows, cols, slots: Object.entries(composition).flatMap(([unitId, count]) => Array.from({ length: count }, (_, index) => ({ row: Math.floor(index / cols), col: index % cols, unitId }))), spacing: 27, sourceSystem: 'field_sigil_rts' }));
DATA.rtsSpells = [
  ['ember_cross', 'Ember Cross', 'click', 7, 28, 2.8, 1.2], ['frost_ring', 'Frost Ring', 'caster', 7, 18, 3.4, .9], ['venom_seal', 'Venom Seal', 'click', 5, 22, 4.2, 1.5]
].map(([id, name, origin, size, damage, duration, expansion]) => ({ id, name, emoji: '', origin, color: '#d9a43f', duration, expansion, damage, size, cells: [Math.floor(size * size / 2)], sourceSystem: 'field_sigil_rts' }));
DATA.godPowers = [
  ['sky_judgment', 'Sky Judgment', 40, 8, 'damage', 85, 95], ['divine_mercy', 'Divine Mercy', 45, 10, 'heal', 95, 120], ['meteor', 'Meteor', 70, 15, 'damage', 130, 145], ['winter_grasp', 'Winter Grasp', 55, 12, 'freeze', 6, 140], ['wild_growth', 'Wild Growth', 35, 9, 'spawnWood', 16, 650], ['earthquake', 'Earthquake', 65, 14, 'earthquake', 60, 175], ['plague', 'Plague', 60, 13, 'poison', 9, 135], ['divine_wall', 'Divine Wall', 40, 8, 'wall', 5, 70], ['custom_rune', 'Custom Rune', 30, 6, 'customSpell', 0, 0]
].map(([id, name, cost, cooldown, effectType, magnitude, radius]) => ({ id, name, emoji: '', cost, cooldown, effectType, magnitude, radius, sourceSystem: 'field_sigil_rts' }));
DATA.rtsBuildingTypes = [
  ['town_center', 'Town Center', 1500, 90, 74, 0, 300, 100], ['house', 'House', 420, 56, 46, 0, 80, 0], ['mill', 'Mill', 500, 62, 52, 0, 110, 0], ['lumber', 'Lumber Camp', 480, 64, 48, 0, 90, 0], ['mine', 'Mining Camp', 480, 58, 48, 0, 100, 0], ['barracks', 'Barracks', 720, 78, 58, 0, 180, 40], ['archery_range', 'Archery Range', 680, 78, 54, 0, 190, 55], ['stable', 'Stable', 760, 86, 58, 0, 220, 90], ['blacksmith', 'Blacksmith', 660, 62, 54, 0, 160, 120], ['mage_tower', 'Mage Tower', 620, 52, 82, 0, 240, 180], ['siege_workshop', 'Siege Workshop', 800, 92, 64, 0, 280, 150], ['keep', 'Keep', 1800, 100, 88, 0, 400, 300]
].map(([id, name, hp, width, height, food, wood, gold]) => ({ id, name, emoji: '', use: '', hp, width, height, cost: { food, wood, gold }, behaviors: [], sourceSystem: 'field_sigil_rts' }));
DATA.buildingComplexes = [
  { id: 'village_core', name: 'Village Core', defaultPriority: 2, plannerWidth: 640, plannerHeight: 420, items: [{ id: 'vc_tc', buildingTypeId: 'town_center', x: 330, y: 210, rotation: 0, priority: 1 }, { id: 'vc_h1', buildingTypeId: 'house', x: 180, y: 115, rotation: -15, priority: 2 }, { id: 'vc_h2', buildingTypeId: 'house', x: 475, y: 120, rotation: 15, priority: 2 }, { id: 'vc_mill', buildingTypeId: 'mill', x: 180, y: 310, rotation: 10, priority: 3 }, { id: 'vc_lumber', buildingTypeId: 'lumber', x: 475, y: 310, rotation: -10, priority: 3 }], sourceSystem: 'field_sigil_rts' },
  { id: 'war_campus', name: 'War Campus', defaultPriority: 2, plannerWidth: 640, plannerHeight: 420, items: [{ id: 'wc_b', buildingTypeId: 'barracks', x: 210, y: 145, rotation: 0, priority: 1 }, { id: 'wc_a', buildingTypeId: 'archery_range', x: 430, y: 145, rotation: 0, priority: 2 }, { id: 'wc_s', buildingTypeId: 'stable', x: 210, y: 300, rotation: 0, priority: 2 }, { id: 'wc_sw', buildingTypeId: 'siege_workshop', x: 430, y: 300, rotation: 0, priority: 3 }, { id: 'wc_bs', buildingTypeId: 'blacksmith', x: 320, y: 225, rotation: 45, priority: 1 }], sourceSystem: 'field_sigil_rts' }
];
DATA.rtsResearch = [
  ['forged_blades', 'Forged Blades', { food: 100, gold: 130 }, 'attack', .12], ['plate_weave', 'Plate Weave', { wood: 120, gold: 110 }, 'defense', 2], ['marching_drill', 'Marching Drill', { food: 160, wood: 80 }, 'speed', .1], ['wheelbarrow', 'Wheelbarrow', { food: 110, wood: 90 }, 'economy', .25], ['runic_memory', 'Runic Memory', { gold: 210 }, 'magic', .2], ['masonry', 'Masonry', { wood: 180, gold: 60 }, 'building', .3]
].map(([id, name, cost, modifier, value]) => ({ id, name, note: '', cost, modifier, value, done: false, prerequisites: [], duration: 0, era: 1, sourceSystem: 'field_sigil_rts' }));

DATA.runtimeVariables = [
  ['player.level', 'number', 'character', true], ['player.xp', 'number', 'character', true], ['player.hp', 'number', 'character', true], ['player.mana', 'number', 'character', true], ['player.position', 'vector3', 'character', true], ['player.target', 'reference', 'runtime', false], ['player.combatTarget', 'reference', 'runtime', false], ['stats.<id>', 'number', 'character', true], ['currencies.<id>', 'number', 'character', true], ['skills.<id>.level', 'number', 'character', true], ['skills.<id>.xp', 'number', 'character', true], ['inventory.<id>.quantity', 'number', 'character', true], ['inventory.<id>.inInventory', 'boolean', 'character', true], ['inventory.<id>.consumed', 'boolean', 'character', true], ['equipment.<slot>', 'itemId', 'character', true], ['world.<state>', 'typed', 'world', true], ['quests.<id>.status', 'enum', 'character', true], ['maps.<id>.visited', 'boolean', 'character', true], ['encounters.<id>.completed', 'boolean', 'character', true], ['tokens.<key>', 'typed', 'dialogue', true], ['unit.target', 'reference', 'runtime', false], ['unit.mesh', 'pointer', 'runtime', false], ['fighter.cooldown', 'seconds', 'runtime', false], ['projectile.targetId', 'fighterId', 'runtime', false], ['resourceNode.amount', 'number', 'runtime', false], ['camera.zoom', 'number', 'runtime', false]
].map(([id, valueType, scope, persistent]) => ({ id: `var_${id.replace(/[^a-z0-9]+/gi, '_')}`, name: id, path: id, valueType, scope, persistent, authority: scope === 'dialogue' ? 'gameplay_designer' : scope === 'character' ? 'emberwake' : 'runtime', defaultValue: null, min: null, max: null, replication: persistent ? 'snapshot' : 'never', sourceSystem: 'shared' }));

DATA.runtimeSchemas = [
  ['emberwake_character', 'Emberwake Character Instance', 'vocationId', ['id', 'name', 'vocationId', 'level', 'experience', 'x', 'y', 'z', 'hp', 'maxHp', 'mana', 'maxMana', 'gold', 'skills', 'inventory', 'containerContents', 'equipment', 'quests', 'flags', 'statuses', 'survival', 'depot'], ['path', 'combatTarget', 'pendingAction']],
  ['primitive_player', 'Primitive Realm Player Save', 'name', runeliteRootFields, ['target', 'combatTarget']],
  ['primitive_npc_actor', 'Primitive Realm NPC Actor', 'npcId', ['id', 'npcId', 'home', 'target', 'area', 'scheduleOffset', 'health', 'maxHealth', 'dead', 'trainingTarget', 'trainingCooldown', 'trainingWeapon'], ['data', 'mesh']],
  ['primitive_enemy_actor', 'Primitive Realm Enemy Actor', 'templateId', ['id', 'templateId', 'x', 'z', 'spawn', 'target', 'hp', 'maxHp', 'dead', 'respawnAt', 'attackCooldown', 'wanderCooldown', 'combatTarget', 'lastAttacker', 'guardAssistCooldown', 'area'], ['data', 'mesh']],
  ['primitive_ground_item', 'Primitive Realm Ground Item', 'itemId', ['id', 'itemId', 'qty', 'x', 'z', 'expiresAt'], ['mesh']],
  ['aegis_unit', 'Aegis Unit Instance', 'cls', ['id', 'cls', 'family', 'faction', 'name', 'x', 'z', 'y', 'facing', 'hp', 'maxHp', 'mp', 'maxMp', 'xp', 'inv', 'equip', 'gold', 'owed', 'gearStep', 'job', 'state', 'think', 'atkCd', 'frozen', 'bornAt', 'ageOffset', 'thought', 'homeBuilding', 'slot', 'greed', 'courage', 'duty', 'flagRef', 'flag', 'awe', 'aweCd', 'pinnedJob', 'lifespan', 'birthAgeYears', 'bornYear', 'carry', 'carryType', 'node', 'site', 'prey', 'shop', 'hauling', 'garrisonOf', 'company'], ['def', 'mesh', 'target', 'squad']],
  ['aegis_building', 'Aegis Building Instance', 'type', ['id', 'type', 'x', 'z', 'tier', 'hp', 'maxHp', 'built', 'prog', 'woodIn', 'woodNeed', 'enemy', 'garrison'], ['def', 'mesh']],
  ['aegis_creature', 'Aegis Creature Instance', 'kind', ['kind', 'name', 'x', 'z', 'hp', 'maxHp', 'girth', 'scale', 'fed', 'hunger', 'mood', 'leashed', 'skills', 'spells'], ['def', 'mesh', 'target']],
  ['rts_fighter', 'RTS Fighter Instance', 'unitId', ['id', 'companyId', 'team', 'unitId', 'x', 'y', 'offsetX', 'offsetY', 'hp', 'maxHp', 'cooldown', 'frozenUntil', 'poisonUntil', 'burnUntil', 'flash'], []],
  ['rts_company', 'RTS Company Instance', 'formationId', ['id', 'team', 'name', 'formationId', 'formationIndex', 'x', 'y', 'targetX', 'targetY', 'stance', 'focus', 'halted', 'patrol', 'flagOffset'], []],
  ['rts_projectile', 'RTS Projectile Instance', 'sourceUnitId', ['x', 'y', 'targetId', 'team', 'damage', 'emoji', 'color', 'speed', 'sourceUnitId', 'dead'], []],
  ['rts_effect', 'RTS Effect / Hazard', 'type', ['type', 'x', 'y', 'created', 'duration', 'radius', 'color', 'emoji', 'expand', 'hazard', 'spellId'], ['spell']],
  ['rts_resource_node', 'RTS Resource Node', 'kind', ['id', 'kind', 'x', 'y', 'amount', 'size'], []],
  ['rts_worker', 'RTS Worker', 'job', ['x', 'y', 'phase', 'job'], []]
].map(([id, name, definitionKey, fields, transientFields]) => ({ id, name, definitionKey, fields, transientFields, persistence: id.includes('character') || id === 'primitive_player' ? 'save snapshot' : 'runtime unless promoted to world snapshot', rehydrateRule: `Resolve ${definitionKey} against its definition registry after load.`, sourceSystem: id.startsWith('aegis') ? 'sovereign_aegis' : id.startsWith('rts') ? 'field_sigil_rts' : id.startsWith('primitive') ? 'runelite_primitive_realm' : 'emberwake' }));

DATA.persistenceRules = [
  ['stable_ids', 'Stable IDs', 'Never rename a stable string ID without an alias and migration.'], ['definition_runtime_split', 'Definitions vs Instances', 'Definitions say what a thing is; instances store only the definition key plus mutable state.'], ['unknown_fields', 'Unknown Fields', 'Round-trip unknown root, integration, Unity component and record fields.'], ['inventory_stack', 'Primitive Inventory Stack', 'Normalize to {id, qty}; unique item metadata belongs in itemInstances until the normalizer changes.'], ['inventory_compaction', 'Primitive Inventory Compaction', 'Loading currently removes null gaps and packs stacks toward the first slots.'], ['hotbar', 'Primitive Hotbar', 'Always ten slots; unknown spell IDs become null.'], ['overall_magic', 'Overall Magic', 'Derived from magic, runecrafting and rune_shooting; never award it XP directly.'], ['optimistic_revision', 'Optimistic Revision', 'Reject a stale save revision with conflict status instead of overwriting newer state.'], ['timestamp_policy', 'Timestamp Policy', 'Use Unix milliseconds for cooldowns and ISO-8601 strings for audits.'], ['no_runtime_pointers', 'No Runtime Pointers', 'Never serialize mesh, def, target, squad, attachTo, DOM nodes, functions, Maps, Sets or circular values.'], ['integration_namespace', 'Integration Namespace', 'Foreign state lives at integrations.<systemId> and migrates independently.'], ['source_authority', 'Authority Order', 'Unity owns serialized bindings; Gameplay Designer owns topology; Stat Designer owns numeric rules; Emberwake owns character movement and inventory; SQL owns identity and revisions.']
].map(([id, name, rule]) => ({ id, name, rule, enforcedBy: 'import/export validator + server revision layer', severity: 'required', sourceSystem: 'shared' }));

DATA.eventTypes = `butler_bank_deposit
butler_bank_withdrawal
chest_opened
consumable_used
container_transfer
cottage_acquired
cottage_rent_auto_paid
cottage_well_used
death_experience_lost
dragon_spar_finished
enemy_killed
equipped_item_dropped
garden_harvested
healing_fountain_used
hotbar_assigned
house_door_toggled
house_room_unlocked
house_training_drill
inventory_moved
item_dropped
item_equipped
item_unequipped
minigame_completed
pet_adopted
pet_released
quest_completed
recipe_crafted
resource_gathered
shop_buy
shop_sell
spell_cast
training_dummy_hit`.split('\n').map(id => ({ id, name: id.replaceAll('_', ' '), payloadSchema: {}, dedupeKey: 'owner_key + event_id', maximumQueued: 100, timestamp: 'ISO-8601', sourceSystem: 'runelite_primitive_realm' }));

DATA.primitiveNpcs = [
  ['banker', 'Banker Ada', 'bank', 'Grand Bank', '', '', ''], ['shopkeeper', 'Shopkeeper Giles', 'shop', 'General Store', 'general_store', '', ''], ['blacksmith', 'Smith Brann', 'craft', 'Forge', 'armor_shop', 'anvil', ''], ['smelter', 'Furnace Keeper Iona', 'craft', 'Forge', '', 'furnace', ''], ['fletcher', 'Fletcher Rowan', 'craft', 'Fletching Hall', 'ranger_shop', 'fletching_bench', ''], ['tanner', 'Tanner Ellis', 'craft', 'Tannery', '', 'tannery', 'apprentice_crafter'], ['weaver', 'Weaver Tessa', 'craft', 'Weaver Hall', '', 'spinning_wheel', 'spider_thread'], ['chef', 'Master Chef Horace', 'craft', 'Golden Ladle Inn', '', 'range', 'cooks_assistant'], ['wizard', 'Wizard Gray', 'quest', 'Arcane Tower', 'magic_shop', '', 'thirsty_mage'], ['huntsman', 'Huntsman Vale', 'slayer', 'Ranger Lodge', '', '', 'bear_hunt'], ['guildmaster', 'Guildmaster Orin', 'quest', 'Adventurers Guild', '', '', 'dragon_slayer'], ['priest', 'Priest Mara', 'prayer', 'Temple', '', '', ''], ['farmer', 'Farmer Bryn', 'farm', 'Market Farm', '', '', ''], ['guard', 'Crownstone Guard', 'guard', 'Guard Barracks', '', '', ''], ['sewer_keeper', 'Drainmaster Pell', 'quest', 'Sewer Works', '', '', 'sewer_key'], ['carpenter', 'Carpenter Nessa', 'craft', 'Carpenters Guild', '', 'sawmill', ''], ['courtyard_trader', 'Mara the Wandering Merchant', 'wandering_merchant', 'Player Courtyard', 'home_trader', '', ''], ['training_archer_one', 'Archer Tovin', 'training_archer', '', '', '', ''], ['training_archer_two', 'Archer Sela', 'training_archer', '', '', '', ''], ['training_soldier', 'Sergeant Bram', 'training_melee', '', '', '', ''], ['butler', 'Butler Alden', 'butler', 'Player Cottage', 'butler_pantry', '', '']
].map(([id, name, role, building, shop, station, quest]) => ({ id, name, role, building, dialogue: [], quest, shop, station, inventory: [], spellbook: { learned: [] }, patrol: [], trainingTarget: '', sourceSystem: 'runelite_primitive_realm' }));
DATA.primitiveShops = [
  ['general_store', 'Crownstone General Store'], ['ranger_shop', "Rowan's Bow Shop"], ['armor_shop', "Brann's Armor Counter"], ['magic_shop', "Gray's Rune & Staff Shop"], ['home_trader', "Mara's Courtyard Caravan"], ['butler_pantry', "Butler Alden's Pantry & Common-Drop Counter"]
].map(([id, name]) => ({ id, name, buyMultiplier: 1.15, sellMultiplier: .45, stock: {}, buyList: [], sourceSystem: 'runelite_primitive_realm' }));
DATA.primitiveQuests = [
  ['thirsty_mage', 'The Thirsty Mage', 'wizard'], ['cooks_assistant', "The Baker's Feast", 'chef'], ['goblin_slayer', 'Goblin Menace', 'guard'], ['spider_thread', "The Spider's Thread", 'weaver'], ['bear_hunt', 'Bear Hunt', 'huntsman'], ['apprentice_crafter', 'Apprentice Crafter', 'tanner'], ['sewer_key', 'Key Beneath the City', 'sewer_keeper'], ['dragon_slayer', 'Dragon Slayer', 'guildmaster']
].map(([id, name, giverId]) => ({ id, name, giverId, summary: '', requirements: {}, objectives: [], rewards: { xp: {}, items: {}, coins: 0 }, states: ['not_started', 'active', 'completed'], sourceSystem: 'runelite_primitive_realm' }));
DATA.primitiveEnemies = [
  ['chicken', 'Chicken', 1, 6, 'melee', 6, false, [{ item: 'bones', chance: 1, min: 1, max: 1 }, { item: 'feather', chance: 1, min: 5, max: 15 }, { item: 'raw_beef', chance: .1, min: 1, max: 1 }]],
  ['cow', 'Cow', 2, 12, 'melee', 10, false, [{ item: 'bones', chance: 1, min: 1, max: 1 }, { item: 'cowhide', chance: 1, min: 1, max: 1 }, { item: 'raw_beef', chance: 1, min: 1, max: 1 }, { item: 'cow_horn_trophy', chance: .16, min: 1, max: 1 }]],
  ['goblin', 'Goblin', 5, 15, 'melee', 20, false, [{ item: 'bones', chance: 1, min: 1, max: 1 }, { item: 'coins', chance: .75, min: 3, max: 18 }, { item: 'bronze_sword', chance: .08, min: 1, max: 1 }, { item: 'mind_rune', chance: .12, min: 2, max: 8 }]],
  ['bear', 'Bear', 12, 25, 'melee', 35, false, [{ item: 'big_bones', chance: 1, min: 1, max: 1 }, { item: 'bear_fur', chance: 1, min: 1, max: 1 }, { item: 'coins', chance: .45, min: 15, max: 45 }]],
  ['giant_spider', 'Giant Spider', 20, 35, 'melee', 55, false, [{ item: 'silk', chance: .65, min: 1, max: 2 }, { item: 'coins', chance: .35, min: 20, max: 70 }, { item: 'chaos_rune', chance: .08, min: 3, max: 10 }]],
  ['skeleton', 'Skeleton', 25, 45, 'melee', 65, false, [{ item: 'bones', chance: 1, min: 1, max: 1 }, { item: 'coins', chance: .55, min: 25, max: 90 }, { item: 'iron_sword', chance: .06, min: 1, max: 1 }, { item: 'death_rune', chance: .03, min: 2, max: 5 }]],
  ['sewer_rat', 'Sewer Rat', 3, 10, 'melee', 12, false, [{ item: 'bones', chance: 1, min: 1, max: 1 }, { item: 'raw_rat_meat', chance: .75, min: 1, max: 1 }, { item: 'rat_tail', chance: .5, min: 1, max: 1 }, { item: 'coins', chance: .35, min: 1, max: 6 }]],
  ['cave_rat', 'Cave Rat', 8, 22, 'melee', 28, false, [{ item: 'bones', chance: 1, min: 1, max: 1 }, { item: 'raw_rat_meat', chance: 1, min: 1, max: 2 }, { item: 'cave_fang', chance: .35, min: 1, max: 1 }, { item: 'iron_ore', chance: .12, min: 1, max: 2 }]],
  ['sewer_slime', 'Sewer Slime', 11, 30, 'melee', 36, false, [{ item: 'slime_core', chance: .55, min: 1, max: 1 }, { item: 'water_rune', chance: .45, min: 2, max: 9 }, { item: 'sewer_key', chance: .08, min: 1, max: 1, unique: true }]],
  ['road_brigand', 'Road Brigand', 15, 38, 'melee', 48, false, [{ item: 'bones', chance: 1, min: 1, max: 1 }, { item: 'coins', chance: .9, min: 25, max: 100 }, { item: 'steel_dagger', chance: .05, min: 1, max: 1 }, { item: 'warehouse_key', chance: .04, min: 1, max: 1 }]],
  ['grey_wolf', 'Grey Wolf', 18, 42, 'melee', 56, false, [{ item: 'bones', chance: 1, min: 1, max: 1 }, { item: 'wolf_pelt', chance: .8, min: 1, max: 1 }, { item: 'raw_beef', chance: .65, min: 1, max: 2 }]],
  ['dark_wizard', 'Dark Wizard', 28, 55, 'magic', 70, false, [{ item: 'bones', chance: 1, min: 1, max: 1 }, { item: 'chaos_rune', chance: .65, min: 4, max: 16 }, { item: 'death_rune', chance: .18, min: 2, max: 8 }, { item: 'fire_staff', chance: .025, min: 1, max: 1 }, { item: 'dark_essence', chance: .08, min: 1, max: 1 }]],
  ['moss_giant', 'Moss Giant', 32, 75, 'melee', 85, false, [{ item: 'big_bones', chance: 1, min: 1, max: 1 }, { item: 'nature_rune', chance: .12, min: 2, max: 6 }, { item: 'steel_battleaxe', chance: .04, min: 1, max: 1 }, { item: 'coins', chance: .7, min: 75, max: 260 }]],
  ['ogre', 'Ogre', 38, 90, 'melee', 100, false, [{ item: 'big_bones', chance: 1, min: 1, max: 1 }, { item: 'steel_legs', chance: .025, min: 1, max: 1 }, { item: 'coins', chance: .75, min: 100, max: 350 }, { item: 'law_rune', chance: .08, min: 1, max: 4 }]],
  ['sewer_king', 'The Sewer King', 35, 180, 'melee', 180, true, [{ item: 'big_bones', chance: 1, min: 2, max: 2 }, { item: 'coins', chance: 1, min: 400, max: 900 }, { item: 'sewer_key', chance: 1, min: 1, max: 1, unique: true }, { item: 'king_rat_pet', chance: .005, min: 1, max: 1 }, { item: 'slime_core', chance: .5, min: 3, max: 8 }]],
  ['iron_golem', 'Iron Golem', 46, 260, 'melee', 260, true, [{ item: 'big_bones', chance: 1, min: 2, max: 3 }, { item: 'iron_bar', chance: 1, min: 4, max: 10 }, { item: 'steel_bar', chance: .55, min: 2, max: 6 }, { item: 'golem_core', chance: .2, min: 1, max: 1 }, { item: 'mithril_sword', chance: .015, min: 1, max: 1 }]],
  ['red_dragon', 'Red Dragon', 50, 320, 'magic', 320, true, [{ item: 'dragon_bones', chance: 1, min: 1, max: 1 }, { item: 'green_dragonhide', chance: 1, min: 1, max: 2 }, { item: 'coins', chance: 1, min: 800, max: 2500 }, { item: 'dragonfire_blade', chance: .008, min: 1, max: 1, unique: true }, { item: 'dragon_pet', chance: .002, min: 1, max: 1, unique: true }]]
].map(([id, name, level, hp, combatStyle, xp, boss, drops]) => ({ id, name, level, hp, aggro: true, speed: 1, attackSpeed: 2, maxHit: Math.max(1, Math.round(level / 5)), combatStyle, color: '#7a6655', shape: id, xp, drops, boss, sourceSystem: 'runelite_primitive_realm' }));
DATA.primitiveSpells = [
  ['wind_strike', 'Wind Strike', 1, 3, 6, 1, { air_rune: 1, mind_rune: 1 }], ['water_strike', 'Water Strike', 5, 5, 9, 2, { air_rune: 1, water_rune: 1, mind_rune: 1 }], ['earth_strike', 'Earth Strike', 9, 7, 12, 3, { air_rune: 1, earth_rune: 2, mind_rune: 1 }], ['fire_strike', 'Fire Strike', 13, 9, 15, 4, { air_rune: 2, fire_rune: 3, mind_rune: 1 }], ['varrock_teleport', 'Crownstone Teleport', 25, 0, 35, 6, { air_rune: 3, fire_rune: 1, law_rune: 1 }], ['house_teleport', 'Player House Teleport', 1, 0, 15, 4, { law_rune: 1, air_rune: 1 }]
].map(([id, name, level, maxHit, xp, mpCost, runes]) => ({ id, name, level, maxHit, xp, mpCost, runes, teleport: id.includes('teleport') ? id : '', sourceSystem: 'runelite_primitive_realm' }));
DATA.primitivePrayers = [
  ['thick_skin', 'Thick Skin', 1, .18, { defence: .05 }], ['burst_strength', 'Burst of Strength', 4, .22, { strength: .05 }], ['clarity_thought', 'Clarity of Thought', 7, .22, { attack: .05 }], ['rock_skin', 'Rock Skin', 10, .32, { defence: .1 }], ['rapid_heal', 'Rapid Heal', 22, .45, { regenerationMultiplier: 2 }], ['protect_melee', 'Protect from Melee', 43, .8, { meleeProtection: .4 }]
].map(([id, name, level, drain, effects]) => ({ id, name, level, drain, effects, sourceSystem: 'runelite_primitive_realm' }));

DATA.aegisSkills = [
  ['hitpoints', 'Dealing and taking damage', 'maxHp +3 per level'], ['attack', 'Landing melee blows', 'Melee power'], ['strength', 'Landing melee blows', 'Melee power'], ['defence', 'Being struck', 'Damage reduction'], ['ranged', 'Arrow hits and hunting', 'Bow damage and hunter speed'], ['magic', 'Bolts, roots and healing', 'Spell damage'], ['prayer', 'Worship at a temple', 'Spell-energy yield'], ['herblore', 'Druid healing', 'Heal potency'], ['woodcutting', 'Felling trees', 'Yield and rate'], ['mining', 'Working stone and veins', 'Yield and rate'], ['smithing', 'Buying gear and artisan work', 'Converter experience'], ['construction', 'Building and repairing', 'Build rate'], ['farming', 'Farms and foraging', 'Food yield'], ['thieving', 'Rogue actions', 'Thieving outcomes'], ['breeding', 'Raising children', 'Birth gap and twin odds']
].map(([id, trainedBy, drives]) => ({ id, name: id[0].toUpperCase() + id.slice(1), trainedBy, drives, maxLevel: 99, xpFormulaId: 'runelite_xp_curve', sourceSystem: 'sovereign_aegis' }));
DATA.aegisCreatures = [
  ['ox', 'Ox', 'ox', 'steadfast', .6, 0], ['wolf', 'Wolf', 'wolf', 'predator', 1.1, 0], ['ape', 'Ape', 'ape', 'clever', .9, .01], ['tortoise', 'Tortoise', 'tortoise', 'ancient', .35, .025]
].map(([id, name, shape, trait, hungerRate, regen]) => ({ id, name, shape, trait, hungerRate, regen, hp: 100, speed: 1, damage: 8, perInstanceDefinition: true, growthFields: ['girth', 'scale', 'fed', 'hunger', 'mood'], sourceSystem: 'sovereign_aegis' }));

DATA.specialObjectTypes = ['travel', 'pickup', 'locked_chest', 'thieving_stall', 'station', 'farm_patch', 'rest', 'spellbook', 'house_unlock', 'pet_manager', 'door', 'healing_well', 'healing_fountain', 'minigame', 'training_dummy', 'sparring_dragon'].map(id => ({ id, name: id.replaceAll('_', ' '), fields: ['id', 'type', 'name', 'icon', 'x', 'z', 'station', 'shop', 'item', 'level', 'xp', 'target', 'targetArea', 'key', 'rewards', 'flag', 'onceFlag', 'visibleWhenFlag', 'requirements', 'unlockName', 'openFlag', 'openAngle', 'requiresCottage', 'continuous', 'occupiedBy', 'game', 'healPerUse', 'mpPerUse', 'visual'], sourceSystem: 'runelite_primitive_realm' }));
const primitiveSpecialRows = `house_portal_out|Portal to Crownstone City Center|travel
city_home_portal|Portal to Your Player-Owned House|travel
sewer_ladder_down|Climb down sewer ladder|travel
sewer_ladder_up|Climb up to Crownstone|travel
sewer_key_cache|Search broken drain|pickup
sewer_treasure|Locked Sewer Treasure Chest|locked_chest
silk_stall|Silk Stall|thieving_stall
city_bank|Bank Booth|station
city_shop|General Store Counter|station
city_furnace|Furnace|station
city_anvil|Anvil|station
city_fletching|Fletching Bench|station
city_tannery|Tanning Rack|station
city_spinning|Spinning Wheel|station
city_range|Cooking Range|station
city_altar|Temple Altar|station
city_farm|City Allotment|farm_patch
city_sawmill|Saw Bench|station
house_bank|Cottage Depot Chest|station
house_range|House Cooking Range|station
house_crafting|House Crafting Table|station
house_altar|House Altar|station
house_bed|Cottage Bed|rest
house_spell_lectern|Spellbook Lectern|spellbook
house_enchanting_desk|Arcane Study Spell Desk|spellbook
house_pet_manager|Pet Room Adoption Board|pet_manager
cottage_training_dummy|Cottage Indoor Training Dummy|training_dummy
cottage_runecrafting_altar|Cottage Rune-Crafting Altar|station
house_arcane_door|Locked Arcane Study|house_unlock
house_pet_door|Locked Pet Room|house_unlock
house_front_door|Front Garden Door|door
house_back_door|Back Yard Door|door
cow_pasture_gate|Cow Pasture Gate|door
house_healing_fountain|Cottage Well|healing_well
house_outdoor_farm|Home Garden Allotment|farm_patch
house_outdoor_range|Outdoor Cooking Hearth|station
house_training_dummy|Open Practice Dummy|training_dummy
house_garden_game|Garden Rune Match Table|minigame
home_furnace|Home Smelting Furnace|station
home_anvil|Home Smithing Anvil|station
home_trader_cart|Mara's Courtyard Caravan|station
house_dummy_archer_one|Archer Practice Dummy One|training_dummy
house_dummy_archer_two|Archer Practice Dummy Two|training_dummy
house_dummy_melee|Sergeant's Melee Dummy|training_dummy
home_sparring_dragon|Emberward, the Sparring Dragon|sparring_dragon`;
DATA.primitiveSpecialObjects = primitiveSpecialRows.split('\n').map(line => { const [id, name, type] = line.split('|'); return { id, name, type, icon: '', x: 0, z: 0, station: '', shop: '', item: '', level: 1, xp: 0, target: {}, targetArea: '', key: '', rewards: {}, flag: '', onceFlag: '', visibleWhenFlag: '', requirements: {}, unlockName: '', openFlag: type === 'door' ? `${id}_open` : '', openAngle: 0, requiresCottage: id.startsWith('house_') || id.startsWith('cottage_'), continuous: type === 'training_dummy', occupiedBy: '', game: '', healPerUse: id === 'house_healing_fountain' ? 1 : 0, mpPerUse: id === 'house_healing_fountain' ? 1 : 0, visual: {}, sourceSystem: 'runelite_primitive_realm' }; });

const AUTHORING_SCHEMA_SPECS = {
  items: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['type', 'Classification', 'enum:currency,tool,resource,food,seed,rune,weapon,armor,ammo,quest,pet,spellbook,trash,material,container'], ['value', 'Economy', 'number'], ['buy', 'Economy', 'number'], ['sell', 'Economy', 'number'], ['weight', 'Physical', 'number'], ['stackable', 'Inventory', 'boolean'], ['stackLimit', 'Inventory', 'number'], ['container', 'Inventory', 'boolean'], ['slot', 'Equipment', 'enum:head,body,legs,feet,hands,weapon,shield,ammo,cape,neck,ring'], ['tier', 'Equipment', 'number'], ['combatStyle', 'Combat', 'enum:melee,ranged,magic'], ['weaponClass', 'Combat', 'string'], ['animationClass', 'Combat', 'string'], ['trainingSkill', 'Combat', 'ref:skills'], ['toolType', 'Gathering', 'enum:axe,pickaxe,bow,staff,sword'], ['stats', 'Modifiers', 'object'], ['actions', 'Actions', 'array'], ['bound', 'Rules', 'boolean'], ['rare', 'Rules', 'boolean']],
  monsters: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['level', 'Progression', 'number'], ['hp', 'Combat', 'number'], ['attack', 'Combat', 'number'], ['defense', 'Combat', 'number'], ['speed', 'Movement', 'number'], ['attackSpeed', 'Combat', 'number'], ['range', 'Combat', 'number'], ['aggro', 'AI', 'number'], ['combatStyle', 'Combat', 'enum:melee,ranged,magic'], ['element', 'Combat', 'string'], ['xp', 'Rewards', 'number'], ['boss', 'Classification', 'boolean'], ['traits', 'AI', 'string'], ['aiFamily', 'AI', 'ref:entityFamilies'], ['resistances', 'Combat', 'object'], ['statuses', 'Combat', 'array'], ['dropTableId', 'Rewards', 'ref:dropTables']],
  npcs: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['role', 'Role', 'string'], ['building', 'World', 'ref:buildings'], ['x', 'World', 'number'], ['y', 'World', 'number'], ['z', 'World', 'number'], ['zoneId', 'World', 'ref:zones'], ['dialogue', 'Dialogue', 'array'], ['quest', 'Services', 'ref:quests'], ['quests', 'Services', 'array'], ['shop', 'Services', 'ref:shops'], ['station', 'Services', 'string'], ['inventory', 'Inventory', 'array'], ['equipment', 'Inventory', 'object'], ['spellbook', 'Magic', 'object'], ['patrol', 'AI', 'array'], ['trainingTarget', 'AI', 'string'], ['factionId', 'AI', 'string'], ['persistentInventory', 'Persistence', 'boolean']],
  shops: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['npcId', 'Ownership', 'ref:npcs'], ['buyMultiplier', 'Economy', 'number'], ['sellMultiplier', 'Economy', 'number'], ['stock', 'Inventory', 'object'], ['buys', 'Inventory', 'array'], ['sells', 'Inventory', 'array'], ['buyList', 'Rules', 'array'], ['restockSeconds', 'Rules', 'number'], ['currencyId', 'Economy', 'ref:currencyDefinitions'], ['infiniteStock', 'Rules', 'boolean']],
  spells: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['group', 'Classification', 'string'], ['effect', 'Effect', 'string'], ['level', 'Requirements', 'number'], ['magicLevel', 'Requirements', 'number'], ['mana', 'Cost', 'number'], ['mpCost', 'Cost', 'number'], ['runes', 'Cost', 'object'], ['cooldown', 'Timing', 'number'], ['castTime', 'Timing', 'number'], ['range', 'Targeting', 'number'], ['radius', 'Targeting', 'number'], ['maxHit', 'Effect', 'number'], ['xp', 'Progression', 'number'], ['vocations', 'Requirements', 'array'], ['targetType', 'Targeting', 'enum:self,tile,enemy,ally,area'], ['teleport', 'Effect', 'ref:zones'], ['onHitEffects', 'Effect', 'array'], ['cells', 'Pattern', 'array']],
  quests: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['giverId', 'Ownership', 'ref:npcs'], ['summary', 'Presentation', 'string'], ['recommendedLevel', 'Requirements', 'number'], ['requirements', 'Requirements', 'object'], ['prerequisite', 'Requirements', 'array'], ['objectives', 'Objectives', 'array'], ['rewards', 'Rewards', 'object'], ['repeatable', 'Rules', 'boolean'], ['solo', 'Rules', 'boolean'], ['nextQuestId', 'Flow', 'ref:quests'], ['guidanceTarget', 'Flow', 'object'], ['failureConditions', 'Rules', 'array']],
  buildings: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['type', 'Classification', 'ref:buildingTypes'], ['x', 'Placement', 'number'], ['y', 'Placement', 'number'], ['z', 'Placement', 'number'], ['width', 'Geometry', 'number'], ['height', 'Geometry', 'number'], ['depth', 'Geometry', 'number'], ['rotation', 'Geometry', 'number'], ['hp', 'Simulation', 'number'], ['cost', 'Economy', 'object'], ['effects', 'Simulation', 'array'], ['npcIds', 'Occupancy', 'array'], ['shopIds', 'Services', 'array'], ['floors', 'Geometry', 'number'], ['collision', 'Geometry', 'object'], ['parts', 'Model', 'array'], ['tiers', 'Progression', 'array'], ['ownership', 'Rules', 'object']],
  vocations: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['promotion', 'Progression', 'ref:vocations'], ['hpPerLevel', 'Gains', 'number'], ['manaPerLevel', 'Gains', 'number'], ['capacityPerLevel', 'Gains', 'number'], ['magicPowerPerMagicLevel', 'Magic', 'number'], ['magicPowerPerCharacterLevel', 'Magic', 'number'], ['magicXpCostMultiplier', 'Magic', 'number'], ['magicXpGrowth', 'Magic', 'number'], ['magicTrainingRate', 'Magic', 'number'], ['skillMultipliers', 'Skills', 'object'], ['equipmentSlots', 'Equipment', 'array'], ['gearLadder', 'Equipment', 'array']],
  externalClasses: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['label', 'Identity', 'string'], ['family', 'AI', 'ref:entityFamilies'], ['colour', 'Appearance', 'color'], ['accent', 'Appearance', 'color'], ['hp', 'Combat', 'number'], ['mp', 'Combat', 'number'], ['speed', 'Movement', 'number'], ['radius', 'Geometry', 'number'], ['height', 'Geometry', 'number'], ['attackRange', 'Combat', 'number'], ['attackSpeed', 'Combat', 'number'], ['damage', 'Combat', 'number'], ['projectile', 'Combat', 'object'], ['greed', 'Personality', 'number'], ['courage', 'Personality', 'number'], ['duty', 'Personality', 'number'], ['baseSkills', 'Skills', 'object'], ['noDefend', 'AI', 'boolean'], ['builder', 'AI', 'boolean'], ['siege', 'AI', 'boolean'], ['healPower', 'Support', 'number'], ['healRange', 'Support', 'number'], ['rootDuration', 'Combat', 'number'], ['food', 'Economy', 'number'], ['herds', 'AI', 'boolean'], ['skittish', 'AI', 'boolean'], ['bounty', 'Economy', 'number'], ['trainCost', 'Progression', 'object'], ['trainTime', 'Progression', 'number'], ['needs', 'Simulation', 'object'], ['desc', 'Metadata', 'text'], ['gearLadder', 'Equipment', 'array'], ['aiFunction', 'AI', 'string']],
  rtsUnitTypes: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['health', 'Combat', 'number'], ['attack', 'Combat', 'number'], ['defense', 'Combat', 'number'], ['speed', 'Movement', 'number'], ['range', 'Combat', 'number'], ['rate', 'Combat', 'number'], ['focus', 'AI', 'enum:melee,ranged,support'], ['stance', 'AI', 'enum:chase,keep-away,ground'], ['role', 'Classification', 'string'], ['projectile', 'Combat', 'object'], ['tiers', 'Progression', 'array'], ['activeTierId', 'Progression', 'string'], ['onHitEffect', 'Combat', 'object']],
  externalBuildings: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['label', 'Identity', 'string'], ['civic', 'Classification', 'boolean'], ['age', 'Requirements', 'string'], ['costText', 'Economy', 'string'], ['cost', 'Economy', 'object'], ['work', 'Construction', 'number'], ['hp', 'Combat', 'number'], ['width', 'Geometry', 'number'], ['depth', 'Geometry', 'number'], ['height', 'Geometry', 'number'], ['colour', 'Appearance', 'color'], ['roof', 'Appearance', 'string'], ['blocks', 'Collision', 'number'], ['guildId', 'Services', 'ref:externalClasses'], ['guild', 'Services', 'ref:externalClasses'], ['effectsText', 'Simulation', 'string'], ['effect', 'Simulation', 'object'], ['parts', 'Model', 'array'], ['models', 'Model', 'array'], ['tiers', 'Progression', 'array'], ['collider', 'Geometry', 'object'], ['iconDir', 'Metadata', 'string'], ['prefabDir', 'Metadata', 'string']],
  rtsFormations: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['rows', 'Grid', 'number'], ['cols', 'Grid', 'number'], ['slots', 'Grid', 'array'], ['spacing', 'Grid', 'number']],
  rtsSpells: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['emoji', 'Presentation', 'string'], ['origin', 'Targeting', 'enum:click,caster'], ['color', 'Presentation', 'color'], ['duration', 'Timing', 'number'], ['expansion', 'Timing', 'number'], ['damage', 'Combat', 'number'], ['size', 'Grid', 'number'], ['cells', 'Grid', 'array']],
  buildingComplexes: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['defaultPriority', 'Construction', 'number'], ['plannerWidth', 'Planner', 'number'], ['plannerHeight', 'Planner', 'number'], ['items', 'Planner', 'array']],
  sequenceDefinitions: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['scene', 'Unity', 'string'], ['hierarchyPath', 'Unity', 'string'], ['globalObjectId', 'Unity', 'string'], ['fileId', 'Unity', 'string'], ['entryNodeId', 'Graph', 'ref:sequenceNodes'], ['componentIds', 'Graph', 'array'], ['conditions', 'Flow', 'array'], ['actions', 'Flow', 'array']],
  sequenceNodes: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['sequenceId', 'Graph', 'ref:sequenceDefinitions'], ['component', 'Graph', 'string'], ['type', 'Graph', 'enum:Condition,Map,Inventory,Interaction,Story,Timing'], ['label', 'Graph', 'string'], ['x', 'Graph', 'number'], ['y', 'Graph', 'number'], ['conditions', 'Flow', 'array'], ['actions', 'Flow', 'array']],
  sequenceEdges: [['id', 'Identity', 'string', true], ['name', 'Identity', 'string', true], ['sequenceId', 'Graph', 'ref:sequenceDefinitions'], ['from', 'Graph', 'ref:sequenceNodes'], ['to', 'Graph', 'ref:sequenceNodes'], ['conditions', 'Flow', 'array']]
};
const sharedMetadataFieldSpecs = [['iconDirectory', 'Metadata', 'string'], ['modelDirectory', 'Metadata', 'string'], ['description', 'Metadata', 'text'], ['tooltip', 'Metadata', 'text']];
DATA.fieldDefinitions = [];
for (const [category, fields] of Object.entries(AUTHORING_SCHEMA_SPECS)) for (const [path, group, typeSpec, required = false] of [...fields, ...sharedMetadataFieldSpecs]) {
  const [valueType, optionText = ''] = typeSpec.split(':');
  DATA.fieldDefinitions.push({ id: `field_${category}_${path}`, name: path, category, path, label: path.replace(/([A-Z])/g, ' $1').replace(/^./, value => value.toUpperCase()), group, valueType, required, options: valueType === 'enum' ? optionText.split(',') : [], referenceCategory: valueType === 'ref' ? optionText : '', defaultValue: valueType === 'number' ? 0 : valueType === 'boolean' ? false : valueType === 'array' ? [] : valueType === 'object' ? {} : '', min: null, max: null, step: valueType === 'number' ? 1 : null, persistence: 'definition', scope: 'definition', mergeRule: ['array', 'object'].includes(valueType) ? 'preserve-unknown-deep-merge' : 'replace', sourceSystem: 'shared' });
}
for (const field of DATA.fieldDefinitions) for (const row of DATA[field.category] || []) if (valueAtPath(row, field.path) === undefined) setValueAtPath(row, field.path, deepClone(field.defaultValue));

const categoryRows = [
  ['primitiveEnemies', 'Primitive Realm Enemies & Bosses', 'creature', 'runelite_primitive_realm'], ['primitiveSpecialObjects', 'Primitive Realm Special Objects', 'specialObject', 'runelite_primitive_realm'], ['aegisCreatures', 'Aegis Growing Creatures', 'creature', 'sovereign_aegis'], ['aegisSkills', 'Aegis Skills', 'skill', 'sovereign_aegis'],
  ['items', 'Items & Equipment', 'item', 'emberwake'], ['primitiveItems', 'Primitive Realm Items', 'item', 'runelite_primitive_realm'], ['gameplayInventory', 'Gameplay Designer Inventory', 'item', 'gameplay_designer'], ['externalItems', 'Aegis Items', 'item', 'sovereign_aegis'], ['monsters', 'Creatures & Enemies', 'creature', 'emberwake'], ['npcs', 'NPCs & Characters', 'npc', 'emberwake'], ['primitiveNpcs', 'Primitive Realm NPCs', 'npc', 'runelite_primitive_realm'], ['shops', 'Shops & Merchants', 'shop', 'emberwake'], ['primitiveShops', 'Primitive Realm Shops', 'shop', 'runelite_primitive_realm'], ['spells', 'Spells & Runes', 'spell', 'emberwake'], ['primitiveSpells', 'Primitive Realm Spells', 'spell', 'runelite_primitive_realm'], ['primitivePrayers', 'Primitive Realm Prayers', 'prayer', 'runelite_primitive_realm'], ['quests', 'Quests', 'quest', 'emberwake'], ['primitiveQuests', 'Primitive Realm Quests', 'quest', 'runelite_primitive_realm'], ['buildings', 'World Buildings', 'building', 'emberwake'], ['externalBuildings', 'Aegis Buildings', 'building', 'sovereign_aegis'], ['rtsBuildingTypes', 'RTS Building Types', 'building', 'field_sigil_rts'], ['buildingComplexes', 'Building Complexes', 'complex', 'field_sigil_rts'], ['vocations', 'Vocations', 'class', 'emberwake'], ['externalClasses', 'Aegis Classes', 'class', 'sovereign_aegis'], ['rtsUnitTypes', 'RTS Unit Types', 'unit', 'field_sigil_rts'], ['rtsFormations', 'RTS Formations', 'formation', 'field_sigil_rts'], ['rtsSpells', 'RTS Rune Patterns', 'spell', 'field_sigil_rts'], ['godPowers', 'God Powers', 'power', 'field_sigil_rts'], ['skills', 'Emberwake Skills', 'skill', 'emberwake'], ['primitiveSkills', 'Primitive Realm Skills', 'skill', 'runelite_primitive_realm'], ['statDesignerSkills', 'Stat Designer Skills', 'skill', 'stat_system_designer'], ['statDefinitions', 'Stat Definitions', 'stat', 'stat_system_designer'], ['currencyDefinitions', 'Currencies', 'currency', 'stat_system_designer'], ['encounters', 'Encounters', 'encounter', 'stat_system_designer'], ['mapDefinitions', 'Map Definitions', 'map', 'stat_system_designer'], ['mapNodes', 'Map Nodes', 'mapNode', 'stat_system_designer'], ['dialogueGlobals', 'Dialogue Globals', 'dialogue', 'gameplay_designer'], ['sequenceDefinitions', 'Sequences', 'sequence', 'gameplay_designer'], ['sequenceNodes', 'Sequence Nodes', 'sequenceNode', 'gameplay_designer'], ['sequenceEdges', 'Sequence Edges', 'sequenceEdge', 'gameplay_designer'], ['unityComponentTypes', 'Unity Components', 'unityComponent', 'gameplay_designer'], ['runtimeVariables', 'Runtime Variables', 'variable', 'shared'], ['runtimeSchemas', 'Runtime Instance Schemas', 'runtimeSchema', 'shared'], ['mutationTypes', 'Mutation Types', 'mutation', 'shared'], ['conditionOperators', 'Condition Operators', 'condition', 'shared'], ['persistenceRules', 'Persistence Rules', 'persistenceRule', 'shared'], ['eventTypes', 'Event Types', 'event', 'shared'], ['specialObjectTypes', 'Special Object Types', 'specialObjectType', 'runelite_primitive_realm'], ['relationships', 'Relationships', 'relationship', 'shared'], ['formulaDefinitions', 'Formula Definitions', 'formula', 'shared'], ['effectTypes', 'Effect Types', 'effect', 'shared'], ['gameRules', 'Game Rules', 'rule', 'emberwake'], ['zones', 'Zones & Areas', 'zone', 'emberwake'], ['spawns', 'Spawn Points', 'spawn', 'emberwake'], ['placements', 'World Placements', 'placement', 'emberwake']
];
DATA.authoringCategories = categoryRows.map(([storageKey, name, entityType, sourceSystem]) => ({ id: `category_${storageKey}`, name, storageKey, entityType, sourceSystem, layer: 'definition', runtimeCollection: '', persistence: 'catalog + JSON + MySQL', stableIdRequired: true, preserveUnknownFields: true, fourStringFieldsRequired: true, builderPreset: entityType }));

DATA.sourceRegistryCounts = [
  ['runelite_primitive_realm', 'skills', 32, DATA.primitiveSkills.length], ['runelite_primitive_realm', 'items', 183, DATA.primitiveItems.length], ['runelite_primitive_realm', 'recipes', 109, DATA.primitiveRecipeGroups.length], ['runelite_primitive_realm', 'enemies', 14, DATA.primitiveEnemies.filter(row => !row.boss).length], ['runelite_primitive_realm', 'bosses', 3, DATA.primitiveEnemies.filter(row => row.boss).length], ['runelite_primitive_realm', 'npcs', 21, DATA.primitiveNpcs.length], ['runelite_primitive_realm', 'shops', 6, DATA.primitiveShops.length], ['runelite_primitive_realm', 'quests', 8, DATA.primitiveQuests.length], ['runelite_primitive_realm', 'specialObjects', 45, DATA.primitiveSpecialObjects.length],
  ['gameplay_designer', 'inventoryDefinitions', 50, DATA.gameplayInventory.length], ['gameplay_designer', 'inventorySlots', 8, DATA.inventorySlotSets[0].slots.length], ['sovereign_aegis', 'classes', 22, 21], ['sovereign_aegis', 'buildings', 71, DATA.externalBuildings.length], ['sovereign_aegis', 'items', 17, 12], ['sovereign_aegis', 'skills', 15, DATA.aegisSkills.length], ['sovereign_aegis', 'jobs', 11, DATA.jobs.length], ['sovereign_aegis', 'research', 14, DATA.research.length], ['field_sigil_rts', 'units', 18, DATA.rtsUnitTypes.length], ['field_sigil_rts', 'formations', 5, DATA.rtsFormations.length], ['field_sigil_rts', 'spells', 3, DATA.rtsSpells.length], ['field_sigil_rts', 'godPowers', 9, DATA.godPowers.length], ['field_sigil_rts', 'buildingTypes', 12, DATA.rtsBuildingTypes.length]
].map(([sourceSystem, registry, verifiedCount, loadedCount]) => ({ id: `count_${sourceSystem}_${registry}`, name: `${sourceSystem}.${registry}`, sourceSystem, registry, verifiedCount, loadedCount, status: verifiedCount === loadedCount ? 'complete' : 'schema-ready / source summary loaded', notes: verifiedCount === loadedCount ? 'All enumerated source records are present.' : 'The source contract reported this total but did not enumerate every full record.' }));

DATA.buildingTypes = [
  ['house', 'House', '#5a3e2d', '#9c754c', '#caa86f'], ['hall', 'Hall', '#403d3a', '#777268', '#d0b56c'], ['civic', 'Civic Hall', '#403d3a', '#777268', '#d0b56c'], ['shop', 'Shop', '#3f584b', '#73906e', '#d7ba6d'],
  ['inn', 'Inn', '#57352d', '#9d5f47', '#e6bd75'], ['market', 'Market', '#3f584b', '#73906e', '#d7ba6d'], ['smithy', 'Smithy', '#3e3632', '#6a5b52', '#d1744d'], ['depot', 'Depot', '#3b4448', '#66747a', '#b7c2bd'],
  ['stable', 'Stable', '#4a3828', '#80613f', '#d1b06e'], ['castle', 'Castle', '#302d2b', '#5d5047', '#b58b5a'], ['tower', 'Tower', '#29292b', '#545158', '#9f8d73'], ['barracks', 'Barracks', '#3b2b29', '#70483e', '#bd7555']
].map(([id, name, wallColor, roofColor, trimColor]) => ({ id, name, wallColor, roofColor, trimColor, defaultCollision: 'walls with marked entrances', description: `${name} visual and collision data used by world buildings.` }));

DATA.gods = DATA.gods || [
  { id: 'god_first_light', name: 'The First Light', domains: ['renewal', 'courage'], powerIds: ['radiant_burst'], followerCharacterIds: [], pantheonId: 'pantheon_dawnreach', worshipRules: { favorPerQuest: 2, favorPerOffering: 1 } },
  { id: 'god_ashen_crown', name: 'The Ashen Crown', domains: ['dominion', 'ordeal'], powerIds: [], followerCharacterIds: [], pantheonId: 'pantheon_ashen', worshipRules: { favorPerQuest: 1, favorPerOffering: 3 }, interests:['public fear','hard-won power'], opposedInterests:['mercy','renewal'] }
];
DATA.pantheons = DATA.pantheons || [
  { id: 'pantheon_dawnreach', name: 'Dawnreach Concord', godIds: ['god_first_light'], doctrine: 'Mortals earn divine notice through brave service.', rivalryPantheonIds: ['pantheon_ashen'], sharedFavorPool: false },
  { id: 'pantheon_ashen', name: 'Ashen Court', godIds: ['god_ashen_crown'], doctrine: 'Adversity reveals who deserves authority.', rivalryPantheonIds: ['pantheon_dawnreach'], sharedFavorPool: false }
];
DATA.guilds = DATA.guilds || [
  { id: 'guild_dawnroad', name: 'Dawnroad Company', memberCharacterIds: [], leaderCharacterId: '', villageId: 'village_anchorage', ranks: ['Recruit', 'Warden', 'Captain'], availableTitleTags: ['Founder','Quartermaster','Arena Keeper','Guild Moderator'], memberTags: {}, treasuryGold: 0, permissions: { invite: ['Captain'], withdraw: ['Captain'] } }
];
DATA.realms = DATA.realms || [{ id:'realm_dawnreach', name:'Dawnreach Realm', godId:'god_first_light', worldIds:['world_emberwake'], description:'The primary realm containing the Emberwake test worlds.', tooltip:'God → Realm hierarchy level.' }];
DATA.villagerClasses = DATA.villagerClasses || [
  ['villager','Villager','folk'],['elder','Elder','folk'],['laborer','Laborer','folk'],['fisherman','Fisherman','folk'],['craftsman','Craftsman','folk'],['guard','Guard','soldier'],['soldier','Soldier','soldier'],['hero','Hero','hero'],['rogue','Rogue','hero'],['wizard','Wizard','hero'],['druid','Druid','hero'],['imp','Imp','creature'],['demigod','Demigod','divine'],
  ['black_knight_villager','Black Knight Villager','hero'],['ranger_villager','Ranger Villager','hero'],['sprite_villager','Sprite Villager','hero'],['necromancer_villager','Necromancer Villager','hero'],['siege_operator_villager','Siege Operator Villager','soldier']
].map(([id,name,family])=>({id,name,family,baseClassId:id.includes('_villager')?id.replace('_villager',''):'villager',duplicateFromId:id==='villager'?'':id==='elder'?'villager':id.includes('_villager')?'hero':'villager',statOverrides:{},skillMultipliers:{},allowedJobIds:[],defaultTagIds:[family],description:`${name} villager-class variant for character-scale testing.`,tooltip:`Duplicate and edit ${name} without changing its base class.`}));
DATA.natureDefinitions = DATA.natureDefinitions || [
  { id: 'nature_tidegrass', name: 'Tidegrass', kind: 'flora', biomeIds: ['harbor_grassland'], harvestSkillId: 'woodcutting', regrowSeconds: 180, yieldItemIds: ['ironwood_beam'], density: .45 },
  { id: 'nature_iron_vein', name: 'Iron Vein', kind: 'mineral', biomeIds: ['cave'], harvestSkillId: 'mining', regrowSeconds: 240, yieldItemIds: ['iron_ore'], density: .18 }
];
DATA.natureZones = DATA.natureZones || [{ id: 'nature_zone_harbor', name: 'Anchorage Greenbelt', zoneId: 'anchorage_harbor', natureDefinitionIds: ['nature_tidegrass'], spawnBudget: 18, seasonalRules: {}, weatherRules: {} }];
DATA.villageDistricts = DATA.villageDistricts || [{ id: 'district_anchorage_hearth', name: 'Hearth Ward', villageId: 'village_anchorage', buildingIds: ['build_tideglass', 'build_furniture_shop'], npcIds: ['npc_edda', 'npc_tovin'], shopIds: ['furniture'], serviceIds: ['housing', 'furnishing'] }];
DATA.villageServices = DATA.villageServices || [{ id: 'service_anchorage_housing', name: 'Anchorage Housing Service', villageId: 'village_anchorage', providerNpcIds: ['npc_edda'], buildingIds: ['build_tideglass'], openingHours: { start: 0, end: 24 }, priceMultiplier: 1 }];
DATA.villageRoutes = DATA.villageRoutes || [{ id: 'route_hearth_market', name: 'Hearth-to-Market Walk', villageId: 'village_anchorage', fromBuildingId: 'build_tideglass', toBuildingId: 'build_furniture_shop', waypoints: [{ x: 23, y: 39, z: 0 }, { x: 25, y: 39, z: 0 }], walkableRequired: true }];
DATA.progressionTracks = DATA.progressionTracks || [{ id: 'track_hero_growth', name: 'Hero Growth', currencyId: 'perk_points', nodeIds: ['node_hardy_steps'], pointsPerLevel: 1, maxPoints: 200, unlockMode: 'prerequisite_graph' }];
DATA.progressionNodes = DATA.progressionNodes || [{ id: 'node_hardy_steps', name: 'Hardy Steps', trackId: 'track_hero_growth', prerequisiteNodeIds: [], cost: 1, maxRank: 5, effects: [{ stat: 'maxHp', operation: 'add', valuePerRank: 5 }], position: { x: 0, y: 0 } }];
DATA.progressionLoops = DATA.progressionLoops || [{ id: 'loop_hunt_improve', name: 'Hunt → Recover → Improve', entryEvent: 'monster_killed', steps: ['collect_loot', 'train_skills', 'spend_perk_points', 'hunt_stronger_spawn'], rewardIds: ['perk_points'], resetRule: 'never', repeatable: true }];
DATA.perks = DATA.perks || [{ id: 'perk_pack_mule', name: 'Pack Mule', trackId: 'track_hero_growth', nodeId: 'node_hardy_steps', rank: 1, effects: [{ stat: 'carryCapacity', operation: 'multiply', value: 1.05 }] }];
DATA.upgrades = DATA.upgrades || [{ id: 'upgrade_tideglass_depot', name: 'Tideglass Depot Service', targetType: 'house', targetId: 'house_tideglass', tier: 1, maxTier: 1, cost: { gold: 0 }, prerequisites: ['house_tideglass'], effects: [{ feature: 'unlimited_depot', enabled: true }] }];
DATA.levelMaps = DATA.levelMaps || [{
  id: 'map_emberwake_overworld', name: 'Emberwake Overworld', width: WORLD_W, height: WORLD_H, tileSize: TILE, seed: 1, backgroundTerrainId: 'deep_water', spawn: { x: 18, y: 46, z: 0 },
  layers: { terrain: deepClone(DATA.levelTiles), pathing: [] }, staticObjects: [], entities: [], chunkSize: 32, sourceSystem: 'emberwake',
  description: 'The complete currently playable Emberwake world.', tooltip: 'Original live world map and source-of-truth layout.'
}];
DATA.mapCivicRequirements = DATA.mapCivicRequirements || [
  { id: 'civic_spawn', name: 'Safe player arrival', category: 'spawn', minimum: 1, recommendedAssetIds: [], rule: 'Spawn is walkable and outside hostile aggro.' },
  { id: 'civic_food', name: 'Food or provisions source', category: 'shop', minimum: 1, recommendedAssetIds: ['general_store'], rule: 'Prevents survival systems from blocking progression.' },
  { id: 'civic_healing', name: 'Healing or rest service', category: 'service', minimum: 1, recommendedAssetIds: ['inn', 'well'], rule: 'At least one safe recovery point.' },
  { id: 'civic_storage', name: 'Depot storage', category: 'depot', minimum: 1, recommendedAssetIds: ['depot_box'], rule: 'Persistent storage must be reachable.' },
  { id: 'civic_trader', name: 'General merchant', category: 'shop', minimum: 1, recommendedAssetIds: ['market'], rule: 'Buys common loot and sells basic supplies.' },
  { id: 'civic_quest', name: 'Quest giver', category: 'npc', minimum: 1, recommendedAssetIds: [], rule: 'Provides a clear first objective.' },
  { id: 'civic_route', name: 'Connected exit route', category: 'route', minimum: 1, recommendedAssetIds: [], rule: 'Spawn, services, and exits share a walkable path.' },
  { id: 'civic_light', name: 'Light source', category: 'lighting', minimum: 1, recommendedAssetIds: ['wall_torch'], rule: 'Required when the map contains darkness.' }
];
DATA.mapObjectInstances = DATA.mapObjectInstances || [];
DATA.mapEntityInstances = DATA.mapEntityInstances || [];
for(const [baseId,id,name,icon] of [['priest','high_luminary','High Luminary','✷'],['warhealer','dawn_marshal','Dawn Marshal','✥'],['battlemage','spellblade_regent','Spellblade Regent','⚜'],['siege_operator','grand_bombardier','Grand Bombardier','☄']]){
  const base=byId(DATA.vocations,baseId);if(base&&!byId(DATA.vocations,id)){base.promotion=id;DATA.vocations.push({...deepClone(base),id,name,icon,base:baseId,promotion:'',promotedName:'',hpGain:Math.ceil(base.hpGain*1.12),manaGain:Math.ceil(base.manaGain*1.12),capGain:Math.ceil(base.capGain*1.1),role:`Promoted ${base.role.toLowerCase()}`});}
}
for(const vocation of DATA.vocations){
  vocation.promotion=vocation.promotion||'';
  vocation.healthRegenPerSecond=Number(vocation.healthRegenPerSecond??Math.max(.08,Number(vocation.hpGain||5)/50));
  vocation.manaRegenPerSecond=Number(vocation.manaRegenPerSecond??Math.max(.08,Number(vocation.manaGain||5)/45));
  vocation.regenGrowthPerLevel=Number(vocation.regenGrowthPerLevel??.015);
  vocation.killHealLevelFactor=Number(vocation.killHealLevelFactor??.001);
  vocation.killHealCap=Number(vocation.killHealCap??1);
  vocation.fountainRegenMultiplier=Number(vocation.fountainRegenMultiplier??10);
  vocation.standardPotionMultiplier=Number(vocation.standardPotionMultiplier??10);
  vocation.greatPotionMultiplier=Number(vocation.greatPotionMultiplier??50);
  vocation.supremePotionMultiplier=Number(vocation.supremePotionMultiplier??1000);
}
DATA.items.push(
  {id:'great_health_potion',name:'Great Roseglass Tonic',type:'potion',icon:'⚗',color:'#f05d72',weight:2.5,buy:420,sell:84,potionResource:'health',potionTier:'great',stackable:true,description:'Restores fifty times the class health-regeneration amount.'},
  {id:'supreme_health_potion',name:'Sovereign Roseglass Elixir',type:'potion',icon:'⚗',color:'#ff8095',weight:3,buy:12500,sell:2500,potionResource:'health',potionTier:'supreme',stackable:true,description:'An extremely expensive health elixir worth one thousand class regeneration ticks.'},
  {id:'great_mana_potion',name:'Great Blueglass Draught',type:'potion',icon:'⚗',color:'#55bdf3',weight:2.5,buy:460,sell:92,potionResource:'mana',potionTier:'great',stackable:true,description:'Restores fifty times the class mana-regeneration amount.'},
  {id:'supreme_mana_potion',name:'Sovereign Blueglass Elixir',type:'potion',icon:'⚗',color:'#85d3ff',weight:3,buy:13500,sell:2700,potionResource:'mana',potionTier:'supreme',stackable:true,description:'An extremely expensive mana elixir worth one thousand class regeneration ticks.'}
);
Object.assign(byId(DATA.items,'minor_potion'),{potionResource:'health',potionTier:'standard'});
Object.assign(byId(DATA.items,'mana_potion'),{potionResource:'mana',potionTier:'standard'});
DATA.shops.push({id:'potion_house',name:'Glasswake Tonics',buys:['minor_potion','mana_potion','great_health_potion','great_mana_potion'],sells:['minor_potion','mana_potion','great_health_potion','great_mana_potion','supreme_health_potion','supreme_mana_potion','antidote']});
DATA.npcs.push({id:'npc_sera_vial',name:'Sera Vial',role:'Potion merchant',icon:'⚗',x:18,y:44,z:0,zoneId:'anchorage_harbor',quests:[],shop:'potion_house',description:'A nearby apothecary who sells class-scaled health and mana potions from standard to sovereign strength.'});
DATA.buildings.push({id:'build_glasswake_tonics',name:'Glasswake Tonics',type:'shop',x:16,y:41,z:0,width:5,height:3,npcIds:['npc_sera_vial'],collision:'open south door',description:'A compact potion shop beside the safe harbor road.'});
DATA.items.push(
  {id:'harbor_sprat',name:'Harbor Sprat',type:'food',icon:'𓆝',color:'#78b5c9',weight:1,buy:8,sell:2,heal:4,nutrition:8,stackable:true,description:'A common edible harbor fish.'},
  {id:'silverfin',name:'Silverfin',type:'food',icon:'𓆟',color:'#b7d9df',weight:2,buy:28,sell:7,heal:12,nutrition:18,stackable:true,description:'A bright mid-depth fish.'},
  {id:'ember_koi',name:'Ember Koi',type:'food',icon:'𓆛',color:'#dc7d51',weight:3,buy:95,sell:24,heal:30,nutrition:30,stackable:true,description:'A rare warm-scaled fish prized by harbor cooks.'}
);
DATA.fishingDropTables=[{id:'fish_anchorage_training',name:'Anchorage Training Waters',fishEntries:[{itemId:'harbor_sprat',weight:70,minLevel:1},{itemId:'silverfin',weight:25,minLevel:8},{itemId:'ember_koi',weight:5,minLevel:20}],gearRollChance:.12,gearItemIds:[],itemLevelMinimum:100,itemLevelMaximum:1000,rarityBias:'More valuable equipment rolls toward higher item levels',description:'Repeatable safe-harbor fishing rewards with an independent equipment roll.'}];
DATA.smithingRecipes=[
  {id:'smith_copper_blade',name:'Copper Training Blade',level:1,inputs:{copper_chunk:2,hardwood_log:1},outputs:{bent_sword:1},xp:45},
  {id:'smith_plank_guard',name:'Plank Guard',level:3,inputs:{copper_chunk:1,hardwood_log:2},outputs:{plank_shield:1},xp:60},
  {id:'smith_iron_mace',name:'Iron Sun Mace',level:8,inputs:{iron_ore:3,hardwood_log:1},outputs:{sun_mace:1},xp:105},
  {id:'smith_ringmail',name:'Harbor Ringmail',level:15,inputs:{iron_ore:6,coal_chunk:2},outputs:{ringmail:1},xp:190}
];
DATA.provenancePolicies=[{id:'provenance_default',name:'Universal Authorship and Custody',trackDefinitions:true,trackInstances:true,trackServerDrops:true,trackAdminCreation:true,retainOriginalAuthor:true,appendTransfers:true,adminTooltipColor:'#d7473f',description:'Every authored building and item keeps its original author, source, current owner and immutable custody history.'}];
DATA.happinessContexts=[['world_hunt','World Hunt',1],['pvp_match','Organized PvP Match',.65],['war','Declared War',1.35],['player_killing','Unlawful Player Killing',1.7],['server_event','Server Event',.8]].map(([id,name,multiplier])=>({id,name,multiplier,enabled:true,description:`Editable happiness context for ${name.toLowerCase()}.`}));
DATA.factions=DATA.factions||[];for(const [id,name,rivals,allies] of [['faction_anchorage','Anchorage Folk',['faction_orcrown'],['faction_first_light']],['faction_orcrown','Orcrown Host',['faction_anchorage','faction_first_light'],[]],['faction_first_light','First Light Faithful',['faction_orcrown'],['faction_anchorage']],['faction_wild','Wild Creatures',[],[]]])if(!byId(DATA.factions,id))DATA.factions.push({id,name,rivalFactionIds:rivals,alliedFactionIds:allies,neutralDefeatModifier:0,rivalDefeatModifier:4,allyDefeatModifier:-6,lovedDefeatModifier:-20,playerKillingModifier:-12,description:`Happiness response policy for ${name}.`});
DATA.factionHappinessRules=DATA.factions.map(faction=>({id:`happiness_${faction.id}`,name:`${faction.name} Defeat Reactions`,factionId:faction.id,contextModifiers:{world_hunt:1,pvp_match:.65,war:1.35,player_killing:1.7,server_event:.8},neutralDefeat:faction.neutralDefeatModifier,rivalDefeat:faction.rivalDefeatModifier,allyDefeat:faction.allyDefeatModifier,lovedDefeat:faction.lovedDefeatModifier,description:`Expandable per-context defeat reactions for ${faction.name}.`}));
DATA.characterAffections=[];
for(const [index,character] of DATA.characters.entries()){character.happiness=Number(character.happiness??50);character.factionId=character.factionId||'faction_anchorage';character.happinessHistory=character.happinessHistory||[];DATA.characterAffections.push({id:`affections_${character.id}`,name:`${character.name} Affections`,characterId:character.id,lovedEntityIds:index===0?['npc_edda']:[],rivalEntityIds:index===0?['mob_orc_grunt']:[],likedFactionIds:['faction_anchorage'],rivalFactionIds:['faction_orcrown'],description:'Direct emotional relationships evaluated before general faction rules.'});}
for(const monster of DATA.monsters){monster.factionId=monster.factionId||(/orc/i.test(`${monster.id} ${monster.name}`)?'faction_orcrown':'faction_wild');monster.happinessModifier=Number(monster.happinessModifier??(/boss|dragon/i.test(`${monster.id} ${monster.name}`)?6:1));}
DATA.upgradeCurrencies=[{id:'upgrade_points',name:'Upgrade Points',startingAmount:0,earnedBy:['level milestones','quests','server events'],spendScope:'character',respecCostFormula:'500 * purchasedNodes',description:'Unassigned branching-upgrade currency; new characters begin with zero.'}];
DATA.upgradeTierDefinitions=[
  {id:'tier_common',name:'Common',tier:1,costMultiplier:1,statMultiplier:1,color:'#737b88'},
  {id:'tier_refined',name:'Refined',tier:2,costMultiplier:4,statMultiplier:1.25,color:'#00b8ff'},
  {id:'tier_masterwork',name:'Masterwork',tier:3,costMultiplier:18,statMultiplier:1.65,color:'#9c6cff'},
  {id:'tier_relic',name:'Relic',tier:4,costMultiplier:90,statMultiplier:2.4,color:'#ff2d8d'},
  {id:'tier_ungodly',name:'Ungodly',tier:5,costMultiplier:600,statMultiplier:4,color:'#ff455f'}
];
DATA.upgradeBranches=[
  {id:'branch_vanguard',name:'Vanguard',playStyle:'melee tank',currencyId:'upgrade_points',rootNodeIds:['up_vanguard_1'],appliesTo:['characters','vocations','items'],description:'Health, armor, blocking, melee force and retaliation.'},
  {id:'branch_marksman',name:'Marksman',playStyle:'ranged precision',currencyId:'upgrade_points',rootNodeIds:['up_marksman_1'],appliesTo:['characters','vocations','items'],description:'Range, ammunition efficiency, accuracy, movement and critical outcomes.'},
  {id:'branch_arcanist',name:'Arcanist',playStyle:'spell power',currencyId:'upgrade_points',rootNodeIds:['up_arcanist_1'],appliesTo:['characters','vocations','spells','items'],description:'Magic level growth, mana, spell power, runes and cooldowns.'},
  {id:'branch_prospector',name:'Prospector',playStyle:'harvesting and crafting',currencyId:'upgrade_points',rootNodeIds:['up_prospector_1'],appliesTo:['items','placements','smithingRecipes','fishingDropTables'],description:'Tool yield, harvesting speed, rare finds, crafting quality and building production.'},
  {id:'branch_fortune',name:'Fortune',playStyle:'Vagabond luck',currencyId:'upgrade_points',rootNodeIds:['up_fortune_1'],appliesTo:['characters','dropTables','fishingDropTables','quests'],description:'Luck, rare rolls, social outcomes, treasure quality and favorable branching results.'}
];
DATA.branchingUpgradeNodes=DATA.upgradeBranches.flatMap((branch,branchIndex)=>[1,2,3,4,5].map(tier=>({id:`up_${branch.id.replace('branch_','')}_${tier}`,name:`${branch.name} ${DATA.upgradeTierDefinitions[tier-1].name}`,branchId:branch.id,tier,pointCost:[1,4,14,55,300][tier-1],goldCost:[100,900,7500,80000,1500000][tier-1],prerequisiteNodeIds:tier===1?[]:[`up_${branch.id.replace('branch_','')}_${tier-1}`],exclusiveWithBranchIds:tier>=4?DATA.upgradeBranches.filter(other=>other.id!==branch.id).map(other=>other.id):[],effects:branch.id==='branch_vanguard'?{maxHpMultiplier:1+tier*.08,armorMultiplier:1+tier*.06,meleeDamageMultiplier:1+tier*.05}:branch.id==='branch_marksman'?{rangeBonus:tier,accuracyMultiplier:1+tier*.06,ammoSaveChance:tier*.06}:branch.id==='branch_arcanist'?{manaMultiplier:1+tier*.09,magicPowerMultiplier:1+tier*.07,cooldownMultiplier:1-tier*.04}:branch.id==='branch_prospector'?{harvestYieldBonus:tier,harvestSpeedMultiplier:1+tier*.1,craftedItemLevelBonus:tier*20,buildingProductionMultiplier:1+tier*.08}:{luckBonus:tier*8,rareDropMultiplier:1+tier*.12,questOutcomeBonus:tier*.05},description:`Tier ${tier} ${branch.name} node with escalating cost and broadly data-driven outcome mutations.`})));
DATA.scenes=[{id:'scene_emberwake',name:'Emberwake Play Scene',mapId:'map_emberwake_overworld',kind:'playable_world',grid:{width:256,height:192,tileSize:40},description:'The established playable world, now represented as a fully editable scene.'},{id:'scene_development_lab',name:'Ungodly Development Test Scene',mapId:'map_development_lab',kind:'development_test',grid:{width:256,height:192,tileSize:40},description:'A massive organized systems laboratory with safe galleries, item displays, simulated players and quarantined creature testing.'}];
if(!byId(DATA.levelMaps,'map_development_lab'))DATA.levelMaps.push({id:'map_development_lab',name:'Ungodly Development Test Scene',sceneId:'scene_development_lab',width:256,height:192,tileSize:40,seed:808080,backgroundTerrainId:'fortress_floor',spawn:{x:20,y:20,z:0},layers:{terrain:[],pathing:[]},staticObjects:[],entities:[],chunkSize:32,sourceSystem:'ungodly_backend',description:'Tool-authored development map with danger isolated east of a sealed wall.',tooltip:'Editable development scene.',iconDirectory:'/assets/icons/levelMaps/map_development_lab.png',modelDirectory:'/assets/models/levelMaps/map_development_lab.glb'});
DATA.sceneDoors=[{id:'door_to_development',name:'Development Transit Door',mapId:'map_emberwake_overworld',x:19,y:46,z:0,targetMapId:'map_development_lab',targetX:20,targetY:20,targetZ:0,icon:'🚪',description:'Toggles from the live world to the development scene.'},{id:'door_to_emberwake',name:'Return to Emberwake',mapId:'map_development_lab',x:20,y:18,z:0,targetMapId:'map_emberwake_overworld',targetX:19,targetY:46,targetZ:0,icon:'🚪',description:'Returns from the development scene to Emberwake.'}];
for(const door of DATA.sceneDoors)if(!DATA.placements.some(place=>place.id===door.id))DATA.placements.push({...door,type:'scene_door',entityId:door.id,label:door.name,authoredById:'server',authoredByName:'Ungodly Backend',ownershipChain:[{at:nowIso(),fromId:null,toId:'server',toName:'Ungodly Backend',reason:'scene editor placement'}],placedByTool:'scene_editor'});
DATA.spawnerDefinitions=[
  {id:'spawn_lab_small',name:'Small Creature Demonstrator',mapId:'map_development_lab',x:190,y:40,z:0,creatureId:'mob_scavenger_rat',desiredAlive:8,spawnBatch:2,respawnSeconds:12,activeDurationSeconds:0,startDelaySeconds:2,maxTotalSpawns:0,spawnRadius:8,formation:'random',aggressive:true,playerSafeBarrier:true,enabled:true,description:'Maintains eight small creatures indefinitely inside quarantine.'},
  {id:'spawn_lab_boss',name:'Timed Boss Demonstrator',mapId:'map_development_lab',x:220,y:130,z:0,creatureId:'boss_brood_tyrant',desiredAlive:1,spawnBatch:1,respawnSeconds:90,activeDurationSeconds:900,startDelaySeconds:10,maxTotalSpawns:5,spawnRadius:3,formation:'center',aggressive:true,playerSafeBarrier:true,enabled:true,description:'Timed limited-count boss spawner.'}
];
DATA.simulatedPlayers=[{id:'sim_tank',name:'Nyx-04',mapId:'map_development_lab',x:178,y:65,z:0,vocationId:'black_knight',level:80,team:'simulation_blue',targetSpawnerId:'spawn_lab_small',aggressiveToPlayer:false,icon:'♞'},{id:'sim_healer',name:'Mend-7',mapId:'map_development_lab',x:180,y:66,z:0,vocationId:'priest',level:75,team:'simulation_blue',targetSpawnerId:'spawn_lab_small',aggressiveToPlayer:false,icon:'✚'},{id:'sim_ranger',name:'Vector-9',mapId:'map_development_lab',x:176,y:67,z:0,vocationId:'royal_scout',level:78,team:'simulation_blue',targetSpawnerId:'spawn_lab_small',aggressiveToPlayer:false,icon:'🏹'}];
for(let index=0;index<DATA.items.length;index++){const x=35+index%28*3,y=28+Math.floor(index/28)*3;DATA.mapEntityInstances.push({id:`lab_item_${index}`,instanceId:`lab_item_${index}`,mapId:'map_development_lab',type:'item_display',assetId:DATA.items[index].id,position:{x,y,z:0},stats:{quantity:1},aiRoutine:'none',description:`Item museum display for ${DATA.items[index].name}.`,tooltip:`Placed by the Scene Editor item-gallery generator.`,placedByTool:'scene_editor'});}
for(let index=0;index<DATA.monsters.length;index++){const x=170+index%18*4,y=28+Math.floor(index/18)*5;DATA.mapEntityInstances.push({id:`lab_monster_${index}`,instanceId:`lab_monster_${index}`,mapId:'map_development_lab',type:'monster_display',assetId:DATA.monsters[index].id,position:{x,y,z:0},stats:{contained:true},aiRoutine:'quarantined_wander',description:`Contained creature exhibit for ${DATA.monsters[index].name}.`,tooltip:'Placed by the Scene Editor creature-gallery generator.',placedByTool:'scene_editor'});}
DATA.emojiPalette=[...'⚔️ 🛡️ 🗡️ 🪓 ⛏️ 🔨 🏹 🪄 🔮 📜 📕 🎒 🧰 🪙 💎 🧪 ⚗️ 🧵 🪡 🪵 🪨 🪴 🌲 🌳 🌾 🍄 🌿 🐟 🐠 🐡 🦈 🐙 🦀 🦞 🐚 🦴 🥩 🍖 🍞 🧀 🍎 🐀 🐍 🕷️ 🦂 🐺 🐗 🐻 🦌 🦅 🐲 🐉 👹 👺 💀 👻 🔥 ❄️ ⚡ ☀️ 🌙 ⭐ 💧 🌀 🏰 🏠 🏪 🏛️ ⛺ 🗿 🚪 🕳️ 🪜 🛏️ 🪑 📦'.split(' ')].map((emoji,index)=>({id:`emoji_${index+1}`,name:emoji,emoji,usage:['item','creature','npc','building'],description:`Selectable authoring symbol ${emoji}.`}));
DATA.fishingDropTables[0].gearItemIds=DATA.items.filter(item=>item.slot&&item.slot!=='back').map(item=>item.id);
DATA.shops.push({id:'harbor_equipment',name:'Starter Equipment Exchange',buys:DATA.items.filter(item=>item.slot).map(item=>item.id),sells:['bent_sword','plank_shield','ringmail','trail_boots','shore_bow','reed_arrow','harbor_spear','spark_wand','fishing_rod','woodcut_axe','pickaxe']});
DATA.npcs.push({id:'npc_kest_gear',name:'Kest Brasshook',role:'Equipment seller',icon:'⚔',x:23,y:45,z:0,zoneId:'anchorage_harbor',quests:[],shop:'harbor_equipment',description:'Supplies all tools needed for the nearby gathering and smithing training yard.'});
DATA.buildings.push({id:'build_harbor_training_forge',name:'Harbor Training Forge',type:'smithy',x:25,y:43,z:0,width:5,height:4,npcIds:[],collision:'open work yard',description:'A safe starter forge supplied by the nearby renewable training grove and seams.'});
DATA.placements.push(
  {id:'place_starter_tree_1',type:'resource',entityId:'starter_tree_1',x:22,y:49,z:0,label:'Young training tree',skillId:'woodcutting',yieldItemId:'hardwood_log',toolId:'woodcut_axe',respawnSeconds:5},
  {id:'place_starter_tree_2',type:'resource',entityId:'starter_tree_2',x:23,y:50,z:0,label:'Young training tree',skillId:'woodcutting',yieldItemId:'hardwood_log',toolId:'woodcut_axe',respawnSeconds:5},
  {id:'place_starter_copper_1',type:'resource',entityId:'starter_copper_1',x:25,y:49,z:0,label:'Training copper seam',skillId:'mining',yieldItemId:'copper_chunk',toolId:'pickaxe',respawnSeconds:5},
  {id:'place_starter_iron_1',type:'resource',entityId:'starter_iron_1',x:26,y:49,z:0,label:'Training iron seam',skillId:'mining',yieldItemId:'iron_ore',toolId:'pickaxe',respawnSeconds:7},
  {id:'place_starter_coal_1',type:'resource',entityId:'starter_coal_1',x:27,y:49,z:0,label:'Training coal outcrop',skillId:'mining',yieldItemId:'coal_chunk',toolId:'pickaxe',respawnSeconds:7},
  {id:'place_starter_fishing_1',type:'fishing',entityId:'starter_fishing_1',x:13,y:49,z:0,label:'Calm training waters',skillId:'fishing',toolId:'fishing_rod',dropTableId:'fish_anchorage_training',respawnSeconds:2},
  {id:'place_starter_fishing_2',type:'fishing',entityId:'starter_fishing_2',x:13,y:50,z:0,label:'Calm training waters',skillId:'fishing',toolId:'fishing_rod',dropTableId:'fish_anchorage_training',respawnSeconds:2},
  {id:'place_starter_forge',type:'smithing_station',entityId:'starter_forge',x:27,y:47,z:0,label:'Harbor training anvil'}
);
for(const building of DATA.buildings){building.authoredById=building.authoredById||'server';building.authoredByName=building.authoredByName||'Emberwake Server';building.adminCreated=Boolean(building.adminCreated);building.ownershipChain=building.ownershipChain||[{at:nowIso(),fromId:null,toId:'server',toName:'Emberwake Server',reason:'world authorship'}];}
for(const place of DATA.placements){place.authoredById=place.authoredById||'server';place.authoredByName=place.authoredByName||'Emberwake Server';place.adminCreated=Boolean(place.adminCreated);place.ownershipChain=place.ownershipChain||[{at:nowIso(),fromId:null,toId:'server',toName:'Emberwake Server',reason:'world placement'}];}
for(const [index,item] of DATA.items.entries())if(!item.icon)item.icon=DATA.emojiPalette[index%DATA.emojiPalette.length].emoji;
for(const [index,monster] of DATA.monsters.entries())if(!monster.icon)monster.icon=DATA.emojiPalette[(index+35)%DATA.emojiPalette.length].emoji;
for(const monster of DATA.monsters){const table=DATA.dropTables.find(row=>row.monsterId===monster.id);if(!table)continue;if(!table.entries.some(entry=>entry.itemId==='small_bones'||entry.itemId==='sturdy_bones'))table.entries.push({itemId:Number(monster.level||1)>=35?'sturdy_bones':'small_bones',tier:'always',chancePercent:100,min:1,max:Math.max(1,Math.floor(Number(monster.level||1)/40)+1)});if(!table.entries.some(entry=>entry.itemId==='raw_game_meat')&&!/slime|skeleton|ghost|spirit|construct|elemental/i.test(`${monster.id} ${monster.name}`))table.entries.push({itemId:'raw_game_meat',tier:'common',chancePercent:35,min:1,max:Math.max(1,Math.ceil(Number(monster.level||1)/50))});table.scatterRadius=Number(table.scatterRadius??2);}
for (const item of DATA.items) { if (!item.slot && !['weapon','armor','shield','wand'].includes(item.type)) continue; item.gearScoreBase=Number(item.gearScoreBase??Math.max(1,Math.round(Number(item.attack||0)*2.5+Number(item.armor||0)*2+Number(item.defense||0)*2+Number(item.magicPower||0)*2.5+Math.sqrt(Math.max(0,Number(item.buy||0)))/3)));item.gearCurveId=item.gearCurveId||(item.type==='weapon'||item.type==='wand'?'curve_weapon_standard':item.type==='shield'?'curve_guard_standard':['ring','amulet','container','ammo'].includes(item.slot)?'curve_accessory_standard':'curve_armor_standard');item.minimumItemLevel=Number(item.minimumItemLevel||1);item.maximumItemLevel=Number(item.maximumItemLevel||100); }
for(const [index,npc] of DATA.npcs.entries()){npc.tags=[...new Set(npc.tags||['npc',String(npc.role||'citizen').split(/\s|&/)[0].toLowerCase()].filter(Boolean))];npc.socialStats=npc.socialStats||Object.fromEntries(DATA.socialStats.map(stat=>[stat.id,stat.defaultValue]));if(!DATA.personalities.some(row=>row.ownerType==='npc'&&row.ownerId===npc.id)){const archetype=DATA.archetypes[index%DATA.archetypes.length];DATA.personalities.push({id:`personality_${npc.id}`,name:`${npc.name} Personality`,ownerType:'npc',ownerId:npc.id,archetypeId:archetype.id,cloneSourceId:'',traits:deepClone(archetype.traits),aspirationIds:deepClone(archetype.aspirationIds),fearIds:deepClone(archetype.fearIds),preferenceIds:deepClone(archetype.preferenceIds),values:['community'],speechStyle:'direct'});}}
for(const character of DATA.characters){character.tags=[...new Set(character.tags||[character.vocationId,'playable'])];character.socialStats=character.socialStats||Object.fromEntries(DATA.socialStats.map(stat=>[stat.id,stat.defaultValue]));character.reputations=character.reputations||Object.fromEntries(DATA.reputations.map(rep=>[rep.id,0]));character.itemProgress=character.itemProgress||{};}
for (const [storageKey, name, entityType] of [
  ['gods', 'Gods', 'god'], ['pantheons', 'Pantheons', 'pantheon'], ['guilds', 'Guilds', 'guild'], ['guildHalls','Guild Halls','guild-hall'], ['villageStores','Village Stores','village-store'], ['realms','Realms','realm'], ['villagerClasses','Villager Classes','villager-class'], ['gearLevelCurves','Gear Level Curves','gear-curve'], ['itemUpgradeServices','Item Upgrade Services','upgrade-service'], ['socialStats','Social Stats','social-stat'], ['socialEventDefinitions','Social Events','social-event'], ['archetypes','Personality Archetypes','archetype'], ['personalities','Personalities','personality'], ['aspirations','Aspirations','aspiration'], ['fears','Fears','fear'], ['preferences','Preferences','preference'], ['feelingRelationships','Feeling Relationships','feeling-relationship'], ['reputations','Reputations','reputation'], ['reputationGoals','Reputation Goals','reputation-goal'], ['leaderboardDefinitions','Leaderboards','leaderboard'], ['characterTags','Character Tags','character-tag'], ['natureDefinitions', 'Nature Definitions', 'nature'], ['natureZones', 'Nature Zones', 'nature-zone'], ['villageDistricts', 'Village Districts', 'district'], ['villageServices', 'Village Services', 'service'], ['villageRoutes', 'Village Routes', 'route'], ['progressionTracks', 'Progression Tracks', 'progression-track'], ['progressionNodes', 'Progression Nodes', 'progression-node'], ['progressionLoops', 'Progression Loops', 'progression-loop'], ['perks', 'Perks', 'perk'], ['upgrades', 'Upgrades', 'upgrade']
]) {
  if (!DATA.authoringCategories.some(category => category.storageKey === storageKey)) DATA.authoringCategories.push({ id: `category_${storageKey}`, name, storageKey, entityType, sourceSystem: 'emberwake', layer: 'definition', runtimeCollection: '', persistence: 'catalog + JSON + MySQL', stableIdRequired: true, preserveUnknownFields: true, fourStringFieldsRequired: true, builderPreset: entityType });
  const sample = DATA[storageKey]?.[0] || {};
  for (const path of [...Object.keys(sample), 'description', 'tooltip', 'iconDirectory', 'modelDirectory']) if (!DATA.fieldDefinitions.some(field => field.category === storageKey && field.path === path)) {
    const value = sample[path]; const valueType = Array.isArray(value) ? 'array' : value && typeof value === 'object' ? 'object' : typeof value === 'number' ? 'number' : typeof value === 'boolean' ? 'boolean' : ['description', 'tooltip'].includes(path) ? 'text' : 'string';
    const label = path === 'iconDirectory' ? 'Specific Icon Image Path' : path === 'modelDirectory' ? 'Specific 3D Model Path' : path.replace(/([A-Z])/g, ' $1').replace(/^./, character => character.toUpperCase());
    DATA.fieldDefinitions.push({ id: `field_${storageKey}_${path}`, category: storageKey, path, label, group: ['description', 'tooltip', 'iconDirectory', 'modelDirectory'].includes(path) ? 'Assets & Presentation' : 'Definition', valueType, required: ['id', 'name', 'description', 'tooltip', 'iconDirectory', 'modelDirectory'].includes(path), defaultValue: valueType === 'array' ? [] : valueType === 'object' ? {} : valueType === 'number' ? 0 : valueType === 'boolean' ? false : '' });
  }
}
for(const [category,path,referenceCategory] of [['personalities','archetypeId','archetypes'],['personalities','cloneSourceId','personalities'],['aspirations','cloneSourceId','aspirations'],['guildHalls','guildId','guilds'],['guildHalls','buildingId','buildings'],['villageStores','villageId','villages'],['villageStores','npcId','npcs'],['reputationGoals','godId','gods'],['characterTags','characterId','characters']]){const field=DATA.fieldDefinitions.find(row=>row.category===category&&row.path===path);if(field)Object.assign(field,{valueType:'reference',referenceCategory,group:'Relationships'});}

const EDITABLE_CATALOG_KEYS = [
  'characters', 'vocations', 'skills', 'items', 'spells', 'monsters', 'dropTables', 'npcs', 'shops', 'houses', 'furniture', 'buildings', 'buildingTypes', 'placements', 'quests', 'zones', 'spawns', 'questGivers', 'mounts', 'tilePalette', 'levelTiles', 'gameRules',
  'integrationSystems', 'worlds', 'continents', 'villages', 'gameModes', 'entityFamilies', 'externalClasses', 'externalItems', 'externalBuildings', 'jobs', 'research', 'effectTypes', 'idAliases', 'relationships', 'formulaDefinitions', 'apiActions', 'externalTables', 'schemaFields', 'categorySchemas', 'externalRecords', 'tailoringRecipes', 'mageTowerFloors', 'runeDispensers', 'butlers',
  'authoringCategories', 'fieldDefinitions', 'runtimeVariables', 'runtimeSchemas', 'mutationTypes', 'conditionOperators', 'persistenceRules', 'eventTypes', 'specialObjectTypes', 'sourceRegistryCounts',
  'primitiveSkills', 'primitiveItems', 'primitiveRecipeGroups', 'primitiveNpcs', 'primitiveShops', 'primitiveQuests', 'primitiveSpells', 'primitivePrayers', 'primitiveEnemies', 'primitiveSpecialObjects', 'aegisSkills', 'aegisCreatures', 'statCategories', 'statDefinitions', 'currencyDefinitions', 'statDesignerSkills', 'encounters', 'mapDefinitions', 'mapNodes',
  'dialogueGlobals', 'gameplayInventory', 'inventorySlotSets', 'unityComponentTypes', 'sequenceDefinitions', 'sequenceNodes', 'sequenceEdges',
  'rtsUnitTypes', 'rtsFormations', 'rtsSpells', 'godPowers', 'rtsBuildingTypes', 'buildingComplexes', 'rtsResearch',
  'gods', 'pantheons', 'guilds', 'guildHalls', 'villageStores', 'realms', 'villagerClasses', 'gearLevelCurves', 'itemUpgradeServices', 'socialStats', 'socialEventDefinitions', 'archetypes', 'personalities', 'aspirations', 'fears', 'preferences', 'feelingRelationships', 'reputations', 'reputationGoals', 'leaderboardDefinitions', 'characterTags', 'natureDefinitions', 'natureZones', 'villageDistricts', 'villageServices', 'villageRoutes', 'progressionTracks', 'progressionNodes', 'progressionLoops', 'perks', 'upgrades', 'levelMaps', 'mapCivicRequirements', 'mapObjectInstances', 'mapEntityInstances'
];
for(const [storageKey,name,entityType] of [['fishingDropTables','Fishing Drop Tables','fishing-drop-table'],['smithingRecipes','Smithing Recipes','smithing-recipe'],['provenancePolicies','Authorship & Ownership Policies','provenance-policy'],['emojiPalette','Emoji Palette','emoji']]){if(!DATA.authoringCategories.some(category=>category.storageKey===storageKey))DATA.authoringCategories.push({id:`category_${storageKey}`,name,storageKey,entityType,sourceSystem:'emberwake',layer:'definition',persistence:'catalog + JSON + MySQL',stableIdRequired:true,preserveUnknownFields:true,fourStringFieldsRequired:true,builderPreset:entityType});if(!EDITABLE_CATALOG_KEYS.includes(storageKey))EDITABLE_CATALOG_KEYS.push(storageKey);const sample=DATA[storageKey]?.[0]||{};for(const path of [...Object.keys(sample),'description','tooltip','iconDirectory','modelDirectory'])if(!DATA.fieldDefinitions.some(field=>field.category===storageKey&&field.path===path)){const value=sample[path],valueType=Array.isArray(value)?'array':value&&typeof value==='object'?'object':typeof value==='number'?'number':typeof value==='boolean'?'boolean':['description','tooltip'].includes(path)?'text':'string';DATA.fieldDefinitions.push({id:`field_${storageKey}_${path}`,category:storageKey,path,label:path.replace(/([A-Z])/g,' $1').replace(/^./,letter=>letter.toUpperCase()),group:['description','tooltip','iconDirectory','modelDirectory'].includes(path)?'Assets & Presentation':'Definition',valueType,required:['id','name'].includes(path),defaultValue:valueType==='array'?[]:valueType==='object'?{}:valueType==='number'?0:valueType==='boolean'?false:''});}}
for(const [storageKey,name,entityType] of [['happinessContexts','Happiness Contexts','happiness-context'],['factions','Factions','faction'],['factionHappinessRules','Faction Happiness Rules','happiness-rule'],['characterAffections','Character Affections','affection']]){if(!DATA.authoringCategories.some(category=>category.storageKey===storageKey))DATA.authoringCategories.push({id:`category_${storageKey}`,name,storageKey,entityType,sourceSystem:'emberwake',layer:'definition',persistence:'catalog + JSON + MySQL',stableIdRequired:true,preserveUnknownFields:true,fourStringFieldsRequired:true,builderPreset:entityType});if(!EDITABLE_CATALOG_KEYS.includes(storageKey))EDITABLE_CATALOG_KEYS.push(storageKey);const sample=DATA[storageKey]?.[0]||{};for(const path of [...Object.keys(sample),'description','tooltip','iconDirectory','modelDirectory'])if(!DATA.fieldDefinitions.some(field=>field.category===storageKey&&field.path===path)){const value=sample[path],valueType=Array.isArray(value)?'array':value&&typeof value==='object'?'object':typeof value==='number'?'number':typeof value==='boolean'?'boolean':['description','tooltip'].includes(path)?'text':'string';DATA.fieldDefinitions.push({id:`field_${storageKey}_${path}`,category:storageKey,path,label:path.replace(/([A-Z])/g,' $1').replace(/^./,letter=>letter.toUpperCase()),group:'Definition',valueType,required:['id','name'].includes(path),defaultValue:valueType==='array'?[]:valueType==='object'?{}:valueType==='number'?0:valueType==='boolean'?false:''});}}
for(const [storageKey,name,entityType] of [['upgradeCurrencies','Upgrade Currencies','upgrade-currency'],['upgradeTierDefinitions','Upgrade Tiers','upgrade-tier'],['upgradeBranches','Upgrade Branches','upgrade-branch'],['branchingUpgradeNodes','Branching Upgrade Nodes','upgrade-node'],['scenes','Scenes','scene'],['sceneDoors','Scene Doors','scene-door'],['spawnerDefinitions','Spawner Definitions','spawner'],['simulatedPlayers','Simulated Players','simulated-player']]){if(!DATA.authoringCategories.some(category=>category.storageKey===storageKey))DATA.authoringCategories.push({id:`category_${storageKey}`,name,storageKey,entityType,sourceSystem:'ungodly_backend',layer:'definition',persistence:'catalog + JSON + MySQL',stableIdRequired:true,preserveUnknownFields:true,fourStringFieldsRequired:true,builderPreset:entityType});if(!EDITABLE_CATALOG_KEYS.includes(storageKey))EDITABLE_CATALOG_KEYS.push(storageKey);const sample=DATA[storageKey]?.[0]||{};for(const path of [...Object.keys(sample),'description','tooltip','iconDirectory','modelDirectory'])if(!DATA.fieldDefinitions.some(field=>field.category===storageKey&&field.path===path)){const value=sample[path],valueType=Array.isArray(value)?'array':value&&typeof value==='object'?'object':typeof value==='number'?'number':typeof value==='boolean'?'boolean':['description','tooltip'].includes(path)?'text':'string';DATA.fieldDefinitions.push({id:`field_${storageKey}_${path}`,category:storageKey,path,label:path.replace(/([A-Z])/g,' $1').replace(/^./,letter=>letter.toUpperCase()),group:'Definition',valueType,required:['id','name'].includes(path),defaultValue:valueType==='array'?[]:valueType==='object'?{}:valueType==='number'?0:valueType==='boolean'?false:''});}}
function normalizeEditableCatalog() {
  for (const map of DATA.levelMaps || []) if ((!Array.isArray(map.layers?.terrain) || !map.layers.terrain.length) && map.layers?.terrainRle?.runs) map.layers.terrain = decodeTerrainRle(map.layers.terrainRle, map.id);
  for (const key of EDITABLE_CATALOG_KEYS) for (const [index, row] of (DATA[key] || []).entries()) {
    if (!row || typeof row !== 'object') continue;
    const id = row.id || `${key}_${index + 1}`; const label = row.name || row.label || id;
    if (typeof row.iconDirectory !== 'string' || !row.iconDirectory.trim()) row.iconDirectory = `/assets/icons/${key}/${id}.png`;
    else if (row.iconDirectory.endsWith('/')) row.iconDirectory += `${id}.png`;
    if (typeof row.modelDirectory !== 'string' || !row.modelDirectory.trim()) row.modelDirectory = `/assets/models/${key}/${id}.glb`;
    else if (row.modelDirectory.endsWith('/')) row.modelDirectory += `${id}.glb`;
    if (typeof row.description !== 'string') row.description = `${label} data entry.`;
    if (typeof row.tooltip !== 'string') row.tooltip = row.description || `${label}.`;
    if (typeof row.authoredBy !== 'string') row.authoredBy = row.sourceSystem || 'emberwake_authoring';
    if (typeof row.authoredAt !== 'string') row.authoredAt = nowIso();
    if (typeof row.updatedBy !== 'string') row.updatedBy = row.authoredBy;
    if (typeof row.updatedAt !== 'string') row.updatedAt = row.authoredAt;
  }
  for (const monster of DATA.monsters || []) {
    if (!(DATA.dropTables || []).some(table => table.monsterId === monster.id)) DATA.dropTables.push({ id: `drop_${monster.id}`, name: `${monster.name} Drops`, monsterId: monster.id, rolls: 1, entries: [], iconDirectory: `/assets/icons/dropTables/drop_${monster.id}.png`, modelDirectory: `/assets/models/dropTables/drop_${monster.id}.glb`, description: `Selectable drop probabilities for ${monster.name}.`, tooltip: `${monster.name} kill reward table.` });
    const table=DATA.dropTables.find(row=>row.monsterId===monster.id);if(table&&!table.entries.some(entry=>['small_bones','sturdy_bones'].includes(entry.itemId)))table.entries.push({itemId:Number(monster.level||1)>=35?'sturdy_bones':'small_bones',tier:'always',chancePercent:100,min:1,max:Math.max(1,Math.floor(Number(monster.level||1)/40)+1)});if(table&&!table.entries.some(entry=>entry.itemId==='raw_game_meat')&&!/slime|skeleton|ghost|spirit|construct|elemental/i.test(`${monster.id} ${monster.name}`))table.entries.push({itemId:'raw_game_meat',tier:'common',chancePercent:35,min:1,max:Math.max(1,Math.ceil(Number(monster.level||1)/50))});if(table)table.scatterRadius=Number(table.scatterRadius??2);
  }
  for (const table of DATA.dropTables || []) {
    table.authoredBy = typeof table.authoredBy === 'string' ? table.authoredBy : 'emberwake_authoring'; table.authoredAt = typeof table.authoredAt === 'string' ? table.authoredAt : nowIso(); table.updatedBy = typeof table.updatedBy === 'string' ? table.updatedBy : table.authoredBy; table.updatedAt = typeof table.updatedAt === 'string' ? table.updatedAt : table.authoredAt;
    const chanceEntries = (table.entries || []).filter(entry => entry.tier !== 'always');
    const oldTotal = Number(table.nothingWeight || 0) + chanceEntries.reduce((sum, entry) => sum + Number(entry.weight || 0), 0);
    for (const entry of chanceEntries) if (!Number.isFinite(Number(entry.chancePercent))) entry.chancePercent = oldTotal ? Number((Number(entry.weight || 0) / oldTotal * 100).toFixed(2)) : 0;
    const chanceTotal=chanceEntries.reduce((sum,entry)=>sum+Number(entry.chancePercent||0),0);if(chanceTotal>100)for(const entry of chanceEntries)entry.chancePercent=Number((Number(entry.chancePercent||0)/chanceTotal*100).toFixed(2));
    table.nothingPercent = Math.max(0, Number((100 - chanceEntries.reduce((sum, entry) => sum + Number(entry.chancePercent || 0), 0)).toFixed(2)));
  }
}
normalizeEditableCatalog();
Object.assign(DATA.meta, { iconDirectory: DATA.meta.iconDirectory?.endsWith('/') ? `${DATA.meta.iconDirectory}emberwake.png` : DATA.meta.iconDirectory || '/assets/icons/project/emberwake.png', modelDirectory: DATA.meta.modelDirectory?.endsWith('/') ? `${DATA.meta.modelDirectory}emberwake.glb` : DATA.meta.modelDirectory || '/assets/models/project/emberwake.glb', tooltip: DATA.meta.tooltip || DATA.meta.description });

const DEFAULT_SAVE = {
  version: APP_VERSION,
  schemaVersion: 19,
  contentVersion: 19,
  revision: 0,
  serverRevision: null,
  projectId: PROJECT_ID,
  activeCharacterId: null,
  characters: deepClone(DATA.characters),
  catalog: null,
  world: {
    purchasedHouses: {}, globalFlags: {}, dispenserState: {}, firstPlayedAt: nowIso(), lastSavedAt: null,
    sharedContext: { godId: 'god_first_light', godName: 'Robin', realmId: 'realm_dawnreach', worldId: 'world_emberwake', continentId: 'continent_dawnreach', villageId: 'village_anchorage', villagerClassId: 'villager', creatureKind: 'ox', creatureName: 'Emberling', gameModeId: 'hero' }
  },
  integrations: Object.fromEntries(DATA.integrationSystems.filter(system => system.id !== 'emberwake').map(system => [system.id, { schemaVersion: system.schemaVersion, contentVersion: system.contentVersion, lastMigratedAt: null, data: {} }])),
  eventQueue: [],
  settings: { music: false, effects: true, autosave: true, reducedMotion: false }
};

const runtime = {
  save: loadSave(),
  character: null,
  monsters: [],
  ground: [],
  effects: [],
  temporaryWalls: [],
  temporaryFields: [],
  dynamicHoles: [],
  keys: new Set(),
  path: [],
  selectedProfileId: null,
  targetId: null,
  selectedInventoryIndex: -1,
  lastMoveAt: 0,
  lastBasicAttackAt: 0,
  lastMonsterTick: 0,
  lastRegenAt: 0,
  lastSaveAt: 0,
  lastFrame: performance.now(),
  lastPlaytimeTick: performance.now(),
  camera: { x: 0, y: 0 },
  cameraZoom: 1,
  mouse: { x: 0, y: 0 },
  trackedQuestId: null,
  activeDevTab: 'authoringHome',
  activeMapId: 'map_emberwake_overworld',
  devSearch: '',
  adminHierarchy: { godId:'god_first_light', realmId:'realm_dawnreach', worldId:'world_emberwake', villageId:'village_anchorage', villagerClassId:'villager', tagFilter:'' },
  devDropMonster: 'mob_scavenger_rat',
  combatStance: 'balanced',
  server: { status: 'offline', authenticated: false, user: null, sessionId: getServerSessionId(), access: 'local', role: 'player', capabilities: { canPlay:true, canAuthor:false, canModerate:false, canManageGuild:false, canManageSessions:false, canGrantModerator:false, canGrantGameMaster:false }, sessions: [] },
  toastTimer: null,
  storageWarningDismissed: false,
  modalOpen: false,
  pendingUse: null,
  dragPayload: null,
  minimapFloor: null,
  minimapBase: null,
  minimapZoom: 1,
  minimapView: { x: 0, y: 0, width: WORLD_W, height: WORLD_H },
  levelTileIndex: null,
  openBagWindows: new Map(),
  levelEditor: { centerX: 170, centerY: 151, z: 0, selectedTerrain: 'fortress_floor', color: '#65574c', walkable: true, wall: false, water: false, erase: false, layer: 'terrain', selectedStaticAssetId: 'build_tideglass', selectedEntityAssetId: 'npc_edda', validation: [] },
  tooltipTarget: null,
  worldReady: false
};

const el = Object.fromEntries([
  'worldCanvas', 'worldStage', 'minimap', 'profileScreen', 'profileCards', 'savedProfileCards', 'continueButton', 'profileButton', 'portrait', 'characterName', 'characterLine',
  'levelValue', 'hpText', 'hpBar', 'manaText', 'manaBar', 'zealText', 'zealBar', 'happinessText', 'happinessBar', 'xpText', 'xpBar', 'magicProgressText', 'magicProgressBar', 'goldText', 'capText', 'lightText', 'magicLevelText',
  'zoneName', 'floorName', 'zoneDanger', 'coordinates', 'nearbyList', 'trackedQuestName', 'trackedQuestDescription', 'trackedObjectives',
  'equipmentGrid', 'inventoryGrid', 'inventoryCount', 'spellBar', 'targetEmpty', 'targetInfo', 'targetIcon', 'targetName', 'targetLevel', 'targetTraits', 'targetBar',
  'interactionPrompt', 'interactionText', 'bossBanner', 'bossName', 'bossBar', 'modalRoot', 'devOverlay', 'devTabs', 'devContent', 'devSearch', 'groundItemLayer', 'bagWindowLayer',
  'devSummary', 'devAddRow', 'consoleLog', 'consoleForm', 'consoleInput', 'jsonFileInput', 'toast', 'gameTooltip', 'combatFloatLayer', 'combatMode', 'torchButton', 'mountButton',
  'minimapZoomOut', 'minimapReset', 'minimapZoomIn', 'hungerText', 'hungerBar', 'thirstText', 'thirstBar', 'restText', 'restBar', 'sharedContextBar', 'devBackButton', 'devConsoleHeader', 'leftRailToggle'
].map(id => [id, document.getElementById(id)]));

const ctx = el.worldCanvas.getContext('2d');
const miniCtx = el.minimap.getContext('2d');

function mergeRowsByStableId(current = [], incoming = []) {
  const rows = new Map((current || []).filter(row => row && typeof row === 'object').map((row, index) => [String(row.id ?? `row_${index}`), deepClone(row)]));
  for (const [index, row] of (incoming || []).entries()) {
    if (!row || typeof row !== 'object') continue;
    const key = String(row.id ?? `row_${index}`); rows.set(key, { ...(rows.get(key) || {}), ...deepClone(row) });
  }
  return [...rows.values()];
}

function deepMergeUnknown(base, incoming) {
  if (Array.isArray(incoming)) return deepClone(incoming);
  if (!incoming || typeof incoming !== 'object') return incoming === undefined ? (base === undefined ? undefined : deepClone(base)) : incoming;
  const output = base && typeof base === 'object' && !Array.isArray(base) ? deepClone(base) : {};
  for (const [key, value] of Object.entries(incoming)) output[key] = value && typeof value === 'object' && !Array.isArray(value) ? deepMergeUnknown(output[key], value) : deepClone(value);
  return output;
}

function loadSave() {
  try {
    const parsed = JSON.parse(localStorage.getItem(SAVE_KEY) || 'null');
    if (!parsed || parsed.projectId !== PROJECT_ID || !Array.isArray(parsed.characters)) return deepClone(DEFAULT_SAVE);
    const defaults = deepClone(DEFAULT_SAVE);
    const mergedCharacters = defaults.characters.map(template => {
      const saved = parsed.characters.find(character => character.id === template.id);
      return saved ? { ...template, ...saved, equipment: { ...template.equipment, ...(saved.equipment || {}) }, flags: { ...template.flags, ...(saved.flags || {}) }, quests: { ...template.quests, ...(saved.quests || {}) }, skills: { ...template.skills, ...(saved.skills || {}) }, itemInstances: { ...template.itemInstances, ...(saved.itemInstances || {}) }, containerContents: { ...template.containerContents, ...(saved.containerContents || {}) } } : template;
    });
    for(const saved of parsed.characters.filter(character=>!mergedCharacters.some(row=>row.id===character.id)))mergedCharacters.push(deepMergeUnknown(defaults.characters[0],saved));
    const starter = mergedCharacters.find(character => character.id === 'char_1');
    if (starter && Number(starter.level || 1) < 5) { starter.level = 5; starter.gold = Math.max(125, Number(starter.gold || 0)); starter.xpNext = Math.max(300, Number(starter.xpNext || 0)); starter.scenario = 'First Landing · Level Five'; }
    if (parsed.catalog && typeof parsed.catalog === 'object') {
      for (const [key, value] of Object.entries(parsed.catalog)) {
        if (key === 'projectMeta' && Array.isArray(value) && value[0]) DATA.meta = value[0];
        else if (Array.isArray(value) && key !== 'characters') DATA[key] = mergeRowsByStableId(DATA[key] || [], value);
      }
      normalizeEditableCatalog();
    }
    const tideglassDepot = DATA.placements.find(place => place.id === 'place_tideglass_depot_box');
    if (tideglassDepot) delete tideglassDepot.requiresHouseId;
    for (const spawn of DATA.spawns) {
      const seconds = Number(spawn.respawnSeconds || 15);
      spawn.respawnSeconds = parsed.version === APP_VERSION ? Math.max(45, seconds) : Math.max(45, Math.round(seconds * 3));
    }
    return {
      ...defaults, ...parsed, version: APP_VERSION, schemaVersion: defaults.schemaVersion, contentVersion: Math.max(Number(defaults.contentVersion || 1), Number(parsed.contentVersion || 1)),
      characters: mergedCharacters,
      world: deepMergeUnknown(defaults.world, parsed.world || {}),
      integrations: deepMergeUnknown(defaults.integrations, parsed.integrations || {}),
      settings: { ...defaults.settings, ...(parsed.settings || {}) },
      eventQueue: Array.isArray(parsed.eventQueue) ? parsed.eventQueue.slice(-100) : []
    };
  } catch (error) {
    console.warn('Save could not be loaded', error);
    return deepClone(DEFAULT_SAVE);
  }
}

function saveGame(showMessage = false) {
  const author=actorIdentity();for(const row of [...(DATA.buildings||[]),...(DATA.placements||[])])if(!row.authoredById){row.authoredById=author.id;row.authoredByName=author.name;row.adminCreated=isAdminMode();row.ownershipChain=[{at:nowIso(),fromId:null,toId:author.id,toName:author.name,reason:isAdminMode()?'admin authoring panel':'player creation'}];}
  if (runtime.character) {
    runtime.character.groundItems = deepClone(runtime.ground);
    runtime.character.dynamicHoles = deepClone(runtime.dynamicHoles);
    const index = runtime.save.characters.findIndex(character => character.id === runtime.character.id);
    if (index >= 0) runtime.save.characters[index] = deepClone(runtime.character);
  }
  runtime.save.version = APP_VERSION;
  runtime.save.schemaVersion = 19;
  runtime.save.contentVersion = 19;
  runtime.save.lastCharacterId = runtime.character?.id || runtime.save.lastCharacterId;
  runtime.save.world.lastSavedAt = nowIso();
  runtime.save.world.activeMapId = runtime.activeMapId;
  runtime.save.catalog = catalogSnapshot();
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(runtime.save));
    runtime.lastSaveAt = Date.now();
    if (showMessage) toast('Progress saved locally.');
  } catch (error) {
    if (!runtime.storageWarningDismissed) toast('Save failed: browser storage is full. Export JSON or sync MySQL from Developer Mode.', true, 12000, true);
  }
}

function catalogSnapshot() {
  const activeMap = activeLevelMap(); if (activeMap) activeMap.layers.terrain = DATA.levelTiles;
  const snapshot = Object.fromEntries(['projectMeta', ...EDITABLE_CATALOG_KEYS.filter(key => key !== 'characters')].map(key => [key, key === 'projectMeta' ? [DATA.meta] : DATA[key]]));
  snapshot.levelMaps = DATA.levelMaps.map(map => { const copy = deepClone(map), terrain = map.layers?.terrain || []; copy.layers = copy.layers || {}; copy.layers.terrainRle = encodeTerrainRle(terrain, map.width, map.height); copy.layers.terrainFormat = 'rle-v1'; delete copy.layers.terrain; delete copy.spatialIndex; return copy; });
  snapshot.levelTiles = [];
  return snapshot;
}

function resetRuntimeWorld() {
  runtime.monsters = [];
  runtime.ground = deepClone(runtime.character?.groundItems || []);
  runtime.effects = [];
  runtime.temporaryWalls = [];
  runtime.temporaryFields = [];
  runtime.dynamicHoles = deepClone(runtime.character?.dynamicHoles || []);
  runtime.targetId = null;
  runtime.path = [];
  runtime.selectedInventoryIndex = -1;
  for (const spawn of DATA.spawns) {
    for (let index = 0; index < spawn.count; index++) spawnMonster(spawn.monsterId, spawn.x + (index % 2), spawn.y + Math.floor(index / 2), spawn.z, { spawnId: spawn.id, homeX: spawn.x, homeY: spawn.y, respawnSeconds: spawn.respawnSeconds });
  }
  for (const floor of [-4, -3, -2, -1, 0]) {
    const count = floor === -4 || floor === 0 ? 3 : 5;
    for (let i = 0; i < count; i++) spawnMonster('mob_silk_tarantula', 58 + (i * 3 + Math.abs(floor)) % 14, 9 + (i * 4) % 14, floor, { spawnId: `silk_${floor}_${i}`, homeX: 58 + (i * 3) % 14, homeY: 9 + (i * 4) % 14, respawnSeconds: 60 });
  }
  spawnMonster('boss_brood_tyrant', 62, 10, -4, { spawnId: 'boss_bottom', homeX: 62, homeY: 10, respawnSeconds: 180, questTargetId: 'boss_brood_tyrant_bottom' });
  spawnMonster('boss_brood_tyrant', 66, 20, 0, { spawnId: 'boss_top', homeX: 66, homeY: 20, respawnSeconds: 180, questTargetId: 'boss_brood_tyrant_top' });
  if (runtime.character?.id === 'char_2' && !runtime.character.flags.haulBagLooted && !runtime.ground.some(pile => pile.id === 'ground_haul_bag')) {
    runtime.ground.push({ id: 'ground_haul_bag', type: 'bag', icon: '▣', name: 'Bag of Swords & Maces', x: 17, y: 48, z: -1, items: [{ id: 'bent_sword', qty: 4 }, { id: 'sun_mace', qty: 3 }] });
  }
}

function spawnMonster(monsterId, x, y, z, options = {}) {
  const template = byId(DATA.monsters, monsterId);
  if (!template) return null;
  const monster = {
    ...deepClone(template),
    entityId: uid('monster'),
    x, y, z,
    hp: template.hp,
    maxHp: template.hp,
    homeX: options.homeX ?? x,
    homeY: options.homeY ?? y,
    spawnId: options.spawnId || null,
    respawnSeconds: Math.max(Number(gameRule('world_rules').minimumRespawnSeconds ?? 45), Number(options.respawnSeconds || 45)),
    questTargetId: options.questTargetId || template.id,
    alive: true,
    deadAt: 0,
    lastAttackAt: 0,
    lastMoveAt: 0,
    splitDone: false,
    statuses: {}
  };
  runtime.monsters.push(monster);
  return monster;
}

function activeCharacter() { return runtime.character; }
function vocationOf(character = runtime.character) { return byId(DATA.vocations, character?.vocationId); }
function itemOf(id) { return byId(DATA.items, id); }
function spellOf(id) { return byId(DATA.spells, id); }
function npcVisibleToCharacter(npc, char = runtime.character) { return !npc?.requiresHouseId || Boolean(char?.houseIds?.includes(npc.requiresHouseId)); }
function syncCottageResidents(char = runtime.character) {
  if (!char?.houseIds?.includes('house_tideglass')) return;
  const edda = byId(DATA.npcs, 'npc_edda'); const tovin = byId(DATA.npcs, 'npc_tovin');
  if (edda) Object.assign(edda, { x: 20, y: 40, z: 0 });
  if (tovin) Object.assign(tovin, { x: 27, y: 39, z: 0 });
}
function questOf(id) { return byId(DATA.quests, id); }
function gameRule(id) { return byId(DATA.gameRules || [], id) || {}; }
function ensureSurvival(character = runtime.character) {
  if (!character) return { hunger: 100, thirst: 100, rest: 100, lastUpdatedAt: Date.now(), lastHungerDamageAt: 0, lastThirstDamageAt: 0 };
  character.survival = { hunger: 100, thirst: 100, rest: 100, lastUpdatedAt: Date.now(), lastHungerDamageAt: 0, lastThirstDamageAt: 0, ...(character.survival || {}) };
  for (const need of ['hunger', 'thirst', 'rest']) character.survival[need] = clamp(Number(character.survival[need] ?? 100), 0, 100);
  return character.survival;
}
function isHungry(character = runtime.character) { return ensureSurvival(character).hunger <= 0; }
function isTired(character = runtime.character) { return ensureSurvival(character).rest <= 0; }
function experienceAward(amount, character = runtime.character) {
  const multiplier = isTired(character) ? Number(gameRule('survival_rules').tiredXpMultiplier ?? .5) : 1;
  return Math.max(0, Math.floor(Number(amount || 0) * multiplier));
}
function magicPowerOf(character = runtime.character) { const vocation = vocationOf(character) || {}; const magicLevel = character?.skills?.magic?.level || 1; return magicLevel * Number(vocation.magicPowerPerMagicLevel || .5) + Number(character?.level || 1) * Number(vocation.magicPowerPerCharacterLevel || .25); }
function classRegen(resource,character=runtime.character){const vocation=vocationOf(character)||{};const base=Number(vocation[resource==='mana'?'manaRegenPerSecond':'healthRegenPerSecond']||.1);return base*(1+Math.max(0,Number(character?.level||1)-1)*Number(vocation.regenGrowthPerLevel||0));}
function potionRestore(item,character=runtime.character){const vocation=vocationOf(character)||{},tier=item.potionTier||'standard',key=tier==='great'?'greatPotionMultiplier':tier==='supreme'?'supremePotionMultiplier':'standardPotionMultiplier';return classRegen(item.potionResource||'health',character)*Number(vocation[key]||10);}
function monsterByEntity(id) { return runtime.monsters.find(monster => monster.entityId === id); }
function placementOnActiveMap(place){return !place?.mapId||place.mapId===runtime.activeMapId;}
function actorIdentity(character=runtime.character){const user=runtime.server?.user||{};return {id:String(user.id||character?.playerId||character?.id||'server'),name:user.username||character?.name||'Emberwake Server'};}
function makeProvenance(sourceType='server_spawn',sourceId='world',options={}){const actor=actorIdentity(options.character),adminCreated=Boolean(options.adminCreated??(sourceType==='admin_create'&&isAdminMode())),serverSource=sourceType.startsWith('server_')||sourceType==='creature_drop';const author={id:serverSource?'server':actor.id,name:serverSource?'Emberwake Server':actor.name,type:serverSource?'server':'player'};const owner=options.owner||actor;return {provenanceId:uid('origin'),authoredAt:nowIso(),authoredById:author.id,authoredByName:author.name,authoredByType:author.type,sourceType,sourceId,adminCreated,currentOwnerId:String(owner.id||actor.id),currentOwnerName:owner.name||actor.name,ownershipChain:[{at:nowIso(),fromId:null,toId:String(owner.id||actor.id),toName:owner.name||actor.name,reason:options.reason||sourceType}]};}
function transferProvenance(record,toCharacter,reason){if(!record)return record;const owner=actorIdentity(toCharacter),fromId=record.currentOwnerId;if(String(fromId)===String(owner.id))return record;record.currentOwnerId=owner.id;record.currentOwnerName=owner.name;record.ownershipChain=record.ownershipChain||[];record.ownershipChain.push({at:nowIso(),fromId,toId:owner.id,toName:owner.name,reason});return record;}
function provenanceText(holder){const records=holder?.provenanceRecords||(holder?.provenance?[holder.provenance]:[]);if(!records.length)return '\nOrigin: legacy server record';const admin=records.some(record=>record.adminCreated);const origins=[...new Set(records.map(record=>`${record.authoredByName||record.authoredById} (${record.sourceType})`))];const transfers=records.reduce((sum,record)=>sum+(record.ownershipChain?.length||0)-1,0);return `${admin?'\n🟥 ADMIN-CREATED':''}\nAuthor: ${origins.join(', ')}\nCurrent owner: ${records[0].currentOwnerName||records[0].currentOwnerId}\nOwnership transfers: ${Math.max(0,transfers)} · right-click for full chain`;}

function migrateItemProvenance(character){if(!character)return;const owner=actorIdentity(character),visit=stacks=>{for(const stack of stacks||[]){stack.instanceId=stack.instanceId||uid('item');if(!stack.provenanceRecords?.length)stack.provenanceRecords=[makeProvenance('server_legacy','migration',{character,owner,reason:'legacy item assigned to current owner'})];if(stack.instanceId&&character.containerContents?.[stack.instanceId])visit(character.containerContents[stack.instanceId]);}};visit(character.inventory);visit(character.depot);character.equipmentProvenance=character.equipmentProvenance||{};for(const [slot,itemId] of Object.entries(character.equipment||{}))if(itemId&&!character.equipmentProvenance[slot])character.equipmentProvenance[slot]={instanceId:uid('item'),provenanceRecords:[makeProvenance('server_legacy',`equipment_${slot}`,{character,owner,reason:'legacy equipment assigned to current owner'})]};}
function inventoryQuantity(itemId, character = runtime.character) {
  if (!character) return 0;
  const visit = (stacks, seen = new Set()) => (stacks || []).reduce((sum, stack) => {
    let amount = stack.id === itemId ? Number(stack.qty || 0) : 0;
    if (stack.instanceId && !seen.has(stack.instanceId)) { seen.add(stack.instanceId); amount += visit(character.containerContents?.[stack.instanceId], seen); }
    return sum + amount;
  }, 0);
  return visit(character.inventory);
}

function addItem(itemId, qty = 1, character = runtime.character, silent = false, originOptions = {}) {
  const item = itemOf(itemId);
  if (!item || qty <= 0 || !character) return false;
  const existing = item.stackable ? character.inventory.find(stack => stack.id === itemId) : null;
  const slotsNeeded = existing ? 0 : item.stackable ? 1 : qty;
  if (character.inventory.length + slotsNeeded > inventoryCapacity(character)) {
    toast(`Your ${itemOf(character.equipment.back)?.name || 'backpack'} is full.`, true);
    return false;
  }
  const provenance=originOptions.provenance?deepClone(originOptions.provenance):makeProvenance(originOptions.sourceType||'server_grant',originOptions.sourceId||itemId,{...originOptions,character,owner:actorIdentity(character)});transferProvenance(provenance,character,originOptions.reason||'received');
  if (existing) { existing.qty += qty;existing.provenanceRecords=existing.provenanceRecords||[];existing.provenanceRecords.push({...provenance,quantity:qty}); }
  else if (item.stackable) character.inventory.push({ id: itemId, qty,instanceId:uid('item'), provenanceRecords:[{...provenance,quantity:qty}], itemLevel:originOptions.itemLevel||null });
  else for (let index = 0; index < qty; index++) {
    const stack = { id: itemId, qty: 1,instanceId:uid('item'), provenanceRecords:[deepClone(provenance)], itemLevel:originOptions.itemLevel||null };
    if (item.type === 'container') ensureContainerInstance(stack, character);
    character.inventory.push(stack);
  }
  if (!silent) toast(`${item.icon || '◆'} ${qty} × ${item.name} added.`);
  refreshCollectObjectives(itemId);
  renderInventory();
  return true;
}

function removeItem(itemId, qty = 1, character = runtime.character) {
  if (!character) return false;
  if (inventoryQuantity(itemId, character) < qty) return false;
  let remaining = qty;
  const consume = (stacks, seen = new Set()) => {
    for (let index = stacks.length - 1; index >= 0 && remaining > 0; index--) {
      const stack = stacks[index];
      if (stack.instanceId && !seen.has(stack.instanceId)) { seen.add(stack.instanceId); consume(character.containerContents?.[stack.instanceId] || [], seen); }
      if (stack.id !== itemId || remaining <= 0) continue;
      const used = Math.min(remaining, Number(stack.qty || 0)); stack.qty -= used; remaining -= used;
      if (stack.qty <= 0) stacks.splice(index, 1);
    }
  };
  consume(character.inventory);
  refreshCollectObjectives(itemId);
  renderInventory();
  return true;
}

function inventoryCapacity(character = runtime.character) {
  return itemOf(character?.equipment?.back)?.capacity || 16;
}

function ensureContainerInstance(stack, character = runtime.character) {
  if (!stack || itemOf(stack.id)?.type !== 'container' || !character) return null;
  character.itemInstances = character.itemInstances || {};
  character.containerContents = character.containerContents || {};
  stack.instanceId = stack.instanceId || uid('container');
  character.itemInstances[stack.instanceId] = { definitionId: stack.id, createdAt: character.itemInstances[stack.instanceId]?.createdAt || nowIso(), ...(character.itemInstances[stack.instanceId] || {}) };
  character.containerContents[stack.instanceId] = character.containerContents[stack.instanceId] || [];
  return stack.instanceId;
}

function stackWeight(stack, character = runtime.character, seen = new Set()) {
  if (!stack) return 0;
  const own = Number(itemOf(stack.id)?.weight || 0) * Number(stack.qty || 1);
  if (!stack.instanceId || seen.has(stack.instanceId)) return own;
  seen.add(stack.instanceId);
  return own + (character?.containerContents?.[stack.instanceId] || []).reduce((sum, child) => sum + stackWeight(child, character, seen), 0);
}

function containerContainsInstance(containerId, soughtId, character = runtime.character, seen = new Set()) {
  if (!containerId || seen.has(containerId)) return false;
  seen.add(containerId);
  for (const child of character?.containerContents?.[containerId] || []) {
    if (child.instanceId === soughtId) return true;
    if (child.instanceId && containerContainsInstance(child.instanceId, soughtId, character, seen)) return true;
  }
  return false;
}

function inventoryWeight(character = runtime.character) {
  if (!character) return 0;
  const inventory = character.inventory.reduce((sum, stack) => sum + stackWeight(stack, character), 0);
  const equipment = Object.values(character.equipment || {}).reduce((sum, id) => sum + (itemOf(id)?.weight || 0), 0);
  return inventory + equipment;
}

function totalArmor(character = runtime.character) {
  if (!character) return 0;
  return Object.values(character.equipment || {}).reduce((sum, id) => sum + effectiveItemStat(id, 'armor', character), 0);
}

function totalDefense(character = runtime.character) {
  if (!character) return 0;
  return Object.values(character.equipment || {}).reduce((sum, id) => sum + effectiveItemStat(id, 'defense', character), 0);
}

function currentLightRadius() {
  const char = runtime.character;
  if (!char) return 2;
  let radius = 2;
  if (char.flags.torchLit) radius = Math.max(radius, 6);
  if (char.flags.lanternLit) radius = Math.max(radius, 9);
  if ((char.statuses.lightUntil || 0) > Date.now()) radius = Math.max(radius, char.statuses.lightRadius || 8);
  return radius;
}

function toast(message, error = false, duration = 2800, dismissible = false) {
  clearTimeout(runtime.toastTimer);
  el.toast.replaceChildren(document.createTextNode(message));
  if (dismissible) { const close = document.createElement('button'); close.type = 'button'; close.className = 'toast-dismiss'; close.textContent = 'DISMISS ×'; close.addEventListener('click', () => { runtime.storageWarningDismissed = true; el.toast.classList.add('hidden'); }); el.toast.appendChild(close); }
  el.toast.style.borderColor = error ? '#b94d48' : '#a68a4f';
  el.toast.classList.remove('hidden');
  runtime.toastTimer = setTimeout(() => el.toast.classList.add('hidden'), duration);
}

function showGameTooltip(text, clientX, clientY, target = null) {
  if (!text || !el.gameTooltip) return;
  runtime.tooltipTarget = target;
  el.gameTooltip.textContent = text;
  el.gameTooltip.classList.toggle('admin-origin',String(text).includes('ADMIN-CREATED'));
  el.gameTooltip.classList.remove('hidden');
  const margin = 9; const offset = 15;
  const rect = el.gameTooltip.getBoundingClientRect();
  el.gameTooltip.style.left = `${clamp(clientX + offset, margin, window.innerWidth - rect.width - margin)}px`;
  el.gameTooltip.style.top = `${clamp(clientY + offset, margin, window.innerHeight - rect.height - margin)}px`;
}

function hideGameTooltip(target = null) {
  if (target && runtime.tooltipTarget && runtime.tooltipTarget !== target) return;
  runtime.tooltipTarget = null;
  el.gameTooltip?.classList.add('hidden');
}

function elementTooltipText(target) {
  if (!target) return '';
  if (target.dataset.tooltip) return target.dataset.tooltip;
  const nativeTitle = target.getAttribute('title');
  if (nativeTitle) { target.dataset.tooltip = nativeTitle; target.removeAttribute('title'); return nativeTitle; }
  const label = target.getAttribute('aria-label') || target.getAttribute('placeholder') || target.textContent?.replace(/\s+/g, ' ').trim();
  return label && label.length > 1 ? label : '';
}

function bindUniversalTooltips() {
  const selector = '[data-tooltip], [title], button, [aria-label], input, select';
  document.addEventListener('pointerover', event => {
    const target = event.target.closest?.(selector);
    if (!target || target === el.worldCanvas || target === el.minimap) return;
    const text = elementTooltipText(target); if (text) showGameTooltip(text, event.clientX, event.clientY, target);
  });
  document.addEventListener('pointermove', event => {
    if (runtime.tooltipTarget instanceof Element && runtime.tooltipTarget !== el.worldCanvas && runtime.tooltipTarget !== el.minimap) showGameTooltip(elementTooltipText(runtime.tooltipTarget), event.clientX, event.clientY, runtime.tooltipTarget);
  });
  document.addEventListener('pointerout', event => {
    const target = event.target.closest?.(selector);
    if (target && !target.contains(event.relatedTarget)) hideGameTooltip(target);
  });
}

function handleWorldTooltip(event) {
  if (!runtime.character) return;
  const tile = worldFromScreen(event.clientX, event.clientY); const char = runtime.character;
  const monster = runtime.monsters.find(entry => entry.alive && entry.z === char.z && entry.x === tile.x && entry.y === tile.y);
  const npc = DATA.npcs.find(entry => entry.z === char.z && entry.x === tile.x && entry.y === tile.y);
  const pile = runtime.ground.find(entry => entry.z === char.z && entry.x === tile.x && entry.y === tile.y);
  const place = DATA.placements.find(entry => placementOnActiveMap(entry)&&entry.z === char.z && entry.x === tile.x && entry.y === tile.y);
  const building = char.z === 0 ? DATA.buildings.find(entry => tile.x >= entry.x && tile.x < entry.x + entry.width && tile.y >= entry.y && tile.y < entry.y + entry.height) : null;
  const tooltip = monster ? monsterTooltipText(monster) : npc ? npcTooltipText(npc) : pile ? pileTooltipText(pile) : place ? `${place.label || place.entityId}\n${place.tooltip || interactionLabel(place)}\nAuthor ${place.authoredByName||place.authoredById||'Emberwake Server'}${place.adminCreated?'\n🟥 ADMIN-CREATED':''}\nOwnership entries ${place.ownershipChain?.length||1}\nX ${place.x} · Y ${place.y} · Z ${place.z}` : building ? `${building.name}\n${building.tooltip || building.type}\nAuthor ${building.authoredByName||building.authoredById||'Emberwake Server'}${building.adminCreated?'\n🟥 ADMIN-CREATED':''}\nOwnership entries ${building.ownershipChain?.length||1}\n${building.width}×${building.height} tiles` : `${zoneAt(tile.x, tile.y, char.z)?.name || 'Uncharted'}\n${terrainAt(tile.x, tile.y, char.z).replaceAll('_', ' ')} · X ${tile.x}, Y ${tile.y}, Z ${char.z}`;
  showGameTooltip(tooltip, event.clientX, event.clientY, el.worldCanvas);
}

function handleMinimapTooltip(event) {
  if (!runtime.character) return;
  const point = minimapWorldPoint(event); const zone = zoneAt(point.x, point.y, runtime.character.z);
  const candidates = [
    ...DATA.npcs.filter(row => row.z === runtime.character.z && npcVisibleToCharacter(row)).map(row => ({ ...row, marker: `NPC · ${row.name}\n${row.role}` })),
    ...DATA.placements.filter(row => row.z === runtime.character.z && (row.type === 'hole' || row.type === 'stairs_down' || Number(row.targetZ) < row.z)).map(row => ({ ...row, marker: `DOWN · ${row.label || row.entityId}` })),
    ...DATA.spawns.filter(row => row.z === runtime.character.z).map(row => ({ ...row, marker: `HUNTING SPOT · ${byId(DATA.monsters, row.monsterId)?.name || row.monsterId}\nSuggested level ${byId(DATA.monsters, row.monsterId)?.level || '?'}` }))
  ];
  const marker = candidates.map(row => ({ row, distance: Math.hypot(row.x - point.x, row.y - point.y) })).sort((a, b) => a.distance - b.distance)[0];
  const markerText = marker?.distance <= Math.max(2, 5 / runtime.minimapZoom) ? `${marker.row.marker}\n` : '';
  showGameTooltip(`${markerText}${zone?.name || 'Uncharted'}\nX ${point.x} · Y ${point.y} · Z ${runtime.character.z}\nClick to auto-walk here. Drag the lower-right corner to resize.`, event.clientX, event.clientY, el.minimap);
}

function logConsole(message, type = '') {
  const line = document.createElement('p');
  line.className = type;
  line.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
  el.consoleLog.appendChild(line);
  el.consoleLog.scrollTop = el.consoleLog.scrollHeight;
}

function queueGameEvent(type, payload = {}) {
  runtime.save.eventQueue = Array.isArray(runtime.save.eventQueue) ? runtime.save.eventQueue : [];
  runtime.save.eventQueue.push({ eventId: uid('event'), type, characterId: runtime.character?.id || null, occurredAtMs: Date.now(), payload: deepClone(payload), createdAt: nowIso() });
  if (runtime.save.eventQueue.length > 100) runtime.save.eventQueue.splice(0, runtime.save.eventQueue.length - 100);
}

function playSfx(kind = 'ui') {
  if (!runtime.save?.settings?.effects) return;
  try {
    const AudioCtor = window.AudioContext || window.webkitAudioContext; if (!AudioCtor) return;
    runtime.audioContext = runtime.audioContext || new AudioCtor(); const audio = runtime.audioContext;
    const oscillator = audio.createOscillator(); const gain = audio.createGain();
    const profile = ({ ui: [430, .018], buy: [720, .04], sell: [520, .04], hit: [135, .035], heal: [860, .05], craft: [610, .06], portal: [330, .08], error: [110, .06] })[kind] || [430, .025];
    oscillator.type = kind === 'hit' || kind === 'error' ? 'square' : 'sine'; oscillator.frequency.value = profile[0]; gain.gain.value = .035;
    oscillator.connect(gain); gain.connect(audio.destination); oscillator.start(); gain.gain.exponentialRampToValueAtTime(.0001, audio.currentTime + profile[1]); oscillator.stop(audio.currentTime + profile[1]);
  } catch { /* Sound is optional when a browser blocks audio context creation. */ }
}

function ellipseContains(x, y, cx, cy, rx, ry) {
  return ((x - cx) ** 2) / (rx ** 2) + ((y - cy) ** 2) / (ry ** 2) <= 1;
}

function isExpandedRoad(x, y) {
  const horizontal = [
    [45, 67, 101], [57, 72, 174], [87, 94, 177], [104, 92, 225],
    [134, 49, 220], [154, 173, 221], [35, 166, 214]
  ].some(([roadY, fromX, toX]) => Math.abs(y - roadY) <= 1 && x >= fromX && x <= toX);
  const vertical = [
    [96, 44, 135], [132, 56, 105], [174, 48, 155], [211, 34, 155]
  ].some(([roadX, fromY, toY]) => Math.abs(x - roadX) <= 1 && y >= fromY && y <= toY);
  return horizontal || vertical;
}

function isSurfaceLand(x, y) {
  if (x < 0 || y < 0 || x >= WORLD_W || y >= WORLD_H) return false;
  const island1 = ellipseContains(x, y, 18, 46, 13, 10);
  const island2 = ellipseContains(x, y, 42, 45, 11, 10);
  const island3 = ellipseContains(x, y, 64, 45, 11, 9);
  const bridge1 = x >= 29 && x <= 32 && y >= 44 && y <= 46;
  const bridge2 = x >= 52 && x <= 55 && y >= 44 && y <= 46;
  const mainland = x >= 5 && x <= 92 && y >= 3 && y <= 30;
  const southRoad = x >= 15 && x <= 20 && y >= 28 && y <= 39;
  const greatContinent = ellipseContains(x, y, 155, 104, 103, 82)
    || ellipseContains(x, y, 205, 53, 47, 45)
    || ellipseContains(x, y, 102, 61, 39, 30)
    || ellipseContains(x, y, 214, 143, 43, 43);
  const coralChain = ellipseContains(x, y, 52, 136, 31, 24)
    || ellipseContains(x, y, 27, 125, 12, 9)
    || ellipseContains(x, y, 72, 151, 13, 10);
  const mainlandNeck = x >= 82 && x <= 117 && y >= 24 && y <= 61;
  const riverX = 134 + Math.sin(y / 11) * 5;
  const riverBridge = [57, 87, 104, 134].some(bridgeY => Math.abs(y - bridgeY) <= 2);
  const silverRiver = y >= 52 && y <= 168 && Math.abs(x - riverX) <= 2 && !riverBridge;
  const craterLake = ellipseContains(x, y, 82, 103, 9, 6) && !isExpandedRoad(x, y);
  const mirrorLake = ellipseContains(x, y, 151, 151, 12, 7) && !isExpandedRoad(x, y);
  const expandedLand = (greatContinent || coralChain || mainlandNeck) && !silverRiver && !craterLake && !mirrorLake;
  return island1 || island2 || island3 || bridge1 || bridge2 || mainland || southRoad || expandedLand || isExpandedRoad(x, y);
}

function caveComplexAt(x, y, z) {
  if (z >= 0) return null;
  const complexes = [
    ['underroot', 104, 60, 17, 14, 6], ['drowned', 132, 91, 18, 14, 5],
    ['emberdeep', 168, 108, 19, 15, 7], ['frostvault', 214, 43, 18, 15, 8],
    ['coralgrotto', 58, 144, 19, 15, 4], ['blackglass', 226, 166, 19, 16, 8]
  ];
  return complexes.find(([, cx, cy, rx, ry, depth]) => z >= -depth && ellipseContains(x, y, cx, cy, rx, ry))?.[0] || null;
}

function isCaveLand(x, y, z) {
  const worm = z === -1 && ellipseContains(x, y, 16, 48, 11, 10);
  const silk = z >= -4 && z <= -1 && x >= 55 && x <= 74 && y >= 5 && y <= 27;
  const frontierHollow = z === -1 && OVERWORLD_HOLLOWS.some(([, hx, hy]) => ellipseContains(x, y, hx, hy, 7, 6));
  return worm || silk || frontierHollow || Boolean(caveComplexAt(x, y, z));
}

function isInsideHouse(x, y, z, house = null) {
  if (z !== 0) return false;
  return DATA.houses.some(candidate => (!house || candidate.id === house.id) && x >= candidate.x && x < candidate.x + candidate.width && y >= candidate.y && y < candidate.y + candidate.height);
}

function rebuildLevelTileIndex() {
  runtime.levelTileIndex = new Map();
  for (const tile of DATA.levelTiles || []) runtime.levelTileIndex.set(`${tile.x},${tile.y},${tile.z}`, tile);
  runtime.minimapBase = null;
}

function levelTileAt(x, y, z) {
  if (!runtime.levelTileIndex) rebuildLevelTileIndex();
  return runtime.levelTileIndex.get(`${Math.round(x)},${Math.round(y)},${z}`) || null;
}

function terrainAt(x, y, z = runtime.character?.z || 0) {
  const edited = levelTileAt(x, y, z);
  if (edited) return edited.terrain;
  if (z < 0) {
    if (z >= -6 && z <= -1 && x >= 28 && x <= 36 && y >= 29 && y <= 39) return x === 28 || x === 36 || y === 29 || y === 39 ? 'stone_wall' : 'house_floor';
    if (!isCaveLand(x, y, z)) return 'void';
    const complex = caveComplexAt(x, y, z);
    if (complex === 'underroot') return 'root_cave';
    if (complex === 'drowned') return 'flooded_cave';
    if (complex === 'emberdeep') return 'volcanic_cave';
    if (complex === 'frostvault') return 'ice_cave';
    if (complex === 'coralgrotto') return 'coral_cave';
    if (complex === 'blackglass') return 'abyss_cave';
    if (x >= 55 && x <= 74 && y >= 5 && y <= 27) return 'silk_cave';
    return 'earth_cave';
  }
  if (!isSurfaceLand(x, y)) return 'water';
  if ((x >= 29 && x <= 32 || x >= 52 && x <= 55) && y >= 44 && y <= 46) return 'bridge';
  if (x >= 55 && x <= 71 && y >= 5 && y <= 26) return 'mountain_cave';
  if (x >= 15 && x <= 20 && y >= 28 && y <= 39) return 'road';
  if (isInsideHouse(x, y, z)) return 'house_floor';
  if (x >= 12 && x <= 25 && y >= 42 && y <= 50) return 'town';
  if (x >= 39 && x <= 45 && y >= 41 && y <= 47) return 'canopy_town';
  if (towns.some(town => x >= town.x - 8 && x <= town.x + 8 && y >= town.y - 8 && y <= town.y + 8)) return 'town';
  if (isExpandedRoad(x, y)) return 'road';
  if (x >= 72 && y <= 30) return 'desert';
  if (x >= 187 && y <= 65) return 'snow';
  if (x >= 188 && y >= 125) return 'nightglass';
  if (x >= 151 && x <= 210 && y >= 76 && y <= 128) return 'savanna';
  if (x >= 105 && x <= 151 && y >= 70 && y <= 106) return 'fen';
  if (x >= 145 && x <= 194 && y >= 27 && y <= 71) return 'highland';
  if (x >= 70 && x <= 116 && y >= 107 && y <= 153) return 'starfall';
  if (x <= 79 && y >= 111) return 'tropical';
  if (x >= 73 && x <= 118 && y >= 38 && y <= 77) return 'forest';
  return 'grass';
}

function isPassable(x, y, z = runtime.character?.z || 0, ignoreBridge = false) {
  const pathOverride = activeLevelMap?.()?.layers?.pathing?.find(row => row.x === x && row.y === y && Number(row.z || 0) === Number(z));
  if (pathOverride && pathOverride.walkable === false) return false;
  x = Math.round(x); y = Math.round(y);
  const edited = levelTileAt(x, y, z);
  if (edited && (!edited.walkable || edited.wall || edited.water)) return false;
  const terrain = terrainAt(x, y, z);
  if (['water', 'void', 'moat', 'lava', 'swamp_water', 'stone_wall'].includes(terrain)) return false;
  const char = runtime.character;
  if (!ignoreBridge && z === 0 && x === 53 && y >= 44 && y <= 46 && !char?.flags?.bridgeRepaired) return false;
  if (runtime.temporaryWalls.some(wall => wall.x === x && wall.y === y && wall.z === z && wall.expiresAt > Date.now())) return false;
  return true;
}

function zoneAt(x, y, z) {
  if (z >= -6 && z <= -1 && x >= 28 && x <= 36 && y >= 29 && y <= 39) return byId(DATA.zones, 'anchorage_harbor');
  if (z < 0 && x < 30) return byId(DATA.zones, 'wormburrow');
  if (x >= 55 && x <= 74 && y >= 5 && y <= 27 && z <= 0) return byId(DATA.zones, 'silkfall_depths');
  if (z < 0) {
    const caveZones = { underroot: 'underroot_deeps', drowned: 'drowned_catacombs', emberdeep: 'emberdeep_mines', frostvault: 'frostvault', coralgrotto: 'coral_grotto', blackglass: 'blackglass_abyss' };
    return byId(DATA.zones, caveZones[caveComplexAt(x, y, z)] || 'silkfall_depths');
  }
  if (z === 0 && x >= 24 && x <= 53 && y >= 4 && y <= 28) return byId(DATA.zones, 'grimfang_castle');
  if (z === 0 && x >= 153 && x <= 187 && y >= 135 && y <= 167) return byId(DATA.zones, 'orcrown_citadel');
  if (x >= 72 && y <= 30) return byId(DATA.zones, 'sunscour_market');
  if (ellipseContains(x, y, 18, 46, 13, 10)) {
    if (x >= 12 && x <= 25 && y >= 41 && y <= 50) return byId(DATA.zones, 'anchorage_harbor');
    return byId(DATA.zones, 'shoreward_green');
  }
  if (ellipseContains(x, y, 42, 45, 12, 10)) return byId(DATA.zones, 'iron_canopy');
  if (ellipseContains(x, y, 64, 45, 12, 10)) {
    if (x >= 63 && y >= 43 && y <= 49) return byId(DATA.zones, 'crucible_sanctum');
    return byId(DATA.zones, 'crucible_reach');
  }
  const town = towns.find(entry => x >= entry.x - 8 && x <= entry.x + 8 && y >= entry.y - 8 && y <= entry.y + 8);
  if (town) return byId(DATA.zones, town.zoneId);
  if (x >= 188 && y >= 125) return byId(DATA.zones, 'nightglass_waste');
  if (x >= 187 && y <= 65) return byId(DATA.zones, 'frostmarch');
  if (x >= 151 && x <= 210 && y >= 76 && y <= 128) return byId(DATA.zones, 'emberwild_savanna');
  if (x >= 105 && x <= 151 && y >= 70 && y <= 106) return byId(DATA.zones, 'mirewatch_fen');
  if (x >= 145 && x <= 194 && y >= 27 && y <= 71) return byId(DATA.zones, 'stoneheart_highlands');
  if (x >= 70 && x <= 116 && y >= 107 && y <= 153) return byId(DATA.zones, 'starfall_basin');
  if (x <= 79 && y >= 111) return byId(DATA.zones, 'coralreach_isles');
  if (x >= 73 && x <= 118 && y >= 38 && y <= 77) return byId(DATA.zones, 'greenhollow_vale');
  if (y <= 31) return byId(DATA.zones, 'northroad');
  if (Math.abs(x - (134 + Math.sin(y / 11) * 5)) <= 7) return byId(DATA.zones, 'silverriver');
  return byId(DATA.zones, 'northroad');
}

function resizeCanvases() {
  const rect = el.worldCanvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const width = Math.max(1, Math.floor(rect.width * dpr));
  const height = Math.max(1, Math.floor(rect.height * dpr));
  if (el.worldCanvas.width !== width || el.worldCanvas.height !== height) {
    el.worldCanvas.width = width;
    el.worldCanvas.height = height;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  runtime.viewport = { width: rect.width, height: rect.height, dpr };
}

function cameraOffset() {
  const width = runtime.viewport?.width || 800;
  const height = runtime.viewport?.height || 600;
  return { x: width / 2 - runtime.camera.x * TILE - TILE / 2, y: height / 2 - runtime.camera.y * TILE - TILE / 2 };
}

function screenFromWorld(x, y) {
  const offset = cameraOffset();
  const width = runtime.viewport?.width || 800; const height = runtime.viewport?.height || 600; const zoom = runtime.cameraZoom || 1;
  const rawX = x * TILE + offset.x; const rawY = y * TILE + offset.y;
  return { x: width / 2 + (rawX - width / 2) * zoom, y: height / 2 + (rawY - height / 2) * zoom };
}

function worldFromScreen(clientX, clientY) {
  const rect = el.worldCanvas.getBoundingClientRect();
  const offset = cameraOffset();
  const zoom = runtime.cameraZoom || 1; const centerX = rect.width / 2; const centerY = rect.height / 2;
  const logicalX = centerX + (clientX - rect.left - centerX) / zoom; const logicalY = centerY + (clientY - rect.top - centerY) / zoom;
  return { x: Math.floor((logicalX - offset.x) / TILE), y: Math.floor((logicalY - offset.y) / TILE) };
}

function drawWorld(time) {
  if (!runtime.character || !runtime.worldReady) return;
  resizeCanvases();
  const char = runtime.character;
  runtime.camera.x += (char.x - runtime.camera.x) * .18;
  runtime.camera.y += (char.y - runtime.camera.y) * .18;
  const width = runtime.viewport.width;
  const height = runtime.viewport.height;
  ctx.clearRect(0, 0, width, height);
  const offset = cameraOffset();
  const zoom = runtime.cameraZoom || 1;
  const logicalLeft = width / 2 - width / (2 * zoom); const logicalRight = width / 2 + width / (2 * zoom);
  const logicalTop = height / 2 - height / (2 * zoom); const logicalBottom = height / 2 + height / (2 * zoom);
  const minX = Math.max(0, Math.floor((logicalLeft - offset.x) / TILE) - 1);
  const maxX = Math.min(WORLD_W - 1, Math.ceil((logicalRight - offset.x) / TILE) + 1);
  const minY = Math.max(0, Math.floor((logicalTop - offset.y) / TILE) - 1);
  const maxY = Math.min(WORLD_H - 1, Math.ceil((logicalBottom - offset.y) / TILE) + 1);

  ctx.save(); ctx.translate(width / 2, height / 2); ctx.scale(zoom, zoom); ctx.translate(-width / 2, -height / 2);

  for (let y = minY; y <= maxY; y++) {
    for (let x = minX; x <= maxX; x++) drawTile(x, y, char.z, offset, time);
  }
  drawBuildings(offset);
  drawPlacements(offset, time);
  drawGround(offset);
  drawNpcs(offset);
  drawMonsters(offset, time);
  drawPlayer(offset, time);
  drawEffects(offset, time);
  drawDarkness();
  ctx.restore();
  drawMinimap();
  renderGroundItemLayer(time);
}

function tileNoise(x, y, z) {
  const value = Math.sin(x * 12.9898 + y * 78.233 + z * 31.117) * 43758.5453;
  return value - Math.floor(value);
}

function drawTile(x, y, z, offset, time) {
  const terrain = terrainAt(x, y, z);
  const edited = levelTileAt(x, y, z);
  const sx = x * TILE + offset.x;
  const sy = y * TILE + offset.y;
  const noise = tileNoise(x, y, z);
  const colors = {
    water: noise > .5 ? '#153948' : '#123340',
    void: '#030706',
    grass: noise > .65 ? '#385f3f' : noise < .18 ? '#2d5138' : '#345a3c',
    town: noise > .5 ? '#536b4e' : '#4b6449',
    canopy_town: '#3c5a3e',
    bridge: noise > .5 ? '#8d6a42' : '#795b39',
    desert: noise > .55 ? '#ae8050' : '#bb8b56',
    mountain_cave: noise > .55 ? '#403c37' : '#363431',
    road: noise > .5 ? '#8f7958' : '#837052',
    house_floor: noise > .5 ? '#816d4e' : '#746047',
    earth_cave: noise > .5 ? '#594536' : '#4c3b30',
    silk_cave: noise > .5 ? '#493b46' : '#3c323c',
    forest: noise > .55 ? '#28583b' : '#214d34',
    fen: noise > .55 ? '#3b5d4f' : '#304f45',
    highland: noise > .55 ? '#67675c' : '#585b51',
    snow: noise > .55 ? '#b9d3d4' : '#a6c3c8',
    savanna: noise > .55 ? '#8d5d3c' : '#79513a',
    starfall: noise > .55 ? '#475b6b' : '#3d5061',
    tropical: noise > .55 ? '#39745b' : '#30674f',
    nightglass: noise > .55 ? '#352d45' : '#2b263a',
    root_cave: noise > .5 ? '#3d4630' : '#303b29',
    flooded_cave: noise > .5 ? '#304b4d' : '#263e43',
    volcanic_cave: noise > .5 ? '#58352b' : '#452a25',
    ice_cave: noise > .5 ? '#426573' : '#354f5d',
    coral_cave: noise > .5 ? '#5d444b' : '#49373f',
    abyss_cave: noise > .5 ? '#30263d' : '#251d31'
  };
  const paletteTile = byId(DATA.tilePalette || [], terrain);
  ctx.fillStyle = edited?.color || paletteTile?.color || colors[terrain] || '#263b33';
  ctx.fillRect(sx, sy, TILE + 1, TILE + 1);
  ctx.strokeStyle = terrain === 'water' ? '#20506444' : '#0a120f20';
  ctx.lineWidth = 1;
  ctx.strokeRect(sx + .5, sy + .5, TILE, TILE);
  if (terrain === 'water') {
    ctx.strokeStyle = '#62a0ae35';
    ctx.beginPath();
    ctx.moveTo(sx + 6 + noise * 7, sy + 12 + Math.sin(time / 500 + x) * 2);
    ctx.quadraticCurveTo(sx + 18, sy + 8, sx + 31, sy + 12);
    ctx.stroke();
  } else if (terrain === 'grass' && noise > .74) {
    ctx.strokeStyle = '#79a15b77';
    ctx.beginPath(); ctx.moveTo(sx + 10, sy + 29); ctx.lineTo(sx + 13, sy + 21); ctx.lineTo(sx + 15, sy + 29); ctx.stroke();
  } else if (terrain.includes('cave') && noise > .78) {
    ctx.fillStyle = '#b7a0a322';
    ctx.beginPath(); ctx.arc(sx + 13, sy + 14, 3, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(sx + 29, sy + 28, 2, 0, Math.PI * 2); ctx.fill();
  } else if (terrain === 'desert' && noise > .75) {
    ctx.fillStyle = '#e0b67533'; ctx.fillRect(sx + 8, sy + 13, 2, 2); ctx.fillRect(sx + 28, sy + 29, 2, 2);
  } else if (terrain === 'snow' && noise > .62) {
    ctx.fillStyle = '#e9f6f588'; ctx.beginPath(); ctx.arc(sx + 12, sy + 11, 2, 0, Math.PI * 2); ctx.arc(sx + 28, sy + 25, 1.5, 0, Math.PI * 2); ctx.fill();
  } else if (terrain === 'fen' && noise > .66) {
    ctx.strokeStyle = '#7da88588'; ctx.beginPath(); ctx.moveTo(sx + 12, sy + 31); ctx.lineTo(sx + 11, sy + 18); ctx.moveTo(sx + 26, sy + 30); ctx.lineTo(sx + 29, sy + 16); ctx.stroke();
  } else if (terrain === 'starfall' && noise > .7) {
    ctx.fillStyle = '#9e87d466'; ctx.beginPath(); ctx.moveTo(sx + 17, sy + 9); ctx.lineTo(sx + 21, sy + 21); ctx.lineTo(sx + 13, sy + 21); ctx.closePath(); ctx.fill();
  } else if (terrain === 'nightglass' && noise > .65) {
    ctx.fillStyle = '#9e79c155'; ctx.beginPath(); ctx.moveTo(sx + 22, sy + 7); ctx.lineTo(sx + 26, sy + 29); ctx.lineTo(sx + 17, sy + 29); ctx.closePath(); ctx.fill();
  }
  if (edited?.wall) {
    ctx.fillStyle = '#171817aa'; ctx.fillRect(sx + 3, sy + 3, TILE - 6, TILE - 6);
    ctx.strokeStyle = edited.color || '#777'; ctx.lineWidth = 3; ctx.strokeRect(sx + 4.5, sy + 4.5, TILE - 9, TILE - 9);
    ctx.strokeStyle = '#a89c8955'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(sx + 4, sy + TILE / 2); ctx.lineTo(sx + TILE - 4, sy + TILE / 2); ctx.moveTo(sx + TILE / 2, sy + 4); ctx.lineTo(sx + TILE / 2, sy + TILE - 4); ctx.stroke();
  }
  if (z === 0 && x === 53 && y >= 44 && y <= 46 && !runtime.character.flags.bridgeRepaired) {
    ctx.fillStyle = '#122a35'; ctx.fillRect(sx, sy, TILE, TILE);
    ctx.strokeStyle = '#a2744b'; ctx.lineWidth = 5;
    ctx.beginPath(); ctx.moveTo(sx + 3, sy + 8); ctx.lineTo(sx + 18, sy + 20); ctx.moveTo(sx + 37, sy + 31); ctx.lineTo(sx + 24, sy + 21); ctx.stroke();
  }
}

function drawBuildings(offset) {
  if (runtime.character.z !== 0) return;
  for (const building of DATA.buildings) {
    const sx = building.x * TILE + offset.x;
    const sy = building.y * TILE + offset.y;
    const width = building.width * TILE;
    const height = building.height * TILE;
    if (sx + width < 0 || sy + height < 0 || sx > runtime.viewport.width || sy > runtime.viewport.height) continue;
    const buildingType = byId(DATA.buildingTypes || [], building.type) || byId(DATA.buildingTypes || [], 'hall') || {};
    const [wall, roof, trim] = [buildingType.wallColor || '#403d3a', buildingType.roofColor || '#777268', buildingType.trimColor || '#d0b56c'];
    ctx.fillStyle = '#00000066'; ctx.fillRect(sx + 8, sy + 10, width - 4, height - 3);
    ctx.fillStyle = wall; ctx.fillRect(sx + 4, sy + 9, width - 8, height - 13);
    ctx.fillStyle = roof; ctx.beginPath(); ctx.moveTo(sx + 1, sy + 12); ctx.lineTo(sx + width / 2, sy + 1); ctx.lineTo(sx + width - 1, sy + 12); ctx.lineTo(sx + width - 6, sy + 20); ctx.lineTo(sx + 6, sy + 20); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = trim; ctx.lineWidth = 2; ctx.stroke();
    ctx.strokeStyle = '#1a1714'; ctx.lineWidth = 4; ctx.strokeRect(sx + 4, sy + 9, width - 8, height - 13);
    ctx.fillStyle = '#8dc4c4';
    ctx.fillRect(sx + 13, sy + height - 24, 10, 8); ctx.fillRect(sx + width - 23, sy + height - 24, 10, 8);
    ctx.strokeStyle = '#e5c984'; ctx.lineWidth = 1; ctx.strokeRect(sx + 13, sy + height - 24, 10, 8); ctx.strokeRect(sx + width - 23, sy + height - 24, 10, 8);
    ctx.fillStyle = '#2b211b'; ctx.fillRect(sx + width / 2 - 7, sy + height - 24, 14, 24);
    ctx.fillStyle = trim; ctx.fillRect(sx + width / 2 + 3, sy + height - 13, 2, 2);
    ctx.fillStyle = '#f4e0af';
    ctx.font = '700 8px Inter';
    ctx.textAlign = 'center';
    ctx.fillText(building.name.toUpperCase(), sx + width / 2, sy + 17, width - 16);
  }
}

function drawPlacements(offset, time) {
  const char = runtime.character;
  const placements = DATA.placements.filter(place => placementOnActiveMap(place)&&place.z === char.z && (!place.profileId || place.profileId === char.id));
  for (const place of placements) {
    if (place.id === 'place_bag_weapons') continue;
    const sx = place.x * TILE + offset.x + TILE / 2;
    const sy = place.y * TILE + offset.y + TILE / 2;
    let icon = '•';
    if (place.type === 'rope_spot' || place.type === 'hole') icon = '◉';
    if (place.type.includes('stairs')) icon = place.type === 'stairs_up' ? '▴' : '▾';
    if (place.type === 'harvest') icon = '♈';
    if (place.entityId === 'millstone') icon = '◉';
    if (place.entityId === 'bread_oven') icon = '♨';
    if (place.type === 'training') icon = '♟';
    if (place.entityId === 'dead_tree') icon = '♧';
    if (place.type === 'bridge') icon = runtime.character.flags.bridgeRepaired ? '═' : '≠';
    if (place.type === 'shrine') icon = '✦';
    if (place.type === 'injured_npc') icon = '♙';
    if (place.type === 'readable') icon = '▤';
    if (place.type === 'door' || place.type === 'house_door') icon = '▥';
    if (place.type === 'relic') icon = '✧';
    if (place.type === 'landmark') icon = '◆';
    if (place.type === 'habitat') icon = '⌂';
    if (place.type === 'infrastructure') icon = '⚙';
    if (place.type === 'depot') icon = '▣';
    if (place.type === 'well') icon = '♒';
    if (place.type === 'rest') icon = '▬';
    if (place.type === 'resource') icon = place.skillId === 'mining' ? '⛏️' : '🌳';
    if (place.type === 'fishing') icon = '🎣';
    if (place.type === 'smithing_station') icon = '🔨';
    ctx.fillStyle = '#07100dbb'; ctx.beginPath(); ctx.arc(sx, sy, 15, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#d1aa5a77'; ctx.stroke();
    ctx.fillStyle = '#efd78d'; ctx.font = '18px serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(icon, sx, sy + Math.sin(time / 350 + place.x) * 1.2);
  }
  for (const wall of runtime.temporaryWalls.filter(wall => wall.z === char.z && wall.expiresAt > Date.now())) {
    const sx = wall.x * TILE + offset.x; const sy = wall.y * TILE + offset.y;
    ctx.fillStyle = '#476e3d'; ctx.fillRect(sx + 5, sy + 2, TILE - 10, TILE - 4);
    ctx.fillStyle = '#7eaa61'; ctx.font = '24px serif'; ctx.fillText('♧', sx + TILE / 2, sy + TILE / 2);
  }
  for (const field of runtime.temporaryFields.filter(field => field.z === char.z && field.expiresAt > Date.now())) {
    const sx = field.x * TILE + offset.x; const sy = field.y * TILE + offset.y;
    ctx.fillStyle = field.effect === 'poison' ? '#6f944a99' : '#db642e99'; ctx.beginPath(); ctx.arc(sx + TILE / 2, sy + TILE / 2, TILE * .34, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = field.effect === 'poison' ? '#a6ca72' : '#ffb04e'; ctx.font = '22px serif'; ctx.fillText(field.effect === 'poison' ? '☣' : '♨', sx + TILE / 2, sy + TILE / 2);
  }
  for (const hole of runtime.dynamicHoles.filter(hole => hole.z === char.z)) {
    const sx = hole.x * TILE + offset.x + TILE / 2; const sy = hole.y * TILE + offset.y + TILE / 2;
    ctx.fillStyle = '#070908'; ctx.beginPath(); ctx.ellipse(sx, sy, 14, 9, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#8e7654'; ctx.stroke();
  }
  for (const furniture of char.furniturePlacements.filter(entry => entry.z === char.z)) {
    const item = itemOf(furniture.itemId); if (!item) continue;
    const sx = furniture.x * TILE + offset.x + TILE / 2; const sy = furniture.y * TILE + offset.y + TILE / 2;
    ctx.fillStyle = item.color || '#ddc18a'; ctx.font = '24px serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(item.icon, sx, sy);
  }
  for (const instance of DATA.mapObjectInstances.filter(row => row.mapId === runtime.activeMapId && Number(row.position.z || 0) === char.z)) { const asset = byId(DATA.buildings, instance.assetId); const sx = instance.position.x * TILE + offset.x, sy = instance.position.y * TILE + offset.y, width = Number(instance.footprint?.width || 1) * TILE, height = Number(instance.footprint?.height || 1) * TILE; ctx.fillStyle = '#725f45cc'; ctx.fillRect(sx + 2, sy + 2, width - 4, height - 4); ctx.strokeStyle = '#d9a43f'; ctx.strokeRect(sx + 2, sy + 2, width - 4, height - 4); ctx.fillStyle = '#f0d28b'; ctx.font = '12px serif'; ctx.fillText(asset?.icon || '▦', sx + width / 2, sy + height / 2); }
  for (const instance of DATA.mapEntityInstances.filter(row => row.mapId === runtime.activeMapId && Number(row.position.z || 0) === char.z)) { const asset = byId(DATA.npcs, instance.assetId) || byId(DATA.monsters, instance.assetId); const sx = instance.position.x * TILE + offset.x + TILE / 2, sy = instance.position.y * TILE + offset.y + TILE / 2; ctx.fillStyle = instance.type === 'monster' ? '#d76b5e' : '#72c9ad'; ctx.font = '22px serif'; ctx.fillText(asset?.icon || '●', sx, sy); }
}

function drawGround(offset) {
  for (const pile of runtime.ground.filter(entry => entry.z === runtime.character.z)) {
    const sx = pile.x * TILE + offset.x + TILE / 2; const sy = pile.y * TILE + offset.y + TILE / 2;
    ctx.fillStyle = '#0c100dcc'; ctx.beginPath(); ctx.ellipse(sx, sy + 10, 14, 6, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = pile.color || '#e5c56d'; ctx.font = '21px serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(pile.icon || '◆', sx, sy);
  }
}

function renderGroundItemLayer(time = performance.now()) {
  if (!runtime.character || time - (runtime.lastGroundLayerAt || 0) < 90) return;
  runtime.lastGroundLayerAt = time;
  const piles = runtime.ground.filter(entry => entry.z === runtime.character.z);
  el.groundItemLayer.innerHTML = piles.map(pile => {
    const point = screenFromWorld(pile.x, pile.y); const item = pile.itemId ? itemOf(pile.itemId) : null;
    return `<button draggable="true" class="ground-item-drag ${pile.type === 'bag' ? 'bag' : ''}" data-ground-id="${pile.id}" style="left:${point.x + TILE / 2}px;top:${point.y + TILE / 2}px;color:${pile.color || item?.color || '#e5c56d'}" data-tooltip="${escapeHtml(pileTooltipText(pile))}">${pile.icon || item?.icon || '◆'}${pile.qty > 1 ? `<small>${pile.qty}</small>` : ''}</button>`;
  }).join('');
  el.groundItemLayer.querySelectorAll('[data-ground-id]').forEach(button => {
    button.addEventListener('dragstart', event => startItemDrag(event, { source: 'ground', groundId: button.dataset.groundId, qty: event.shiftKey ? 1 : null }));
    button.addEventListener('dblclick', () => { const pile = runtime.ground.find(entry => entry.id === button.dataset.groundId); if (pile) lootGround(pile); });
  });
}

function drawNpcs(offset) {
  if (runtime.character.z !== 0) return;
  for (const npc of DATA.npcs) {
    const sx = npc.x * TILE + offset.x + TILE / 2; const sy = npc.y * TILE + offset.y + TILE / 2;
    if (sx < -40 || sy < -40 || sx > runtime.viewport.width + 40 || sy > runtime.viewport.height + 40) continue;
    ctx.fillStyle = '#11251f'; ctx.beginPath(); ctx.arc(sx, sy, 15, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#e0bc6877'; ctx.stroke();
    ctx.fillStyle = '#f4e0aa'; ctx.font = '20px serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(npc.icon, sx, sy);
    ctx.font = '700 8px Inter'; ctx.fillStyle = '#f2e7ce'; ctx.fillText(npc.name, sx, sy - 23);
    if (npc.quests.some(id => runtime.character.quests[id]?.status === 'active' || runtime.character.quests[id]?.status === 'available')) {
      ctx.fillStyle = npc.quests.some(id => questReady(id)) ? '#65d990' : '#f1c65f';
      ctx.font = '800 15px Inter'; ctx.fillText(npc.quests.some(id => questReady(id)) ? '?' : '!', sx + 13, sy - 13);
    }
  }
}

function drawMonsters(offset, time) {
  for (const monster of runtime.monsters.filter(entry => entry.z === runtime.character.z && entry.alive)) {
    const sx = monster.x * TILE + offset.x + TILE / 2; const sy = monster.y * TILE + offset.y + TILE / 2;
    if (sx < -40 || sy < -40 || sx > runtime.viewport.width + 40 || sy > runtime.viewport.height + 40) continue;
    const targeted = monster.entityId === runtime.targetId;
    if (targeted) {
      ctx.strokeStyle = '#f2c665'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(sx, sy + 2, 18 + Math.sin(time / 130) * 2, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.fillStyle = '#08100dc9'; ctx.beginPath(); ctx.ellipse(sx, sy + 12, 15, 6, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = monster.color || '#ddd'; ctx.font = `${monster.boss ? 30 : 23}px serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(monster.icon, sx, sy + Math.sin(time / 300 + monster.x) * 1.5);
    if (monster.hp < monster.maxHp || targeted || monster.boss) {
      ctx.fillStyle = '#1b0908'; ctx.fillRect(sx - 16, sy - 22, 32, 4);
      ctx.fillStyle = monster.boss ? '#f05a4f' : '#d96b53'; ctx.fillRect(sx - 16, sy - 22, 32 * clamp(monster.hp / monster.maxHp, 0, 1), 4);
    }
  }
}

function drawPlayer(offset, time) {
  const char = runtime.character;
  const vocation = vocationOf(char);
  const sx = char.x * TILE + offset.x + TILE / 2; const sy = char.y * TILE + offset.y + TILE / 2;
  if (char.statuses.shieldUntil > Date.now()) {
    ctx.strokeStyle = char.vocationId === 'priest' ? '#f4dc7f' : '#6ec6e1'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(sx, sy, 20 + Math.sin(time / 160) * 2, 0, Math.PI * 2); ctx.stroke();
  }
  if (char.flags.siegeMode) {
    ctx.strokeStyle = '#e68050'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(sx - 20, sy + 18); ctx.lineTo(sx - 11, sy + 7); ctx.moveTo(sx + 20, sy + 18); ctx.lineTo(sx + 11, sy + 7); ctx.stroke();
  }
  if (char.mounted) {
    ctx.fillStyle = '#111b17'; ctx.beginPath(); ctx.ellipse(sx, sy + 11, 19, 8, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#d7a75b'; ctx.font = '29px serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('♞', sx, sy + 5);
  }
  if (char.flags.sneaking && !char.flags.unconscious) {
    ctx.fillStyle = '#77b59a22'; ctx.beginPath(); ctx.ellipse(sx, sy + 12, 20, 9, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#83c7a5'; ctx.setLineDash([3, 3]); ctx.stroke(); ctx.setLineDash([]);
  }
  ctx.fillStyle = char.flags.cannonPowered ? '#ff8d58' : vocation?.color || '#fff';
  ctx.font = `${char.mounted ? 22 : 27}px serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.save();
  if (char.flags.unconscious) { ctx.translate(sx, sy); ctx.rotate(Math.PI / 2); ctx.translate(-sx, -sy); }
  ctx.shadowBlur = 8; ctx.shadowColor = vocation?.color || '#fff'; ctx.fillText(vocation?.icon || '♙', sx, sy - (char.mounted ? 7 : 0)); ctx.shadowBlur = 0;
  ctx.restore();
  ctx.fillStyle = '#fff1cf'; ctx.font = '800 9px Inter'; ctx.fillText(char.name, sx, sy - 27);
  if (char.flags.unconscious) { ctx.fillStyle = '#e1a06c'; ctx.font = '800 7px Inter'; ctx.fillText('PRONE · PLAYING DEAD', sx, sy + 27); }
  else if (char.flags.sneaking) { ctx.fillStyle = '#92d0ad'; ctx.font = '800 7px Inter'; ctx.fillText('SNEAKING', sx, sy + 27); }
}

function drawEffects(offset, time) {
  runtime.effects = runtime.effects.filter(effect => time - effect.startedAt < effect.duration);
  for (const effect of runtime.effects) {
    if (effect.z !== runtime.character.z) continue;
    const progress = clamp((time - effect.startedAt) / effect.duration, 0, 1);
    const sx = effect.x * TILE + offset.x + TILE / 2; const sy = effect.y * TILE + offset.y + TILE / 2;
    ctx.save(); ctx.globalAlpha = 1 - progress;
    ctx.strokeStyle = effect.color; ctx.fillStyle = effect.color;
    if (effect.kind === 'ring') {
      ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(sx, sy, 8 + progress * (effect.radius || 2) * TILE, 0, Math.PI * 2); ctx.stroke();
    } else if (effect.kind === 'burst') {
      for (let i = 0; i < 8; i++) { const angle = i * Math.PI / 4; ctx.beginPath(); ctx.arc(sx + Math.cos(angle) * progress * 28, sy + Math.sin(angle) * progress * 28, 5 * (1 - progress), 0, Math.PI * 2); ctx.fill(); }
    } else if (effect.kind === 'projectile') {
      const tx = effect.targetX * TILE + offset.x + TILE / 2; const ty = effect.targetY * TILE + offset.y + TILE / 2;
      ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx + (tx - sx) * progress, sy + (ty - sy) * progress); ctx.stroke();
    }
    ctx.restore();
  }
}

function drawDarkness() {
  if (runtime.character.z >= 0 && terrainAt(runtime.character.x, runtime.character.y, 0) !== 'mountain_cave') return;
  const center = screenFromWorld(runtime.character.x, runtime.character.y);
  center.x += TILE / 2; center.y += TILE / 2;
  const radius = currentLightRadius() * TILE;
  const gradient = ctx.createRadialGradient(center.x, center.y, radius * .2, center.x, center.y, radius);
  gradient.addColorStop(0, 'rgba(0,0,0,0)');
  gradient.addColorStop(.55, 'rgba(0,0,0,.18)');
  gradient.addColorStop(1, 'rgba(0,0,0,.93)');
  ctx.fillStyle = gradient; ctx.fillRect(-runtime.viewport.width, -runtime.viewport.height, runtime.viewport.width * 3, runtime.viewport.height * 3);
}

function drawMinimap() {
  const char = runtime.character;
  const displayWidth = Math.max(100, Math.round(el.minimap.clientWidth || 160));
  const displayHeight = Math.max(64, Math.round(el.minimap.clientHeight || 96));
  if (el.minimap.width !== displayWidth || el.minimap.height !== displayHeight) {
    el.minimap.width = displayWidth; el.minimap.height = displayHeight;
    runtime.minimapBase = null; runtime.minimapFloor = null;
  }
  const width = el.minimap.width; const height = el.minimap.height;
  const scaleX = width / WORLD_W; const scaleY = height / WORLD_H;
  if (!runtime.minimapBase || runtime.minimapFloor !== char.z) {
    const base = document.createElement('canvas'); base.width = width; base.height = height;
    const baseCtx = base.getContext('2d'); baseCtx.fillStyle = '#07100e'; baseCtx.fillRect(0, 0, width, height);
    const colors = Object.fromEntries((DATA.tilePalette || []).map(tile => [tile.terrain, tile.color]));
    for (let y = 0; y < WORLD_H; y += 2) for (let x = 0; x < WORLD_W; x += 2) {
      const terrain = terrainAt(x, y, char.z);
      baseCtx.fillStyle = colors[terrain] || '#426747';
      baseCtx.fillRect(x * scaleX, y * scaleY, 2 * scaleX + 1, 2 * scaleY + 1);
    }
    runtime.minimapBase = base; runtime.minimapFloor = char.z;
  }
  const viewWidth = WORLD_W / runtime.minimapZoom; const viewHeight = WORLD_H / runtime.minimapZoom;
  const viewX = clamp(char.x - viewWidth / 2, 0, WORLD_W - viewWidth);
  const viewY = clamp(char.y - viewHeight / 2, 0, WORLD_H - viewHeight);
  runtime.minimapView = { x: viewX, y: viewY, width: viewWidth, height: viewHeight };
  const pointOnMap = entity => ({ x: (entity.x - viewX) / viewWidth * width, y: (entity.y - viewY) / viewHeight * height });
  miniCtx.clearRect(0, 0, width, height);
  miniCtx.drawImage(runtime.minimapBase, viewX * scaleX, viewY * scaleY, viewWidth * scaleX, viewHeight * scaleY, 0, 0, width, height);
  for (const npc of DATA.npcs.filter(npc => npc.z === char.z && npcVisibleToCharacter(npc, char) && npc.x >= viewX && npc.x <= viewX + viewWidth && npc.y >= viewY && npc.y <= viewY + viewHeight)) {
    const point = pointOnMap(npc); miniCtx.fillStyle = '#f0d36d'; miniCtx.fillRect(point.x - 2, point.y - 2, 4, 4);
  }
  for (const spawn of DATA.spawns.filter(spawn => spawn.z === char.z && spawn.x >= viewX && spawn.x <= viewX + viewWidth && spawn.y >= viewY && spawn.y <= viewY + viewHeight)) {
    const point = pointOnMap(spawn); const monster = byId(DATA.monsters, spawn.monsterId);
    miniCtx.strokeStyle = monster?.boss ? '#ff5d4e' : '#e18858'; miniCtx.lineWidth = monster?.boss ? 2 : 1;
    miniCtx.beginPath(); miniCtx.arc(point.x, point.y, monster?.boss ? 4.5 : 2.5, 0, Math.PI * 2); miniCtx.stroke();
  }
  const downMarkers = [...DATA.placements.filter(place => place.z === char.z && (place.type === 'hole' || place.type === 'stairs_down' || Number(place.targetZ) < place.z)), ...runtime.dynamicHoles.filter(hole => hole.z === char.z && hole.targetZ < hole.z)];
  for (const place of downMarkers.filter(place => place.x >= viewX && place.x <= viewX + viewWidth && place.y >= viewY && place.y <= viewY + viewHeight)) {
    const point = pointOnMap(place); miniCtx.fillStyle = '#62d2df'; miniCtx.beginPath(); miniCtx.moveTo(point.x, point.y + 4); miniCtx.lineTo(point.x - 3.5, point.y - 2.5); miniCtx.lineTo(point.x + 3.5, point.y - 2.5); miniCtx.closePath(); miniCtx.fill();
  }
  const player = pointOnMap(char);
  miniCtx.fillStyle = '#fff'; miniCtx.beginPath(); miniCtx.arc(player.x, player.y, 3.5, 0, Math.PI * 2); miniCtx.fill();
  miniCtx.strokeStyle = '#d8a94d'; miniCtx.stroke();
  if (runtime.path.length) {
    const destination = pointOnMap(runtime.path.at(-1));
    miniCtx.strokeStyle = '#f2d06f'; miniCtx.lineWidth = 1.5; miniCtx.beginPath(); miniCtx.arc(destination.x, destination.y, 5, 0, Math.PI * 2); miniCtx.stroke();
  }
}

function setMinimapZoom(zoom) {
  const rules = gameRule('world_rules'); runtime.minimapZoom = clamp(Math.round(zoom * 10) / 10, Number(rules.minimapZoomMinimum ?? 1), Number(rules.minimapZoomMaximum ?? 3));
  el.minimapReset.textContent = `${runtime.minimapZoom.toFixed(1).replace('.0', '')}×`;
  drawMinimap();
}

function minimapWorldPoint(event) {
  const rect = el.minimap.getBoundingClientRect(); const view = runtime.minimapView;
  return {
    x: clamp(Math.round(view.x + (event.clientX - rect.left) / rect.width * view.width), 0, WORLD_W - 1),
    y: clamp(Math.round(view.y + (event.clientY - rect.top) / rect.height * view.height), 0, WORLD_H - 1)
  };
}

function handleMinimapClick(event) {
  const char = runtime.character; if (!char || runtime.modalOpen) return;
  const point = minimapWorldPoint(event);
  if (!isPassable(point.x, point.y, char.z)) { toast('That minimap location is not walkable.', true); return; }
  const path = findPath(char.x, char.y, point.x, point.y, char.z);
  if (!path.length && (point.x !== char.x || point.y !== char.y)) { toast('No route reaches that minimap location from this floor.', true); return; }
  runtime.path = path;
  toast(path.length ? `Auto-walking ${path.length} tiles toward X ${point.x}, Y ${point.y}.` : 'You are already there.');
}

function renderProfileCards() {
  const characters=[...runtime.save.characters].sort((a,b)=>String(b.lastPlayedAt||'').localeCompare(String(a.lastPlayedAt||''))||Number(a.slot||0)-Number(b.slot||0)),presetIds=DATA.characters.filter(character=>character.presetTemplate).slice(0,8).map(character=>character.id),presets=presetIds.map(id=>byId(DATA.characters,id)).filter(Boolean),saved=characters.filter(character=>character.lastPlayedAt||!presetIds.includes(character.id));
  const formatPlaytime=seconds=>{const value=Math.max(0,Math.floor(Number(seconds||0)));const hours=Math.floor(value/3600),minutes=Math.floor(value%3600/60);return hours?`${hours}h ${minutes}m`:`${minutes}m`;};
  const summary=document.getElementById('profileSummary');if(summary)summary.textContent=`${characters.length} characters · ${formatPlaytime(characters.reduce((sum,row)=>sum+Number(row.playSeconds||0),0))} total playtime · most recently played first`;
  const cardHtml=(character,editable=false)=>{
    const vocation = vocationOf(character);
    const selected = character.id === runtime.selectedProfileId;
    const power = totalGearScore(character);
    const tooltip = `${character.name}\nLevel ${character.level} ${vocation?.name || character.vocationId}\n${character.tooltip || character.scenario}\n${character.location}\nGear ${power} · ${number(character.gold)} gp`;
    return `<button class="profile-card ${selected ? 'selected' : ''}" data-profile-id="${character.id}" data-tooltip="${escapeHtml(tooltip)}" style="--card-glow:${vocation?.color || '#d8a94d'}55">
      <div class="profile-art">${vocation?.icon || '♙'}</div>
      <div class="profile-copy">
        <span>SAVE SLOT ${character.slot} · LEVEL ${character.level}</span>
        ${editable?`<input class="profile-name-input" data-profile-name="${character.id}" value="${escapeHtml(character.name)}" aria-label="Character name">`:`<h2>${escapeHtml(character.name)}</h2>`}
        <h3>${escapeHtml(vocation?.name || character.vocationId)}</h3>
        <p>${escapeHtml(`Now level ${character.level} with ${number(character.gold)} gp and ${power} equipped gear score. ${character.scenarioText}`)}</p>
        <dl><dt>Scene</dt><dd>${escapeHtml(character.scenario)}</dd><dt>Location</dt><dd>${escapeHtml(character.location)}</dd><dt>Gear score</dt><dd>${power}${character.gearScoreBudget?` + ${number(character.gearScoreBudget)} budget`:''}</dd><dt>Gold</dt><dd>${number(character.gold)} gp</dd><dt>Playtime</dt><dd>${formatPlaytime(character.playSeconds)}</dd><dt>Last played</dt><dd>${character.lastPlayedAt?new Date(character.lastPlayedAt).toLocaleString():'Never'}</dd></dl>
      </div>
    </button>`;};
  el.profileCards.innerHTML=presets.map(character=>cardHtml(character,false)).join('');if(el.savedProfileCards)el.savedProfileCards.innerHTML=saved.map(character=>cardHtml(character,true)).join('')||'<div class="target-empty">Play or create a character and its updated save appears here.</div>';
  document.querySelectorAll('#profileCards [data-profile-id],#savedProfileCards [data-profile-id]').forEach(card => card.addEventListener('click',event => {
    if(event.target.closest('input'))return;
    runtime.selectedProfileId = card.dataset.profileId;
    el.continueButton.disabled = false;
    renderProfileCards();
  }));
  document.querySelectorAll('[data-profile-name]').forEach(input=>input.addEventListener('change',()=>{const character=runtime.save.characters.find(row=>row.id===input.dataset.profileName);if(character){character.name=input.value.trim()||character.name;character.lastPlayedAt=character.lastPlayedAt||nowIso();saveGame(false);renderProfileCards();}}));
}

function totalGearScore(character) {
  return Object.values(character.equipment || {}).reduce((sum, id) => {
    return sum + itemGearScore(id, character);
  }, 0);
}

function gearCurveFor(item) { return byId(DATA.gearLevelCurves, item?.gearCurveId) || DATA.gearLevelCurves[0]; }
function itemProgressFor(itemId, character=runtime.character) {
  if(!character)return {level:1,xp:0,paidUpgrades:0,uses:0,weaponUses:0,hitsTakenWhileEquipped:0,damageTakenWhileEquipped:0,spellCastsWhileEquipped:0};
  character.itemProgress=character.itemProgress||{};
  const progress=character.itemProgress[itemId]||(character.itemProgress[itemId]={level:Number(itemOf(itemId)?.minimumItemLevel||1),xp:0,paidUpgrades:0});
  for(const field of ['uses','weaponUses','hitsTakenWhileEquipped','damageTakenWhileEquipped','spellCastsWhileEquipped'])progress[field]=Number(progress[field]||0);
  return progress;
}
function itemXpNeeded(itemId, level, character=runtime.character) { const item=itemOf(itemId),curve=gearCurveFor(item);return Math.max(1,Math.round(Number(curve.baseXp||100)*Math.pow(Math.max(1,level),Number(curve.exponent||1.3)))); }
function effectiveItemStat(itemId,stat,character=runtime.character){const item=itemOf(itemId)||{},progress=itemProgressFor(itemId,character),curve=gearCurveFor(item);return Number(item[stat]||0)*(1+Math.max(0,progress.level-1)*Number(curve.statGainPerLevel||0));}
function itemGearScore(itemId,character=runtime.character){const item=itemOf(itemId)||{},progress=itemProgressFor(itemId,character),curve=gearCurveFor(item);return Math.max(0,Math.round(Number(item.gearScoreBase||0)+Math.max(0,progress.level-1)*Number(curve.gearScorePerLevel||1)));}
function trainEquippedItem(slot,amount,reason='use') { const char=runtime.character,itemId=char?.equipment?.[slot];if(!itemId)return;const item=itemOf(itemId),curve=gearCurveFor(item),progress=itemProgressFor(itemId,char),cap=Math.min(Number(item.maximumItemLevel||100),Number(curve.maxLevel||100));progress.xp+=Math.max(0,Number(amount||0));progress.uses+=1;while(progress.level<cap&&progress.xp>=itemXpNeeded(itemId,progress.level,char)){progress.xp-=itemXpNeeded(itemId,progress.level,char);progress.level+=1;toast(`${item.name} advanced to item level ${progress.level} through ${reason}.`);} }
function trainEquippedDefense(amount){for(const slot of EQUIP_SLOTS.filter(slot=>slot!=='weapon'&&slot!=='ammo')){const item=itemOf(runtime.character?.equipment?.[slot]),curve=gearCurveFor(item);if(item){const progress=itemProgressFor(item.id,runtime.character);progress.hitsTakenWhileEquipped+=1;progress.damageTakenWhileEquipped+=Math.max(0,Number(amount||0));trainEquippedItem(slot,Math.max(.2,amount*Number(curve.useXpDefense||2)/10),'defense');}}}
function trainEquippedSpellGear(amount){for(const slot of ['weapon','shield','amulet','ring']){const item=itemOf(runtime.character?.equipment?.[slot]),curve=gearCurveFor(item);if(item){const progress=itemProgressFor(item.id,runtime.character);progress.spellCastsWhileEquipped+=1;if(slot==='weapon')progress.weaponUses+=1;trainEquippedItem(slot,Math.max(.2,amount*Number(curve.useXpSpell||3)/10),'magic use');}}}

function socialValue(character,id){return Number(character?.socialStats?.[id]||0);}
function applySocialEffects(effects={},source='event'){const char=runtime.character;if(!char)return;char.socialStats=char.socialStats||{};for(const [id,amount] of Object.entries(effects)){const definition=byId(DATA.socialStats,id);if(!definition)continue;const before=socialValue(char,id);char.socialStats[id]=clamp(before+Number(amount||0),Number(definition.minimum??-100),Number(definition.maximum??100));for(const linked of definition.interplay||[])char.socialStats[linked]=clamp(socialValue(char,linked)+Number(amount||0)*.08,-100,100);}queueGameEvent('social_change',{source,effects});progressQuestEvent('social_threshold','fame_or_infamy',Math.max(socialValue(char,'fame'),socialValue(char,'infamy')));}
function applyReputationInterests(tags=[]){const char=runtime.character;if(!char)return;char.reputations=char.reputations||{};for(const goal of DATA.reputationGoals){const matches=(goal.interestTags||[]).filter(tag=>tags.includes(tag)).length;if(!matches)continue;const reputation=DATA.reputations.find(row=>(row.goalIds||[]).includes(goal.id));if(reputation)char.reputations[reputation.id]=clamp(Number(char.reputations[reputation.id]||0)+Number(goal.successReputation||0)*matches,Number(reputation.minimum||-1000),Number(reputation.maximum||1000));for(const opposedId of goal.opposedGoalIds||[]){const opposedRep=DATA.reputations.find(row=>(row.goalIds||[]).includes(opposedId));if(opposedRep)char.reputations[opposedRep.id]=clamp(Number(char.reputations[opposedRep.id]||0)-Math.ceil(Number(goal.successReputation||0)*matches/2),Number(opposedRep.minimum||-1000),Number(opposedRep.maximum||1000));}}}
function applySocialEvent(eventId){const event=byId(DATA.socialEventDefinitions,eventId);if(!event)return;applySocialEffects(event.effects,eventId);const tags=event.interestTags||({event_helpful_quest:['rescue','defense'],event_heroic_kill:['defense'],event_public_threat:['infamy','threat'],event_generous_trade:['healing']}[eventId]||[]);applyReputationInterests(tags);progressQuestEvent('social_event',eventId,1);}
function applyDefeatHappiness(defeated,contextId='world_hunt',killer=runtime.character){if(!killer||!defeated)return 0;const context=byId(DATA.happinessContexts,contextId)||{multiplier:1},affections=DATA.characterAffections.find(row=>row.characterId===killer.id)||{},faction=byId(DATA.factions,killer.factionId)||{},rule=DATA.factionHappinessRules.find(row=>row.factionId===killer.factionId)||{},targetId=defeated.entityId||defeated.id,targetFaction=defeated.factionId||'faction_wild';let amount=Number(defeated.happinessModifier||0);if((affections.lovedEntityIds||[]).includes(targetId)||(affections.lovedEntityIds||[]).includes(defeated.id))amount=Number(rule.lovedDefeat??faction.lovedDefeatModifier??-20);else if((affections.rivalEntityIds||[]).includes(targetId)||(affections.rivalEntityIds||[]).includes(defeated.id)||(faction.rivalFactionIds||[]).includes(targetFaction))amount+=Number(rule.rivalDefeat??faction.rivalDefeatModifier??4);else if((faction.alliedFactionIds||[]).includes(targetFaction)||targetFaction===killer.factionId)amount+=Number(rule.allyDefeat??faction.allyDefeatModifier??-6);else amount+=Number(rule.neutralDefeat??faction.neutralDefeatModifier??0);if(contextId==='player_killing')amount+=Number(faction.playerKillingModifier??-12);amount*=Number(rule.contextModifiers?.[contextId]??context.multiplier??1);killer.happiness=clamp(Number(killer.happiness??50)+amount,0,100);killer.happinessHistory=killer.happinessHistory||[];killer.happinessHistory.unshift({at:nowIso(),amount:Number(amount.toFixed(2)),contextId,targetId,reason:`${defeated.name||targetId} defeated`});killer.happinessHistory=killer.happinessHistory.slice(0,100);if(Math.abs(amount)>=.01)floatText(killer.x,killer.y,`${amount>0?'+':''}${amount.toFixed(1)} 😊`,amount>0?'heal':'');queueGameEvent('happiness_changed',{amount,contextId,targetId,factionId:targetFaction});return amount;}
function socialRequirementsMet(quest,char=runtime.character){const all=Object.entries(quest.socialRequirements||{}).every(([id,value])=>socialValue(char,id)>=Number(value));const any=!quest.socialRequirementsAny?.length||quest.socialRequirementsAny.some(group=>Object.entries(group).every(([id,value])=>socialValue(char,id)>=Number(value)));return all&&any;}

function selectCharacter(characterId) {
  if (runtime.character) saveGame(false);
  const saved = runtime.save.characters.find(character => character.id === characterId);
  if (!saved) return;
  const sharedMap = byId(DATA.levelMaps, runtime.save.world.activeMapId); if (sharedMap && sharedMap.id !== runtime.activeMapId) { runtime.activeMapId = sharedMap.id; DATA.levelTiles = sharedMap.layers.terrain = sharedMap.layers.terrain || decodeTerrainRle(sharedMap.layers.terrainRle || {}, sharedMap.id); rebuildLevelTileIndex(); }
  runtime.character = saved;
  migrateItemProvenance(saved);
  saved.lastPlayedAt=nowIso();saved.playSeconds=Number(saved.playSeconds||0);
  runtime.lastPlaytimeTick=performance.now();
  syncCottageResidents(saved);
  runtime.save.world.activeMapId = runtime.activeMapId;
  saved.depot = saved.depot || []; saved.ownedMounts = saved.ownedMounts || (saved.mountId ? [saved.mountId] : []);
  if (!saved.inventory.some(stack => stack.id === 'pickaxe')) saved.inventory.push({ id: 'pickaxe', qty: 1 });
  if (!saved.inventory.some(stack => stack.id === 'woodcut_axe')) saved.inventory.push({ id: 'woodcut_axe', qty: 1 });
  if (!Array.isArray(saved.learnedSpells)) saved.learnedSpells = [...(saved.spells || [])];
  if (!saved.inventory.some(stack => stack.id === 'spellbook')) saved.inventory.unshift({ id: 'spellbook', qty: 1 });
  if (!saved.flags.starterCombatKitGranted) {
    for (const stack of [{ id: 'spark_wand', qty: 1 }, { id: 'shore_bow', qty: 1 }, { id: 'reed_arrow', qty: 40 }, { id: 'harbor_spear', qty: 5 }, { id: 'ember_rune', qty: 8 }, { id: 'mending_rune', qty: 8 }]) if (!saved.inventory.some(entry => entry.id === stack.id)) saved.inventory.push(stack);
    saved.flags.starterCombatKitGranted = true;
  }
  ensureSurvival(saved).lastUpdatedAt = Date.now();
  runtime.save.activeCharacterId = characterId;
  runtime.camera.x = saved.x;
  runtime.camera.y = saved.y;
  runtime.trackedQuestId = Object.keys(saved.quests).find(id => saved.quests[id].status === 'active') || 'Q_01';
  resetRuntimeWorld();
  if (location.protocol !== 'file:' && runtime.server.authenticated) setTimeout(() => syncServer(true), 0);
  runtime.worldReady = true;
  el.profileScreen.classList.add('hidden');
  el.worldCanvas.focus();
  renderAllUi();
  saveGame(false);
  toast(`${saved.name} enters ${zoneAt(saved.x, saved.y, saved.z)?.name || 'Dawnreach'}.`);
  logConsole(`Character loaded: ${saved.name}, level ${saved.level} ${vocationOf(saved)?.name}.`);
}

function renderAllUi() {
  renderHud();
  renderEquipment();
  renderInventory();
  renderSpellBar();
  renderQuestTracker();
  renderNearby();
  renderTarget();
}

function renderHud() {
  const char = runtime.character;
  if (!char) return;
  const vocation = vocationOf(char);
  el.portrait.textContent = vocation?.icon || '♙';
  el.characterName.textContent = char.name;
  el.characterLine.textContent = `Level ${char.level} ${vocation?.name || char.vocationId}${char.flags.sneaking ? ' · SNEAKING' : ''}${char.flags.unconscious ? ' · PRONE' : ''}`;
  el.profileButton.dataset.tooltip = `${char.name}\nLevel ${char.level} ${vocation?.name || char.vocationId}\n${char.location}\nHealth ${Math.ceil(char.hp)}/${char.maxHp} · Mana ${Math.ceil(char.mana)}/${char.maxMana}\nGear ${totalGearScore(char)} · ${number(char.gold)} gp\nClick to switch character.`;
  el.levelValue.textContent = char.level;
  el.hpText.textContent = `${Math.ceil(char.hp)} / ${char.maxHp}`;
  el.hpBar.style.width = `${clamp(char.hp / char.maxHp * 100, 0, 100)}%`;
  el.manaText.textContent = `${Math.ceil(char.mana)} / ${char.maxMana}`;
  el.manaBar.style.width = `${clamp(char.mana / char.maxMana * 100, 0, 100)}%`;
  el.zealText.textContent = `${char.zeal || 0}`;
  if(el.happinessText)el.happinessText.textContent=`${Number(char.happiness??50).toFixed(1)} / 100`;
  if(el.happinessBar)el.happinessBar.style.width=`${clamp(Number(char.happiness??50),0,100)}%`;
  const xpProgress = clamp(char.xp / char.xpNext * 100, 0, 100);
  el.xpText.textContent = `${Math.floor(xpProgress)}%`;
  el.xpBar.style.width = `${xpProgress}%`;
  const magic=char.skills?.magic||{level:1,xp:0,next:100},magicProgress=clamp(Number(magic.xp||0)/Math.max(1,Number(magic.next||100))*100,0,100);
  if(el.magicProgressText)el.magicProgressText.textContent=`ML ${magic.level} · ${Math.floor(magicProgress)}%`;
  if(el.magicProgressBar)el.magicProgressBar.style.width=`${magicProgress}%`;
  el.goldText.textContent = number(char.gold);
  el.capText.textContent = `${Math.round(inventoryWeight(char))} / ${char.capMax}`;
  el.lightText.textContent = `${currentLightRadius() > 2 ? '☀' : '☾'} ${currentLightRadius()} tiles`;
  if (el.magicLevelText) el.magicLevelText.textContent = char.skills?.magic?.level || 1;
  document.querySelector('[data-resource-detail="health"]')?.setAttribute('data-tooltip',`Health\n${char.hp.toFixed(2)} / ${char.maxHp}\nRegenerates ${classRegen('health',char).toFixed(3)} per second. Click for the tracked class details.`);
  document.querySelector('[data-resource-detail="mana"]')?.setAttribute('data-tooltip',`Mana\n${char.mana.toFixed(2)} / ${char.maxMana}\nRegenerates ${classRegen('mana',char).toFixed(3)} per second. Click for the tracked class details.`);
  document.querySelector('[data-resource-detail="zeal"]')?.setAttribute('data-tooltip','Zeal\nA simple combat charge number used by Warhealer abilities. Click for details.');
  document.querySelector('[data-resource-detail="happiness"]')?.setAttribute('data-tooltip',`Happiness\n${Number(char.happiness??50).toFixed(1)} / 100\nChanges from defeats, loved or rival entities, factions, PvP, wars and server-event contexts. Click for history.`);
  document.querySelector('[data-resource-detail="progression"]')?.setAttribute('data-tooltip',`Progression\nLevel ${char.level}: ${Math.floor(char.xp)} / ${char.xpNext} XP\nMagic Level ${char.skills?.magic?.level||1}: ${Math.floor(char.skills?.magic?.xp||0)} / ${char.skills?.magic?.next||100}. Click for details.`);
  const zone = zoneAt(char.x, char.y, char.z);
  el.zoneName.textContent = zone?.name || 'Open Water';
  const floorLabels = { 0: 'Surface', '-1': 'Lower I', '-2': 'Lower II', '-3': 'Lower III', '-4': 'Lower IV', '-5': 'Deep V', '-6': 'Deep VI', '-7': 'Abyss VII', '-8': 'Deepest VIII' };
  el.floorName.textContent = `${floorLabels[char.z] || `Floor ${char.z}`} · ${zone?.pz ? 'Protection Zone' : `${zone?.danger || 'unknown'} danger`}`;
  el.zoneDanger.textContent = zone?.danger?.toUpperCase() || 'UNKNOWN';
  el.zoneDanger.style.color = zone?.danger === 'safe' ? '#68c791' : zone?.danger === 'low' ? '#c3c86d' : zone?.danger === 'medium' ? '#dcaa4d' : '#e35f56';
  el.coordinates.textContent = `X ${char.x} · Y ${char.y} · Z ${char.z}`;
  el.combatMode.querySelector('small').textContent = runtime.combatStance.toUpperCase();
  el.mountButton.style.borderColor = char.mounted ? '#d8a94d' : '';
  el.torchButton.style.borderColor = (char.flags.torchLit || char.flags.lanternLit || char.statuses.lightUntil > Date.now()) ? '#d8a94d' : '';
  const survival = ensureSurvival(char);
  for (const need of ['hunger', 'thirst', 'rest']) {
    const value = survival[need];
    const textNode = el[`${need}Text`]; const barNode = el[`${need}Bar`];
    if (textNode) textNode.textContent = Math.ceil(value);
    if (barNode) {
      barNode.style.width = `${value}%`;
      const card = barNode.closest('article');
      card?.classList.toggle('low', value > 0 && value <= 25);
      card?.classList.toggle('empty', value <= 0);
    }
  }
}

function renderEquipment() {
  const char = runtime.character;
  if (!char) return;
  el.equipmentGrid.innerHTML = EQUIP_SLOTS.map(slot => {
    const item = itemOf(char.equipment[slot]);
    const title = item ? `${slot.toUpperCase()}\n${itemTooltipText(item,1,char.equipmentProvenance?.[slot])}` : `Empty ${slot} equipment slot`;
    const progress=item?itemProgressFor(item.id,char):null;
    return `<button class="equip-slot ${item ? '' : 'empty'}" data-pos="${slot}" data-slot="${slot}" draggable="${item ? 'true' : 'false'}" data-tooltip="${escapeHtml(title)}">${item ? `<span class="item-icon" style="color:${item.color || '#ddd'}">${item.icon || '◆'}</span><small>IL ${progress.level} · GS ${itemGearScore(item.id,char)}</small>` : ''}</button>`;
  }).join('');
  el.equipmentGrid.querySelectorAll('.equip-slot').forEach(button => {
    button.addEventListener('click', () => { if (runtime.character.equipment[button.dataset.pos]) unequipItem(button.dataset.pos); });
    button.addEventListener('contextmenu', event => { event.preventDefault(); const itemId=runtime.character.equipment[button.dataset.pos];if(itemId)openItemUpgrade(itemId); });
    button.addEventListener('dragstart', event => startItemDrag(event, { source: 'equipment', slot: button.dataset.pos, qty: 1 }));
    button.addEventListener('dragover', event => event.preventDefault());
    button.addEventListener('drop', event => { event.preventDefault(); handleEquipmentDrop(button.dataset.pos, readDragPayload(event)); });
  });
}

function renderInventory() {
  const char = runtime.character;
  if (!char) return;
  const capacity = inventoryCapacity(char);
  const slots = [];
  for (let index = 0; index < capacity; index++) {
    const stack = char.inventory[index];
    const item = stack ? itemOf(stack.id) : null;
    const contained = stack?.instanceId ? (char.containerContents?.[stack.instanceId] || []).length : 0;
    slots.push(`<button class="inventory-slot ${runtime.selectedInventoryIndex === index ? 'selected' : ''}" data-index="${index}" draggable="${item ? 'true' : 'false'}" data-tooltip="${escapeHtml(item ? `${itemTooltipText(item, stack.qty,stack)}${item.type === 'container' ? `\n${contained} / ${item.capacity || 0} contained stacks · double-click to open` : ''}` : `Empty backpack slot ${index + 1}`)}">${item ? `<span class="item-icon" style="color:${item.color || '#ddd'}">${item.icon || '◆'}</span><small>${item.type === 'container' ? contained : stack.qty > 1 ? stack.qty : ''}</small>` : ''}</button>`);
  }
  el.inventoryGrid.innerHTML = slots.join('');
  el.inventoryCount.textContent = `${char.inventory.length} / ${capacity}`;
  el.inventoryGrid.querySelectorAll('.inventory-slot').forEach(button => {
    button.addEventListener('click', event => {
      const index = Number(button.dataset.index);
      runtime.selectedInventoryIndex = index < char.inventory.length ? index : -1;
      renderInventory();
      if (event.detail === 2 && runtime.selectedInventoryIndex >= 0) useInventoryItem(runtime.selectedInventoryIndex);
    });
    button.addEventListener('dragstart', event => startItemDrag(event, { source: 'inventory', index: Number(button.dataset.index), qty: event.shiftKey ? 1 : null }));
    button.addEventListener('contextmenu',event=>{event.preventDefault();const stack=char.inventory[Number(button.dataset.index)];if(stack)openProvenanceViewer(stack,itemOf(stack.id));});
    button.addEventListener('dragover', event => event.preventDefault());
    button.addEventListener('drop', event => { event.preventDefault(); handleInventoryDrop(Number(button.dataset.index), readDragPayload(event)); });
  });
}

function renderSpellBar() {
  const char = runtime.character;
  if (!char) return;
  const spells = [...char.spells].slice(0, 8);
  while (spells.length < 8) spells.push(null);
  el.spellBar.innerHTML = spells.map((id, index) => {
    const spell = id ? spellOf(id) : null;
    const cooldownUntil = id ? char.cooldowns[id] || 0 : 0;
    const cooldown = spell ? Math.max(0, cooldownUntil - Date.now()) : 0;
    const disabled = !spell || char.level < spell.level || char.mana < (spell.mana || 0) || char.zeal < (spell.zeal || 0) || cooldown > 0;
    const resource = spell ? spell.zeal ? `${spell.zeal}Z` : spell.mana ? `${spell.mana}M` : 'FREE' : '';
    return `<button class="spell-button" data-spell-id="${id || ''}" ${disabled ? 'disabled' : ''} data-tooltip="${spell ? escapeHtml(`${spell.name} — ${spell.incantation || 'skill'}\n${spell.tooltip || spell.visual}\nLevel ${spell.level} · ${resource} · Cooldown ${(spell.cooldown / 1000).toFixed(1)}s`) : `Empty spell slot ${index + 1}`}"><kbd>${index + 1}</kbd><span>${spell?.icon || '·'}</span><small>${spell?.name || 'EMPTY'}</small><b>${resource}</b>${cooldown ? `<i class="cooldown" style="transform:scaleY(${clamp(cooldown / spell.cooldown, 0, 1)})"></i>` : ''}</button>`;
  }).join('');
  el.spellBar.querySelectorAll('[data-spell-id]').forEach(button => button.addEventListener('click', () => button.dataset.spellId && castSpell(button.dataset.spellId)));
}

function renderTarget() {
  const target = monsterByEntity(runtime.targetId);
  if (!target || !target.alive || target.z !== runtime.character?.z) {
    runtime.targetId = null;
    el.targetEmpty.classList.remove('hidden');
    el.targetInfo.classList.add('hidden');
    el.bossBanner.classList.add('hidden');
    return;
  }
  el.targetEmpty.classList.add('hidden');
  el.targetInfo.classList.remove('hidden');
  el.targetIcon.textContent = target.icon;
  el.targetIcon.style.color = target.color;
  el.targetName.textContent = target.name;
  el.targetLevel.textContent = `Level ${target.level} · ${target.element}`;
  el.targetTraits.textContent = target.traits || '';
  el.targetInfo.dataset.tooltip = monsterTooltipText(target);
  el.targetBar.style.width = `${clamp(target.hp / target.maxHp * 100, 0, 100)}%`;
  if (target.boss) {
    el.bossBanner.classList.remove('hidden'); el.bossName.textContent = target.name; el.bossBar.style.width = `${clamp(target.hp / target.maxHp * 100, 0, 100)}%`;
  } else el.bossBanner.classList.add('hidden');
}

function renderNearby() {
  const char = runtime.character;
  if (!char) return;
  const entries = [];
  for (const npc of DATA.npcs.filter(npc => npc.z === char.z && npcVisibleToCharacter(npc, char))) {
    const distance = manhattan(char, npc);
    if (distance <= 7) entries.push({ type: 'npc', id: npc.id, name: npc.name, sub: npc.role, icon: npc.icon, distance, entity: npc });
  }
  for (const monster of runtime.monsters.filter(monster => monster.alive && monster.z === char.z)) {
    const distance = manhattan(char, monster);
    if (distance <= 7) entries.push({ type: 'monster', id: monster.entityId, name: monster.name, sub: `Level ${monster.level} · ${monster.element}`, icon: monster.icon, distance, entity: monster });
  }
  for (const pile of runtime.ground.filter(pile => pile.z === char.z)) {
    const distance = manhattan(char, pile);
    if (distance <= 5) entries.push({ type: 'ground', id: pile.id, name: pile.name || itemOf(pile.itemId)?.name || 'Ground loot', sub: 'Lootable', icon: pile.icon || itemOf(pile.itemId)?.icon || '◆', distance, entity: pile });
  }
  entries.sort((a, b) => a.distance - b.distance);
  el.nearbyList.innerHTML = entries.slice(0, 8).map(entry => {
    const tooltip = entry.type === 'monster' ? monsterTooltipText(entry.entity) : entry.type === 'npc' ? npcTooltipText(entry.entity) : pileTooltipText(entry.entity);
    return `<button data-nearby-type="${entry.type}" data-nearby-id="${entry.id}" data-tooltip="${escapeHtml(tooltip)}"><i style="color:${entry.entity.color || '#d8a94d'}">${entry.icon}</i><span><strong>${escapeHtml(entry.name)}</strong><small>${escapeHtml(entry.sub)}</small></span><b>${entry.distance}t</b></button>`;
  }).join('') || '<div class="target-empty">The immediate area is quiet.</div>';
  el.nearbyList.querySelectorAll('button').forEach(button => button.addEventListener('click', () => {
    if (button.dataset.nearbyType === 'monster') { runtime.targetId = button.dataset.nearbyId; renderTarget(); }
    else {
      const entity = button.dataset.nearbyType === 'npc' ? byId(DATA.npcs, button.dataset.nearbyId) : runtime.ground.find(pile => pile.id === button.dataset.nearbyId);
      if (entity) runtime.path = findPath(char.x, char.y, entity.x, entity.y, char.z, true);
    }
  }));
  updateInteractionPrompt();
}

function renderQuestTracker() {
  const char = runtime.character;
  if (!char) return;
  let questId = runtime.trackedQuestId;
  if (!questId || !char.quests[questId] || !['active', 'ready'].includes(char.quests[questId].status)) {
    questId = Object.keys(char.quests).find(id => ['active', 'ready'].includes(char.quests[id].status));
    runtime.trackedQuestId = questId;
  }
  const quest = questOf(questId);
  if (!quest) {
    el.trackedQuestName.textContent = 'No quest tracked'; el.trackedQuestDescription.textContent = 'Visit a quest giver marked with !'; el.trackedObjectives.innerHTML = ''; return;
  }
  const state = char.quests[quest.id];
  el.trackedQuestName.textContent = quest.name;
  el.trackedQuestDescription.textContent = state.status === 'ready' ? 'All objectives complete. Return to the quest giver.' : quest.description;
  el.trackedObjectives.innerHTML = quest.objectives.map(objective => {
    const progress = Number(state.progress[objective.id] || 0);
    const done = progress >= objective.amount;
    return `<p class="${done ? 'done' : ''}"><i></i><span>${escapeHtml(objective.label)}</span><b>${Math.min(progress, objective.amount)} / ${objective.amount}</b></p>`;
  }).join('');
}

function updateInteractionPrompt() {
  const interaction = nearestInteraction();
  if (!interaction) { el.interactionPrompt.classList.add('hidden'); return; }
  el.interactionPrompt.classList.remove('hidden');
  el.interactionText.textContent = interaction.label;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[character]);
}
function number(value) { return Number(value || 0).toLocaleString(); }
function manhattan(a, b) { return Math.abs(a.x - b.x) + Math.abs(a.y - b.y); }

function itemTooltipText(item, quantity = 1, holder = null) {
  if (!item) return 'Empty item slot';
  const progress=runtime.character&&item.id?itemProgressFor(item.id,runtime.character):{level:item.minimumItemLevel||1,xp:0};
  const stats = [item.attack ? `Attack ${effectiveItemStat(item.id,'attack').toFixed(1)}` : '', item.defense ? `Defense ${effectiveItemStat(item.id,'defense').toFixed(1)}` : '', item.armor ? `Armor ${effectiveItemStat(item.id,'armor').toFixed(1)}` : '', item.heal ? `Heals ${item.heal}` : '', item.mana ? `Restores ${item.mana} mana` : '', item.lightRadius ? `Light ${item.lightRadius} tiles` : ''].filter(Boolean).join(' · ');
  const history=[item.type==='weapon'||item.slot==='weapon'?`Weapon used ${number(progress.weaponUses)} times`:'',item.type==='armor'||item.type==='shield'||item.slot&&item.slot!=='weapon'?`Hits taken while equipped ${number(progress.hitsTakenWhileEquipped)} · damage received ${number(progress.damageTakenWhileEquipped)}`:'',progress.spellCastsWhileEquipped?`Spell casts while equipped ${number(progress.spellCastsWhileEquipped)}`:''].filter(Boolean).join('\n');
  const instanceLevel=Number(holder?.itemLevel||progress.level);return `${item.name}${quantity > 1 ? ` × ${quantity}` : ''}\n${item.tooltip || item.description || item.type}${item.gearScoreBase?`\nItem level ${instanceLevel} · ${Math.floor(progress.xp)} / ${itemXpNeeded(item.id,progress.level)} XP · Gear score ${itemGearScore(item.id)}`:''}${stats ? `\n${stats}` : ''}${history?`\n${history}`:''}\n${item.weight || 0} oz each · Buy ${number(item.buy)} gp · Sell ${number(item.sell)} gp${provenanceText(holder)}`;
}
function openProvenanceViewer(holder,item){const records=holder?.provenanceRecords||(holder?.provenance?[holder.provenance]:[]);const html=records.length?records.map(record=>`<article class="info-card ${record.adminCreated?'provenance-admin':''}"><h3>${record.adminCreated?'🟥 ADMIN-CREATED':'ORIGINAL AUTHOR'}</h3><p><b>${escapeHtml(record.authoredByName||record.authoredById)}</b> · ${escapeHtml(record.authoredByType||'unknown')}<br>${escapeHtml(record.sourceType)} · ${escapeHtml(record.sourceId)}<br>${escapeHtml(record.authoredAt)}</p><ol>${(record.ownershipChain||[]).map(event=>`<li>${escapeHtml(event.at)} · ${escapeHtml(event.fromId||'origin')} → ${escapeHtml(event.toName||event.toId)} · ${escapeHtml(event.reason||'transfer')}</li>`).join('')}</ol></article>`).join(''):'<article class="info-card"><p>Legacy server-authored instance. Its chain begins with the server when next transferred.</p></article>';openModal('AUTHORSHIP & OWNERSHIP CHAIN',item?.name||'World Object',html,'wide');}

function monsterTooltipText(monster) {
  if (!monster) return 'Unknown creature';
  return `${monster.boss ? 'ELITE · ' : ''}${monster.name}\nLevel ${monster.level} · ${monster.element}\nHealth ${Math.ceil(monster.hp ?? monster.maxHp ?? 0)} / ${monster.maxHp ?? monster.hp ?? 0}\nAttack ${monster.attack} · Defense ${monster.defense} · XP ${number(monster.xp)}\n${monster.tooltip || monster.traits || 'No special traits'}${monster.respawnSeconds ? `\nRespawns in ${monster.respawnSeconds}s after defeat` : ''}`;
}

function npcTooltipText(npc) {
  if (!npc) return 'Unknown character';
  const shop = npc.shop ? byId(DATA.shops, npc.shop)?.name : '';
  return `${npc.name}\n${npc.role}${npc.tooltip || npc.description ? `\n${npc.tooltip || npc.description}` : ''}${shop ? `\nShop: ${shop}` : ''}${npc.quests?.length ? `\nQuests available: ${npc.quests.length}` : ''}`;
}

function pileTooltipText(pile) {
  if (!pile) return 'Ground loot';
  if (pile.type === 'bag') return `${pile.name || 'Loot bag'}\n${pile.items.map(stack => `${itemOf(stack.id)?.name || stack.id} × ${stack.qty}`).join('\n')}\nPress E within the surrounding 3×3 area to collect.`;
  return `${itemTooltipText(itemOf(pile.itemId), pile.qty,pile)}\nOn the ground · Press E within the surrounding 3×3 area to collect.`;
}

function questReady(questId) {
  const quest = questOf(questId); const state = runtime.character?.quests?.[questId];
  if (!quest || !state || !['active', 'ready'].includes(state.status)) return false;
  return quest.objectives.every(objective => Number(state.progress[objective.id] || 0) >= objective.amount);
}

function acceptQuest(questId) {
  const char = runtime.character; const quest = questOf(questId); const state = char?.quests?.[questId];
  if (!quest || !state || state.status !== 'available') return;
  const unmet = (quest.prerequisite || []).filter(id => char.quests[id]?.status !== 'complete');
  if (unmet.length) { toast(`Complete ${unmet.map(id => questOf(id)?.name || id).join(', ')} first.`, true); return; }
  if (!socialRequirementsMet(quest,char)) { toast('Your current social reputation does not meet this quest’s requirements.', true); return; }
  state.status = 'active'; state.acceptedAt = nowIso();
  runtime.trackedQuestId = questId;
  for (const objective of quest.objectives.filter(objective => objective.type === 'collect')) state.progress[objective.id] = inventoryQuantity(objective.targetId);
  for (const objective of quest.objectives.filter(objective => objective.type === 'social_threshold')) state.progress[objective.id]=Math.min(objective.amount,Math.max(socialValue(char,'fame'),socialValue(char,'infamy')));
  toast(`Quest accepted: ${quest.name}`);
  renderQuestTracker(); saveGame(false); closeModal();
}

function completeQuest(questId) {
  const char = runtime.character; const quest = questOf(questId); const state = char?.quests?.[questId];
  if (!quest || !state || !questReady(questId)) return;
  state.status = 'complete'; state.completedAt = nowIso();
  const earnedXp = experienceAward(quest.rewards.xp || 0, char);
  char.xp += earnedXp; char.gold += quest.rewards.gold || 0;
  for (const reward of quest.rewards.items || []) if (reward.qty > 0) addItem(reward.id, reward.qty, char, true);
  applySocialEvent('event_helpful_quest'); applySocialEffects(quest.socialEffects||{},`quest:${questId}`);
  checkLevelUp();
  toast(`Quest complete: ${quest.name} · +${earnedXp} XP${earnedXp < (quest.rewards.xp || 0) ? ' (tired)' : ''} · +${quest.rewards.gold || 0} gp`);
  runtime.trackedQuestId = Object.keys(char.quests).find(id => char.quests[id].status === 'active') || null;
  renderAllUi(); saveGame(false); closeModal();
}

function progressQuestEvent(type, targetId, amount = 1) {
  const char = runtime.character;
  if (!char) return;
  for (const quest of DATA.quests) {
    const state = char.quests[quest.id];
    if (!state || !['active', 'ready'].includes(state.status)) continue;
    let changed = false;
    for (const objective of quest.objectives) {
      const typeMatches = objective.type === type || (objective.type === 'cast_group' && type === 'cast_group');
      const targetMatches = objective.targetId === targetId || (objective.type === 'cast_group' && objective.targetId === targetId);
      if (!typeMatches || !targetMatches) continue;
      state.progress[objective.id] = objective.type === 'social_threshold' ? clamp(Number(amount||0),0,objective.amount) : clamp(Number(state.progress[objective.id] || 0) + amount, 0, objective.amount);
      changed = true;
    }
    if (changed) {
      if (questReady(quest.id)) { state.status = 'ready'; toast(`${quest.name}: objectives complete. Return to the quest giver.`); }
      runtime.trackedQuestId = quest.id;
    }
  }
  renderQuestTracker();
}

function refreshCollectObjectives(itemId) {
  const char = runtime.character;
  if (!char) return;
  for (const quest of DATA.quests) {
    const state = char.quests[quest.id];
    if (!state || !['active', 'ready'].includes(state.status)) continue;
    for (const objective of quest.objectives.filter(objective => objective.type === 'collect' && objective.targetId === itemId)) state.progress[objective.id] = Math.min(inventoryQuantity(itemId), objective.amount);
    if (questReady(quest.id)) state.status = 'ready';
    else if (state.status === 'ready') state.status = 'active';
  }
  renderQuestTracker();
}

function nearestInteraction() {
  const char = runtime.character;
  if (!char) return null;
  const options = [];
  for (const pile of runtime.ground.filter(entry => entry.z === char.z)) {
    const distance = manhattan(char, pile);
    if (distance <= 1) options.push({ kind: 'ground', entity: pile, distance, label: `Loot ${pile.name || itemOf(pile.itemId)?.name || 'items'}` });
  }
  for (const npc of DATA.npcs.filter(npc => npc.z === char.z && npcVisibleToCharacter(npc, char))) {
    const distance = manhattan(char, npc);
    if (distance <= 1) options.push({ kind: 'npc', entity: npc, distance, label: `Talk to ${npc.name}` });
  }
  for (const place of DATA.placements.filter(place => placementOnActiveMap(place)&&place.z === char.z && (!place.profileId || place.profileId === char.id))) {
    const distance = manhattan(char, place);
    if (distance <= 1) options.push({ kind: 'placement', entity: place, distance, label: interactionLabel(place) });
  }
  for (const furniture of char.furniturePlacements.filter(place => place.z === char.z && (place.itemId === 'depot_box' || ['reed_bed', 'canopy_bed', 'caravan_cot'].includes(place.itemId)))) {
    const distance = manhattan(char, furniture);
    const kind = furniture.itemId === 'depot_box' ? 'depot' : 'rest';
    if (distance <= 1) options.push({ kind, entity: furniture, distance, label: kind === 'depot' ? 'Open house depot box' : 'Rest in bed' });
  }
  options.sort((a, b) => a.distance - b.distance || ({ ground: 0, npc: 1, depot: 2, placement: 3 }[a.kind] - { ground: 0, npc: 1, depot: 2, placement: 3 }[b.kind]));
  return options[0] || null;
}

function interactionLabel(place) {
  if (place.type === 'rope_spot') return 'Use rope spot';
  if (place.type === 'hole') return 'Descend into Wormburrow';
  if (place.type === 'stairs_up') return 'Climb stairs up';
  if (place.type === 'stairs_down') return 'Descend stairs';
  if (place.entityId === 'broken_bridge') return runtime.character?.flags?.bridgeRepaired ? 'Inspect repaired bridge' : 'Repair broken bridge';
  if (place.type === 'house_door') return 'Open house controls';
  if (place.type === 'depot') return 'Open unlimited depot storage';
  if (place.type === 'well') return 'Drink, refill Thirst, and heal 1 HP';
  if (place.type === 'mage_tower') return 'Open Starveil Tower property controls';
  if (place.type === 'tower_fountain') return 'Use owner fountain for 5 HP';
  if (place.type === 'guildhall') return 'Open Dawnroad Guildhall controls';
  if (place.type === 'tailoring') return 'Open Tailoring workbench';
  if (place.type === 'rest') return 'Rest and refill Rest';
  if (place.type === 'mailbox') return 'Check the room mailbox';
  if (place.type === 'training') return 'Practice combat or magic';
  if (place.type === 'room_pet') return 'Greet the room-bound pet';
  if (place.type === 'rune_dispenser') return 'Collect produced runes';
  if (place.type === 'tower_archive') return 'Open the owner archive';
  if (place.type === 'tower_lockbox') return 'Practice lockpicking while sneaking';
  if (place.type === 'tower_portal') return 'Return to Anchorage Harbor';
  if (place.type === 'resource') return `${place.skillId === 'mining' ? 'Mine' : 'Cut'} ${place.label}`;
  if (place.type === 'fishing') return `Fish at ${place.label}`;
  if (place.type === 'smithing_station') return `Use ${place.label}`;
  return place.label || 'Interact';
}

function restCharacter(label = 'bed') {
  const char = runtime.character; if (!char) return;
  const survival = ensureSurvival(char); survival.rest = Number(gameRule('survival_rules').restRestore ?? 100); survival.warnedRest = false;
  effectAt(char.x, char.y, '#b79de8', 'ring', 1); toast(`You rest at the ${label}. Rest is fully restored.`);
  renderAllUi(); saveGame(false);
}

function interact() {
  if (runtime.modalOpen || !runtime.character) return;
  const looted = lootNearbyGrid();
  if (looted > 0) return;
  const interaction = nearestInteraction();
  if (!interaction) { toast('Nothing is close enough to interact with.'); return; }
  if (interaction.kind === 'ground') lootGround(interaction.entity);
  if (interaction.kind === 'npc') openNpc(interaction.entity);
  if (interaction.kind === 'depot') openDepot();
  if (interaction.kind === 'rest') restCharacter();
  if (interaction.kind === 'placement') interactPlacement(interaction.entity);
}

function lootNearbyGrid() {
  const char = runtime.character;
  const radius = Number(gameRule('world_rules').autoLootRadius ?? 1);
  const piles = runtime.ground.filter(pile => pile.z === char.z && Math.abs(pile.x - char.x) <= radius && Math.abs(pile.y - char.y) <= radius);
  let collected = 0;
  for (const pile of [...piles]) collected += lootGround(pile, { silent: true, deferRender: true });
  if (collected > 0) {
    renderAllUi(); saveGame(false);
    toast(`Auto-looted ${collected} item${collected === 1 ? '' : 's'} from the surrounding 3×3 area.`);
  }
  return collected;
}

function lootGround(pile, options = {}) {
  const char = runtime.character;
  let collected = 0;
  if (pile.type === 'bag') {
    const remaining = [];
    for (const stack of pile.items) {
      if (addItem(stack.id, stack.qty, char, true)) collected += stack.qty;
      else remaining.push(stack);
    }
    pile.items = remaining;
    if (!remaining.length) {
      char.flags.haulBagLooted = true;
      runtime.ground.splice(runtime.ground.indexOf(pile), 1);
      if (!options.silent) toast('Bag looted. The rope spot is north.');
    }
  } else {
    if (pile.itemId === 'gold_piece') {
      collected = pile.qty; char.gold += pile.qty;
      if (!options.silent) toast(`Picked up ${pile.qty} gold pieces.`);
      runtime.ground.splice(runtime.ground.indexOf(pile), 1);
    } else if (addItem(pile.itemId, pile.qty, char, true,{provenance:pile.provenanceRecords?.[0],sourceType:'ground_pickup',sourceId:pile.id,reason:'picked up from ground'})) {
      collected = pile.qty;
      if (!options.silent) toast(`Picked up ${pile.qty} × ${itemOf(pile.itemId)?.name}.`);
      runtime.ground.splice(runtime.ground.indexOf(pile), 1);
    }
  }
  if (!options.deferRender) { renderAllUi(); saveGame(false); }
  return collected;
}

function interactPlacement(place) {
  const char = runtime.character;
  if (place.requiresHouseId && !char.houseIds.includes(place.requiresHouseId)) { toast('This room feature is locked until this character purchases the floor.', true); playSfx('error'); return; }
  if (place.type === 'depot') {
    openDepot(); return;
  } else if (place.type === 'well') {
    const survival = ensureSurvival(char); survival.thirst = Number(gameRule('survival_rules').wellThirstRestore ?? 100); survival.warnedThirst = false;
    const healed = Math.min(1, char.maxHp - char.hp); char.hp += healed;
    effectAt(place.x, place.y, '#63bfd5', 'ring', 1); floatText(char.x, char.y, `+${healed}`, 'heal'); playSfx('heal'); queueGameEvent('cottage_well_used', { objectId: place.entityId, hp: healed });
    toast(`Cool well water refills Thirst${healed ? ' and restores 1 HP' : '; health is already full'}.`);
  } else if (place.type === 'mage_tower') {
    openMageTower(); return;
  } else if (place.type === 'tower_fountain') {
    const ownsRoom = DATA.mageTowerFloors.some(floor => char.houseIds.includes(floor.id));
    if (!ownsRoom) { toast('The Starveil fountain answers only a tower-room owner.', true); playSfx('error'); return; }
    const multiplier=Number(vocationOf(char)?.fountainRegenMultiplier||10),healed=Math.min(classRegen('health',char)*multiplier,char.maxHp-char.hp),mana=Math.min(classRegen('mana',char)*multiplier,char.maxMana-char.mana);char.hp+=healed;char.mana+=mana;floatText(char.x,char.y,`+${healed.toFixed(2)} HP`,'heal');effectAt(place.x,place.y,'#78cde1','ring',2);playSfx('heal');queueGameEvent('healing_fountain_used',{objectId:place.entityId,hp:healed,mana});
    toast(`The class-scaled fountain restores ${healed.toFixed(2)} HP and ${mana.toFixed(2)} mana.`);
  } else if (place.type === 'guildhall') {
    openGuildhall(); return;
  } else if (place.type === 'tailoring') {
    openTailoring(); return;
  } else if (place.type === 'rune_dispenser') {
    collectRuneDispenser(place.entityId); return;
  } else if (place.type === 'mailbox') {
    openModal('ROOM MAILBOX', place.label, '<div class="info-card"><h3>Persistent correspondence slot</h3><p>The mailbox identity and message payloads are data-driven and available to the shared server. No new letters are waiting.</p></div>'); return;
  } else if (place.type === 'room_pet') {
    trainSkill('animal_care', 4); effectAt(place.x, place.y, '#d8b879', 'ring', 1); toast('Your room pet follows you around this room, then settles back by its cushion.');
  } else if (place.type === 'training') {
    trainSkill(char.equipment.weapon ? itemOf(char.equipment.weapon)?.weaponSkill || 'attack' : 'magic', 18); effectAt(place.x, place.y, '#e0ad50', 'burst', 1); toast('The training dummy records a clean practice strike.');
  } else if (place.type === 'tower_archive') {
    if (!DATA.mageTowerFloors.some(floor => char.houseIds.includes(floor.id))) { toast('The archive shelves reject anyone who owns no Starveil room.', true); return; }
    if (!char.flags.towerArchiveClaimed) { char.flags.towerArchiveClaimed = true; for (const [id, qty] of [['great_emberburst_rune', 10], ['sovereign_mending_rune', 10], ['sudden_death_rune', 10], ['avalanche_rune', 10]]) addItem(id, qty, char, true); toast('The archive grants its owner rune collection.'); }
    else toast('The archive remains open for rune, scroll and staff practice.');
    trainSkill('magic', 16); trainSkill('runecraft', 10);
  } else if (place.type === 'tower_lockbox') {
    if (!char.flags.sneaking) { toast('Crouch with C before practicing on a guarded lockbox.', true); return; }
    const seen = DATA.npcs.some(npc => npc.z === char.z && npc.role?.includes('archive guard') && manhattan(npc, char) <= 6);
    if (seen) { char.x = 18; char.y = 46; char.z = 0; runtime.path = []; runtime.camera.x = char.x; runtime.camera.y = char.y; char.flags.sneaking = false; playSfx('error'); toast('An archive guard catches you and sends you back to town.', true); }
    else { trainSkill('lockpicking', 28); trainSkill('stealth', 18); trainSkill('thievery', 12); toast('Lock practice succeeds unseen. Lockpicking, Stealth and Thievery improve.'); }
  } else if (place.type === 'tower_portal') {
    char.x = 18; char.y = 46; char.z = 0; runtime.path = []; runtime.camera.x = char.x; runtime.camera.y = char.y; playSfx('portal'); toast('The archive portal returns you to Anchorage Harbor.');
  } else if (place.type === 'rest') {
    restCharacter(place.label); return;
  } else if (place.type === 'resource') {
    char.flags.resourceReady = char.flags.resourceReady || {};
    const readyAt = Number(char.flags.resourceReady[place.id] || 0);
    if (readyAt > Date.now()) { toast(`${place.label} is recovering for ${Math.ceil((readyAt - Date.now()) / 1000)} more seconds.`, true); return; }
    const hasTool = inventoryQuantity(place.toolId) > 0 || Object.values(char.equipment || {}).includes(place.toolId);
    if (!hasTool) { toast(`You need ${itemOf(place.toolId)?.name || place.toolId}.`, true); return; }
    const skillLevel = char.skills?.[place.skillId]?.level || 1; const qty = 1 + Math.floor(skillLevel / 40);
    if (!addItem(place.yieldItemId, qty, char, true,{sourceType:'player_gathered',sourceId:place.entityId,reason:`${place.skillId} harvest`})) { toast('Your carried load is too heavy for the gathered material.', true); return; }
    trainSkill(place.skillId, 28 + skillLevel * .12); trainSkill('labouring', 22 + qty * 3); trainSkill('strength', 7 + qty * 2);
    char.flags.resourceReady[place.id] = Date.now() + Number(place.respawnSeconds || 20) * 1000;
    effectAt(place.x, place.y, place.skillId === 'mining' ? '#c6b58e' : '#79aa66', 'burst', 1);
    toast(`${place.skillId === 'mining' ? 'Mined' : 'Cut'} ${qty} × ${itemOf(place.yieldItemId)?.name}. Labouring also improved.`);
  } else if(place.type==='fishing'){
    const hasRod=inventoryQuantity(place.toolId)>0||Object.values(char.equipment||{}).includes(place.toolId);if(!hasRod){toast(`You need ${itemOf(place.toolId)?.name||'a fishing rod'}.`,true);return;}
    char.flags.resourceReady=char.flags.resourceReady||{};const readyAt=Number(char.flags.resourceReady[place.id]||0);if(readyAt>Date.now()){toast(`The water settles in ${Math.ceil((readyAt-Date.now())/1000)} seconds.`);return;}
    const table=byId(DATA.fishingDropTables,place.dropTableId),skill=char.skills?.fishing?.level||1,eligible=(table?.fishEntries||[]).filter(entry=>skill>=Number(entry.minLevel||1));let roll=Math.random()*eligible.reduce((sum,entry)=>sum+Number(entry.weight||0),0),fish=eligible[0];for(const entry of eligible){roll-=Number(entry.weight||0);if(roll<=0){fish=entry;break;}}
    if(fish)addItem(fish.itemId,1,char,true,{sourceType:'player_fished',sourceId:place.entityId,reason:'caught while fishing'});
    let gearMessage='';if(table&&Math.random()<Number(table.gearRollChance||0)){const gearId=table.gearItemIds[Math.floor(Math.random()*table.gearItemIds.length)],gear=itemOf(gearId),value=Number(gear?.buy||0),rarity=value>=1500?'legendary':value>=600?'rare':value>=180?'uncommon':'common',bounds={common:[100,400],uncommon:[300,650],rare:[600,900],legendary:[850,1000]}[rarity],itemLevel=Math.floor(bounds[0]+Math.random()*(bounds[1]-bounds[0]+1));if(addItem(gearId,1,char,true,{sourceType:'player_fished',sourceId:place.entityId,reason:`${rarity} fishing equipment roll`,itemLevel}))gearMessage=` and found ${gear.icon} ${gear.name} at item level ${itemLevel}`;}
    trainSkill('fishing',30+skill*.2);trainSkill('labouring',8);char.flags.resourceReady[place.id]=Date.now()+Number(place.respawnSeconds||2)*1000;effectAt(place.x,place.y,'#55a9ca','ring',1);toast(`Caught ${itemOf(fish?.itemId)?.name||'nothing'}${gearMessage}.`);
  } else if(place.type==='smithing_station'){
    openSmithingForge();return;
  } else if (['stairs_up', 'stairs_down', 'door'].includes(place.type)) {
    char.x = place.targetX; char.y = place.targetY; char.z = place.targetZ;
    runtime.path = []; runtime.camera.x = char.x; runtime.camera.y = char.y;
    if (place.entityId === 'silkfall_exit') progressQuestEvent('interact', 'silkfall_exit', 1);
    toast(`${place.label}: now on floor ${char.z}.`);
  } else if (place.type === 'hole') {
    char.x = place.targetX; char.y = place.targetY; char.z = place.targetZ; runtime.path = []; runtime.camera.x = char.x; runtime.camera.y = char.y;
    if (place.entityId === 'worm_hole') progressQuestEvent('visit', 'wormburrow', 1);
    toast(`You descend into ${place.label || 'the hollow'}. Keep a rope or Ropecall ready.`);
  } else if (place.type === 'rope_spot') {
    if (!inventoryQuantity('rope') && !inventoryQuantity('troll_rope') && char.level < 8) { toast('You need a climbing rope, troll rope, or level 8 Ropecall.', true); return; }
    char.x = place.targetX; char.y = place.targetY; char.z = place.targetZ; runtime.path = []; runtime.camera.x = char.x; runtime.camera.y = char.y;
    if (place.entityId === 'rope_spot') progressQuestEvent('interact', 'rope_spot', 1);
    toast(place.entityId === 'rope_spot' ? 'You climb out beside Bram’s trader. The furniture shop is east along the clear road.' : `You rope up from ${place.label || 'the hollow'}.`);
  } else if (place.entityId === 'wheat_patch') {
    addItem('wheat', 1); progressQuestEvent('interact', 'wheat_patch', 1);
  } else if (place.entityId === 'millstone') {
    if (!removeItem('wheat', 1)) { toast('Harvest Sunwheat first.', true); return; }
    addItem('flour', 1); progressQuestEvent('interact', 'millstone', 1);
  } else if (place.entityId === 'bread_oven') {
    if (!removeItem('flour', 1)) { toast('Grind a wheat bundle at the millstone first.', true); return; }
    addItem('bread', 1); progressQuestEvent('interact', 'bread_oven', 1);
  } else if (place.entityId === 'training_dummy') {
    char.zeal = Math.min(char.maxZeal || 5, (char.zeal || 0) + (char.vocationId === 'warhealer' ? 1 : 0));
    trainSkill(char.equipment.weapon ? itemOf(char.equipment.weapon)?.weaponSkill || 'attack' : 'attack', 18);
    progressQuestEvent('interact', 'training_dummy', 1); effectAt(char.x, char.y, '#e0ad50', 'burst', 1);
  } else if (place.entityId === 'dead_tree') {
    if (!char.flags.deadTreeSearched) { char.flags.deadTreeSearched = true; addItem('iron_shield', 1); }
    progressQuestEvent('interact', 'dead_tree', 1);
  } else if (place.entityId === 'broken_bridge') {
    if (char.flags.bridgeRepaired) { toast('The Ironwood bridge is firm and passable.'); return; }
    if (inventoryQuantity('ironwood_beam') < 3) { toast('Three Ironwood Beams are required. Scrap Trolls and Cave Beetles carry them.', true); return; }
    removeItem('ironwood_beam', 3); char.flags.bridgeRepaired = true; progressQuestEvent('interact', 'broken_bridge', 1); toast('Bridge repaired. Crucible Reach is now open.');
  } else if (place.entityId === 'fallen_scout') {
    if (char.mana >= 16) char.mana -= 16;
    else if (!removeItem('minor_potion', 1)) { toast('You need at least 16 mana or a Roseglass Tonic.', true); return; }
    progressQuestEvent('interact', 'fallen_scout', 1); effectAt(place.x, place.y, '#71d796', 'ring', 1);
  } else if (place.entityId === 'light_shrine') {
    if (!inventoryQuantity('sacred_relic')) { toast('The shrine requires a Tideworn Reliquary.', true); return; }
    char.statuses.blessedUntil = Date.now() + 120000; progressQuestEvent('interact', 'light_shrine', 1); effectAt(place.x, place.y, '#f1d76a', 'ring', 3); toast('First Light blessing: +10% damage and healing for two minutes.');
  } else if (place.type === 'readable') {
    progressQuestEvent('interact', place.entityId, 1);
    const index = place.entityId.slice(-1); openModal('EXPEDITION RECORD', `Captain’s Log ${index}`, `<div class="info-card"><p>${index === '1' ? 'The Canopy bridge was never meant to keep people out. It was meant to teach preparation.' : index === '2' ? 'We found the Brute Mystic listening to something beneath the ruined stones. The sea itself seemed to answer.' : 'Silkfall is not a dead end. The highest nest opens south onto the old road to Dawnreach.'}</p></div>`);
  } else if (place.type === 'relic' || place.type === 'landmark') {
    progressQuestEvent('interact', place.entityId, 1);
    effectAt(place.x, place.y, place.type === 'relic' ? '#d5b7ef' : '#e6c56e', 'ring', 2);
    toast(place.type === 'relic' ? `${place.label} recovered. Its expedition quest can now be turned in.` : `${place.label} inspected.`);
  } else if (place.type === 'house_door') openHouse(place.entityId);
  renderAllUi(); saveGame(false);
}

function allTowerRoomsPurchased() {
  const purchased = runtime.save.world.purchasedHouses || {};
  return DATA.mageTowerFloors.every(floor => Boolean(purchased[floor.id]));
}

function updateRuneDispenser(dispenser) {
  runtime.save.world.dispenserState = runtime.save.world.dispenserState || {};
  const now = Date.now(); const allOwned = allTowerRoomsPurchased(); const intervalMs = Number(dispenser.intervalSeconds || 30) * (allOwned ? 500 : 1000);
  const state = runtime.save.world.dispenserState[dispenser.id] || { lastProducedAt: now - intervalMs, stock: {} };
  const cycles = Math.max(0, Math.floor((now - Number(state.lastProducedAt || now)) / intervalMs));
  if (cycles > 0) {
    for (const [itemId, perCycle] of Object.entries(dispenser.outputs)) state.stock[itemId] = Math.min(Number(dispenser.maxStack || 999), Number(state.stock[itemId] || 0) + cycles * Number(perCycle));
    state.lastProducedAt += cycles * intervalMs;
  }
  runtime.save.world.dispenserState[dispenser.id] = state; return { state, intervalMs };
}

function collectRuneDispenser(dispenserId) {
  const char = runtime.character; const dispenser = byId(DATA.runeDispensers, dispenserId); if (!char || !dispenser) return;
  if (!char.houseIds.includes(dispenser.floorId)) { toast('Only the owner of this room can collect its rune press.', true); return; }
  const { state } = updateRuneDispenser(dispenser); let collected = 0;
  for (const [itemId, qty] of Object.entries(state.stock)) {
    if (qty <= 0) continue;
    if (addItem(itemId, qty, char, true)) { collected += qty; state.stock[itemId] = 0; }
  }
  if (!collected) toast('The rune press has nothing ready or your backpack is full.', true);
  else { queueGameEvent('tower_runes_collected', { dispenserId, quantity: collected }); playSfx('craft'); toast(`${collected} produced runes collected.`); }
  saveGame(false); openMageTower();
}

function openMageTower() {
  const char = runtime.character; if (!char) return;
  runtime.save.world.purchasedHouses = runtime.save.world.purchasedHouses || {};
  const allOwned = allTowerRoomsPurchased();
  const floors = DATA.mageTowerFloors.map(floor => {
    const ownerId = runtime.save.world.purchasedHouses[floor.id] || null; const mine = char.houseIds.includes(floor.id); const dispenser = DATA.runeDispensers.find(row => row.floorId === floor.id); const { state, intervalMs } = updateRuneDispenser(dispenser);
    const stock = Object.entries(state.stock).filter(([, qty]) => qty > 0).map(([id, qty]) => `${itemOf(id)?.name || id} × ${qty}`).join(', ') || 'empty';
    return `<article class="quest-card ${mine ? 'ready' : ownerId ? 'complete' : 'available'}"><b>FLOOR ${floor.floorNumber}<br>${number(floor.price)} GP</b><div><h3>${escapeHtml(floor.name)}</h3><p>${ownerId ? `Owner: ${escapeHtml(runtime.save.characters.find(row => row.id === ownerId)?.name || ownerId)}` : 'Available to one character'} · ${escapeHtml(byId(DATA.butlers, floor.butlerId)?.name || 'Butler')} · press every ${Math.round(intervalMs / 1000)}s · stock ${escapeHtml(stock)}</p></div>${!ownerId ? `<button data-buy-tower-floor="${floor.id}" ${char.gold < floor.price ? 'disabled' : ''}>BUY</button>` : mine ? `<button data-collect-dispenser="${dispenser.id}">COLLECT</button>` : '<button disabled>OCCUPIED</button>'}</article>`;
  }).join('');
  const ownsAny = DATA.mageTowerFloors.some(floor => char.houseIds.includes(floor.id));
  openModal('FIVE-FLOOR PROPERTY', 'Starveil Mage Tower', `<div class="info-card"><h3>${allOwned ? 'Full tower covenant active' : 'Five separately owned rooms'}</h3><p>Every room is now a physical floor with stairs, an endless depot, bed, mailbox, personal butler, training dummy, room-bound pet and rune press. ${allOwned ? 'All presses run at double speed and the sealed portal is open.' : 'Buy all five across your characters to double every press and unlock the completed-tower portal.'}</p><button id="towerEnter">ENTER PHYSICAL TOWER</button>${ownsAny ? ' <button id="towerRest">REST IN OWNED ROOM</button> <button id="towerDepot">OPEN ENDLESS DEPOT</button> <button id="towerArchive">ENTER BASEMENT ARCHIVE</button>' : ''}${allOwned ? ' <button id="towerPortal">USE SEALED PORTAL</button>' : ''}</div><div class="quest-list" style="margin-top:12px">${floors}</div>`, 'wide');
  document.getElementById('towerEnter')?.addEventListener('click', () => { char.x = 32; char.y = 37; char.z = -1; runtime.path = []; runtime.camera.x = char.x; runtime.camera.y = char.y; closeModal(); playSfx('portal'); toast('You enter Starveil Tower room 1. Use the stairs to visit all five floors and the archive.'); });
  document.querySelectorAll('[data-buy-tower-floor]').forEach(button => button.addEventListener('click', () => {
    const floor = byId(DATA.mageTowerFloors, button.dataset.buyTowerFloor); if (!floor || char.gold < floor.price || runtime.save.world.purchasedHouses[floor.id]) return;
    char.gold -= floor.price; char.houseIds.push(floor.id); runtime.save.world.purchasedHouses[floor.id] = char.id; queueGameEvent('tower_room_acquired', { floorId: floor.id, price: floor.price }); playSfx('buy'); saveGame(false); openMageTower();
  }));
  document.querySelectorAll('[data-collect-dispenser]').forEach(button => button.addEventListener('click', () => collectRuneDispenser(button.dataset.collectDispenser)));
  document.getElementById('towerRest')?.addEventListener('click', () => restCharacter('Starveil room bed'));
  document.getElementById('towerDepot')?.addEventListener('click', openDepot);
  document.getElementById('towerArchive')?.addEventListener('click', () => {
    char.x = 30; char.y = 37; char.z = -6; runtime.path = []; runtime.camera.x = char.x; runtime.camera.y = char.y; closeModal(); playSfx('portal'); toast('You enter the guarded Starveil archive. Crouch before practicing on its locks.');
  });
  document.getElementById('towerPortal')?.addEventListener('click', () => { char.x = 18; char.y = 46; char.z = 0; runtime.camera.x = char.x; runtime.camera.y = char.y; runtime.path = []; closeModal(); playSfx('portal'); toast('The completed-tower portal returns you to Anchorage Harbor.'); });
}

function openGuildhall() {
  const char = runtime.character; if (!char) return;
  const guild = byId(DATA.houses, 'house_dawnroad_guild'); const owned = char.houseIds.includes(guild.id); const available = allTowerRoomsPurchased();
  openModal('GUILD PROPERTY', guild.name, `<div class="modal-grid"><article class="info-card"><h3>${owned ? 'Owned guild compound' : available ? 'Available for purchase' : 'Tower covenant required'}</h3><p>${escapeHtml(guild.description)}</p><ul><li>Price: ${number(guild.price)} gold</li><li>Eight independent lever cages in the basement arena</li><li>Guild rooms, shops, depot, mailbox, beds and practice areas</li></ul><button id="buyGuildhall" ${owned || !available || char.gold < guild.price ? 'disabled' : ''}>${owned ? 'OWNED' : 'BUY GUILDHALL'}</button></article><article class="info-card"><h3>Arena control</h3><p>${owned ? 'Each cage lever deletes its own gate and releases only that cage. Arena state is tracked in world flags.' : 'Purchase the guild to operate the arena.'}</p>${owned ? Array.from({ length: 8 }, (_, index) => `<button data-arena-cage="${index + 1}" ${runtime.save.world.globalFlags[`guild_cage_${index + 1}_open`] ? 'disabled' : ''}>CAGE ${index + 1}</button>`).join(' ') : ''}</article></div>`, 'wide');
  document.getElementById('buyGuildhall')?.addEventListener('click', () => {
    if (!available || owned || char.gold < guild.price) return;
    char.gold -= guild.price; char.houseIds.push(guild.id); runtime.save.world.purchasedHouses[guild.id] = char.id; queueGameEvent('guildhall_acquired', { houseId: guild.id, price: guild.price }); playSfx('buy'); saveGame(false); openGuildhall();
  });
  document.querySelectorAll('[data-arena-cage]').forEach(button => button.addEventListener('click', () => {
    const cage = Number(button.dataset.arenaCage); runtime.save.world.globalFlags[`guild_cage_${cage}_open`] = true;
    const monsterIds = ['mob_scavenger_rat', 'mob_venom_spider', 'mob_timber_wolf', 'mob_goblin_slinger', 'mob_ash_raider', 'mob_horned_brute', 'mob_silk_tarantula', 'boss_brood_tyrant'];
    spawnMonster(monsterIds[cage - 1], 26 + cage % 4, 61 + Math.floor((cage - 1) / 4), 0, { homeX: 26 + cage % 4, homeY: 61 + Math.floor((cage - 1) / 4), respawnSeconds: 300 });
    queueGameEvent('guild_arena_cage_opened', { cage }); playSfx('portal'); saveGame(false); openGuildhall();
  }));
}

function openNpc(npc) {
  applySocialEvent('event_friendly_conversation');
  if (npc.id === 'npc_ferryman') progressQuestEvent('interact', 'npc_ferryman', 1);
  const questRows = npc.quests.map(id => {
    const quest = questOf(id); const state = runtime.character.quests[id];
    const unmet = (quest.prerequisite || []).some(required => runtime.character.quests[required]?.status !== 'complete') || !socialRequirementsMet(quest,runtime.character);
    const button = state.status === 'available' ? `<button data-accept-quest="${id}" ${unmet ? 'disabled' : ''}>${unmet ? 'LOCKED' : 'ACCEPT'}</button>` : questReady(id) ? `<button data-complete-quest="${id}">TURN IN</button>` : `<button data-track-quest="${id}">${state.status === 'complete' ? 'COMPLETE' : 'TRACK'}</button>`;
    return `<article class="quest-card ${state.status}"><b>${id}<br>LV ${quest.recommendedLevel}</b><div><h3>${escapeHtml(quest.name)}</h3><p>${escapeHtml(quest.description)}</p></div>${button}</article>`;
  }).join('');
  const tradeButton = npc.shop ? `<button class="secondary-button" data-open-shop="${npc.shop}">OPEN ${escapeHtml(byId(DATA.shops, npc.shop)?.name || 'SHOP')}</button>` : '';
  const houseButton = npc.id === 'npc_edda' ? `<button class="secondary-button" data-house-broker="house_tideglass">VIEW TIDEGLASS COTTAGE</button>` : npc.id === 'npc_tower_steward' ? '<button class="secondary-button" id="openTowerFromNpc">OPEN STARVEIL TOWER</button>' : npc.id === 'npc_guild_factor' ? '<button class="secondary-button" id="openGuildFromNpc">OPEN GUILDHALL</button>' : npc.id === 'npc_commons_keeper' ? '<button class="secondary-button" id="openVillageStore">OPEN SHARED VILLAGE STORE</button>' : '';
  openModal(npc.role.toUpperCase(), npc.name, `<div class="info-card"><p>${escapeHtml(npc.description)}</p></div><div class="quest-list" style="margin-top:12px">${questRows || '<p>No quests here.</p>'}</div><div style="display:flex;gap:7px;margin-top:12px">${tradeButton}${houseButton}</div>`, 'wide');
  document.querySelectorAll('[data-accept-quest]').forEach(button => button.addEventListener('click', () => acceptQuest(button.dataset.acceptQuest)));
  document.querySelectorAll('[data-complete-quest]').forEach(button => button.addEventListener('click', () => completeQuest(button.dataset.completeQuest)));
  document.querySelectorAll('[data-track-quest]').forEach(button => button.addEventListener('click', () => { runtime.trackedQuestId = button.dataset.trackQuest; renderQuestTracker(); closeModal(); }));
  document.querySelectorAll('[data-open-shop]').forEach(button => button.addEventListener('click', () => openShop(button.dataset.openShop)));
  document.querySelectorAll('[data-house-broker]').forEach(button => button.addEventListener('click', () => openHouseBroker(button.dataset.houseBroker)));
  document.getElementById('openTowerFromNpc')?.addEventListener('click', openMageTower);
  document.getElementById('openGuildFromNpc')?.addEventListener('click', openGuildhall);
  document.getElementById('openVillageStore')?.addEventListener('click', () => openVillageStore('store_anchorage_commons'));
}

function openShop(shopId) {
  const shop = byId(DATA.shops, shopId); const char = runtime.character;
  if (!shop || !char) return;
  char.ownedMounts = char.ownedMounts || [];
  const itemBuyRows = (shop.sells || []).map(id => itemOf(id)).filter(Boolean).map(item => `<div class="shop-row"><i style="color:${item.color || '#d8a94d'}">${item.icon}</i><span><strong>${escapeHtml(item.name)}</strong><small>${item.weight || 0} oz · ${item.type}</small></span><button data-buy-item="${item.id}" ${char.gold < item.buy ? 'disabled' : ''}>${number(item.buy)} GP</button></div>`).join('');
  const mountRows = (shop.mounts || []).map(id => byId(DATA.mounts, id)).filter(Boolean).map(mount => {
    const owned = char.ownedMounts.includes(mount.id); const allowed = mount.usableBy?.includes('all') || mount.usableBy?.includes(char.vocationId);
    return `<div class="shop-row mount-row"><i>${mount.icon}</i><span><strong>${escapeHtml(mount.name)}</strong><small>Mount · +${Math.round(mount.speedBonus * 100)}% travel speed</small></span><button data-buy-mount="${mount.id}" ${!allowed || (!owned && char.gold < mount.price) ? 'disabled' : ''}>${!allowed ? 'WRONG CLASS' : owned ? char.mountId === mount.id ? 'EQUIPPED' : 'EQUIP' : `${number(mount.price)} GP`}</button></div>`;
  }).join('');
  const buyRows = itemBuyRows + mountRows || '<div class="target-empty">No stock is listed.</div>';
  const sellable = char.inventory.map((stack, index) => ({ stack, index, item: itemOf(stack.id) })).filter(row => row.item && shop.buys.includes(row.item.id) && row.item.sell > 0);
  const sellRows = sellable.map(row => `<div class="shop-row"><i style="color:${row.item.color || '#d8a94d'}">${row.item.icon}</i><span><strong>${escapeHtml(row.item.name)} × ${row.stack.qty}</strong><small>${number(row.item.sell)} gp each</small></span><button data-sell-index="${row.index}">SELL ${number(row.item.sell * row.stack.qty)}</button></div>`).join('') || '<div class="target-empty">Nothing in this backpack is bought here.</div>';
  openModal('BUTTON-DRIVEN TRADE', shop.name, `<div class="merchant-layout"><section class="shop-column"><header><span>BUY</span><b>${number(char.gold)} GP</b></header><div class="shop-list">${buyRows}</div></section><section class="shop-column"><header><span>SELL</span><b>YOUR BACKPACK</b></header><div class="shop-list">${sellRows}</div></section></div>`, 'wide');
  document.querySelectorAll('[data-buy-item]').forEach(button => button.addEventListener('click', () => {
    const item = itemOf(button.dataset.buyItem);
    if (!item || char.gold < item.buy) return;
    if (addItem(item.id,1,char,true,{sourceType:'server_merchant',sourceId:shopId,reason:`purchased from ${shop.name}`})){char.gold-=item.buy;queueGameEvent('shop_buy',{shopId,itemId:item.id,quantity:1,value:item.buy});playSfx('buy');toast(`Bought ${item.name} for ${item.buy} gp.`);renderHud();openShop(shopId);saveGame(false);}
  }));
  document.querySelectorAll('[data-buy-mount]').forEach(button => button.addEventListener('click', () => {
    const mount = byId(DATA.mounts, button.dataset.buyMount); if (!mount) return;
    if (!char.ownedMounts.includes(mount.id)) { if (char.gold < mount.price) return; char.gold -= mount.price; char.ownedMounts.push(mount.id); toast(`${mount.name} purchased and equipped.`); }
    else toast(`${mount.name} equipped. Use the mount button to ride.`);
    char.mountId = mount.id; char.mounted = false; renderAllUi(); openShop(shopId); saveGame(false);
  }));
  document.querySelectorAll('[data-sell-index]').forEach(button => button.addEventListener('click', () => {
    const index = Number(button.dataset.sellIndex); const stack = char.inventory[index]; const item = stack && itemOf(stack.id);
    if (!item || !shop.buys.includes(item.id)) return;
    const value = item.sell * stack.qty; char.gold += value; char.inventory.splice(index, 1);
    if (shopId === 'desert_merchant') progressQuestEvent('sell_value', 'desert_merchant', value);
    queueGameEvent('shop_sell', { shopId, itemId: item.id, quantity: stack.qty, value }); playSfx('sell'); toast(`Sold ${stack.qty} × ${item.name} for ${value} gp.`); renderAllUi(); openShop(shopId); saveGame(false);
  }));
}

async function villageStoreSnapshot(storeId) {
  runtime.save.world.villageStoreStock=runtime.save.world.villageStoreStock||{};
  if(location.protocol==='file:') { if(!runtime.save.world.villageStoreStock[storeId])runtime.save.world.villageStoreStock[storeId]=deepClone(byId(DATA.villageStores,storeId)?.defaultStock||{});return runtime.save.world.villageStoreStock[storeId]; }
  const result=await emberwakeServerApi('villageStore',{method:'GET'});return Object.fromEntries((result.items||[]).filter(row=>row.store_id===storeId).map(row=>[row.item_id,Number(row.quantity||0)]));
}

async function transferVillageStore(storeId,itemId,quantity,direction) {
  const char=runtime.character,qty=Math.max(1,Math.floor(Number(quantity||1)));if(!char)return;
  if(direction==='deposit'&&inventoryQuantity(itemId,char)<qty){toast('You do not have that many to deposit.',true);return;}
  try {
    if(location.protocol==='file:') { const stock=await villageStoreSnapshot(storeId);if(direction==='withdraw'&&Number(stock[itemId]||0)<qty)throw new Error('The shared store does not have that many.');stock[itemId]=Math.max(0,Number(stock[itemId]||0)+(direction==='deposit'?qty:-qty)); }
    else await emberwakeServerApi('transferVillageStore',{method:'POST',body:{storeId,itemId,quantity:qty,direction}});
    if(direction==='deposit'){removeItem(itemId,qty,char);applySocialEvent('event_generous_trade');}
    else if(!addItem(itemId,qty,char,true)){if(location.protocol!=='file:')await emberwakeServerApi('transferVillageStore',{method:'POST',body:{storeId,itemId,quantity:qty,direction:'deposit'}});throw new Error('Your backpack cannot hold that withdrawal.');}
    queueGameEvent(`village_store_${direction}`,{storeId,itemId,quantity:qty});saveGame(false);await openVillageStore(storeId);
  } catch(error){toast(error.message||'Village store transfer failed.',true,6000);}
}

async function openVillageStore(storeId='store_anchorage_commons') {
  const store=byId(DATA.villageStores,storeId),char=runtime.character;if(!store||!char)return;
  try { const stock=await villageStoreSnapshot(storeId);const stockRows=Object.entries(stock).filter(([,qty])=>qty>0).map(([itemId,qty])=>{const item=itemOf(itemId);return item?`<div class="shop-row"><i>${item.icon||'◆'}</i><span><strong>${escapeHtml(item.name)}</strong><small>${number(qty)} shared · all approved accounts</small></span><button data-store-withdraw="${itemId}">WITHDRAW 1</button></div>`:''}).join('')||'<div class="target-empty">The shared store is empty.</div>';const depositRows=char.inventory.filter(stack=>itemOf(stack.id)).map(stack=>`<div class="shop-row"><i>${itemOf(stack.id).icon||'◆'}</i><span><strong>${escapeHtml(itemOf(stack.id).name)}</strong><small>You carry ${stack.qty}</small></span><button data-store-deposit="${stack.id}">DEPOSIT 1</button></div>`).join('');openModal('ACCOUNT-SHARED CIVIC STORAGE',store.name,`<div class="info-card"><p>${escapeHtml(store.description)} Changes are synchronized by server session, not by character.</p></div><div class="modal-grid village-store-grid"><section><h3>SHARED STOCK</h3>${stockRows}</section><section><h3>YOUR BACKPACK</h3>${depositRows||'<div class="target-empty">Nothing to deposit.</div>'}</section></div>`,'wide');document.querySelectorAll('[data-store-withdraw]').forEach(button=>button.addEventListener('click',()=>transferVillageStore(storeId,button.dataset.storeWithdraw,1,'withdraw')));document.querySelectorAll('[data-store-deposit]').forEach(button=>button.addEventListener('click',()=>transferVillageStore(storeId,button.dataset.storeDeposit,1,'deposit'))); } catch(error){toast(error.message||'The shared village store is unavailable.',true,6000);}
}

function openHouseBroker(houseId) {
  const house = byId(DATA.houses, houseId); const char = runtime.character;
  if (!house) return;
  const owned = char.houseIds.includes(house.id);
  openModal('PROPERTY', house.name, `<div class="modal-grid"><div class="info-card"><h3>${escapeHtml(house.town)}</h3><p>${escapeHtml(house.description)}</p><ul><li>${house.width * house.height} interior tiles</li><li>${number(house.price)} gp purchase</li><li>${number(house.rent)} gp monthly server rent</li></ul></div><div class="info-card"><h3>${owned ? 'Owned' : 'Available'}</h3><p>${owned ? 'You already own this property. Use its door to place furniture.' : `You have ${number(char.gold)} gp.`}</p><button class="primary-button" id="buyHouseButton" ${owned || char.gold < house.price ? 'disabled' : ''}>${owned ? 'OWNED' : `BUY FOR ${number(house.price)} GP`}</button></div></div>`);
  document.getElementById('buyHouseButton')?.addEventListener('click', () => {
    if (char.gold < house.price || char.houseIds.includes(house.id)) return;
    char.gold -= house.price; char.houseIds.push(house.id); house.ownerCharacterId = char.id; runtime.save.world.purchasedHouses[house.id] = char.id;
    syncCottageResidents(char); progressQuestEvent('own', house.id, 1); toast(`${house.name} purchased. Edda and Tovin return outside, and Merrin with your training dummy are now inside.`); closeModal(); renderAllUi(); saveGame(false);
  });
}

function openHouse(houseId) {
  const house = byId(DATA.houses, houseId); const char = runtime.character;
  if (!house) return;
  const owned = char.houseIds.includes(house.id);
  const furniture = char.inventory.map((stack, index) => ({ stack, index, item: itemOf(stack.id) })).filter(row => row.item?.type === 'furniture');
  const hasDepot = char.furniturePlacements.some(place => place.houseId === house.id && place.itemId === 'depot_box');
  openModal('HOUSING', house.name, `<div class="info-card"><h3>${owned ? 'Your home' : 'Property locked'}</h3><p>${owned ? 'Select a furniture item below to place it on the next clear interior tile. All placements persist in JSON and MySQL save data.' : 'Speak to Edda Hearth outside to purchase this cottage.'}</p>${owned && hasDepot ? '<button class="primary-button" id="openHouseDepot">OPEN UNLIMITED DEPOT</button>' : owned ? '<p>Buy and place a House Depot Box here to access unlimited storage.</p>' : ''}</div>${owned ? `<div class="shop-list" style="margin-top:12px">${furniture.map(row => `<div class="shop-row"><i>${row.item.icon}</i><span><strong>${escapeHtml(row.item.name)}</strong><small>${row.item.type}</small></span><button data-place-furniture="${row.index}">PLACE</button></div>`).join('') || '<div class="target-empty">Buy furniture from Tovin Peg, directly east of the cottage.</div>'}</div>` : ''}`);
  document.getElementById('openHouseDepot')?.addEventListener('click', openDepot);
  document.querySelectorAll('[data-place-furniture]').forEach(button => button.addEventListener('click', () => placeFurniture(house, Number(button.dataset.placeFurniture))));
}

function addDepotStack(itemId, qty) {
  const char = runtime.character; char.depot = char.depot || [];
  const item = itemOf(itemId); const existing = item?.stackable ? char.depot.find(stack => stack.id === itemId) : null;
  if (existing) existing.qty += qty; else char.depot.push({ id: itemId, qty });
}

function openDepot() {
  const char = runtime.character; if (!char) return; char.depot = char.depot || [];
  const inventoryRows = char.inventory.map((stack, index) => ({ stack, index, item: itemOf(stack.id) })).filter(row => row.item).map(row => `<div class="shop-row"><i>${row.item.icon}</i><span><strong>${escapeHtml(row.item.name)} × ${row.stack.qty}</strong><small>${Math.round((row.item.weight || 0) * row.stack.qty)} oz carried</small></span><button data-depot-store="${row.index}">STORE</button></div>`).join('') || '<div class="target-empty">Backpack empty.</div>';
  const depotRows = char.depot.map((stack, index) => ({ stack, index, item: itemOf(stack.id) })).filter(row => row.item).map(row => `<div class="shop-row"><i>${row.item.icon}</i><span><strong>${escapeHtml(row.item.name)} × ${row.stack.qty}</strong><small>Unlimited persistent storage</small></span><button data-depot-withdraw="${row.index}">WITHDRAW</button></div>`).join('') || '<div class="target-empty">Depot empty.</div>';
  openModal('PERSISTENT STORAGE', 'Character Depot', `<div class="depot-actions"><button class="primary-button" id="depotStoreAll" ${char.inventory.length ? '' : 'disabled'}>STORE ENTIRE BACKPACK</button><button class="secondary-button" id="depotWithdrawAll" ${char.depot.length ? '' : 'disabled'}>WITHDRAW AS MUCH AS FITS</button><span>${char.depot.length} unlimited depot stacks</span></div><div class="merchant-layout"><section class="shop-column"><header><span>BACKPACK</span><b>${char.inventory.length} / 20</b></header><div class="shop-list">${inventoryRows}</div></section><section class="shop-column"><header><span>DEPOT</span><b>UNLIMITED SLOTS</b></header><div class="shop-list">${depotRows}</div></section></div>`, 'wide');
  document.querySelectorAll('[data-depot-store]').forEach(button => button.addEventListener('click', () => { const index = Number(button.dataset.depotStore); const stack = char.inventory[index]; if (!stack) return; addDepotStack(stack.id, stack.qty); char.inventory.splice(index, 1); saveGame(false); openDepot(); }));
  document.querySelectorAll('[data-depot-withdraw]').forEach(button => button.addEventListener('click', () => { const index = Number(button.dataset.depotWithdraw); const stack = char.depot[index]; if (!stack) return; if (addItem(stack.id, stack.qty, char, true)) { char.depot.splice(index, 1); saveGame(false); openDepot(); } else toast('That stack does not fit in your backpack.', true); }));
  document.getElementById('depotStoreAll')?.addEventListener('click', () => { for (const stack of char.inventory) addDepotStack(stack.id, stack.qty); char.inventory = []; runtime.selectedInventoryIndex = -1; saveGame(false); openDepot(); toast('Entire backpack transferred to unlimited depot storage.'); });
  document.getElementById('depotWithdrawAll')?.addEventListener('click', () => { for (let index = char.depot.length - 1; index >= 0; index--) { const stack = char.depot[index]; if (addItem(stack.id, stack.qty, char, true)) char.depot.splice(index, 1); } saveGame(false); openDepot(); });
}

function placeFurniture(house, inventoryIndex) {
  const char = runtime.character; const stack = char.inventory[inventoryIndex]; const item = stack && itemOf(stack.id);
  if (!item?.placeable || !char.houseIds.includes(house.id)) return;
  const occupied = new Set(char.furniturePlacements.filter(place => place.houseId === house.id).map(place => `${place.x},${place.y}`));
  let target = null;
  for (let y = house.y + 1; y < house.y + house.height - 1 && !target; y++) for (let x = house.x + 1; x < house.x + house.width - 1; x++) if (!occupied.has(`${x},${y}`)) { target = { x, y }; break; }
  if (!target) { toast('This cottage has no free furniture tile.', true); return; }
  char.furniturePlacements.push({ id: uid('furniture'), houseId: house.id, itemId: item.id, x: target.x, y: target.y, z: house.z, rotation: 0,provenanceRecords:deepClone(stack.provenanceRecords||[]),itemLevel:stack.itemLevel||null });
  removeItem(item.id, 1); progressQuestEvent('place', 'furniture', 1); toast(`${item.name} placed in ${house.name}.`); closeModal(); saveGame(false);
}

function openModal(kicker, title, body, className = '') {
  runtime.modalOpen = true;
  el.modalRoot.innerHTML = `<div class="modal-backdrop"><section class="modal ${className}"><header><div><span>${escapeHtml(kicker)}</span><h2>${escapeHtml(title)}</h2></div><button class="modal-close" aria-label="Close">×</button></header><div class="modal-body">${body}</div></section></div>`;
  el.modalRoot.querySelector('.modal-close')?.addEventListener('click', closeModal);
  el.modalRoot.querySelector('.modal-backdrop')?.addEventListener('click', event => { if (event.target.classList.contains('modal-backdrop')) closeModal(); });
}

function closeModal() { runtime.modalOpen = false; el.modalRoot.innerHTML = ''; el.worldCanvas.focus(); }

function startItemDrag(event, payload) {
  runtime.dragPayload = payload;
  if (event.dataTransfer) {
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('application/x-emberwake-item', JSON.stringify(payload));
    event.dataTransfer.setData('text/plain', JSON.stringify(payload));
  }
}

function readDragPayload(event) {
  try {
    const raw = event.dataTransfer?.getData('application/x-emberwake-item') || event.dataTransfer?.getData('text/plain');
    return raw ? JSON.parse(raw) : runtime.dragPayload;
  } catch { return runtime.dragPayload; }
}

function handleInventoryDrop(targetIndex, payload) {
  const char = runtime.character;
  if (!char || !payload) return;
  if (payload.source === 'inventory') {
    const sourceIndex = Number(payload.index); const stack = char.inventory[sourceIndex];
    if (!stack || sourceIndex === targetIndex) return;
    const target = char.inventory[targetIndex];
    const targetItem = target && itemOf(target.id);
    if (targetItem?.type === 'container') {
      const targetInstanceId = ensureContainerInstance(target, char);
      const sourceItem = itemOf(stack.id); const sourceInstanceId = sourceItem?.type === 'container' ? ensureContainerInstance(stack, char) : null;
      if (sourceInstanceId && !targetItem.acceptsContainers) { toast(`${targetItem.name} cannot hold another bag.`, true); return; }
      if (sourceInstanceId && (sourceInstanceId === targetInstanceId || containerContainsInstance(sourceInstanceId, targetInstanceId, char))) { toast('That would put a bag inside itself.', true); return; }
      const contents = char.containerContents[targetInstanceId];
      if (contents.length >= Number(targetItem.capacity || 0)) { toast(`${targetItem.name} is full.`, true); return; }
      const requested = sourceItem?.stackable ? Math.min(Number(payload.qty || stack.qty), stack.qty) : stack.qty;
      const moved = requested < stack.qty ? { id: stack.id, qty: requested } : stack;
      if (requested < stack.qty) stack.qty -= requested; else char.inventory.splice(sourceIndex, 1);
      contents.push(moved); runtime.selectedInventoryIndex = -1;
      toast(`${sourceItem?.name || stack.id} moved inside ${targetItem.name}.`); renderAllUi(); saveGame(false); return;
    }
    if (target?.id === stack.id && itemOf(stack.id)?.stackable) {
      const qty = payload.qty || stack.qty; target.qty += qty; stack.qty -= qty; if (stack.qty <= 0) char.inventory.splice(sourceIndex, 1);
    } else {
      const [moved] = char.inventory.splice(sourceIndex, 1);
      const adjusted = sourceIndex < targetIndex ? targetIndex - 1 : targetIndex;
      char.inventory.splice(Math.min(adjusted, char.inventory.length), 0, moved);
    }
  } else if (payload.source === 'equipment') {
    const itemId = char.equipment[payload.slot]; if (!itemId) return;
    if (char.inventory.length >= inventoryCapacity(char)) { toast('Your backpack is full.', true); return; }
    char.equipment[payload.slot] = null;
    char.inventory.splice(Math.min(targetIndex, char.inventory.length), 0, { id: itemId, qty: 1 });
  } else if (payload.source === 'ground') {
    const pile = runtime.ground.find(entry => entry.id === payload.groundId); if (!pile) return;
    if (pile.type === 'bag') { lootGround(pile); return; }
    const item = itemOf(pile.itemId); const qty = payload.qty || pile.qty;
    const existing = item?.stackable ? char.inventory.find(stack => stack.id === pile.itemId) : null;
    if (!existing && char.inventory.length >= inventoryCapacity(char)) { toast('Your backpack is full.', true); return; }
    if (existing) existing.qty += qty; else char.inventory.splice(Math.min(targetIndex, char.inventory.length), 0, { id: pile.itemId, qty });
    pile.qty -= qty; if (pile.qty <= 0) runtime.ground.splice(runtime.ground.indexOf(pile), 1);
    refreshCollectObjectives(pile.itemId);
  }
  runtime.selectedInventoryIndex = -1; renderAllUi(); saveGame(false);
}

function handleEquipmentDrop(slot, payload) {
  const char = runtime.character;
  if (!char || !payload) return;
  let itemId = null; let sourceStack = null; let sourcePile = null;
  if (payload.source === 'inventory') { sourceStack = char.inventory[Number(payload.index)]; itemId = sourceStack?.id; }
  if (payload.source === 'ground') { sourcePile = runtime.ground.find(entry => entry.id === payload.groundId); itemId = sourcePile?.itemId; }
  if (payload.source === 'equipment') {
    const from = payload.slot; if (from === slot) return;
    const moving = char.equipment[from]; const target = char.equipment[slot];
    if (!moving || itemOf(moving)?.slot !== slot || (target && itemOf(target)?.slot !== from)) { toast('Those equipment slots are not compatible.', true); return; }
    char.equipment[slot] = moving; char.equipment[from] = target || null; renderAllUi(); saveGame(false); return;
  }
  const item = itemOf(itemId);
  if (!item || item.slot !== slot) { toast(`${item?.name || 'That item'} cannot be equipped in the ${slot} slot.`, true); return; }
  const oldItem = char.equipment[slot];
  if (sourceStack) {
    sourceStack.qty -= 1; if (sourceStack.qty <= 0) char.inventory.splice(char.inventory.indexOf(sourceStack), 1);
  } else if (sourcePile) {
    sourcePile.qty -= 1; if (sourcePile.qty <= 0) runtime.ground.splice(runtime.ground.indexOf(sourcePile), 1);
  }
  char.equipment[slot] = item.id;
  if (oldItem) addItem(oldItem, 1, char, true);
  renderAllUi(); saveGame(false);
}

function handleWorldDrop(event) {
  event.preventDefault();
  const payload = readDragPayload(event); const char = runtime.character;
  if (!payload || !char) return;
  const tile = worldFromScreen(event.clientX, event.clientY);
  if (manhattan(char, tile) > 7) { toast('That tile is too far away to throw an item.', true); return; }
  const sourceItemId = payload.source === 'inventory' ? char.inventory[Number(payload.index)]?.id : payload.source === 'equipment' ? char.equipment[payload.slot] : runtime.ground.find(entry => entry.id === payload.groundId)?.itemId;
  const sourceItem = itemOf(sourceItemId);
  if (sourceItem?.type === 'furniture') {
    const house = DATA.houses.find(candidate => char.houseIds.includes(candidate.id) && isInsideHouse(tile.x, tile.y, char.z, candidate));
    if (!house) { toast('Drag furniture onto a clear interior tile of a house you own.', true); return; }
    if (char.furniturePlacements.some(place => place.z === char.z && place.x === tile.x && place.y === tile.y)) { toast('That furniture tile is occupied.', true); return; }
    if (payload.source !== 'inventory') { toast('Place furniture by dragging it from your backpack.', true); return; }
    const stack = char.inventory[Number(payload.index)]; if (!stack) return;
    char.furniturePlacements.push({ id: uid('furniture'), houseId: house.id, itemId: sourceItem.id, x: tile.x, y: tile.y, z: char.z, rotation: 0,provenanceRecords:deepClone(stack.provenanceRecords||[]),itemLevel:stack.itemLevel||null });
    stack.qty -= 1; if (stack.qty <= 0) char.inventory.splice(char.inventory.indexOf(stack), 1);
    progressQuestEvent('place', 'furniture', 1); playSfx('craft'); toast(`${sourceItem.name} placed where you dropped it.`); renderAllUi(); saveGame(false); return;
  }
  const hole = holeAt(tile.x, tile.y, char.z);
  if (!isPassable(tile.x, tile.y, char.z, true) && !hole) { toast('Items cannot be placed on that tile.', true); return; }
  let pile = null; let itemId = null; let qty = 1;
  if (payload.source === 'inventory') {
    const stack = char.inventory[Number(payload.index)]; if (!stack) return;
    itemId = stack.id; qty = payload.qty || stack.qty;
    stack.qty -= qty; if (stack.qty <= 0) char.inventory.splice(char.inventory.indexOf(stack), 1);
  } else if (payload.source === 'equipment') {
    itemId = char.equipment[payload.slot]; if (!itemId) return; char.equipment[payload.slot] = null;
  } else if (payload.source === 'ground') {
    pile = runtime.ground.find(entry => entry.id === payload.groundId); if (!pile) return;
    if (pile.type === 'bag') runtime.ground.splice(runtime.ground.indexOf(pile), 1);
    else {
      qty = payload.qty || pile.qty; itemId = pile.itemId; pile.qty -= qty; if (pile.qty <= 0) runtime.ground.splice(runtime.ground.indexOf(pile), 1); pile = null;
    }
  }
  const destination = hole && hole.targetZ < char.z ? { x: hole.targetX, y: hole.targetY, z: hole.targetZ } : { x: tile.x, y: tile.y, z: char.z };
  if (pile?.type === 'bag') { pile.x = destination.x; pile.y = destination.y; pile.z = destination.z; runtime.ground.push(pile); }
  else if (itemId) addGroundStack(itemId, qty, destination.x, destination.y, destination.z);
  toast(hole && destination.z < char.z ? `${itemOf(itemId)?.name || 'The item'} falls through the hole to floor ${destination.z}.` : `${itemOf(itemId)?.name || 'Item'} moved onto the ground.`);
  refreshCollectObjectives(itemId); renderAllUi(); saveGame(false);
}

function addGroundStack(itemId, qty, x, y, z, originOptions={}) {
  const item = itemOf(itemId); if (!item || qty <= 0) return;
  const existing = item.stackable ? runtime.ground.find(pile => pile.type !== 'bag' && pile.itemId === itemId && pile.x === x && pile.y === y && pile.z === z) : null;
  const provenance=originOptions.provenance?deepClone(originOptions.provenance):makeProvenance(originOptions.sourceType||'server_spawn',originOptions.sourceId||itemId,originOptions);
  if (existing){existing.qty+=qty;existing.provenanceRecords=existing.provenanceRecords||[];existing.provenanceRecords.push({...provenance,quantity:qty});}
  else runtime.ground.push({ id: uid('ground'),instanceId:uid('item'), type: 'item', itemId, qty, x, y, z, icon: item.icon, color: item.color, name: item.name,provenanceRecords:[{...provenance,quantity:qty}],itemLevel:originOptions.itemLevel||null });
}

function holeAt(x, y, z) {
  const staticHole = DATA.placements.find(place => place.x === x && place.y === y && place.z === z && ['hole', 'rope_spot'].includes(place.type));
  if (staticHole) return staticHole;
  return runtime.dynamicHoles.find(hole => hole.x === x && hole.y === y && hole.z === z) || null;
}

function useInventoryItem(index) {
  const char = runtime.character; const stack = char?.inventory[index]; const item = stack && itemOf(stack.id);
  if (!item) return;
  if (item.type === 'container') { openContainer(stack); return; }
  if (item.action === 'tailoring') { openTailoring(); return; }
  if (item.type === 'spellbook') { openSpellbook(); return; }
  if (item.type === 'rune') {
    if (item.runeEffect === 'heal') {
      const amount = Math.min(Math.round(Number(item.power || 40) + magicPowerOf(char) * .8), char.maxHp - char.hp);
      char.hp += amount; floatText(char.x, char.y, `+${amount}`, 'heal'); effectAt(char.x, char.y, '#74d59b', 'ring', 1);
    } else if (item.runeEffect === 'wall') {
      const target = nearestVisibleEnemy(); const x = target?.x ?? char.x + (char.facing === 'east' ? 1 : char.facing === 'west' ? -1 : 0); const y = target?.y ?? char.y + (char.facing === 'south' ? 1 : char.facing === 'north' ? -1 : 0);
      runtime.temporaryWalls = runtime.temporaryWalls.filter(wall => wall.x !== x || wall.y !== y || wall.z !== char.z);
      runtime.temporaryWalls.push({ x, y, z: char.z, expiresAt: Date.now() + 12000 }); effectAt(x, y, '#71a859', 'burst', 1);
    } else if (item.runeEffect === 'destroy_field') {
      const target = nearestVisibleEnemy(); const x = target?.x ?? char.x + (char.facing === 'east' ? 1 : char.facing === 'west' ? -1 : 0); const y = target?.y ?? char.y + (char.facing === 'south' ? 1 : char.facing === 'north' ? -1 : 0);
      const before = runtime.temporaryWalls.length + runtime.temporaryFields.length;
      runtime.temporaryWalls = runtime.temporaryWalls.filter(entry => entry.z !== char.z || manhattan(entry, { x, y }) > 1);
      runtime.temporaryFields = runtime.temporaryFields.filter(entry => entry.z !== char.z || manhattan(entry, { x, y }) > 1);
      effectAt(x, y, '#d7d5c8', 'ring', 1); toast(before === runtime.temporaryWalls.length + runtime.temporaryFields.length ? 'No temporary field was present; the rune still trains Magic Level.' : 'Nearby temporary fields were dispelled.');
    } else if (item.runeEffect === 'fire_field' || item.runeEffect === 'poison') {
      const target = nearestVisibleEnemy();
      if (!target || manhattan(char, target) > Number(item.range || 6)) { toast('No enemy is visible within rune range.', true); return; }
      runtime.targetId = target.entityId; runtime.temporaryFields.push({ x: target.x, y: target.y, z: target.z, effect: item.runeEffect === 'poison' ? 'poison' : 'fire', damage: Math.max(3, Math.round(Number(item.power || 30) * .32 + magicPowerOf(char) * .2)), nextTick: Date.now(), expiresAt: Date.now() + 10000 }); effectAt(target.x, target.y, item.runeEffect === 'poison' ? '#8db35b' : '#e87842', 'burst', 1);
    } else {
      const target = nearestVisibleEnemy();
      if (!target || manhattan(char, target) > Number(item.range || 6)) { toast('No enemy is visible within rune range.', true); return; }
      runtime.targetId = target.entityId;
      const damage = Math.max(1, Math.round(Number(item.power || 35) + magicPowerOf(char) * 1.2));
      damageMonster(target, damage, item.runeEffect || 'energy'); effectAt(target.x, target.y, effectColor(item.runeEffect), 'burst', 1);
    }
    trainSkill('magic', 20 * Number(vocationOf(char)?.magicTrainingRate || 1)); trainSkill('runecraft', 8);
    removeItem(item.id, 1); toast(`${item.name} used · Magic Level trained.`); renderAllUi(); saveGame(false); return;
  }
  if (item.type === 'food' || item.type === 'potion') {
    let hungerRestored = 0;
    if (item.type === 'food') {
      const survival = ensureSurvival(char); hungerRestored = Math.min(Number(item.nutrition || 10), 100 - survival.hunger); survival.hunger += hungerRestored; survival.warnedHunger = false;
    }
    if (item.heal||item.potionResource==='health') { const restore=item.potionResource?potionRestore(item,char):item.heal;const amount=Math.min(restore,char.maxHp-char.hp);char.hp+=amount;floatText(char.x,char.y,`+${amount.toFixed(amount<1?3:1)}`,'heal'); }
    if (item.mana||item.potionResource==='mana') { const restore=item.potionResource?potionRestore(item,char):item.mana;const amount=Math.min(restore,char.maxMana-char.mana);char.mana+=amount;floatText(char.x,char.y,`+${amount.toFixed(amount<1?3:1)}`,'mana'); }
    if (item.cure) { delete char.statuses[item.cure]; progressQuestEvent('cure', item.cure, 1); }
    removeItem(item.id, 1); if (hungerRestored > 0) toast(`${item.name} restores ${Math.ceil(hungerRestored)} Hunger.`); renderAllUi(); saveGame(false); return;
  }
  if (item.type === 'light') {
    if (item.id === 'torch') { char.flags.torchLit = !char.flags.torchLit; if (char.flags.torchLit) progressQuestEvent('use', 'torch', 1); }
    if (item.id === 'lantern') char.flags.lanternLit = !char.flags.lanternLit;
    toast(`${item.name} ${char.flags.torchLit || char.flags.lanternLit ? 'lit' : 'extinguished'}.`); renderAllUi(); return;
  }
  if (item.type === 'tool' && ['rope', 'troll_rope', 'pickaxe'].includes(item.id)) {
    runtime.pendingUse = { itemId: item.id, index };
    toast(`${item.name} selected. Click a nearby hole or rope spot.`); return;
  }
  if (item.slot) { equipFromInventory(index); return; }
  if (item.type === 'furniture') {
    const house = DATA.houses.find(candidate => char.houseIds.includes(candidate.id) && isInsideHouse(char.x, char.y, char.z, candidate));
    if (!house) { toast('Enter an owned house before placing furniture.', true); return; }
    placeFurniture(house, index); return;
  }
  toast(`${item.name} has no direct use here.`);
}

function equipFromInventory(index) {
  const char = runtime.character; const stack = char.inventory[index]; const item = stack && itemOf(stack.id);
  if (!item?.slot) return;
  const old = char.equipment[item.slot];char.equipmentProvenance=char.equipmentProvenance||{};const oldProvenance=char.equipmentProvenance[item.slot],movingProvenance={provenanceRecords:deepClone(stack.provenanceRecords||[]),itemLevel:stack.itemLevel||null};
  stack.qty -= 1; if (stack.qty <= 0) char.inventory.splice(index, 1);
  char.equipment[item.slot] = item.id;
  char.equipmentProvenance[item.slot]=movingProvenance;if(stack.itemLevel)itemProgressFor(item.id,char).level=Math.max(itemProgressFor(item.id,char).level,Number(stack.itemLevel));
  if (old) addItem(old, 1, char, true,{provenance:oldProvenance?.provenanceRecords?.[0],sourceType:'unequipped',sourceId:item.slot,reason:'returned from equipment'});
  toast(`${item.name} equipped.`); renderAllUi(); saveGame(false);
}

function unequipItem(slot) {
  const char = runtime.character; const itemId = char?.equipment?.[slot];
  if (!itemId) return;
  if (char.inventory.length >= inventoryCapacity(char)) { toast('Your backpack is full.', true); return; }
  const provenance=char.equipmentProvenance?.[slot];char.equipment[slot]=null;if(char.equipmentProvenance)delete char.equipmentProvenance[slot];addItem(itemId,1,char,true,{provenance:provenance?.provenanceRecords?.[0],sourceType:'unequipped',sourceId:slot,reason:'returned from equipment'});renderAllUi();saveGame(false);
}

function openContainer(stack) {
  const char=runtime.character,item=stack&&itemOf(stack.id);if(!char||item?.type!=='container')return;const instanceId=ensureContainerInstance(stack,char);char.uiState=char.uiState||{};char.uiState.bagWindows=char.uiState.bagWindows||{};const previous=char.uiState.bagWindows[instanceId]||{},index=runtime.openBagWindows.size;runtime.openBagWindows.set(instanceId,{stack,x:previous.x??(22+index*28),y:previous.y??(70+index*24),width:previous.width||270,height:previous.height||245,collapsed:Boolean(previous.collapsed),dock:previous.dock||''});renderBagWindows();
}

function renderBagWindows(){const char=runtime.character;if(!char||!el.bagWindowLayer)return;el.bagWindowLayer.innerHTML=[...runtime.openBagWindows.entries()].map(([instanceId,state])=>{const item=itemOf(state.stack.id),contents=char.containerContents?.[instanceId]||[];return `<section class="bag-window ${state.collapsed?'collapsed':''}" data-bag-window="${instanceId}" style="left:${state.x}px;top:${state.y}px;width:${state.width}px;height:${state.height}px"><header><span>${item?.icon||'🎒'} ${escapeHtml(item?.name||'Bag')} · ${contents.length}/${item?.capacity||0}</span><div><button data-bag-dock="${instanceId}" title="Dock window">▣</button><button data-bag-collapse="${instanceId}" title="Collapse">—</button><button data-bag-close="${instanceId}" title="Close">×</button></div></header><div class="bag-window-body"><div class="bag-window-grid">${contents.map((child,index)=>{const childItem=itemOf(child.id);return `<button class="inventory-slot" data-bag-item="${instanceId}" data-bag-index="${index}" data-tooltip="${escapeHtml(itemTooltipText(childItem,child.qty,child))}"><span class="item-icon">${childItem?.icon||'◆'}</span><small>${child.qty>1?child.qty:''}</small></button>`;}).join('')}</div><div class="bag-dock-hint">Double-click nested bags · right-click withdraws · ▣ docks to an edge</div></div></section>`;}).join('');
  el.bagWindowLayer.querySelectorAll('[data-bag-window]').forEach(windowNode=>{const id=windowNode.dataset.bagWindow,state=runtime.openBagWindows.get(id),header=windowNode.querySelector('header');let drag=null;header?.addEventListener('pointerdown',event=>{if(event.target.closest('button'))return;drag={x:event.clientX,y:event.clientY,left:windowNode.offsetLeft,top:windowNode.offsetTop};header.setPointerCapture(event.pointerId);});header?.addEventListener('pointermove',event=>{if(!drag)return;state.x=clamp(drag.left+event.clientX-drag.x,0,Math.max(0,el.worldStage?.clientWidth-windowNode.offsetWidth));state.y=clamp(drag.top+event.clientY-drag.y,0,Math.max(0,el.worldStage?.clientHeight-windowNode.offsetHeight));windowNode.style.left=`${state.x}px`;windowNode.style.top=`${state.y}px`;});header?.addEventListener('pointerup',()=>{drag=null;persistBagWindow(id,windowNode);});new ResizeObserver(()=>persistBagWindow(id,windowNode)).observe(windowNode);});
  el.bagWindowLayer.querySelectorAll('[data-bag-close]').forEach(button=>button.addEventListener('click',()=>{runtime.openBagWindows.delete(button.dataset.bagClose);renderBagWindows();}));el.bagWindowLayer.querySelectorAll('[data-bag-collapse]').forEach(button=>button.addEventListener('click',()=>{const state=runtime.openBagWindows.get(button.dataset.bagCollapse);state.collapsed=!state.collapsed;renderBagWindows();}));el.bagWindowLayer.querySelectorAll('[data-bag-dock]').forEach(button=>button.addEventListener('click',()=>{const state=runtime.openBagWindows.get(button.dataset.bagDock);state.dock=state.dock==='left'?'right':'left';state.x=state.dock==='left'?6:Math.max(6,(el.worldStage?.clientWidth||800)-state.width-6);state.y=42;renderBagWindows();}));el.bagWindowLayer.querySelectorAll('[data-bag-item]').forEach(button=>{button.addEventListener('dblclick',()=>{const contents=char.containerContents[button.dataset.bagItem]||[],child=contents[Number(button.dataset.bagIndex)];if(itemOf(child?.id)?.type==='container')openContainer(child);else if(child)toast(itemTooltipText(itemOf(child.id),child.qty,child));});button.addEventListener('contextmenu',event=>{event.preventDefault();const contents=char.containerContents[button.dataset.bagItem]||[],index=Number(button.dataset.bagIndex),child=contents[index];if(!child)return;if(char.inventory.length>=inventoryCapacity(char)){toast('Your main backpack has no open slot.',true);return;}char.inventory.push(child);contents.splice(index,1);saveGame(false);renderAllUi();renderBagWindows();});});}
function persistBagWindow(instanceId,node){const char=runtime.character,state=runtime.openBagWindows.get(instanceId);if(!char||!state)return;if(node){state.width=node.offsetWidth;state.height=node.offsetHeight;}char.uiState=char.uiState||{};char.uiState.bagWindows=char.uiState.bagWindows||{};char.uiState.bagWindows[instanceId]={x:state.x,y:state.y,width:state.width,height:state.height,collapsed:state.collapsed,dock:state.dock};}

function openTailoring() {
  const char = runtime.character; if (!char) return;
  const skill = char.skills.tailoring || { level: 1, xp: 0, next: 100 };
  const rows = DATA.tailoringRecipes.map(recipe => {
    const ready = skill.level >= recipe.level && Object.entries(recipe.inputs).every(([id, qty]) => inventoryQuantity(id, char) >= qty);
    const inputs = Object.entries(recipe.inputs).map(([id, qty]) => `${itemOf(id)?.name || id} × ${qty}`).join(', ');
    const outputs = Object.entries(recipe.outputs).map(([id, qty]) => `${itemOf(id)?.name || id} × ${qty}`).join(', ');
    return `<div class="shop-row"><i>✂</i><span><strong>${escapeHtml(recipe.name)}</strong><small>Tailoring ${recipe.level} · ${escapeHtml(inputs)} → ${escapeHtml(outputs)} · ${recipe.xp} XP</small></span><button data-tailor-recipe="${recipe.id}" ${ready ? '' : 'disabled'}>SEW</button></div>`;
  }).join('');
  openModal('ARTISAN WORKBENCH', `Tailoring · Level ${skill.level}`, `<div class="info-card"><p>Local humanoids and spider nests supply cloth. Maeve sells the remaining reagents cheaply, so the full path to level 100 remains available.</p></div><div class="shop-list" style="margin-top:12px">${rows}</div>`, 'wide');
  document.querySelectorAll('[data-tailor-recipe]').forEach(button => button.addEventListener('click', () => craftTailoring(button.dataset.tailorRecipe)));
}
function openSmithingForge(){const char=runtime.character,skill=char?.skills?.smithing||{level:1,xp:0,next:100};if(!char)return;const rows=DATA.smithingRecipes.map(recipe=>{const ready=skill.level>=recipe.level&&Object.entries(recipe.inputs).every(([id,qty])=>inventoryQuantity(id,char)>=qty);return `<div class="shop-row"><i>🔨</i><span><strong>${escapeHtml(recipe.name)}</strong><small>Smithing ${recipe.level} · ${Object.entries(recipe.inputs).map(([id,qty])=>`${qty} ${itemOf(id)?.name||id}`).join(' + ')} · ${recipe.xp} XP</small></span><button data-smith-recipe="${recipe.id}" ${ready?'':'disabled'}>FORGE</button></div>`;}).join('');openModal('HARBOR TRAINING FORGE',`Smithing ${skill.level}`,`<div class="info-card"><p>Mine and chop the nearby renewable training nodes, then forge equipment here. Every result records this player as its original author.</p></div><div class="shop-list" style="margin-top:12px">${rows}</div>`,'wide');document.querySelectorAll('[data-smith-recipe]').forEach(button=>button.addEventListener('click',()=>{const recipe=byId(DATA.smithingRecipes,button.dataset.smithRecipe);if(!recipe)return;for(const [id,qty] of Object.entries(recipe.inputs))if(!removeItem(id,qty,char))return;for(const [id,qty] of Object.entries(recipe.outputs))addItem(id,qty,char,true,{sourceType:'player_crafted',sourceId:recipe.id,reason:'forged at Harbor Training Forge'});trainSkill('smithing',recipe.xp);trainSkill('labouring',Math.ceil(recipe.xp*.2));queueGameEvent('recipe_crafted',{recipeId:recipe.id,skillId:'smithing',authorId:actorIdentity(char).id});saveGame(false);openSmithingForge();toast(`${recipe.name} forged. Your player ID is preserved as its author.`);}));}

function craftTailoring(recipeId) {
  const char = runtime.character; const recipe = byId(DATA.tailoringRecipes, recipeId); const level = char?.skills?.tailoring?.level || 1;
  if (!char || !recipe || level < recipe.level || !Object.entries(recipe.inputs).every(([id, qty]) => inventoryQuantity(id, char) >= qty)) return;
  const outputSlots = Object.entries(recipe.outputs).reduce((sum, [id, qty]) => sum + (itemOf(id)?.stackable ? 1 : qty), 0);
  if (char.inventory.length + outputSlots > inventoryCapacity(char) + Object.keys(recipe.inputs).length) { toast('Make more backpack space before sewing.', true); return; }
  for (const [id, qty] of Object.entries(recipe.inputs)) removeItem(id, qty, char);
  for (const [id, qty] of Object.entries(recipe.outputs)) addItem(id,qty,char,true,{sourceType:'player_crafted',sourceId:recipe.id,reason:'tailored by player'});
  trainSkill('tailoring', recipe.xp); queueGameEvent('recipe_crafted', { recipeId, skillId: 'tailoring' });
  toast(`${recipe.name} completed · +${recipe.xp} Tailoring XP.`); saveGame(false); renderAllUi(); openTailoring();
}

function openSpellbook() {
  const char = runtime.character;
  const learned = (char.learnedSpells || []).map(spellOf).filter(Boolean);
  const rows = learned.map(spell => `<div class="shop-row"><i>${spell.icon}</i><span><strong>${escapeHtml(spell.name)}</strong><small>Level ${spell.level} · ${spell.mana ? `${spell.mana} mana` : spell.zeal ? `${spell.zeal} Zeal` : 'skill'} · ${escapeHtml(spell.visual)}</small></span><div style="display:grid;grid-template-columns:repeat(4,27px);gap:3px">${Array.from({ length: 8 }, (_, slot) => `<button data-assign-spell="${spell.id}" data-hotbar-slot="${slot}" style="min-width:27px">${slot + 1}</button>`).join('')}</div></div>`).join('');
  openModal('VOCATION SPELLBOOK', `${char.name}’s Learned Spells`, `<div class="info-card"><p>Choose a numbered button to assign that spell to hotbar slot 1–8. Assigning a spell already on the bar moves it to the new slot.</p></div><div class="shop-list" style="margin-top:12px;max-height:480px">${rows}</div><button id="clearHotbar" class="secondary-button" style="margin-top:12px">CLEAR HOTBAR</button>`, 'wide');
  document.querySelectorAll('[data-assign-spell]').forEach(button => button.addEventListener('click', () => assignSpell(button.dataset.assignSpell, Number(button.dataset.hotbarSlot))));
  document.getElementById('clearHotbar')?.addEventListener('click', () => { char.spells = Array(8).fill(null); renderSpellBar(); openSpellbook(); saveGame(false); });
}

function assignSpell(spellId, slot) {
  const char = runtime.character;
  if (!char.learnedSpells.includes(spellId) || slot < 0 || slot > 7) return;
  while (char.spells.length < 8) char.spells.push(null);
  const current = char.spells.indexOf(spellId); if (current >= 0) char.spells[current] = null;
  char.spells[slot] = spellId;
  toast(`${spellOf(spellId)?.name} assigned to hotbar ${slot + 1}.`); renderSpellBar(); openSpellbook(); saveGame(false);
}

function handlePendingUseAt(x, y) {
  const pending = runtime.pendingUse; const char = runtime.character;
  if (!pending || !char) return false;
  const item = itemOf(pending.itemId); const hole = holeAt(x, y, char.z);
  if (manhattan(char, { x, y }) > 2) { toast('Move within two tiles of the hole first.', true); return true; }
  if (['rope', 'troll_rope'].includes(pending.itemId)) {
    if (!hole) { toast('A rope must be used on a hole or rope spot.', true); runtime.pendingUse = null; return true; }
    if (hole.targetZ > char.z) {
      char.x = hole.targetX; char.y = hole.targetY; char.z = hole.targetZ; runtime.camera.x = char.x; runtime.camera.y = char.y;
      progressQuestEvent('interact', 'rope_spot', 1); toast(`The rope lifts you to floor ${char.z}.`);
    } else {
      const below = runtime.ground.filter(pile => pile.x === hole.targetX && pile.y === hole.targetY && pile.z === hole.targetZ).at(-1);
      if (below) { below.x = x; below.y = y; below.z = char.z; toast(`${below.name || itemOf(below.itemId)?.name || 'Item'} roped up from floor ${hole.targetZ}.`); }
      else toast(`The rope reaches floor ${hole.targetZ}, but hooks no item.`);
    }
  } else if (pending.itemId === 'pickaxe') {
    if (hole) {
      char.x = hole.targetX; char.y = hole.targetY; char.z = hole.targetZ; runtime.camera.x = char.x; runtime.camera.y = char.y;
      toast(`You pick a safe grip and traverse to floor ${char.z}.`);
    } else {
      const downZ = char.z - 1;
      if (!isCaveLand(x, y, downZ)) { toast('The rock below is too dense here. Try over an established cave region.', true); runtime.pendingUse = null; return true; }
      const down = { id: uid('hole'), type: 'dynamic_hole', x, y, z: char.z, targetX: x, targetY: y, targetZ: downZ };
      const up = { id: uid('hole'), type: 'dynamic_hole', x, y, z: downZ, targetX: x, targetY: y, targetZ: char.z };
      runtime.dynamicHoles.push(down, up); char.x = x; char.y = y; char.z = downZ; runtime.camera.x = x; runtime.camera.y = y;
      toast(`You pickaxe a shaft down to floor ${downZ}. The paired hole can be climbed back with the pickaxe or rope.`);
    }
  }
  runtime.pendingUse = null; runtime.path = []; renderAllUi(); saveGame(false); return true;
}

function movementDelay() {
  const char = runtime.character; const vocation = vocationOf(char);
  const rules = gameRule('progression_rules');
  const levelSpeed = 1 + Math.min(Number(rules.levelSpeedCap ?? .7), Math.max(0, char.level - 1) * Number(rules.levelSpeedPerLevel ?? .0033));
  const athleticsLevel = char.skills?.athletics?.level || 1;
  const athleticsSpeed = 1 + Math.min(Number(rules.athleticsSpeedCap ?? .4), Math.max(0, athleticsLevel - 1) * Number(rules.athleticsSpeedPerLevel ?? .0035));
  let speed = (vocation?.speed || 1) * levelSpeed * athleticsSpeed;
  if (char.mounted) speed += byId(DATA.mounts, char.mountId)?.speedBonus || .35;
  if ((char.statuses.hasteUntil || 0) > Date.now()) speed += char.statuses.hastePower || .3;
  if (char.flags.sneaking) speed *= Number(rules.sneakSpeedMultiplier ?? .58);
  if (isTired(char)) speed *= Number(gameRule('survival_rules').tiredSpeedMultiplier ?? .5);
  if (char.flags.cannonPowered) speed *= .55;
  if (char.flags.siegeMode) return Infinity;
  if (inventoryWeight(char) > char.capMax) speed *= .55;
  return clamp(175 / speed, 52, isTired(char) ? 640 : 320);
}

function moveOne(dx, dy) {
  const char = runtime.character;
  if (!char || char.hp <= 0 || runtime.modalOpen || !Number.isFinite(movementDelay())) return false;
  const x = char.x + dx; const y = char.y + dy;
  char.facing = dx > 0 ? 'east' : dx < 0 ? 'west' : dy > 0 ? 'south' : 'north';
  const blockingMonster = runtime.monsters.find(monster => monster.alive && monster.z === char.z && monster.x === x && monster.y === y);
  if (blockingMonster) { runtime.targetId = blockingMonster.entityId; performBasicAttack(); return false; }
  if (!isPassable(x, y, char.z)) { runtime.path = []; toast(terrainAt(x, y, char.z) === 'water' ? 'Deep water blocks the way.' : 'That path is blocked.'); return false; }
  char.x = x; char.y = y;
  const carriedRatio = clamp(inventoryWeight(char) / Math.max(1, char.capMax), 0, 2);
  trainSkill('athletics', Math.max(.2, 1.25 - carriedRatio * .45));
  if (carriedRatio >= Number(gameRule('progression_rules').strengthTrainingLoadThreshold ?? .2)) trainSkill('strength', .25 + carriedRatio * 1.8);
  if (char.flags.sneaking) {
    const nearestThreat = runtime.monsters.filter(monster => monster.alive && monster.z === char.z).reduce((best, monster) => Math.min(best, manhattan(monster, char)), Infinity);
    trainSkill('stealth', nearestThreat <= 10 ? 1.8 : .45);
  }
  const zone = zoneAt(x, y, char.z); char.location = zone?.name || char.location;
  if (zone?.id) progressQuestEvent('visit', zone.id, 1);
  renderHud(); renderNearby();
  return true;
}

function findPath(startX, startY, goalX, goalY, z, stopAdjacent = false) {
  const goalCandidates = stopAdjacent ? [[goalX, goalY], [goalX + 1, goalY], [goalX - 1, goalY], [goalX, goalY + 1], [goalX, goalY - 1]].filter(([x, y]) => isPassable(x, y, z)) : [[goalX, goalY]];
  const goals = new Set(goalCandidates.map(([x, y]) => `${x},${y}`));
  const startKey = `${startX},${startY}`;
  const queue = [[startX, startY]]; const parents = new Map([[startKey, null]]);
  let found = null;
  for (let head = 0; head < queue.length && head < WORLD_W * WORLD_H; head++) {
    const [x, y] = queue[head]; const key = `${x},${y}`;
    if (goals.has(key)) { found = key; break; }
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx; const ny = y + dy; const nextKey = `${nx},${ny}`;
      if (parents.has(nextKey) || !isPassable(nx, ny, z)) continue;
      parents.set(nextKey, key); queue.push([nx, ny]);
    }
  }
  if (!found) return [];
  const path = [];
  for (let key = found; key && key !== startKey; key = parents.get(key)) { const [x, y] = key.split(',').map(Number); path.unshift({ x, y }); }
  return path;
}

function handleWorldClick(event) {
  if (!runtime.character || runtime.modalOpen) return;
  const tile = worldFromScreen(event.clientX, event.clientY);
  if (runtime.pendingUse && handlePendingUseAt(tile.x, tile.y)) return;
  const monster = runtime.monsters.find(entry => entry.alive && entry.z === runtime.character.z && entry.x === tile.x && entry.y === tile.y);
  if (monster) {
    runtime.targetId = monster.entityId; runtime.path = [];
    const weaponRange = itemOf(runtime.character.equipment.weapon)?.range || 1;
    if (manhattan(runtime.character, monster) <= weaponRange) performBasicAttack();
    renderTarget(); return;
  }
  const npc = DATA.npcs.find(entry => entry.z === runtime.character.z && entry.x === tile.x && entry.y === tile.y);
  const pile = runtime.ground.find(entry => entry.z === runtime.character.z && entry.x === tile.x && entry.y === tile.y);
  const place = DATA.placements.find(entry => placementOnActiveMap(entry)&&entry.z === runtime.character.z && entry.x === tile.x && entry.y === tile.y);
  if ((npc || pile || place) && manhattan(runtime.character, npc || pile || place) <= 1) { interact(); return; }
  const path = findPath(runtime.character.x, runtime.character.y, tile.x, tile.y, runtime.character.z, Boolean(npc || pile || place));
  if (!path.length && (tile.x !== runtime.character.x || tile.y !== runtime.character.y)) toast('No clear path to that tile.', true);
  runtime.path = path;
}
function handleWorldContextMenu(event){event.preventDefault();if(!runtime.character)return;const tile=worldFromScreen(event.clientX,event.clientY),building=DATA.buildings.find(row=>row.z===runtime.character.z&&tile.x>=row.x&&tile.x<row.x+Number(row.width||1)&&tile.y>=row.y&&tile.y<row.y+Number(row.height||1)),place=DATA.placements.find(row=>row.z===runtime.character.z&&row.x===tile.x&&row.y===tile.y),target=place||building;if(!target)return;const record={authoredById:target.authoredById||'server',authoredByName:target.authoredByName||'Emberwake Server',authoredByType:target.authoredById&&target.authoredById!=='server'?'player':'server',sourceType:place?'world_placement':'building_authorship',sourceId:target.id,authoredAt:target.authoredAt||DATA.meta.updated,adminCreated:Boolean(target.adminCreated),currentOwnerId:target.ownershipChain?.at(-1)?.toId||'server',currentOwnerName:target.ownershipChain?.at(-1)?.toName||'Emberwake Server',ownershipChain:target.ownershipChain||[]};openProvenanceViewer({provenanceRecords:[record]},{name:target.name||target.label||target.entityId});}

function performBasicAttack() {
  const char = runtime.character; const target = monsterByEntity(runtime.targetId);
  if (!char || !target || !target.alive || target.z !== char.z) return;
  const now = Date.now(); const interval = runtime.combatStance === 'aggressive' ? 680 : runtime.combatStance === 'defensive' ? 1050 : 850;
  if (now - runtime.lastBasicAttackAt < interval) return;
  const weapon = itemOf(char.equipment.weapon) || {};
  const range = weapon.range || (char.vocationId === 'ranger' || char.vocationId === 'court_ranger' ? 5 : 1);
  if (manhattan(char, target) > range) { runtime.path = findPath(char.x, char.y, target.x, target.y, char.z, true); return; }
  if (char.vocationId === 'siege_operator' && !char.flags.siegeMode) { toast('The cannon can only fire after Power Cannon and Anchor Siege Mode.', true); return; }
  let ammunition = null;
  if (weapon.ammoItemId) {
    ammunition = itemOf(weapon.ammoItemId);
    if (inventoryQuantity(weapon.ammoItemId, char) > 0) removeItem(weapon.ammoItemId, 1, char);
    else if (char.equipment.ammo === weapon.ammoItemId) char.equipment.ammo = null;
    else { toast(`${weapon.name} needs ${ammunition?.name || 'ammunition'} in your backpack.`, true); return; }
  }
  runtime.lastBasicAttackAt = now;
  if(weapon.id)itemProgressFor(weapon.id,char).weaponUses+=1;
  trainEquippedItem('weapon',Number(gearCurveFor(weapon).useXpAttack||14),'combat use');
  if (char.flags.sneaking) { char.flags.sneaking = false; toast('Sneaking ended when you attacked.'); }
  const skillId = weapon.weaponSkill || (range > 1 ? 'distance' : 'attack'); const skill = char.skills[skillId]?.level || 1;
  trainSkill(skillId, 16);
  const accuracy = clamp(.78 + skill / 300 - (target.evasion || 0), .35, .98);
  if (Math.random() > accuracy) { floatText(target.x, target.y, 'MISS'); effectAt(target.x, target.y, '#c6c3b4', 'burst', 1); return; }
  let damage = (effectiveItemStat(weapon.id,'attack',char) || 4) + Number(ammunition?.attack || 0) + char.level * .55 + skill * .32 - target.defense * .28;
  if (skillId === 'magic') damage += magicPowerOf(char) * .45;
  if (runtime.combatStance === 'aggressive') damage *= 1.18;
  if (runtime.combatStance === 'defensive') damage *= .82;
  if ((char.statuses.rageUntil || 0) > now) damage *= 1 + (char.statuses.ragePower || .3);
  if ((char.statuses.focusUntil || 0) > now) damage *= 1 + (char.statuses.focusPower || .35);
  if ((char.statuses.blessedUntil || 0) > now) damage *= 1.1;
  damage = Math.max(1, Math.round(damage * (.85 + Math.random() * .3)));
  const attackElement = weapon.element || (weapon.holy ? 'holy' : 'physical');
  damageMonster(target, damage, attackElement);
  trainSkill('attack', 8); trainSkill('dexterity', Math.max(.5, 2.5 - (weapon.weight || 10) / 24)); if (range <= 1) char.zeal = Math.min(char.maxZeal || 5, char.zeal + (char.vocationId === 'warhealer' ? 1 : 0));
  effectAt(char.x, char.y, effectColor(attackElement), 'projectile', 1, target.x, target.y);
}

function nearestVisibleEnemy() {
  const char = runtime.character; if (!char || char.flags.unconscious) return false;
  const width = runtime.viewport?.width || el.worldCanvas.getBoundingClientRect().width;
  const height = runtime.viewport?.height || el.worldCanvas.getBoundingClientRect().height;
  const tileSize = TILE * (runtime.cameraZoom || 1);
  return runtime.monsters
    .filter(monster => {
      if (!monster.alive || monster.z !== char.z) return false;
      const point = screenFromWorld(monster.x, monster.y);
      return point.x + tileSize > 0 && point.y + tileSize > 0 && point.x < width && point.y < height;
    })
    .sort((a, b) => manhattan(char, a) - manhattan(char, b) || a.entityId.localeCompare(b.entityId))[0] || null;
}

function attackNearestVisibleEnemy() {
  const target = nearestVisibleEnemy();
  if (!target) return false;
  runtime.targetId = target.entityId; runtime.path = []; renderTarget(); performBasicAttack(); return true;
}

function castSpell(spellId) {
  const char = runtime.character; const spell = spellOf(spellId);
  if (!char || !spell || !(char.learnedSpells || char.spells).includes(spellId)) return;
  const now = Date.now();
  if ((char.cooldowns[spellId] || 0) > now) return;
  if (char.level < spell.level) { toast(`Requires level ${spell.level}.`, true); return; }
  if (char.mana < (spell.mana || 0) || char.zeal < (spell.zeal || 0)) { toast('Not enough mana or Zeal.', true); return; }
  if (spell.requiresSiege && !char.flags.siegeMode) { toast('Anchor Siege Mode before firing that shell.', true); return; }
  if (spell.effect === 'power_cannon') {
    char.flags.cannonPowered = !char.flags.cannonPowered; if (!char.flags.cannonPowered) char.flags.siegeMode = false;
    toast(char.flags.cannonPowered ? 'Cannon powered. Movement speed reduced; anchor to fire.' : 'Cannon powered down.');
  } else if (spell.effect === 'siege') {
    if (!char.flags.cannonPowered) { toast('Power the cannon first.', true); return; }
    char.flags.siegeMode = !char.flags.siegeMode; runtime.path = [];
    toast(char.flags.siegeMode ? 'Siege Mode anchored. Movement stopped; cannon ready.' : 'Stabilizers raised.');
  } else if (spell.effect === 'light') {
    char.statuses.lightUntil = now + 120000; char.statuses.lightRadius = spell.power || 8; progressQuestEvent('cast', 'light_orb', 1); effectAt(char.x, char.y, '#f1d06d', 'ring', 2);
  } else if (spell.effect === 'heal' || spell.effect === 'mass_heal') {
    const scale = typeof spell.power === 'number' && spell.power > 5 ? spell.power : 65;
    const magicPower = magicPowerOf(char); const amount = Math.round((scale + magicPower * 1.4) * ((char.statuses.blessedUntil || 0) > now ? 1.1 : 1));
    char.hp = Math.min(char.maxHp, char.hp + amount); floatText(char.x, char.y, `+${amount}`, 'heal'); effectAt(char.x, char.y, '#71d793', 'ring', spell.radius || 2);
    progressQuestEvent('cast_group', 'healing', 1);
  } else if (spell.effect === 'haste') {
    char.statuses.hasteUntil = now + (spell.duration || 8000); char.statuses.hastePower = spell.power || .3; effectAt(char.x, char.y, '#dce8e0', 'burst', 1);
  } else if (spell.effect === 'cleanse') {
    for (const status of ['poison', 'burning', 'shock', 'bleed', 'curse', 'slow']) delete char.statuses[status]; progressQuestEvent('cure', 'poison', 1); effectAt(char.x, char.y, '#7fdbba', 'burst', 1);
  } else if (spell.effect === 'shield') {
    char.statuses.shieldUntil = now + (spell.duration || 8000); char.statuses.shieldPower = spell.power || .35; effectAt(char.x, char.y, '#70bede', 'ring', 1);
  } else if (spell.effect === 'rage') {
    char.statuses.rageUntil = now + (spell.duration || 9000); char.statuses.ragePower = spell.power || .3; effectAt(char.x, char.y, '#d65e50', 'burst', 1);
  } else if (spell.effect === 'focus') {
    char.statuses.focusUntil = now + (spell.duration || 8500); char.statuses.focusPower = spell.power || .4; char.statuses.slow = { until: now + (spell.duration || 8500), amount: .4 }; effectAt(char.x, char.y, '#f0c85d', 'ring', 1);
  } else if (spell.effect === 'rope') {
    const ropeSpot = [...DATA.placements, ...runtime.dynamicHoles].find(place => place.x === char.x && place.y === char.y && place.z === char.z && place.targetZ > char.z);
    if (!ropeSpot) { toast('Stand on a rope spot to use Spectral Ropecall.', true); return; }
    char.x = ropeSpot.targetX; char.y = ropeSpot.targetY; char.z = ropeSpot.targetZ; runtime.camera.x = char.x; runtime.camera.y = char.y; progressQuestEvent('interact', 'rope_spot', 1);
  } else if (spell.effect === 'wall') {
    const target = monsterByEntity(runtime.targetId); const x = target?.x ?? char.x + (char.facing === 'east' ? 1 : char.facing === 'west' ? -1 : 0); const y = target?.y ?? char.y + (char.facing === 'south' ? 1 : char.facing === 'north' ? -1 : 0);
    runtime.temporaryWalls.push({ x, y, z: char.z, expiresAt: now + (spell.duration || 8000) }); effectAt(x, y, '#71a859', 'burst', 1);
  } else if (['physical', 'fire', 'ice', 'earth', 'energy', 'death', 'holy'].includes(spell.effect)) {
    const target = monsterByEntity(runtime.targetId);
    if (!target && !(spell.radius && spell.range === 0)) { toast('Select a creature first.', true); return; }
    const center = target || char;
    if (target && manhattan(char, target) > (spell.range || 1)) { toast('Target is out of spell range.', true); return; }
    const victims = runtime.monsters.filter(monster => monster.alive && monster.z === char.z && manhattan(monster, center) <= (spell.radius || 0));
    if (!spell.radius && target) victims.splice(0, victims.length, target);
    const magic = spell.effect === 'physical' && char.vocationId === 'siege_operator' ? (char.skills.artillery?.level || 1) : magicPowerOf(char); const weapon = itemOf(char.equipment.weapon) || {};
    for (const victim of victims) {
      let damage = ((effectiveItemStat(weapon.id,'attack',char) || 5) * .6 + char.level * .8 + magic * .7 + 15) * (spell.power || 1);
      if ((char.statuses.blessedUntil || 0) > now) damage *= 1.1;
      damageMonster(victim, Math.max(1, Math.round(damage * (.85 + Math.random() * .3))), spell.effect);
      effectAt(victim.x, victim.y, effectColor(spell.effect), 'burst', spell.radius || 1);
    }
    progressQuestEvent('cast_group', 'elemental_attack', 1);
    if (spell.buildsZeal) char.zeal = Math.min(char.maxZeal || 5, char.zeal + spell.buildsZeal);
  } else if (spell.effect === 'taunt') {
    for (const monster of runtime.monsters.filter(monster => monster.alive && monster.z === char.z && manhattan(monster, char) <= (spell.radius || 4))) monster.aggroTarget = char.id;
    effectAt(char.x, char.y, '#c58a56', 'ring', spell.radius || 4);
  } else if (spell.effect === 'revive') {
    if (char.hp <= 0) { char.hp = Math.round(char.maxHp * (spell.power || .5)); toast('Your soul returns to the body.'); }
    else toast('No fallen ally is in range.');
  }
  char.mana = Math.max(0, char.mana - (spell.mana || 0)); char.zeal = Math.max(0, char.zeal - (spell.zeal || 0)); char.cooldowns[spellId] = now + spell.cooldown;
  const trainingAmount = Math.max(10, 14 + Number(spell.mana || 0) * .45);
  trainSkill('magic', trainingAmount * Number(vocationOf(char)?.magicTrainingRate || 1));
  trainEquippedSpellGear(trainingAmount);
  if (spell.effect === 'physical' && char.vocationId === 'siege_operator') trainSkill('artillery', trainingAmount);
  renderAllUi(); saveGame(false);
}

function effectColor(element) { return ({ physical: '#e6e0cc', fire: '#ec7046', ice: '#76d0ed', earth: '#76a65d', poison: '#8db35b', energy: '#6ebcec', death: '#a66bd0', holy: '#f2d76b' })[element] || '#fff'; }

function damageMonster(monster, damage, element = 'physical') {
  if (!monster?.alive) return;
  monster.hp -= damage; floatText(monster.x, monster.y, `-${damage}`); effectAt(monster.x, monster.y, effectColor(element), 'burst', 1); renderTarget();
  if (monster.id === 'mob_mud_slime' && !monster.splitDone && monster.hp < monster.maxHp / 2) {
    monster.splitDone = true; const split = spawnMonster(monster.id, monster.x + 1, monster.y, monster.z, { homeX: monster.homeX, homeY: monster.homeY, respawnSeconds: monster.respawnSeconds }); if (split) { split.hp = Math.round(split.maxHp * .4); split.maxHp = split.hp; }
  }
  if (monster.hp <= 0) killMonster(monster);
}

function killMonster(monster) {
  const char = runtime.character;
  monster.alive = false; monster.hp = 0; monster.deadAt = Date.now();
  const earnedXp = experienceAward(monster.xp, char);
  char.xp += earnedXp; char.killCounts[monster.id] = (char.killCounts[monster.id] || 0) + 1;
  const vocation=vocationOf(char)||{},killHeal=Math.min(Number(vocation.killHealCap||1),Number(char.level||1)*Number(vocation.killHealLevelFactor||.001)),actualKillHeal=Math.min(killHeal,char.maxHp-char.hp);char.hp+=actualKillHeal;if(actualKillHeal>0)floatText(char.x,char.y,`+${actualKillHeal.toFixed(3)}`,'heal');
  applySocialEvent('event_heroic_kill');
  applyDefeatHappiness(monster,runtime.activeDefeatContext||'world_hunt',char);
  progressQuestEvent('kill', monster.id, 1); if (monster.questTargetId !== monster.id) progressQuestEvent('kill', monster.questTargetId, 1);
  const drops=rollDrops(monster.id),dropTable=DATA.dropTables.find(table=>table.monsterId===monster.id),scatter=Math.max(0,Number(dropTable?.scatterRadius||0));
  for(const [index,drop] of drops.entries()){const angle=index*2.399+Math.random()*.8,distance=scatter?Math.floor(Math.random()*(scatter+1)):0,dx=Math.round(Math.cos(angle)*distance),dy=Math.round(Math.sin(angle)*distance),candidateX=monster.x+dx,candidateY=monster.y+dy,clear=isPassable(candidateX,candidateY,monster.z,true);addGroundStack(drop.itemId,drop.qty,clear?candidateX:monster.x,clear?candidateY:monster.y,monster.z,{sourceType:'creature_drop',sourceId:monster.id,reason:`dropped by ${monster.name}`});}
  toast(`${monster.name} defeated · +${earnedXp} XP${earnedXp < monster.xp ? ' (tired)' : ''}${drops.length ? ' · loot dropped' : ''}.`);
  if (runtime.targetId === monster.entityId) runtime.targetId = null;
  checkLevelUp(); renderAllUi();
}

function rollDrops(monsterId, random = Math.random) {
  const table = DATA.dropTables.find(entry => entry.monsterId === monsterId || monsterId === 'boss_brood_tyrant' && entry.monsterId === 'boss_brood_tyrant');
  if (!table) {
    if (monsterId === 'mob_silk_tarantula') return [{ itemId: 'spider_silk', qty: 1 + Math.floor(random() * 2) }, { itemId: 'gold_piece', qty: 12 + Math.floor(random() * 22) }];
    return [];
  }
  const result = new Map();
  const add = (itemId, qty) => result.set(itemId, (result.get(itemId) || 0) + qty);
  for (const entry of table.entries.filter(entry => entry.tier === 'always')) add(entry.itemId, rollQuantity(entry, random));
  const pool = table.entries.filter(entry => entry.tier !== 'always');
  for (let roll = 0; roll < (table.rolls || 1); roll++) {
    let pick = random() * 100;
    for (const entry of pool) { pick -= Number(entry.chancePercent || 0); if (pick < 0) { add(entry.itemId, rollQuantity(entry, random)); break; } }
  }
  return [...result].map(([itemId, qty]) => ({ itemId, qty }));
}

function rollQuantity(entry, random = Math.random) { return Number(entry.min || 1) + Math.floor(random() * (Number(entry.max || entry.min || 1) - Number(entry.min || 1) + 1)); }

function trainSkill(skillId, amount) {
  const skill = runtime.character?.skills?.[skillId]; if (!skill) return;
  skill.xp += amount;
  while (skill.xp >= skill.next) {
    skill.xp -= skill.next; skill.level += 1;
    if (skillId === 'magic') { const vocation = vocationOf() || {}; skill.next = Math.round(skill.next * Number(vocation.magicXpGrowth || 1.13) + 30 * Number(vocation.magicXpCostMultiplier || 1)); }
    else skill.next = Math.round(skill.next * 1.13 + 30);
    toast(`${byId(DATA.skills, skillId)?.name || skillId} advanced to ${skill.level}.`);
  }
}

function checkLevelUp() {
  const char = runtime.character;
  while (char.xp >= char.xpNext) {
    char.xp -= char.xpNext; char.level += 1; char.xpNext = Math.round(char.xpNext * 1.2 + 80);
    const vocation = vocationOf(char); char.maxHp += vocation?.hpGain || 5; char.maxMana += vocation?.manaGain || 5; char.capMax += vocation?.capGain || 10; char.hp = char.maxHp; char.mana = char.maxMana;
    toast(`Level ${char.level}! Health and mana fully restored.`); effectAt(char.x, char.y, '#f2d66a', 'ring', 4);
  }
}

function npcPatrolTick(time) {
  const char = runtime.character; if (!char) return;
  let detected = false;
  for (const npc of DATA.npcs.filter(row => Array.isArray(row.patrol) && row.patrol.length)) {
    if (time - Number(npc.lastPatrolMoveAt || 0) > 1100) {
      npc.lastPatrolMoveAt = time; npc.patrolIndex = Number(npc.patrolIndex || 0) % npc.patrol.length;
      const [targetX, targetY] = npc.patrol[npc.patrolIndex]; const dx = Math.sign(targetX - npc.x); const dy = Math.sign(targetY - npc.y);
      const step = Math.abs(targetX - npc.x) >= Math.abs(targetY - npc.y) ? [dx, 0] : [0, dy];
      if (npc.x === targetX && npc.y === targetY) npc.patrolIndex = (npc.patrolIndex + 1) % npc.patrol.length;
      else if (isPassable(npc.x + step[0], npc.y + step[1], npc.z, true)) { npc.x += step[0]; npc.y += step[1]; }
    }
    if (char.flags.sneaking && npc.z === char.z) {
      const stealth = char.skills?.stealth?.level || 1; const range = clamp(6 - stealth * .035 + (currentLightRadius() > 3 ? 2 : 0), 1.5, 8);
      if (manhattan(npc, char) <= range) detected = true;
    }
  }
  char.flags.stealthDetected = detected;
  if (detected && char.z === -6) { char.x = 18; char.y = 46; char.z = 0; char.flags.sneaking = false; runtime.path = []; runtime.camera.x = char.x; runtime.camera.y = char.y; playSfx('error'); toast('An archive warden spots you sneaking and escorts you back to town.', true); }
}

function monsterTick(time) {
  const char = runtime.character;
  if (!char || char.hp <= 0 || time - runtime.lastMonsterTick < 220) return;
  runtime.lastMonsterTick = time;
  const now = Date.now();
  for (const monster of runtime.monsters) {
    if (!monster.alive) {
      if (now - monster.deadAt >= monster.respawnSeconds * 1000) { monster.alive = true; monster.hp = monster.maxHp; monster.x = monster.homeX; monster.y = monster.homeY; monster.splitDone = false; }
      continue;
    }
    if (monster.z !== char.z) continue;
    const distance = manhattan(monster, char); const zone = zoneAt(char.x, char.y, char.z);
    if (zone?.pz) continue;
    const stealthLevel = char.skills?.stealth?.level || 1;
    const lightExposure = currentLightRadius() > 2 ? 1.22 : .86;
    const sneakFactor = char.flags.sneaking ? clamp((.76 - stealthLevel * .0045) * lightExposure, .18, .9) : 1;
    const detectionRange = Math.max(monster.range, Math.round(monster.aggro * sneakFactor));
    if (distance <= detectionRange) { monster.aggroTarget = char.id; monster.alertedUntil = now + 4500; }
    const hasAggro = monster.aggroTarget === char.id && now <= Number(monster.alertedUntil || 0);
    if (!hasAggro && monster.aggroTarget) monster.aggroTarget = null;
    if (hasAggro && distance <= monster.range && now - monster.lastAttackAt > 1350 / (monster.speed || 1)) {
      monster.lastAttackAt = now; monsterAttack(monster); continue;
    }
    if (hasAggro && now - monster.lastMoveAt > 520 / (monster.speed || 1)) {
      monster.lastMoveAt = now;
      const dx = Math.sign(char.x - monster.x); const dy = Math.sign(char.y - monster.y);
      const options = Math.abs(char.x - monster.x) > Math.abs(char.y - monster.y) ? [[dx, 0], [0, dy]] : [[0, dy], [dx, 0]];
      if (monster.range > 1 && distance <= 2) options.reverse(), options[0] = [-dx, -dy];
      for (const [mx, my] of options) {
        const nx = monster.x + mx; const ny = monster.y + my;
        if (isPassable(nx, ny, monster.z) && !(nx === char.x && ny === char.y) && !runtime.monsters.some(other => other !== monster && other.alive && other.z === monster.z && other.x === nx && other.y === ny)) { monster.x = nx; monster.y = ny; break; }
      }
    } else if (!hasAggro && now - monster.lastMoveAt > 900 + Math.random() * 1500) {
      monster.lastMoveAt = now;
      const directions = [[1, 0], [-1, 0], [0, 1], [0, -1], [0, 0]].sort(() => Math.random() - .5);
      for (const [mx, my] of directions) {
        const nx = monster.x + mx; const ny = monster.y + my;
        if (Math.abs(nx - monster.homeX) > 5 || Math.abs(ny - monster.homeY) > 5) continue;
        if (isPassable(nx, ny, monster.z) && !runtime.monsters.some(other => other !== monster && other.alive && other.z === monster.z && other.x === nx && other.y === ny)) { monster.x = nx; monster.y = ny; break; }
      }
    }
  }
}

function monsterAttack(monster) {
  const char = runtime.character; let damage = monster.attack * (.8 + Math.random() * .35);
  if (monster.element === 'physical') damage -= totalArmor(char) * .45 + totalDefense(char) * .15;
  else damage -= totalArmor(char) * .08;
  if (runtime.combatStance === 'defensive') damage *= .82;
  if ((char.statuses.shieldUntil || 0) > Date.now()) damage *= 1 - (char.statuses.shieldPower || .35);
  const toughnessLevel = char.skills?.toughness?.level || 1; const progressionRules = gameRule('progression_rules');
  damage *= 1 - Math.min(Number(progressionRules.toughnessDamageReductionCap ?? .38), Math.max(0, toughnessLevel - 1) * Number(progressionRules.toughnessDamageReductionPerLevel ?? .0032));
  damage = Math.max(1, Math.round(damage)); char.hp -= damage; runtime.targetId = monster.entityId; runtime.path = []; floatText(char.x, char.y, `-${damage}`); effectAt(char.x, char.y, effectColor(monster.element), 'burst', 1); playSfx('hit');
  trainEquippedDefense(damage);
  trainSkill('toughness', Math.max(1, damage * .22));
  if (monster.range <= 2) trainSkill('melee_defence', Math.max(.5, damage * .07));
  if (monster.dot && Math.random() < .42) {
    char.statuses.poison = { until: Date.now() + 9000, damage: monster.dot, nextTick: Date.now() + 1000 };
    progressQuestEvent('status', 'poison', 1); toast('Poisoned! Use Verdant Antidote or Clearblood.', true);
  }
  if (char.hp <= 0) playerDeath(monster.name);
  renderHud();
}

function playerDeath(source) {
  const char = runtime.character; if (!char || char.flags.unconscious) return;
  char.hp = 1; char.flags.unconscious = true; char.flags.sneaking = false; char.flags.knockedOutBy = source; char.flags.knockedOutAt = Date.now();
  char.mounted = false; runtime.path = []; runtime.targetId = null; runtime.keys.clear();
  for (const monster of runtime.monsters) { monster.aggroTarget = null; monster.alertedUntil = 0; }
  delete char.statuses.poison; trainSkill('toughness', 85 + char.level * 1.5);
  openModal('UNCONSCIOUS · PLAYING DEAD', `${source} knocked ${char.name} prone`, `<div class="info-card"><h3>Enemies have lost aggro</h3><p>You are not dead yet. While prone you heal rapidly to 20% health, then continue at normal regeneration. Press a movement key to wake up, or press Space to accept defeat and return to Anchorage Harbor with a 10% total-experience loss.</p><p id="recoveryProgress">Recovery: 1 / ${char.maxHp} HP</p></div>`, '');
  const footer = document.createElement('div'); footer.className = 'modal-actions'; footer.innerHTML = '<button class="primary" id="returnHarborButton">RETURN TO HARBOR · SPACE</button>';
  el.modalRoot.querySelector('.modal')?.appendChild(footer);
  document.getElementById('returnHarborButton')?.addEventListener('click', returnToHarbor);
  saveGame(false);
}

function applyDeathExperiencePenalty() {
  const char = runtime.character; const oldLevel = char.level;
  let lifetime = Math.max(0, 100 * (char.level - 1) ** 2 + Number(char.xp || 0));
  const lost = Math.ceil(lifetime * Number(gameRule('progression_rules').deathXpLossFraction ?? .1)); lifetime = Math.max(0, lifetime - lost);
  const newLevel = Math.max(1, Math.floor(Math.sqrt(lifetime / 100)) + 1);
  char.level = newLevel; char.xp = Math.max(0, Math.floor(lifetime - 100 * (newLevel - 1) ** 2)); char.xpNext = Math.max(100, 100 * (2 * newLevel - 1));
  const levelsLost = oldLevel - newLevel; const vocation = vocationOf(char);
  if (levelsLost > 0) { char.maxHp = Math.max(100, char.maxHp - levelsLost * (vocation?.hpGain || 5)); char.maxMana = Math.max(0, char.maxMana - levelsLost * (vocation?.manaGain || 5)); char.capMax = Math.max(200, char.capMax - levelsLost * (vocation?.capGain || 10)); }
  return { lost, levelsLost };
}

function returnToHarbor() {
  const char = runtime.character; if (!char) return; const penalty = applyDeathExperiencePenalty();
  char.deathCount += 1; char.flags.unconscious = false; char.flags.knockedOutBy = null; char.hp = char.maxHp; char.mana = char.maxMana; char.x = 18; char.y = 49; char.z = 0; char.statuses = {};
  runtime.camera.x = char.x; runtime.camera.y = char.y; runtime.path = []; closeModal(); renderAllUi(); saveGame(false);
  toast(`Returned to Harbor · lost ${number(penalty.lost)} XP${penalty.levelsLost ? ` · lost ${penalty.levelsLost} level${penalty.levelsLost === 1 ? '' : 's'}` : ''}.`, true);
}

function wakeFromUnconscious() {
  const char = runtime.character; if (!char?.flags.unconscious) return;
  char.flags.unconscious = false; char.flags.knockedOutBy = null; closeModal(); trainSkill('toughness', 35); renderAllUi(); saveGame(false);
  toast(`You get back up at ${Math.ceil(char.hp)} HP. Enemies can detect you again.`);
}

function survivalTick(now) {
  const char = runtime.character; if (!char) return;
  const survival = ensureSurvival(char); const rules = gameRule('survival_rules');
  const previous = Number(survival.lastUpdatedAt || now); const elapsedSeconds = clamp((now - previous) / 1000, 0, 5); survival.lastUpdatedAt = now;
  survival.hunger = clamp(survival.hunger - elapsedSeconds / Math.max(1, Number(rules.hungerSecondsPerPoint || 180)), 0, 100);
  survival.thirst = clamp(survival.thirst - elapsedSeconds / Math.max(1, Number(rules.thirstSecondsPerPoint || 120)), 0, 100);
  survival.rest = clamp(survival.rest - elapsedSeconds / Math.max(1, Number(rules.restSecondsPerPoint || 150)), 0, 100);
  for (const need of ['Hunger', 'Thirst', 'Rest']) {
    const key = need.toLowerCase(); const warningKey = `warned${need}`;
    if (survival[key] <= 25 && !survival[warningKey]) { survival[warningKey] = true; toast(`${need} is low. ${need === 'Hunger' ? 'Eat food' : need === 'Thirst' ? 'Find a well' : 'Use a bed or rest cot'} soon.`, true); }
    if (survival[key] > 25) survival[warningKey] = false;
  }
  if (survival.hunger <= 0 && now - Number(survival.lastHungerDamageAt || 0) >= 1000 && char.hp > Number(rules.hungerHealthFloor ?? 20)) {
    survival.lastHungerDamageAt = now; char.hp = Math.max(Number(rules.hungerHealthFloor ?? 20), char.hp - 1); floatText(char.x, char.y, '-1 hunger');
  }
  if (survival.thirst <= 0 && now - Number(survival.lastThirstDamageAt || 0) >= 1000 && char.hp > Number(rules.thirstHealthFloor ?? 5)) {
    survival.lastThirstDamageAt = now; char.hp = Math.max(Number(rules.thirstHealthFloor ?? 5), char.hp - 1); floatText(char.x, char.y, '-1 thirst');
  }
}

function unconsciousTick(now) {
  const char = runtime.character; if (!char?.flags.unconscious || now - (char.flags.lastProneHealAt || 0) < 1000) return;
  if (isHungry(char)) { char.flags.lastProneHealAt = now; const progress = document.getElementById('recoveryProgress'); if (progress) progress.textContent = `Recovery: ${Math.ceil(char.hp)} / ${char.maxHp} HP · blocked by Hunger`; return; }
  char.flags.lastProneHealAt = now; const rules = gameRule('progression_rules'); const rapidUntil = Math.max(1, Math.ceil(char.maxHp * Number(rules.proneRapidHealUntilFraction ?? .2)));
  const amount = char.hp < rapidUntil ? Math.max(3, Math.ceil(char.maxHp * Number(rules.proneRapidHealPerSecondFraction ?? .035))) : Math.max(1, Math.round(char.level / 80));
  char.hp = Math.min(char.maxHp, char.hp + amount); trainSkill('toughness', char.hp < rapidUntil ? 2 : .2); trainSkill('first_aid', .35);
  const progress = document.getElementById('recoveryProgress'); if (progress) progress.textContent = `Recovery: ${Math.ceil(char.hp)} / ${char.maxHp} HP · ${char.hp < rapidUntil ? 'rapid prone healing' : 'normal prone healing'}`;
  renderHud();
}

function statusTick(now) {
  const char = runtime.character;
  const poison = char?.statuses?.poison;
  if (poison && poison.until <= now) delete char.statuses.poison;
  else if (poison && poison.nextTick <= now) { poison.nextTick = now + 1000; char.hp -= poison.damage; floatText(char.x, char.y, `-${poison.damage}`); if (char.hp <= 0) playerDeath('poison'); }
}

function fieldTick(now) {
  runtime.temporaryFields = runtime.temporaryFields.filter(field => field.expiresAt > now);
  for (const field of runtime.temporaryFields) {
    if (field.nextTick > now) continue;
    field.nextTick = now + 1000;
    for (const monster of runtime.monsters.filter(monster => monster.alive && monster.x === field.x && monster.y === field.y && monster.z === field.z)) damageMonster(monster, Number(field.damage || 1), field.effect);
  }
}

function effectAt(x, y, color, kind = 'burst', radius = 1, targetX = x, targetY = y) { runtime.effects.push({ id: uid('fx'), x, y, z: runtime.character?.z || 0, targetX, targetY, color, kind, radius, startedAt: performance.now(), duration: kind === 'projectile' ? 300 : 650 }); }

function floatText(x, y, text, type = '') {
  const point = screenFromWorld(x, y); const node = document.createElement('span'); node.className = `combat-float ${type}`; node.textContent = text; node.style.left = `${point.x + TILE / 2}px`; node.style.top = `${point.y + 5}px`; el.combatFloatLayer.appendChild(node); setTimeout(() => node.remove(), 900);
}

function gameLoop(time) {
  const char = runtime.character;
  if (char && runtime.worldReady) {
    if(time-runtime.lastPlaytimeTick>=1000){const seconds=Math.floor((time-runtime.lastPlaytimeTick)/1000);char.playSeconds=Number(char.playSeconds||0)+seconds;char.lastPlayedAt=nowIso();runtime.lastPlaytimeTick+=seconds*1000;}
    survivalTick(Date.now());
    if (char.flags.unconscious) {
      unconsciousTick(Date.now());
      if (time - (runtime.lastUiTick || 0) > 220) { runtime.lastUiTick = time; renderHud(); renderTarget(); }
      if (runtime.save.settings.autosave && time - runtime.lastSaveAt > 8000) saveGame(false);
      drawWorld(time); requestAnimationFrame(gameLoop); return;
    }
    if (!runtime.modalOpen && !el.devOverlay.classList.contains('hidden')) {
      // Developer mode intentionally pauses movement and combat.
    } else if (!runtime.modalOpen) {
      const moveDelay = movementDelay();
      if (time - runtime.lastMoveAt >= moveDelay) {
        let direction = null;
        if (runtime.keys.has('w') || runtime.keys.has('arrowup')) direction = [0, -1];
        else if (runtime.keys.has('s') || runtime.keys.has('arrowdown')) direction = [0, 1];
        else if (runtime.keys.has('a') || runtime.keys.has('arrowleft')) direction = [-1, 0];
        else if (runtime.keys.has('d') || runtime.keys.has('arrowright')) direction = [1, 0];
        if (direction) { runtime.path = []; moveOne(...direction); runtime.lastMoveAt = time; }
        else if (runtime.path.length) { const next = runtime.path.shift(); moveOne(next.x - char.x, next.y - char.y); runtime.lastMoveAt = time; }
      }
      if (runtime.targetId) performBasicAttack();
      npcPatrolTick(time); monsterTick(time); statusTick(Date.now()); fieldTick(Date.now());
      if (time - runtime.lastRegenAt > 1000) {
        runtime.lastRegenAt = time;
        if (!isHungry(char)) { char.hp = Math.min(char.maxHp, char.hp + classRegen('health',char)); char.mana = Math.min(char.maxMana, char.mana + classRegen('mana',char)); }
      }
    }
    if (time - (runtime.lastUiTick || 0) > 220) { runtime.lastUiTick = time; renderHud(); renderSpellBar(); renderTarget(); }
    if (runtime.save.settings.autosave && time - runtime.lastSaveAt > 8000) saveGame(false);
    drawWorld(time);
  }
  requestAnimationFrame(gameLoop);
}

const AUTHORING_WORKBENCHES = {
  itemStudio: { label: 'Item Forge', icon: '◆', categories: ['items', 'gearLevelCurves', 'itemUpgradeServices', 'provenancePolicies', 'emojiPalette', 'primitiveItems', 'gameplayInventory', 'externalItems'], summary: 'Items, emoji, authorship, custody, gear score, natural level curves, paid upgrades, slots, stats and source bindings.' },
  creatureStudio: { label: 'Creature Lab', icon: '♜', categories: ['monsters', 'primitiveEnemies', 'aegisCreatures', 'externalClasses', 'rtsUnitTypes'], summary: 'Creatures, enemies, bosses, AI, combat, resistances, drops, tiers and on-hit effects.' },
  npcStudio: { label: 'NPC Director', icon: '♟', categories: ['npcs', 'primitiveNpcs'], summary: 'NPC identity, placement, dialogue, patrols, factions, quests, shops, spells and owned inventory.' },
  shopStudio: { label: 'Shop Builder', icon: '¤', categories: ['shops', 'primitiveShops'], summary: 'Stock, buy and sell permissions, quantities, price multipliers, restocking and merchant ownership.' },
  spellStudio: { label: 'Spell & Rune Lab', icon: '✦', categories: ['spells', 'primitiveSpells', 'primitivePrayers', 'rtsSpells', 'godPowers'], summary: 'Spell costs, runes, vocation access, targeting, cells, damage, statuses, cooldowns and magic XP.' },
  questStudio: { label: 'Quest Architect', icon: '⚑', categories: ['quests', 'socialEventDefinitions', 'primitiveQuests', 'encounters'], summary: 'Givers, social requirements, events, objectives, choices, rewards, failures, prerequisites and guidance targets.' },
  buildingStudio: { label: 'Building Architect', icon: '▦', categories: ['buildings', 'externalBuildings', 'rtsBuildingTypes', 'buildingComplexes', 'buildingTypes'], summary: 'Placement, geometry, floors, collision, parts, costs, ownership, effects, tiers, services and complexes.' },
  classStudio: { label: 'Class & Progression', icon: '♛', categories: ['villagerClasses', 'vocations', 'externalClasses', 'skills', 'primitiveSkills', 'aegisSkills', 'statDesignerSkills', 'statDefinitions', 'currencyDefinitions'], summary: 'Vocations, promotions, level gains, magic growth, skills, stats, currencies and gear ladders.' },
  worldStudio: { label: 'World & Scene Studio', icon: '⌖', categories: ['scenes','sceneDoors','zones','spawns','spawnerDefinitions','simulatedPlayers','placements','primitiveSpecialObjects','mapDefinitions','mapNodes','tilePalette','levelTiles'], summary: 'Scenes, variable grids, map-link doors, advanced spawners, simulated players, terrain, placements, resources and travel.' },
  sequenceStudio: { label: 'Dialogue & Sequence', icon: '⤳', categories: ['dialogueGlobals', 'sequenceDefinitions', 'sequenceNodes', 'sequenceEdges', 'unityComponentTypes', 'inventorySlotSets'], summary: 'Typed globals, conditions, actions, visual-graph nodes, edges, Unity identities and slot sets.' },
  formationStudio: { label: 'Formation & Realm', icon: '▥', categories: ['rtsFormations', 'rtsUnitTypes', 'rtsSpells', 'rtsBuildingTypes', 'buildingComplexes', 'rtsResearch', 'research', 'jobs'], summary: 'Formations, companies, combat units, realm jobs, research, construction and god-view content.' },
  godStudio: { label: 'God & Pantheon Builder', icon: '☼', categories: ['gods', 'realms', 'pantheons', 'godPowers', 'reputations', 'reputationGoals'], summary: 'God identities, competing interests, goals, domains, powers, followers, doctrines, rivalries and favor rules.' },
  guildStudio: { label: 'Guild & Hall Builder', icon: '⚜', categories: ['guilds', 'guildHalls'], summary: 'Guild identity, hall rooms, shops, arenas, storage, human-character membership, leaders, ranks, treasuries and permissions.' },
  socialStudio: { label: 'Personality & Society', icon: '♥', categories: ['personalities','archetypes','aspirations','fears','preferences','feelingRelationships','socialStats','socialEventDefinitions','happinessContexts','factions','factionHappinessRules','characterAffections','characterTags'], summary: 'Personalities, happiness, expandable defeat contexts, faction reactions, aspirations, fears, preferences, relationships, social stats, events and tags.' },
  leaderboardStudio: { label: 'Leaderboards & Reputation', icon: '≋', categories: ['leaderboardDefinitions','reputations','reputationGoals','characterTags'], summary: 'Live sortable character rankings by numeric path and tag, plus competing god and faction reputations.' },
  natureStudio: { label: 'Nature Designer', icon: '❧', categories: ['natureDefinitions', 'natureZones', 'fishingDropTables', 'smithingRecipes'], summary: 'Flora, fauna, minerals, fishing rewards, smithing recipes, harvests, regrowth, density and regional ecology.' },
  villageStudio: { label: 'Village Designer', icon: '⌂', categories: ['villages', 'villageStores', 'villageDistricts', 'villageServices', 'villageRoutes'], summary: 'Districts, account-shared stores, buildings, residents, shops, services, hours, routes and guaranteed walkability.' },
  progressionStudio: { label: 'Tier & Branch Upgrade Designer', icon: '⟰', categories: ['upgradeCurrencies','upgradeTierDefinitions','upgradeBranches','branchingUpgradeNodes','progressionTracks','progressionNodes','progressionLoops','perks','upgrades'], summary: 'Character, class, equipment and building tiers; branching choices; escalating costs; prerequisites; and mutations spanning combat, harvesting, crafting and rewards.' },
  rulesStudio: { label: 'Rules & Relationships', icon: '∞', categories: ['gameRules', 'formulaDefinitions', 'effectTypes', 'relationships', 'conditionOperators', 'mutationTypes', 'runtimeVariables', 'runtimeSchemas', 'persistenceRules', 'eventTypes', 'specialObjectTypes', 'idAliases'], summary: 'Formulas, effects, typed variables, mutations, conditions, aliases and every cross-record relationship.' }
};

const DEV_SECTIONS = [
  ['authoringHome', 'Authoring Home'], ['adminPanel', 'Admin & Sessions'], ['schemaStudio', 'Schema Studio'], ['runtimeInspector', 'Live Simulation'], ['integrationVault', 'Integration Vault'],
  ...Object.entries(AUTHORING_WORKBENCHES).map(([key, value]) => [key, value.label]),
  ['integrationOverview', 'Integration Map'], ['levelEditor', 'Level Editor'], ['projectMeta', 'Project'],
  ['integrationSystems', 'Systems'], ['worlds', 'Worlds'], ['continents', 'Continents'], ['villages', 'Villages'], ['gameModes', 'Game Modes'], ['schemaFields', 'Schema Fields'], ['categorySchemas', 'Category Schemas'], ['relationships', 'Relationships'], ['idAliases', 'ID Aliases'], ['formulaDefinitions', 'Formulas'], ['effectTypes', 'Effect Types'], ['apiActions', 'API Actions'], ['externalTables', 'External Tables'], ['externalRecords', 'External Records'],
  ['characters', 'Characters'], ['vocations', 'Vocations'], ['monsters', 'Monsters'], ['items', 'Items'], ['spells', 'Spells'], ['quests', 'Quests'],
  ['npcs', 'NPCs'], ['questGivers', 'Quest Givers'], ['shops', 'Shops'], ['dropTables', 'Drop Controller'], ['dropTableData', 'Drop Table Data'], ['skills', 'Skills'], ['zones', 'Zones'],
  ['spawns', 'Spawns'], ['buildings', 'Buildings'], ['buildingTypes', 'Building Types'], ['placements', 'Placements'], ['houses', 'Houses'], ['furniture', 'Furniture'], ['mounts', 'Mounts'],
  ['externalClasses', 'Aegis Classes'], ['externalItems', 'Aegis Items'], ['externalBuildings', 'Aegis Buildings'], ['entityFamilies', 'AI Families'], ['jobs', 'Jobs'], ['research', 'Research'],
  ['tailoringRecipes', 'Tailoring'], ['mageTowerFloors', 'Tower Rooms'], ['runeDispensers', 'Rune Presses'], ['butlers', 'Butlers'],
  ['gods', 'Gods'], ['pantheons', 'Pantheons'], ['guilds', 'Guilds'], ['natureDefinitions', 'Nature Definitions'], ['natureZones', 'Nature Zones'], ['villageDistricts', 'Village Districts'], ['villageServices', 'Village Services'], ['villageRoutes', 'Village Routes'], ['progressionTracks', 'Progression Tracks'], ['progressionNodes', 'Progression Nodes'], ['progressionLoops', 'Progression Loops'], ['perks', 'Perks'], ['upgrades', 'Upgrades'],
  ['tilePalette', 'Tile Palette'], ['levelTiles', 'Level Tiles'], ['gameRules', 'Game Rules']
];

function openDeveloper(tab = 'authoringHome') {
  if(!canOpenDeveloper()){toast('Developer Mode is hidden for this account.',true);return;}
  runtime.activeDevTab = tab;
  el.devOverlay.classList.remove('hidden');
  renderSharedContextBar(); renderDevTabs(); renderDevContent();
  if (!el.consoleLog.children.length) {
    logConsole(`Emberwake World Data Workbench ${APP_VERSION} ready.`);
    logConsole(`${DATA.monsters.length} creature definitions, ${DATA.quests.length} completable quests, ${DATA.items.length} item templates, ${DATA.spells.length} spells.`);
  }
}

function closeDeveloper() { el.devOverlay.classList.add('hidden'); runtime.activeDevTab = 'authoringHome'; runtime.devStudioCategory = null; runtime.devSearch = ''; el.devSearch.value = ''; el.worldCanvas.focus(); }

function canAuthorData() {
  return location.protocol === 'file:' || Boolean(runtime.server.status === 'online' && runtime.server.authenticated && runtime.server.access === 'approved' && runtime.server.capabilities?.canAuthor);
}

function isAdminMode() { return location.protocol==='file:'||Boolean(runtime.server.status==='online'&&runtime.server.authenticated&&runtime.server.access==='approved'&&['admin','server_owner'].includes(runtime.server.role)); }
function canOpenDeveloper(){return location.protocol==='file:'||canAuthorData();}
function updatePermissionVisibility(){const dev=document.getElementById('devButton');if(dev)dev.classList.toggle('hidden',!canOpenDeveloper());const spawner=document.getElementById('devMonsterSpawner');if(spawner)spawner.classList.toggle('hidden',!isAdminMode());const tools=document.getElementById('adminProfileTools');if(tools)tools.classList.toggle('hidden',!isAdminMode());const select=document.getElementById('adminStarterClass');if(select&&!select.options.length)select.innerHTML=DATA.vocations.map(row=>`<option value="${row.id}">${escapeHtml(row.name)}</option>`).join('');}

function createAdminStarter(vocationId){if(!isAdminMode())return;const vocation=byId(DATA.vocations,vocationId);if(!vocation)return;const template=deepClone(DATA.characters[0]);const benchmark=runtime.save.characters.find(row=>row.id==='char_4')||DATA.characters[3];const id=uid(`admin_${vocationId}`);Object.assign(template,{id,slot:Math.max(0,...runtime.save.characters.map(row=>Number(row.slot||0)))+1,name:`${vocation.name} Initiate`,vocationId,level:1,xp:0,xpNext:120,hp:150,maxHp:150,mana:80,maxMana:80,gold:125,x:17,y:49,z:0,location:'Anchorage Harbor',scenario:'Admin Level-One Test Path',scenarioText:`A fresh ${vocation.name} beginning with an upgrade budget equal to twice Calder Lux’s current equipped gear score.`,gearScoreBudget:totalGearScore(benchmark)*2,adminStarterFor:vocationId,itemProgress:{},playSeconds:0,lastPlayedAt:null,tags:[vocationId,'playable','admin_test','level_one'],socialStats:Object.fromEntries(DATA.socialStats.map(stat=>[stat.id,stat.defaultValue])),reputations:Object.fromEntries(DATA.reputations.map(rep=>[rep.id,0])),quests:makeQuestStates('Q_01'),flags:{tutorialSeen:false,bridgeRepaired:false,adminStarter:true}});runtime.save.characters.push(template);DATA.characterTags.push({id:`tags_${id}`,name:`${template.name} Tags`,characterId:id,tags:template.tags});runtime.selectedProfileId=id;saveGame(false);renderProfileCards();el.continueButton.disabled=false;toast(`${template.name} created with ${number(template.gearScoreBudget)} gear-score budget.`);}

function openAdminMonsterSpawner(){if(!isAdminMode()||!runtime.character)return;const x=Math.round(runtime.camera.x),y=Math.round(runtime.camera.y),z=runtime.character.z;openModal('ADMIN WORLD CONTROL','Spawn at Camera Focus',`<div class="info-card"><p>Camera focus X ${x}, Y ${y}, Z ${z}. The spawned creature uses its full authored definition.</p></div><form id="adminSpawnForm" class="auth-form"><label>MONSTER<select name="monsterId">${DATA.monsters.map(monster=>`<option value="${monster.id}">${escapeHtml(monster.name)} · LV ${monster.level}</option>`).join('')}</select></label><label>COUNT<input name="count" type="number" min="1" max="30" value="1"></label><button>SPAWN AT CAMERA</button></form>`);document.getElementById('adminSpawnForm')?.addEventListener('submit',event=>{event.preventDefault();const form=new FormData(event.currentTarget),count=clamp(Number(form.get('count')||1),1,30);for(let index=0;index<count;index++)spawnMonster(String(form.get('monsterId')),clamp(x+(index%5)-2,0,WORLD_W-1),clamp(y+Math.floor(index/5),0,WORLD_H-1),z,{homeX:x,homeY:y,respawnSeconds:300});closeModal();toast(`${count} monster${count===1?'':'s'} spawned at the camera focus.`);});}

function developerSectionIsMutable(key = runtime.activeDevTab) {
  return !['authoringHome', 'adminPanel', 'integrationOverview'].includes(key);
}

function devRows(key) {
  if (AUTHORING_WORKBENCHES[key]) return AUTHORING_WORKBENCHES[key].categories.flatMap(category => DATA[category] || []);
  if (key === 'authoringHome' || key === 'adminPanel' || key === 'schemaStudio') return DATA.authoringCategories;
  if (key === 'runtimeInspector') return DATA.runtimeVariables;
  if (key === 'integrationVault') return DATA.sourceRegistryCounts;
  return key === 'characters' ? runtime.save.characters : key === 'projectMeta' ? [DATA.meta] : key === 'integrationOverview' ? DATA.integrationSystems : key === 'levelEditor' || key === 'levelTiles' ? DATA.levelTiles : key === 'dropTableData' ? DATA.dropTables : DATA[key] || [];
}

function renderSharedContextBar() {
  if (!el.sharedContextBar) return;
  const context = runtime.save.world.sharedContext = runtime.save.world.sharedContext || deepClone(DEFAULT_SAVE.world.sharedContext);
  const specs = [
    ['godName', 'OVERSEER', []], ['worldId', 'WORLD', DATA.worlds], ['continentId', 'CONTINENT', DATA.continents], ['villageId', 'VILLAGE', DATA.villages],
    ['creatureKind', 'CREATURE TYPE', [{ id: 'ox', name: 'Ox' }, { id: 'wolf', name: 'Wolf' }, { id: 'ape', name: 'Ape' }, { id: 'tortoise', name: 'Tortoise' }]], ['creatureName', 'CREATURE NAME', []], ['gameModeId', 'GAME MODE', DATA.gameModes]
  ];
  el.sharedContextBar.innerHTML = specs.map(([field, label, options]) => {
    const listId = `context_${field}`;
    return `<label><span>${label}</span><input data-context-field="${field}" list="${listId}" value="${escapeHtml(context[field] || '')}" placeholder="Choose or type a new value"><datalist id="${listId}">${options.map(row => `<option value="${escapeHtml(row.id)}">${escapeHtml(row.name || row.id)}</option>`).join('')}</datalist></label>`;
  }).join('');
  el.sharedContextBar.querySelectorAll('[data-context-field]').forEach(input => input.addEventListener('change', () => {
    const field = input.dataset.contextField; const value = input.value.trim(); if (!value) return;
    context[field] = value;
    const collection = field === 'worldId' ? DATA.worlds : field === 'continentId' ? DATA.continents : field === 'villageId' ? DATA.villages : field === 'gameModeId' ? DATA.gameModes : null;
    if (collection && !byId(collection, value)) collection.push({ id: value, name: value.replaceAll('_', ' '), sourceSystem: 'emberwake', createdFromContextBar: true });
    queueGameEvent('shared_context_changed', { field, value }); saveGame(false); renderDevTabs();
  }));
}

function renderDevTabs() {
  el.devTabs.innerHTML = DEV_SECTIONS.map(([key, label]) => `<button data-dev-tab="${key}" class="${runtime.activeDevTab === key ? 'active' : ''}">${label}<b>${devRows(key).length}</b></button>`).join('');
  el.devTabs.querySelectorAll('[data-dev-tab]').forEach(button => button.addEventListener('click', () => { const nextTab = button.dataset.devTab; if (AUTHORING_WORKBENCHES[nextTab] && !AUTHORING_WORKBENCHES[nextTab].categories.includes(runtime.devStudioCategory)) runtime.devStudioCategory = AUTHORING_WORKBENCHES[nextTab].categories[0]; runtime.activeDevTab = nextTab; renderDevTabs(); renderDevContent(); }));
}

function renderIntegrationOverview() {
  const counts = { classes: DATA.externalClasses.length, buildings: DATA.externalBuildings.length, items: DATA.externalItems.length, skills: 15, jobs: DATA.jobs.length, research: DATA.research.length, tables: DATA.externalTables.filter(row => row.sourceSystem === 'sovereign_aegis').length, actions: DATA.apiActions.length };
  const systemCards = DATA.integrationSystems.map(system => `<article class="contract-card"><header><span>${escapeHtml(system.status)}</span><h3>${escapeHtml(system.name)}</h3></header><p>${escapeHtml(system.authority)}</p><dl><dt>Schema</dt><dd>${system.schemaVersion}</dd><dt>Content</dt><dd>${system.contentVersion}</dd><dt>Ownership</dt><dd>${escapeHtml(system.ownership)}</dd><dt>Conflict</dt><dd>${escapeHtml(system.conflictPolicy)}</dd></dl><button data-open-system="${system.id}">OPEN ROWS</button></article>`).join('');
  el.devSummary.textContent = `${DATA.integrationSystems.length} systems · ${DATA.schemaFields.length} tracked schema fields · ${DATA.relationships.length} authored relationships`;
  el.devContent.innerHTML = `<div class="contract-overview"><section class="contract-counts">${Object.entries(counts).map(([key, value]) => `<article><b>${value}</b><span>${escapeHtml(key)}</span></article>`).join('')}</section><section class="contract-layers"><article><b>DEFINITION</b><span>Static editable records and stable IDs. What a thing is.</span></article><i>→</i><article><b>RUNTIME</b><span>Instances, positions, targets and temporary state. This thing now.</span></article><i>→</i><article><b>PERSISTENCE</b><span>Flattened JSON/MySQL snapshots. Pointers are stored as IDs.</span></article></section><section class="contract-rules"><h2>INTEROPERABILITY RULES ENFORCED HERE</h2><p>Unknown integration fields survive imports. Skills, flags, kills, collections and achievements merge. Definitions and world snapshots remain separate. Runtime references such as meshes, targets and definition pointers are never authored into the save. Millisecond timestamps are used for cooldowns; ISO dates are used for audits. Every editable category gets stable ID, icon directory, model directory, description and tooltip fields.</p></section><section class="contract-grid">${systemCards}</section></div>`;
  el.devContent.querySelectorAll('[data-open-system]').forEach(button => button.addEventListener('click', () => { runtime.activeDevTab = 'integrationSystems'; runtime.devSearch = button.dataset.openSystem; el.devSearch.value = runtime.devSearch; renderDevTabs(); renderDevContent(); }));
}

function categoryDefinition(storageKey) { return DATA.authoringCategories.find(category => category.storageKey === storageKey); }
function workbenchForCategory(storageKey) { return Object.keys(AUTHORING_WORKBENCHES).find(key => AUTHORING_WORKBENCHES[key].categories.includes(storageKey)) || 'rulesStudio'; }
function valueAtPath(object, path) { return path.split('.').reduce((value, key) => value == null ? undefined : value[key], object); }
function setValueAtPath(object, path, value) {
  const keys = path.split('.'); let cursor = object;
  keys.slice(0, -1).forEach(key => { if (!cursor[key] || typeof cursor[key] !== 'object') cursor[key] = {}; cursor = cursor[key]; });
  cursor[keys.at(-1)] = value;
}
function inferAuthoringType(value) { return Array.isArray(value) ? 'array' : value === null ? 'string' : typeof value === 'object' ? 'object' : typeof value === 'boolean' ? 'boolean' : typeof value === 'number' ? 'number' : 'string'; }
function authoringFieldsFor(category, row) {
  const authored = DATA.fieldDefinitions.filter(field => field.category === category);
  const known = new Set(authored.map(field => field.path));
  const inferred = Object.keys(row || {}).filter(path => !known.has(path)).map(path => ({ id: `inferred_${category}_${path}`, name: path, category, path, label: path.replace(/([A-Z])/g, ' $1').replace(/^./, value => value.toUpperCase()), group: ['iconDirectory', 'modelDirectory', 'description', 'tooltip'].includes(path) ? 'Metadata' : 'Additional / source-specific', valueType: inferAuthoringType(row[path]), required: path === 'id', options: [], referenceCategory: '', persistence: 'definition', mergeRule: 'preserve' }));
  return [...authored, ...inferred];
}
function recordDisplayName(row, index = 0) { return row?.name || row?.displayName || row?.label || row?.id || `Record ${index + 1}`; }

function renderAuthoringHome() {
  const totalDefinitions = DATA.authoringCategories.reduce((sum, category) => sum + (DATA[category.storageKey]?.length || 0), 0);
  const layerCounts = { definition: totalDefinitions, runtime: (runtime.monsters?.length || 0) + (runtime.npcs?.length || 0), persistence: EDITABLE_CATALOG_KEYS.length };
  el.devSummary.textContent = `${DATA.authoringCategories.length} modular categories · ${DATA.fieldDefinitions.length} typed field controls · ${totalDefinitions} editable definitions`;
  el.devContent.innerHTML = `<div class="authoring-home">
    <section class="authoring-hero"><div><span>COMPLETE SIMULATION CONTROL</span><h2>Authoring Control Center</h2><p>Create categories, add typed fields, edit every definition, connect records, inspect live instances and preserve all source-system data without changing the five-file architecture.</p></div><button data-open-dev="schemaStudio">CREATE A CATEGORY OR FIELD</button></section>
    <section class="layer-meter">${Object.entries(layerCounts).map(([name, count]) => `<article class="layer-${name}"><b>${number(count)}</b><span>${name.toUpperCase()}</span><p>${name === 'definition' ? 'What every thing is' : name === 'runtime' ? 'What exists right now' : 'What exports and stores'}</p></article>`).join('')}</section>
    <section class="workbench-grid">${Object.entries(AUTHORING_WORKBENCHES).map(([key, studio]) => `<button data-open-dev="${key}"><i>${studio.icon}</i><span><b>${escapeHtml(studio.label)}</b><small>${studio.categories.reduce((sum, category) => sum + (DATA[category]?.length || 0), 0)} definitions across ${studio.categories.length} registries</small><em>${escapeHtml(studio.summary)}</em></span></button>`).join('')}</section>
    <section class="authoring-audit"><header><h3>CONTRACT COVERAGE</h3><button data-open-dev="integrationVault">OPEN INTEGRATION VAULT</button></header>${DATA.sourceRegistryCounts.map(row => `<div class="${row.status === 'complete' ? 'complete' : 'partial'}"><span>${escapeHtml(row.sourceSystem)}</span><b>${escapeHtml(row.registry)}</b><em>${row.loadedCount} / ${row.verifiedCount}</em><small>${escapeHtml(row.status)}</small></div>`).join('')}</section>
  </div>`;
  el.devContent.querySelectorAll('[data-open-dev]').forEach(button => button.addEventListener('click', () => { runtime.activeDevTab = button.dataset.openDev; renderDevTabs(); renderDevContent(); }));
}

function renderSchemaStudio() {
  runtime.devSchemaCategory = runtime.devSchemaCategory || 'items';
  let category = categoryDefinition(runtime.devSchemaCategory) || DATA.authoringCategories[0];
  if (!category) return;
  runtime.devSchemaCategory = category.storageKey;
  const fields = DATA.fieldDefinitions.filter(field => field.category === category.storageKey);
  el.devSummary.textContent = `${DATA.authoringCategories.length} categories · ${DATA.fieldDefinitions.length} fields · this schema has ${fields.length} authored fields`;
  el.devContent.innerHTML = `<div class="schema-studio"><aside class="studio-list"><header><span>MODULAR REGISTRIES</span><h2>Categories</h2></header><div>${DATA.authoringCategories.map(row => `<button data-schema-category="${row.storageKey}" class="${row.storageKey === category.storageKey ? 'active' : ''}"><b>${escapeHtml(row.name)}</b><small>${row.storageKey} · ${DATA[row.storageKey]?.length || 0} records</small></button>`).join('')}</div><form id="newCategoryForm" class="schema-new"><b>NEW CATEGORY</b><input name="label" placeholder="Display name" required><input name="storageKey" placeholder="stableStorageKey" required><select name="entityType"><option>custom</option><option>item</option><option>building</option><option>npc</option><option>creature</option><option>spell</option><option>quest</option><option>runtime</option></select><button>CREATE CATEGORY</button></form></aside>
    <section class="schema-main"><header class="studio-title"><div><span>SCHEMA + PERSISTENCE CONTRACT</span><h2>${escapeHtml(category.name)}</h2><p>${escapeHtml(category.storageKey)} · ${escapeHtml(category.sourceSystem)} · unknown fields ${category.preserveUnknownFields ? 'preserved' : 'replaced'}</p></div><button data-open-category="${category.storageKey}">OPEN RECORDS</button></header>
    <div class="schema-category-settings">${['name', 'entityType', 'sourceSystem', 'layer', 'runtimeCollection', 'persistence'].map(field => `<label>${field.replace(/([A-Z])/g, ' $1').toUpperCase()}<input data-category-setting="${field}" value="${escapeHtml(category[field] ?? '')}"></label>`).join('')}<label>STABLE IDS<select data-category-setting="stableIdRequired"><option value="true" ${category.stableIdRequired ? 'selected' : ''}>required</option><option value="false" ${!category.stableIdRequired ? 'selected' : ''}>optional</option></select></label><label>UNKNOWN FIELDS<select data-category-setting="preserveUnknownFields"><option value="true" ${category.preserveUnknownFields ? 'selected' : ''}>preserve</option><option value="false" ${!category.preserveUnknownFields ? 'selected' : ''}>replace</option></select></label></div>
    <form id="newFieldForm" class="field-author"><header><b>ADD A TYPED FIELD</b><span>Every new field immediately appears in the matching authoring workbench.</span></header><input name="path" placeholder="fieldPath" required><input name="label" placeholder="Visible label" required><input name="group" placeholder="Inspector group" value="Custom"><select name="valueType"><option>string</option><option>text</option><option>number</option><option>boolean</option><option>color</option><option>enum</option><option>reference</option><option>array</option><option>object</option></select><select name="referenceCategory"><option value="">No reference</option>${DATA.authoringCategories.map(row => `<option value="${row.storageKey}">${escapeHtml(row.name)}</option>`).join('')}</select><input name="defaultValue" placeholder="Default value / JSON"><input name="min" type="number" placeholder="Minimum"><input name="max" type="number" placeholder="Maximum"><button>ADD FIELD</button></form>
    <div class="schema-fields">${fields.map(field => `<article data-schema-field-id="${field.id}"><header><b>${escapeHtml(field.label || field.path)}</b><code>${escapeHtml(field.path)}</code><button data-delete-schema-field="${field.id}">×</button></header><div>${[['group', field.group], ['valueType', field.valueType], ['referenceCategory', field.referenceCategory], ['persistence', field.persistence], ['scope', field.scope], ['mergeRule', field.mergeRule], ['min', field.min], ['max', field.max]].map(([name, value]) => `<label>${name}<input data-schema-field-setting="${name}" value="${escapeHtml(value ?? '')}"></label>`).join('')}<label>required<select data-schema-field-setting="required"><option value="true" ${field.required ? 'selected' : ''}>true</option><option value="false" ${!field.required ? 'selected' : ''}>false</option></select></label></div></article>`).join('') || '<div class="target-empty">No authored fields yet. Source fields still appear automatically and are never discarded.</div>'}</div></section></div>`;
  el.devContent.querySelectorAll('[data-schema-category]').forEach(button => button.addEventListener('click', () => { runtime.devSchemaCategory = button.dataset.schemaCategory; renderSchemaStudio(); }));
  el.devContent.querySelectorAll('[data-category-setting]').forEach(input => input.addEventListener('change', () => { const key = input.dataset.categorySetting; category[key] = ['stableIdRequired', 'preserveUnknownFields'].includes(key) ? input.value === 'true' : input.value; saveGame(false); renderDevTabs(); }));
  el.devContent.querySelectorAll('[data-schema-field-setting]').forEach(input => input.addEventListener('change', () => { const article = input.closest('[data-schema-field-id]'); const field = DATA.fieldDefinitions.find(row => row.id === article?.dataset.schemaFieldId); if (!field) return; const key = input.dataset.schemaFieldSetting; field[key] = key === 'required' ? input.value === 'true' : ['min', 'max'].includes(key) && input.value !== '' ? Number(input.value) : input.value; saveGame(false); }));
  el.devContent.querySelectorAll('[data-delete-schema-field]').forEach(button => button.addEventListener('click', () => { const index = DATA.fieldDefinitions.findIndex(row => row.id === button.dataset.deleteSchemaField); if (index >= 0 && confirm('Delete this field control? Existing record values are preserved.')) DATA.fieldDefinitions.splice(index, 1); saveGame(false); renderSchemaStudio(); }));
  document.getElementById('newCategoryForm')?.addEventListener('submit', event => {
    event.preventDefault(); const form = new FormData(event.currentTarget); const storageKey = String(form.get('storageKey') || '').trim().replace(/[^a-zA-Z0-9_]/g, ''); if (!storageKey) return;
    if (!Array.isArray(DATA[storageKey])) DATA[storageKey] = [];
    if (!EDITABLE_CATALOG_KEYS.includes(storageKey)) EDITABLE_CATALOG_KEYS.push(storageKey);
    if (!categoryDefinition(storageKey)) DATA.authoringCategories.push({ id: `category_${storageKey}`, name: String(form.get('label') || storageKey), storageKey, entityType: String(form.get('entityType') || 'custom'), sourceSystem: 'emberwake', layer: 'definition', runtimeCollection: '', persistence: 'catalog + JSON + MySQL', stableIdRequired: true, preserveUnknownFields: true, fourStringFieldsRequired: true, builderPreset: 'custom' });
    for (const [path, group, valueType] of sharedMetadataFieldSpecs) if (!DATA.fieldDefinitions.some(field => field.category === storageKey && field.path === path)) DATA.fieldDefinitions.push({ id: `field_${storageKey}_${path}`, name: path, category: storageKey, path, label: path, group, valueType, required: false, options: [], referenceCategory: '', defaultValue: '', persistence: 'definition', scope: 'definition', mergeRule: 'replace', sourceSystem: 'emberwake' });
    runtime.devSchemaCategory = storageKey; saveGame(false); renderDevTabs(); renderSchemaStudio();
  });
  document.getElementById('newFieldForm')?.addEventListener('submit', event => {
    event.preventDefault(); const form = new FormData(event.currentTarget); const path = String(form.get('path') || '').trim(); if (!path) return; let defaultValue = String(form.get('defaultValue') || ''); const valueType = String(form.get('valueType') || 'string');
    if (['array', 'object'].includes(valueType)) try { defaultValue = JSON.parse(defaultValue || (valueType === 'array' ? '[]' : '{}')); } catch { toast('Default value must be valid JSON.', true); return; }
    if (valueType === 'number') defaultValue = Number(defaultValue || 0); if (valueType === 'boolean') defaultValue = defaultValue === 'true';
    DATA.fieldDefinitions.push({ id: uid(`field_${category.storageKey}`), name: path, category: category.storageKey, path, label: String(form.get('label') || path), group: String(form.get('group') || 'Custom'), valueType, required: false, options: [], referenceCategory: String(form.get('referenceCategory') || ''), defaultValue, min: form.get('min') === '' ? null : Number(form.get('min')), max: form.get('max') === '' ? null : Number(form.get('max')), step: valueType === 'number' ? 1 : null, persistence: 'definition', scope: 'definition', mergeRule: ['array', 'object'].includes(valueType) ? 'preserve-unknown-deep-merge' : 'replace', sourceSystem: 'emberwake' });
    for (const row of DATA[category.storageKey] || []) if (valueAtPath(row, path) === undefined) setValueAtPath(row, path, deepClone(defaultValue)); saveGame(false); renderSchemaStudio();
  });
  el.devContent.querySelector('[data-open-category]')?.addEventListener('click', () => { runtime.activeDevTab = workbenchForCategory(category.storageKey); runtime.devStudioCategory = category.storageKey; renderDevTabs(); renderDevContent(); });
}

function authoringFieldInput(category, rowIndex, field, row) {
  const value = valueAtPath(row, field.path); const encoded = ['array', 'object'].includes(field.valueType) ? JSON.stringify(value ?? field.defaultValue ?? (field.valueType === 'array' ? [] : {}), null, 2) : value ?? field.defaultValue ?? '';
  const common = `data-author-category="${category}" data-author-index="${rowIndex}" data-author-path="${field.path}" data-author-type="${field.valueType}"`;
  if (field.valueType === 'boolean') return `<select ${common}><option value="true" ${Boolean(value) ? 'selected' : ''}>true</option><option value="false" ${!value ? 'selected' : ''}>false</option></select>`;
  if (field.valueType === 'enum') return `<select ${common}>${(field.options || []).map(option => `<option value="${escapeHtml(option)}" ${value === option ? 'selected' : ''}>${escapeHtml(option)}</option>`).join('')}</select>`;
  if (field.valueType === 'ref' || field.valueType === 'reference') { const options = DATA[field.referenceCategory] || []; return `<select ${common}><option value="">None</option>${options.map(option => `<option value="${escapeHtml(option.id)}" ${value === option.id ? 'selected' : ''}>${escapeHtml(recordDisplayName(option))} · ${escapeHtml(option.id)}</option>`).join('')}</select>`; }
  if (['array', 'object', 'text'].includes(field.valueType)) return `<textarea rows="${field.valueType === 'text' ? 3 : 5}" ${common}>${escapeHtml(encoded)}</textarea>`;
  return `<input type="${field.valueType === 'number' ? 'number' : field.valueType === 'color' ? 'color' : 'text'}" ${field.valueType === 'number' ? `step="${field.step || 'any'}" ${field.min != null ? `min="${field.min}"` : ''} ${field.max != null ? `max="${field.max}"` : ''}` : ''} value="${escapeHtml(encoded)}" ${common}>`;
}

function relationshipPanelHtml(category, row) {
  const links = DATA.relationships.filter(link => (link.sourceCategory === category && link.sourceId === row.id) || (link.targetCategory === category && link.targetId === row.id));
  return `<section class="relation-panel"><header><b>RELATIONSHIPS</b><span>${links.length} links</span></header><div class="relation-list">${links.map(link => `<div><code>${escapeHtml(link.sourceCategory)}.${escapeHtml(link.sourceId)}</code><b>${escapeHtml(link.relationshipType)}</b><code>${escapeHtml(link.targetCategory)}.${escapeHtml(link.targetId)}</code><button data-remove-author-link="${link.id}">×</button></div>`).join('') || '<div class="target-empty">No links yet.</div>'}</div><div class="relation-add"><select id="authorRelType"><option>contains</option><option>defines</option><option>given-by</option><option>sells</option><option>buys</option><option>drops</option><option>spawns</option><option>requires</option><option>unlocks</option><option>equips</option><option>learns</option><option>assigned-to</option><option>uses</option><option>custom</option></select><select id="authorRelTargetCategory">${DATA.authoringCategories.map(candidate => `<option value="${candidate.storageKey}">${escapeHtml(candidate.name)}</option>`).join('')}</select><select id="authorRelTargetId"></select><button id="authorAddRelation">ADD LINK</button></div></section>`;
}

function membershipPanelHtml(category, row) {
  if (category === 'npcs') {
    const owned = new Set((row.inventory || []).map(item => typeof item === 'string' ? item : item.id)); const have = DATA.items.filter(item => owned.has(item.id)); const missing = DATA.items.filter(item => !owned.has(item.id));
    return `<section class="membership-panel"><header><b>NPC INVENTORY OWNERSHIP</b><span>Every item is shown. Move it between the two sides.</span></header><div><article><h4>HAS ${have.length}</h4>${have.map(item => `<button data-membership="remove" data-member-id="${item.id}">${escapeHtml(item.name)} <b>REMOVE</b></button>`).join('') || '<em>Empty</em>'}</article><article><h4>DOES NOT HAVE ${missing.length}</h4>${missing.map(item => `<button data-membership="add" data-member-id="${item.id}">${escapeHtml(item.name)} <b>ADD</b></button>`).join('')}</article></div></section>`;
  }
  if (category === 'shops') {
    const stock = row.stock && !Array.isArray(row.stock) ? row.stock : {}; const sells = new Set([...(row.sells || []), ...Object.keys(stock)]); const have = DATA.items.filter(item => sells.has(item.id)); const missing = DATA.items.filter(item => !sells.has(item.id));
    return `<section class="membership-panel shop-membership"><header><b>SHOP STOCK & PERMISSIONS</b><span>Quantity 999 means effectively full; buy and sell lists remain separately editable.</span></header><div><article><h4>STOCKS ${have.length}</h4>${have.map(item => `<div><button data-membership="remove" data-member-id="${item.id}">${escapeHtml(item.name)} <b>REMOVE</b></button><input type="number" min="0" max="999" value="${stock[item.id] ?? 999}" data-stock-qty="${item.id}" title="Stock quantity"></div>`).join('') || '<em>Empty</em>'}</article><article><h4>DOES NOT STOCK ${missing.length}</h4>${missing.map(item => `<button data-membership="add" data-member-id="${item.id}">${escapeHtml(item.name)} <b>ADD</b></button>`).join('')}</article></div></section>`;
  }
  if (category === 'spells') {
    const access = new Set(row.vocations || []); return `<section class="membership-panel"><header><b>VOCATION ACCESS</b><span>Click to allow or remove this spell.</span></header><div><article><h4>CAN USE</h4>${DATA.vocations.filter(vocation => access.has(vocation.id)).map(vocation => `<button data-membership="remove" data-member-id="${vocation.id}">${escapeHtml(vocation.name)} <b>REMOVE</b></button>`).join('') || '<em>None</em>'}</article><article><h4>CANNOT USE</h4>${DATA.vocations.filter(vocation => !access.has(vocation.id)).map(vocation => `<button data-membership="add" data-member-id="${vocation.id}">${escapeHtml(vocation.name)} <b>ADD</b></button>`).join('')}</article></div></section>`;
  }
  if (category === 'guilds') {
    const members = new Set(row.memberCharacterIds || []); const have = runtime.save.characters.filter(character => members.has(character.id)); const missing = runtime.save.characters.filter(character => !members.has(character.id));
    return `<section class="membership-panel"><header><b>HUMAN CHARACTER MEMBERSHIP</b><span>Assign playable characters by stable save ID.</span></header><div><article><h4>GUILD MEMBERS ${have.length}</h4>${have.map(character => `<button data-membership="remove" data-member-id="${character.id}">${escapeHtml(character.name)} · LV ${character.level} <b>REMOVE</b></button>`).join('') || '<em>No members</em>'}</article><article><h4>AVAILABLE CHARACTERS ${missing.length}</h4>${missing.map(character => `<button data-membership="add" data-member-id="${character.id}">${escapeHtml(character.name)} · ${escapeHtml(character.vocationId)} <b>ASSIGN</b></button>`).join('') || '<em>Everyone assigned</em>'}</article></div></section>`;
  }
  if (category === 'pantheons') {
    const members = new Set(row.godIds || []); const have = DATA.gods.filter(god => members.has(god.id)); const missing = DATA.gods.filter(god => !members.has(god.id));
    return `<section class="membership-panel"><header><b>PANTHEON MEMBERSHIP</b><span>Assign existing god definitions to this pantheon.</span></header><div><article><h4>MEMBER GODS ${have.length}</h4>${have.map(god => `<button data-membership="remove" data-member-id="${god.id}">${escapeHtml(god.name)} <b>REMOVE</b></button>`).join('') || '<em>No gods</em>'}</article><article><h4>AVAILABLE GODS ${missing.length}</h4>${missing.map(god => `<button data-membership="add" data-member-id="${god.id}">${escapeHtml(god.name)} <b>ASSIGN</b></button>`).join('') || '<em>All assigned</em>'}</article></div></section>`;
  }
  if (category === 'leaderboardDefinitions') {
    const ranked=runtime.save.characters.map(character=>({...character,gearScore:totalGearScore(character),socialStats:character.socialStats||{},tags:character.tags||[]})).filter(character=>!row.tagFilter||(character.tags||[]).includes(row.tagFilter)).sort((a,b)=>{const av=Number(valueAtPath(a,row.valuePath)||0),bv=Number(valueAtPath(b,row.valuePath)||0);return row.direction==='ascending'?av-bv:bv-av;});
    return `<section class="membership-panel leaderboard-preview"><header><b>LIVE SORTED LEADERBOARD</b><span>${ranked.length} characters · value ${escapeHtml(row.valuePath)} · tag ${escapeHtml(row.tagFilter||'all')}</span></header><div><article><h4>RANKINGS</h4>${ranked.map((character,index)=>`<div><b>#${index+1}</b><span>${escapeHtml(character.name)}<small>${escapeHtml((character.tags||[]).join(', '))}</small></span><strong>${number(row.valuePath==='gearScore'?character.gearScore:valueAtPath(character,row.valuePath))}</strong></div>`).join('')||'<em>No character matches this tag.</em>'}</article><article><h4>AVAILABLE TAGS</h4>${[...new Set(runtime.save.characters.flatMap(character=>character.tags||[]))].map(tag=>`<div><span>${escapeHtml(tag)}</span><strong>${runtime.save.characters.filter(character=>(character.tags||[]).includes(tag)).length}</strong></div>`).join('')}</article></div></section>`;
  }
  return '';
}

function renderAuthoringStudio(studioKey) {
  const studio = AUTHORING_WORKBENCHES[studioKey]; if (!studio) return;
  const customCategory = runtime.devStudioCategory && categoryDefinition(runtime.devStudioCategory) && !Object.values(AUTHORING_WORKBENCHES).some(workbench => workbench.categories.includes(runtime.devStudioCategory)) ? runtime.devStudioCategory : '';
  const studioCategories = customCategory ? [customCategory, ...studio.categories] : studio.categories;
  runtime.devStudioCategory = studioCategories.includes(runtime.devStudioCategory) ? runtime.devStudioCategory : studioCategories[0];
  const category = runtime.devStudioCategory; const rows = DATA[category] || []; const search = runtime.devSearch.toLowerCase(); const filtered = rows.map((row, index) => ({ row, index })).filter(({ row }) => !search || JSON.stringify(row).toLowerCase().includes(search));
  runtime.devStudioSelection = runtime.devStudioSelection || {}; let selectedIndex = runtime.devStudioSelection[category] ?? filtered[0]?.index ?? 0; if (!rows[selectedIndex]) selectedIndex = filtered[0]?.index ?? 0; runtime.devStudioSelection[category] = selectedIndex; const row = rows[selectedIndex];
  el.devSummary.textContent = `${studio.label} · ${rows.length} ${category} records · ${row ? authoringFieldsFor(category, row).length : 0} editable fields`;
  const categoryTabs = studioCategories.map(key => `<button data-studio-category="${key}" class="${key === category ? 'active' : ''}">${escapeHtml(categoryDefinition(key)?.name || key)}<b>${DATA[key]?.length || 0}</b></button>`).join('');
  if (!row) {
    el.devContent.innerHTML = `<div class="author-studio"><header class="studio-category-tabs">${categoryTabs}</header><div class="empty-author"><i>${studio.icon}</i><h2>${escapeHtml(studio.label)}</h2><p>This registry has no records yet. Create the first fully data-driven entry.</p><button id="studioNewRecord">CREATE FIRST RECORD</button></div></div>`; bindAuthorStudioNavigation(studioKey, category, rows, null, -1); return;
  }
  const fields = authoringFieldsFor(category, row); const groups = [...new Set(fields.map(field => field.group || 'General'))];
  el.devContent.innerHTML = `<div class="author-studio"><header class="studio-category-tabs">${categoryTabs}</header><div class="studio-columns"><aside class="studio-list"><header><span>${escapeHtml(studio.label).toUpperCase()}</span><h2>${escapeHtml(categoryDefinition(category)?.name || category)}</h2><div><button id="studioNewRecord">＋ NEW</button><button id="studioDuplicateRecord">DUPLICATE</button></div></header><div>${filtered.map(({ row: candidate, index }) => `<button data-studio-record="${index}" class="${index === selectedIndex ? 'active' : ''}"><b>${escapeHtml(recordDisplayName(candidate, index))}</b><small>${escapeHtml(candidate.id || `row_${index + 1}`)} · ${escapeHtml(candidate.sourceSystem || 'emberwake')}</small></button>`).join('')}</div></aside>
    <main class="studio-inspector"><header class="studio-title"><div><span>${escapeHtml(categoryDefinition(category)?.entityType || 'definition').toUpperCase()} DEFINITION</span><h2>${escapeHtml(recordDisplayName(row, selectedIndex))}</h2><p>${escapeHtml(row.id || '')} · ${escapeHtml(row.sourceSystem || 'emberwake')} · unknown fields preserved</p></div><div><button id="studioDuplicateRecord">DUPLICATE</button><button id="studioDeleteRecord" class="danger">DELETE</button></div></header>
    <div class="field-groups">${groups.map(group => `<section><header><b>${escapeHtml(group)}</b><span>${fields.filter(field => field.group === group).length} controls</span></header><div>${fields.filter(field => field.group === group).map(field => `<label class="field-${field.valueType}"><span>${escapeHtml(field.label || field.path)}${field.required ? '<b>*</b>' : ''}</span>${authoringFieldInput(category, selectedIndex, field, row)}<small>${escapeHtml(field.path)} · ${escapeHtml(field.valueType)}${field.referenceCategory ? ` → ${escapeHtml(field.referenceCategory)}` : ''}</small></label>`).join('')}</div></section>`).join('')}</div>
    ${membershipPanelHtml(category, row)}${relationshipPanelHtml(category, row)}
    <section class="raw-record"><header><b>COMPLETE RECORD JSON</b><span>Includes every known and unknown source field.</span><button id="applyRawRecord">APPLY JSON</button></header><textarea id="rawRecordJson" rows="16">${escapeHtml(JSON.stringify(row, null, 2))}</textarea></section></main></div></div>`;
  bindAuthorStudioNavigation(studioKey, category, rows, row, selectedIndex);
}

function bindAuthorStudioNavigation(studioKey, category, rows, row, selectedIndex) {
  el.devContent.querySelectorAll('[data-studio-category]').forEach(button => button.addEventListener('click', () => { runtime.devStudioCategory = button.dataset.studioCategory; renderAuthoringStudio(studioKey); }));
  el.devContent.querySelectorAll('[data-studio-record]').forEach(button => button.addEventListener('click', () => { runtime.devStudioSelection[category] = Number(button.dataset.studioRecord); renderAuthoringStudio(studioKey); }));
  const createRecord = () => { const definition = categoryDefinition(category); const schema = DATA.fieldDefinitions.filter(field => field.category === category); const next = { id: uid((definition?.entityType || 'record').replace(/[^a-z0-9]/gi, '_')), name: `New ${definition?.entityType || 'Record'}` }; for (const field of schema) if (next[field.path] === undefined) setValueAtPath(next, field.path, deepClone(field.defaultValue)); Object.assign(next, { iconDirectory: `/assets/icons/${category}/${next.id}.png`, modelDirectory: `/assets/models/${category}/${next.id}.glb`, description: 'New data-driven definition.', tooltip: 'New editable definition.', sourceSystem: 'emberwake' }); rows.push(next); runtime.devStudioSelection[category] = rows.length - 1; saveGame(false); renderDevTabs(); renderAuthoringStudio(studioKey); };
  el.devContent.querySelectorAll('#studioNewRecord').forEach(button => button.addEventListener('click', createRecord));
  el.devContent.querySelectorAll('#studioDuplicateRecord').forEach(button => button.addEventListener('click', () => { if (!row) return; const copy = deepClone(row); copy.id = uid((row.id || 'record').replace(/[^a-z0-9]/gi, '_')); copy.name = `${recordDisplayName(row)} Copy`; rows.push(copy); runtime.devStudioSelection[category] = rows.length - 1; saveGame(false); renderDevTabs(); renderAuthoringStudio(studioKey); }));
  document.getElementById('studioDeleteRecord')?.addEventListener('click', () => { if (!row || !confirm(`Delete ${recordDisplayName(row)}?`)) return; rows.splice(selectedIndex, 1); runtime.devStudioSelection[category] = Math.max(0, selectedIndex - 1); saveGame(false); renderDevTabs(); renderAuthoringStudio(studioKey); });
  el.devContent.querySelectorAll('[data-author-path]').forEach(input => input.addEventListener('change', () => { const target = DATA[input.dataset.authorCategory]?.[Number(input.dataset.authorIndex)]; if (!target) return; let value = input.value; try { if (input.dataset.authorType === 'number') value = Number(value); else if (input.dataset.authorType === 'boolean') value = value === 'true'; else if (['array', 'object'].includes(input.dataset.authorType)) value = JSON.parse(value); setValueAtPath(target, input.dataset.authorPath, value); target.updatedBy = runtime.server.user?.username || runtime.server.identity || 'local_author'; target.updatedAt = nowIso(); input.classList.add('saved'); saveGame(false); } catch { input.classList.add('invalid'); toast('That field needs valid JSON.', true); } }));
  if (!row) return;
  const membershipKey = category === 'spells' ? 'vocations' : category === 'guilds' ? 'memberCharacterIds' : category === 'pantheons' ? 'godIds' : 'inventory';
  el.devContent.querySelectorAll('[data-membership]').forEach(button => button.addEventListener('click', () => {
    const id = button.dataset.memberId; const adding = button.dataset.membership === 'add';
    if (category === 'shops') { row.sells = [...new Set(row.sells || [])]; row.stock = row.stock && !Array.isArray(row.stock) ? row.stock : {}; if (adding) { if (!row.sells.includes(id)) row.sells.push(id); row.stock[id] = row.stock[id] ?? 999; } else { row.sells = row.sells.filter(itemId => itemId !== id); delete row.stock[id]; } }
    else { row[membershipKey] = (row[membershipKey] || []).map(value => typeof value === 'string' ? value : value.id); if (adding && !row[membershipKey].includes(id)) row[membershipKey].push(id); if (!adding) row[membershipKey] = row[membershipKey].filter(itemId => itemId !== id); }
    saveGame(false); renderAuthoringStudio(studioKey);
  }));
  el.devContent.querySelectorAll('[data-stock-qty]').forEach(input => input.addEventListener('change', () => { row.stock = row.stock && !Array.isArray(row.stock) ? row.stock : {}; row.stock[input.dataset.stockQty] = clamp(Number(input.value), 0, 999); saveGame(false); }));
  const targetCategory = document.getElementById('authorRelTargetCategory'); const fillTargets = () => { const select = document.getElementById('authorRelTargetId'); if (select) select.innerHTML = (DATA[targetCategory?.value] || []).map(target => `<option value="${escapeHtml(target.id)}">${escapeHtml(recordDisplayName(target))} · ${escapeHtml(target.id)}</option>`).join(''); }; targetCategory?.addEventListener('change', fillTargets); fillTargets();
  document.getElementById('authorAddRelation')?.addEventListener('click', () => { const targetId = document.getElementById('authorRelTargetId')?.value; if (!targetId) return; const relation = document.getElementById('authorRelType')?.value || 'references'; DATA.relationships.push({ id: uid('relationship'), name: relation, sourceCategory: category, sourceId: row.id, targetCategory: targetCategory.value, targetId, relationshipType: relation, cardinality: 'many-to-many', cascade: 'restrict', sourceSystem: 'emberwake' }); saveGame(false); renderAuthoringStudio(studioKey); });
  el.devContent.querySelectorAll('[data-remove-author-link]').forEach(button => button.addEventListener('click', () => { const index = DATA.relationships.findIndex(link => link.id === button.dataset.removeAuthorLink); if (index >= 0) DATA.relationships.splice(index, 1); saveGame(false); renderAuthoringStudio(studioKey); }));
  document.getElementById('applyRawRecord')?.addEventListener('click', () => { try { const parsed = JSON.parse(document.getElementById('rawRecordJson').value); if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error(); rows[selectedIndex] = parsed; normalizeEditableCatalog(); saveGame(false); renderAuthoringStudio(studioKey); } catch { toast('Complete record JSON is invalid.', true); } });
}

function renderIntegrationVault() {
  const systems = DATA.integrationSystems.map(system => ({ ...system, registries: DATA.authoringCategories.filter(category => category.sourceSystem === system.id), counts: DATA.sourceRegistryCounts.filter(row => row.sourceSystem === system.id) }));
  el.devSummary.textContent = `${systems.length} systems · ${DATA.sourceRegistryCounts.length} verified source counts · ${DATA.schemaFields.length + DATA.fieldDefinitions.length} tracked fields`;
  el.devContent.innerHTML = `<div class="integration-vault"><header><span>CROSS-APPLICATION SOURCE OF TRUTH</span><h2>Integration Data Vault</h2><p>Definitions stay separate from runtime instances. Stable string IDs are persisted; live pointers, meshes, targets, squads and attachments are re-resolved after loading.</p></header><section>${systems.map(system => `<article><header><div><span>${escapeHtml(system.status)}</span><h3>${escapeHtml(system.name)}</h3></div><b>schema ${system.schemaVersion} · content ${system.contentVersion}</b></header><p>${escapeHtml(system.authority)}</p><dl><dt>Authority</dt><dd>${escapeHtml(system.ownership)}</dd><dt>Conflict rule</dt><dd>${escapeHtml(system.conflictPolicy)}</dd><dt>Table prefix</dt><dd><code>${escapeHtml(system.tablePrefix)}</code></dd></dl><div class="vault-counts">${system.counts.map(row => `<button data-vault-category="${escapeHtml(row.registry)}" title="${escapeHtml(row.notes)}"><b>${row.loadedCount}</b><span>${escapeHtml(row.registry)}</span><small>${escapeHtml(row.status)}</small></button>`).join('') || '<em>No reported fixed counts.</em>'}</div><div class="vault-registries">${system.registries.map(category => `<button data-open-vault-registry="${category.storageKey}">${escapeHtml(category.name)} <b>${DATA[category.storageKey]?.length || 0}</b></button>`).join('')}</div></article>`).join('')}</section><footer><b>Compatibility rules active</b><span>Unknown fields preserved · aliases migrated · optimistic revisions · integration namespaces isolated · Unix-ms cooldowns · ISO audit dates · no DOM/functions/Maps/Sets in persistence.</span></footer></div>`;
  el.devContent.querySelectorAll('[data-open-vault-registry]').forEach(button => button.addEventListener('click', () => { runtime.devStudioCategory = button.dataset.openVaultRegistry; runtime.activeDevTab = workbenchForCategory(runtime.devStudioCategory); renderDevTabs(); renderDevContent(); }));
}

function renderRuntimeInspector() {
  const char = runtime.character; const liveCounts = { monsters: runtime.monsters?.filter(row => row.alive).length || 0, npcActors: runtime.npcs?.length || DATA.npcs.length, groundItems: runtime.groundItems?.length || 0, fields: runtime.fields?.length || 0, projectiles: runtime.projectiles?.length || 0 };
  el.devSummary.textContent = `${Object.values(liveCounts).reduce((sum, count) => sum + count, 0)} live instances · ${DATA.runtimeVariables.length} registered variables · transient pointers excluded from saves`;
  el.devContent.innerHTML = `<div class="runtime-inspector"><header><div><span>LIVE INSTANCE CONTROL</span><h2>${escapeHtml(char?.name || 'No active character')}</h2><p>Changes here affect this running simulation. Definition edits remain in their authoring registries.</p></div><div class="runtime-badge">SIMULATION PAUSED WHILE DEV MODE IS OPEN</div></header><section class="runtime-counts">${Object.entries(liveCounts).map(([key, count]) => `<article><b>${count}</b><span>${escapeHtml(key)}</span></article>`).join('')}</section>${char ? `<section class="runtime-controls"><article><header><b>CHARACTER INSTANCE</b><code>${escapeHtml(char.id)}</code></header><div>${[['level', char.level], ['experience', char.experience], ['hp', char.hp], ['maxHp', char.maxHp], ['mana', char.mana], ['maxMana', char.maxMana], ['gold', char.gold], ['x', char.x], ['y', char.y], ['z', char.z]].map(([field, value]) => `<label>${field}<input type="number" step="any" data-live-char-field="${field}" value="${value ?? 0}"></label>`).join('')}</div><footer><button data-live-action="heal">FULL HEAL</button><button data-live-action="mana">FULL MANA</button><button data-live-action="gold">+1,000 GOLD</button><button data-live-action="clearAggro">CLEAR AGGRO</button></footer></article><article><header><b>SPAWN & TELEPORT</b><span>Uses live runtime constructors.</span></header><label>Creature<select id="liveSpawnMonster">${DATA.monsters.map(monster => `<option value="${monster.id}">${escapeHtml(monster.name)} · LV ${monster.level}</option>`).join('')}</select></label><label>Count<input id="liveSpawnCount" type="number" min="1" max="30" value="1"></label><button id="liveSpawnButton">SPAWN BESIDE CHARACTER</button><label>Destination X<input id="liveTeleportX" type="number" value="${char.x}"></label><label>Destination Y<input id="liveTeleportY" type="number" value="${char.y}"></label><label>Floor Z<input id="liveTeleportZ" type="number" min="-8" max="0" value="${char.z}"></label><button id="liveTeleportButton">TELEPORT</button></article></section>` : ''}<section class="runtime-variable-table"><header><b>CANONICAL RUNTIME VARIABLE REGISTRY</b><span>These paths are available to conditions, mutations, sequences and integrations.</span></header>${DATA.runtimeVariables.map(variable => `<div><code>${escapeHtml(variable.path)}</code><span>${escapeHtml(variable.valueType)}</span><span>${escapeHtml(variable.scope)}</span><b>${variable.persistent ? 'SNAPSHOT' : 'TRANSIENT'}</b><em>${escapeHtml(variable.authority)}</em></div>`).join('')}</section><section class="runtime-live-json"><header><b>READ-ONLY INSTANCE SNAPSHOT</b><span>Meshes and circular runtime pointers are intentionally omitted.</span></header><pre>${escapeHtml(JSON.stringify(char ? { id: char.id, vocationId: char.vocationId, level: char.level, x: char.x, y: char.y, z: char.z, hp: char.hp, maxHp: char.maxHp, mana: char.mana, maxMana: char.maxMana, gold: char.gold, survival: char.survival, skills: char.skills, equipment: char.equipment, inventory: char.inventory, statuses: char.statuses } : {}, null, 2))}</pre></section></div>`;
  el.devContent.querySelectorAll('[data-live-char-field]').forEach(input => input.addEventListener('change', () => { if (!char) return; char[input.dataset.liveCharField] = Number(input.value); saveGame(false); renderRuntimeInspector(); }));
  el.devContent.querySelectorAll('[data-live-action]').forEach(button => button.addEventListener('click', () => { if (!char) return; if (button.dataset.liveAction === 'heal') char.hp = char.maxHp; if (button.dataset.liveAction === 'mana') char.mana = char.maxMana; if (button.dataset.liveAction === 'gold') char.gold += 1000; if (button.dataset.liveAction === 'clearAggro') for (const monster of runtime.monsters) monster.aggroTarget = null; saveGame(false); renderRuntimeInspector(); }));
  document.getElementById('liveSpawnButton')?.addEventListener('click', () => { const monsterId = document.getElementById('liveSpawnMonster').value; const count = clamp(Number(document.getElementById('liveSpawnCount').value), 1, 30); for (let index = 0; index < count; index++) spawnMonster(monsterId, char.x + 2 + index % 3, char.y + Math.floor(index / 3), char.z, { homeX: char.x + 2, homeY: char.y }); renderRuntimeInspector(); });
  document.getElementById('liveTeleportButton')?.addEventListener('click', () => { char.x = clamp(Number(document.getElementById('liveTeleportX').value), 0, WORLD_W - 1); char.y = clamp(Number(document.getElementById('liveTeleportY').value), 0, WORLD_H - 1); char.z = clamp(Number(document.getElementById('liveTeleportZ').value), -8, 0); char.path = []; saveGame(false); renderRuntimeInspector(); });
}

function relationshipBuilderHtml() {
  const categories = DEV_SECTIONS.map(([id, name]) => ({ id, name })).filter(row => Array.isArray(devRows(row.id)) && !['relationships', 'integrationOverview', 'levelEditor', 'dropTables'].includes(row.id));
  const options = categories.map(row => `<option value="${row.id}">${escapeHtml(row.name)}</option>`).join('');
  return `<section class="relationship-builder"><header><div><span>MODULAR LINK AUTHOR</span><h2>Relationship Builder</h2></div><p>Choose existing records from dropdowns or type a new stable ID in the table after creation.</p></header><div><label>SOURCE CATEGORY<select id="relSourceCategory">${options}</select></label><label>SOURCE ENTRY<select id="relSourceId"></select></label><label>RELATION<select id="relType"><option>contains</option><option>defines</option><option>given-by</option><option>sells</option><option>buys</option><option>drops</option><option>spawns</option><option>requires</option><option>unlocks</option><option>equips</option><option>learns</option><option>assigned-to</option><option>custom</option></select></label><label>TARGET CATEGORY<select id="relTargetCategory">${options}</select></label><label>TARGET ENTRY<select id="relTargetId"></select></label><label>CARDINALITY<select id="relCardinality"><option>many-to-one</option><option>one-to-many</option><option>many-to-many</option><option>one-to-one</option></select></label><button id="addRelationship">ADD LINK</button></div></section>`;
}

function bindRelationshipBuilder() {
  const sourceCategory = document.getElementById('relSourceCategory'); const targetCategory = document.getElementById('relTargetCategory');
  const fill = (categorySelect, entryId) => {
    const select = document.getElementById(entryId); const rows = devRows(categorySelect.value); select.innerHTML = rows.map(row => `<option value="${escapeHtml(row.id)}">${escapeHtml(row.name || row.label || row.id)}</option>`).join('');
  };
  sourceCategory.value = sourceCategory.querySelector('option[value="characters"]') ? 'characters' : sourceCategory.value;
  targetCategory.value = targetCategory.querySelector('option[value="vocations"]') ? 'vocations' : targetCategory.value;
  fill(sourceCategory, 'relSourceId'); fill(targetCategory, 'relTargetId');
  sourceCategory.addEventListener('change', () => fill(sourceCategory, 'relSourceId')); targetCategory.addEventListener('change', () => fill(targetCategory, 'relTargetId'));
  document.getElementById('addRelationship')?.addEventListener('click', () => {
    const sourceId = document.getElementById('relSourceId').value; const targetId = document.getElementById('relTargetId').value; if (!sourceId || !targetId) return;
    DATA.relationships.push({ id: uid('relationship'), name: document.getElementById('relType').value, sourceCategory: sourceCategory.value, sourceId, targetCategory: targetCategory.value, targetId, relationshipType: document.getElementById('relType').value, cardinality: document.getElementById('relCardinality').value, cascade: 'restrict', sourceSystem: 'emberwake', iconDirectory: '/assets/icons/relationships/', modelDirectory: '/assets/models/relationships/', description: 'Authored cross-registry relationship.', tooltip: 'Editable stable-ID relationship.' });
    saveGame(false); renderDevTabs(); renderDevContent();
  });
}

async function emberwakeServerApi(action, {method='GET',body=null}={}) {
  const sessionId=getServerSessionId(), query=`action=${encodeURIComponent(action)}&projectId=${encodeURIComponent(PROJECT_ID)}&serverSessionId=${encodeURIComponent(sessionId)}`;
  const response=await fetch(`./app.php?${query}`,{method,headers:{Accept:'application/json','Content-Type':'application/json','X-FSG-Server-Session':sessionId},...(body?{body:JSON.stringify({...body,projectId:PROJECT_ID,serverSessionId:sessionId})}:{})}); const result=await response.json(); if(!response.ok||result.status==='error') throw new Error(result.message||'Server request failed.'); return result;
}

async function renderAdminPanel() {
  el.devSummary.textContent=`${runtime.server.authenticated?'SIGNED IN':'NOT SIGNED IN'} · ${runtime.server.role||'player'} · session ${getServerSessionId()}`;
  const hierarchy=runtime.adminHierarchy, select=(id,rows,value)=>`<select id="${id}">${rows.map(row=>`<option value="${row.id}" ${row.id===value?'selected':''}>${escapeHtml(row.name||row.id)}</option>`).join('')}</select>`;
  const hierarchyHtml=`<section class="admin-hierarchy"><header><b>SAVE DATA READ CHAIN</b><span>God → Realm → World → Village → Villager Class</span></header><div><label>GOD${select('adminGodFilter',DATA.gods,hierarchy.godId)}</label><label>REALM${select('adminRealmFilter',DATA.realms.filter(row=>!row.godId||row.godId===hierarchy.godId),hierarchy.realmId)}</label><label>WORLD${select('adminWorldFilter',DATA.worlds.filter(row=>{const realm=byId(DATA.realms,hierarchy.realmId);return !realm?.worldIds?.length||realm.worldIds.includes(row.id)}),hierarchy.worldId)}</label><label>VILLAGE${select('adminVillageFilter',DATA.villages.filter(row=>!row.worldId||row.worldId===hierarchy.worldId),hierarchy.villageId)}</label><label>VILLAGER CLASS${select('adminClassFilter',DATA.villagerClasses,hierarchy.villagerClassId)}</label><label>TAG FILTER<input id="adminTagFilter" value="${escapeHtml(hierarchy.tagFilter)}" placeholder="rank or title tag"></label></div></section>`;
  el.devContent.innerHTML=`<div class="admin-workbench"><header><div><span>EMBERWAKE SERVER CONTROL</span><h2>Accounts, Sessions & Permissions</h2><p>Suite login is shared automatically. Server sessions remain isolated until their immutable original admin approves access.</p></div><button id="adminRefresh">REFRESH</button></header><section class="session-loader"><label>MANUAL SERVER SESSION ID<input id="adminSessionInput" value="${escapeHtml(getServerSessionId())}"></label><button id="adminLoadSession">LOAD / REQUEST SESSION</button><button id="adminNewSession">CREATE NEW SESSION</button><code>adminID ${runtime.server.adminID||'unassigned'} · role ${escapeHtml(runtime.server.role||'player')} · ${escapeHtml(runtime.server.access||'local')}</code></section>${hierarchyHtml}<div id="adminServerContent"><div class="target-empty">Loading account-scoped server data…</div></div></div>`;
  const updateHierarchy=()=>{ hierarchy.godId=document.getElementById('adminGodFilter')?.value||hierarchy.godId; hierarchy.realmId=document.getElementById('adminRealmFilter')?.value||hierarchy.realmId; hierarchy.worldId=document.getElementById('adminWorldFilter')?.value||hierarchy.worldId; hierarchy.villageId=document.getElementById('adminVillageFilter')?.value||hierarchy.villageId; hierarchy.villagerClassId=document.getElementById('adminClassFilter')?.value||hierarchy.villagerClassId; hierarchy.tagFilter=document.getElementById('adminTagFilter')?.value||''; Object.assign(runtime.save.world.sharedContext,{godId:hierarchy.godId,realmId:hierarchy.realmId,worldId:hierarchy.worldId,villageId:hierarchy.villageId,villagerClassId:hierarchy.villagerClassId}); saveGame(false); renderAdminPanel(); };
  ['adminGodFilter','adminRealmFilter','adminWorldFilter','adminVillageFilter','adminClassFilter'].forEach(id=>document.getElementById(id)?.addEventListener('change',updateHierarchy)); document.getElementById('adminTagFilter')?.addEventListener('input',event=>{hierarchy.tagFilter=event.target.value; renderAdminServerContent(runtime.adminPanelData);});
  document.getElementById('adminRefresh')?.addEventListener('click',renderAdminPanel);
  document.getElementById('adminLoadSession')?.addEventListener('click',async()=>{const value=document.getElementById('adminSessionInput').value;if(!setServerSessionId(value)){toast('Enter a valid session ID.',true);return;} runtime.server.sessionConfirmed=true; await loadServerSession(); renderAdminPanel();});
  document.getElementById('adminNewSession')?.addEventListener('click',async()=>{setServerSessionId(createLocalServerSessionId());runtime.server.sessionConfirmed=true;await loadServerSession();renderAdminPanel();});
  if(location.protocol==='file:'){document.getElementById('adminServerContent').innerHTML='<div class="info-card"><h3>PHP server required</h3><p>Open this game through the PHP host to use shared login, server sessions, and account permissions. Local authoring remains available for development.</p></div>';return;}
  try { const sessions=await emberwakeServerApi('listServerSessions'); let data={sessions:sessions.sessions||[]}; if(runtime.server.capabilities.canModerate) data={...data,...await emberwakeServerApi('adminPanel')}; runtime.adminPanelData=data; renderAdminServerContent(data); } catch(error){document.getElementById('adminServerContent').innerHTML=`<div class="info-card"><h3>Account action required</h3><p>${escapeHtml(error.message)}</p><button id="adminOpenAccount">SIGN IN / REGISTER</button><button id="adminRequestAccess">REQUEST ACCESS TO THIS SESSION</button></div>`;document.getElementById('adminOpenAccount')?.addEventListener('click',openAccount);document.getElementById('adminRequestAccess')?.addEventListener('click',()=>adminMutation('requestSessionAccess',{message:'Requested from Emberwake World Data Workbench'}));}
}

function renderAdminServerContent(data={}) {
  const root=document.getElementById('adminServerContent'); if(!root)return; const tagFilter=runtime.adminHierarchy.tagFilter.toLowerCase();
  const sessions=(data.sessions||[]).map(row=>`<button data-admin-session="${escapeHtml(row.session_id)}"><b>${escapeHtml(row.name||row.session_id)}</b><span>${escapeHtml(row.role||'player')} · ${escapeHtml(row.status||'active')}</span><code>${escapeHtml(row.session_id)}</code></button>`).join('')||'<em>No approved sessions yet.</em>';
  const members=(data.members||[]).filter(row=>!tagFilter||JSON.stringify(row).toLowerCase().includes(tagFilter));
  const allowedRoles=['player',...(runtime.server.capabilities.canManageGuild?['guild_moderator']:[]),...(runtime.server.capabilities.canGrantModerator?['moderator']:[]),...(runtime.server.role==='admin'||runtime.server.role==='server_owner'?['guild_master','game_master']:[])];
  const originalAdmin=runtime.server.adminID===Number(runtime.server.user?.id);
  const memberRows=members.map(row=>{const immutable=['admin','server_owner'].includes(row.role);const roles=[...new Set([...allowedRoles,...((immutable||!allowedRoles.includes(row.role))?[row.role]:[])])];return `<tr><td>${escapeHtml(row.username||`user ${row.user_id}`)}<small>${escapeHtml(row.email||'')}</small></td><td><select data-member-role="${row.user_id}" ${immutable||runtime.server.role==='moderator'?'disabled':''}>${roles.map(role=>`<option ${role===row.role?'selected':''}>${role}</option>`).join('')}</select></td><td>${escapeHtml(row.guild_tags||row.role_tags_json||'[]')}</td><td><span class="account-state ${row.is_active?'active':'inactive'}">${row.is_active?'ACTIVE':'NO ACCESS'}</span>${originalAdmin&&!immutable&&row.is_active?`<button data-review-user="${row.user_id}" data-decision="revoke">REVOKE</button>`:''}</td></tr>`}).join('');
  const requests=(data.requests||[]).filter(row=>row.status==='pending').map(row=>`<article><span>${escapeHtml(row.username||`user ${row.user_id}`)}</span><code>${escapeHtml(row.email||'')}</code>${runtime.server.adminID===Number(runtime.server.user?.id)?`<button data-review-user="${row.user_id}" data-decision="approve">APPROVE</button><button data-review-user="${row.user_id}" data-decision="deny">DENY</button>`:'<em>Original admin review required</em>'}</article>`).join('')||'<div class="target-empty">No pending requests.</div>';
  const guildOptions=DATA.guilds.map(row=>`<option value="${row.id}">${escapeHtml(row.name)}</option>`).join(''), userOptions=members.map(row=>`<option value="${row.user_id}">${escapeHtml(row.username||row.user_id)}</option>`).join('');
  root.innerHTML=`<section class="session-list"><header><b>YOUR SERVER SESSIONS</b></header>${sessions}</section>${runtime.server.capabilities.canModerate?`<section class="permission-table"><header><b>PLAYER ACCOUNTS & ROLES</b><span>Admins are immutable. Game Masters may grant Moderator; Guild Masters may grant Guild Moderator.</span></header><table><thead><tr><th>ACCOUNT</th><th>ROLE</th><th>TAGS</th><th>STATE</th></tr></thead><tbody>${memberRows}</tbody></table></section><section class="access-requests"><header><b>SESSION ACCESS REQUESTS</b></header>${requests}</section>`:''}${runtime.server.capabilities.canManageGuild?`<section class="guild-tag-editor"><header><b>GUILD RANK & TITLE TAGS</b></header><label>GUILD<select id="guildTagGuild">${guildOptions}</select></label><label>MEMBER<select id="guildTagUser">${userOptions}</select></label><label>RANK<input id="guildTagRank" value="member"></label><label>TITLE TAG<input id="guildTitleTag" placeholder="Quartermaster"></label><label><input id="guildModeratorTag" type="checkbox"> GUILD MODERATOR</label><button id="saveGuildTag">SAVE GUILD TAGS</button></section>`:''}`;
  root.querySelectorAll('[data-admin-session]').forEach(button=>button.addEventListener('click',async()=>{setServerSessionId(button.dataset.adminSession);runtime.server.sessionConfirmed=true;await loadServerSession();renderAdminPanel();})); root.querySelectorAll('[data-member-role]').forEach(select=>select.addEventListener('change',()=>adminMutation('setMemberRole',{userId:Number(select.dataset.memberRole),role:select.value}))); root.querySelectorAll('[data-review-user]').forEach(button=>button.addEventListener('click',()=>adminMutation('reviewSessionAccess',{userId:Number(button.dataset.reviewUser),decision:button.dataset.decision}))); document.getElementById('saveGuildTag')?.addEventListener('click',()=>adminMutation('setGuildMemberTag',{guildId:document.getElementById('guildTagGuild').value,userId:Number(document.getElementById('guildTagUser').value),rankId:document.getElementById('guildTagRank').value,titleTag:document.getElementById('guildTitleTag').value,isGuildModerator:document.getElementById('guildModeratorTag').checked}));
}

async function adminMutation(action,body){try{const result=await emberwakeServerApi(action,{method:'POST',body});toast(result.message||'Permissions updated.');await loadServerSession();renderAdminPanel();}catch(error){toast(error.message,true,6000);}}

function renderDevContent() {
  const key = runtime.activeDevTab;
  const locked = developerSectionIsMutable(key) && !canAuthorData();
  el.devContent.classList.toggle('permission-locked', locked);
  el.devOverlay.classList.toggle('authoring-locked', !canAuthorData());
  el.devAddRow.disabled = !canAuthorData();
  if (el.devBackButton) el.devBackButton.hidden = key === 'authoringHome';
  const virtual = key === 'authoringHome' || key === 'adminPanel' || key === 'schemaStudio' || key === 'runtimeInspector' || key === 'integrationVault' || Boolean(AUTHORING_WORKBENCHES[key]);
  el.devAddRow.style.display = virtual || ['dropTables', 'levelEditor', 'projectMeta', 'integrationOverview'].includes(key) ? 'none' : '';
  if (key === 'authoringHome') { renderAuthoringHome(); return; }
  if (key === 'adminPanel') { renderAdminPanel(); return; }
  if (key === 'schemaStudio') { renderSchemaStudio(); return; }
  if (key === 'runtimeInspector') { renderRuntimeInspector(); return; }
  if (key === 'integrationVault') { renderIntegrationVault(); return; }
  if (AUTHORING_WORKBENCHES[key]) { renderAuthoringStudio(key); return; }
  if (key === 'integrationOverview') { renderIntegrationOverview(); return; }
  if (key === 'dropTables') { renderDropController(); return; }
  if (key === 'levelEditor') { renderLevelEditor(); return; }
  const rows = devRows(key); const search = runtime.devSearch.toLowerCase();
  const filtered = rows.map((row, index) => ({ row, index })).filter(({ row }) => !search || JSON.stringify(row).toLowerCase().includes(search));
  const preferred = ['id', 'slot', 'name', 'type', 'role', 'level', 'x', 'y', 'z', 'zoneId', 'giverId', 'monsterId', 'itemId', 'recommendedLevel', 'hp', 'attack', 'defense', 'xp', 'gold', 'iconDirectory', 'modelDirectory', 'description', 'tooltip'];
  const allKeys = [...new Set(filtered.flatMap(({ row }) => Object.keys(row)))];
  const columns = [...preferred.filter(column => allKeys.includes(column)), ...allKeys.filter(column => !preferred.includes(column))];
  el.devSummary.textContent = `${filtered.length} of ${rows.length} rows · ${columns.length} fields · edits save locally`;
  const builder = key === 'relationships' ? relationshipBuilderHtml() : '';
  el.devContent.innerHTML = `${builder}<table class="data-table"><thead><tr><th>ROW</th>${columns.map(column => `<th>${escapeHtml(column)}</th>`).join('')}</tr></thead><tbody>${filtered.map(({ row, index }) => `<tr><td>${index + 1}<br><button class="row-delete" data-delete-row="${index}" title="Delete row">×</button></td>${columns.map(column => `<td>${devCell(key, index, column, row[column], row)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
  if (key === 'relationships') bindRelationshipBuilder();
  el.devContent.querySelectorAll('[data-dev-field]').forEach(input => input.addEventListener('change', () => updateDevField(input)));
  el.devContent.querySelectorAll('[data-delete-row]').forEach(button => button.addEventListener('click', () => {
    const index = Number(button.dataset.deleteRow); const row = rows[index];
    if (!confirm(`Delete ${row?.name || row?.id || `row ${index + 1}`} from ${key}?`)) return;
    rows.splice(index, 1); renderDevTabs(); renderDevContent(); saveGame(false); logConsole(`Deleted ${key} row ${index + 1}.`);
  }));
}

function referenceOptions(section, field, row = {}) {
  let category = null;
  if (field === 'sourceCategory' || field === 'targetCategory' || field === 'category') return DEV_SECTIONS.map(([id, name]) => ({ id, name }));
  if (field === 'sourceId') category = row.sourceCategory;
  else if (field === 'targetId') category = row.targetCategory;
  else category = ({ sourceSystem: 'integrationSystems', worldId: 'worlds', continentId: 'continents', villageId: 'villages', gameModeId: 'gameModes', family: 'entityFamilies', familyId: 'entityFamilies', vocationId: 'vocations', classId: 'externalClasses', cls: 'externalClasses', skillId: 'skills', itemId: 'items', giverId: 'npcs', npcId: 'npcs', questId: 'quests', monsterId: 'monsters', enemyId: 'monsters', shopId: 'shops', shop: 'shops', buildingId: 'buildings', floorId: 'mageTowerFloors', requiresResearchId: 'research', spellId: 'spells', zoneId: 'zones', areaId: 'zones' })[field] || null;
  return category ? devRows(category).filter(candidate => candidate && typeof candidate === 'object') : [];
}

function devCell(section, rowIndex, field, value, row = {}) {
  const encoded = typeof value === 'object' && value !== null ? JSON.stringify(value) : value ?? '';
  if (typeof value === 'boolean') return `<select class="boolean-cell" data-dev-field="${field}" data-dev-row="${rowIndex}" data-dev-section="${section}"><option value="true" ${value ? 'selected' : ''}>true</option><option value="false" ${!value ? 'selected' : ''}>false</option></select>`;
  if (typeof value === 'object' && value !== null) return `<textarea rows="2" data-dev-field="${field}" data-dev-row="${rowIndex}" data-dev-section="${section}">${escapeHtml(encoded)}</textarea>`;
  const inputType = typeof value === 'number' ? 'number' : 'text';
  const options = inputType === 'text' ? referenceOptions(section, field, row) : [];
  const listId = options.length ? `devref_${section}_${rowIndex}_${field}` : '';
  return `<input type="${inputType}" ${inputType === 'number' ? 'step="any"' : ''} ${listId ? `list="${listId}"` : ''} value="${escapeHtml(encoded)}" data-original-type="${typeof value}" data-dev-field="${field}" data-dev-row="${rowIndex}" data-dev-section="${section}">${listId ? `<datalist id="${listId}">${options.map(option => `<option value="${escapeHtml(option.id)}">${escapeHtml(option.name || option.label || option.id)}</option>`).join('')}</datalist>` : ''}`;
}

function updateDevField(input) {
  const rows = devRows(input.dataset.devSection); const row = rows[Number(input.dataset.devRow)]; if (!row) return;
  const original = row[input.dataset.devField]; let value = input.value;
  try {
    if (typeof original === 'number') value = Number(value);
    else if (typeof original === 'boolean') value = value === 'true';
    else if (typeof original === 'object' && original !== null) value = JSON.parse(value);
    row[input.dataset.devField] = value; input.style.boxShadow = 'inset 0 0 0 1px #68c791'; if (input.dataset.devSection === 'levelTiles') rebuildLevelTileIndex(); saveGame(false);
    logConsole(`${input.dataset.devSection}.${row.id || input.dataset.devRow}.${input.dataset.devField} updated.`);
  } catch (error) { input.style.boxShadow = 'inset 0 0 0 1px #e35f56'; toast('Invalid JSON in developer cell.', true); }
}

function activeLevelMap() { return byId(DATA.levelMaps, runtime.activeMapId) || DATA.levelMaps[0]; }
function openSceneManager(){const rows=DATA.scenes.map(scene=>{const map=byId(DATA.levelMaps,scene.mapId);return `<article class="info-card"><h3>${escapeHtml(scene.name)}</h3><p>${escapeHtml(scene.description)}</p><small>${map?.width||0} × ${map?.height||0} · ${escapeHtml(scene.kind)}</small><button data-edit-scene="${scene.id}">OPEN IN MAP EDITOR</button></article>`;}).join('');openModal('SCENE MANAGER','Ungodly Scenes',`<div class="modal-grid">${rows}<article class="info-card"><h3>Create a scene</h3><form id="newSceneForm" class="auth-form"><input name="name" placeholder="Scene name" required><input name="width" type="number" min="17" max="4096" value="256"><input name="height" type="number" min="11" max="4096" value="192"><button>CREATE & EDIT</button></form></article></div>`,'wide');document.querySelectorAll('[data-edit-scene]').forEach(button=>button.addEventListener('click',()=>{const scene=byId(DATA.scenes,button.dataset.editScene);if(!scene)return;closeModal();switchLevelMap(scene.mapId);openDeveloper('levelEditor');}));document.getElementById('newSceneForm')?.addEventListener('submit',event=>{event.preventDefault();const form=new FormData(event.currentTarget),id=uid('scene'),mapId=`map_${id}`,name=String(form.get('name')),width=clamp(Number(form.get('width')||256),17,4096),height=clamp(Number(form.get('height')||192),11,4096);DATA.scenes.push({id,name,mapId,kind:'custom',grid:{width,height,tileSize:TILE},description:`Custom ${width} × ${height} scene.`});DATA.levelMaps.push({id:mapId,name,width,height,tileSize:TILE,seed:0,backgroundTerrainId:'deep_water',spawn:{x:Math.floor(width/2),y:Math.floor(height/2),z:0},layers:{terrain:[],pathing:[]},staticObjects:[],entities:[],chunkSize:32,sourceSystem:'ungodly_backend',description:`${name} editable scene.`,tooltip:`${name} scene map.`});closeModal();switchLevelMap(mapId);openDeveloper('levelEditor');});}
function encodeTerrainRle(tiles, width, height, z = 0) { const lookup = new Map(tiles.filter(tile => Number(tile.z || 0) === z).map(tile => [`${tile.x},${tile.y}`, tile.terrain])); const runs = []; let last = null, count = 0; for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) { const value = lookup.get(`${x},${y}`) || ''; if (value === last) count++; else { if (count) runs.push([last, count]); last = value; count = 1; } } if (count) runs.push([last, count]); return { format: 'rle-v1', width, height, z, runs }; }
function decodeTerrainRle(encoded, mapId) { const tiles = []; let index = 0; for (const [terrainId, count] of encoded.runs || []) for (let offset = 0; offset < Number(count); offset++, index++) { if (!terrainId) continue; const x = index % encoded.width, y = Math.floor(index / encoded.width), definition = byId(DATA.tilePalette, terrainId) || {}; tiles.push({ id: `rle_${mapId}_${x}_${y}_${encoded.z || 0}`, mapId, x, y, z: encoded.z || 0, terrain: terrainId, color: definition.color || '#33443c', walkable: Boolean(definition.walkable), wall: Boolean(definition.wall), water: Boolean(definition.water), description: `Decoded ${terrainId} map tile.`, tooltip: `${mapId} tile ${x}, ${y}.`, iconDirectory: `/assets/icons/levelTiles/rle_${mapId}_${x}_${y}.png`, modelDirectory: `/assets/models/levelTiles/rle_${mapId}_${x}_${y}.glb` }); } return tiles; }
function indexMapInstance(map, kind, instance) { map.spatialIndex = map.spatialIndex || {}; const size = Number(map.chunkSize || 32), key = `${Math.floor(instance.position.x / size)},${Math.floor(instance.position.y / size)},${instance.position.z || 0}`; map.spatialIndex[key] = map.spatialIndex[key] || { static: [], entities: [] }; map.spatialIndex[key][kind].push(instance.instanceId); }
function switchLevelMap(mapId) {
  const current = activeLevelMap(); if (current) current.layers.terrain = DATA.levelTiles;
  const next = byId(DATA.levelMaps, mapId); if (!next) return;
  runtime.activeMapId = next.id; DATA.levelTiles = next.layers.terrain = next.layers.terrain || []; rebuildLevelTileIndex(); runtime.minimapBase = null;
  const spawn = next.spawn || { x: Math.floor(next.width / 2), y: Math.floor(next.height / 2), z: 0 };
  if (runtime.character) { Object.assign(runtime.character, spawn); runtime.path = []; runtime.camera.x = spawn.x; runtime.camera.y = spawn.y; }
  Object.assign(runtime.levelEditor, { centerX: spawn.x, centerY: spawn.y, z: spawn.z || 0 }); resetRuntimeWorld(); saveGame(false);
}
function generateLandBlob(map) {
  const width = map.width, height = map.height, seed = Math.floor(Math.random() * 2147483647); map.seed = seed;
  const random = index => { const value = Math.sin(seed + index * 9283.77) * 43758.5453; return value - Math.floor(value); };
  const cx = width / 2, cy = height / 2, rx = width * (.31 + random(1) * .12), ry = height * (.31 + random(2) * .12), tiles = [];
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) { const angle = Math.atan2((y - cy) / ry, (x - cx) / rx); const wobble = 1 + Math.sin(angle * 3 + random(3) * 6) * .13 + Math.sin(angle * 7 + random(4) * 6) * .07; const distance = Math.sqrt(((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2); const land = distance < wobble; const definition = DATA.tilePalette.find(tile => land ? tile.walkable && !tile.water : tile.water) || DATA.tilePalette[0]; tiles.push({ id: `blob_${map.id}_${x}_${y}`, mapId: map.id, x, y, z: 0, terrain: definition.id, color: definition.color, walkable: Boolean(definition.walkable), wall: false, water: Boolean(definition.water), description: `Generated ${definition.name} base tile.`, tooltip: `${map.name} generated tile ${x}, ${y}.`, iconDirectory: `/assets/icons/levelTiles/blob_${map.id}_${x}_${y}.png`, modelDirectory: `/assets/models/levelTiles/blob_${map.id}_${x}_${y}.glb` }); }
  map.layers.terrain = tiles; map.layers.terrainRle = encodeTerrainRle(tiles, width, height); map.layers.terrainFormat = 'rle-v1 with editable runtime cache'; if (map.id === runtime.activeMapId) { DATA.levelTiles = tiles; rebuildLevelTileIndex(); runtime.minimapBase = null; }
}
function validateLevelMap(map) {
  const issues = [], terrain = map.layers.terrain || [], pathing = map.layers.pathing || [], objects = DATA.mapObjectInstances.filter(row => row.mapId === map.id), entities = DATA.mapEntityInstances.filter(row => row.mapId === map.id), tileAt = new Map(terrain.map(tile => [`${tile.x},${tile.y},${tile.z || 0}`, tile])), occupied = new Map();
  map.spatialIndex = {}; for (const object of objects) indexMapInstance(map, 'static', object); for (const entity of entities) indexMapInstance(map, 'entities', entity);
  for (const object of objects) for (let y = object.position.y; y < object.position.y + Number(object.footprint?.height || 1); y++) for (let x = object.position.x; x < object.position.x + Number(object.footprint?.width || 1); x++) { const key = `${x},${y},${object.position.z || 0}`; if (occupied.has(key)) issues.push(`Static overlap at ${key}: ${occupied.get(key)} and ${object.instanceId}`); else occupied.set(key, object.instanceId); }
  for (const entity of entities) { const key = `${entity.position.x},${entity.position.y},${entity.position.z || 0}`, tile = tileAt.get(key), path = pathing.find(row => row.x === entity.position.x && row.y === entity.position.y && Number(row.z || 0) === Number(entity.position.z || 0)); if (tile?.water || tile?.walkable === false || path?.walkable === false) issues.push(`${entity.instanceId} spawns on blocked terrain at ${key}`); if (![...DATA.npcs, ...DATA.monsters].some(row => row.id === entity.assetId)) issues.push(`${entity.instanceId} references missing asset ${entity.assetId}`); }
  const spawnTile = tileAt.get(`${map.spawn.x},${map.spawn.y},${map.spawn.z || 0}`); if (spawnTile?.water || spawnTile?.walkable === false) issues.push('Player spawn is not walkable.'); if (!objects.length && map.id !== 'map_emberwake_overworld') issues.push('No civic or static objects have been placed.'); if (!entities.length && map.id !== 'map_emberwake_overworld') issues.push('No NPCs or creatures have been placed.'); runtime.levelEditor.validation = issues; return issues;
}

function renderLevelEditor() {
  const editor = runtime.levelEditor; const halfW = 8; const halfH = 5;
  const map = activeLevelMap(); const mapWidth = map.width; const mapHeight = map.height;
  editor.centerX = clamp(Math.round(editor.centerX), halfW, mapWidth - halfW - 1); editor.centerY = clamp(Math.round(editor.centerY), halfH, mapHeight - halfH - 1); editor.z = clamp(Math.round(editor.z), -8, 0);
  const palette = byId(DATA.tilePalette, editor.selectedTerrain) || DATA.tilePalette[0];
  const cells = [];
  for (let y = editor.centerY - halfH; y <= editor.centerY + halfH; y++) for (let x = editor.centerX - halfW; x <= editor.centerX + halfW; x++) {
    const override = levelTileAt(x, y, editor.z); const terrain = override?.terrain || terrainAt(x, y, editor.z); const definition = byId(DATA.tilePalette, terrain);
    const color = override?.color || definition?.color || '#33443c'; const status = override ? override.wall ? 'W' : override.water ? '≈' : override.walkable ? '·' : '×' : '';
    cells.push(`<button class="level-cell ${override ? 'overridden' : ''}" data-level-x="${x}" data-level-y="${y}" style="--tile-color:${color}" data-tooltip="${escapeHtml(`${definition?.name || terrain}\nX ${x} · Y ${y} · Z ${editor.z}\n${override ? `Override · walkable ${override.walkable} · wall ${override.wall} · water ${override.water}` : 'Generated base terrain'}`)}"><span>${status}</span><small>${x},${y}</small></button>`);
  }
  el.devSummary.textContent = `${DATA.levelMaps.length} maps · ${DATA.levelTiles.length} terrain cells · ${DATA.mapObjectInstances.filter(row => row.mapId === map.id).length} static objects · ${DATA.mapEntityInstances.filter(row => row.mapId === map.id).length} entities`;
  el.devContent.innerHTML = `<div class="level-editor"><aside class="level-palette"><header><h2>TERRAIN PALETTE</h2><p>Used and new tile families</p></header><div class="palette-list">${DATA.tilePalette.map(tile => `<button data-palette-id="${tile.id}" class="${tile.id === editor.selectedTerrain && !editor.erase ? 'active' : ''}" style="--swatch:${tile.color}"><i></i><span>${escapeHtml(tile.name)}</span><small>${tile.walkable ? 'WALK' : tile.wall ? 'WALL' : tile.water ? 'WATER' : 'BLOCK'}</small></button>`).join('')}</div></aside><section class="level-canvas"><div class="level-tools"><div class="coordinate-tools"><button data-editor-pan="0,-5">▲</button><button data-editor-pan="-8,0">◀</button><label>X<input id="editorX" type="number" min="0" max="${WORLD_W - 1}" value="${editor.centerX}"></label><label>Y<input id="editorY" type="number" min="0" max="${WORLD_H - 1}" value="${editor.centerY}"></label><label>Z<input id="editorZ" type="number" min="-8" max="0" value="${editor.z}"></label><button data-editor-pan="8,0">▶</button><button data-editor-pan="0,5">▼</button><button id="editorGoPlayer">PLAYER</button></div><div class="brush-tools"><label>COLOR <input id="editorColor" type="color" value="${editor.color || palette.color}"></label><label><input id="editorWalkable" type="checkbox" ${editor.walkable ? 'checked' : ''}> WALKABLE</label><label><input id="editorWall" type="checkbox" ${editor.wall ? 'checked' : ''}> WALL</label><label><input id="editorWater" type="checkbox" ${editor.water ? 'checked' : ''}> WATER</label><button id="editorSavePaletteColor">RECOLOR PALETTE</button><button id="editorErase" class="${editor.erase ? 'active' : ''}">ERASER</button></div></div><div class="level-grid">${cells.join('')}</div><footer><span>Brush: <b>${editor.erase ? 'ERASE OVERRIDE' : escapeHtml(palette.name)}</b></span><span>Drag across cells to paint. Base procedural terrain remains underneath erased cells.</span></footer></section></div>`;
  el.devContent.querySelectorAll('[data-palette-id]').forEach(button => button.addEventListener('click', () => { const tile = byId(DATA.tilePalette, button.dataset.paletteId); if (!tile) return; Object.assign(editor, { selectedTerrain: tile.id, color: tile.color, walkable: tile.walkable, wall: tile.wall, water: tile.water, erase: false }); renderLevelEditor(); }));
  const syncTools = () => { editor.centerX = Number(document.getElementById('editorX').value); editor.centerY = Number(document.getElementById('editorY').value); editor.z = Number(document.getElementById('editorZ').value); editor.color = document.getElementById('editorColor').value; editor.walkable = document.getElementById('editorWalkable').checked; editor.wall = document.getElementById('editorWall').checked; editor.water = document.getElementById('editorWater').checked; };
  el.devContent.insertAdjacentHTML('afterbegin', `<section class="map-manager"><div class="map-row"><label>ACTIVE MAP<select id="editorMapSelect">${DATA.levelMaps.map(row => `<option value="${row.id}" ${row.id === map.id ? 'selected' : ''}>${escapeHtml(row.name)} · ${row.width}×${row.height}</option>`).join('')}</select></label><button id="editorNewMap">＋ NEW MAP</button><button id="editorBlob">GENERATE RANDOM LAND BLOB</button><button id="editorValidate">VALIDATE MAP</button></div><div class="layer-tabs">${['terrain','pathing','static','entities'].map(layer => `<button data-map-layer="${layer}" class="${editor.layer === layer ? 'active' : ''}">${layer.toUpperCase()}</button>`).join('')}</div><div class="map-stamps">${editor.layer === 'static' ? `<label>STATIC ASSET<select id="editorStaticAsset">${DATA.buildings.map(row => `<option value="${row.id}" ${row.id === editor.selectedStaticAssetId ? 'selected' : ''}>${escapeHtml(row.name)}</option>`).join('')}</select></label>` : editor.layer === 'entities' ? `<label>ENTITY ASSET<select id="editorEntityAsset">${[...DATA.npcs, ...DATA.monsters].map(row => `<option value="${row.id}" ${row.id === editor.selectedEntityAssetId ? 'selected' : ''}>${escapeHtml(row.name)}</option>`).join('')}</select></label>` : '<span>Paint the selected layer directly onto the shared coordinate grid.</span>'}</div><aside class="civic-checklist"><b>MINIMUM WORKING MAP CHECKLIST</b>${DATA.mapCivicRequirements.map(rule => `<span title="${escapeHtml(rule.rule)}">□ ${escapeHtml(rule.name)} · min ${rule.minimum}</span>`).join('')}</aside>${editor.validation.length ? `<div class="map-validation">${editor.validation.map(issue => `<p>⚠ ${escapeHtml(issue)}</p>`).join('')}</div>` : ''}</section>`);
  document.getElementById('editorMapSelect')?.addEventListener('change', event => { switchLevelMap(event.target.value); renderLevelEditor(); });
  document.getElementById('editorNewMap')?.addEventListener('click', () => { const name = prompt('Map name', `New Map ${DATA.levelMaps.length + 1}`); if (!name) return; const width = clamp(Number(prompt('Width (17–256)', '128') || 128), 17, WORLD_W), height = clamp(Number(prompt('Height (11–192)', '128') || 128), 11, WORLD_H), id = uid('map'); DATA.levelMaps.push({ id, name, width, height, tileSize: TILE, seed: 0, backgroundTerrainId: 'deep_water', spawn: { x: Math.floor(width / 2), y: Math.floor(height / 2), z: 0 }, layers: { terrain: [], pathing: [] }, staticObjects: [], entities: [], chunkSize: 32, sourceSystem: 'emberwake', description: `${name} editable level map.`, tooltip: `${name} layered map definition.`, iconDirectory: `/assets/icons/levelMaps/${id}.png`, modelDirectory: `/assets/models/levelMaps/${id}.glb` }); switchLevelMap(id); renderLevelEditor(); });
  document.getElementById('editorBlob')?.addEventListener('click', () => { generateLandBlob(map); editor.centerX = Math.floor(map.width / 2); editor.centerY = Math.floor(map.height / 2); saveGame(false); renderLevelEditor(); });
  document.getElementById('editorValidate')?.addEventListener('click', () => { validateLevelMap(map); renderLevelEditor(); });
  el.devContent.querySelectorAll('[data-map-layer]').forEach(button => button.addEventListener('click', () => { editor.layer = button.dataset.mapLayer; editor.erase = false; renderLevelEditor(); }));
  document.getElementById('editorStaticAsset')?.addEventListener('change', event => editor.selectedStaticAssetId = event.target.value);
  document.getElementById('editorEntityAsset')?.addEventListener('change', event => editor.selectedEntityAssetId = event.target.value);
  ['editorX', 'editorY', 'editorZ'].forEach(id => document.getElementById(id)?.addEventListener('change', () => { syncTools(); renderLevelEditor(); }));
  ['editorColor', 'editorWalkable', 'editorWall', 'editorWater'].forEach(id => document.getElementById(id)?.addEventListener('change', syncTools));
  el.devContent.querySelectorAll('[data-editor-pan]').forEach(button => button.addEventListener('click', () => { const [dx, dy] = button.dataset.editorPan.split(',').map(Number); editor.centerX += dx; editor.centerY += dy; renderLevelEditor(); }));
  document.getElementById('editorGoPlayer')?.addEventListener('click', () => { editor.centerX = runtime.character?.x || 18; editor.centerY = runtime.character?.y || 46; editor.z = runtime.character?.z || 0; renderLevelEditor(); });
  document.getElementById('editorErase')?.addEventListener('click', () => { syncTools(); editor.erase = !editor.erase; renderLevelEditor(); });
  document.getElementById('editorSavePaletteColor')?.addEventListener('click', () => { syncTools(); const tile = byId(DATA.tilePalette, editor.selectedTerrain); if (tile) tile.color = editor.color; runtime.minimapBase = null; saveGame(false); renderLevelEditor(); });
  let painting = false;
  const paint = button => { syncTools(); paintLevelTile(Number(button.dataset.levelX), Number(button.dataset.levelY)); button.style.setProperty('--tile-color', editor.erase ? (byId(DATA.tilePalette, terrainAt(Number(button.dataset.levelX), Number(button.dataset.levelY), editor.z))?.color || '#33443c') : editor.color); button.classList.toggle('overridden', !editor.erase); };
  el.devContent.querySelectorAll('[data-level-x]').forEach(button => {
    button.addEventListener('pointerdown', event => { event.preventDefault(); painting = true; paint(button); });
    button.addEventListener('pointerenter', () => { if (painting) paint(button); });
    button.addEventListener('click', event => event.preventDefault());
  });
  const stopPainting = () => { if (!painting) return; painting = false; saveGame(false); renderLevelEditor(); };
  el.devContent.querySelector('.level-grid')?.addEventListener('pointerleave', stopPainting, { once: true });
  window.addEventListener('pointerup', stopPainting, { once: true });
}

function paintLevelTile(x, y) {
  const editor = runtime.levelEditor, map = activeLevelMap();
  if (editor.layer === 'pathing') { const index = map.layers.pathing.findIndex(row => row.x === x && row.y === y && row.z === editor.z); if (index >= 0) map.layers.pathing.splice(index, 1); if (!editor.erase) map.layers.pathing.push({ id: uid('path'), mapId: map.id, x, y, z: editor.z, walkable: Boolean(editor.walkable), movementCost: editor.walkable ? 1 : 255, flags: editor.water ? ['water'] : editor.wall ? ['wall'] : [] }); return; }
  if (editor.layer === 'static') { const asset = byId(DATA.buildings, editor.selectedStaticAssetId); if (!asset) return; DATA.mapObjectInstances.push({ id: uid('map_object'), instanceId: uid('object'), mapId: map.id, assetId: asset.id, position: { x, y, z: editor.z }, footprint: { width: Number(asset.width || 1), height: Number(asset.height || 1) }, customProperties: { hp: asset.hp || 0, team: 'neutral' }, description: `${asset.name} map instance.`, tooltip: `${asset.name} at ${x}, ${y}.`, iconDirectory: asset.iconDirectory || `/assets/icons/buildings/${asset.id}.png`, modelDirectory: asset.modelDirectory || `/assets/models/buildings/${asset.id}.glb` }); return; }
  if (editor.layer === 'entities') { const asset = byId(DATA.npcs, editor.selectedEntityAssetId) || byId(DATA.monsters, editor.selectedEntityAssetId); if (!asset) return; DATA.mapEntityInstances.push({ id: uid('map_entity'), instanceId: uid('entity'), mapId: map.id, type: byId(DATA.npcs, asset.id) ? 'npc' : 'monster', assetId: asset.id, position: { x, y, z: editor.z }, stats: { health: asset.hp || 100, aggroRange: asset.aggro || 0 }, aiRoutine: asset.patrol ? 'patrol' : asset.aggro ? 'wander_aggro' : 'idle', description: `${asset.name} map entity.`, tooltip: `${asset.name} at ${x}, ${y}.`, iconDirectory: asset.iconDirectory || `/assets/icons/entities/${asset.id}.png`, modelDirectory: asset.modelDirectory || `/assets/models/entities/${asset.id}.glb` }); return; }
  const index = DATA.levelTiles.findIndex(tile => tile.x === x && tile.y === y && tile.z === editor.z);
  if (index >= 0) DATA.levelTiles.splice(index, 1);
  if (!editor.erase) DATA.levelTiles.push({ id: uid('level_tile'), x, y, z: editor.z, terrain: editor.selectedTerrain, color: editor.color, walkable: Boolean(editor.walkable), wall: Boolean(editor.wall), water: Boolean(editor.water), iconDirectory: '/assets/icons/levelTiles/', modelDirectory: '/assets/models/levelTiles/', description: `${byId(DATA.tilePalette, editor.selectedTerrain)?.name || editor.selectedTerrain} tile override.`, tooltip: `Editable ${editor.selectedTerrain} tile at X ${x}, Y ${y}, Z ${editor.z}.` });
  rebuildLevelTileIndex();
}

function addDevRow() {
  const key = runtime.activeDevTab; const rows = devRows(key); if (!Array.isArray(rows)) return;
  const label = DEV_SECTIONS.find(entry => entry[0] === key)?.[1] || key;
  const presets = {
    items: { type: 'material', weight: 0, buy: 0, sell: 0, stackable: true }, spells: { group: 'utility', effect: 'light', level: 1, mana: 0, cooldown: 1000, vocations: [] }, monsters: { level: 1, hp: 10, attack: 1, defense: 0, xp: 5, speed: 1, range: 1, aggro: 3, element: 'physical' }, quests: { giverId: '', recommendedLevel: 1, solo: true, prerequisite: [], objectives: [], rewards: { xp: 0, gold: 0, items: [] } }, npcs: { role: 'citizen', x: 18, y: 46, z: 0, zoneId: 'anchorage_harbor', quests: [], shop: null, inventory: [], spellbook: { learned: [] } }, shops: { buys: [], sells: [], stock: {} }, buildings: { type: 'house', x: 18, y: 46, z: 0, width: 3, height: 3, npcIds: [], collision: 'open entrance' }, externalBuildings: { age: 'Dark', costText: '', work: 0, hp: 100, width: 2, depth: 2, height: 2, guildId: '', effectsText: '', tiers: 4, collider: {}, parts: [], sourceSystem: 'sovereign_aegis' }, relationships: { sourceCategory: 'characters', sourceId: 'char_1', targetCategory: 'vocations', targetId: 'black_knight', relationshipType: 'defines', cardinality: 'many-to-one', cascade: 'restrict', sourceSystem: 'emberwake' }, externalRecords: { sourceSystem: 'gameplay_designer', category: 'custom', payload: {} }, tailoringRecipes: { skillId: 'tailoring', level: 1, inputs: {}, outputs: {}, xp: 0, station: 'tailoring_kit' }, schemaFields: { sourceSystem: 'emberwake', scope: 'definition', path: '', valueType: 'string', persistence: 'definition', derived: false, mergeRule: 'stable-key merge' }
  };
  const newId = uid(key.replace(/s$/, ''));
  rows.push({ id: newId, name: `New ${label.replace(/s$/, '')}`, ...(deepClone(presets[key] || {})), iconDirectory: `/assets/icons/${key}/${newId}.png`, modelDirectory: `/assets/models/${key}/${newId}.glb`, description: 'New data-driven entry', tooltip: 'New editable data-driven entry.' });
  renderDevTabs(); renderDevContent(); saveGame(false); logConsole(`Added a new entry to ${key}.`);
}

function renderDropController() {
  const search = runtime.devSearch.toLowerCase();
  const monsters = DATA.monsters.filter(monster => !search || monster.name.toLowerCase().includes(search) || monster.id.includes(search));
  let monster = byId(DATA.monsters, runtime.devDropMonster) || monsters[0] || DATA.monsters[0];
  if (monster && !monsters.includes(monster) && monsters.length) monster = monsters[0];
  if (!monster) return;
  runtime.devDropMonster = monster.id;
  let table = DATA.dropTables.find(entry => entry.monsterId === monster.id);
  if (!table) { table = { id: `drop_${monster.id.replace('mob_', '')}`, monsterId: monster.id, rolls: 1, entries: [], iconDirectory: `/assets/icons/dropTables/drop_${monster.id}.png`, modelDirectory: `/assets/models/dropTables/drop_${monster.id}.glb`, description: `Drop rules for ${monster.name}.`, tooltip: `${monster.name} percentage drop table.` }; DATA.dropTables.push(table); }
  const chanceTotal = () => table.entries.filter(entry => entry.tier !== 'always').reduce((sum, entry) => sum + Number(entry.chancePercent || 0), 0);
  const total = chanceTotal();
  el.devSummary.textContent = `${DATA.dropTables.length} tables · every killable creature covered · selectable percentage rolls`;
  const groups = ['always', 'common', 'rare', 'tertiary'];
  el.devContent.innerHTML = `<div class="drop-controller"><aside class="drop-monsters">${monsters.map(entry => `<button data-drop-monster="${entry.id}" class="${entry.id === monster.id ? 'active' : ''}"><span>${entry.icon} ${escapeHtml(entry.name)}</span><b>LV ${entry.level}</b></button>`).join('')}</aside><section class="drop-editor"><h2>${monster.icon} ${escapeHtml(monster.name)}</h2><p>${escapeHtml(monster.traits || '')} · ${monster.xp} XP · ${table.rolls} percentage roll(s). Always entries are additional guaranteed rewards.</p><div class="drop-total ${total > 100.001 ? 'over' : ''}"><b>RARITY POOL: ${total.toFixed(2)}%</b><span>${total <= 100 ? `${(100 - total).toFixed(2)}% chance of no selectable drop` : `${(total - 100).toFixed(2)}% over budget`}</span><button id="normalizeDropChances">NORMALIZE TO 100%</button></div>${groups.map(group => `<section class="drop-roll-group"><header><span>${group.toUpperCase()}</span><button data-add-drop="${group}">＋ ENTRY</button></header>${table.entries.filter(entry => entry.tier === group).map(entry => dropEntryHtml(table, entry)).join('') || '<div class="target-empty">No entries in this tier.</div>'}</section>`).join('')}<section class="drop-sim"><label>Simulated kills <input id="dropKillCount" type="number" min="1" max="100000" value="1000"></label><button class="primary-button" id="simulateDrops">ROLL TABLE</button><span>Uses the same controller as live monster deaths.</span></section><div id="dropResults" class="drop-results"></div></section></div>`;
  el.devContent.querySelectorAll('[data-drop-monster]').forEach(button => button.addEventListener('click', () => { runtime.devDropMonster = button.dataset.dropMonster; renderDropController(); }));
  el.devContent.querySelectorAll('[data-drop-entry-id]').forEach(input => input.addEventListener('change', () => {
    const entry = table.entries.find(candidate => candidate._editorId === input.dataset.dropEntryId); if (!entry) return;
    const field = input.dataset.dropField; entry[field] = ['chancePercent', 'min', 'max'].includes(field) ? Number(input.value) : input.value; saveGame(false); if (field === 'chancePercent') renderDropController();
  }));
  el.devContent.querySelectorAll('[data-remove-drop]').forEach(button => button.addEventListener('click', () => { const index = table.entries.findIndex(entry => entry._editorId === button.dataset.removeDrop); if (index >= 0) table.entries.splice(index, 1); renderDropController(); saveGame(false); }));
  el.devContent.querySelectorAll('[data-add-drop]').forEach(button => button.addEventListener('click', () => { table.entries.push({ _editorId: uid('dropentry'), itemId: DATA.items[0].id, tier: button.dataset.addDrop, chancePercent: button.dataset.addDrop === 'always' ? 100 : Math.max(0, Math.min(10, 100 - chanceTotal())), min: 1, max: 1 }); renderDropController(); saveGame(false); }));
  document.getElementById('normalizeDropChances')?.addEventListener('click', () => { const entries = table.entries.filter(entry => entry.tier !== 'always'); const sum = chanceTotal(); if (entries.length && sum > 0) entries.forEach(entry => entry.chancePercent = Number((Number(entry.chancePercent || 0) / sum * 100).toFixed(2))); renderDropController(); saveGame(false); });
  document.getElementById('simulateDrops')?.addEventListener('click', () => simulateDropTable(monster.id, Number(document.getElementById('dropKillCount').value || 1000)));
}

function dropEntryHtml(table, entry) {
  if (!entry._editorId) entry._editorId = uid('dropentry');
  const chance = entry.tier === 'always' ? 100 : Number(entry.chancePercent || 0);
  return `<div class="drop-entry"><select data-drop-entry-id="${entry._editorId}" data-drop-field="itemId">${DATA.items.map(item => `<option value="${item.id}" ${item.id === entry.itemId ? 'selected' : ''}>${escapeHtml(item.name)}</option>`).join('')}</select><label class="chance-editor" title="Exact share of this creature's 100% selectable rarity pool"><input type="range" min="0" max="100" step="0.1" value="${chance}" ${entry.tier === 'always' ? 'disabled' : ''} data-drop-entry-id="${entry._editorId}" data-drop-field="chancePercent"><input type="number" min="0" max="100" step="0.1" value="${chance}" ${entry.tier === 'always' ? 'disabled' : ''} data-drop-entry-id="${entry._editorId}" data-drop-field="chancePercent"></label><input title="Minimum quantity" type="number" value="${entry.min}" data-drop-entry-id="${entry._editorId}" data-drop-field="min"><input title="Maximum quantity" type="number" value="${entry.max}" data-drop-entry-id="${entry._editorId}" data-drop-field="max"><button class="row-delete" data-remove-drop="${entry._editorId}">×</button></div>`;
}

function simulateDropTable(monsterId, kills) {
  kills = clamp(Math.floor(kills), 1, 100000); const totals = new Map();
  for (let i = 0; i < kills; i++) for (const drop of rollDrops(monsterId)) totals.set(drop.itemId, (totals.get(drop.itemId) || 0) + drop.qty);
  const rows = [...totals.entries()].sort((a, b) => b[1] - a[1]).map(([id, qty]) => `${itemOf(id)?.name || id}: ${number(qty)} total · ${(qty / kills).toFixed(3)} per kill`);
  document.getElementById('dropResults').textContent = rows.join('\n') || 'No items rolled.';
  logConsole(`Simulated ${number(kills)} kills for ${monsterId}; ${rows.length} item types rolled.`);
}

function exportGameJson() {
  saveGame(false);
  const payload = {
    format: 'FSG_TIBIALIKE_EMBERWAKE', version: APP_VERSION, schemaVersion: runtime.save.schemaVersion, contentVersion: runtime.save.contentVersion,
    sourceSystem: 'emberwake', exportedAt: nowIso(), meta: DATA.meta,
    definitions: catalogSnapshot(), catalog: catalogSnapshot(), world: runtime.save.world, save: runtime.save, integrations: runtime.save.integrations,
    interoperability: { stableIds: true, unknownFields: 'preserve', definitionsSeparateFromRuntime: true, inventoryStack: '{id,qty,instanceId?}', foreignDataPath: 'save.integrations.<systemId>.data', timestampPolicy: { cooldowns: 'unix-ms', audits: 'ISO-8601' } }
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = `emberwake-${new Date().toISOString().slice(0, 10)}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  toast('Game data and all five saves exported to JSON.'); logConsole('Exported catalog and player state JSON.');
}

async function importGameJson(file) {
  try {
    const payload = JSON.parse(await file.text());
    const isEmberwake = payload.format === 'FSG_TIBIALIKE_EMBERWAKE' && (payload.catalog || payload.definitions) && payload.save;
    if (!isEmberwake) {
      const systemId = payload.format === 'sovereign-aegis/1' ? 'sovereign_aegis' : payload.format === 'FSG.StatSystemDesigner' ? 'stat_system_designer' : payload.format === 'FSG.GameplayDesigner' ? 'gameplay_designer' : payload.rtsProject || payload.formations && payload.buildingTypes ? 'field_sigil_rts' : payload.schemaVersion && payload.inventory && payload.skills ? 'runelite_primitive_realm' : null;
      if (!systemId) throw new Error('The JSON format is not one of the mapped game contracts.');
      const previous = runtime.save.integrations[systemId] || {};
      runtime.save.integrations[systemId] = { ...previous, schemaVersion: Number(payload.schemaVersion || previous.schemaVersion || 1), contentVersion: Number(payload.contentVersion || previous.contentVersion || 1), lastMigratedAt: nowIso(), data: deepMergeUnknown(previous.data || {}, payload) };
      const recordId = `import_${systemId}`; const record = byId(DATA.externalRecords, recordId); const nextRecord = { id: recordId, name: `${byId(DATA.integrationSystems, systemId)?.name || systemId} Imported Contract`, sourceSystem: systemId, category: 'import', payload };
      if (record) Object.assign(record, nextRecord); else DATA.externalRecords.push(nextRecord);
      normalizeEditableCatalog(); saveGame(false); renderSharedContextBar(); renderDevTabs(); renderDevContent(); el.jsonFileInput.value = ''; toast(`${byId(DATA.integrationSystems, systemId)?.name || systemId} data imported without replacing Emberwake state.`); logConsole(`Imported ${systemId} into save.integrations.${systemId}.data.`); return;
    }
    for (const [key, value] of Object.entries(payload.catalog || payload.definitions)) {
      if (key === 'projectMeta' && Array.isArray(value) && value[0]) DATA.meta = { ...DATA.meta, ...value[0] };
      else if (Array.isArray(value)) {
        DATA[key] = mergeRowsByStableId(DATA[key] || [], value);
        if (!EDITABLE_CATALOG_KEYS.includes(key)) EDITABLE_CATALOG_KEYS.push(key);
      }
    }
    for (const key of EDITABLE_CATALOG_KEYS) if (Array.isArray(DATA[key]) && !categoryDefinition(key) && !['characters', 'authoringCategories', 'fieldDefinitions', 'sourceRegistryCounts'].includes(key)) DATA.authoringCategories.push({ id: `category_${key}`, name: key.replace(/([A-Z])/g, ' $1').replace(/^./, value => value.toUpperCase()), storageKey: key, entityType: 'custom', sourceSystem: 'import', layer: 'definition', runtimeCollection: '', persistence: 'catalog + JSON + MySQL', stableIdRequired: true, preserveUnknownFields: true, fourStringFieldsRequired: true, builderPreset: 'custom' });
    normalizeEditableCatalog();
    runtime.save = deepMergeUnknown(DEFAULT_SAVE, payload.save);
    runtime.save.integrations = deepMergeUnknown(runtime.save.integrations, payload.integrations || payload.save.integrations || {});
    for (const [index, character] of (runtime.save.characters || []).entries()) {
      character.iconDirectory = typeof character.iconDirectory === 'string' ? character.iconDirectory : '/assets/icons/characters/'; character.modelDirectory = typeof character.modelDirectory === 'string' ? character.modelDirectory : '/assets/models/characters/';
      character.description = typeof character.description === 'string' ? character.description : character.scenarioText || `Character ${index + 1}.`; character.tooltip = typeof character.tooltip === 'string' ? character.tooltip : character.description;
    }
    runtime.character = runtime.save.characters.find(character => character.id === runtime.character?.id) || null; runtime.levelTileIndex = null; runtime.minimapBase = null;
    saveGame(false); renderSharedContextBar(); renderDevTabs(); renderDevContent(); if (runtime.character) renderAllUi(); toast('JSON imported successfully.'); logConsole('Imported and applied JSON catalog/save bundle.');
  } catch (error) { toast(`Import failed: ${error.message}`, true); logConsole(`Import error: ${error.message}`, 'error'); }
  el.jsonFileInput.value = '';
}

async function syncServer(silent = false) {
  if (location.protocol === 'file:') { if (!silent) toast('MySQL sync needs this folder served through PHP; local play and JSON export remain available.', true, 1800); return; }
  saveGame(false); const button = document.getElementById('devSync'); button.disabled = true; button.textContent = 'SYNCING…';
  try {
    const response = await fetch('./app.php?action=save', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-FSG-Server-Session': getServerSessionId() }, body: JSON.stringify({ projectId: PROJECT_ID, serverSessionId:getServerSessionId(), expectedRevision: runtime.save.serverRevision, state: runtime.save, catalog: catalogSnapshot(), integrations: runtime.save.integrations, events: runtime.save.eventQueue || [] }) });
    const result = await response.json(); if (!response.ok || result.status !== 'success') throw new Error(result.message || 'Server rejected the save.');
    runtime.save.serverRevision = Number(result.revision ?? runtime.save.serverRevision ?? 0); runtime.save.revision = runtime.save.serverRevision; runtime.save.eventQueue = []; runtime.server.status = 'synced'; runtime.server.role=result.role||runtime.server.role; if (!silent) toast(`MySQL sync complete · revision ${runtime.save.serverRevision}.`); logConsole(`MySQL sync complete for ${result.identity || 'current identity'} at revision ${runtime.save.serverRevision}.`);
  } catch (error) { runtime.server.status = 'offline'; if (!silent) toast(`Server sync unavailable; local save is safe. ${error.message}`, true, 1200); logConsole(`Server sync failed: ${error.message}`, 'error'); }
  finally { button.disabled = false; button.textContent = 'SYNC MYSQL'; }
}

function runConsoleCommand(raw) {
  const char = runtime.character; const [command = '', ...args] = raw.trim().split(/\s+/); if (!command) return;
  logConsole(`› ${raw}`, 'command');
  try {
    if (command === 'help') logConsole('Commands: help, where, teleport X Y Z, level N, gold N, give ITEM [QTY], spawn MONSTER [COUNT], heal, light, complete QUEST, killall, export, list monsters|items|quests, reset-character');
    else if (command === 'where') logConsole(`${char.name}: ${char.x}, ${char.y}, ${char.z} · ${zoneAt(char.x, char.y, char.z)?.name}`);
    else if (command === 'teleport') { const [x, y, z] = args.map(Number); if (![x, y, z].every(Number.isFinite)) throw new Error('Usage: teleport X Y Z'); char.x = x; char.y = y; char.z = z; runtime.camera.x = x; runtime.camera.y = y; logConsole(`Teleported to ${x}, ${y}, ${z}.`); }
    else if (command === 'level') { const value = clamp(Number(args[0]), 1, 999); if (!Number.isFinite(value)) throw new Error('Usage: level N'); char.level = value; logConsole(`Level set to ${value}.`); }
    else if (command === 'gold') { const value = Math.max(0, Number(args[0])); if (!Number.isFinite(value)) throw new Error('Usage: gold N'); char.gold = value; logConsole(`Gold set to ${value}.`); }
    else if (command === 'give') { const item = itemOf(args[0]); if (!item) throw new Error(`Unknown item: ${args[0]}`); addItem(item.id, Math.max(1, Number(args[1] || 1)),runtime.character,false,{sourceType:'admin_create',sourceId:'developer_console',adminCreated:true,reason:'created with admin give command'}); }
    else if (command === 'spawn') { const monster = byId(DATA.monsters, args[0]); if (!monster) throw new Error(`Unknown monster: ${args[0]}`); const count = clamp(Number(args[1] || 1), 1, 30); for (let i = 0; i < count; i++) spawnMonster(monster.id, char.x + 2 + i % 3, char.y + Math.floor(i / 3), char.z); logConsole(`Spawned ${count} × ${monster.name}.`); }
    else if (command === 'heal') { char.hp = char.maxHp; char.mana = char.maxMana; char.zeal = char.maxZeal; char.statuses = {}; logConsole('Health, mana, Zeal, and statuses restored.'); }
    else if (command === 'light') { char.statuses.lightUntil = Date.now() + 600000; char.statuses.lightRadius = 14; logConsole('Developer light enabled for 10 minutes.'); }
    else if (command === 'complete') { const quest = questOf(args[0]); if (!quest) throw new Error(`Unknown quest: ${args[0]}`); const state = char.quests[quest.id]; state.status = 'ready'; for (const objective of quest.objectives) state.progress[objective.id] = objective.amount; completeQuest(quest.id); }
    else if (command === 'killall') { for (const monster of runtime.monsters.filter(monster => monster.alive && monster.z === char.z)) killMonster(monster); logConsole('All creatures on the current floor defeated.'); }
    else if (command === 'export') exportGameJson();
    else if (command === 'list') { const rows = args[0] === 'items' ? DATA.items : args[0] === 'quests' ? DATA.quests : DATA.monsters; logConsole(rows.map(row => `${row.id}: ${row.name}`).join('\n')); }
    else if (command === 'reset-character') { const template = deepClone(DATA.characters.find(entry => entry.id === char.id)); Object.assign(char, template); resetRuntimeWorld(); logConsole(`${char.name} reset to showcase defaults.`); }
    else throw new Error(`Unknown command: ${command}. Try “help”.`);
    renderAllUi(); saveGame(false);
  } catch (error) { logConsole(error.message, 'error'); }
}

function openPanel(panel) {
  if (!runtime.character && panel !== 'help') return;
  if (panel === 'journal') openJournal();
  else if (panel === 'skills') openSkills();
  else if (panel === 'world') openWorldMap();
  else if (panel === 'character') openCharacterDetails();
  else openHelp();
}

function openJournal() {
  const char = runtime.character;
  const rows = DATA.quests.map(quest => {
    const state = char.quests[quest.id]; const unmet = (quest.prerequisite || []).some(required => char.quests[required]?.status !== 'complete') || !socialRequirementsMet(quest,char);
    const progress = quest.objectives.reduce((sum, objective) => sum + Math.min(Number(state.progress[objective.id] || 0), objective.amount), 0);
    const total = quest.objectives.reduce((sum, objective) => sum + objective.amount, 0);
    const button = state.status === 'available' ? `<button data-journal-accept="${quest.id}" ${unmet ? 'disabled' : ''}>${unmet ? 'LOCKED' : 'ACCEPT'}</button>` : state.status === 'complete' ? '<button disabled>COMPLETE</button>' : `<button data-journal-track="${quest.id}">${runtime.trackedQuestId === quest.id ? 'TRACKED' : 'TRACK'}</button>`;
    return `<article class="quest-card ${state.status}"><b>${quest.id}<br>LV ${quest.recommendedLevel}</b><div><h3>${escapeHtml(quest.name)}</h3><p>${escapeHtml(quest.description)} · ${progress}/${total} objective progress · ${quest.solo ? 'Solo friendly' : 'Group'}</p></div>${button}</article>`;
  }).join('');
  openModal(`${DATA.quests.length} COMPLETABLE QUESTS`, 'Emberwake World Journal', `<div class="quest-list">${rows}</div>`, 'wide');
  document.querySelectorAll('[data-journal-accept]').forEach(button => button.addEventListener('click', () => acceptQuest(button.dataset.journalAccept)));
  document.querySelectorAll('[data-journal-track]').forEach(button => button.addEventListener('click', () => { runtime.trackedQuestId = button.dataset.journalTrack; renderQuestTracker(); closeModal(); }));
}

function openSkills() {
  const char = runtime.character; const families = [...new Set(DATA.skills.map(skill => skill.family))];
  const html = families.map(family => `<section class="skill-section"><h3>${escapeHtml(family)}</h3><div class="skills-grid">${DATA.skills.filter(skill => skill.family === family).map(skill => {
    const state = char.skills[skill.id] || { level: 1, xp: 0, next: 100 }; const percent = clamp(state.xp / state.next * 100, 0, 100);
    const magicDetail = skill.id === 'magic' ? ` · ${magicPowerOf(char).toFixed(1)} magic power · next level costs ${number(state.next)} XP · ${vocationOf(char)?.magicPowerPerMagicLevel || 0} power/magic level · ${vocationOf(char)?.magicPowerPerCharacterLevel || 0} power/character level` : '';
    return `<article class="skill-row" data-tooltip="${escapeHtml(`${skill.tooltip || skill.description || skill.name}\nLevel ${state.level} · ${number(state.xp)} / ${number(state.next)} XP${magicDetail}`)}"><div><strong>${escapeHtml(skill.name)}</strong><b>${state.level}</b></div><i><b style="width:${percent}%;background:${skill.color}"></b></i>${skill.id === 'magic' ? `<small>${magicPowerOf(char).toFixed(1)} POWER · ${number(state.next)} NEXT XP</small>` : ''}</article>`;
  }).join('')}</div></section>`).join('');
  openModal('ALL COMBAT + ADVENTURING SKILLS', `${char.name}’s Skills`, `<div class="skill-sections">${html}</div>`, 'wide');
}

function openWorldMap() {
  const char = runtime.character;
  const sx = value => value * 5;
  const sy = value => value * 4.68;
  const townMarkers = towns.map(town => `<g transform="translate(${sx(town.x)} ${sy(town.y)})"><circle r="11" fill="#e6c36c" stroke="#fff1b8" stroke-width="3"/><text y="-17">${escapeHtml(town.name.toUpperCase())}</text></g>`).join('');
  const oldMarkers = [['ANCHORAGE', 18, 46], ['GRIMFANG CASTLE', 39, 16], ['IRON CANOPY', 42, 45], ['CRUCIBLE', 64, 45], ['SUNSCOUR', 80, 17]].map(([name, x, y]) => `<g transform="translate(${sx(x)} ${sy(y)})"><circle r="9" fill="#e6c36c"/><text y="-15">${name}</text></g>`).join('');
  openModal('49,152-TILE WORLD & ROUTES', 'The Great Emberwake Mainland', `<div class="world-map"><svg viewBox="0 0 1280 900" role="img" aria-label="Map of the expanded Emberwake world"><defs><filter id="shadow"><feDropShadow dx="0" dy="5" stdDeviation="6" flood-opacity=".55"/></filter></defs><rect width="1280" height="900" fill="#153d4d"/><rect x="25" y="14" width="440" height="130" rx="18" fill="#6b7b4d" stroke="#a7b875" stroke-width="4"/><ellipse cx="90" cy="215" rx="65" ry="47" fill="#4d764b"/><ellipse cx="210" cy="211" rx="55" ry="47" fill="#386440"/><ellipse cx="320" cy="211" rx="55" ry="43" fill="#705b40"/><ellipse cx="775" cy="487" rx="515" ry="384" fill="#62784b" stroke="#a1b777" stroke-width="5" filter="url(#shadow)"/><ellipse cx="1025" cy="248" rx="235" ry="210" fill="#b8d2d2"/><ellipse cx="875" cy="487" rx="180" ry="125" fill="#955d3e"/><ellipse cx="475" cy="610" rx="120" ry="105" fill="#52697a"/><ellipse cx="260" cy="637" rx="155" ry="112" fill="#39765c"/><ellipse cx="1095" cy="716" rx="215" ry="180" fill="#392d4c"/><path d="M675 250 C710 345 640 440 690 545 S635 715 690 800" fill="none" stroke="#29677c" stroke-width="19"/><g fill="none" stroke="#b39a68" stroke-width="13" stroke-linecap="round" opacity=".9"><path d="M340 211 L480 267 L870 487 L1100 720"/><path d="M480 267 L835 230 L1055 164"/><path d="M475 610 L870 487 L1095 716"/><path d="M260 637 L475 610"/></g><g fill="#f7e5ae" font-family="Cinzel" font-size="16" font-weight="700" text-anchor="middle">${oldMarkers}${townMarkers}</g><circle cx="${sx(char.x)}" cy="${sy(char.y)}" r="12" fill="#fff" stroke="#e0aa42" stroke-width="5"/><circle cx="${sx(char.x)}" cy="${sy(char.y)}" r="22" fill="none" stroke="#fff" stroke-width="2" opacity=".6"/></svg><div class="map-legend"><span>● You are here</span><span>Gold: towns and services</span><span>Pale north-east: Frostmarch</span><span>Purple south-east: Nightglass endgame</span><span>Major roads bridge the Silverriver and connect every city</span></div></div>`, 'wide');
}

function openCharacterDetails() {
  const char=runtime.character,vocation=vocationOf(char),magic=char.skills?.magic||{level:1,xp:0,next:100};const gear=EQUIP_SLOTS.map(slot=>{const item=itemOf(char.equipment[slot]),progress=item?itemProgressFor(item.id,char):null;return `<li>${slot}: ${item?`${item.icon} ${escapeHtml(item.name)} — item level ${progress.level}, gear score ${itemGearScore(item.id,char)}`:'empty'}</li>`;}).join('');const groups=[...new Set(DATA.skills.map(skill=>skill.family))],skills=groups.map(group=>`<section><h3>${escapeHtml(group)}</h3><p>${DATA.skills.filter(skill=>skill.family===group).map(skill=>`${escapeHtml(skill.name)} ${char.skills?.[skill.id]?.level||1}`).join(' · ')}</p></section>`).join('');openModal('CHARACTER SHEET',char.name,`<div class="modal-grid"><article class="info-card"><h2>YOUR ${escapeHtml(vocation.name).toUpperCase()}</h2><p>${escapeHtml(vocation.description)}</p><ul><li>Character Level ${char.level} · ${Math.floor(char.xp)}/${char.xpNext} XP</li><li>Magic Level ${magic.level} · ${Math.floor(magic.xp)}/${magic.next}</li><li>HP ${char.hp.toFixed(1)}/${char.maxHp}</li><li>MP ${char.mana.toFixed(1)}/${char.maxMana}</li><li>Luck ${char.skills?.luck?.level||1}</li><li>Carry ${Math.round(inventoryWeight(char))}/${char.capMax} oz</li><li>Gear score ${totalGearScore(char)}</li></ul><button id="openPersonalityPanel">PERSONALITY & ASPIRATIONS</button></article><article class="info-card"><h3>Equipment progression</h3><ul>${gear}</ul><div class="skill-family-list">${skills}</div></article></div>`);document.getElementById('openPersonalityPanel')?.addEventListener('click',openPersonalityPanel);
}
function openResourceDetails(resource){const char=runtime.character,vocation=vocationOf(char)||{},magic=char.skills?.magic||{level:1,xp:0,next:100};const rows={health:[`Current ${char.hp.toFixed(2)} / ${char.maxHp}`,`Passive regeneration ${classRegen('health',char).toFixed(3)} HP/second`,`Per level +${vocation.hpGain||0} maximum HP`],mana:[`Current ${char.mana.toFixed(2)} / ${char.maxMana}`,`Passive regeneration ${classRegen('mana',char).toFixed(3)} mana/second`,`Per level +${vocation.manaGain||0} maximum mana`],zeal:[`Current ${char.zeal||0}`,`Maximum ${char.maxZeal||5}`,'Zeal is a simple combat charge number. Warhealer attacks build it and certain abilities spend it.'],happiness:[`Current ${Number(char.happiness??50).toFixed(1)} / 100`,`Faction ${byId(DATA.factions,char.factionId)?.name||char.factionId}`,...(char.happinessHistory||[]).slice(0,8).map(event=>`${event.amount>0?'+':''}${event.amount} · ${event.contextId} · ${event.reason}`)],progression:[`Character level ${char.level}: ${Math.floor(char.xp)} / ${char.xpNext} XP`,`Magic Level ${magic.level}: ${Math.floor(magic.xp)} / ${magic.next} training XP`,`Magic power ${magicPowerOf(char).toFixed(2)}`]}[resource]||[];const category=resource==='progression'?'skills':resource==='happiness'?'happinessContexts':'vocations';openModal('TRACKED CHARACTER RESOURCE',resource.toUpperCase(),`<article class="info-card"><h3>${escapeHtml(vocation.name||'Character')} ${escapeHtml(resource)}</h3><ul>${rows.map(row=>`<li>${escapeHtml(row)}</li>`).join('')}</ul><p>This live value is calculated from editable definitions and persisted character history.</p>${canOpenDeveloper()?`<button id="openResourceDefinition">OPEN ${resource==='happiness'?'HAPPINESS':category==='skills'?'SKILL':'CLASS'} DEFINITIONS</button>`:''}</article>`);document.getElementById('openResourceDefinition')?.addEventListener('click',()=>{closeModal();runtime.activeDevTab=resource==='happiness'?'socialStudio':'classStudio';runtime.devStudioCategory=category;openDeveloper(runtime.activeDevTab);});}

function openItemUpgrade(itemId){const char=runtime.character,item=itemOf(itemId);if(!char||!item)return;const progress=itemProgressFor(itemId,char),curve=gearCurveFor(item),needed=itemXpNeeded(itemId,progress.level,char),goldCost=Math.round(Number(curve.paidUpgradeGoldBase||100)*Math.pow(progress.level,Number(curve.paidUpgradeGoldExponent||1.2))),budgetCost=Math.max(1,Number(curve.gearScorePerLevel||1));openModal('EQUIPPED ITEM PROGRESSION',item.name,`<div class="modal-grid"><article class="info-card"><h3>Item level ${progress.level}</h3><p>${Math.floor(progress.xp)} / ${needed} natural-use XP · ${progress.uses||0} training events</p><ul><li>Weapon uses: ${number(progress.weaponUses)}</li><li>Hits taken while equipped: ${number(progress.hitsTakenWhileEquipped)}</li><li>Damage received while equipped: ${number(progress.damageTakenWhileEquipped)}</li><li>Spell casts while equipped: ${number(progress.spellCastsWhileEquipped)}</li><li>Gear score ${itemGearScore(itemId,char)}</li><li>Curve ${escapeHtml(curve.name)}</li><li>Stat gain ${(Number(curve.statGainPerLevel||0)*100).toFixed(1)}% per level</li><li>Maximum ${Math.min(item.maximumItemLevel||100,curve.maxLevel||100)}</li></ul></article><article class="info-card"><h3>Paid improvement</h3><p>Natural leveling continues automatically. Payment immediately buys one additional item level.</p><button id="upgradeItemGold" ${char.gold<goldCost?'disabled':''}>PAY ${number(goldCost)} GOLD</button>${char.gearScoreBudget?` <button id="upgradeItemBudget" ${char.gearScoreBudget<budgetCost?'disabled':''}>SPEND ${budgetCost} GS BUDGET</button><p>${number(char.gearScoreBudget)} gear-score budget remains.</p>`:''}</article></div>`);const upgrade=currency=>{const cap=Math.min(Number(item.maximumItemLevel||100),Number(curve.maxLevel||100));if(progress.level>=cap){toast('This item is already at its authored maximum.',true);return;}if(currency==='gold'){if(char.gold<goldCost)return;char.gold-=goldCost;}else{if(Number(char.gearScoreBudget||0)<budgetCost)return;char.gearScoreBudget-=budgetCost;}progress.level+=1;progress.paidUpgrades+=1;saveGame(false);renderAllUi();openItemUpgrade(itemId);};document.getElementById('upgradeItemGold')?.addEventListener('click',()=>upgrade('gold'));document.getElementById('upgradeItemBudget')?.addEventListener('click',()=>upgrade('budget'));}

function openPersonalityPanel(){const char=runtime.character;if(!char)return;const personality=DATA.personalities.find(row=>row.ownerType==='character'&&row.ownerId===char.id)||DATA.personalities[0],archetype=byId(DATA.archetypes,personality?.archetypeId);const stats=DATA.socialStats.map(stat=>`<div class="social-stat"><span>${escapeHtml(stat.name)}</span><b>${socialValue(char,stat.id).toFixed(1)}</b><i><em style="width:${clamp((socialValue(char,stat.id)+100)/2,0,100)}%"></em></i></div>`).join('');const aspirations=(personality?.aspirationIds||[]).map(id=>byId(DATA.aspirations,id)).filter(Boolean).map(row=>`<article><h3>${escapeHtml(row.name)}</h3><p>${escapeHtml(row.description)}</p><small>${escapeHtml(row.category)} · target ${row.target}</small></article>`).join('');const fears=(personality?.fearIds||[]).map(id=>byId(DATA.fears,id)).filter(Boolean).map(row=>`${escapeHtml(row.name)} (${row.severity})`).join(', ');const preferences=(personality?.preferenceIds||[]).map(id=>byId(DATA.preferences,id)).filter(Boolean).map(row=>`${escapeHtml(row.name)} — ${escapeHtml(row.feeling)} ${row.value}`).join('<br>');openModal('PERSONALITY PANEL',char.name,`<div class="modal-grid personality-grid"><section class="info-card"><h3>${escapeHtml(archetype?.name||'Custom')} archetype</h3><p>Speech style: ${escapeHtml(personality?.speechStyle||'custom')} · values: ${escapeHtml((personality?.values||[]).join(', '))}</p>${stats}<h3>Fears</h3><p>${fears||'None assigned'}</p><h3>Preferences & feelings</h3><p>${preferences||'None assigned'}</p></section><section><h2>ASPIRATIONS</h2><div class="aspiration-list">${aspirations||'<p>No aspirations assigned.</p>'}</div></section></div>`,'wide');}

function openHelp() {
  openModal('PLAY GUIDE', 'How Emberwake Works', `<div class="modal-grid"><article class="info-card"><h3>Move & interact</h3><ul><li>WASD or arrow keys move one tile.</li><li>Click a world tile to path there.</li><li>Use the mouse wheel over the main game to zoom from 0.35× to 2.4×.</li><li>E first collects every loot pile in the surrounding 3×3 area, then interacts, trades, climbs, reads, or turns in quests.</li><li>Click the minimap to auto-walk there; use its −/+ controls or mouse wheel to zoom, and drag its lower-right corner to resize.</li><li>Space selects and attacks the nearest visible enemy. If a target or charge path already exists, Space releases it. In a submenu, Space closes the submenu.</li></ul></article><article class="info-card"><h3>Items like a classic tile RPG</h3><ul><li>Drag between backpack and equipment slots.</li><li>Drag inventory or equipment onto the world to drop it.</li><li>Shift-drag moves one item from a stack.</li><li>Drag an item onto a hole to send it down one floor.</li><li>Double-click bags to open them; bags can contain smaller bags and all contents count toward carry weight.</li><li>Double-click items to use them; double-click ground loot to pick it up.</li></ul></article><article class="info-card"><h3>Ropes, holes & pickaxes</h3><ul><li>Use a rope in the backpack, then click a nearby hole from above to pull up its top ground item.</li><li>Use a rope on an upward rope spot below to climb.</li><li>Use a pickaxe, then click an established hole to move down or up.</li><li>In an existing cave region, a pickaxe can open a paired shaft between floors.</li></ul></article><article class="info-card"><h3>Spells & cannon</h3><ul><li>Open the Spellbook item to assign learned spells to keys 1–8.</li><li>Torches and Kindlelight expand underground vision.</li><li>Siege Cannon Operators travel faster mounted, slow while powered, and must stop in Siege Mode to fire.</li><li>F2 opens the editable world spreadsheet, integration map, relationship builders and console.</li></ul></article></div>`, 'wide');
}

async function loadServerSession() {
  try {
    const requestedSession = SERVER_SESSION_PREEXISTED || runtime.server.sessionConfirmed ? getServerSessionId() : '';
    const response = await fetch(`./app.php?action=session&projectId=${encodeURIComponent(PROJECT_ID)}${requestedSession ? `&serverSessionId=${encodeURIComponent(requestedSession)}` : ''}`, { headers: { Accept: 'application/json', ...(requestedSession ? {'X-FSG-Server-Session':requestedSession}:{}) } }); const result = await response.json();
    if (!response.ok) throw new Error(result.message || 'Server session unavailable.');
    const context=result.serverSession||{}; if(context.sessionId) setServerSessionId(context.sessionId);
    runtime.server = { ...runtime.server, status: 'online', authenticated: Boolean(result.authenticated), user: result.user || null, authAvailable: Boolean(result.authAvailable), identity: result.identity || null, sessionId:context.sessionId||getServerSessionId(), sessionConfirmed:true, access:context.access||'guest', role:context.role||'player', adminID:context.adminID||0, capabilities:{...runtime.server.capabilities,...(context.capabilities||{})}, sessions:result.sessions||runtime.server.sessions||[] };
    updatePermissionVisibility();
    if (result.state?.characters?.length) {
      const localDate = runtime.save.world.lastSavedAt || ''; const remoteDate = result.updatedAt || '';
      if (remoteDate > localDate) { runtime.save = { ...runtime.save, ...result.state }; const scope=runtime.save.world?.sharedContext||{}; Object.assign(runtime.adminHierarchy,{godId:scope.godId||runtime.adminHierarchy.godId,realmId:scope.realmId||runtime.adminHierarchy.realmId,worldId:scope.worldId||runtime.adminHierarchy.worldId,villageId:scope.villageId||runtime.adminHierarchy.villageId,villagerClassId:scope.villagerClassId||runtime.adminHierarchy.villagerClassId}); toast('A newer MySQL save is available and was loaded.'); renderProfileCards(); }
    }
    if (result.catalog && typeof result.catalog === 'object') { for (const [key, rows] of Object.entries(result.catalog)) if (Array.isArray(rows) && key !== 'characters') DATA[key] = mergeRowsByStableId(DATA[key] || [], rows); normalizeEditableCatalog(); runtime.save.catalog = catalogSnapshot(); }
    if (runtime.server.access==='pending') toast('This server session is awaiting approval from its original admin.',true,8000);
    runtime.save.serverRevision = result.revision == null ? runtime.save.serverRevision : Number(result.revision);
  } catch { runtime.server.status = 'offline'; updatePermissionVisibility(); }
}

function openAccount() {
  const server = runtime.server;
  if (server.authenticated) {
    openModal('SERVER ACCOUNT', server.user?.username || 'Signed in', `<div class="info-card"><h3>Authenticated persistence</h3><p>Your shared suite account is connected. Player saves are private to this account; authored definitions are shared only inside the approved server session.</p><ul><li>${escapeHtml(server.user?.email || 'Email protected')}</li><li>Session: ${escapeHtml(server.sessionId||getServerSessionId())}</li><li>Role: ${escapeHtml(server.role||'player')} · ${escapeHtml(server.access||'pending')}</li><li>Original adminID: ${server.adminID||'unassigned'}</li><li>Connection: ${server.status}</li></ul></div><button id="openAccountAdmin" class="secondary-button">OPEN ADMIN & SESSIONS</button><button id="logoutButton" class="secondary-button" style="margin-top:12px">LOG OUT</button>`);
    document.getElementById('openAccountAdmin')?.addEventListener('click', () => { closeModal(); openDeveloper('adminPanel'); });
    document.getElementById('logoutButton')?.addEventListener('click', () => authRequest('logout', {})); return;
  }
  openModal('SERVER ACCOUNT', 'Sign in or create an account', `<div class="auth-tabs"><button class="active" data-auth-mode="login">SIGN IN</button><button data-auth-mode="register">REGISTER</button></div><form id="authForm" class="auth-form"><input type="hidden" name="mode" value="login"><label id="identifierLabel">USERNAME OR EMAIL<input name="identifier" required autocomplete="username"></label><label id="usernameLabel" class="hidden">USERNAME<input name="username" autocomplete="username"></label><label id="emailLabel" class="hidden">EMAIL<input name="email" type="email" autocomplete="email"></label><label>PASSWORD<input name="password" type="password" required autocomplete="current-password"></label><label id="confirmLabel" class="hidden">CONFIRM PASSWORD<input name="passwordConfirm" type="password" autocomplete="new-password"></label><label id="consentLabel" class="hidden" style="grid-template-columns:auto 1fr;align-items:center"><input name="over18" type="checkbox" value="1" style="min-height:auto;width:16px">I am 18+ and agree to the Terms of Service and Privacy Policy.<input name="terms" type="hidden" value="1"><input name="privacy" type="hidden" value="1"></label><button class="primary-button">CONTINUE</button></form><div class="info-card" style="margin-top:12px"><p>${server.authAvailable === false ? 'The shared auth package is not installed on this host yet. Local play and JSON export still work.' : 'Credentials are handled only by the private shared-auth backend and never stored in this JavaScript bundle.'}</p></div>`);
  document.querySelectorAll('[data-auth-mode]').forEach(button => button.addEventListener('click', () => {
    document.querySelectorAll('[data-auth-mode]').forEach(candidate => candidate.classList.toggle('active', candidate === button));
    const register = button.dataset.authMode === 'register'; const form = document.getElementById('authForm'); form.elements.mode.value = button.dataset.authMode;
    document.getElementById('usernameLabel').classList.toggle('hidden', !register); document.getElementById('emailLabel').classList.toggle('hidden', !register); document.getElementById('identifierLabel').classList.toggle('hidden', register); document.getElementById('confirmLabel').classList.toggle('hidden', !register); document.getElementById('consentLabel').classList.toggle('hidden', !register);
    form.elements.identifier.required = !register; form.elements.username.required = register; form.elements.email.required = register; form.elements.passwordConfirm.required = register; form.elements.over18.required = register; form.elements.password.autocomplete = register ? 'new-password' : 'current-password';
  }));
  document.getElementById('authForm')?.addEventListener('submit', event => { event.preventDefault(); const body = Object.fromEntries(new FormData(event.currentTarget)); const action = body.mode; delete body.mode; authRequest(action, body); });
}

async function authRequest(action, body) {
  try {
    body={...body,projectId:PROJECT_ID,serverSessionId:getServerSessionId()};
    const response = await fetch(`./app.php?action=${action}`, { method: 'POST', headers: { 'Content-Type': 'application/json','X-FSG-Server-Session':getServerSessionId() }, body: JSON.stringify(body) }); const result = await response.json();
    if (!response.ok || result.status === 'error' || result.ok === false) throw new Error(result.message || result.error || 'Authentication failed.');
    runtime.server.authenticated = action !== 'logout'; runtime.server.user = result.user || null; closeModal(); toast(result.message || (action === 'logout' ? 'Logged out.' : 'Account connected.')); await loadServerSession();
  } catch (error) { toast(error.message, true); }
}

function cycleTrackedQuest() {
  const char = runtime.character; const active = Object.keys(char.quests).filter(id => ['active', 'ready'].includes(char.quests[id].status));
  if (!active.length) return; const index = active.indexOf(runtime.trackedQuestId); runtime.trackedQuestId = active[(index + 1) % active.length]; renderQuestTracker();
}

function dropSelectedInventory() {
  const char = runtime.character; const index = runtime.selectedInventoryIndex; const stack = char?.inventory?.[index]; if (!stack) return;
  addGroundStack(stack.id, stack.qty, char.x, char.y, char.z); char.inventory.splice(index, 1); runtime.selectedInventoryIndex = -1; refreshCollectObjectives(stack.id); renderAllUi(); saveGame(false); toast(`${itemOf(stack.id)?.name} dropped at your feet.`);
}

function toggleQuickLight() {
  const char = runtime.character; const lanternIndex = char.inventory.findIndex(stack => stack.id === 'lantern'); const torchIndex = char.inventory.findIndex(stack => stack.id === 'torch');
  if (lanternIndex >= 0) useInventoryItem(lanternIndex); else if (torchIndex >= 0) useInventoryItem(torchIndex); else castSpell('light_orb');
}

function toggleMount() {
  const char = runtime.character; if (!char.mountId) { toast('This character has no mount equipped.', true); return; }
  if (char.flags.siegeMode) { toast('Raise the siege stabilizers before mounting.', true); return; }
  char.mounted = !char.mounted; toast(char.mounted ? `Mounted ${byId(DATA.mounts, char.mountId)?.name}.` : 'Dismounted.'); renderHud(); saveGame(false);
}

function toggleSneak() {
  const char = runtime.character; if (!char || char.flags.unconscious) return;
  if (char.mounted || char.flags.siegeMode) { toast('Dismount and raise siege stabilizers before sneaking.', true); return; }
  char.flags.sneaking = !char.flags.sneaking; runtime.path = [];
  toast(char.flags.sneaking ? 'Sneaking: detection radius reduced. Darkness and Stealth skill improve concealment.' : 'Sneaking ended.');
  renderHud(); saveGame(false);
}

function bindEvents() {
  bindUniversalTooltips();
  const gameLayout = document.querySelector('.game-layout');
  const setLeftRailHidden = hidden => {
    gameLayout?.classList.toggle('left-hidden', Boolean(hidden));
    if (el.leftRailToggle) {
      el.leftRailToggle.textContent = hidden ? '›' : '‹';
      el.leftRailToggle.title = hidden ? 'Show left sidebar' : 'Hide left sidebar';
      el.leftRailToggle.setAttribute('aria-label', el.leftRailToggle.title);
      el.leftRailToggle.setAttribute('aria-expanded', String(!hidden));
    }
  };
  setLeftRailHidden(Boolean(runtime.save.settings.leftRailHidden));
  el.leftRailToggle?.addEventListener('click', () => {
    runtime.save.settings.leftRailHidden = !gameLayout?.classList.contains('left-hidden');
    setLeftRailHidden(runtime.save.settings.leftRailHidden);
    saveGame(false);
    resizeCanvases();
  });
  document.addEventListener('click', event => { if (event.target.closest?.('button')) playSfx('ui'); }, true);
  el.continueButton.addEventListener('click', () => runtime.selectedProfileId && selectCharacter(runtime.selectedProfileId));
  el.profileButton.addEventListener('click', () => { saveGame(false); runtime.selectedProfileId = runtime.character?.id || runtime.save.lastCharacterId || null; renderProfileCards(); el.continueButton.disabled = !runtime.selectedProfileId; el.profileScreen.classList.remove('hidden'); });
  document.querySelectorAll('[data-panel]').forEach(button => button.addEventListener('click', () => openPanel(button.dataset.panel)));
  document.querySelectorAll('[data-collapse-panel]').forEach(header=>header.addEventListener('click',event=>{if(event.target.closest('button'))return;const panel=header.closest('.panel');panel.classList.toggle('collapsed');runtime.save.settings.collapsedPanels=runtime.save.settings.collapsedPanels||{};runtime.save.settings.collapsedPanels[header.dataset.collapsePanel]=panel.classList.contains('collapsed');saveGame(false);}));
  document.querySelectorAll('[data-collapse-panel]').forEach(header=>header.closest('.panel')?.classList.toggle('collapsed',Boolean(runtime.save.settings.collapsedPanels?.[header.dataset.collapsePanel])));
  document.querySelectorAll('[data-resource-detail]').forEach(button=>button.addEventListener('click',()=>openResourceDetails(button.dataset.resourceDetail)));
  document.getElementById('devButton').addEventListener('click', () => openDeveloper());
  document.getElementById('accountButton').addEventListener('click', openAccount);
  document.getElementById('devClose').addEventListener('click', closeDeveloper);
  el.devBackButton?.addEventListener('click', () => { runtime.activeDevTab = 'authoringHome'; runtime.devStudioCategory = null; runtime.devSearch = ''; el.devSearch.value = ''; renderDevTabs(); renderDevContent(); });
  const toggleConsole = () => { const panel = el.devConsoleHeader?.closest('.dev-console'); if (!panel) return; const collapsed = panel.classList.toggle('collapsed'); el.devConsoleHeader.setAttribute('aria-expanded', String(!collapsed)); };
  el.devConsoleHeader?.addEventListener('click', toggleConsole);
  el.devConsoleHeader?.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); toggleConsole(); } });
  document.getElementById('devExport').addEventListener('click', exportGameJson);
  document.getElementById('devMapEditor').addEventListener('click', () => { runtime.activeDevTab = 'levelEditor'; runtime.devSearch = ''; el.devSearch.value = ''; renderDevTabs(); renderDevContent(); });
  document.getElementById('devSceneEditor')?.addEventListener('click',openSceneManager);
  document.getElementById('devMonsterSpawner').addEventListener('click', openAdminMonsterSpawner);
  document.getElementById('devAdminPanel').addEventListener('click', () => { runtime.activeDevTab = 'adminPanel'; runtime.devSearch = ''; el.devSearch.value = ''; renderDevTabs(); renderDevContent(); });
  document.getElementById('adminCreateStarter')?.addEventListener('click',()=>{const vocationId=document.getElementById('adminStarterClass').value;createAdminStarter(vocationId);const created=runtime.save.characters.at(-1);if(created?.adminStarterFor===vocationId){created.scenario=vocationId==='vagabond'?'A New Vagabond':'A New Journey';created.scenarioText=`A fresh ${byId(DATA.vocations,vocationId)?.name||'character'} ready for an unassigned branching progression path.`;created.skills=created.skills||{};if(vocationId==='vagabond')created.skills.luck={level:75,xp:0,next:9000};created.tags=(created.tags||[]).filter(tag=>tag!=='admin_test');created.tags.push('custom_character');saveGame(false);renderProfileCards();}});
  document.getElementById('devImport').addEventListener('click', () => el.jsonFileInput.click());
  document.getElementById('devSync').addEventListener('click', () => syncServer(false));
  el.jsonFileInput.addEventListener('change', () => el.jsonFileInput.files[0] && importGameJson(el.jsonFileInput.files[0]));
  el.devSearch.addEventListener('input', event => { runtime.devSearch = event.target.value; renderDevContent(); });
  el.devAddRow.addEventListener('click', addDevRow);
  const guardAuthoring = event => {
    if (canAuthorData() || !developerSectionIsMutable()) return;
    const navigation = event.target.closest?.('[data-studio-category],[data-studio-record],[data-schema-category],[data-open-category],[data-open-dev],[data-open-system],[data-open-vault-registry]');
    if (navigation) return;
    if (event.type === 'click' || event.target.matches?.('input,select,textarea,button,canvas')) { event.preventDefault(); event.stopImmediatePropagation(); toast('Authoring is read-only for this account. A Guild Master, Game Master, Admin, or Server Owner role is required.', true, 5000); }
  };
  ['click','change','input','submit','drop'].forEach(type=>el.devContent.addEventListener(type,guardAuthoring,true));
  el.consoleForm.addEventListener('submit', event => { event.preventDefault(); const raw = el.consoleInput.value; el.consoleInput.value = ''; runConsoleCommand(raw); });
  el.worldCanvas.addEventListener('click', handleWorldClick);
  el.worldCanvas.addEventListener('contextmenu',handleWorldContextMenu);
  el.worldCanvas.addEventListener('pointermove', handleWorldTooltip);
  el.worldCanvas.addEventListener('pointerleave', () => hideGameTooltip(el.worldCanvas));
  el.worldCanvas.addEventListener('wheel', event => {
    event.preventDefault();
    const rules = gameRule('world_rules'); runtime.cameraZoom = clamp(Math.round((runtime.cameraZoom * (event.deltaY < 0 ? 1.1 : 1 / 1.1)) * 20) / 20, Number(rules.cameraZoomMinimum ?? .35), Number(rules.cameraZoomMaximum ?? 2.4));
    toast(`World camera ${runtime.cameraZoom.toFixed(2).replace(/0$/, '')}×.`);
  }, { passive: false });
  el.worldCanvas.addEventListener('dragover', event => event.preventDefault());
  el.worldCanvas.addEventListener('drop', handleWorldDrop);
  el.minimap.addEventListener('click', handleMinimapClick);
  el.minimap.addEventListener('pointermove', handleMinimapTooltip);
  el.minimap.addEventListener('pointerleave', () => hideGameTooltip(el.minimap));
  el.minimap.addEventListener('wheel', event => { event.preventDefault(); setMinimapZoom(runtime.minimapZoom * (event.deltaY < 0 ? 1.3 : 1 / 1.3)); }, { passive: false });
  el.minimapZoomOut.addEventListener('click', () => setMinimapZoom(runtime.minimapZoom / 1.3));
  el.minimapZoomIn.addEventListener('click', () => setMinimapZoom(runtime.minimapZoom * 1.3));
  el.minimapReset.addEventListener('click', () => setMinimapZoom(1));
  if ('ResizeObserver' in window) new ResizeObserver(() => { runtime.minimapBase = null; runtime.minimapFloor = null; }).observe(el.minimap);
  document.getElementById('useSelected').addEventListener('click', () => runtime.selectedInventoryIndex >= 0 && useInventoryItem(runtime.selectedInventoryIndex));
  document.getElementById('dropSelected').addEventListener('click', dropSelectedInventory);
  document.getElementById('clearTarget').addEventListener('click', () => { runtime.targetId = null; renderTarget(); });
  document.getElementById('cycleQuest').addEventListener('click', cycleTrackedQuest);
  el.combatMode.addEventListener('click', () => { runtime.combatStance = runtime.combatStance === 'balanced' ? 'aggressive' : runtime.combatStance === 'aggressive' ? 'defensive' : 'balanced'; renderHud(); toast(`${runtime.combatStance} combat stance.`); });
  el.torchButton.addEventListener('click', toggleQuickLight); el.mountButton.addEventListener('click', toggleMount);
  window.addEventListener('keydown', event => {
    const tag = event.target.tagName; if (['INPUT', 'TEXTAREA', 'SELECT'].includes(tag)) return;
    const key = event.key.toLowerCase();
    const movementKeys = ['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'];
    if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' ', '1', '2', '3', '4', '5', '6', '7', '8'].includes(key)) event.preventDefault();
    const harborButton = document.getElementById('returnHarborButton');
    if (key === ' ' && harborButton) { event.preventDefault(); harborButton.click(); return; }
    if (key === ' ') {
      event.preventDefault();
      if (!el.devOverlay.classList.contains('hidden')) { closeDeveloper(); return; }
      if (runtime.modalOpen) { closeModal(); return; }
      if (!el.profileScreen.classList.contains('hidden') && runtime.character) { el.profileScreen.classList.add('hidden'); el.worldCanvas.focus(); return; }
      if (runtime.targetId || runtime.path.length) { runtime.targetId = null; runtime.path = []; renderTarget(); toast('Focus and charge path released.'); return; }
      attackNearestVisibleEnemy(); return;
    }
    if (runtime.character?.flags.unconscious && movementKeys.includes(key)) { event.preventDefault(); wakeFromUnconscious(); return; }
    if (key === 'escape') { if (!el.devOverlay.classList.contains('hidden')) closeDeveloper(); else if (runtime.modalOpen) closeModal(); }
    else if (key === 'f2' || key === '`') { event.preventDefault(); if(!canOpenDeveloper())return;el.devOverlay.classList.contains('hidden') ? openDeveloper() : closeDeveloper(); }
    else if (key === 'e') interact();
    else if (key === 'c') toggleSneak();
    else if (/^[1-8]$/.test(key)) { const spellId = runtime.character?.spells?.[Number(key) - 1]; if (spellId) castSpell(spellId); }
    else if (key === 'j') openJournal(); else if (key === 'k') openSkills(); else if (key === 'm') openWorldMap(); else if (key === '?') openHelp();
    if (movementKeys.includes(key)) runtime.keys.add(key);
  });
  window.addEventListener('keyup', event => runtime.keys.delete(event.key.toLowerCase()));
  window.addEventListener('blur', () => runtime.keys.clear());
  window.addEventListener('resize', resizeCanvases);
  window.addEventListener('beforeunload', () => saveGame(false));
}

function initialize() {
  bindEvents(); renderProfileCards();
  updatePermissionVisibility();
  runtime.selectedProfileId = runtime.save.lastCharacterId || null;
  el.continueButton.disabled = !runtime.selectedProfileId;
  if (runtime.selectedProfileId) renderProfileCards();
  if (location.protocol === 'file:') runtime.server.status = 'local';
  else loadServerSession();
  requestAnimationFrame(gameLoop);
}

initialize();




