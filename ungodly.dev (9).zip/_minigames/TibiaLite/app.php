<?php
declare(strict_types=1);

/*
 * Emberwake API
 *
 * All five deliverable files may live in one web directory. Shared authentication
 * remains in the server's external _private directory and is never served publicly.
 * All game tables are defined in schema.sql and use FSG_TIBIALIKE_.
 */

const FSG_TIBIALIKE_PROJECT = 'emberwake-dawnreach';
const FSG_TIBIALIKE_VERSION = '1.9.0';
const FSG_TIBIALIKE_MAX_BODY = 16_777_216;
const FSG_TIBIALIKE_GUEST_COOKIE = 'FSG_TIBIALIKE_GUEST';

final class GameRevisionConflict extends RuntimeException
{
    public function __construct(public readonly int $currentRevision)
    {
        parent::__construct('This save changed on another client. Load the current revision before saving again.');
    }
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header("Content-Security-Policy: default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; script-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'self'");

$authAvailable = false;
foreach ([
    dirname(__DIR__) . '/_private/AuthShared.php',
    dirname(__DIR__, 2) . '/_private/AuthShared.php',
    __DIR__ . '/_private/AuthShared.php',
] as $authFile) {
    if (is_file($authFile)) {
        require_once $authFile;
        $authAvailable = function_exists('fsgAuth_dbConnection');
        break;
    }
}

function gameJson(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function gameText(mixed $value, int $limit = 255): string
{
    $text = trim((string)$value);
    return function_exists('mb_substr') ? mb_substr($text, 0, $limit, 'UTF-8') : substr($text, 0, $limit);
}

function gameBody(): array
{
    $raw = file_get_contents('php://input');
    if (!is_string($raw) || $raw === '') return [];
    if (strlen($raw) > FSG_TIBIALIKE_MAX_BODY) gameJson(['status' => 'error', 'message' => 'Request is too large.'], 413);
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) gameJson(['status' => 'error', 'message' => 'Invalid JSON request.'], 400);
    return $decoded;
}

function gameEncode(mixed $value): string
{
    $json = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) throw new RuntimeException('A game value could not be encoded.');
    return $json;
}

function gameDatabase(): PDO
{
    if (function_exists('fsgAuth_dbConnection')) return fsgAuth_dbConnection();
    $dsn = trim((string)(getenv('FSG_DB_DSN') ?: ''));
    $user = (string)(getenv('FSG_DB_USER') ?: '');
    $pass = (string)(getenv('FSG_DB_PASS') ?: '');
    if ($dsn === '') {
        $host = trim((string)(getenv('FSG_DB_HOST') ?: '127.0.0.1'));
        $port = trim((string)(getenv('FSG_DB_PORT') ?: '3306'));
        $name = trim((string)(getenv('FSG_DB_NAME') ?: ''));
        if ($name === '' || $user === '') throw new RuntimeException('Database credentials are not configured.');
        $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
    }
    return new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function gameSchemaInstalled(PDO $pdo): bool
{
    $statement = $pdo->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'FSG_TIBIALIKE_PlayerSaves'");
    $statement->execute();
    return (int)$statement->fetchColumn() > 0;
}

function gameInstallSchema(PDO $pdo): void
{
    $path = is_file(__DIR__ . '/schema.sql') ? __DIR__ . '/schema.sql' : dirname(__DIR__) . '/schema.sql';
    $sql = file_get_contents($path);
    if (!is_string($sql) || $sql === '') throw new RuntimeException('schema.sql is missing.');
    $sql = preg_replace('/^\s*--.*$/m', '', $sql) ?? $sql;
    foreach (preg_split('/;\s*(?:\r?\n|$)/', $sql) ?: [] as $statement) {
        $statement = trim($statement);
        if ($statement === '' || preg_match('/^(DROP\s+TABLE|SET\s+FOREIGN_KEY_CHECKS)/i', $statement)) continue;
        $pdo->exec($statement);
    }
}

function gameGuestKey(): string
{
    $token = strtolower(trim((string)($_COOKIE[FSG_TIBIALIKE_GUEST_COOKIE] ?? '')));
    if (!preg_match('/^[a-f0-9]{48}$/', $token)) {
        $token = bin2hex(random_bytes(24));
        $secure = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') || strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
        setcookie(FSG_TIBIALIKE_GUEST_COOKIE, $token, [
            'expires' => time() + 31_536_000, 'path' => '/', 'secure' => $secure,
            'httponly' => true, 'samesite' => 'Lax',
        ]);
    }
    return 'guest:' . substr(hash('sha256', 'emberwake:' . $token), 0, 40);
}

/** @return array{ownerKey:string,authenticated:bool,user:?array} */
function gameIdentity(PDO $pdo): array
{
    if (function_exists('fsgAuth_currentUserIdFromRequest')) {
        $userId = fsgAuth_currentUserIdFromRequest($pdo);
        if ($userId > 0) {
            $user = function_exists('fsgAuth_getUserById') ? fsgAuth_getUserById($pdo, $userId) : ['id' => $userId];
            if ($user) return ['ownerKey' => 'user:' . $userId, 'authenticated' => true, 'user' => $user];
        }
    }
    return ['ownerKey' => gameGuestKey(), 'authenticated' => false, 'user' => null];
}

function gameSessionId(array $body = []): string
{
    $value = $body['serverSessionId'] ?? $body['sessionId'] ?? $_GET['serverSessionId'] ?? $_GET['sessionId'] ?? $_SERVER['HTTP_X_FSG_SERVER_SESSION'] ?? '';
    $value = gameText($value, 96);
    return preg_match('/^[A-Za-z0-9][A-Za-z0-9._:-]{5,95}$/', $value) ? $value : '';
}

function gameRoleCapabilities(string $role): array
{
    $author = in_array($role, ['guild_master', 'game_master', 'admin', 'server_owner'], true);
    return [
        'role' => $role, 'canPlay' => true, 'canAuthor' => $author,
        'canModerate' => in_array($role, ['moderator', 'guild_master', 'game_master', 'admin', 'server_owner'], true),
        'canManageGuild' => in_array($role, ['guild_master', 'game_master', 'admin', 'server_owner'], true),
        'canManageSessions' => in_array($role, ['admin', 'server_owner'], true),
        'canGrantModerator' => in_array($role, ['game_master', 'admin', 'server_owner'], true),
        'canGrantGameMaster' => in_array($role, ['admin', 'server_owner'], true),
    ];
}

function gameGenerateSessionId(PDO $pdo): string
{
    if (function_exists('fsgAuth_generateUniqueSessionId')) return gameText(fsgAuth_generateUniqueSessionId($pdo), 96);
    return 'EW-' . strtoupper(substr(bin2hex(random_bytes(12)), 0, 8)) . '-' . strtoupper(substr(bin2hex(random_bytes(12)), 8, 12));
}

function gameResolveSession(PDO $pdo, array $identity, string $projectId, string $requestedId, bool $create = true): array
{
    $userId = (int)($identity['user']['id'] ?? 0); $sessionId = $requestedId;
    if ($sessionId === '' && $userId > 0) {
        $recent = $pdo->prepare('SELECT m.session_id FROM FSG_TIBIALIKE_ServerSessionMembers m JOIN FSG_TIBIALIKE_ServerSessions s ON s.project_id=m.project_id AND s.session_id=m.session_id WHERE m.project_id=? AND m.user_id=? AND m.is_active=1 AND s.status="active" ORDER BY m.updated_at DESC LIMIT 1');
        $recent->execute([$projectId, $userId]); $sessionId = (string)($recent->fetchColumn() ?: '');
    }
    if ($sessionId === '') $sessionId = gameGenerateSessionId($pdo);
    $query = $pdo->prepare('SELECT * FROM FSG_TIBIALIKE_ServerSessions WHERE project_id=? AND session_id=? LIMIT 1'); $query->execute([$projectId, $sessionId]); $session = $query->fetch();
    if (!$session && $create) {
        $dataOwnerKey = 'session:' . substr(hash('sha256', $projectId . ':' . $sessionId), 0, 48); $adminId = $userId > 0 ? $userId : null;
        $insert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_ServerSessions (project_id,session_id,data_owner_key,admin_id,created_by_user_id,name,status,payload_json) VALUES (?,?,?,?,?,?,"active",?)');
        $insert->execute([$projectId,$sessionId,$dataOwnerKey,$adminId,$adminId,'Emberwake Session ' . $sessionId,gameEncode(['initialGeneratorUserId'=>$adminId])]);
        if ($userId > 0) $pdo->prepare('INSERT INTO FSG_TIBIALIKE_ServerSessionMembers (project_id,session_id,user_id,role,role_tags_json,granted_by_user_id,is_active) VALUES (?,?,?,"admin",?, ?,1)')->execute([$projectId,$sessionId,$userId,gameEncode(['initialGenerator']),$userId]);
        $query->execute([$projectId, $sessionId]); $session = $query->fetch();
    }
    if (!$session) return ['sessionId'=>$sessionId,'access'=>'missing','role'=>'player','capabilities'=>gameRoleCapabilities('player')];
    if ($userId > 0 && (int)($session['admin_id'] ?? 0) === 0) {
        $claim = $pdo->prepare('UPDATE FSG_TIBIALIKE_ServerSessions SET admin_id=?,created_by_user_id=COALESCE(created_by_user_id,?) WHERE project_id=? AND session_id=? AND admin_id IS NULL');
        $claim->execute([$userId,$userId,$projectId,$sessionId]);
        if ($claim->rowCount() > 0) {
            $pdo->prepare('INSERT INTO FSG_TIBIALIKE_ServerSessionMembers (project_id,session_id,user_id,role,role_tags_json,granted_by_user_id,is_active) VALUES (?,?,?,"admin",?,?,1) ON DUPLICATE KEY UPDATE role="admin",is_active=1,granted_by_user_id=VALUES(granted_by_user_id)')->execute([$projectId,$sessionId,$userId,gameEncode(['initialGenerator']),$userId]);
            $query->execute([$projectId, $sessionId]); $session = $query->fetch();
        }
    }
    $role = 'player'; $access = $userId === 0 ? 'guest' : 'pending';
    if ($userId > 0) {
        $member = $pdo->prepare('SELECT role,is_active FROM FSG_TIBIALIKE_ServerSessionMembers WHERE project_id=? AND session_id=? AND user_id=? LIMIT 1'); $member->execute([$projectId,$sessionId,$userId]); $membership = $member->fetch();
        if ($membership && (int)$membership['is_active'] === 1) { $role=(string)$membership['role']; $access='approved'; $pdo->prepare('UPDATE FSG_TIBIALIKE_ServerSessionMembers SET updated_at=CURRENT_TIMESTAMP WHERE project_id=? AND session_id=? AND user_id=?')->execute([$projectId,$sessionId,$userId]); }
        elseif ((int)($session['admin_id'] ?? 0) === $userId) { $role='admin'; $access='approved'; }
        else $pdo->prepare('INSERT INTO FSG_TIBIALIKE_SessionAccessRequests (project_id,session_id,user_id,requested_role,status) VALUES (?,?,?,"player","pending") ON DUPLICATE KEY UPDATE status=IF(status="revoked","pending",status)')->execute([$projectId,$sessionId,$userId]);
    }
    if ((string)$session['status'] !== 'active') $access = 'revoked';
    $dataOwnerKey=(string)$session['data_owner_key']; $playerOwnerKey=$userId>0 ? $dataOwnerKey . ':user:' . $userId : $identity['ownerKey'];
    if ($userId > 0 && function_exists('fsgAuth_touchServerSession')) {
        try { fsgAuth_touchServerSession($pdo,$userId,'Emberwake',$sessionId,'view'); } catch (Throwable $ignored) {}
    }
    return ['sessionId'=>$sessionId,'access'=>$access,'role'=>$role,'adminID'=>(int)($session['admin_id']??0),'dataOwnerKey'=>$dataOwnerKey,'playerOwnerKey'=>$playerOwnerKey,'capabilities'=>gameRoleCapabilities($role),'session'=>$session];
}

function gameRequireCapability(array $context, string $capability): void
{
    if (($context['access'] ?? '') !== 'approved' || empty($context['capabilities'][$capability])) gameJson(['status'=>'error','message'=>'This server-session role does not have permission for that action.','session'=>$context],403);
}

function gameLoad(PDO $pdo, string $ownerKey, string $projectId): ?array
{
    $statement = $pdo->prepare('SELECT payload_json, updated_at FROM FSG_TIBIALIKE_PlayerSaves WHERE owner_key = ? AND project_id = ? LIMIT 1');
    $statement->execute([$ownerKey, $projectId]);
    $row = $statement->fetch();
    if (!$row) return null;
    $state = json_decode((string)$row['payload_json'], true);
    return ['state' => is_array($state) ? $state : null, 'updatedAt' => (string)$row['updated_at']];
}

function gameRevision(PDO $pdo, string $ownerKey, string $projectId, bool $forUpdate = false): array
{
    $insert = $pdo->prepare('INSERT IGNORE INTO FSG_TIBIALIKE_SaveRevisions (owner_key, project_id, revision, content_revision) VALUES (?, ?, 0, 0)');
    $insert->execute([$ownerKey, $projectId]);
    $sql = 'SELECT revision, content_revision FROM FSG_TIBIALIKE_SaveRevisions WHERE owner_key = ? AND project_id = ?' . ($forUpdate ? ' FOR UPDATE' : '');
    $statement = $pdo->prepare($sql); $statement->execute([$ownerKey, $projectId]);
    $row = $statement->fetch() ?: ['revision' => 0, 'content_revision' => 0];
    return ['revision' => (int)$row['revision'], 'contentRevision' => (int)$row['content_revision']];
}

function gameAdvanceRevision(PDO $pdo, string $ownerKey, string $projectId, mixed $expectedRevision, bool $content = false): array
{
    $head = gameRevision($pdo, $ownerKey, $projectId, true);
    if ($expectedRevision !== null && $expectedRevision !== '' && (int)$expectedRevision !== $head['revision']) {
        throw new GameRevisionConflict($head['revision']);
    }
    $nextRevision = $head['revision'] + 1;
    $nextContent = $head['contentRevision'] + ($content ? 1 : 0);
    $statement = $pdo->prepare('UPDATE FSG_TIBIALIKE_SaveRevisions SET revision = ?, content_revision = ? WHERE owner_key = ? AND project_id = ?');
    $statement->execute([$nextRevision, $nextContent, $ownerKey, $projectId]);
    return ['before' => $head['revision'], 'revision' => $nextRevision, 'contentRevision' => $nextContent];
}

function gameAudit(PDO $pdo, string $ownerKey, string $projectId, string $action, ?int $before, ?int $after, array $payload = []): void
{
    $statement = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_AuditLog (owner_key, project_id, action_id, revision_before, revision_after, payload_json) VALUES (?, ?, ?, ?, ?, ?)');
    $statement->execute([$ownerKey, $projectId, gameText($action, 64), $before, $after, gameEncode($payload)]);
}

function gameWriteEvents(PDO $pdo, string $ownerKey, string $projectId, array $events): int
{
    $insert = $pdo->prepare('INSERT IGNORE INTO FSG_TIBIALIKE_Events (owner_key, project_id, event_id, event_type, character_id, occurred_at_ms, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $written = 0;
    foreach (array_slice($events, -1000) as $index => $event) {
        if (!is_array($event)) continue;
        $eventId = gameText($event['id'] ?? $event['eventId'] ?? '', 128);
        if ($eventId === '') $eventId = substr(hash('sha256', gameEncode($event) . ':' . $index), 0, 48);
        $insert->execute([$ownerKey, $projectId, $eventId, gameText($event['type'] ?? $event['eventType'] ?? 'unknown', 128), isset($event['characterId']) ? gameText($event['characterId'], 128) : null, (int)($event['occurredAtMs'] ?? $event['timestamp'] ?? 0), gameEncode($event)]);
        $written += $insert->rowCount();
    }
    return $written;
}

function gameWriteIntegrations(PDO $pdo, string $ownerKey, string $projectId, array $integrations, array $catalog): void
{
    $systemInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_IntegrationSystems (owner_key, project_id, system_id, name, authority_scope, schema_version, content_version, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), authority_scope = VALUES(authority_scope), schema_version = VALUES(schema_version), content_version = VALUES(content_version), payload_json = VALUES(payload_json)');
    foreach (($catalog['integrationSystems'] ?? []) as $system) if (is_array($system)) $systemInsert->execute([$ownerKey, $projectId, gameText($system['id'] ?? '', 128), gameText($system['name'] ?? $system['id'] ?? ''), gameText($system['authority'] ?? $system['authorityScope'] ?? '', 255), (int)($system['schemaVersion'] ?? 1), (int)($system['contentVersion'] ?? 1), gameEncode($system)]);

    $snapshot = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_IntegrationSnapshots (owner_key, project_id, system_id, schema_version, content_version, source_revision, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE schema_version = VALUES(schema_version), content_version = VALUES(content_version), source_revision = VALUES(source_revision), payload_json = VALUES(payload_json), imported_at = CURRENT_TIMESTAMP');
    foreach ($integrations as $systemId => $entry) if (is_array($entry)) $snapshot->execute([$ownerKey, $projectId, gameText($systemId, 128), (int)($entry['schemaVersion'] ?? 1), (int)($entry['contentVersion'] ?? 1), isset($entry['revision']) ? gameText($entry['revision'], 128) : null, gameEncode($entry)]);

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_EntityAliases WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $aliasInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_EntityAliases (owner_key, project_id, alias_id, source_system, entity_type, external_id, canonical_id, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['idAliases'] ?? []) as $row) if (is_array($row)) $aliasInsert->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['sourceSystem'] ?? '', 128), gameText($row['entityType'] ?? '', 64), gameText($row['externalId'] ?? $row['alias'] ?? $row['fromId'] ?? '', 255), gameText($row['canonicalId'] ?? $row['targetId'] ?? $row['toId'] ?? '', 255), gameEncode($row)]);

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_Relationships WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $relationshipInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_Relationships (owner_key, project_id, relationship_id, source_type, source_id, relation_type, target_type, target_id, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['relationships'] ?? []) as $row) if (is_array($row)) $relationshipInsert->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['sourceType'] ?? $row['sourceCategory'] ?? '', 64), gameText($row['sourceId'] ?? '', 255), gameText($row['relationType'] ?? $row['relationshipType'] ?? $row['type'] ?? 'references', 64), gameText($row['targetType'] ?? $row['targetCategory'] ?? '', 64), gameText($row['targetId'] ?? '', 255), gameEncode($row)]);

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_ApiActions WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $actionInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_ApiActions (owner_key, project_id, action_id, http_method, requires_auth, payload_json) VALUES (?, ?, ?, ?, ?, ?)');
    foreach (($catalog['apiActions'] ?? []) as $row) if (is_array($row)) $actionInsert->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['method'] ?? 'GET', 16), !empty($row['requiresAuth']) ? 1 : 0, gameEncode($row)]);

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_ExternalTables WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $tableInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_ExternalTables (owner_key, project_id, table_id, source_system, table_name, payload_json) VALUES (?, ?, ?, ?, ?, ?)');
    foreach (($catalog['externalTables'] ?? []) as $row) if (is_array($row)) $tableInsert->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['sourceSystem'] ?? '', 128), gameText($row['name'] ?? $row['tableName'] ?? $row['id'] ?? ''), gameEncode($row)]);
}

function gameReadCatalog(PDO $pdo, string $ownerKey, string $projectId): array
{
    $statement = $pdo->prepare('SELECT category, payload_json FROM FSG_TIBIALIKE_CatalogEntries WHERE owner_key = ? AND project_id = ? ORDER BY category, sort_order, entity_id');
    $statement->execute([$ownerKey, $projectId]); $catalog = [];
    foreach ($statement->fetchAll() as $row) {
        $payload = json_decode((string)$row['payload_json'], true);
        if (is_array($payload)) $catalog[(string)$row['category']][] = $payload;
    }
    return $catalog;
}

function gameValidatePayload(array $state, array $catalog): array
{
    $errors = []; $warnings = []; $ids = [];
    foreach ($catalog as $category => $rows) {
        if (!is_array($rows)) { $errors[] = "Catalog category {$category} must be a list."; continue; }
        $seen = [];
        foreach ($rows as $index => $row) {
            if (!is_array($row)) { $errors[] = "{$category}[{$index}] must be an object."; continue; }
            $id = trim((string)($row['id'] ?? ''));
            if ($id === '') { $errors[] = "{$category}[{$index}] has no stable id."; continue; }
            if (isset($seen[$id])) $errors[] = "Duplicate {$category} id: {$id}.";
            $seen[$id] = true; $ids[$category][$id] = true;
            foreach (['iconDirectory', 'modelDirectory', 'description', 'tooltip'] as $field) if (!array_key_exists($field, $row)) $warnings[] = "{$category}.{$id} is missing {$field}.";
        }
    }
    $references = ['vocationId' => 'vocations', 'itemId' => 'items', 'monsterId' => 'monsters', 'npcId' => 'npcs', 'questId' => 'quests', 'shopId' => 'shops', 'spellId' => 'spells'];
    foreach (($catalog['relationships'] ?? []) as $row) if (is_array($row)) {
        $targetType = (string)($row['targetType'] ?? $row['targetCategory'] ?? ''); $targetId = (string)($row['targetId'] ?? '');
        if ($targetType !== '' && $targetId !== '' && isset($ids[$targetType]) && !isset($ids[$targetType][$targetId])) $warnings[] = "Relationship {$row['id']} targets missing {$targetType}.{$targetId}.";
    }
    if (!is_array($state['characters'] ?? null)) $errors[] = 'State must contain a characters list.';
    return ['valid' => !$errors, 'errors' => array_values(array_unique($errors)), 'warnings' => array_slice(array_values(array_unique($warnings)), 0, 500), 'counts' => array_map('count', $ids), 'referenceVocabulary' => $references];
}

function gameWriteCatalog(PDO $pdo, string $ownerKey, string $projectId, array $catalog): void
{
    $project = $pdo->prepare(
        'INSERT INTO FSG_TIBIALIKE_Projects (project_id, owner_key, name, version, payload_json)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE name = VALUES(name), version = VALUES(version), payload_json = VALUES(payload_json)'
    );
    $project->execute([$projectId, $ownerKey, 'Emberwake', FSG_TIBIALIKE_VERSION, gameEncode(['categories' => array_keys($catalog)])]);

    $delete = $pdo->prepare('DELETE FROM FSG_TIBIALIKE_CatalogEntries WHERE owner_key = ? AND project_id = ?');
    $delete->execute([$ownerKey, $projectId]);
    $insert = $pdo->prepare(
        'INSERT INTO FSG_TIBIALIKE_CatalogEntries
          (owner_key, project_id, category, entity_id, name, authored_by, authored_at, updated_by, sort_order, payload_json)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    foreach ($catalog as $category => $rows) {
        if (!is_array($rows)) continue;
        foreach (array_values($rows) as $index => $row) {
            if (!is_array($row)) continue;
            $entityId = gameText($row['id'] ?? ($category . '_' . $index), 128);
            $insert->execute([$ownerKey, $projectId, gameText($category, 64), $entityId, gameText($row['name'] ?? $entityId), gameText($row['authoredBy'] ?? $ownerKey, 128), ($row['authoredAt'] ?? null) ?: null, gameText($row['updatedBy'] ?? $ownerKey, 128), $index, gameEncode($row)]);
        }
    }

    gameWriteRuleProjections($pdo, $ownerKey, $projectId, $catalog);
}

function gameWriteRuleProjections(PDO $pdo, string $ownerKey, string $projectId, array $catalog): void
{
    $simple = [
        'vocations' => ['FSG_TIBIALIKE_Vocations', 'role', 'role'],
        'skills' => ['FSG_TIBIALIKE_Skills', 'family', 'family'],
        'shops' => ['FSG_TIBIALIKE_Shops', null, null],
        'mounts' => ['FSG_TIBIALIKE_Mounts', 'speed_bonus', 'speedBonus'],
    ];
    foreach ($simple as $category => [$table, $extraColumn, $sourceField]) {
        $pdo->prepare("DELETE FROM {$table} WHERE owner_key = ? AND project_id = ?")->execute([$ownerKey, $projectId]);
        $columns = 'owner_key, project_id, entity_id, name' . ($extraColumn ? ", {$extraColumn}" : '') . ', payload_json';
        $marks = $extraColumn ? '?, ?, ?, ?, ?, ?' : '?, ?, ?, ?, ?';
        $insert = $pdo->prepare("INSERT INTO {$table} ({$columns}) VALUES ({$marks})");
        foreach (($catalog[$category] ?? []) as $row) {
            if (!is_array($row)) continue;
            $values = [$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['name'] ?? '')];
            if ($extraColumn) $values[] = $row[$sourceField] ?? ($extraColumn === 'speed_bonus' ? 0 : '');
            $values[] = gameEncode($row); $insert->execute($values);
        }
    }

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_Items WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insertItem = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_Items (owner_key, project_id, entity_id, name, item_type, equip_slot, weight_oz, buy_value, sell_value, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['items'] ?? []) as $row) if (is_array($row)) $insertItem->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['name'] ?? ''), gameText($row['type'] ?? '', 64), isset($row['slot']) ? gameText($row['slot'], 64) : null, (float)($row['weight'] ?? 0), (int)($row['buy'] ?? 0), (int)($row['sell'] ?? 0), gameEncode($row)]);

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_Spells WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_VocationSpells WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insertSpell = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_Spells (owner_key, project_id, entity_id, name, spell_group, effect_type, min_level, mana_cost, zeal_cost, cooldown_ms, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $insertVocationSpell = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_VocationSpells (owner_key, project_id, vocation_id, spell_id, min_level, payload_json) VALUES (?, ?, ?, ?, ?, ?)');
    foreach (($catalog['spells'] ?? []) as $row) {
        if (!is_array($row)) continue;
        $spellId = gameText($row['id'] ?? '', 128);
        $insertSpell->execute([$ownerKey, $projectId, $spellId, gameText($row['name'] ?? ''), gameText($row['group'] ?? '', 64), gameText($row['effect'] ?? '', 64), (int)($row['level'] ?? 1), (int)($row['mana'] ?? 0), (int)($row['zeal'] ?? 0), (int)($row['cooldown'] ?? 0), gameEncode($row)]);
        foreach (($row['vocations'] ?? []) as $vocationId) $insertVocationSpell->execute([$ownerKey, $projectId, gameText($vocationId, 128), $spellId, (int)($row['level'] ?? 1), gameEncode(['vocationId' => $vocationId, 'spellId' => $spellId])]);
    }

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_Monsters WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insertMonster = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_Monsters (owner_key, project_id, entity_id, name, monster_level, max_hp, attack_value, defense_value, xp_value, element_type, is_boss, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['monsters'] ?? []) as $row) if (is_array($row)) $insertMonster->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['name'] ?? ''), (int)($row['level'] ?? 1), (int)($row['hp'] ?? 1), (int)($row['attack'] ?? 0), (int)($row['defense'] ?? 0), (int)($row['xp'] ?? 0), gameText($row['element'] ?? 'physical', 64), !empty($row['boss']) ? 1 : 0, gameEncode($row)]);

    gameWriteDropProjections($pdo, $ownerKey, $projectId, $catalog['dropTables'] ?? []);
    gameWriteQuestProjections($pdo, $ownerKey, $projectId, $catalog['quests'] ?? []);
    gameWriteWorldProjections($pdo, $ownerKey, $projectId, $catalog);
}

function gameWriteWorldProjections(PDO $pdo, string $ownerKey, string $projectId, array $catalog): void
{
    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_Zones WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_Zones (owner_key, project_id, entity_id, name, floor_z, min_level, max_level, danger, is_protection_zone, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['zones'] ?? []) as $row) if (is_array($row)) $insert->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['name'] ?? ''), (int)($row['floor'] ?? 0), (int)($row['minLevel'] ?? 1), (int)($row['maxLevel'] ?? 1), gameText($row['danger'] ?? 'low', 32), !empty($row['pz']) ? 1 : 0, gameEncode($row)]);

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_Buildings WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_Buildings (owner_key, project_id, entity_id, name, building_type, pos_x, pos_y, pos_z, width_tiles, height_tiles, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['buildings'] ?? []) as $row) if (is_array($row)) $insert->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['name'] ?? ''), gameText($row['type'] ?? '', 64), (int)($row['x'] ?? 0), (int)($row['y'] ?? 0), (int)($row['z'] ?? 0), (int)($row['width'] ?? 1), (int)($row['height'] ?? 1), gameEncode($row)]);

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_Placements WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_Placements (owner_key, project_id, entity_id, name, placement_type, template_id, pos_x, pos_y, pos_z, target_x, target_y, target_z, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['placements'] ?? []) as $row) if (is_array($row)) $insert->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['label'] ?? ($row['name'] ?? '')), gameText($row['type'] ?? '', 64), gameText($row['entityId'] ?? '', 128), (int)($row['x'] ?? 0), (int)($row['y'] ?? 0), (int)($row['z'] ?? 0), isset($row['targetX']) ? (int)$row['targetX'] : null, isset($row['targetY']) ? (int)$row['targetY'] : null, isset($row['targetZ']) ? (int)$row['targetZ'] : null, gameEncode($row)]);

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_NPCs WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_NPCs (owner_key, project_id, entity_id, name, npc_role, pos_x, pos_y, pos_z, shop_id, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['npcs'] ?? []) as $row) if (is_array($row)) $insert->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['name'] ?? ''), gameText($row['role'] ?? ''), (int)($row['x'] ?? 0), (int)($row['y'] ?? 0), (int)($row['z'] ?? 0), isset($row['shop']) ? gameText($row['shop'], 128) : null, gameEncode($row)]);

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_QuestGivers WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_QuestGivers (owner_key, project_id, entity_id, name, npc_id, quest_id, pos_x, pos_y, pos_z, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['questGivers'] ?? []) as $row) if (is_array($row)) $insert->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['id'] ?? ''), gameText($row['npcId'] ?? '', 128), gameText($row['questId'] ?? '', 128), (int)($row['x'] ?? 0), (int)($row['y'] ?? 0), (int)($row['z'] ?? 0), gameEncode($row)]);

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_ShopEntries WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_ShopEntries (owner_key, project_id, shop_id, item_id, direction, price_override, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['shops'] ?? []) as $shop) if (is_array($shop)) {
        foreach (['buys' => 'buy', 'sells' => 'sell'] as $field => $direction) foreach (array_unique($shop[$field] ?? []) as $itemId) $insert->execute([$ownerKey, $projectId, gameText($shop['id'] ?? '', 128), gameText($itemId, 128), $direction, null, gameEncode(['shopId' => $shop['id'] ?? '', 'itemId' => $itemId, 'direction' => $direction])]);
    }

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_SpawnPoints WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_SpawnPoints (owner_key, project_id, entity_id, name, monster_id, pos_x, pos_y, pos_z, spawn_count, radius_tiles, respawn_seconds, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['spawns'] ?? []) as $row) if (is_array($row)) $insert->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['id'] ?? ''), gameText($row['monsterId'] ?? '', 128), (int)($row['x'] ?? 0), (int)($row['y'] ?? 0), (int)($row['z'] ?? 0), (int)($row['count'] ?? 1), (int)($row['radius'] ?? 0), (int)($row['respawnSeconds'] ?? 15), gameEncode($row)]);

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_Houses WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_Houses (owner_key, project_id, entity_id, name, town, pos_x, pos_y, pos_z, width_tiles, height_tiles, purchase_price, rent_gold, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['houses'] ?? []) as $row) if (is_array($row)) $insert->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['name'] ?? ''), gameText($row['town'] ?? '', 128), (int)($row['x'] ?? 0), (int)($row['y'] ?? 0), (int)($row['z'] ?? 0), (int)($row['width'] ?? 1), (int)($row['height'] ?? 1), (int)($row['price'] ?? 0), (int)($row['rent'] ?? 0), gameEncode($row)]);

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_FurnitureDefinitions WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_FurnitureDefinitions (owner_key, project_id, entity_id, name, category, buy_value, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['furniture'] ?? []) as $row) if (is_array($row)) $insert->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), gameText($row['name'] ?? ''), gameText($row['category'] ?? 'decor', 64), (int)($row['buy'] ?? 0), gameEncode($row)]);

    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_WorldTiles WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_WorldTiles (owner_key, project_id, entity_id, pos_x, pos_y, pos_z, terrain_id, color_hex, is_walkable, is_wall, is_water, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($catalog['levelTiles'] ?? []) as $row) if (is_array($row)) $insert->execute([$ownerKey, $projectId, gameText($row['id'] ?? '', 128), (int)($row['x'] ?? 0), (int)($row['y'] ?? 0), (int)($row['z'] ?? 0), gameText($row['terrain'] ?? '', 64), gameText($row['color'] ?? '', 16), !empty($row['walkable']) ? 1 : 0, !empty($row['wall']) ? 1 : 0, !empty($row['water']) ? 1 : 0, gameEncode($row)]);
}

function gameWriteDropProjections(PDO $pdo, string $ownerKey, string $projectId, array $tables): void
{
    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_DropEntries WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_DropTables WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insertTable = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_DropTables (owner_key, project_id, entity_id, name, monster_id, roll_count, nothing_weight, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $insertEntry = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_DropEntries (owner_key, project_id, drop_table_id, item_id, tier, weight_value, min_quantity, max_quantity, sort_order, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    foreach ($tables as $table) {
        if (!is_array($table)) continue;
        $tableId = gameText($table['id'] ?? '', 128);
        $insertTable->execute([$ownerKey, $projectId, $tableId, gameText($table['name'] ?? $tableId), gameText($table['monsterId'] ?? '', 128), (int)($table['rolls'] ?? 1), (float)($table['nothingWeight'] ?? 0), gameEncode($table)]);
        foreach (array_values($table['entries'] ?? []) as $index => $entry) if (is_array($entry)) $insertEntry->execute([$ownerKey, $projectId, $tableId, gameText($entry['itemId'] ?? '', 128), gameText($entry['tier'] ?? 'common', 32), (float)($entry['weight'] ?? 0), (int)($entry['min'] ?? 1), (int)($entry['max'] ?? 1), $index, gameEncode($entry)]);
    }
}

function gameWriteQuestProjections(PDO $pdo, string $ownerKey, string $projectId, array $quests): void
{
    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_QuestObjectives WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_QuestRewards WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $pdo->prepare('DELETE FROM FSG_TIBIALIKE_Quests WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insertQuest = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_Quests (owner_key, project_id, entity_id, name, giver_id, recommended_level, is_soloable, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $insertObjective = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_QuestObjectives (owner_key, project_id, quest_id, objective_id, objective_type, target_id, required_amount, sort_order, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $insertReward = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_QuestRewards (owner_key, project_id, quest_id, reward_type, target_id, amount, sort_order, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    foreach ($quests as $quest) {
        if (!is_array($quest)) continue;
        $questId = gameText($quest['id'] ?? '', 128);
        $insertQuest->execute([$ownerKey, $projectId, $questId, gameText($quest['name'] ?? ''), isset($quest['giverId']) ? gameText($quest['giverId'], 128) : null, (int)($quest['recommendedLevel'] ?? 1), !empty($quest['solo']) ? 1 : 0, gameEncode($quest)]);
        foreach (array_values($quest['objectives'] ?? []) as $index => $objective) if (is_array($objective)) $insertObjective->execute([$ownerKey, $projectId, $questId, gameText($objective['id'] ?? ('objective_' . $index), 128), gameText($objective['type'] ?? '', 64), gameText($objective['targetId'] ?? '', 128), (int)($objective['amount'] ?? 1), $index, gameEncode($objective)]);
        $rewardOrder = 0;
        foreach (['xp', 'gold'] as $type) if (!empty($quest['rewards'][$type])) $insertReward->execute([$ownerKey, $projectId, $questId, $type, '', (int)$quest['rewards'][$type], $rewardOrder++, gameEncode([$type => $quest['rewards'][$type]])]);
        foreach (($quest['rewards']['items'] ?? []) as $item) if (is_array($item)) $insertReward->execute([$ownerKey, $projectId, $questId, 'item', gameText($item['id'] ?? '', 128), (int)($item['qty'] ?? 1), $rewardOrder++, gameEncode($item)]);
    }
}

function gameFlattenInventory(array $stacks, array $containerContents, ?string $parentInstanceId = null, array &$output = [], array &$visited = []): array
{
    foreach ($stacks as $stack) {
        if (!is_array($stack)) continue;
        $output[] = ['stack' => $stack, 'parentInstanceId' => $parentInstanceId];
        $instanceId = trim((string)($stack['instanceId'] ?? ''));
        if ($instanceId === '' || isset($visited[$instanceId])) continue;
        $visited[$instanceId] = true;
        $children = $containerContents[$instanceId] ?? [];
        if (is_array($children)) gameFlattenInventory($children, $containerContents, $instanceId, $output, $visited);
    }
    return $output;
}

function gameWriteState(PDO $pdo, string $ownerKey, string $projectId, array $state): void
{
    $save = $pdo->prepare(
        'INSERT INTO FSG_TIBIALIKE_PlayerSaves (owner_key, project_id, save_version, active_character_id, payload_json)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE save_version = VALUES(save_version), active_character_id = VALUES(active_character_id), payload_json = VALUES(payload_json)'
    );
    $save->execute([$ownerKey, $projectId, gameText($state['version'] ?? FSG_TIBIALIKE_VERSION, 32), gameText($state['activeCharacterId'] ?? '', 128) ?: null, gameEncode($state)]);
    $sharedContext = is_array($state['world']['sharedContext'] ?? null) ? $state['world']['sharedContext'] : [];
    $instanceKey = gameText(($sharedContext['worldId'] ?? 'world') . ':' . ($sharedContext['villageId'] ?? 'global'), 128);
    $worldInstance = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_WorldInstances (owner_key, project_id, instance_key, content_revision, revision, is_active, state_json) VALUES (?, ?, ?, ?, ?, 1, ?) ON DUPLICATE KEY UPDATE content_revision = VALUES(content_revision), revision = VALUES(revision), is_active = 1, state_json = VALUES(state_json)');
    $worldInstance->execute([$ownerKey, $projectId, $instanceKey, (int)($state['contentVersion'] ?? 0), (int)($state['revision'] ?? 0), gameEncode($state['world'] ?? [])]);

    foreach (['PlayerSkills', 'PlayerInventory', 'PlayerDepot', 'PlayerEquipment', 'PlayerSpellbooks', 'PlayerQuestStates', 'PlayerHouses', 'FurniturePlacements', 'GroundItems', 'PlayerSurvival', 'PlayerCharacters'] as $suffix) {
        $pdo->prepare("DELETE FROM FSG_TIBIALIKE_{$suffix} WHERE owner_key = ? AND project_id = ?")->execute([$ownerKey, $projectId]);
    }
    $characterInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_PlayerCharacters (owner_key, project_id, character_id, slot_number, character_name, vocation_id, character_level, xp, hp_current, hp_max, mana_current, mana_max, zeal_current, gold, pos_x, pos_y, pos_z, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $survivalInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_PlayerSurvival (owner_key, project_id, character_id, hunger, thirst, rest_level, last_updated_ms, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $skillInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_PlayerSkills (owner_key, project_id, character_id, skill_id, skill_level, skill_xp, next_xp, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $inventoryInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_PlayerInventory (owner_key, project_id, character_id, slot_index, item_id, quantity, parent_instance_id, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $depotInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_PlayerDepot (owner_key, project_id, character_id, slot_index, item_id, quantity, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $equipmentInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_PlayerEquipment (owner_key, project_id, character_id, equip_slot, item_id, payload_json) VALUES (?, ?, ?, ?, ?, ?)');
    $spellInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_PlayerSpellbooks (owner_key, project_id, character_id, spell_id, hotbar_slot, payload_json) VALUES (?, ?, ?, ?, ?, ?)');
    $questInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_PlayerQuestStates (owner_key, project_id, character_id, quest_id, quest_status, progress_json, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $houseInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_PlayerHouses (owner_key, project_id, character_id, house_id, payload_json) VALUES (?, ?, ?, ?, ?)');
    $furnitureInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_FurniturePlacements (owner_key, project_id, character_id, placement_id, house_id, item_id, pos_x, pos_y, pos_z, rotation, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $groundInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_GroundItems (owner_key, project_id, character_id, ground_item_id, item_id, quantity, pos_x, pos_y, pos_z, container_json, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');

    foreach (($state['characters'] ?? []) as $character) {
        if (!is_array($character)) continue;
        $characterId = gameText($character['id'] ?? '', 128);
        $characterInsert->execute([$ownerKey, $projectId, $characterId, (int)($character['slot'] ?? 0), gameText($character['name'] ?? ''), gameText($character['vocationId'] ?? '', 128), (int)($character['level'] ?? 1), (int)($character['xp'] ?? 0), (int)($character['hp'] ?? 1), (int)($character['maxHp'] ?? 1), (int)($character['mana'] ?? 0), (int)($character['maxMana'] ?? 0), (int)($character['zeal'] ?? 0), (int)($character['gold'] ?? 0), (int)($character['x'] ?? 0), (int)($character['y'] ?? 0), (int)($character['z'] ?? 0), gameEncode($character)]);
        $survival = is_array($character['survival'] ?? null) ? $character['survival'] : [];
        $survivalInsert->execute([$ownerKey, $projectId, $characterId, (float)($survival['hunger'] ?? 100), (float)($survival['thirst'] ?? 100), (float)($survival['rest'] ?? 100), (int)($survival['lastUpdatedAt'] ?? 0), gameEncode($survival)]);
        foreach (($character['skills'] ?? []) as $skillId => $skill) if (is_array($skill)) $skillInsert->execute([$ownerKey, $projectId, $characterId, gameText($skillId, 128), (int)($skill['level'] ?? 1), (int)($skill['xp'] ?? 0), (int)($skill['next'] ?? 100), gameEncode($skill)]);
        $flattenedInventory = gameFlattenInventory(array_values($character['inventory'] ?? []), is_array($character['containerContents'] ?? null) ? $character['containerContents'] : []);
        foreach ($flattenedInventory as $slot => $entry) {
            $stack = $entry['stack'];
            $inventoryInsert->execute([$ownerKey, $projectId, $characterId, $slot, gameText($stack['id'] ?? '', 128), (int)($stack['qty'] ?? 1), $entry['parentInstanceId'] ? gameText($entry['parentInstanceId'], 128) : null, gameEncode($stack)]);
        }
        foreach (array_values($character['depot'] ?? []) as $slot => $stack) if (is_array($stack)) $depotInsert->execute([$ownerKey, $projectId, $characterId, $slot, gameText($stack['id'] ?? '', 128), (int)($stack['qty'] ?? 1), gameEncode($stack)]);
        foreach (($character['equipment'] ?? []) as $slot => $itemId) $equipmentInsert->execute([$ownerKey, $projectId, $characterId, gameText($slot, 64), $itemId ? gameText($itemId, 128) : null, gameEncode(['slot' => $slot, 'itemId' => $itemId])]);
        foreach (($character['learnedSpells'] ?? $character['spells'] ?? []) as $spellId) {
            if (!$spellId) continue; $hotbar = array_search($spellId, $character['spells'] ?? [], true);
            $spellInsert->execute([$ownerKey, $projectId, $characterId, gameText($spellId, 128), $hotbar === false ? null : (int)$hotbar, gameEncode(['spellId' => $spellId, 'hotbarSlot' => $hotbar === false ? null : $hotbar])]);
        }
        foreach (($character['quests'] ?? []) as $questId => $questState) if (is_array($questState)) $questInsert->execute([$ownerKey, $projectId, $characterId, gameText($questId, 128), gameText($questState['status'] ?? 'available', 32), gameEncode($questState['progress'] ?? []), gameEncode($questState)]);
        foreach (($character['houseIds'] ?? []) as $houseId) $houseInsert->execute([$ownerKey, $projectId, $characterId, gameText($houseId, 128), gameEncode(['houseId' => $houseId])]);
        foreach (($character['furniturePlacements'] ?? []) as $placement) if (is_array($placement)) $furnitureInsert->execute([$ownerKey, $projectId, $characterId, gameText($placement['id'] ?? '', 128), gameText($placement['houseId'] ?? '', 128), gameText($placement['itemId'] ?? '', 128), (int)($placement['x'] ?? 0), (int)($placement['y'] ?? 0), (int)($placement['z'] ?? 0), (int)($placement['rotation'] ?? 0), gameEncode($placement)]);
        foreach (($character['groundItems'] ?? []) as $ground) if (is_array($ground)) $groundInsert->execute([$ownerKey, $projectId, $characterId, gameText($ground['id'] ?? '', 128), isset($ground['itemId']) ? gameText($ground['itemId'], 128) : null, (int)($ground['qty'] ?? 1), (int)($ground['x'] ?? 0), (int)($ground['y'] ?? 0), (int)($ground['z'] ?? 0), isset($ground['items']) ? gameEncode($ground['items']) : null, gameEncode($ground)]);
    }
}

try {
    $action = gameText($_GET['action'] ?? 'session', 32);
    $postActions = ['register', 'login', 'logout', 'save', 'deleteSave', 'saveContent', 'logEvents', 'validate', 'requestSessionAccess', 'reviewSessionAccess', 'setMemberRole', 'setGuildMemberTag', 'transferVillageStore'];
    $body = in_array($action, $postActions, true) ? gameBody() : [];
    $pdo = gameDatabase();
    gameInstallSchema($pdo);

    if ($action === 'health') gameJson(['status' => 'success', 'databaseAvailable' => true, 'schemaInstalled' => gameSchemaInstalled($pdo), 'version' => FSG_TIBIALIKE_VERSION, 'time' => gmdate('c')]);

    if (in_array($action, ['login', 'register', 'logout'], true)) {
        if (!function_exists('fsgAuth_authPayload')) gameJson(['status' => 'error', 'message' => 'The shared auth package is not installed.'], 503);
        if ($action === 'login') {
            $body['identity'] = $body['identity'] ?? $body['identifier'] ?? '';
            $payload = fsgAuth_loginAccount($pdo, $body);
        } elseif ($action === 'register') {
            $payload = fsgAuth_registerAccount($pdo, $body);
        } else {
            fsgAuth_logout($pdo); $payload = ['loggedIn' => false, 'user' => null];
        }
        gameJson(['status' => 'success', 'message' => $action === 'logout' ? 'Logged out.' : 'Account connected.', 'authenticated' => (bool)($payload['loggedIn'] ?? false), 'user' => $payload['user'] ?? null]);
    }

    $identity = gameIdentity($pdo);
    $projectId = gameText($body['projectId'] ?? $_GET['projectId'] ?? FSG_TIBIALIKE_PROJECT, 128);
    if ($projectId === '') $projectId = FSG_TIBIALIKE_PROJECT;
    $ownerKey = $identity['ownerKey'];
    $sessionContext = gameResolveSession($pdo, $identity, $projectId, gameSessionId($body), !in_array($action, ['health','login','register','logout'], true));
    $catalogOwnerKey = (string)($sessionContext['dataOwnerKey'] ?? $ownerKey);
    $ownerKey = (string)($sessionContext['playerOwnerKey'] ?? $ownerKey);
    if (in_array($action, ['listSaves', 'saveContent', 'deleteSave'], true) && !$identity['authenticated']) gameJson(['status' => 'error', 'message' => 'This action requires a signed-in server account.'], 401);

    if ($action === 'status') {
        $head = gameRevision($pdo, $ownerKey, $projectId);
        gameJson(['status' => 'success', 'version' => FSG_TIBIALIKE_VERSION, 'identity' => $ownerKey, 'authenticated' => $identity['authenticated'], 'revision' => $head['revision'], 'contentRevision' => $head['contentRevision']]);
    }

    if ($action === 'listServerSessions') {
        if (!$identity['authenticated']) gameJson(['status'=>'error','message'=>'Sign in to view server sessions.'],401);
        $statement=$pdo->prepare('SELECT s.session_id,s.name,s.status,s.admin_id,s.created_at,s.updated_at,m.role,m.is_active FROM FSG_TIBIALIKE_ServerSessionMembers m JOIN FSG_TIBIALIKE_ServerSessions s ON s.project_id=m.project_id AND s.session_id=m.session_id WHERE m.project_id=? AND m.user_id=? ORDER BY m.updated_at DESC');
        $statement->execute([$projectId,(int)$identity['user']['id']]); gameJson(['status'=>'success','sessions'=>$statement->fetchAll(),'currentSession'=>$sessionContext]);
    }

    if ($action === 'adminPanel') {
        gameRequireCapability($sessionContext,'canModerate');
        $members=$pdo->prepare('SELECT u.id AS user_id,u.username,u.email,COALESCE(m.role,"player") AS role,COALESCE(m.role_tags_json,"[]") AS role_tags_json,COALESCE(m.is_active,0) AS is_active,m.created_at,m.updated_at,(SELECT GROUP_CONCAT(CONCAT(t.guild_id,":",t.rank_id,IF(t.title_tag="","",CONCAT(":",t.title_tag))) SEPARATOR ", ") FROM FSG_TIBIALIKE_GuildMemberTags t WHERE t.project_id=? AND t.session_id=? AND t.user_id=u.id) AS guild_tags FROM FSG_users u LEFT JOIN FSG_TIBIALIKE_ServerSessionMembers m ON m.project_id=? AND m.session_id=? AND m.user_id=u.id ORDER BY FIELD(COALESCE(m.role,"player"),"server_owner","admin","game_master","guild_master","moderator","guild_moderator","player"),u.username');
        $members->execute([$projectId,$sessionContext['sessionId'],$projectId,$sessionContext['sessionId']]);
        $requests=$pdo->prepare('SELECT r.request_id,r.user_id,u.username,u.email,r.requested_role,r.status,r.message,r.created_at FROM FSG_TIBIALIKE_SessionAccessRequests r LEFT JOIN FSG_users u ON u.id=r.user_id WHERE r.project_id=? AND r.session_id=? ORDER BY FIELD(r.status,"pending","approved","denied","revoked"),r.created_at DESC');
        $requests->execute([$projectId,$sessionContext['sessionId']]);
        $tags=$pdo->prepare('SELECT * FROM FSG_TIBIALIKE_GuildMemberTags WHERE project_id=? AND session_id=? ORDER BY guild_id,rank_id,title_tag'); $tags->execute([$projectId,$sessionContext['sessionId']]);
        gameJson(['status'=>'success','session'=>$sessionContext,'members'=>$members->fetchAll(),'requests'=>$requests->fetchAll(),'guildTags'=>$tags->fetchAll()]);
    }

    if ($action === 'villageStore') {
        if (!$identity['authenticated'] || ($sessionContext['access']??'')!=='approved') gameJson(['status'=>'error','message'=>'An approved account is required to use the village store.'],403);
        $seed=['apple'=>30,'bread'=>20,'torch'=>15,'rope'=>5,'minor_potion'=>8];
        $insert=$pdo->prepare('INSERT IGNORE INTO FSG_TIBIALIKE_VillageStoreItems (project_id,session_id,store_id,item_id,quantity,updated_by_user_id,payload_json) VALUES (?,?,"store_anchorage_commons",?,?,?,?)');
        foreach($seed as $itemId=>$quantity)$insert->execute([$projectId,$sessionContext['sessionId'],$itemId,$quantity,(int)$identity['user']['id'],gameEncode(['seeded'=>true])]);
        $items=$pdo->prepare('SELECT store_id,item_id,quantity,updated_at FROM FSG_TIBIALIKE_VillageStoreItems WHERE project_id=? AND session_id=? ORDER BY store_id,item_id');$items->execute([$projectId,$sessionContext['sessionId']]);gameJson(['status'=>'success','items'=>$items->fetchAll()]);
    }

    if ($action === 'transferVillageStore') {
        if (!$identity['authenticated'] || ($sessionContext['access']??'')!=='approved') gameJson(['status'=>'error','message'=>'An approved account is required to use the village store.'],403);
        $storeId=gameText($body['storeId']??'',128);$itemId=gameText($body['itemId']??'',128);$quantity=max(1,min(999,(int)($body['quantity']??1)));$direction=gameText($body['direction']??'',16);
        if($storeId===''||$itemId===''||!in_array($direction,['deposit','withdraw'],true))gameJson(['status'=>'error','message'=>'Invalid village-store transfer.'],400);
        $pdo->beginTransaction();try{$row=$pdo->prepare('SELECT quantity FROM FSG_TIBIALIKE_VillageStoreItems WHERE project_id=? AND session_id=? AND store_id=? AND item_id=? FOR UPDATE');$row->execute([$projectId,$sessionContext['sessionId'],$storeId,$itemId]);$current=(int)($row->fetchColumn()?:0);if($direction==='withdraw'&&$current<$quantity)throw new RuntimeException('The shared store does not have that many.');$next=$direction==='deposit'?$current+$quantity:$current-$quantity;$pdo->prepare('INSERT INTO FSG_TIBIALIKE_VillageStoreItems (project_id,session_id,store_id,item_id,quantity,updated_by_user_id,payload_json) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE quantity=VALUES(quantity),updated_by_user_id=VALUES(updated_by_user_id),payload_json=VALUES(payload_json)')->execute([$projectId,$sessionContext['sessionId'],$storeId,$itemId,$next,(int)$identity['user']['id'],gameEncode(['lastDirection'=>$direction])]);$pdo->commit();}catch(Throwable $error){if($pdo->inTransaction())$pdo->rollBack();throw $error;}gameJson(['status'=>'success','message'=>'Village store updated.','storeId'=>$storeId,'itemId'=>$itemId,'quantity'=>$next]);
    }

    if ($action === 'requestSessionAccess') {
        if (!$identity['authenticated']) gameJson(['status'=>'error','message'=>'Sign in before requesting a server session.'],401);
        $requested=gameSessionId($body); if ($requested==='') gameJson(['status'=>'error','message'=>'Enter a valid server session ID.'],400);
        $exists=$pdo->prepare('SELECT admin_id,status FROM FSG_TIBIALIKE_ServerSessions WHERE project_id=? AND session_id=?'); $exists->execute([$projectId,$requested]); if (!$exists->fetch()) gameJson(['status'=>'error','message'=>'That server session does not exist.'],404);
        $pdo->prepare('INSERT INTO FSG_TIBIALIKE_SessionAccessRequests (project_id,session_id,user_id,requested_role,status,message) VALUES (?,?,?,"player","pending",?) ON DUPLICATE KEY UPDATE status="pending",message=VALUES(message),reviewed_by_user_id=NULL,reviewed_at=NULL')->execute([$projectId,$requested,(int)$identity['user']['id'],gameText($body['message']??'',500)]);
        gameJson(['status'=>'success','message'=>'Access request sent to this session’s original admin.','sessionId'=>$requested]);
    }

    if ($action === 'reviewSessionAccess') {
        if ((int)($sessionContext['adminID']??0)!==(int)($identity['user']['id']??0)) gameJson(['status'=>'error','message'=>'Only this project session’s original admin can approve or revoke access.'],403);
        $target=(int)($body['userId']??0); $decision=gameText($body['decision']??'',16); if ($target<=0||!in_array($decision,['approve','deny','revoke'],true)) gameJson(['status'=>'error','message'=>'Invalid access review.'],400);
        if ($decision==='approve') { $pdo->prepare('INSERT INTO FSG_TIBIALIKE_ServerSessionMembers (project_id,session_id,user_id,role,role_tags_json,granted_by_user_id,is_active) VALUES (?,?,?,"player",?,?,1) ON DUPLICATE KEY UPDATE role=IF(role IN ("admin","server_owner"),role,"player"),is_active=1,granted_by_user_id=VALUES(granted_by_user_id)')->execute([$projectId,$sessionContext['sessionId'],$target,gameEncode([]),(int)$identity['user']['id']]); }
        else $pdo->prepare('UPDATE FSG_TIBIALIKE_ServerSessionMembers SET is_active=0 WHERE project_id=? AND session_id=? AND user_id=? AND role NOT IN ("admin","server_owner")')->execute([$projectId,$sessionContext['sessionId'],$target]);
        $status=$decision==='approve'?'approved':($decision==='deny'?'denied':'revoked'); $pdo->prepare('UPDATE FSG_TIBIALIKE_SessionAccessRequests SET status=?,reviewed_by_user_id=?,reviewed_at=CURRENT_TIMESTAMP WHERE project_id=? AND session_id=? AND user_id=?')->execute([$status,(int)$identity['user']['id'],$projectId,$sessionContext['sessionId'],$target]); gameJson(['status'=>'success','message'=>'Session access updated.']);
    }

    if ($action === 'setMemberRole') {
        gameRequireCapability($sessionContext,'canModerate'); $actorRole=(string)$sessionContext['role']; $target=(int)($body['userId']??0); $role=gameText($body['role']??'player',32);
        if ($target <= 0) gameJson(['status'=>'error','message'=>'Choose a valid account.'],400);
        if ($actorRole === 'moderator') gameJson(['status'=>'error','message'=>'Moderators may inspect accounts but cannot grant or revoke roles.'],403);
        if (in_array($role,['admin','server_owner'],true)) gameJson(['status'=>'error','message'=>'Admin and server-owner privileges cannot be granted. The original adminID is immutable.'],403);
        if (in_array($role,['game_master','guild_master'],true) && !in_array($actorRole,['admin','server_owner'],true)) gameJson(['status'=>'error','message'=>'Only the original admin or server owner can grant game-master or guild-master access.'],403);
        if ($role==='moderator' && !in_array($actorRole,['game_master','admin','server_owner'],true)) gameJson(['status'=>'error','message'=>'Only a game master or original admin can grant moderator access.'],403);
        if ($role==='guild_moderator' && !in_array($actorRole,['guild_master','game_master','admin','server_owner'],true)) gameJson(['status'=>'error','message'=>'Only a guild master or higher can grant guild-moderator access.'],403);
        if (!in_array($role,['player','guild_moderator','moderator','guild_master','game_master'],true)) gameJson(['status'=>'error','message'=>'Unknown role.'],400);
        $targetRoleQuery=$pdo->prepare('SELECT role FROM FSG_TIBIALIKE_ServerSessionMembers WHERE project_id=? AND session_id=? AND user_id=?'); $targetRoleQuery->execute([$projectId,$sessionContext['sessionId'],$target]); $targetRole=(string)($targetRoleQuery->fetchColumn()?:'player');
        if ($actorRole==='game_master' && in_array($targetRole,['game_master','guild_master','admin','server_owner'],true)) gameJson(['status'=>'error','message'=>'A game master cannot alter an equal or higher authoring role.'],403);
        if ($actorRole==='guild_master' && in_array($targetRole,['moderator','game_master','guild_master','admin','server_owner'],true)) gameJson(['status'=>'error','message'=>'A guild master can manage players and guild moderators only.'],403);
        $pdo->prepare('INSERT INTO FSG_TIBIALIKE_ServerSessionMembers (project_id,session_id,user_id,role,role_tags_json,granted_by_user_id,is_active) VALUES (?,?,?,?,?,?,1) ON DUPLICATE KEY UPDATE role=IF(role IN ("admin","server_owner"),role,VALUES(role)),granted_by_user_id=IF(role IN ("admin","server_owner"),granted_by_user_id,VALUES(granted_by_user_id)),is_active=IF(role IN ("admin","server_owner"),is_active,1)')->execute([$projectId,$sessionContext['sessionId'],$target,$role,gameEncode([]),(int)$identity['user']['id']]); gameJson(['status'=>'success','message'=>'Member role updated and session access enabled.']);
    }

    if ($action === 'setGuildMemberTag') {
        gameRequireCapability($sessionContext,'canManageGuild'); $target=(int)($body['userId']??0); $guildId=gameText($body['guildId']??'',128); if($target<=0||$guildId==='') gameJson(['status'=>'error','message'=>'Guild and member are required.'],400);
        $rank=gameText($body['rankId']??'member',128); $tag=gameText($body['titleTag']??'',128); $isMod=!empty($body['isGuildModerator'])?1:0;
        $pdo->prepare('INSERT INTO FSG_TIBIALIKE_GuildMemberTags (project_id,session_id,guild_id,user_id,rank_id,title_tag,is_guild_moderator,assigned_by_user_id,payload_json) VALUES (?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE rank_id=VALUES(rank_id),title_tag=VALUES(title_tag),is_guild_moderator=VALUES(is_guild_moderator),assigned_by_user_id=VALUES(assigned_by_user_id),payload_json=VALUES(payload_json)')->execute([$projectId,$sessionContext['sessionId'],$guildId,$target,$rank,$tag,$isMod,(int)$identity['user']['id'],gameEncode($body)]); gameJson(['status'=>'success','message'=>'Guild rank and title tags updated.']);
    }

    if ($action === 'save') {
        if ($identity['authenticated'] && ($sessionContext['access'] ?? '') !== 'approved') gameJson(['status'=>'error','message'=>'This server session is awaiting approval from its original admin.'],403);
        $state = $body['state'] ?? null; $catalog = $body['catalog'] ?? null;
        if (!is_array($state) || !is_array($catalog)) gameJson(['status' => 'error', 'message' => 'state and catalog are required.'], 400);
        $canAuthor=!empty($sessionContext['capabilities']['canAuthor']); $authoritativeCatalog=$canAuthor?$catalog:gameReadCatalog($pdo,$catalogOwnerKey,$projectId); if(!$authoritativeCatalog)$authoritativeCatalog=$catalog;
        $validation = gameValidatePayload($state, $authoritativeCatalog);
        if (!$validation['valid']) gameJson(['status' => 'error', 'message' => 'The save failed contract validation.', 'validation' => $validation], 422);
        $pdo->beginTransaction();
        try {
            $head = gameAdvanceRevision($pdo, $ownerKey, $projectId, $body['expectedRevision'] ?? null);
            $state['revision'] = $head['revision']; $state['serverRevision'] = $head['revision'];
            if ($canAuthor) { gameWriteCatalog($pdo, $catalogOwnerKey, $projectId, $catalog); $pdo->prepare('UPDATE FSG_TIBIALIKE_Projects SET admin_id=COALESCE(admin_id,?) WHERE owner_key=? AND project_id=?')->execute([$sessionContext['adminID']?:null,$catalogOwnerKey,$projectId]); }
            gameWriteState($pdo, $ownerKey, $projectId, $state);
            if ($canAuthor) gameWriteIntegrations($pdo, $catalogOwnerKey, $projectId, is_array($body['integrations'] ?? null) ? $body['integrations'] : ($state['integrations'] ?? []), $catalog);
            $eventsWritten = gameWriteEvents($pdo, $ownerKey, $projectId, is_array($body['events'] ?? null) ? $body['events'] : []);
            gameAudit($pdo, $ownerKey, $projectId, 'save', $head['before'], $head['revision'], ['eventsWritten' => $eventsWritten, 'catalogCategories' => count($catalog)]);
            $pdo->commit();
        } catch (Throwable $error) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $error;
        }
        gameJson(['status' => 'success', 'message' => 'Emberwake session data synchronized.', 'identity' => $ownerKey, 'authenticated' => $identity['authenticated'], 'serverSessionId'=>$sessionContext['sessionId'], 'role'=>$sessionContext['role'], 'revision' => $head['revision'], 'contentRevision' => $head['contentRevision'], 'eventsWritten' => $eventsWritten, 'validation' => $validation]);
    }

    if ($action === 'saveContent') {
        gameRequireCapability($sessionContext,'canAuthor');
        $catalog = $body['catalog'] ?? $body['definitions'] ?? null;
        if (!is_array($catalog)) gameJson(['status' => 'error', 'message' => 'catalog or definitions is required.'], 400);
        $validation = gameValidatePayload(is_array($body['state'] ?? null) ? $body['state'] : ['characters' => []], $catalog);
        if (!$validation['valid']) gameJson(['status' => 'error', 'message' => 'The content failed contract validation.', 'validation' => $validation], 422);
        $integrations = is_array($body['integrations'] ?? null) ? $body['integrations'] : [];
        $pdo->beginTransaction();
        try {
            $head = gameAdvanceRevision($pdo, $catalogOwnerKey, $projectId, $body['expectedRevision'] ?? null, true);
            gameWriteCatalog($pdo, $catalogOwnerKey, $projectId, $catalog);
            gameWriteIntegrations($pdo, $catalogOwnerKey, $projectId, $integrations, $catalog);
            $contentInsert = $pdo->prepare('INSERT INTO FSG_TIBIALIKE_ContentVersions (owner_key, project_id, content_revision, schema_version, content_version, payload_json) VALUES (?, ?, ?, ?, ?, ?)');
            $contentInsert->execute([$catalogOwnerKey, $projectId, $head['contentRevision'], (int)($body['schemaVersion'] ?? 1), (int)($body['contentVersion'] ?? $head['contentRevision']), gameEncode(['definitions' => $catalog, 'integrations' => $integrations])]);
            gameAudit($pdo, $catalogOwnerKey, $projectId, 'saveContent', $head['before'], $head['revision'], ['contentRevision' => $head['contentRevision']]);
            $pdo->commit();
        } catch (Throwable $error) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $error;
        }
        gameJson(['status' => 'success', 'message' => 'Definitions published.', 'revision' => $head['revision'], 'contentRevision' => $head['contentRevision'], 'validation' => $validation]);
    }

    if ($action === 'validate') {
        $state = is_array($body['state'] ?? null) ? $body['state'] : ['characters' => []];
        $catalog = is_array($body['catalog'] ?? null) ? $body['catalog'] : (is_array($body['definitions'] ?? null) ? $body['definitions'] : []);
        $validation = gameValidatePayload($state, $catalog);
        gameJson(['status' => $validation['valid'] ? 'success' : 'error', 'message' => $validation['valid'] ? 'Contract is valid.' : 'Contract has validation errors.', 'validation' => $validation], $validation['valid'] ? 200 : 422);
    }

    if ($action === 'logEvents') {
        $events = $body['events'] ?? null;
        if (!is_array($events)) gameJson(['status' => 'error', 'message' => 'events must be a list.'], 400);
        $written = gameWriteEvents($pdo, $ownerKey, $projectId, $events);
        gameJson(['status' => 'success', 'message' => 'Events accepted.', 'written' => $written, 'duplicates' => max(0, count($events) - $written)]);
    }

    if ($action === 'listEvents') {
        $since = max(0, (int)($_GET['since'] ?? 0)); $limit = min(1000, max(1, (int)($_GET['limit'] ?? 200)));
        $statement = $pdo->prepare("SELECT event_id, event_type, character_id, occurred_at_ms, payload_json, received_at FROM FSG_TIBIALIKE_Events WHERE owner_key = ? AND project_id = ? AND occurred_at_ms >= ? ORDER BY occurred_at_ms, event_id LIMIT {$limit}");
        $statement->execute([$ownerKey, $projectId, $since]); $events = [];
        foreach ($statement->fetchAll() as $row) { $payload = json_decode((string)$row['payload_json'], true); $events[] = ['eventId' => $row['event_id'], 'eventType' => $row['event_type'], 'characterId' => $row['character_id'], 'occurredAtMs' => (int)$row['occurred_at_ms'], 'receivedAt' => $row['received_at'], 'payload' => is_array($payload) ? $payload : []]; }
        gameJson(['status' => 'success', 'events' => $events, 'count' => count($events)]);
    }

    if ($action === 'listCatalog') gameJson(['status' => 'success', 'catalog' => gameReadCatalog($pdo, $catalogOwnerKey, $projectId), 'session'=>$sessionContext]);

    if ($action === 'loadContent') {
        $statement = $pdo->prepare('SELECT content_revision, schema_version, content_version, payload_json, created_at FROM FSG_TIBIALIKE_ContentVersions WHERE owner_key = ? AND project_id = ? ORDER BY content_revision DESC LIMIT 1');
        $statement->execute([$catalogOwnerKey, $projectId]); $row = $statement->fetch();
        if ($row) gameJson(['status' => 'success', 'contentRevision' => (int)$row['content_revision'], 'schemaVersion' => (int)$row['schema_version'], 'contentVersion' => (int)$row['content_version'], 'content' => json_decode((string)$row['payload_json'], true), 'createdAt' => $row['created_at']]);
        gameJson(['status' => 'success', 'contentRevision' => 0, 'content' => ['definitions' => gameReadCatalog($pdo, $catalogOwnerKey, $projectId), 'integrations' => []], 'createdAt' => null]);
    }

    if ($action === 'listSaves') {
        $statement = $pdo->prepare('SELECT project_id, save_version, active_character_id, created_at, updated_at FROM FSG_TIBIALIKE_PlayerSaves WHERE owner_key = ? ORDER BY updated_at DESC');
        $statement->execute([$ownerKey]); gameJson(['status' => 'success', 'saves' => $statement->fetchAll()]);
    }

    if ($action === 'deleteSave') {
        if (!$identity['authenticated']) gameJson(['status' => 'error', 'message' => 'Sign in before deleting a server save.'], 401);
        $pdo->beginTransaction();
        try {
            foreach (['PlayerSkills', 'PlayerInventory', 'PlayerDepot', 'PlayerEquipment', 'PlayerSpellbooks', 'PlayerQuestStates', 'PlayerHouses', 'FurniturePlacements', 'GroundItems', 'PlayerSurvival', 'PlayerCharacters', 'PlayerSaves', 'IntegrationSnapshots', 'Events', 'ContentVersions', 'WorldInstances', 'SaveRevisions'] as $suffix) $pdo->prepare("DELETE FROM FSG_TIBIALIKE_{$suffix} WHERE owner_key = ? AND project_id = ?")->execute([$ownerKey, $projectId]);
            gameAudit($pdo, $ownerKey, $projectId, 'deleteSave', null, null, []); $pdo->commit();
        } catch (Throwable $error) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $error; }
        gameJson(['status' => 'success', 'message' => 'Server save deleted.']);
    }

    if ($action === 'session' || $action === 'load') {
        $allowed=($sessionContext['access']??'')==='approved'||!$identity['authenticated']; $loaded = $allowed ? gameLoad($pdo, $ownerKey, $projectId) : null; $head = gameRevision($pdo, $ownerKey, $projectId);
        $authPayload = function_exists('fsgAuth_authPayload') ? fsgAuth_authPayload($pdo) : ['loggedIn' => false, 'user' => null];
        gameJson([
            'status' => 'success', 'databaseAvailable' => true, 'authAvailable' => function_exists('fsgAuth_authPayload'),
            'authenticated' => (bool)($authPayload['loggedIn'] ?? $identity['authenticated']), 'user' => $authPayload['user'] ?? $identity['user'],
            'identity' => $ownerKey, 'state' => $loaded['state'] ?? null, 'catalog' => $allowed ? gameReadCatalog($pdo, $catalogOwnerKey, $projectId) : [], 'serverSession'=>$sessionContext, 'sessions'=>($authPayload['sessions']??[]), 'updatedAt' => $loaded['updatedAt'] ?? null,
            'revision' => $head['revision'], 'contentRevision' => $head['contentRevision'],
        ]);
    }

    gameJson(['status' => 'error', 'message' => 'Unknown action.'], 404);
} catch (GameRevisionConflict $error) {
    gameJson(['status' => 'conflict', 'message' => $error->getMessage(), 'revision' => $error->currentRevision], 409);
} catch (Throwable $error) {
    if (($_GET['action'] ?? 'session') === 'session') {
        gameJson(['status' => 'success', 'databaseAvailable' => false, 'authAvailable' => $authAvailable, 'authenticated' => false, 'user' => null, 'state' => null, 'updatedAt' => null, 'revision' => null, 'contentRevision' => null, 'message' => 'Local mode: ' . $error->getMessage()]);
    }
    gameJson(['status' => 'error', 'message' => $error->getMessage()], 500);
}
