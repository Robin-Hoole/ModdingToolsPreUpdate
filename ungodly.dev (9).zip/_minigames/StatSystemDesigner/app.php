<?php
declare(strict_types=1);

$authCandidates = [
    __DIR__ . '/_private/AuthShared.php',
    dirname(__DIR__) . '/_private/AuthShared.php',
];
$authPath = null;
foreach ($authCandidates as $candidate) {
    if (is_file($candidate)) {
        $authPath = $candidate;
        break;
    }
}
if ($authPath === null) {
    http_response_code(500);
    exit('StatSystemDesigner could not find _private/AuthShared.php.');
}
require_once $authPath;

fsgAuth_startSharedSession();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

const FSG_STAT_APP_KEY = 'StatSystemDesigner';
const FSG_STAT_GUEST_COOKIE = 'FSG_STAT_GUEST';
const FSG_STAT_USER_SESSION_COOKIE = 'FSG_STAT_SESSION';
const FSG_STAT_MAX_PROGRESS_BYTES = 8388608;
const FSG_STAT_MAX_IMAGE_BYTES = 10485760;

function statJson(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function statCookie(string $name, string $value, int $maxAge = 31536000): void
{
    setcookie($name, $value, [
        'expires' => time() + $maxAge,
        'path' => '/',
        'domain' => fsgAuth_cookieDomain(),
        'secure' => fsgAuth_isHttpsRequest(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function statSafeId(string $prefix, string $token): string
{
    return $prefix . strtoupper(substr(hash('sha256', $token), 0, 20));
}

function statEnsureTables(PDO $pdo): void
{
    $userIdType = fsgAuth_sharedFsgUserIdSqlType($pdo);
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_StatManager_Guests (
        guest_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        token_hash CHAR(64) NOT NULL,
        display_name VARCHAR(64) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (guest_id),
        UNIQUE KEY uq_FSG_StatManager_Guests_token (token_hash)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_StatManager_Sessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        session_id VARCHAR(64) NOT NULL,
        user_id {$userIdType} NULL,
        guest_id BIGINT UNSIGNED NULL,
        actor_type VARCHAR(16) NOT NULL,
        display_name VARCHAR(64) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_saved_at TIMESTAMP NULL DEFAULT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_StatManager_Sessions_session (session_id),
        KEY idx_FSG_StatManager_Sessions_user (user_id, last_seen_at),
        KEY idx_FSG_StatManager_Sessions_guest (guest_id, last_seen_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_StatManager_PlayerProgress (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        session_id VARCHAR(64) NOT NULL,
        user_id {$userIdType} NULL,
        guest_id BIGINT UNSIGNED NULL,
        project_id VARCHAR(128) NOT NULL,
        project_name VARCHAR(255) NOT NULL,
        payload_json LONGTEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_StatManager_PlayerProgress_session (session_id),
        KEY idx_FSG_StatManager_PlayerProgress_user (user_id, updated_at),
        KEY idx_FSG_StatManager_PlayerProgress_guest (guest_id, updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_StatManager_Projects (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        owner_key VARCHAR(96) NOT NULL,
        project_id VARCHAR(128) NOT NULL,
        name VARCHAR(255) NOT NULL,
        payload_json LONGTEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_StatManager_Projects_owner_project (owner_key, project_id),
        KEY idx_FSG_StatManager_Projects_updated (updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_StatManager_Assets (
        asset_id VARCHAR(80) NOT NULL,
        owner_key VARCHAR(96) NOT NULL,
        session_id VARCHAR(64) NOT NULL,
        original_name VARCHAR(255) NOT NULL,
        relative_path VARCHAR(500) NOT NULL,
        mime_type VARCHAR(100) NOT NULL,
        byte_size BIGINT UNSIGNED NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (asset_id),
        KEY idx_FSG_StatManager_Assets_owner (owner_key, created_at),
        KEY idx_FSG_StatManager_Assets_session (session_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_StatManager_Definitions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        owner_key VARCHAR(96) NOT NULL,
        project_id VARCHAR(128) NOT NULL,
        definition_type VARCHAR(32) NOT NULL,
        definition_id VARCHAR(128) NOT NULL,
        parent_id VARCHAR(128) NOT NULL DEFAULT '',
        display_name VARCHAR(255) NOT NULL DEFAULT '',
        sort_order INT NOT NULL DEFAULT 0,
        payload_json LONGTEXT NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_StatManager_Definitions_owner (owner_key, project_id, definition_type, definition_id),
        KEY idx_FSG_StatManager_Definitions_project (owner_key, project_id, definition_type, sort_order),
        KEY idx_FSG_StatManager_Definitions_parent (owner_key, project_id, parent_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function statReplaceDefinitions(PDO $pdo, string $ownerKey, string $projectId, array $project): void
{
    $pdo->prepare('DELETE FROM FSG_StatManager_Definitions WHERE owner_key = ? AND project_id = ?')->execute([$ownerKey, $projectId]);
    $insert = $pdo->prepare('INSERT INTO FSG_StatManager_Definitions
        (owner_key, project_id, definition_type, definition_id, parent_id, display_name, sort_order, payload_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $write = static function (string $type, array $item, string $parentId, int $sortOrder) use ($insert, $ownerKey, $projectId): void {
        $id = substr((string)($item['id'] ?? ($type . '-' . $sortOrder)), 0, 128);
        $name = substr((string)($item['name'] ?? $item['label'] ?? $item['title'] ?? ''), 0, 255);
        $insert->execute([$ownerKey, $projectId, $type, $id, substr($parentId, 0, 128), $name, $sortOrder, json_encode($item, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
    };
    foreach (($project['categories'] ?? []) as $categoryIndex => $category) {
        if (!is_array($category)) continue;
        $write('category', $category, '', (int)$categoryIndex);
        foreach (($category['stats'] ?? []) as $statIndex => $stat) {
            if (is_array($stat)) $write('stat', $stat, (string)($category['id'] ?? ''), (int)$statIndex);
        }
    }
    foreach (($project['currencies'] ?? []) as $index => $item) if (is_array($item)) $write('currency', $item, '', (int)$index);
    foreach (($project['skills'] ?? []) as $index => $item) if (is_array($item)) $write('skill', $item, '', (int)$index);
    foreach (($project['map']['nodes'] ?? []) as $index => $item) if (is_array($item)) $write('map_node', $item, '', (int)$index);
    foreach (($project['encounters'] ?? []) as $index => $item) if (is_array($item)) $write('encounter', $item, '', (int)$index);
}

/**
 * @return array{
 *   sessionId:string, actorType:string, displayName:string, ownerKey:string,
 *   userId:int, guestId:int, officialAdmin:bool
 * }
 */
function statIdentity(PDO $pdo): array
{
    $userId = fsgAuth_currentUserIdFromRequest($pdo);
    if ($userId > 0) {
        $user = fsgAuth_getUserById($pdo, $userId);
        if ($user) {
            $deviceToken = strtolower(trim((string)($_COOKIE[FSG_STAT_USER_SESSION_COOKIE] ?? '')));
            if (!preg_match('/^[a-f0-9]{48}$/', $deviceToken)) {
                $deviceToken = bin2hex(random_bytes(24));
                statCookie(FSG_STAT_USER_SESSION_COOKIE, $deviceToken);
            }
            $adminStmt = $pdo->prepare('SELECT is_admin FROM FSG_users WHERE id = ? LIMIT 1');
            $adminStmt->execute([$userId]);
            $officialAdmin = ((int)($adminStmt->fetchColumn() ?: 0) === 1)
                || !empty($_SESSION['admin_id']);
            return [
                'sessionId' => statSafeId('SSD-U-', $userId . ':' . $deviceToken),
                'actorType' => 'user',
                'displayName' => (string)$user['username'],
                'ownerKey' => 'user:' . $userId,
                'userId' => $userId,
                'guestId' => 0,
                'officialAdmin' => $officialAdmin,
            ];
        }
    }

    $guestToken = strtolower(trim((string)($_COOKIE[FSG_STAT_GUEST_COOKIE] ?? '')));
    if (!preg_match('/^[a-f0-9]{48}$/', $guestToken)) {
        $guestToken = bin2hex(random_bytes(24));
        statCookie(FSG_STAT_GUEST_COOKIE, $guestToken);
    }
    $tokenHash = hash('sha256', 'fsg-stat-guest:' . $guestToken);
    $displayName = 'Guest_' . str_pad((string)(hexdec(substr($tokenHash, 0, 8)) % 10000), 4, '0', STR_PAD_LEFT);
    $insert = $pdo->prepare("INSERT INTO FSG_StatManager_Guests (token_hash, display_name)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE display_name = VALUES(display_name), last_seen_at = CURRENT_TIMESTAMP");
    $insert->execute([$tokenHash, $displayName]);
    $lookup = $pdo->prepare('SELECT guest_id FROM FSG_StatManager_Guests WHERE token_hash = ? LIMIT 1');
    $lookup->execute([$tokenHash]);
    $guestId = (int)$lookup->fetchColumn();

    return [
        'sessionId' => statSafeId('SSD-G-', $guestToken),
        'actorType' => 'guest',
        'displayName' => $displayName,
        'ownerKey' => 'guest:' . $guestId,
        'userId' => 0,
        'guestId' => $guestId,
        'officialAdmin' => false,
    ];
}

function statTouchSession(PDO $pdo, array $identity, bool $saved = false): void
{
    $sql = "INSERT INTO FSG_StatManager_Sessions
        (session_id, user_id, guest_id, actor_type, display_name, created_at, last_seen_at, last_saved_at, is_active)
        VALUES (?, NULLIF(?, 0), NULLIF(?, 0), ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, " .
        ($saved ? 'CURRENT_TIMESTAMP' : 'NULL') . ", 1)
        ON DUPLICATE KEY UPDATE
            user_id = VALUES(user_id),
            guest_id = VALUES(guest_id),
            actor_type = VALUES(actor_type),
            display_name = VALUES(display_name),
            last_seen_at = CURRENT_TIMESTAMP,
            last_saved_at = " . ($saved ? 'CURRENT_TIMESTAMP' : 'last_saved_at') . ",
            is_active = 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $identity['sessionId'],
        $identity['userId'],
        $identity['guestId'],
        $identity['actorType'],
        $identity['displayName'],
    ]);
    if ($identity['userId'] > 0) {
        fsgAuth_touchServerSession(
            $pdo,
            $identity['userId'],
            FSG_STAT_APP_KEY,
            $identity['sessionId'],
            $saved ? 'push' : 'view'
        );
    }
}

function statLatestProgress(PDO $pdo, array $identity): ?array
{
    if ($identity['userId'] > 0) {
        $stmt = $pdo->prepare("SELECT payload_json, updated_at
            FROM FSG_StatManager_PlayerProgress
            WHERE user_id = ?
            ORDER BY (session_id = ?) DESC, updated_at DESC
            LIMIT 1");
        $stmt->execute([$identity['userId'], $identity['sessionId']]);
    } else {
        $stmt = $pdo->prepare("SELECT payload_json, updated_at
            FROM FSG_StatManager_PlayerProgress
            WHERE guest_id = ?
            ORDER BY (session_id = ?) DESC, updated_at DESC
            LIMIT 1");
        $stmt->execute([$identity['guestId'], $identity['sessionId']]);
    }
    $row = $stmt->fetch();
    if (!$row) return null;
    $decoded = json_decode((string)$row['payload_json'], true);
    return [
        'state' => is_array($decoded) ? $decoded : null,
        'updatedAt' => (string)$row['updated_at'],
    ];
}

try {
    $pdo = fsgAuth_dbConnection();
    fsgAuth_ensureAccountTables($pdo);
    statEnsureTables($pdo);
    $action = strtolower(trim((string)($_GET['action'] ?? 'session')));
    fsgAuth_touchSharedSession();

    if ($action === 'status' || $action === 'authstatus') {
        statJson(['ok' => true, 'success' => true] + fsgAuth_authPayload($pdo));
    }
    if ($action === 'register') {
        statJson(['ok' => true, 'success' => true] + fsgAuth_registerAccount($pdo, fsgAuth_requestBody()));
    }
    if ($action === 'login') {
        statJson(['ok' => true, 'success' => true] + fsgAuth_loginAccount($pdo, fsgAuth_requestBody()));
    }
    if ($action === 'logout') {
        fsgAuth_logout($pdo);
        statJson(['ok' => true, 'success' => true, 'loggedIn' => false, 'user' => null, 'sessions' => []]);
    }

    $identity = statIdentity($pdo);

    if ($action === 'health') {
        statJson(['ok' => true, 'service' => FSG_STAT_APP_KEY, 'persistence' => ['MySQL', 'server uploads']]);
    }

    if ($action === 'session' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        statTouchSession($pdo, $identity, false);
        $stored = statLatestProgress($pdo, $identity);
        statJson([
            'ok' => true,
            'sessionId' => $identity['sessionId'],
            'actorType' => $identity['actorType'],
            'displayName' => $identity['displayName'],
            'officialAdmin' => $identity['officialAdmin'],
            'lastSavedAt' => $stored['updatedAt'] ?? '',
            'progress' => $stored['state'] ?? null,
        ]);
    }

    if ($action === 'progress' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        statTouchSession($pdo, $identity, false);
        $stored = statLatestProgress($pdo, $identity);
        statJson([
            'ok' => true,
            'progress' => $stored['state'] ?? null,
            'savedAt' => $stored['updatedAt'] ?? '',
        ]);
    }

    if ($action === 'progress' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $contentLength = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
        if ($contentLength > FSG_STAT_MAX_PROGRESS_BYTES) {
            statJson(['ok' => false, 'error' => 'Progress payload is too large.'], 413);
        }
        $body = fsgAuth_requestBody();
        if ((string)($body['sessionId'] ?? '') !== $identity['sessionId']) {
            statJson(['ok' => false, 'error' => 'Session ownership check failed.'], 403);
        }
        $projectId = substr(trim((string)($body['projectId'] ?? '')), 0, 128);
        $projectName = substr(trim((string)($body['projectName'] ?? '')), 0, 255);
        $state = $body['state'] ?? null;
        if ($projectId === '' || $projectName === '' || !is_array($state)) {
            statJson(['ok' => false, 'error' => 'Project and progress state are required.'], 422);
        }
        $payloadJson = json_encode($state, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($payloadJson === false || strlen($payloadJson) > FSG_STAT_MAX_PROGRESS_BYTES) {
            statJson(['ok' => false, 'error' => 'Progress payload could not be stored.'], 413);
        }

        $pdo->beginTransaction();
        $save = $pdo->prepare("INSERT INTO FSG_StatManager_PlayerProgress
            (session_id, user_id, guest_id, project_id, project_name, payload_json, created_at, updated_at)
            VALUES (?, NULLIF(?, 0), NULLIF(?, 0), ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ON DUPLICATE KEY UPDATE
                user_id = VALUES(user_id),
                guest_id = VALUES(guest_id),
                project_id = VALUES(project_id),
                project_name = VALUES(project_name),
                payload_json = VALUES(payload_json),
                updated_at = CURRENT_TIMESTAMP");
        $save->execute([
            $identity['sessionId'],
            $identity['userId'],
            $identity['guestId'],
            $projectId,
            $projectName,
            $payloadJson,
        ]);
        $project = $pdo->prepare("INSERT INTO FSG_StatManager_Projects
            (owner_key, project_id, name, payload_json, created_at, updated_at)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ON DUPLICATE KEY UPDATE
                name = VALUES(name),
                payload_json = VALUES(payload_json),
                updated_at = CURRENT_TIMESTAMP");
        $project->execute([$identity['ownerKey'], $projectId, $projectName, $payloadJson]);
        statReplaceDefinitions($pdo, $identity['ownerKey'], $projectId, is_array($state['project'] ?? null) ? $state['project'] : []);
        statTouchSession($pdo, $identity, true);
        $pdo->commit();
        statJson(['ok' => true, 'savedAt' => gmdate('c')]);
    }

    if ($action === 'asset' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        if ((string)($_POST['sessionId'] ?? '') !== $identity['sessionId']) {
            statJson(['ok' => false, 'error' => 'Session ownership check failed.'], 403);
        }
        if (!isset($_FILES['image']) || !is_uploaded_file($_FILES['image']['tmp_name'])) {
            statJson(['ok' => false, 'error' => 'No image upload was received.'], 400);
        }
        $upload = $_FILES['image'];
        if ((int)$upload['error'] !== UPLOAD_ERR_OK) {
            statJson(['ok' => false, 'error' => 'The image upload did not complete.'], 400);
        }
        $byteSize = (int)$upload['size'];
        if ($byteSize <= 0 || $byteSize > FSG_STAT_MAX_IMAGE_BYTES) {
            statJson(['ok' => false, 'error' => 'Image must be between 1 byte and 10 MB.'], 413);
        }
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($upload['tmp_name']) ?: '';
        $extensions = [
            'image/png' => 'png',
            'image/jpeg' => 'jpg',
            'image/webp' => 'webp',
            'image/gif' => 'gif',
            'image/avif' => 'avif',
        ];
        if (!isset($extensions[$mime])) {
            statJson(['ok' => false, 'error' => 'Only PNG, JPEG, WEBP, GIF, and AVIF images are accepted.'], 415);
        }

        $assetId = 'asset-' . bin2hex(random_bytes(12));
        $ownerFolder = preg_replace('/[^a-zA-Z0-9_-]+/', '-', $identity['ownerKey']) ?: 'guest';
        $uploadRoot = __DIR__ . '/uploads/StatSystemDesigner/' . $ownerFolder;
        if (!is_dir($uploadRoot) && !mkdir($uploadRoot, 0755, true) && !is_dir($uploadRoot)) {
            statJson(['ok' => false, 'error' => 'The server upload folder is unavailable.'], 500);
        }
        $filename = $assetId . '.' . $extensions[$mime];
        $absolutePath = $uploadRoot . '/' . $filename;
        if (!move_uploaded_file($upload['tmp_name'], $absolutePath)) {
            statJson(['ok' => false, 'error' => 'The server could not store the uploaded image.'], 500);
        }
        $relativePath = 'uploads/StatSystemDesigner/' . $ownerFolder . '/' . $filename;
        $asset = $pdo->prepare("INSERT INTO FSG_StatManager_Assets
            (asset_id, owner_key, session_id, original_name, relative_path, mime_type, byte_size)
            VALUES (?, ?, ?, ?, ?, ?, ?)");
        $asset->execute([
            $assetId,
            $identity['ownerKey'],
            $identity['sessionId'],
            substr((string)$upload['name'], 0, 255),
            $relativePath,
            $mime,
            $byteSize,
        ]);
        statJson(['ok' => true, 'assetId' => $assetId, 'url' => './' . $relativePath]);
    }

    statJson(['ok' => false, 'error' => 'Route not found.'], 404);
} catch (Throwable $error) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('StatSystemDesigner error: ' . $error->getMessage());
    statJson(['ok' => false, 'error' => 'The server could not complete that request.'], 500);
}
