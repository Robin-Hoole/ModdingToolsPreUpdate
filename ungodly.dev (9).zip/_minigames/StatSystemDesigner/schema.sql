-- StatSystemDesigner production schema
-- Import once into the same MySQL database used by ../_private/AuthShared.php.
-- Shared FSG_users, FSG_auth_sessions, and FSG_server_sessions remain owned by
-- AuthShared.php so StatSystemDesigner uses the same account and 12-hour token.

CREATE TABLE IF NOT EXISTS FSG_StatManager_Guests (
  guest_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  token_hash CHAR(64) NOT NULL,
  display_name VARCHAR(64) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (guest_id),
  UNIQUE KEY uq_FSG_StatManager_Guests_token (token_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_StatManager_Sessions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id VARCHAR(64) NOT NULL,
  user_id BIGINT UNSIGNED NULL,
  guest_id BIGINT UNSIGNED NULL,
  actor_type VARCHAR(16) NOT NULL,
  display_name VARCHAR(64) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_saved_at TIMESTAMP NULL DEFAULT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uq_FSG_StatManager_Sessions_session (session_id),
  KEY idx_FSG_StatManager_Sessions_user (user_id, last_seen_at),
  KEY idx_FSG_StatManager_Sessions_guest (guest_id, last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_StatManager_PlayerProgress (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id VARCHAR(64) NOT NULL,
  user_id BIGINT UNSIGNED NULL,
  guest_id BIGINT UNSIGNED NULL,
  project_id VARCHAR(128) NOT NULL,
  project_name VARCHAR(255) NOT NULL,
  payload_json LONGTEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_FSG_StatManager_PlayerProgress_session (session_id),
  KEY idx_FSG_StatManager_PlayerProgress_user (user_id, updated_at),
  KEY idx_FSG_StatManager_PlayerProgress_guest (guest_id, updated_at),
  KEY idx_FSG_StatManager_PlayerProgress_project (project_id, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_StatManager_Projects (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_key VARCHAR(96) NOT NULL,
  project_id VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  payload_json LONGTEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_FSG_StatManager_Projects_owner_project (owner_key, project_id),
  KEY idx_FSG_StatManager_Projects_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_StatManager_Assets (
  asset_id VARCHAR(80) NOT NULL,
  owner_key VARCHAR(96) NOT NULL,
  session_id VARCHAR(64) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  relative_path VARCHAR(500) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  byte_size BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (asset_id),
  KEY idx_FSG_StatManager_Assets_owner (owner_key, created_at),
  KEY idx_FSG_StatManager_Assets_session (session_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Searchable normalized authoring definitions. The complete project JSON is
-- also retained above, providing reliable round-trip recovery.
CREATE TABLE IF NOT EXISTS FSG_StatManager_Definitions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_key VARCHAR(96) NOT NULL,
  project_id VARCHAR(128) NOT NULL,
  definition_type VARCHAR(32) NOT NULL,
  definition_id VARCHAR(128) NOT NULL,
  parent_id VARCHAR(128) NOT NULL DEFAULT '',
  display_name VARCHAR(255) NOT NULL DEFAULT '',
  sort_order INT NOT NULL DEFAULT 0,
  payload_json LONGTEXT NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_FSG_StatManager_Definitions_owner
    (owner_key, project_id, definition_type, definition_id),
  KEY idx_FSG_StatManager_Definitions_project
    (owner_key, project_id, definition_type, sort_order),
  KEY idx_FSG_StatManager_Definitions_parent
    (owner_key, project_id, parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
