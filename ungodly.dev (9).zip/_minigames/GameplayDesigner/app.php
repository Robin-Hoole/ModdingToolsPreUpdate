<?php
declare(strict_types=1);

/**
 * GameplayDesigner production API.
 *
 * Install beside Auth.php and the existing _private/AuthShared.php on
 * ungodly.dev. It deliberately reuses the same bearer token, cookie, account,
 * and server-session helpers as Dialogue Designer.
 */

require_once dirname(__DIR__) . '/_private/AuthShared.php';
fsgAuth_startSharedSession();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');

const GD_APP_KEY = 'GameplayDesigner';
const GD_SCHEMA_VERSION = '1.0.0';
const GD_MAX_JSON_BYTES = 16_777_216;
const GD_MAX_IMAGE_BYTES = 10_485_760;

function gdRespond(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function gdEnsureTables(PDO $pdo): void
{
    $userType = fsgAuth_sharedFsgUserIdSqlType($pdo);

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Map_Workspaces (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        session_id VARCHAR(96) NOT NULL,
        user_id {$userType} NOT NULL,
        project_name VARCHAR(190) NOT NULL DEFAULT 'GameplayDesigner Project',
        schema_version VARCHAR(24) NOT NULL DEFAULT '1.0.0',
        manifest_json LONGTEXT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Map_Workspaces_session (session_id),
        KEY idx_FSG_Map_Workspaces_user_updated (user_id, updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Map_Sequences (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        sequence_id VARCHAR(190) NOT NULL,
        sequence_name VARCHAR(255) NOT NULL DEFAULT '',
        scene_name VARCHAR(255) NOT NULL DEFAULT '',
        hierarchy_path TEXT NULL,
        sequence_json LONGTEXT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Map_Sequences_workspace_sequence (workspace_id, sequence_id),
        KEY idx_FSG_Map_Sequences_workspace_sort (workspace_id, sort_order),
        CONSTRAINT fk_FSG_Map_Sequences_workspace FOREIGN KEY (workspace_id)
            REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Map_Components (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        sequence_id VARCHAR(190) NOT NULL,
        component_id VARCHAR(190) NOT NULL,
        component_type VARCHAR(255) NOT NULL,
        component_name VARCHAR(255) NOT NULL DEFAULT '',
        category VARCHAR(80) NOT NULL DEFAULT '',
        component_json LONGTEXT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Map_Components_workspace_component (workspace_id, component_id),
        KEY idx_FSG_Map_Components_sequence (workspace_id, sequence_id, sort_order),
        CONSTRAINT fk_FSG_Map_Components_workspace FOREIGN KEY (workspace_id)
            REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Map_Maps (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        map_id VARCHAR(190) NOT NULL,
        map_name VARCHAR(255) NOT NULL DEFAULT '',
        map_json LONGTEXT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Map_Maps_workspace_map (workspace_id, map_id),
        CONSTRAINT fk_FSG_Map_Maps_workspace FOREIGN KEY (workspace_id)
            REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Inventory_Items (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        item_id VARCHAR(190) NOT NULL,
        display_name VARCHAR(255) NOT NULL DEFAULT '',
        internal_name VARCHAR(255) NOT NULL DEFAULT '',
        category VARCHAR(100) NOT NULL DEFAULT '',
        quantity INT NOT NULL DEFAULT 0,
        maximum_stack_size INT NOT NULL DEFAULT 1,
        item_json LONGTEXT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Inventory_Items_workspace_item (workspace_id, item_id),
        KEY idx_FSG_Inventory_Items_workspace_category (workspace_id, category),
        CONSTRAINT fk_FSG_Inventory_Items_workspace FOREIGN KEY (workspace_id)
            REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Inventory_ItemActions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        item_id VARCHAR(190) NOT NULL,
        action_id VARCHAR(190) NOT NULL,
        action_type VARCHAR(100) NOT NULL DEFAULT '',
        action_json LONGTEXT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Inventory_ItemActions_action (workspace_id, item_id, action_id),
        KEY idx_FSG_Inventory_ItemActions_item (workspace_id, item_id, sort_order),
        CONSTRAINT fk_FSG_Inventory_ItemActions_workspace FOREIGN KEY (workspace_id)
            REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Inventory_SlotSets (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        slot_set_id VARCHAR(190) NOT NULL,
        slot_set_name VARCHAR(255) NOT NULL DEFAULT '',
        slot_set_json LONGTEXT NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Inventory_SlotSets_set (workspace_id, slot_set_id),
        CONSTRAINT fk_FSG_Inventory_SlotSets_workspace FOREIGN KEY (workspace_id)
            REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Inventory_Assets (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        workspace_id BIGINT UNSIGNED NOT NULL,
        asset_id VARCHAR(190) NOT NULL,
        original_name VARCHAR(255) NOT NULL,
        stored_path TEXT NOT NULL,
        public_url TEXT NOT NULL,
        mime_type VARCHAR(100) NOT NULL,
        byte_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
        sha256 CHAR(64) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Inventory_Assets_asset (workspace_id, asset_id),
        CONSTRAINT fk_FSG_Inventory_Assets_workspace FOREIGN KEY (workspace_id)
            REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function gdReadBody(): array
{
    $length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > GD_MAX_JSON_BYTES) {
        gdRespond(['success' => false, 'error' => 'JSON request is too large.'], 413);
    }
    return fsgAuth_requestBody();
}

function gdRequireUser(PDO $pdo): int
{
    $userId = fsgAuth_currentUserIdFromRequest($pdo);
    if ($userId <= 0) {
        gdRespond(['success' => false, 'error' => 'Shared account login required.'], 401);
    }
    return $userId;
}

function gdValidateManifest(array $manifest): void
{
    if (($manifest['format'] ?? '') !== 'FSG.GameplayDesigner') {
        gdRespond(['success' => false, 'error' => 'Unsupported manifest format.'], 422);
    }
    if (($manifest['schemaVersion'] ?? '') !== GD_SCHEMA_VERSION) {
        gdRespond(['success' => false, 'error' => 'Unsupported schemaVersion.'], 422);
    }
    if (!is_array($manifest['inventory'] ?? null) ||
        ($manifest['inventory']['tablePrefix'] ?? '') !== 'FSG_Inventory_') {
        gdRespond(['success' => false, 'error' => 'Inventory table prefix must be FSG_Inventory_.'], 422);
    }
    if (!is_array($manifest['maps'] ?? null) ||
        ($manifest['maps']['tablePrefix'] ?? '') !== 'FSG_Map_') {
        gdRespond(['success' => false, 'error' => 'Map table prefix must be FSG_Map_.'], 422);
    }
    if (!is_array($manifest['sequences'] ?? null)) {
        gdRespond(['success' => false, 'error' => 'Sequences must be an array.'], 422);
    }
}

function gdSessionId(): string
{
    return 'GD-' . strtoupper(bin2hex(random_bytes(4))) . '-' . strtoupper(bin2hex(random_bytes(4)));
}

function gdWorkspace(PDO $pdo, int $userId, string $sessionId): ?array
{
    $stmt = $pdo->prepare('SELECT id, session_id, user_id, project_name, schema_version, manifest_json, created_at, updated_at
        FROM FSG_Map_Workspaces WHERE session_id = ? AND user_id = ? LIMIT 1');
    $stmt->execute([$sessionId, $userId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function gdReplaceChildren(PDO $pdo, int $workspaceId, array $manifest): void
{
    foreach (['FSG_Map_Sequences', 'FSG_Map_Components', 'FSG_Map_Maps', 'FSG_Inventory_Items', 'FSG_Inventory_ItemActions', 'FSG_Inventory_SlotSets'] as $table) {
        $pdo->prepare("DELETE FROM {$table} WHERE workspace_id = ?")->execute([$workspaceId]);
    }

    $sequenceStmt = $pdo->prepare('INSERT INTO FSG_Map_Sequences
        (workspace_id, sequence_id, sequence_name, scene_name, hierarchy_path, sequence_json, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?)');
    $componentStmt = $pdo->prepare('INSERT INTO FSG_Map_Components
        (workspace_id, sequence_id, component_id, component_type, component_name, category, component_json, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (($manifest['sequences'] ?? []) as $sequenceIndex => $sequence) {
        if (!is_array($sequence)) continue;
        $sequenceId = trim((string)($sequence['sequenceId'] ?? ''));
        if ($sequenceId === '') $sequenceId = 'sequence-' . $sequenceIndex;
        $sequenceStmt->execute([
            $workspaceId,
            $sequenceId,
            (string)($sequence['sequenceName'] ?? ''),
            (string)($sequence['sceneName'] ?? ''),
            (string)($sequence['hierarchyPath'] ?? ''),
            json_encode($sequence, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            $sequenceIndex
        ]);
        foreach (($sequence['components'] ?? []) as $componentIndex => $component) {
            if (!is_array($component)) continue;
            $componentId = trim((string)($component['componentId'] ?? ''));
            if ($componentId === '') $componentId = $sequenceId . '-component-' . $componentIndex;
            $componentStmt->execute([
                $workspaceId,
                $sequenceId,
                $componentId,
                (string)($component['componentType'] ?? ''),
                (string)($component['componentName'] ?? ''),
                (string)($component['category'] ?? ''),
                json_encode($component, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                $componentIndex
            ]);
        }
    }

    $mapStmt = $pdo->prepare('INSERT INTO FSG_Map_Maps
        (workspace_id, map_id, map_name, map_json, sort_order) VALUES (?, ?, ?, ?, ?)');
    foreach (($manifest['maps']['maps'] ?? []) as $mapIndex => $map) {
        if (!is_array($map)) continue;
        $mapStmt->execute([
            $workspaceId,
            (string)($map['mapId'] ?? ('map-' . $mapIndex)),
            (string)($map['name'] ?? ''),
            json_encode($map, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            $mapIndex
        ]);
    }

    $itemStmt = $pdo->prepare('INSERT INTO FSG_Inventory_Items
        (workspace_id, item_id, display_name, internal_name, category, quantity, maximum_stack_size, item_json, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $actionStmt = $pdo->prepare('INSERT INTO FSG_Inventory_ItemActions
        (workspace_id, item_id, action_id, action_type, action_json, sort_order) VALUES (?, ?, ?, ?, ?, ?)');
    foreach (($manifest['inventory']['itemDefinitions'] ?? []) as $itemIndex => $item) {
        if (!is_array($item)) continue;
        $itemId = (string)($item['itemId'] ?? ('item-' . $itemIndex));
        $itemStmt->execute([
            $workspaceId,
            $itemId,
            (string)($item['displayName'] ?? ''),
            (string)($item['internalName'] ?? ''),
            (string)($item['category'] ?? ''),
            max(0, (int)($item['quantity'] ?? 0)),
            max(1, (int)($item['maximumStackSize'] ?? 1)),
            json_encode($item, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            $itemIndex
        ]);
        foreach (($item['actions'] ?? []) as $actionIndex => $action) {
            if (!is_array($action)) continue;
            $actionStmt->execute([
                $workspaceId,
                $itemId,
                (string)($action['actionId'] ?? ($itemId . '-action-' . $actionIndex)),
                (string)($action['type'] ?? $action['actionType'] ?? ''),
                json_encode($action, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                $actionIndex
            ]);
        }
    }

    $slotStmt = $pdo->prepare('INSERT INTO FSG_Inventory_SlotSets
        (workspace_id, slot_set_id, slot_set_name, slot_set_json, sort_order) VALUES (?, ?, ?, ?, ?)');
    foreach (($manifest['inventory']['slotSets'] ?? []) as $slotIndex => $slotSet) {
        if (!is_array($slotSet)) continue;
        $slotStmt->execute([
            $workspaceId,
            (string)($slotSet['slotSetId'] ?? ('slot-set-' . $slotIndex)),
            (string)($slotSet['name'] ?? $slotSet['slotSetName'] ?? ''),
            json_encode($slotSet, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            $slotIndex
        ]);
    }
}

function gdSave(PDO $pdo, int $userId, array $body): never
{
    $manifest = $body['manifest'] ?? null;
    if (!is_array($manifest)) gdRespond(['success' => false, 'error' => 'manifest is required.'], 422);
    gdValidateManifest($manifest);

    $sessionId = trim((string)($body['sessionId'] ?? $manifest['dialogueDesignerGlobals']['serverSessionId'] ?? ''));
    if ($sessionId === '') $sessionId = gdSessionId();
    if (!preg_match('/^[A-Za-z0-9_-]{6,96}$/', $sessionId)) {
        gdRespond(['success' => false, 'error' => 'Invalid session ID.'], 422);
    }
    $manifest['dialogueDesignerGlobals']['serverSessionId'] = $sessionId;
    $manifest['exportedAtUtc'] = gmdate('c');
    $projectName = trim((string)($body['projectName'] ?? $manifest['projectName'] ?? 'GameplayDesigner Project'));
    $manifestJson = json_encode($manifest, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($manifestJson === false || strlen($manifestJson) > GD_MAX_JSON_BYTES) {
        gdRespond(['success' => false, 'error' => 'Manifest could not be encoded or is too large.'], 413);
    }

    $pdo->beginTransaction();
    try {
        $existing = gdWorkspace($pdo, $userId, $sessionId);
        if ($existing) {
            $stmt = $pdo->prepare('UPDATE FSG_Map_Workspaces SET project_name = ?, schema_version = ?, manifest_json = ?, updated_at = UTC_TIMESTAMP() WHERE id = ?');
            $stmt->execute([$projectName, GD_SCHEMA_VERSION, $manifestJson, $existing['id']]);
            $workspaceId = (int)$existing['id'];
        } else {
            $stmt = $pdo->prepare('INSERT INTO FSG_Map_Workspaces (session_id, user_id, project_name, schema_version, manifest_json) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$sessionId, $userId, $projectName, GD_SCHEMA_VERSION, $manifestJson]);
            $workspaceId = (int)$pdo->lastInsertId();
        }
        gdReplaceChildren($pdo, $workspaceId, $manifest);
        $pdo->commit();
    } catch (Throwable $error) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('GameplayDesigner save failed: ' . $error->getMessage());
        gdRespond(['success' => false, 'error' => 'The project could not be saved.'], 500);
    }

    fsgAuth_touchServerSession($pdo, $userId, GD_APP_KEY, $sessionId, 'edit');
    gdRespond([
        'success' => true,
        'sessionId' => $sessionId,
        'serverSessionId' => $sessionId,
        'schemaVersion' => GD_SCHEMA_VERSION,
        'counts' => [
            'sequences' => count($manifest['sequences']),
            'items' => count($manifest['inventory']['itemDefinitions'] ?? []),
            'maps' => count($manifest['maps']['maps'] ?? [])
        ]
    ]);
}

function gdLoad(PDO $pdo, int $userId, string $sessionId): never
{
    $row = gdWorkspace($pdo, $userId, $sessionId);
    if (!$row) gdRespond(['success' => false, 'error' => 'Project not found.'], 404);
    fsgAuth_touchServerSession($pdo, $userId, GD_APP_KEY, $sessionId, 'view');
    gdRespond([
        'success' => true,
        'sessionId' => $sessionId,
        'projectName' => $row['project_name'],
        'manifest' => json_decode((string)$row['manifest_json'], true),
        'updatedAt' => $row['updated_at']
    ]);
}

function gdLoadLatest(PDO $pdo, int $userId): never
{
    $stmt = $pdo->prepare('SELECT session_id FROM FSG_Map_Workspaces WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1');
    $stmt->execute([$userId]);
    $sessionId = (string)($stmt->fetchColumn() ?: '');
    if ($sessionId === '') gdRespond(['success' => true, 'sessionId' => '', 'manifest' => null]);
    gdLoad($pdo, $userId, $sessionId);
}

function gdList(PDO $pdo, int $userId): never
{
    $stmt = $pdo->prepare('SELECT session_id, project_name, schema_version, created_at, updated_at
        FROM FSG_Map_Workspaces WHERE user_id = ? ORDER BY updated_at DESC LIMIT 100');
    $stmt->execute([$userId]);
    gdRespond(['success' => true, 'projects' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
}

function gdUpload(PDO $pdo, int $userId): never
{
    $sessionId = trim((string)($_POST['sessionId'] ?? ''));
    $workspace = gdWorkspace($pdo, $userId, $sessionId);
    if (!$workspace) gdRespond(['success' => false, 'error' => 'Save the project before uploading images.'], 404);
    if (!isset($_FILES['image']) || !is_uploaded_file($_FILES['image']['tmp_name'])) {
        gdRespond(['success' => false, 'error' => 'image upload is required.'], 422);
    }
    $file = $_FILES['image'];
    if ((int)$file['size'] <= 0 || (int)$file['size'] > GD_MAX_IMAGE_BYTES) {
        gdRespond(['success' => false, 'error' => 'Image must be between 1 byte and 10 MB.'], 413);
    }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string)$finfo->file($file['tmp_name']);
    $extensions = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    if (!isset($extensions[$mime])) gdRespond(['success' => false, 'error' => 'Only PNG, JPEG, WEBP, and GIF are accepted.'], 415);

    $assetId = 'asset-' . bin2hex(random_bytes(12));
    $directory = __DIR__ . '/uploads/GameplayDesigner/' . $userId . '/' . preg_replace('/[^A-Za-z0-9_-]/', '_', $sessionId);
    if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
        gdRespond(['success' => false, 'error' => 'Upload directory could not be created.'], 500);
    }
    $filename = $assetId . '.' . $extensions[$mime];
    $path = $directory . '/' . $filename;
    if (!move_uploaded_file($file['tmp_name'], $path)) {
        gdRespond(['success' => false, 'error' => 'Image could not be stored.'], 500);
    }
    $publicUrl = '/uploads/GameplayDesigner/' . $userId . '/' . rawurlencode($sessionId) . '/' . $filename;
    $stmt = $pdo->prepare('INSERT INTO FSG_Inventory_Assets
        (workspace_id, asset_id, original_name, stored_path, public_url, mime_type, byte_size, sha256)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([
        $workspace['id'],
        $assetId,
        basename((string)$file['name']),
        $path,
        $publicUrl,
        $mime,
        (int)$file['size'],
        hash_file('sha256', $path)
    ]);
    gdRespond(['success' => true, 'assetId' => $assetId, 'url' => $publicUrl, 'mimeType' => $mime]);
}

try {
    $action = (string)($_GET['action'] ?? 'health');
    if ($action === 'health') {
        gdRespond([
            'success' => true,
            'app' => GD_APP_KEY,
            'schemaVersion' => GD_SCHEMA_VERSION,
            'auth' => 'shared Auth.php bearer/cookie',
            'prefixes' => ['inventory' => 'FSG_Inventory_', 'map' => 'FSG_Map_']
        ]);
    }

    $pdo = fsgAuth_dbConnection();
    fsgAuth_ensureAccountTables($pdo);
    fsgAuth_touchSharedSession();

    if ($action === 'status' || $action === 'authStatus') {
        gdRespond(['success' => true] + fsgAuth_authPayload($pdo));
    }
    if ($action === 'register') {
        gdRespond(['success' => true] + fsgAuth_registerAccount($pdo, gdReadBody()));
    }
    if ($action === 'login') {
        gdRespond(['success' => true] + fsgAuth_loginAccount($pdo, gdReadBody()));
    }
    if ($action === 'logout') {
        fsgAuth_logout($pdo);
        gdRespond(['success' => true, 'loggedIn' => false, 'user' => null, 'sessions' => []]);
    }

    gdEnsureTables($pdo);
    $userId = gdRequireUser($pdo);

    switch ($action) {
        case 'saveSession': gdSave($pdo, $userId, gdReadBody());
        case 'loadSession': gdLoad($pdo, $userId, trim((string)($_GET['sessionId'] ?? '')));
        case 'loadLatest': gdLoadLatest($pdo, $userId);
        case 'listSessions': gdList($pdo, $userId);
        case 'uploadAsset': gdUpload($pdo, $userId);
        case 'authStatus': gdRespond(['success' => true, 'auth' => fsgAuth_authPayload($pdo)]);
        default: gdRespond(['success' => false, 'error' => 'Unknown action.'], 404);
    }
} catch (Throwable $error) {
    error_log('GameplayDesigner API error: ' . $error->getMessage());
    gdRespond(['success' => false, 'error' => 'GameplayDesigner server error.'], 500);
}
