
-- FSG Browser RPG designers: MySQL 8 / MariaDB 10.5+
-- Shared account tables (FSG_users and FSG_auth_sessions) are managed by AuthShared.php.

CREATE TABLE IF NOT EXISTS FSG_Gameplay_Guests (
  guest_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  token_hash CHAR(64) NOT NULL UNIQUE,
  display_name VARCHAR(64) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Gameplay_Sessions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  session_id VARCHAR(64) NOT NULL UNIQUE,
  user_id INT NULL,
  guest_id BIGINT UNSIGNED NULL,
  actor_type VARCHAR(16) NOT NULL,
  display_name VARCHAR(64) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_saved_at TIMESTAMP NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_browserrpg_stat_session_user (user_id,last_seen_at),
  KEY idx_browserrpg_stat_session_guest (guest_id,last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Gameplay_PlayerProgress (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  session_id VARCHAR(64) NOT NULL UNIQUE,
  user_id INT NULL,
  guest_id BIGINT UNSIGNED NULL,
  project_id VARCHAR(128) NOT NULL,
  project_name VARCHAR(255) NOT NULL,
  payload_json LONGTEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_browserrpg_stat_progress_user (user_id,updated_at),
  KEY idx_browserrpg_stat_progress_guest (guest_id,updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Gameplay_Projects (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_key VARCHAR(96) NOT NULL,
  project_id VARCHAR(128) NOT NULL,
  name VARCHAR(255) NOT NULL,
  payload_json LONGTEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_browserrpg_stat_owner_project (owner_key,project_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Gameplay_Assets (
  asset_id VARCHAR(80) PRIMARY KEY,
  owner_key VARCHAR(96) NOT NULL,
  session_id VARCHAR(64) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  relative_path VARCHAR(500) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  byte_size BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Map_Workspaces (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  session_id VARCHAR(96) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  project_name VARCHAR(190) NOT NULL DEFAULT 'GameplayDesigner Project',
  schema_version VARCHAR(24) NOT NULL DEFAULT '1.0.0',
  manifest_json LONGTEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_browserrpg_map_user_updated (user_id,updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Map_Sequences (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  workspace_id BIGINT UNSIGNED NOT NULL,
  sequence_id VARCHAR(190) NOT NULL,
  sequence_name VARCHAR(255) NOT NULL DEFAULT '',
  scene_name VARCHAR(255) NOT NULL DEFAULT '',
  hierarchy_path TEXT NULL,
  sequence_json LONGTEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_browserrpg_map_sequence (workspace_id,sequence_id),
  CONSTRAINT fk_browserrpg_sequence_workspace FOREIGN KEY (workspace_id)
    REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Map_Components (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  workspace_id BIGINT UNSIGNED NOT NULL,
  sequence_id VARCHAR(190) NOT NULL,
  component_id VARCHAR(190) NOT NULL,
  component_type VARCHAR(255) NOT NULL,
  component_name VARCHAR(255) NOT NULL DEFAULT '',
  category VARCHAR(80) NOT NULL DEFAULT '',
  component_json LONGTEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_browserrpg_map_component (workspace_id,component_id),
  CONSTRAINT fk_browserrpg_component_workspace FOREIGN KEY (workspace_id)
    REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Map_Maps (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  workspace_id BIGINT UNSIGNED NOT NULL,
  map_id VARCHAR(190) NOT NULL,
  map_name VARCHAR(255) NOT NULL DEFAULT '',
  map_json LONGTEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_browserrpg_map (workspace_id,map_id),
  CONSTRAINT fk_browserrpg_map_workspace FOREIGN KEY (workspace_id)
    REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Inventory_Items (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  workspace_id BIGINT UNSIGNED NOT NULL,
  item_id VARCHAR(190) NOT NULL,
  display_name VARCHAR(255) NOT NULL DEFAULT '',
  internal_name VARCHAR(255) NOT NULL DEFAULT '',
  category VARCHAR(100) NOT NULL DEFAULT '',
  quantity INT NOT NULL DEFAULT 0,
  maximum_stack_size INT NOT NULL DEFAULT 1,
  item_json LONGTEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_browserrpg_inventory_item (workspace_id,item_id),
  CONSTRAINT fk_browserrpg_item_workspace FOREIGN KEY (workspace_id)
    REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Inventory_ItemActions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  workspace_id BIGINT UNSIGNED NOT NULL,
  item_id VARCHAR(190) NOT NULL,
  action_id VARCHAR(190) NOT NULL,
  action_type VARCHAR(100) NOT NULL DEFAULT '',
  action_json LONGTEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  UNIQUE KEY uq_browserrpg_inventory_action (workspace_id,item_id,action_id),
  CONSTRAINT fk_browserrpg_action_workspace FOREIGN KEY (workspace_id)
    REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Inventory_SlotSets (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  workspace_id BIGINT UNSIGNED NOT NULL,
  slot_set_id VARCHAR(190) NOT NULL,
  slot_set_name VARCHAR(255) NOT NULL DEFAULT '',
  slot_set_json LONGTEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  UNIQUE KEY uq_browserrpg_inventory_slot_set (workspace_id,slot_set_id),
  CONSTRAINT fk_browserrpg_slot_workspace FOREIGN KEY (workspace_id)
    REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Inventory_Assets (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  workspace_id BIGINT UNSIGNED NOT NULL,
  asset_id VARCHAR(190) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  stored_path TEXT NOT NULL,
  public_url TEXT NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  byte_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
  sha256 CHAR(64) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_browserrpg_inventory_asset (workspace_id,asset_id),
  CONSTRAINT fk_browserrpg_asset_workspace FOREIGN KEY (workspace_id)
    REFERENCES FSG_Map_Workspaces(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


