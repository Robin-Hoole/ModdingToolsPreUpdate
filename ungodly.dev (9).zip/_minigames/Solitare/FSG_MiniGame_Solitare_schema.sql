-- FSG MiniGame: Solitare
-- MySQL 5.7+ / MariaDB 10.2+
-- Import this file once into the same database used by ../db.php.

SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE IF NOT EXISTS `FSG_MiniGame_Solitare_PlayerProfiles` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `session_id` VARCHAR(64) NOT NULL,
    `display_name` VARCHAR(100) NULL,
    `games_started` INT UNSIGNED NOT NULL DEFAULT 0,
    `games_won` INT UNSIGNED NOT NULL DEFAULT 0,
    `best_score` INT UNSIGNED NOT NULL DEFAULT 0,
    `best_moves` INT UNSIGNED NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `last_seen_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_FSG_MiniGame_Solitare_ProfileSession` (`session_id`),
    KEY `idx_FSG_MiniGame_Solitare_ProfileWins` (`games_won`),
    KEY `idx_FSG_MiniGame_Solitare_ProfileScore` (`best_score`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FSG_MiniGame_Solitare_GameSaves` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `session_id` VARCHAR(64) NOT NULL,
    `game_state_json` LONGTEXT NOT NULL,
    `moves` INT UNSIGNED NOT NULL DEFAULT 0,
    `score` INT UNSIGNED NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_FSG_MiniGame_Solitare_SaveSession` (`session_id`),
    KEY `idx_FSG_MiniGame_Solitare_SaveUpdated` (`updated_at`),
    CONSTRAINT `fk_FSG_MiniGame_Solitare_SaveProfile`
        FOREIGN KEY (`session_id`)
        REFERENCES `FSG_MiniGame_Solitare_PlayerProfiles` (`session_id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `chk_FSG_MiniGame_Solitare_GameStateJson`
        CHECK (JSON_VALID(`game_state_json`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FSG_MiniGame_Solitare_CardArt` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `session_id` VARCHAR(64) NOT NULL,
    `card_key` VARCHAR(32) NOT NULL,
    `source_mode` ENUM('url', 'html') NOT NULL,
    `source_value` MEDIUMTEXT NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_FSG_MiniGame_Solitare_CardArt` (`session_id`, `card_key`),
    KEY `idx_FSG_MiniGame_Solitare_CardKey` (`card_key`),
    CONSTRAINT `fk_FSG_MiniGame_Solitare_CardArtProfile`
        FOREIGN KEY (`session_id`)
        REFERENCES `FSG_MiniGame_Solitare_PlayerProfiles` (`session_id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `FSG_MiniGame_Solitare_GameResults` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `session_id` VARCHAR(64) NOT NULL,
    `won` TINYINT(1) NOT NULL DEFAULT 0,
    `moves` INT UNSIGNED NOT NULL DEFAULT 0,
    `score` INT UNSIGNED NOT NULL DEFAULT 0,
    `elapsed_seconds` INT UNSIGNED NOT NULL DEFAULT 0,
    `completed_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_FSG_MiniGame_Solitare_ResultSession` (`session_id`),
    KEY `idx_FSG_MiniGame_Solitare_ResultLeaderboard` (`won`, `score`, `moves`),
    KEY `idx_FSG_MiniGame_Solitare_ResultCompleted` (`completed_at`),
    CONSTRAINT `fk_FSG_MiniGame_Solitare_ResultProfile`
        FOREIGN KEY (`session_id`)
        REFERENCES `FSG_MiniGame_Solitare_PlayerProfiles` (`session_id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
