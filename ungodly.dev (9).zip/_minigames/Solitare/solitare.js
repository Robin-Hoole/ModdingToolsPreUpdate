"use strict";

const Solitare = (() => {
    const API_URL = "solitare.php";
    const STORAGE_GAME = "FSG_MiniGame_Solitare_Game";
    const STORAGE_ART = "FSG_MiniGame_Solitare_CardArt";
    const STORAGE_SESSION = "FSG_MiniGame_Solitare_Session";
    const SUITS = ["hearts", "diamonds", "clubs", "spades"];
    const SUIT_GLYPHS = { hearts: "♥", diamonds: "♦", clubs: "♣", spades: "♠" };
    const SUIT_EMOJI = { hearts: "♥️", diamonds: "♦️", clubs: "♣️", spades: "♠️" };
    const SUIT_NAMES = { hearts: "Hearts", diamonds: "Diamonds", clubs: "Clubs", spades: "Spades" };
    const RANKS = ["", "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

    let game = null;
    let history = [];
    let selected = null;
    let cardArt = {};
    let editorCard = { suit: "hearts", rank: 1 };
    let editorFileData = "";
    let saveTimer = null;
    let toastTimer = null;

    const elements = {};

    function cacheElements() {
        [
            "moves-stat", "score-stat", "save-status", "undo-button", "new-game-button",
            "session-button", "studio-button", "stock-pile", "stock-count", "waste-pile",
            "foundation-piles", "tableau-piles", "toast", "win-overlay", "win-summary",
            "deal-again-button", "session-overlay", "session-id", "copy-session-button",
            "new-session-button", "load-session-button", "save-session-button",
            "studio-overlay", "card-picker", "editing-card-name", "card-preview", "art-mode",
            "url-controls", "html-controls", "default-hint", "art-url", "art-file", "art-html",
            "save-card-art-button", "reset-card-art-button"
        ].forEach((id) => {
            elements[id] = document.getElementById(id);
        });
    }

    function createDeck() {
        return SUITS.flatMap((suit) =>
            Array.from({ length: 13 }, (_, index) => ({
                id: `${suit}-${index + 1}`,
                suit,
                rank: index + 1,
                faceUp: false
            }))
        );
    }

    function shuffle(cards) {
        const output = cards.map((card) => ({ ...card }));
        for (let index = output.length - 1; index > 0; index -= 1) {
            const other = Math.floor(Math.random() * (index + 1));
            [output[index], output[other]] = [output[other], output[index]];
        }
        return output;
    }

    function makeNewGame() {
        const deck = shuffle(createDeck());
        const tableau = Array.from({ length: 7 }, () => []);
        let cursor = 0;

        for (let column = 0; column < 7; column += 1) {
            for (let row = 0; row <= column; row += 1) {
                tableau[column].push({
                    ...deck[cursor],
                    faceUp: row === column
                });
                cursor += 1;
            }
        }

        return {
            version: 1,
            stock: deck.slice(cursor),
            waste: [],
            foundations: [[], [], [], []],
            tableau,
            moves: 0,
            score: 0,
            startedAt: new Date().toISOString()
        };
    }

    function isValidGame(value) {
        return value &&
            Array.isArray(value.stock) &&
            Array.isArray(value.waste) &&
            Array.isArray(value.foundations) &&
            value.foundations.length === 4 &&
            Array.isArray(value.tableau) &&
            value.tableau.length === 7;
    }

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function isRed(card) {
        return card.suit === "hearts" || card.suit === "diamonds";
    }

    function artKey(suit, rank) {
        return `${suit}-${rank}`;
    }

    function loadLocalData() {
        try {
            const localGame = JSON.parse(localStorage.getItem(STORAGE_GAME));
            game = isValidGame(localGame) ? localGame : makeNewGame();
        } catch (error) {
            game = makeNewGame();
        }

        try {
            const localArt = JSON.parse(localStorage.getItem(STORAGE_ART));
            cardArt = localArt && typeof localArt === "object" ? localArt : {};
        } catch (error) {
            cardArt = {};
        }

        const existingSession = localStorage.getItem(STORAGE_SESSION);
        elements["session-id"].value = existingSession || generateSessionId();
        localStorage.setItem(STORAGE_SESSION, elements["session-id"].value);
    }

    function saveLocalData() {
        try {
            localStorage.setItem(STORAGE_GAME, JSON.stringify(game));
            localStorage.setItem(STORAGE_ART, JSON.stringify(cardArt));
            elements["save-status"].textContent = "Saved locally";
        } catch (error) {
            elements["save-status"].textContent = "Local save full";
            showToast("The selected image is too large for browser storage.");
        }
    }

    function scheduleSave() {
        saveLocalData();
        clearTimeout(saveTimer);
        saveTimer = setTimeout(() => {
            const sessionId = getSessionId();
            if (sessionId) {
                saveToServer(false);
            }
        }, 900);
    }

    function generateSessionId() {
        const randomPart = crypto.getRandomValues(new Uint32Array(3))
            .reduce((text, value) => text + value.toString(36), "");
        return `solitare_${Date.now().toString(36)}_${randomPart}`.slice(0, 64);
    }

    function getSessionId() {
        const value = elements["session-id"].value.trim();
        return /^[A-Za-z0-9_-]{6,64}$/.test(value) ? value : "";
    }

    function showToast(message) {
        clearTimeout(toastTimer);
        elements.toast.textContent = message;
        elements.toast.classList.add("show");
        toastTimer = setTimeout(() => elements.toast.classList.remove("show"), 2200);
    }

    function pushHistory() {
        history.push(clone(game));
        if (history.length > 50) {
            history.shift();
        }
    }

    function commitMove(nextGame, scoreChange = 0) {
        pushHistory();
        nextGame.moves = (nextGame.moves || 0) + 1;
        nextGame.score = Math.max(0, (nextGame.score || 0) + scoreChange);
        game = nextGame;
        selected = null;
        render();
        scheduleSave();
        checkForWin();
    }

    function getSourceCards(source, state = game) {
        if (!source) {
            return [];
        }
        if (source.kind === "waste") {
            return state.waste.slice(-1);
        }
        if (source.kind === "foundation") {
            return state.foundations[source.index].slice(-1);
        }
        if (source.kind === "tableau") {
            return state.tableau[source.index].slice(source.cardIndex);
        }
        return [];
    }

    function removeSource(state, source) {
        if (source.kind === "waste") {
            state.waste.pop();
            return;
        }
        if (source.kind === "foundation") {
            state.foundations[source.index].pop();
            return;
        }
        if (source.kind === "tableau") {
            state.tableau[source.index].splice(source.cardIndex);
            const exposed = state.tableau[source.index].at(-1);
            if (exposed && !exposed.faceUp) {
                exposed.faceUp = true;
                state.score = (state.score || 0) + 5;
            }
        }
    }

    function drawFromStock() {
        const next = clone(game);
        if (next.stock.length) {
            const card = next.stock.pop();
            next.waste.push({ ...card, faceUp: true });
            commitMove(next);
        } else if (next.waste.length) {
            next.stock = next.waste.reverse().map((card) => ({ ...card, faceUp: false }));
            next.waste = [];
            commitMove(next);
        }
    }

    function canMoveToTableau(cards, target) {
        if (!cards.length) {
            return false;
        }
        if (!target) {
            return cards[0].rank === 13;
        }
        return target.faceUp &&
            target.rank === cards[0].rank + 1 &&
            isRed(target) !== isRed(cards[0]);
    }

    function moveToTableau(source, targetIndex) {
        const moving = getSourceCards(source);
        if (!moving.length || (source.kind === "tableau" && source.index === targetIndex)) {
            return false;
        }

        const target = game.tableau[targetIndex].at(-1);
        if (!canMoveToTableau(moving, target)) {
            showToast("That card cannot move there.");
            return false;
        }

        const next = clone(game);
        const nextMoving = getSourceCards(source, next);
        removeSource(next, source);
        next.tableau[targetIndex].push(...nextMoving);
        const penalty = source.kind === "foundation" ? -10 : 0;
        commitMove(next, penalty);
        return true;
    }

    function canMoveToFoundation(card, foundation) {
        if (!card) {
            return false;
        }
        const target = foundation.at(-1);
        if (!target) {
            return card.rank === 1;
        }
        return target.suit === card.suit && target.rank + 1 === card.rank;
    }

    function moveToFoundation(source, targetIndex) {
        const moving = getSourceCards(source);
        if (moving.length !== 1 || !canMoveToFoundation(moving[0], game.foundations[targetIndex])) {
            showToast("That card is not ready for the foundation.");
            return false;
        }

        const next = clone(game);
        const nextCard = getSourceCards(source, next)[0];
        removeSource(next, source);
        next.foundations[targetIndex].push(nextCard);
        commitMove(next, 10);
        return true;
    }

    function autoFoundation(source) {
        const card = getSourceCards(source)[0];
        if (!card) {
            return;
        }
        const existing = game.foundations.findIndex((pile) => pile[0] && pile[0].suit === card.suit);
        const empty = game.foundations.findIndex((pile) => pile.length === 0);
        const targetIndex = existing >= 0 ? existing : empty;
        if (targetIndex >= 0) {
            moveToFoundation(source, targetIndex);
        }
    }

    function selectOrMoveTableau(columnIndex, cardIndex, card) {
        if (!card.faceUp) {
            return;
        }
        if (selected) {
            moveToTableau(selected, columnIndex);
        } else {
            selected = { kind: "tableau", index: columnIndex, cardIndex };
            render();
        }
    }

    function createCardElement(card, options = {}) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "card";

        if (!card) {
            button.classList.add("slot");
            button.textContent = options.placeholder || "";
            button.setAttribute("aria-label", options.label || "Empty card pile");
            return button;
        }

        if (!card.faceUp) {
            button.classList.add("card-back");
            button.innerHTML = '<span class="back-ornament">✦</span>';
            button.setAttribute("aria-label", "Face-down card");
            return button;
        }

        button.classList.add("card-face", isRed(card) ? "red" : "black");
        if (options.selected) {
            button.classList.add("selected");
        }
        button.setAttribute("aria-label", options.label || `${RANKS[card.rank]} of ${SUIT_NAMES[card.suit]}`);

        const custom = options.overrideArt || cardArt[artKey(card.suit, card.rank)];
        if (custom && custom.mode === "url" && custom.value) {
            const image = document.createElement("img");
            image.src = custom.value;
            image.alt = "";
            image.referrerPolicy = "no-referrer";
            button.appendChild(image);
        } else if (custom && custom.mode === "html" && custom.value) {
            const frame = document.createElement("iframe");
            frame.title = `${RANKS[card.rank]} of ${SUIT_NAMES[card.suit]} custom card art`;
            frame.setAttribute("sandbox", "");
            frame.srcdoc = custom.value;
            button.appendChild(frame);
        } else {
            button.innerHTML = `
                <span class="corner top"><b>${RANKS[card.rank]}</b><i>${SUIT_GLYPHS[card.suit]}</i></span>
                <span class="center-suit">${SUIT_EMOJI[card.suit]}</span>
                <span class="corner bottom"><b>${RANKS[card.rank]}</b><i>${SUIT_GLYPHS[card.suit]}</i></span>
            `;
        }

        return button;
    }

    function renderStock() {
        elements["stock-pile"].className = game.stock.length ? "card card-back" : "card card-back empty";
        elements["stock-pile"].innerHTML = game.stock.length
            ? `<span class="back-ornament">✦</span><small id="stock-count">${game.stock.length}</small>`
            : '<span class="back-ornament">↻</span>';
        elements["stock-pile"].setAttribute("aria-label", game.stock.length ? "Draw a card" : "Recycle waste pile");

        elements["waste-pile"].replaceChildren();
        const wasteCard = game.waste.at(-1);
        if (wasteCard) {
            const source = { kind: "waste" };
            const card = createCardElement(wasteCard, { selected: selected && selected.kind === "waste" });
            card.addEventListener("click", () => {
                if (selected && selected.kind !== "waste") {
                    selected = null;
                } else {
                    selected = selected ? null : source;
                }
                render();
            });
            card.addEventListener("dblclick", () => autoFoundation(source));
            elements["waste-pile"].appendChild(card);
        } else {
            elements["waste-pile"].appendChild(createCardElement(null, { label: "Empty waste pile" }));
        }
    }

    function renderFoundations() {
        elements["foundation-piles"].replaceChildren();
        game.foundations.forEach((pile, index) => {
            const card = pile.at(-1);
            const button = createCardElement(card, {
                placeholder: SUIT_GLYPHS[SUITS[index]],
                label: `${SUIT_NAMES[SUITS[index]]} foundation`,
                selected: selected && selected.kind === "foundation" && selected.index === index
            });
            button.addEventListener("click", () => {
                if (selected) {
                    moveToFoundation(selected, index);
                } else if (card) {
                    selected = { kind: "foundation", index };
                    render();
                }
            });
            elements["foundation-piles"].appendChild(button);
        });
    }

    function renderTableau() {
        elements["tableau-piles"].replaceChildren();
        game.tableau.forEach((pile, columnIndex) => {
            const column = document.createElement("div");
            column.className = "column";
            column.setAttribute("aria-label", `Tableau column ${columnIndex + 1}`);

            if (!pile.length) {
                const slot = createCardElement(null, { placeholder: "K", label: `Empty tableau column ${columnIndex + 1}` });
                slot.addEventListener("click", () => {
                    if (selected) {
                        moveToTableau(selected, columnIndex);
                    }
                });
                column.appendChild(slot);
            }

            pile.forEach((card, cardIndex) => {
                const wrapper = document.createElement("div");
                wrapper.className = "stacked-card";
                wrapper.style.top = `${cardIndex * (card.faceUp ? 34 : 18)}px`;
                wrapper.style.zIndex = cardIndex;

                const source = { kind: "tableau", index: columnIndex, cardIndex };
                const isSelected = selected &&
                    selected.kind === "tableau" &&
                    selected.index === columnIndex &&
                    selected.cardIndex === cardIndex;
                const cardButton = createCardElement(card, { selected: isSelected });

                cardButton.addEventListener("click", (event) => {
                    event.stopPropagation();
                    selectOrMoveTableau(columnIndex, cardIndex, card);
                });
                cardButton.addEventListener("dblclick", (event) => {
                    event.stopPropagation();
                    if (cardIndex === pile.length - 1) {
                        autoFoundation(source);
                    }
                });

                wrapper.appendChild(cardButton);
                column.appendChild(wrapper);
            });
            elements["tableau-piles"].appendChild(column);
        });
    }

    function renderStats() {
        elements["moves-stat"].textContent = `${game.moves || 0} move${game.moves === 1 ? "" : "s"}`;
        elements["score-stat"].textContent = `${game.score || 0} score`;
        elements["undo-button"].disabled = history.length === 0;
    }

    function render() {
        renderStock();
        renderFoundations();
        renderTableau();
        renderStats();
    }

    function undo() {
        if (!history.length) {
            return;
        }
        game = history.pop();
        selected = null;
        render();
        scheduleSave();
    }

    function startNewGame(ask = true) {
        if (ask && game && game.moves > 0 && !window.confirm("Start a new game and replace the current deal?")) {
            return;
        }
        game = makeNewGame();
        history = [];
        selected = null;
        elements["win-overlay"].classList.add("hidden");
        render();
        scheduleSave();
    }

    function checkForWin() {
        const foundationCount = game.foundations.reduce((total, pile) => total + pile.length, 0);
        if (foundationCount !== 52) {
            return;
        }
        elements["win-summary"].textContent = `You cleared the table in ${game.moves} moves with a score of ${game.score}.`;
        elements["win-overlay"].classList.remove("hidden");
        recordWin();
    }

    function buildCardPicker() {
        elements["card-picker"].replaceChildren();
        SUITS.forEach((suit) => {
            const group = document.createElement("section");
            group.className = `picker-suit ${isRed({ suit }) ? "red" : ""}`;
            group.innerHTML = `<h3>${SUIT_EMOJI[suit]} ${SUIT_NAMES[suit]}</h3>`;
            const rankGrid = document.createElement("div");
            rankGrid.className = "picker-ranks";

            for (let rank = 1; rank <= 13; rank += 1) {
                const button = document.createElement("button");
                button.type = "button";
                button.textContent = RANKS[rank];
                button.dataset.suit = suit;
                button.dataset.rank = String(rank);
                button.addEventListener("click", () => openCardEditor(suit, rank));
                rankGrid.appendChild(button);
            }
            group.appendChild(rankGrid);
            elements["card-picker"].appendChild(group);
        });
    }

    function openCardEditor(suit, rank) {
        editorCard = { suit, rank };
        editorFileData = "";
        const saved = cardArt[artKey(suit, rank)] || { mode: "default", value: "" };
        elements["editing-card-name"].textContent = `${RANKS[rank]} ${SUIT_GLYPHS[suit]}`;
        elements["art-mode"].value = saved.mode;
        elements["art-url"].value = saved.mode === "url" && !saved.value.startsWith("data:") ? saved.value : "";
        elements["art-html"].value = saved.mode === "html" ? saved.value : "";
        document.querySelectorAll(".picker-ranks button").forEach((button) => {
            button.classList.toggle(
                "active",
                button.dataset.suit === suit && Number(button.dataset.rank) === rank
            );
        });
        updateSourceControls();
        renderCardPreview(saved);
    }

    function getEditorArt() {
        const mode = elements["art-mode"].value;
        if (mode === "url") {
            return { mode, value: editorFileData || elements["art-url"].value.trim() };
        }
        if (mode === "html") {
            return { mode, value: elements["art-html"].value };
        }
        return { mode: "default", value: "" };
    }

    function updateSourceControls() {
        const mode = elements["art-mode"].value;
        elements["url-controls"].classList.toggle("hidden", mode !== "url");
        elements["html-controls"].classList.toggle("hidden", mode !== "html");
        elements["default-hint"].classList.toggle("hidden", mode !== "default");
        renderCardPreview(getEditorArt());
    }

    function renderCardPreview(overrideArt = getEditorArt()) {
        elements["card-preview"].replaceChildren();
        const previewCard = {
            id: "preview",
            suit: editorCard.suit,
            rank: editorCard.rank,
            faceUp: true
        };
        elements["card-preview"].appendChild(createCardElement(previewCard, { overrideArt }));
    }

    function handleCardFile(file) {
        if (!file) {
            return;
        }
        if (!file.type.startsWith("image/")) {
            showToast("Please choose an image file.");
            return;
        }
        const reader = new FileReader();
        reader.addEventListener("load", () => {
            editorFileData = String(reader.result);
            elements["art-url"].value = "";
            renderCardPreview();
        });
        reader.readAsDataURL(file);
    }

    function saveCardArt() {
        const value = getEditorArt();
        const key = artKey(editorCard.suit, editorCard.rank);
        if (value.mode !== "default" && !value.value) {
            showToast("Add an image URL, local image, or HTML first.");
            return;
        }
        if (value.mode === "default") {
            delete cardArt[key];
        } else {
            cardArt[key] = value;
        }
        saveLocalData();
        render();
        renderCardPreview(value);
        showToast("Card face saved.");
    }

    function resetCardArt() {
        delete cardArt[artKey(editorCard.suit, editorCard.rank)];
        editorFileData = "";
        elements["art-mode"].value = "default";
        elements["art-url"].value = "";
        elements["art-html"].value = "";
        updateSourceControls();
        saveLocalData();
        render();
        showToast("Built-in card restored.");
    }

    async function apiRequest(payload, method = "POST") {
        const options = method === "GET"
            ? { method: "GET", credentials: "same-origin" }
            : {
                method: "POST",
                credentials: "same-origin",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            };
        const url = method === "GET"
            ? `${API_URL}?action=${encodeURIComponent(payload.action)}&session_id=${encodeURIComponent(payload.session_id)}`
            : API_URL;
        const response = await fetch(url, options);
        const text = await response.text();
        let result;
        try {
            result = JSON.parse(text);
        } catch (error) {
            throw new Error("The server returned an unreadable response.");
        }
        if (!response.ok || !result.success) {
            throw new Error(result.message || `Server request failed (${response.status}).`);
        }
        return result;
    }

    async function saveToServer(showFeedback = true) {
        const sessionId = getSessionId();
        if (!sessionId) {
            if (showFeedback) {
                showToast("Use at least 6 letters, numbers, dashes, or underscores.");
            }
            return;
        }
        localStorage.setItem(STORAGE_SESSION, sessionId);
        elements["save-status"].textContent = "Saving…";
        try {
            await apiRequest({
                action: "save_game",
                session_id: sessionId,
                game_state: game,
                card_art: cardArt
            });
            elements["save-status"].textContent = "Saved to server";
            if (showFeedback) {
                showToast("Session saved to the server.");
            }
        } catch (error) {
            elements["save-status"].textContent = "Local game";
            if (showFeedback) {
                showToast(`${error.message} Your local save is safe.`);
            }
        }
    }

    async function loadFromServer() {
        const sessionId = getSessionId();
        if (!sessionId) {
            showToast("Enter a valid session ID first.");
            return;
        }
        elements["save-status"].textContent = "Loading…";
        try {
            const result = await apiRequest({ action: "load_game", session_id: sessionId }, "GET");
            if (isValidGame(result.game_state)) {
                game = result.game_state;
                cardArt = result.card_art && typeof result.card_art === "object" ? result.card_art : {};
                history = [];
                selected = null;
                localStorage.setItem(STORAGE_SESSION, sessionId);
                saveLocalData();
                render();
                openCardEditor(editorCard.suit, editorCard.rank);
                elements["save-status"].textContent = "Loaded from server";
                showToast("Server session loaded.");
            } else {
                throw new Error("This session does not contain a playable save.");
            }
        } catch (error) {
            elements["save-status"].textContent = "Local game";
            showToast(error.message);
        }
    }

    async function recordWin() {
        const sessionId = getSessionId();
        if (!sessionId) {
            return;
        }
        const elapsed = Math.max(0, Math.round((Date.now() - new Date(game.startedAt).getTime()) / 1000));
        try {
            await apiRequest({
                action: "record_result",
                session_id: sessionId,
                moves: game.moves,
                score: game.score,
                elapsed_seconds: elapsed,
                won: true
            });
        } catch (error) {
            console.warn("[Solitare] Win result could not be saved:", error.message);
        }
    }

    function bindEvents() {
        elements["stock-pile"].addEventListener("click", drawFromStock);
        elements["undo-button"].addEventListener("click", undo);
        elements["new-game-button"].addEventListener("click", () => startNewGame(true));
        elements["deal-again-button"].addEventListener("click", () => startNewGame(false));
        elements["studio-button"].addEventListener("click", () => {
            elements["studio-overlay"].classList.remove("hidden");
            openCardEditor(editorCard.suit, editorCard.rank);
        });
        elements["session-button"].addEventListener("click", () => {
            elements["session-overlay"].classList.remove("hidden");
        });

        document.querySelectorAll("[data-close]").forEach((button) => {
            button.addEventListener("click", () => {
                document.getElementById(button.dataset.close).classList.add("hidden");
            });
        });

        document.querySelectorAll(".overlay").forEach((overlay) => {
            overlay.addEventListener("mousedown", (event) => {
                if (event.target === overlay && overlay.id !== "win-overlay") {
                    overlay.classList.add("hidden");
                }
            });
        });

        document.addEventListener("keydown", (event) => {
            if (event.key === "Escape") {
                elements["session-overlay"].classList.add("hidden");
                elements["studio-overlay"].classList.add("hidden");
            }
            if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") {
                event.preventDefault();
                undo();
            }
        });

        elements["session-id"].addEventListener("change", () => {
            const sessionId = getSessionId();
            if (sessionId) {
                localStorage.setItem(STORAGE_SESSION, sessionId);
            }
        });
        elements["copy-session-button"].addEventListener("click", async () => {
            const sessionId = getSessionId();
            if (!sessionId) {
                showToast("Enter a valid session ID first.");
                return;
            }
            await navigator.clipboard.writeText(sessionId);
            showToast("Session ID copied.");
        });
        elements["new-session-button"].addEventListener("click", () => {
            elements["session-id"].value = generateSessionId();
            localStorage.setItem(STORAGE_SESSION, elements["session-id"].value);
            showToast("New session ID generated.");
        });
        elements["load-session-button"].addEventListener("click", loadFromServer);
        elements["save-session-button"].addEventListener("click", () => saveToServer(true));

        elements["art-mode"].addEventListener("change", () => {
            editorFileData = "";
            updateSourceControls();
        });
        elements["art-url"].addEventListener("input", () => {
            editorFileData = "";
            renderCardPreview();
        });
        elements["art-html"].addEventListener("input", () => renderCardPreview());
        elements["art-file"].addEventListener("change", (event) => handleCardFile(event.target.files[0]));
        elements["save-card-art-button"].addEventListener("click", saveCardArt);
        elements["reset-card-art-button"].addEventListener("click", resetCardArt);
    }

    function init() {
        cacheElements();
        loadLocalData();
        buildCardPicker();
        bindEvents();
        openCardEditor("hearts", 1);
        render();
        saveLocalData();
    }

    return { init };
})();

document.addEventListener("DOMContentLoaded", Solitare.init);
