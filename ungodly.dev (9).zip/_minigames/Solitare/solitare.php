<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$databaseFile = dirname(__DIR__) . '/db.php';
if (!is_file($databaseFile)) {
    respond(false, null, 'Database configuration file was not found at ../db.php.', 500);
}

require_once $databaseFile;

if (!isset($conn) || !($conn instanceof mysqli)) {
    respond(false, null, 'The database configuration must create a mysqli connection named $conn.', 500);
}

$conn->set_charset('utf8mb4');

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = isset($_GET['action']) ? (string) $_GET['action'] : '';
        if ($action !== 'load_game') {
            throw new ApiException('Invalid GET action.', 400);
        }
        loadGame($conn, requireSessionId($_GET['session_id'] ?? null));
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new ApiException('Method not allowed.', 405);
    }

    $rawBody = file_get_contents('php://input');
    $data = json_decode($rawBody ?: '', true);
    if (!is_array($data)) {
        throw new ApiException('The request body must contain valid JSON.', 400);
    }

    $action = isset($data['action']) ? (string) $data['action'] : '';
    switch ($action) {
        case 'save_game':
            saveGame($conn, $data);
            break;
        case 'record_result':
            recordResult($conn, $data);
            break;
        case 'delete_session':
            deleteSession($conn, requireSessionId($data['session_id'] ?? null));
            break;
        case 'ping':
            respond(true, ['server_time' => gmdate('c')]);
            break;
        default:
            throw new ApiException('Invalid POST action.', 400);
    }
} catch (ApiException $exception) {
    respond(false, null, $exception->getMessage(), $exception->statusCode);
} catch (Throwable $exception) {
    error_log('[FSG MiniGame Solitare] ' . $exception->getMessage());
    respond(false, null, 'The server could not complete the request.', 500);
}

final class ApiException extends RuntimeException
{
    public int $statusCode;

    public function __construct(string $message, int $statusCode)
    {
        parent::__construct($message);
        $this->statusCode = $statusCode;
    }
}

function requireSessionId($value): string
{
    $sessionId = trim((string) $value);
    if (!preg_match('/^[A-Za-z0-9_-]{6,64}$/', $sessionId)) {
        throw new ApiException('Session ID must be 6-64 letters, numbers, dashes, or underscores.', 400);
    }
    return $sessionId;
}

function requireInteger($value, string $field, int $minimum, int $maximum): int
{
    if (filter_var($value, FILTER_VALIDATE_INT) === false) {
        throw new ApiException($field . ' must be an integer.', 400);
    }
    $number = (int) $value;
    if ($number < $minimum || $number > $maximum) {
        throw new ApiException($field . ' is outside the accepted range.', 400);
    }
    return $number;
}

function encodeJsonValue($value, string $field, int $maximumBytes): string
{
    $encoded = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($encoded === false) {
        throw new ApiException($field . ' could not be encoded.', 400);
    }
    if (strlen($encoded) > $maximumBytes) {
        throw new ApiException($field . ' is too large to save.', 413);
    }
    return $encoded;
}

function decodeJsonValue(?string $value, $fallback)
{
    if ($value === null || $value === '') {
        return $fallback;
    }
    $decoded = json_decode($value, true);
    return json_last_error() === JSON_ERROR_NONE ? $decoded : $fallback;
}

function saveGame(mysqli $conn, array $data): void
{
    $sessionId = requireSessionId($data['session_id'] ?? null);
    $gameState = $data['game_state'] ?? null;
    $cardArt = $data['card_art'] ?? [];

    if (!is_array($gameState) || !isset($gameState['tableau'], $gameState['stock'], $gameState['foundations'])) {
        throw new ApiException('A valid game state is required.', 400);
    }
    if (!is_array($cardArt)) {
        throw new ApiException('Card art must be an object.', 400);
    }

    $gameJson = encodeJsonValue($gameState, 'Game state', 1048576);
    $moves = requireInteger($gameState['moves'] ?? 0, 'Moves', 0, 1000000);
    $score = requireInteger($gameState['score'] ?? 0, 'Score', 0, 100000000);

    $conn->begin_transaction();
    try {
        $profileSql = '
            INSERT INTO FSG_MiniGame_Solitare_PlayerProfiles
                (session_id, last_seen_at)
            VALUES
                (?, CURRENT_TIMESTAMP)
            ON DUPLICATE KEY UPDATE
                last_seen_at = CURRENT_TIMESTAMP
        ';
        $profile = $conn->prepare($profileSql);
        $profile->bind_param('s', $sessionId);
        $profile->execute();
        $profile->close();

        $saveSql = '
            INSERT INTO FSG_MiniGame_Solitare_GameSaves
                (session_id, game_state_json, moves, score, updated_at)
            VALUES
                (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON DUPLICATE KEY UPDATE
                game_state_json = VALUES(game_state_json),
                moves = VALUES(moves),
                score = VALUES(score),
                updated_at = CURRENT_TIMESTAMP
        ';
        $save = $conn->prepare($saveSql);
        $save->bind_param('ssii', $sessionId, $gameJson, $moves, $score);
        $save->execute();
        $save->close();

        $deleteArt = $conn->prepare('DELETE FROM FSG_MiniGame_Solitare_CardArt WHERE session_id = ?');
        $deleteArt->bind_param('s', $sessionId);
        $deleteArt->execute();
        $deleteArt->close();

        if ($cardArt) {
            $insertArtSql = '
                INSERT INTO FSG_MiniGame_Solitare_CardArt
                    (session_id, card_key, source_mode, source_value)
                VALUES
                    (?, ?, ?, ?)
            ';
            $insertArt = $conn->prepare($insertArtSql);
            foreach ($cardArt as $cardKey => $art) {
                if (!preg_match('/^(hearts|diamonds|clubs|spades)-(?:[1-9]|1[0-3])$/', (string) $cardKey)) {
                    continue;
                }
                if (!is_array($art)) {
                    continue;
                }
                $mode = isset($art['mode']) ? (string) $art['mode'] : '';
                $value = isset($art['value']) ? (string) $art['value'] : '';
                if (!in_array($mode, ['url', 'html'], true) || $value === '') {
                    continue;
                }
                if (strlen($value) > 2097152) {
                    throw new ApiException('One of the custom card faces is too large.', 413);
                }
                $safeCardKey = (string) $cardKey;
                $insertArt->bind_param('ssss', $sessionId, $safeCardKey, $mode, $value);
                $insertArt->execute();
            }
            $insertArt->close();
        }

        $conn->commit();
        respond(true, [
            'session_id' => $sessionId,
            'moves' => $moves,
            'score' => $score,
            'saved_at' => gmdate('c')
        ]);
    } catch (Throwable $exception) {
        $conn->rollback();
        throw $exception;
    }
}

function loadGame(mysqli $conn, string $sessionId): void
{
    $saveSql = '
        SELECT game_state_json, moves, score, updated_at
        FROM FSG_MiniGame_Solitare_GameSaves
        WHERE session_id = ?
        LIMIT 1
    ';
    $save = $conn->prepare($saveSql);
    $save->bind_param('s', $sessionId);
    $save->execute();
    $saveResult = $save->get_result();
    $saveRow = $saveResult->fetch_assoc();
    $save->close();

    if (!$saveRow) {
        throw new ApiException('No saved game exists for that session ID.', 404);
    }

    $artSql = '
        SELECT card_key, source_mode, source_value
        FROM FSG_MiniGame_Solitare_CardArt
        WHERE session_id = ?
        ORDER BY card_key ASC
    ';
    $artStatement = $conn->prepare($artSql);
    $artStatement->bind_param('s', $sessionId);
    $artStatement->execute();
    $artResult = $artStatement->get_result();
    $cardArt = [];
    while ($row = $artResult->fetch_assoc()) {
        $cardArt[$row['card_key']] = [
            'mode' => $row['source_mode'],
            'value' => $row['source_value']
        ];
    }
    $artStatement->close();

    $profile = $conn->prepare('UPDATE FSG_MiniGame_Solitare_PlayerProfiles SET last_seen_at = CURRENT_TIMESTAMP WHERE session_id = ?');
    $profile->bind_param('s', $sessionId);
    $profile->execute();
    $profile->close();

    respond(true, [
        'session_id' => $sessionId,
        'game_state' => decodeJsonValue($saveRow['game_state_json'], null),
        'card_art' => $cardArt,
        'moves' => (int) $saveRow['moves'],
        'score' => (int) $saveRow['score'],
        'updated_at' => $saveRow['updated_at']
    ]);
}

function recordResult(mysqli $conn, array $data): void
{
    $sessionId = requireSessionId($data['session_id'] ?? null);
    $moves = requireInteger($data['moves'] ?? 0, 'Moves', 0, 1000000);
    $score = requireInteger($data['score'] ?? 0, 'Score', 0, 100000000);
    $elapsedSeconds = requireInteger($data['elapsed_seconds'] ?? 0, 'Elapsed seconds', 0, 31536000);
    $won = !empty($data['won']) ? 1 : 0;

    $sql = '
        INSERT INTO FSG_MiniGame_Solitare_GameResults
            (session_id, won, moves, score, elapsed_seconds)
        VALUES
            (?, ?, ?, ?, ?)
    ';
    $statement = $conn->prepare($sql);
    $statement->bind_param('siiii', $sessionId, $won, $moves, $score, $elapsedSeconds);
    $statement->execute();
    $resultId = $statement->insert_id;
    $statement->close();

    $profileSql = '
        INSERT INTO FSG_MiniGame_Solitare_PlayerProfiles
            (session_id, games_started, games_won, best_score, best_moves, last_seen_at)
        VALUES
            (?, 1, ?, ?, NULLIF(?, 0), CURRENT_TIMESTAMP)
        ON DUPLICATE KEY UPDATE
            games_started = games_started + 1,
            games_won = games_won + VALUES(games_won),
            best_score = GREATEST(best_score, VALUES(best_score)),
            best_moves = CASE
                WHEN VALUES(best_moves) IS NULL THEN best_moves
                WHEN best_moves IS NULL THEN VALUES(best_moves)
                ELSE LEAST(best_moves, VALUES(best_moves))
            END,
            last_seen_at = CURRENT_TIMESTAMP
    ';
    $profile = $conn->prepare($profileSql);
    $wonCount = $won === 1 ? 1 : 0;
    $profile->bind_param('siii', $sessionId, $wonCount, $score, $moves);
    $profile->execute();
    $profile->close();

    respond(true, ['result_id' => $resultId]);
}

function deleteSession(mysqli $conn, string $sessionId): void
{
    $statement = $conn->prepare('DELETE FROM FSG_MiniGame_Solitare_PlayerProfiles WHERE session_id = ?');
    $statement->bind_param('s', $sessionId);
    $statement->execute();
    $deleted = $statement->affected_rows > 0;
    $statement->close();
    respond(true, ['deleted' => $deleted]);
}

function respond(bool $success, ?array $data = null, ?string $message = null, int $status = 200): void
{
    http_response_code($status);
    $payload = ['success' => $success];
    if ($data !== null) {
        $payload = array_merge($payload, $data);
    }
    if ($message !== null) {
        $payload['message'] = $message;
    }
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
