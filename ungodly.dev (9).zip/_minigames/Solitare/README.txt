FSG MiniGame - Solitare
=======================

UPLOAD LOCATION

Upload this entire "Solitare" folder into the root of ungodly.dev.
The playable page will then be:

    https://ungodly.dev/Solitare/solitare.html

FILES

    solitare.html
        The playable page and modal interface.

    solitare.css
        All visual styling, card transitions, responsive rules, and modal styling.

    solitare.js
        Klondike gameplay, undo, scoring, local saves, card customization,
        server save/load, image URLs, HTML card faces, and local image loading.

    solitare.php
        JSON API for game saves, custom card art, session loading, and results.
        It expects your existing database file at ../db.php and expects that
        file to create a mysqli connection named $conn.

    FSG_MiniGame_Solitare_schema.sql
        Import this once through phpMyAdmin or your MySQL management tool.
        Every table begins with FSG_MiniGame_Solitare_.

INSTALLATION

1. Import FSG_MiniGame_Solitare_schema.sql into the same database used by db.php.
2. Upload the complete Solitare folder into the ungodly.dev root.
3. Open /Solitare/solitare.html.
4. The game works locally even when the PHP API is unavailable.
5. Open Session inside the game to save or load a server-backed session.

CUSTOM CARD FACES

Open Card Studio. Each of the 52 cards can use:

    - The built-in emoji/value face.
    - An image URL.
    - An image chosen through the local file browser.
    - Custom HTML rendered inside an isolated iframe.

Local images are stored as data URLs. Very large files can exceed browser or
database storage limits, so web-sized card images are recommended.
