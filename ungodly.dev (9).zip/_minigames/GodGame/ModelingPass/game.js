/* PROJECT SOVEREIGN AEGIS - game.js */
/* ===== db.js ===== */
/* ═══════════════════════════════════════════════════════════════
   SOVEREIGN AEGIS — DB
   Every tunable number in the game lives here. The in-game editor
   (Ctrl+E) walks this object generically, so anything you add with
   a numeric / boolean / string value becomes editable at runtime.
   ═══════════════════════════════════════════════════════════════ */
(function (global) {
"use strict";

/* ── RuneScape XP curve ──────────────────────────────────────── */
function xpForLevel(L){
  let s = 0;
  for (let l = 1; l < L; l++) s += Math.floor(l + 300 * Math.pow(2, l / 7));
  return Math.floor(s / 4);
}
const XP_TABLE = [];
for (let L = 1; L <= 99; L++) XP_TABLE.push(xpForLevel(L));

function levelFor(xp){
  let lo = 1;
  for (let L = 99; L >= 1; L--) if (xp >= XP_TABLE[L-1]) { lo = L; break; }
  return lo;
}
function xpProgress(xp){
  const L = levelFor(xp);
  if (L >= 99) return {level:99, into:0, need:0, frac:1};
  const a = XP_TABLE[L-1], b = XP_TABLE[L];
  return {level:L, into:xp-a, need:b-a, frac:(xp-a)/(b-a)};
}

/* ── skills ──────────────────────────────────────────────────── */
const SKILLS = {
  hitpoints:   {label:"Hitpoints",   colour:"#C8504A", note:"Raises max HP. Trained by taking and dealing damage."},
  attack:      {label:"Attack",      colour:"#D9A43F", note:"Melee accuracy. Trained by landing melee blows."},
  strength:    {label:"Strength",    colour:"#C87A3F", note:"Melee damage. Trained by landing melee blows."},
  defence:     {label:"Defence",     colour:"#46988C", note:"Damage reduction. Trained by being struck."},
  ranged:      {label:"Ranged",      colour:"#7FA65C", note:"Bow damage and range. Rangers and archers."},
  magic:       {label:"Magic",       colour:"#8E7BC8", note:"Spell power. Druids and wizards."},
  prayer:      {label:"Prayer",      colour:"#C8B45A", note:"Worship yield. Trained at the temple."},
  herblore:    {label:"Herblore",    colour:"#5F9159", note:"Healing potency. Druids."},
  woodcutting: {label:"Woodcutting", colour:"#5F9159", note:"Timber per swing and swing speed."},
  mining:      {label:"Mining",      colour:"#7C8AA6", note:"Ore per swing and swing speed."},
  smithing:    {label:"Smithing",    colour:"#A87C4A", note:"Gear crafted at the forge."},
  construction:{label:"Construction",colour:"#D9A43F", note:"Build and repair speed."},
  farming:     {label:"Farming",     colour:"#8FA55C", note:"Food yield and woodland regrowth."},
  thieving:    {label:"Thieving",    colour:"#8E7BC8", note:"Rogue purse-cutting and loot rolls."},
  breeding:    {label:"Breeding",    colour:"#D07FA8", note:"Shortens the wait between children and raises twin odds."}
};

/* ── items ───────────────────────────────────────────────────── */
const ITEMS = {
  bread:       {label:"Bread",           kind:"food",   value:6,   heal:8},
  ale:         {label:"Tankard of Ale",  kind:"food",   value:9,   heal:4},
  herbs:       {label:"Bundled Herbs",   kind:"reagent",value:12},
  hatchet:     {label:"Bronze Hatchet",  kind:"tool",   value:20,  skill:"woodcutting", bonus:2},
  pickaxe:     {label:"Bronze Pickaxe",  kind:"tool",   value:20,  skill:"mining",      bonus:2},
  hammer:      {label:"Mason's Hammer",  kind:"tool",   value:24,  skill:"construction",bonus:2},
  leather:     {label:"Hardened Leather",kind:"armour", value:70,  def:3},
  chain:       {label:"Chainmail",       kind:"armour", value:180, def:7},
  plate:       {label:"Fine Plate",      kind:"armour", value:420, def:14},
  runeplate:   {label:"Runed Plate",     kind:"armour", value:900, def:24},
  shortsword:  {label:"Shortsword",      kind:"weapon", value:80,  atk:4},
  longsword:   {label:"Longsword",       kind:"weapon", value:220, atk:9},
  greatsword:  {label:"Greatsword",      kind:"weapon", value:520, atk:18},
  shortbow:    {label:"Shortbow",        kind:"weapon", value:90,  atk:5,  ranged:true},
  yewbow:      {label:"Yew Longbow",     kind:"weapon", value:340, atk:13, ranged:true},
  staff:       {label:"Oaken Staff",     kind:"weapon", value:110, atk:6,  magic:true},
  elderstaff:  {label:"Elder Staff",     kind:"weapon", value:460, atk:15, magic:true}
};

/* Gear ladders — each class buys up its own ladder at the market. */
const GEAR_LADDER = {
  warrior: ["shortsword","leather","longsword","chain","greatsword","plate"],
  rogue:   ["shortsword","leather","longsword","chain","greatsword"],
  ranger:  ["shortbow","leather","yewbow","chain","runeplate"],
  druid:   ["staff","leather","elderstaff","chain"],
  wizard:  ["staff","leather","elderstaff","chain","runeplate"],
  barbarian:["shortsword","leather","greatsword","chain"],
  priestess:["staff","leather","elderstaff","chain"],
  dwarf:   ["hammer","shortsword","chain","longsword","plate"],
  elf:     ["shortbow","leather","yewbow","chain"],
  gnome:   ["hammer","leather"],
  soldier: ["shortsword","leather","longsword","chain"]
};

/* ── unit archetypes ─────────────────────────────────────────── */
const CLASSES = {
  /* — the folk: direct control via job assignment — */
  villager: {
    label:"Villager", family:"folk", colour:"#B9C0D4", accent:"#8A93AC",
    hp:26, mp:0, speed:3.4, radius:.42, height:1.5,
    baseSkills:{hitpoints:1, woodcutting:1, mining:1, construction:1, prayer:1, farming:1},
    desc:"Cuts, digs, builds and prays. Everything else is downstream of them."
  },
  /* — adventurers: indirect control via flags — */
  warrior: {
    label:"Warrior", family:"hero", colour:"#46988C", accent:"#2C6C61",
    hp:74, mp:0, speed:3.6, radius:.46, height:1.72, attackRange:1.6, attackSpeed:1.25, damage:8,
    greed:.55, courage:.92, duty:.82,
    baseSkills:{hitpoints:8, attack:7, strength:7, defence:6},
    desc:"Brave and dutiful, slow to enrich. Answers a defend flag for almost nothing."
  },
  ranger: {
    label:"Ranger", family:"hero", colour:"#8FA55C", accent:"#5F7A38",
    hp:52, mp:20, speed:4.3, radius:.4, height:1.68, attackRange:11, attackSpeed:1.0, damage:9, projectile:"arrow",
    greed:.85, courage:.62, duty:.38,
    baseSkills:{hitpoints:5, ranged:9, defence:3},
    desc:"Shoots from range and keeps its distance. Greedy, and knows its own worth."
  },
  druid: {
    label:"Druid", family:"hero", colour:"#5F9159", accent:"#3C6B39",
    hp:48, mp:60, speed:3.4, radius:.4, height:1.66, attackRange:9, attackSpeed:1.5, damage:6, projectile:"roots",
    greed:.45, courage:.55, duty:.85, healPower:14, healRange:8, rootDuration:3.2,
    baseSkills:{hitpoints:5, magic:9, herblore:8, defence:3},
    desc:"Casts binding roots that freeze a target where it stands, and mends allies between volleys."
  },
  rogue: {
    label:"Rogue", family:"hero", colour:"#8E7BC8", accent:"#5B4A96",
    hp:46, mp:0, speed:4.6, radius:.38, height:1.64, attackRange:1.5, attackSpeed:.85, damage:13,
    greed:1.1, courage:.36, duty:.14,
    baseSkills:{hitpoints:5, attack:9, strength:8, thieving:12},
    desc:"Lethal, avaricious and a coward. Will not move without a very good price."
  },
  wizard: {
    label:"Wizard", family:"hero", colour:"#8E7BC8", accent:"#4A3B78",
    hp:44, mp:90, speed:3.2, radius:.4, height:1.7, attackRange:13, attackSpeed:1.7, damage:19, projectile:"bolt",
    greed:1.15, courage:.45, duty:.20,
    baseSkills:{hitpoints:5, magic:14, defence:3},
    desc:"Outranges everything and dies to a stiff breeze. Will not leave the tower for small money."
  },

  barbarian: {
    label:"Barbarian", family:"hero", colour:"#A8562E", accent:"#6B3418",
    hp:96, mp:0, speed:4.0, radius:.5, height:1.86, attackRange:1.8, attackSpeed:1.0, damage:15,
    greed:.30, courage:1.25, duty:.10,
    baseSkills:{hitpoints:12, attack:10, strength:12, defence:4},
    noDefend:true,
    desc:"Will not stand a defend flag and will not retreat. Charges the nearest violence for almost nothing."
  },
  priestess: {
    label:"Priestess of Krypta", family:"hero", colour:"#6B5B8A", accent:"#3E3352",
    hp:50, mp:70, speed:3.3, radius:.4, height:1.68, attackRange:8, attackSpeed:1.6, damage:9, projectile:"bolt",
    greed:.65, courage:.55, duty:.70, raisesDead:true,
    baseSkills:{hitpoints:6, magic:11, prayer:10, defence:4},
    desc:"Raises the fallen to fight on. Your alignment will not survive the habit."
  },
  dwarf: {
    label:"Dwarf", family:"hero", colour:"#A87C4A", accent:"#5E4426",
    hp:84, mp:0, speed:2.9, radius:.44, height:1.42, attackRange:1.6, attackSpeed:1.2, damage:11,
    greed:.95, courage:.85, duty:.55, builder:true,
    baseSkills:{hitpoints:10, attack:8, strength:10, defence:9, construction:14, mining:12},
    desc:"Fights well and builds better. Will stop mid-battle to repair a wall."
  },
  elf: {
    label:"Elf", family:"hero", colour:"#8FA55C", accent:"#4E6B33",
    hp:54, mp:40, speed:4.6, radius:.4, height:1.76, attackRange:12, attackSpeed:.95, damage:11, projectile:"arrow",
    greed:1.20, courage:.60, duty:.25,
    baseSkills:{hitpoints:6, ranged:12, magic:6, thieving:8},
    desc:"Shoots beautifully and charges accordingly. Brings gold into the realm and crime with it."
  },
  gnome: {
    label:"Gnome", family:"hero", colour:"#6FA85E", accent:"#3C6B39",
    hp:30, mp:0, speed:4.4, radius:.32, height:1.18, attackRange:1.4, attackSpeed:1.1, damage:4,
    greed:.55, courage:.30, duty:.65, builder:true,
    baseSkills:{hitpoints:3, attack:3, construction:11},
    desc:"Cheap, quick, tireless, and killed by almost anything. Send them to build, not to fight."
  },

  /* — soldiers: direct control via squad banners — */
  pikeman: {
    label:"Pikeman", family:"soldier", colour:"#C8B45A", accent:"#8A7620",
    hp:64, mp:0, speed:3.2, radius:.42, height:1.7, attackRange:2.4, attackSpeed:1.35, damage:9,
    baseSkills:{hitpoints:7, attack:6, strength:6, defence:7},
    trainCost:{food:20, wood:15, gold:30}, trainTime:9,
    desc:"Holds a line. Long reach, slow swing. Marches where the banner goes."
  },
  swordsman: {
    label:"Swordsman", family:"soldier", colour:"#D9A43F", accent:"#8A5B10",
    hp:78, mp:0, speed:3.5, radius:.44, height:1.72, attackRange:1.7, attackSpeed:1.05, damage:11,
    baseSkills:{hitpoints:9, attack:8, strength:8, defence:6},
    trainCost:{food:25, gold:45, stone:10}, trainTime:12,
    desc:"The weight of the line. Swarms anything that comes inside the banner's watch."
  },
  archer: {
    label:"Archer", family:"soldier", colour:"#7FA65C", accent:"#4E6B33",
    hp:46, mp:0, speed:3.6, radius:.38, height:1.66, attackRange:12, attackSpeed:1.1, damage:8, projectile:"arrow",
    baseSkills:{hitpoints:5, ranged:8, defence:3},
    trainCost:{food:15, wood:25, gold:35}, trainTime:10,
    desc:"Volleys from behind the pikes. Will not close unless the banner does."
  },
  scout: {
    label:"Scout Cavalry", family:"soldier", colour:"#B58A4A", accent:"#7A5822",
    hp:70, mp:0, speed:6.4, radius:.5, height:2.1, attackRange:1.9, attackSpeed:1.0, damage:10,
    baseSkills:{hitpoints:8, attack:7, strength:8, defence:4},
    trainCost:{food:40, gold:55}, trainTime:11, needs:"stable",
    desc:"Outruns everything on the field. Reaches the far side of the map before the pikes have formed up."
  },
  ram: {
    label:"Battering Ram", family:"soldier", colour:"#6B5B3A", accent:"#3E341F",
    hp:220, mp:0, speed:1.9, radius:.9, height:2.2, attackRange:3.0, attackSpeed:2.6, damage:46,
    baseSkills:{hitpoints:24, attack:6, strength:14, defence:16},
    trainCost:{wood:120, gold:60}, trainTime:16, needs:"siege", siege:true,
    desc:"Exists to take down structures. Nearly useless against anything that can step aside."
  },
  /* — the creature — */
  creature: {
    label:"Creature", family:"creature", colour:"#A87C4A", accent:"#6B4B26",
    hp:600, mp:0, speed:5.2, radius:1.8, height:5.2, attackRange:3.4, attackSpeed:1.6, damage:34,
    baseSkills:{hitpoints:40, attack:30, strength:34, defence:28},
    desc:"Yours. Leash it and it learns from what you let it do."
  },
  /* — wildlife — */
  sheep: {
    label:"Sheep", family:"beast", colour:"#DAD6CC", accent:"#9A9488",
    hp:22, mp:0, speed:1.7, radius:.42, height:1.0, food:22, herds:true, skittish:9,
    baseSkills:{hitpoints:2},
    desc:"Grazes in a flock and drifts. Worth twenty-odd food to whoever gets there first."
  },
  deer: {
    label:"Deer", family:"beast", colour:"#A8814E", accent:"#6E5330",
    hp:34, mp:0, speed:5.6, radius:.46, height:1.7, food:40, herds:false, skittish:20,
    baseSkills:{hitpoints:4},
    desc:"Bolts long before you reach it. Worth the chase if a hunter is quick."
  },

  /* — monsters — */
  gnoll: {
    label:"Gnoll", family:"monster", colour:"#C8504A", accent:"#7A2C28",
    hp:28, mp:0, speed:3.3, radius:.4, height:1.55, attackRange:1.5, attackSpeed:.95, damage:5,
    baseSkills:{hitpoints:4, attack:4, strength:4}, bounty:1,
    desc:"Comes in numbers, dies in numbers."
  },
  ogre: {
    label:"Ogre", family:"monster", colour:"#A8403A", accent:"#5E211E",
    hp:96, mp:0, speed:2.5, radius:.75, height:2.6, attackRange:2.1, attackSpeed:1.5, damage:16,
    baseSkills:{hitpoints:14, attack:9, strength:12, defence:6}, bounty:3,
    desc:"Slow, and it does not care about your palisade."
  },
  wraith: {
    label:"Wraith", family:"monster", colour:"#8E7BC8", accent:"#4A3B78",
    hp:54, mp:40, speed:4.4, radius:.45, height:2.0, attackRange:7, attackSpeed:1.2, damage:12, projectile:"bolt",
    baseSkills:{hitpoints:8, magic:12, defence:5}, bounty:4, age:2,
    desc:"Ignores walls the way smoke ignores a door."
  }
};

/* ── compound parts authored in the modeller ─────────────────
   A preset is one or more primitives welded into a single reusable
   piece. Colours, glow and lights are kept exactly as authored. */
const PART_PRESETS = {};

/* ── every building carries these, editable in the modeller ──
   tiers:    how many visual tiers it has
   models:   {1:[parts], 2:[parts], ...} — a tier falls back to tier 1
   collider: {w,h,d,x,y,z,rx,ry,rz} the box used for picking and blocking
   iconDir / prefabDir / description / tooltip — export metadata for
   whatever engine you take this into afterwards. */
const BUILDING_META_DEFAULTS = {
  tiers:1, iconDir:"", prefabDir:"", description:"", tooltip:""
};

/* ── the six things a realm holds ────────────────────────────
   wood / stone / gold / food are gathered. iron and goods are made by
   converter buildings, which is what drives the production chains. */
const RESOURCES = {
  wood: {label:"Wood",  colour:"#6FA85E", gathered:true},
  stone:{label:"Stone", colour:"#8C9AB6", gathered:true},
  gold: {label:"Gold",  colour:"#D9A43F", gathered:true},
  food: {label:"Food",  colour:"#C8A05A", gathered:true},
  iron: {label:"Iron",  colour:"#A8B0C0", gathered:false},
  goods:{label:"Goods", colour:"#C86A7A", gathered:false}
};

/* ── buildings ───────────────────────────────────────────────
   effect keys the sim understands, so a new building can be given real
   behaviour from the editor alone:
     popCap        n      raises the population ceiling
     recruits      n      guild: attracts n heroes per tier
     gatherBonus   0..1   speeds nearby gatherers, acts as a drop-off
     produces      {res:perSecond}          passive trickle
     converts      {in:{}, out:{}, every:s} an artisan turns one into another
     appeal        n      town appeal: birth rate, hero morale, land value
     heal          n      mends anything friendly standing near it
     garrison      {cls,count}              keeps its own defenders
     range/damage/rate    it shoots
     research      true   sells research when clicked
     unlocks       key    lets the barracks train that unit
     storage       n      raises how much the piles can show
     wonder        true   a victory monument
   ────────────────────────────────────────────────────────────── */
const BUILDINGS = {
  keep: {
    label:"Keep", civic:true, w:6, d:6, height:7, colour:"#8A93AC", roof:"#46988C",
    cost:{wood:220, stone:220}, work:0, hp:900, age:0,
    desc:"Seat of the crown. Its tier gates the Age you may reach and the folk you may hold.",
    effect:{popCap:6}
  },
  house: {
    label:"House", civic:false, w:2.4, d:2.4, height:2.6, colour:"#A08A6A", roof:"#8A5B10",
    cost:{wood:45}, work:7, hp:110, age:0,
    desc:"Villagers site and raise these themselves, keeping their distance from the works.",
    effect:{popCap:4}
  },
  hut: {
    label:"Hut", civic:true, w:2, d:2, height:2.4, colour:"#98866A", roof:"#7A5B3A",
    cost:{wood:35}, work:5, hp:90, age:0,
    desc:"The cheap way to make room for more folk. Four more to the cap per tier.",
    effect:{popCap:4}
  },
  store: {
    label:"Village Store", civic:true, w:3.4, d:3.4, height:3.2, colour:"#9A8F76", roof:"#6B5B3A",
    cost:{wood:80}, work:11, hp:240, age:0,
    desc:"Everything gathered is carried here, and every building draws from it.",
    effect:{}
  },
  wall: {
    label:"Wall", civic:true, w:2, d:2, height:2.6, colour:"#7C8AA6", roof:null,
    cost:{stone:14}, work:0, hp:220, age:0, blocks:1,
    desc:"Stops the horde. What it cannot stop it delays, which is usually enough.",
    effect:{}
  },
  gate: {
    label:"Gate", civic:true, w:2, d:2, height:3.0, colour:"#8A5B10", roof:null,
    cost:{wood:40, stone:20}, work:4, hp:260, age:0, blocks:2,
    desc:"Your folk pass freely. Nothing else does.",
    effect:{}
  },
  tower: {
    label:"Watchtower", civic:true, w:2.4, d:2.4, height:6.5, colour:"#7C8AA6", roof:"#46988C",
    cost:{wood:60, stone:90}, work:12, hp:340, age:1,
    desc:"Shoots anything hostile in range. Obeys without being paid.",
    effect:{range:16, damage:14, rate:1.2}
  },
  lumber: {
    label:"Lumber Camp", civic:true, w:3.6, d:3.6, height:2.8, colour:"#7A6647", roof:"#5F9159",
    cost:{wood:75}, work:12, hp:220, age:0,
    desc:"Timber drop-off. Foresters working near it cut appreciably faster.",
    effect:{gatherBonus:.3}
  },
  mine: {
    label:"Mining Camp", civic:true, w:3.6, d:3.6, height:2.8, colour:"#6E7285", roof:"#7C8AA6",
    cost:{wood:60, stone:25}, work:12, hp:220, age:0,
    desc:"Ore drop-off. Miners working near it swing appreciably faster.",
    effect:{gatherBonus:.3}
  },
  farm: {
    label:"Farmstead", civic:true, w:4, d:4, height:2.2, colour:"#8FA55C", roof:"#6B7A3A",
    cost:{wood:70}, work:10, hp:180, age:0,
    desc:"Food for your soldiers. Without it a barracks trains nothing.",
    effect:{foodRate:1.4}
  },
  mill: {
    label:"Mill", civic:true, w:3.2, d:3.2, height:5.4, colour:"#9A8256", roof:"#C8B45A",
    cost:{wood:85}, work:11, hp:200, age:0,
    desc:"Food drop-off. Farmers working near it thresh a good deal faster, and it keeps a standing food tithe.",
    effect:{gatherBonus:.35, foodTithe:.5}
  },
  blacksmith: {
    label:"Blacksmith", civic:true, w:4, d:4, height:3.2, colour:"#6E6A62", roof:"#A8403A",
    cost:{wood:110, stone:70}, work:16, hp:280, age:1,
    desc:"Every armed thing in the realm hits harder and takes less. Scales with tier and applies to heroes and soldiers alike.",
    effect:{attackBonus:.12, defenceBonus:.12}
  },
  stable: {
    label:"Stable", civic:true, w:4.6, d:4.6, height:3.0, colour:"#7A6647", roof:"#B58A4A",
    cost:{wood:130, food:40}, work:16, hp:280, age:1,
    desc:"Lets the barracks muster scout cavalry — the fastest thing you will ever field.",
    effect:{unlocks:"scout"}
  },
  siege: {
    label:"Siege Workshop", civic:true, w:5, d:5, height:3.4, colour:"#5E5646", roof:"#6B5B3A",
    cost:{wood:180, stone:100}, work:20, hp:320, age:2,
    desc:"Lets the barracks build battering rams for cracking lairs and enemy stonework.",
    effect:{unlocks:"ram"}
  },
  mageTower: {
    label:"Mage Tower", civic:true, w:3.6, d:3.6, height:9.5, colour:"#5A5878", roof:"#8E7BC8",
    cost:{wood:150, stone:130, gold:120}, work:20, hp:300, age:2,
    desc:"Raises the ceiling on your spell energy and drops a bolt on anything hostile that strays near.",
    effect:{energyBonus:60, range:18, damage:22, rate:2.2}
  },
  university: {
    label:"University", civic:true, w:5, d:5, height:6.0, colour:"#B0B6C4", roof:"#4E7FC8",
    cost:{wood:180, stone:140, gold:80}, work:22, hp:340, age:2,
    desc:"Click it to buy research. Everything bought here is permanent and applies across the whole realm.",
    effect:{research:true}
  },
  torch: {
    label:"Torch", civic:true, w:1, d:1, height:3.2, colour:"#5A4630", roof:null,
    cost:{wood:12}, work:0, hp:40, age:0,
    desc:"Throws light and holds a small circle of ground. Monsters will not path through the flame willingly.",
    effect:{light:14, ward:5}
  },
  market: {
    label:"Marketplace", civic:true, w:4.4, d:4.4, height:3.4, colour:"#A08A6A", roof:"#D9A43F",
    cost:{wood:120, stone:60}, work:16, hp:260, age:1,
    desc:"Heroes buy their own gear here. Its tier caps how good that gear ever gets. You tax every sale.",
    effect:{gearTier:2, taxRate:.5}
  },
  tavern: {
    label:"Tavern", civic:true, w:4, d:4, height:3.2, colour:"#8A6A4A", roof:"#A8403A",
    cost:{wood:95}, work:14, hp:230, age:0,
    desc:"Heroes drink away their bounty money and you tax that too.",
    effect:{taxRate:.5}
  },
  temple: {
    label:"Godly Temple", civic:true, w:11, d:11, height:20, colour:"#C6CBDA", roof:"#C8B45A",
    cost:{wood:260, stone:220}, work:34, hp:900, age:0,
    desc:"The largest thing you will ever raise — taller and wider than the keep. Drop a villager " +
         "onto its floor and they become a bound worshipper. Its whole form changes with your alignment.",
    effect:{prayerRate:1.0, energyCap:120}
  },
  barracks: {
    label:"Barracks", civic:true, w:5, d:5, height:3.6, colour:"#7A6647", roof:"#C8B45A",
    cost:{wood:130, stone:70}, work:18, hp:340, age:1,
    desc:"Trains soldiers who obey you and only you. Each barracks fields one squad banner per tier.",
    effect:{squads:1}
  },
  warriorGuild: {
    label:"Warrior's Guild", guild:"warrior", civic:true, w:4.4, d:4.4, height:4.2, colour:"#6E7A86", roof:"#46988C",
    cost:{wood:120, stone:70}, work:18, hp:300, age:0,
    desc:"Attracts one warrior per tier. They will not take orders — only contracts.",
    effect:{recruits:1}
  },
  rangerLodge: {
    label:"Ranger's Lodge", guild:"ranger", civic:true, w:4.4, d:4.4, height:4.0, colour:"#6B7A55", roof:"#8FA55C",
    cost:{wood:110, stone:45}, work:16, hp:260, age:1,
    desc:"Attracts one ranger per tier. They shoot, they loot, and they are expensive.",
    effect:{recruits:1}
  },
  druidGrove: {
    label:"Druid Grove", guild:"druid", civic:true, w:4.4, d:4.4, height:4.6, colour:"#5C7A50", roof:"#5F9159",
    cost:{wood:130, stone:50}, work:18, hp:280, age:1,
    desc:"Attracts one druid per tier. Roots that hold, and hands that mend.",
    effect:{recruits:1}
  },
  rogueDen: {
    label:"Rogues' Den", guild:"rogue", civic:true, w:4.2, d:4.2, height:3.6, colour:"#5E5A70", roof:"#8E7BC8",
    cost:{wood:140, stone:60, gold:110}, work:20, hp:260, age:2,
    desc:"Attracts one rogue per tier. Pay them properly or watch them stand still.",
    effect:{recruits:1}
  },
  conclave: {
    label:"Wizard Conclave", guild:"wizard", civic:true, w:4.6, d:4.6, height:7.0, colour:"#5A5878", roof:"#8E7BC8",
    cost:{wood:170, stone:140, gold:180}, work:26, hp:280, age:3,
    desc:"Attracts one wizard per tier. Devastating at range, and utterly mercenary about it.",
    effect:{recruits:1}
  },

  /* ═══ AGE OF EMPIRES ANALOGS ═══════════════════════════════ */
  archery: {
    label:"Archery Range", civic:true, w:4.6, d:4.6, height:3.2, colour:"#6B7A55", roof:"#7FA65C",
    cost:{wood:120, stone:30}, work:16, hp:250, age:1,
    desc:"Lets the barracks muster archers and horse archers, and sharpens every bow in the realm.",
    effect:{unlocks:"archer", rangedBonus:.1}
  },
  outpost: {
    label:"Outpost", civic:true, w:1.6, d:1.6, height:5.0, colour:"#7C8AA6", roof:"#46988C",
    cost:{wood:20, stone:10}, work:4, hp:120, age:0,
    desc:"Cheap eyes on distant ground. Sees far, shoots nothing.",
    effect:{vision:34}
  },
  palisade: {
    label:"Palisade", civic:true, w:2, d:2, height:2.0, colour:"#7A5B33", roof:null,
    cost:{wood:6}, work:0, hp:70, age:0, blocks:1,
    desc:"Timber stakes. Quick, cheap, and it will not hold for long.",
    effect:{}
  },
  dock: {
    label:"Dock", civic:true, w:5, d:5, height:3.0, colour:"#6E7A86", roof:"#4E7FC8",
    cost:{wood:130}, work:14, hp:240, age:0,
    desc:"Fishing boats work the water and bring food back. Also the yard for trade cogs.",
    effect:{produces:{food:.7}, appeal:2}
  },
  feitoria: {
    label:"Feitoria", civic:true, w:5, d:5, height:4.4, colour:"#9A8256", roof:"#D9A43F",
    cost:{wood:300, stone:250, gold:300}, work:30, hp:420, age:3,
    desc:"Needs no workers and never stops. A slow trickle of everything, forever.",
    effect:{produces:{wood:.35, stone:.35, gold:.5, food:.35}}
  },
  wonder: {
    label:"Wonder", civic:true, w:14, d:14, height:26, colour:"#D8D2C0", roof:"#D9A43F",
    cost:{wood:900, stone:900, gold:800, iron:150}, work:90, hp:2000, age:3,
    desc:"The monument that says you won. Enormous, ruinously expensive, and visible from every corner of the map.",
    effect:{wonder:true, appeal:40, popCap:20}
  },

  /* ═══ MAJESTY ANALOGS ══════════════════════════════════════ */
  guardhouse: {
    label:"Guardhouse", civic:true, w:3.4, d:3.4, height:3.4, colour:"#6E7A86", roof:"#46988C",
    cost:{wood:70, stone:50}, work:12, hp:280, age:0,
    desc:"Royal guards who patrol from it and answer to you, not to gold.",
    effect:{garrison:{cls:"pikeman", count:2}, range:12, damage:8, rate:1.6}
  },
  ballista: {
    label:"Ballista Tower", civic:true, w:2.6, d:2.6, height:7.5, colour:"#7A6647", roof:"#8C9AB6",
    cost:{wood:110, stone:80, iron:20}, work:16, hp:360, age:2,
    desc:"Dwarven work. Throws a bolt hard enough to go through two things at once.",
    effect:{range:22, damage:34, rate:2.4}
  },
  library: {
    label:"Library", civic:true, w:4.2, d:4.2, height:4.0, colour:"#A8A090", roof:"#8E7BC8",
    cost:{wood:130, stone:90, gold:60}, work:18, hp:250, age:1,
    desc:"Sells research like the university, and every spell you own costs a little less energy.",
    effect:{research:true, spellDiscount:.15, appeal:4}
  },
  fairgrounds: {
    label:"Fairgrounds", civic:true, w:6, d:6, height:2.6, colour:"#8FA55C", roof:"#D9A43F",
    cost:{wood:150, gold:80}, work:16, hp:200, age:1,
    desc:"Tournaments. Heroes gain experience here without anything trying to kill them.",
    effect:{trainHeroes:.6, appeal:8}
  },
  gardens: {
    label:"Royal Gardens", civic:true, w:5, d:5, height:2.2, colour:"#5C7A50", roof:"#7FD8A0",
    cost:{wood:90, stone:60, gold:40}, work:12, hp:160, age:1,
    desc:"Mends anything friendly that rests here, and makes the land worth living on.",
    effect:{heal:5, appeal:12}
  },
  bazaar: {
    label:"Magic Bazaar", civic:true, w:4, d:4, height:3.4, colour:"#5E5A70", roof:"#8E7BC8",
    cost:{wood:110, gold:120}, work:16, hp:220, age:2,
    desc:"Sells potions and rings to passing heroes. You tax every sale, as ever.",
    effect:{taxRate:.55, heroPotions:true, appeal:3}
  },
  gambling: {
    label:"Gambling Hall", civic:true, w:4.4, d:4.4, height:3.4, colour:"#6B5B3A", roof:"#C8504A",
    cost:{wood:120, gold:90}, work:16, hp:220, age:2,
    desc:"Pours gold into the treasury and pulls heroes off their contracts to do it.",
    effect:{produces:{gold:1.6}, distraction:.35, appeal:5}
  },
  tradingPost: {
    label:"Trading Post", civic:true, w:4, d:4, height:3.2, colour:"#8A6A4A", roof:"#C8B45A",
    cost:{wood:120, stone:40}, work:14, hp:230, age:1,
    desc:"Built out past the wall. The further from your market it stands, the more each caravan is worth.",
    effect:{produces:{gold:1.1}, caravan:true}
  },
  graveyard: {
    label:"Graveyard", civic:true, w:4, d:4, height:1.8, colour:"#5A5A62", roof:"#4A4A55",
    cost:{wood:50, stone:60}, work:10, hp:180, age:0,
    desc:"The dead go here. Left untended long enough, something comes back out of it.",
    effect:{burial:true, appeal:-3, hauntChance:.02}
  },
  barbarianHall: {
    label:"Barbarian Hall", guild:"barbarian", civic:true, w:5, d:5, height:4.2, colour:"#7A5B3E", roof:"#A8403A",
    cost:{wood:150, stone:60}, work:20, hp:320, age:1,
    desc:"Attracts barbarians. They will not take a defend flag and they cannot be bribed to retreat.",
    effect:{recruits:1}
  },
  crypt: {
    label:"Crypt of Krypta", guild:"priestess", civic:true, w:4.6, d:4.6, height:5.0, colour:"#4A4658", roof:"#6B5B8A",
    cost:{wood:140, stone:120, gold:100}, work:22, hp:300, age:2,
    desc:"Attracts priestesses who raise the dead to fight beside the living. Your alignment will suffer for it.",
    effect:{recruits:1, alignDrift:-.02}
  },
  dwarfHall: {
    label:"Dwarven Settlement", guild:"dwarf", civic:true, w:5, d:5, height:3.6, colour:"#6E6A62", roof:"#A87C4A",
    cost:{wood:130, stone:150, gold:80}, work:22, hp:400, age:1,
    desc:"Attracts dwarves. They build faster than anyone and they raise ballista towers.",
    effect:{recruits:1, buildRate:.25}
  },
  elvenLounge: {
    label:"Elven Lounge", guild:"elf", civic:true, w:4.6, d:4.6, height:4.4, colour:"#5C7A50", roof:"#8FA55C",
    cost:{wood:160, gold:140}, work:20, hp:260, age:2,
    desc:"Attracts elves and a great deal of gold. Also crime, which you will notice later.",
    effect:{recruits:1, produces:{gold:1.4}, crime:.2}
  },
  gnomeHovel: {
    label:"Gnome Hovel", guild:"gnome", civic:true, w:3, d:3, height:2.2, colour:"#8A7A5E", roof:"#6FA85E",
    cost:{wood:60}, work:8, hp:140, age:0,
    desc:"Attracts gnomes: cheap, quick, tireless builders who die if anything looks at them.",
    effect:{recruits:2, buildRate:.15}
  },

  /* ═══ BLACK & WHITE ANALOGS ════════════════════════════════ */
  workshop: {
    label:"Scaffold Workshop", civic:true, w:4.4, d:4.4, height:3.4, colour:"#7A6647", roof:"#A87C4A",
    cost:{wood:90}, work:14, hp:220, age:0,
    desc:"Turns felled timber into scaffolding. Every site raised anywhere in the realm goes up faster for it.",
    effect:{converts:{in:{wood:8}, out:{goods:2}, every:5}, buildRate:.2}
  },
  creche: {
    label:"Creche", civic:true, w:3.6, d:3.6, height:2.6, colour:"#A08A6A", roof:"#7FD8A0",
    cost:{wood:70}, work:10, hp:170, age:0,
    desc:"Children are raised here instead of underfoot. Breeders work faster when one stands nearby.",
    effect:{breedBonus:.5, appeal:6}
  },
  cemetery: {
    label:"Cemetery", civic:true, w:4.4, d:4.4, height:2.0, colour:"#8C9AB6", roof:"#C6CBDA",
    cost:{stone:90}, work:12, hp:220, age:0,
    desc:"The kept dead. Unlike a graveyard nothing crawls back out, and the living sleep better.",
    effect:{burial:true, appeal:4}
  },
  dispenser: {
    label:"Miracle Dispenser", civic:true, w:2.6, d:2.6, height:4.0, colour:"#5A5878", roof:"#B9A6F0",
    cost:{stone:120, gold:150}, work:18, hp:240, age:2,
    desc:"A standing well of power. Spell energy refills from it whether anyone is praying or not.",
    effect:{produces:{energy:1.2}, energyBonus:40}
  },

  /* ═══ BLACK & WHITE 2 ANALOGS ══════════════════════════════ */
  villa: {
    label:"Villa", civic:true, w:3.4, d:3.4, height:3.6, colour:"#B0A48A", roof:"#A8403A",
    cost:{wood:110, stone:70}, work:14, hp:200, age:1,
    desc:"Housing for people who have done well. Holds more than a house and looks far better doing it.",
    effect:{popCap:8, appeal:9}
  },
  manor: {
    label:"Manor", civic:true, w:5, d:5, height:5.4, colour:"#C0B49A", roof:"#8A5B10",
    cost:{wood:200, stone:160, gold:90}, work:22, hp:320, age:2,
    desc:"The grandest thing anyone lives in. Enormous appeal, enormous footprint.",
    effect:{popCap:14, appeal:20}
  },
  amphitheatre: {
    label:"Amphitheatre", civic:true, w:7, d:7, height:4.0, colour:"#C6CBDA", roof:"#B7BECD",
    cost:{wood:180, stone:220}, work:26, hp:380, age:2,
    desc:"Nothing here is useful. That is rather the point — it is the most impressive thing you can build short of a wonder.",
    effect:{appeal:26}
  },
  baths: {
    label:"Baths", civic:true, w:5, d:5, height:2.8, colour:"#B7BECD", roof:"#4E7FC8",
    cost:{wood:110, stone:130}, work:18, hp:260, age:1,
    desc:"Clean folk are content folk. Mends the sick and keeps the town in good humour.",
    effect:{heal:3, appeal:14}
  },
  hospital: {
    label:"Hospital", civic:true, w:5, d:5, height:3.6, colour:"#D0D6E2", roof:"#7FD8A0",
    cost:{wood:150, stone:110, gold:70}, work:22, hp:300, age:2,
    desc:"The wounded and the old are tended here. Lengthens lives and mends anything friendly nearby.",
    effect:{heal:9, lifespanBonus:8, appeal:10}
  },
  prison: {
    label:"Prison", civic:true, w:5, d:5, height:4.0, colour:"#4A4A55", roof:"#2E2E38",
    cost:{wood:120, stone:180, iron:30}, work:22, hp:420, age:2,
    desc:"Order through fear. Crime falls, appeal falls further, and your alignment drifts toward the dark.",
    effect:{appeal:-14, crime:-.6, alignDrift:-.03}
  },
  smelter: {
    label:"Smelter", civic:true, w:4.4, d:4.4, height:4.4, colour:"#6E6A62", roof:"#C8504A",
    cost:{wood:120, stone:140}, work:20, hp:300, age:1,
    desc:"Raw stone in, worked iron out. Nothing good is armoured without it.",
    effect:{converts:{in:{stone:6}, out:{iron:2}, every:6}}
  },
  storehouse: {
    label:"Storehouse", civic:true, w:5, d:5, height:3.4, colour:"#9A8F76", roof:"#6B5B3A",
    cost:{wood:120, stone:40}, work:16, hp:280, age:0,
    desc:"A second store. Gatherers carry to whichever is nearer, so the far side of the map stops being a walk.",
    effect:{storage:600, dropOff:true}
  },
  armory: {
    label:"Armory", civic:true, w:4.6, d:4.6, height:3.4, colour:"#6E7A86", roof:"#8C9AB6",
    cost:{wood:130, stone:90, iron:20}, work:18, hp:320, age:1,
    desc:"Drafts soldiers directly, without a barracks, and keeps their kit in repair.",
    effect:{unlocks:"swordsman", armourBonus:.1}
  },

  /* ═══ FOUNDATION ANALOGS (production chains) ═══════════════ */
  gatherHut: {
    label:"Gathering Hut", civic:true, w:2.6, d:2.6, height:2.4, colour:"#8A7A5E", roof:"#5C7A50",
    cost:{wood:35}, work:6, hp:130, age:0,
    desc:"Foragers work out of it. Berries come in steadily and no one has to be told to do it.",
    effect:{produces:{food:.45}, gatherBonus:.2}
  },
  fisher: {
    label:"Fisher's Hut", civic:true, w:3, d:3, height:2.6, colour:"#7A6647", roof:"#4E7FC8",
    cost:{wood:60}, work:9, hp:150, age:0,
    desc:"Works the water. A steady, unglamorous supply of food that never runs dry.",
    effect:{produces:{food:.8}}
  },
  hunterHut: {
    label:"Hunter's Hut", civic:true, w:3, d:3, height:2.6, colour:"#7A5B3E", roof:"#B58A4A",
    cost:{wood:55}, work:9, hp:150, age:0,
    desc:"Hunters range out from it after deer. Meat comes back faster than they could carry it alone.",
    effect:{gatherBonus:.35, produces:{food:.3}}
  },
  stonecutter: {
    label:"Stonecutter Camp", civic:true, w:3.6, d:3.6, height:2.8, colour:"#6E7285", roof:"#8C9AB6",
    cost:{wood:70}, work:11, hp:200, age:0,
    desc:"Cuts raw stone into blocks worth building with. Doubles as a drop-off.",
    effect:{gatherBonus:.3, converts:{in:{stone:10}, out:{goods:2}, every:7}}
  },
  bakery: {
    label:"Bakery", civic:true, w:3.6, d:3.6, height:3.0, colour:"#B0A48A", roof:"#C8A05A",
    cost:{wood:90, stone:40}, work:14, hp:200, age:1,
    desc:"Grain into bread. Feeds far more mouths than the grain would have on its own.",
    effect:{converts:{in:{food:6}, out:{food:11}, every:6}, appeal:5}
  },
  brewery: {
    label:"Brewery", civic:true, w:4, d:4, height:3.4, colour:"#8A6A4A", roof:"#C8B45A",
    cost:{wood:110, stone:40}, work:16, hp:220, age:1,
    desc:"Beer. The town is measurably happier and measurably less productive.",
    effect:{converts:{in:{food:8}, out:{goods:3}, every:7}, appeal:12}
  },
  weaver: {
    label:"Weaver's Hut", civic:true, w:3.4, d:3.4, height:2.8, colour:"#A08A6A", roof:"#C86A7A",
    cost:{wood:80}, work:12, hp:180, age:0,
    desc:"Wool from your flocks becomes cloth, and cloth is the first thing anyone will trade for.",
    effect:{converts:{in:{food:4}, out:{goods:2}, every:6}}
  },
  jeweler: {
    label:"Jeweller's Workshop", civic:true, w:3.6, d:3.6, height:3.2, colour:"#B0A48A", roof:"#D9A43F",
    cost:{wood:110, stone:70, gold:60}, work:18, hp:220, age:2,
    desc:"Turns raw gold into worked goods worth several times what went in.",
    effect:{converts:{in:{gold:10}, out:{goods:4}, every:7}, appeal:6}
  },
  weaponsmith: {
    label:"Weaponsmith", civic:true, w:4, d:4, height:3.2, colour:"#6E6A62", roof:"#A8403A",
    cost:{wood:110, stone:80, iron:20}, work:18, hp:280, age:2,
    desc:"Iron into arms. Everything your heroes buy at the market is better for it standing.",
    effect:{converts:{in:{iron:3}, out:{goods:3}, every:6}, attackBonus:.08}
  },
  well: {
    label:"Well", civic:true, w:1.8, d:1.8, height:1.8, colour:"#8C9AB6", roof:"#6E7285",
    cost:{stone:35}, work:5, hp:120, age:0,
    desc:"Clean water. Cheap, small, and everyone within reach of one lives a little longer.",
    effect:{appeal:6, heal:1.5, lifespanBonus:3}
  },
  warehouse: {
    label:"Warehouse", civic:true, w:5.4, d:5.4, height:3.8, colour:"#9A8F76", roof:"#8A6A4A",
    cost:{wood:150, stone:60}, work:18, hp:320, age:1,
    desc:"Bulk storage and the foreign trade counter. Sells surplus goods abroad for gold.",
    effect:{storage:900, dropOff:true, converts:{in:{goods:3}, out:{gold:26}, every:8}}
  },
  chapel: {
    label:"Chapel", civic:true, w:3.6, d:3.6, height:5.4, colour:"#C6CBDA", roof:"#C8B45A",
    cost:{wood:90, stone:90}, work:16, hp:240, age:0,
    desc:"A small house of worship out among the homes. Raises a little energy and settles the neighbourhood.",
    effect:{prayerRate:.4, energyBonus:15, appeal:8}
  }
};

/* ═══ NATURE ═════════════════════════════════════════════════
   Flora and fauna, and the rules that decide where they end up when
   a map is generated. Add entries here (or in the editor) and they
   appear in the world on the next restart.
   zone:  "player" (west), "wild" (middle), "monster" (east), "any"
   ═══════════════════════════════════════════════════════════ */
const NATURE = {
  flora:{
    oak:      {label:"Oak", kind:"tree", yields:"wood", amount:160, regrow:55,
               colour:"#3E6B3A", trunk:"#6B4B26", scale:1.0, shape:"conifer",
               dist:{zone:"any", density:1.0, clumps:6, spread:15, minGap:2.4}},
    pine:     {label:"Pine", kind:"tree", yields:"wood", amount:200, regrow:70,
               colour:"#2F5C42", trunk:"#5A3F22", scale:1.25, shape:"pine",
               dist:{zone:"any", density:.7, clumps:4, spread:12, minGap:2.6}},
    birch:    {label:"Birch", kind:"tree", yields:"wood", amount:120, regrow:40,
               colour:"#7FA65C", trunk:"#C6CBDA", scale:.85, shape:"round",
               dist:{zone:"player", density:.55, clumps:3, spread:11, minGap:2.2}},
    bramble:  {label:"Bramble Bush", kind:"bush", yields:"food", amount:60, regrow:34,
               colour:"#4C6B3E", berry:"#B0384A", scale:.8,
               dist:{zone:"player", density:.6, clumps:4, spread:8, minGap:1.8}},
    sunberry: {label:"Sunberry Bush", kind:"bush", yields:"food", amount:80, regrow:42,
               colour:"#5C7A46", berry:"#E0A33A", scale:.9,
               dist:{zone:"wild", density:.45, clumps:3, spread:9, minGap:1.8}},
    grass:    {label:"Wild Grass", kind:"grass", yields:null, amount:0, regrow:0,
               colour:"#4E6E42", scale:1.0, decorative:true,
               dist:{zone:"any", density:1.0, clumps:34, spread:26, minGap:0}}
  },
  fauna:{
    sheep:{label:"Sheep", cls:"sheep", dist:{zone:"player", herds:3, size:[5,8], spread:5}},
    deer: {label:"Deer",  cls:"deer",  dist:{zone:"wild",   herds:2, size:[2,4], spread:9}}
  },
  minerals:{
    rock:    {label:"Stone Seam", kind:"rock",    yields:"stone", amount:260,
              dist:{zone:"any", clumps:3, count:9, spread:8}},
    vein:    {label:"Gold Vein",  kind:"vein",    yields:"gold",  amount:190,
              dist:{zone:"any", clumps:2, count:5, spread:6}},
    deposit: {label:"Gold Deposit", kind:"deposit", yields:"gold", amount:520,
              dist:{zone:"any", clumps:3, count:2, spread:6}}
  },
  zones:{
    player:  {x1:-166, x2:-26},
    wild:    {x1:-40,  x2:60},
    monster: {x1:50,   x2:166},
    any:     {x1:-166, x2:70}
  }
};

/* ── research: bought by clicking the building that offers it ── */
const RESEARCH = {
  /* — Blacksmith: arms and armour, in the Age of Empires manner — */
  forging:      {at:"blacksmith", label:"Forging",        cost:{gold:120, stone:60},  age:1,
                 desc:"+2 melee damage to every armed thing you own.", effect:{meleeDamage:2}},
  ironCasting:  {at:"blacksmith", label:"Iron Casting",   cost:{gold:240, stone:120}, age:2, needs:"forging",
                 desc:"+3 more melee damage.", effect:{meleeDamage:3}},
  scaleMail:    {at:"blacksmith", label:"Scale Mail",     cost:{gold:140, stone:80},  age:1,
                 desc:"+2 armour on every soldier and hero.", effect:{armour:2}},
  chainMail:    {at:"blacksmith", label:"Chain Mail",     cost:{gold:260, stone:140}, age:2, needs:"scaleMail",
                 desc:"+3 more armour.", effect:{armour:3}},
  fletching:    {at:"blacksmith", label:"Fletching",      cost:{gold:130, wood:120},  age:1,
                 desc:"+2 damage and +1 range on everything that shoots.", effect:{rangedDamage:2, rangedRange:1}},
  bodkinArrow:  {at:"blacksmith", label:"Bodkin Arrows",  cost:{gold:250, wood:220},  age:2, needs:"fletching",
                 desc:"+3 more shooting damage and +1 range.", effect:{rangedDamage:3, rangedRange:1}},

  /* — University: economy, structures and the divine — */
  masonry:      {at:"university", label:"Masonry",        cost:{stone:180, gold:100}, age:2,
                 desc:"+30% structure on every wall, tower and building.", effect:{buildingHp:.3}},
  architecture: {at:"university", label:"Architecture",   cost:{stone:300, gold:200}, age:3, needs:"masonry",
                 desc:"+30% more structure, and builders work a third faster.", effect:{buildingHp:.3, buildRate:.33}},
  doubleBitAxe: {at:"university", label:"Double-Bit Axe", cost:{wood:150, gold:80},   age:1,
                 desc:"Foresters cut 35% faster.", effect:{woodRate:.35}},
  stoneMining:  {at:"university", label:"Stone Mining",   cost:{wood:130, gold:80},   age:1,
                 desc:"Miners work 35% faster.", effect:{oreRate:.35}},
  wheelbarrow:  {at:"university", label:"Wheelbarrow",    cost:{wood:180, gold:140},  age:2,
                 desc:"Villagers move 25% faster and carry half again as much.", effect:{folkSpeed:.25, carry:.5}},
  theocracy:    {at:"university", label:"Theocracy",      cost:{gold:260, stone:120}, age:2,
                 desc:"Acolytes raise spell energy 60% faster.", effect:{prayerRate:.6}},
  heraldry:     {at:"university", label:"Heraldry",       cost:{gold:300},            age:2,
                 desc:"Heroes accept 20% less gold for the same contract.", effect:{bountyDiscount:.2}},
  ballistics:   {at:"university", label:"Ballistics",     cost:{wood:200, gold:180},  age:3,
                 desc:"Watchtowers fire 40% faster and reach 25% further.", effect:{towerRate:.4, towerRange:.25}}
};

/* ── flags ───────────────────────────────────────────────────── */
const FLAGS = {
  attack: {
    label:"Attack", colour:"#C8504A", key:"A", maxFlags:6,
    basePrice:60, minPrice:0, maxPrice:400,
    desc:"Clear everything hostile around this point. Priced per kill.",
    appeal:{risk:1.0, dutyWeight:26, distWeight:.035}
  },
  defend: {
    label:"Defend", colour:"#4E7FC8", key:"D", maxFlags:6,
    basePrice:30, minPrice:0, maxPrice:300,
    desc:"Hold this ground and engage anything that comes near. Paid as a retainer for every five seconds held.",
    appeal:{risk:.55, dutyWeight:44, distWeight:.05}
  },
  follow: {
    label:"Follow", colour:"#5F9159", key:"F", maxFlags:6,
    basePrice:90, minPrice:0, maxPrice:400,
    desc:"Shadow a moving charge — a cart, a villager, or your creature — and keep it alive.",
    appeal:{risk:.8, dutyWeight:34, distWeight:.02}
  }
};

/* ── spells (number keys) ────────────────────────────────────── */
const SPELLS = {
  heal:      {key:"1", label:"Mend",        cost:18, radius:7,  align:+6, colour:"#5F9159",
              desc:"Knits every friendly thing in the circle back together."},
  bless:     {key:"2", label:"Quicken",     cost:26, radius:10, align:+4, colour:"#C8B45A", dur:24,
              desc:"Hastens work and regrowth across the circle for a while."},
  shield:    {key:"3", label:"Aegis",       cost:34, radius:9,  align:+2, colour:"#46988C", dur:18,
              desc:"A ward over the circle. Damage taken is halved while it holds."},
  roots:     {key:"4", label:"Binding",     cost:22, radius:8,  align:-1, colour:"#5F7A38", dur:5,
              desc:"Roots erupt and hold every hostile thing in the circle where it stands."},
  lightning: {key:"5", label:"Levinbolt",   cost:30, radius:5,  align:-6, colour:"#8E7BC8", damage:70,
              desc:"One bolt, one crater. It does not check whose side anyone is on."},
  firestorm: {key:"6", label:"Firestorm",   cost:55, radius:11, align:-12,colour:"#C8504A", damage:34, dur:5,
              desc:"Burns the circle for several seconds. Burns your own folk just as happily."}
};

/* ── alignment ───────────────────────────────────────────────── */
const ALIGNMENT = {
  range:100,
  good:{label:"Benevolent", colour:"#E4E9F2", accent:"#C8B45A"},
  neutral:{label:"Impartial", colour:"#9AA3B8", accent:"#7C8AA6"},
  evil:{label:"Tyrannical", colour:"#3A2430", accent:"#C8504A"},
  deltas:{
    healVillager:+3, blessLand:+2, prayerTick:+0.05, feedFolk:+2, buildHouse:+1,
    killMonster:+0.4, tossRock:0, tossVillager:-6, killVillager:-14,
    burnLand:-8, lightningFolk:-10, creatureEatsFolk:-9, creatureHelps:+3
  }
};

/* ── the four creatures you may be given ─────────────────────── */
const CREATURES = {
  ox: {
    label:"The Ox", shape:"ox", colour:"#8A7A5E", accent:"#5E5140",
    hp:1100, speed:4.0, radius:2.0, height:5.0, attackRange:3.6, attackSpeed:1.9, damage:30,
    baseSkills:{hitpoints:52, attack:26, strength:38, defence:40},
    trait:"Slow and immovable. Takes a beating meant for your walls.",
    hungerRate:.7
  },
  wolf: {
    label:"The Wolf", shape:"wolf", colour:"#6E7285", accent:"#454A5E",
    hp:520, speed:8.2, radius:1.4, height:3.8, attackRange:2.8, attackSpeed:.85, damage:38,
    baseSkills:{hitpoints:26, attack:42, strength:34, defence:18},
    trait:"Fast and merciless. Reaches a lair before your heroes have finished haggling.",
    hungerRate:1.5
  },
  ape: {
    label:"The Ape", shape:"ape", colour:"#7A5B3E", accent:"#4E3A28",
    hp:760, speed:5.4, radius:1.8, height:5.4, attackRange:3.2, attackSpeed:1.3, damage:46,
    baseSkills:{hitpoints:38, attack:34, strength:48, defence:26},
    trait:"Hits hardest of the four. Also the most likely to pick something up and throw it.",
    hungerRate:1.1
  },
  tortoise: {
    label:"The Tortoise", shape:"tortoise", colour:"#5C7A50", accent:"#3C5236",
    hp:1400, speed:3.0, radius:2.2, height:3.6, attackRange:3.0, attackSpeed:2.2, damage:20,
    baseSkills:{hitpoints:66, attack:20, strength:24, defence:54},
    trait:"Barely moves and barely dies. Mends itself where it stands.",
    hungerRate:.5, regen:.9
  }
};

/* ── the creature's mind ─────────────────────────────────────── */
const CREATURE = {
  learnRate:.25, hungerRate:.9, wanderRadius:26,
  leashPull:11, leashSnap:34,
  thoughts:{
    idle:["Nothing is happening.","I could be doing something.","Where did everyone go?","I am very large."],
    hungry:["I am hungry.","Those look edible.","Something ought to be eaten."],
    leashed:["Where are we going?","Pulled again.","Fine. I am coming."],
    fighting:["This one first.","Smaller than me.","Good."],
    petted:["Oh. That is nice.","More of that.","I am appreciated."],
    slapped:["That hurt.","Why.","I will remember that."],
    hugged:["Warm.","I am safe.","Do not let go."],
    thrown:["Wheee—","I was not ready.","Put me down."]
  }
};

/* ── missions ────────────────────────────────────────────────── */
const MISSIONS = [
  {id:"clear_lair",   flag:"attack", label:"Break the {lair}",
   brief:"Post an attack flag on the lair and see it emptied.", reward:{gold:220, xp:400}, target:"lair", need:6},
  {id:"hold_gate",    flag:"defend", label:"Hold the {place} for {t}s",
   brief:"Keep a defend flag manned while the horde tests the line.", reward:{gold:180, xp:320}, target:"gate", need:60},
  {id:"escort_cart",  flag:"follow", label:"See the cart to the {place}",
   brief:"A laden cart must cross open ground. Post an escort flag on it.", reward:{gold:260, xp:520}, target:"cart", need:1},
  {id:"cull",         flag:"attack", label:"Cull {n} of them",
   brief:"Numbers, not ground. Pay whatever it takes.", reward:{gold:150, xp:260}, target:"kills", need:12}
];

/* ── the clock, and how long people live ─────────────────────── */
const TIME = {
  secondsPerHour: 6,        // real seconds for one in-world hour
  hoursPerDay: 24,
  daysPerYear: 365,
  lifespanMin: 70,          // each person rolls their own span in this band
  lifespanMax: 110,
  childhoodYears: 14,       // before this they cannot work or breed
  breedingMinAge: 18,
  breedingMaxAge: 45,
  breedingCooldownDays: 300,
  gestationDays: 270
};

/* ── threats: the lairs, whether they run at all, and how they come back ── */
const THREATS = {
  enabled: true,
  respawnMode: "same",      // "same" | "new" | "never"
  respawnDelaySeconds: 90,
  wanderRadius: 40,         // how far a "new" location may be from the old one
  lairHp: 400,
  escalatePerMinute: 0.06
};

/* ── how the creature learns your miracles by watching ───────── */
const SPELL_LEARNING = {
  maxLevel: 10,
  /* watches needed for each level, scaled per spell by its own difficulty */
  watchesForLevel: [3, 8, 16, 28, 45, 68, 98, 140, 200, 280],
  /* chance to pull it off at each level, 1..10 */
  successByLevel: [0.11, 0.22, 0.34, 0.46, 0.58, 0.70, 0.80, 0.90, 0.99, 1.00],
  masteryBonus: 1.75,       // level 10 makes the spell this much stronger
  /* multiplies the watch requirement — a hard spell starts at 25 watches */
  difficulty: {heal:1, bless:1.4, shield:2.2, roots:2.6, lightning:6.5, firestorm:8.3}
};

/* ── modes ───────────────────────────────────────────────────── */
const GAME_MODES = {
  single:    {label:"Single player instance", desc:"Your world, yours alone."},
  sandbox:   {label:"Sandbox", desc:"No threats, nothing to lose."},
  siege:     {label:"Siege", desc:"Threats escalate twice as fast."}
};

/* ── world / tuning ──────────────────────────────────────────── */
const TUNING = {
  world:{size:340, tile:2, seed:1337},
  economy:{tithe:3.2, startWood:340, startStone:220, startGold:420, startFood:120,
           depositAmount:12, gatherTime:1.6, buildRate:1.0},
  population:{startVillagers:8, growthEvery:16, baseCap:8, staffFloor:3},
  combat:{xpPerDamage:4, xpPerHeal:3, fleeThreshold:.3},
  lairs:{spawnEvery:6.5, escalate:.9, maxAlive:26},
  camera:{minDist:14, maxDist:120, startDist:52, minPitch:.18, maxPitch:1.32, panSpeed:1, zoomSpeed:1},
  ageing:{yearsPerMinute:1.1}
};

/* ── ages ────────────────────────────────────────────────────── */
const AGES = [
  {label:"Dark Age",     cost:null},
  {label:"Feudal Age",   cost:{wood:340, stone:180}, keepTier:2},
  {label:"Castle Age",   cost:{wood:600, stone:450, gold:300}, keepTier:3},
  {label:"Imperial Age", cost:{wood:900, stone:700, gold:650}, keepTier:4}
];

/* ── the starting map (fully editable pre-runtime) ───────────── */
const MAP = {
  name:"Aldermarch",
  villageCentre:{x:-80, z:0},
  /* Two companies of eight, one of each adventuring class, on the field
     from the first frame. They answer flags like any other hero. */
  startingCompanies:[
    {name:"The Aegis Company", x:-100, z:-8,
     roster:["warrior","warrior","ranger","ranger","druid","druid","rogue","wizard"]},
    {name:"The Vardan Company", x:-100, z:8,
     roster:["warrior","warrior","ranger","ranger","druid","druid","rogue","wizard"]},
    /* the mage tower's own, on the field from the start */
    {name:"The Conclave", x:-40, z:16,
     roster:["wizard","wizard","wizard"]}
  ],
  /* A proper village from the first frame, laid out inside a wall that
     actually encloses it. */
  /* A working town inside a wall that actually contains it: homes, food,
     industry, faith, learning, guilds and comfort all within the line. */
  buildings:[
    /* — the heart — */
    {type:"keep",         x:-92, z:0,   tier:1},
    {type:"temple",       x:-52, z:0,   tier:1},
    {type:"store",        x:-76, z:-14, tier:1},
    {type:"storehouse",   x:-76, z:16,  tier:1},
    /* — gathering & food — */
    {type:"lumber",       x:-104, z:-32, tier:1},
    {type:"mine",         x:-104, z:32,  tier:1},
    {type:"farm",         x:-86, z:34,  tier:1},
    {type:"mill",         x:-74, z:38,  tier:1},
    {type:"gatherHut",    x:-98, z:-46, tier:1},
    {type:"hunterHut",    x:-98, z:46,  tier:1},
    {type:"well",         x:-70, z:-4,  tier:1},
    {type:"well",         x:-70, z:8,   tier:1},
    /* — workshops — */
    {type:"workshop",     x:-88, z:-28, tier:1},
    {type:"smelter",      x:-88, z:24,  tier:1},
    {type:"bakery",       x:-64, z:30,  tier:1},
    {type:"blacksmith",   x:-64, z:-28, tier:1},
    /* — trade & comfort — */
    {type:"market",       x:-60, z:-16, tier:1},
    {type:"tavern",       x:-60, z:16,  tier:1},
    {type:"baths",        x:-44, z:22,  tier:1},
    {type:"gardens",      x:-44, z:-22, tier:1},
    {type:"creche",       x:-56, z:-34, tier:1},
    {type:"cemetery",     x:-108, z:6,  tier:1},
    /* — faith & learning — */
    {type:"chapel",       x:-40, z:-8,  tier:1},
    {type:"mageTower",    x:-38, z:10,  tier:1},
    {type:"library",      x:-52, z:-40, tier:1},
    {type:"university",   x:-52, z:40,  tier:1},
    /* — guilds — */
    {type:"warriorGuild", x:-108, z:-18, tier:1},
    {type:"rangerLodge",  x:-108, z:18,  tier:1},
    {type:"druidGrove",   x:-118, z:0,   tier:1},
    /* — homes — */
    {type:"house",        x:-84, z:-44, tier:1},
    {type:"house",        x:-78, z:-48, tier:1},
    {type:"house",        x:-84, z:44,  tier:1},
    {type:"house",        x:-78, z:48,  tier:1},
    {type:"villa",        x:-68, z:-44, tier:1},
    {type:"villa",        x:-68, z:44,  tier:1},
    {type:"hut",          x:-96, z:-52, tier:1},
    {type:"hut",          x:-96, z:52,  tier:1},
    {type:"hut",          x:-110, z:-44, tier:1},
    {type:"hut",          x:-110, z:44,  tier:1},
    /* — the line, lit — */
    {type:"tower",        x:-30, z:-30, tier:1},
    {type:"tower",        x:-30, z:30,  tier:1},
    {type:"guardhouse",   x:-36, z:0,   tier:1},
    {type:"torch",        x:-30, z:-10, tier:1},
    {type:"torch",        x:-30, z:10,  tier:1},
    {type:"torch",        x:-30, z:-20, tier:1},
    {type:"torch",        x:-30, z:20,  tier:1},
    {type:"torch",        x:-52, z:-14, tier:1},
    {type:"torch",        x:-52, z:14,  tier:1},
    {type:"torch",        x:-80, z:-30, tier:1},
    {type:"torch",        x:-80, z:30,  tier:1},
    {type:"torch",        x:-100, z:0,  tier:1},
    {type:"gate",         x:-28, z:-2,  tier:1},
    {type:"gate",         x:-28, z:0,   tier:1},
    {type:"gate",         x:-28, z:2,   tier:1},

    /* ── the military encampment, outside the east gate ── */
    {type:"barracks",     x:-6,  z:-14, tier:1},
    {type:"archery",      x:-6,  z:14,  tier:1},
    {type:"armory",       x:4,   z:0,   tier:1},
    {type:"storehouse",   x:-14, z:0,   tier:1},
    {type:"hut",          x:4,   z:-16, tier:1},
    {type:"hut",          x:4,   z:16,  tier:1},
    {type:"tower",        x:12,  z:-12, tier:1},
    {type:"tower",        x:12,  z:12,  tier:1},
    {type:"torch",        x:-2,  z:-6,  tier:1},
    {type:"torch",        x:-2,  z:6,   tier:1},
    {type:"gate",         x:14,  z:0,   tier:1},

    /* ── the wonder, deliberately outside the walls ── */
    {type:"wonder",       x:-70, z:-88, tier:1}
  ],
  /* The city wall, with a triple gate east. A second, smaller palisade
     ring holds the military encampment beyond it. */
  wallRuns:[
    {x1:-28,  z1:-58, x2:-28,  z2:-4,  type:"wall"},
    {x1:-28,  z1:4,   x2:-28,  z2:58,  type:"wall"},
    {x1:-30,  z1:-58, x2:-124, z2:-58, type:"wall"},
    {x1:-30,  z1:58,  x2:-124, z2:58,  type:"wall"},
    {x1:-126, z1:-58, x2:-126, z2:-14, type:"wall"},
    {x1:-126, z1:14,  x2:-126, z2:58,  type:"wall"},
    /* the encampment's own palisade */
    {x1:-18,  z1:-22, x2:16,   z2:-22, type:"palisade"},
    {x1:-18,  z1:22,  x2:16,   z2:22,  type:"palisade"},
    {x1:16,   z1:-22, x2:16,   z2:-2,  type:"palisade"},
    {x1:16,   z1:2,   x2:16,   z2:22,  type:"palisade"},
    {x1:-18,  z1:-22, x2:-18,  z2:22,  type:"palisade"}
  ],
  /* Squads mustered at the encampment from the first frame. */
  startingSquads:[
    {name:"Shield Company", colour:"#D9A43F", x:-6, z:-8,
     roster:["swordsman","swordsman","swordsman","swordsman","pikeman","pikeman"]},
    {name:"Longbow Company", colour:"#5F9159", x:-6, z:8,
     roster:["archer","archer","archer","archer","archer","archer"]}
  ],
  nodeClusters:[
    {kind:"tree",  x:-70, z:-34, count:22, spread:16},
    {kind:"tree",  x:-66, z:34,  count:20, spread:15},
    {kind:"tree",  x:-16, z:-46, count:16, spread:13},
    {kind:"tree",  x:-8,  z:42,  count:14, spread:12},
    {kind:"rock",  x:-24, z:-16, count:9,  spread:8},
    {kind:"rock",  x:-22, z:20,  count:8,  spread:8},
    {kind:"vein",    x:-6,  z:-4,  count:5, spread:6},
    {kind:"vein",    x:-12, z:30,  count:4, spread:5},
    {kind:"deposit", x:-64, z:2,   count:2, spread:5},
    {kind:"deposit", x:2,   z:-20, count:2, spread:7},
    {kind:"deposit", x:16,  z:24,  count:1, spread:3}
  ],
  herds:[
    {kind:"sheep", x:-58, z:-14, count:7, spread:5},
    {kind:"sheep", x:-56, z:16,  count:6, spread:5},
    {kind:"sheep", x:-18, z:-34, count:5, spread:6},
    {kind:"deer",  x:-30, z:-40, count:3, spread:9},
    {kind:"deer",  x:-20, z:38,  count:2, spread:8}
  ],
  spawns:[
    {id:"north_lair", x:96,  z:-62, kind:"gnoll",  every:7.0, cap:9,  radius:5, label:"North Lair"},
    {id:"south_lair", x:104, z:56,  kind:"gnoll",  every:7.5, cap:9,  radius:5, label:"South Lair"},
    {id:"deep_lair",  x:136, z:-6,  kind:"ogre",   every:15,  cap:5,  radius:6, label:"Deep Lair"},
    {id:"barrow",     x:76,  z:4,   kind:"wraith", every:26,  cap:3,  radius:4, label:"The Barrow"},
    {id:"far_lair",   x:150, z:70,  kind:"gnoll",  every:9.0, cap:8,  radius:5, label:"Far Lair"},
    {id:"deep_north", x:144, z:-74, kind:"ogre",   every:19,  cap:4,  radius:6, label:"Northern Deep"}
  ],
  enemyBuildings:[
    {type:"wall", x:58, z:-18, tier:1, enemy:true},
    {type:"wall", x:58, z:-16, tier:1, enemy:true},
    {type:"wall", x:58, z:16,  tier:1, enemy:true},
    {type:"wall", x:58, z:18,  tier:1, enemy:true},
    {type:"tower", x:70, z:0,  tier:1, enemy:true}
  ]
};

/* ── jobs ────────────────────────────────────────────────────── */
const JOBS = {
  idle:    {label:"Idle",      colour:"#8A93AC", skill:null,           desc:"Awaiting orders."},
  forester:{label:"Forester",  colour:"#5F9159", skill:"woodcutting",  desc:"Fells trees and carries timber to the store."},
  miner:   {label:"Miner",     colour:"#7C8AA6", skill:"mining",       desc:"Works stone seams and gold veins."},
  builder: {label:"Builder",   colour:"#D9A43F", skill:"construction", desc:"Raises what you place, repairs what breaks, and sites houses."},
  acolyte: {label:"Acolyte",   colour:"#C8B45A", skill:"prayer",       desc:"Worships at the temple, which is where your spell energy comes from."},
  farmer:  {label:"Farmer",    colour:"#8FA55C", skill:"farming",      desc:"Works the farmstead. Soldiers do not train without food."},
  hunter:  {label:"Hunter",    colour:"#B58A4A", skill:"ranged",       desc:"Runs down sheep and deer and carries the meat to the store."},
  forager: {label:"Forager",   colour:"#C86A7A", skill:"farming",      desc:"Strips the berry bushes and carries the fruit to the store."},
  breeder: {label:"Breeder",   colour:"#D07FA8", skill:"breeding",     desc:"Raises families. They will outbreed the housing if there is timber for more."},
  worshipper:{label:"Worshipper", colour:"#E0C060", skill:"prayer",    desc:"Bound to the temple floor. Produces the spell energy you spend."},
  artisan: {label:"Artisan",   colour:"#A87C4A", skill:"smithing",     desc:"Works the converters — smelter, bakery, brewery, weaponsmith — turning one resource into another."}
};

global.DB = {
  XP_TABLE, xpForLevel, levelFor, xpProgress,
  SKILLS, ITEMS, GEAR_LADDER, CLASSES, BUILDINGS, RESOURCES, FLAGS, SPELLS, RESEARCH,
  PART_PRESETS, BUILDING_META_DEFAULTS,
  ALIGNMENT, CREATURE, CREATURES, MISSIONS, TUNING, AGES, MAP, JOBS, NATURE,
  TIME, THREATS, SPELL_LEARNING, GAME_MODES
};

})(window);
/* ===== engine.js ===== */
/* ═══════════════════════════════════════════════════════════════
   SOVEREIGN AEGIS — ENGINE
   Three.js scene, RTS camera (pan / zoom / orbit), picking, and
   every mesh in the game built from boxes, cones, cylinders and
   spheres. Deliberately low fidelity — readable at a glance.
   ═══════════════════════════════════════════════════════════════ */
(function (global) {
"use strict";

const T = global.THREE;
const DB = global.DB;

const E = {
  scene:null, camera:null, renderer:null, clock:null,
  ground:null, groundHit:null, sun:null,
  cam:{target:new T.Vector3(-40,0,0), dist:DB.TUNING.camera.startDist, yaw:-0.62, pitch:0.72},
  pointer:new T.Vector2(), ray:new T.Raycaster(),
  cursorWorld:new T.Vector3(), hoveredEntity:null,
  keys:Object.create(null), dragging:null, container:null,
  materials:Object.create(null)
};

/* ── materials (cached, flat-shaded) ─────────────────────────── */
function mat(hex, opts){
  const k = hex + "|" + JSON.stringify(opts || {});
  if (E.materials[k]) return E.materials[k];
  const m = new T.MeshLambertMaterial(Object.assign({color:new T.Color(hex)}, opts || {}));
  E.materials[k] = m;
  return m;
}
E.mat = mat;

/* ── boot ────────────────────────────────────────────────────── */
E.init = function (container){
  E.container = container;
  const scene = E.scene = new T.Scene();
  scene.background = new T.Color("#05070E");
  scene.fog = new T.Fog("#05070E", 80, 210);

  const cam = E.camera = new T.PerspectiveCamera(46, 1, .5, 600);
  const r = E.renderer = new T.WebGLRenderer({antialias:true, powerPreference:"high-performance"});
  r.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
  r.shadowMap.enabled = true;
  r.shadowMap.type = T.PCFSoftShadowMap;
  container.appendChild(r.domElement);

  scene.add(new T.HemisphereLight("#7C93C4", "#1A1C26", .62));
  const sun = E.sun = new T.DirectionalLight("#F4E4C4", .82);
  sun.position.set(46, 70, 32);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  const S = 120, c = sun.shadow.camera;
  c.left = -S; c.right = S; c.top = S; c.bottom = -S; c.near = 1; c.far = 260;
  scene.add(sun, sun.target);

  buildGround();
  E.clock = new T.Clock();
  E.resize();
  addEventListener("resize", E.resize);
  bindInput(r.domElement);
  return E;
};

E.resize = function (){
  if (!E.container) return;
  const w = E.container.clientWidth || 1, h = E.container.clientHeight || 1;
  E.camera.aspect = w / h;
  E.camera.updateProjectionMatrix();
  E.renderer.setSize(w, h, false);
};

/* ── ground ──────────────────────────────────────────────────── */
function buildGround(){
  const S = DB.TUNING.world.size;
  const g = new T.PlaneGeometry(S, S, 1, 1);
  g.rotateX(-Math.PI/2);
  const ground = E.ground = new T.Mesh(g, mat("#22302B"));
  ground.receiveShadow = true;
  E.scene.add(ground);
  E.groundHit = ground;

  // the monsters' half, tinted
  const g2 = new T.PlaneGeometry(S/2 - 26, S, 1, 1);
  g2.rotateX(-Math.PI/2);
  const bad = new T.Mesh(g2, mat("#2B2020"));
  bad.position.set(S/4 + 13, .02, 0);
  bad.receiveShadow = true;
  E.scene.add(bad);

  const grid = new T.GridHelper(S, S/DB.TUNING.world.tile, "#2E463E", "#26362F");
  grid.material.opacity = .3; grid.material.transparent = true;
  grid.position.y = .03;
  E.scene.add(grid);
}

/* ── camera ──────────────────────────────────────────────────── */
E.updateCamera = function (dt){
  const C = DB.TUNING.camera, k = E.keys;
  const sp = (k.shift ? 46 : 24) * dt * (E.cam.dist / 40) * C.panSpeed;
  let fx = 0, fz = 0;
  if (k.w || k.arrowup) fz -= 1;
  if (k.s || k.arrowdown) fz += 1;
  if (k.a || k.arrowleft) fx -= 1;
  if (k.d || k.arrowright) fx += 1;
  if (fx || fz){
    const sin = Math.sin(E.cam.yaw), cos = Math.cos(E.cam.yaw);
    E.cam.target.x += (fx*cos - fz*sin) * sp;
    E.cam.target.z += (fx*sin + fz*cos) * sp;
  }
  if (k.q) E.cam.yaw -= dt*1.3;
  if (k.e) E.cam.yaw += dt*1.3;

  const lim = DB.TUNING.world.size/2 - 6;
  E.cam.target.x = Math.max(-lim, Math.min(lim, E.cam.target.x));
  E.cam.target.z = Math.max(-lim, Math.min(lim, E.cam.target.z));
  E.cam.pitch = Math.max(C.minPitch, Math.min(C.maxPitch, E.cam.pitch));
  E.cam.dist  = Math.max(C.minDist, Math.min(C.maxDist, E.cam.dist));

  const d = E.cam.dist, p = E.cam.pitch, y = E.cam.yaw;
  E.camera.position.set(
    E.cam.target.x + Math.sin(y) * Math.cos(p) * d,
    E.cam.target.y + Math.sin(p) * d,
    E.cam.target.z + Math.cos(y) * Math.cos(p) * d
  );
  E.camera.lookAt(E.cam.target);

  E.sun.position.set(E.cam.target.x + 46, 78, E.cam.target.z + 34);
  E.sun.target.position.copy(E.cam.target);
  E.sun.target.updateMatrixWorld();
};

E.focusOn = function (x, z, dist){
  E.cam.target.set(x, 0, z);
  if (dist) E.cam.dist = dist;
};

/* ── input ───────────────────────────────────────────────────── */
E.onPointer = {down:null, up:null, move:null, dbl:null, wheel:null};

function bindInput(dom){
  const rect = () => dom.getBoundingClientRect();

  function setPointer(ev){
    const r = rect();
    E.pointer.x = ((ev.clientX - r.left) / r.width) * 2 - 1;
    E.pointer.y = -((ev.clientY - r.top) / r.height) * 2 + 1;
    E.screen = {x:ev.clientX - r.left, y:ev.clientY - r.top, cx:ev.clientX, cy:ev.clientY};
  }

  let orbiting = false, lastX = 0, lastY = 0;

  dom.addEventListener("contextmenu", e => e.preventDefault());

  /* Drag the camera by the ground under the cursor. */
  E.panBy = function (dx, dy){
    const s = E.cam.dist * .0022;
    const sin = Math.sin(E.cam.yaw), cos = Math.cos(E.cam.yaw);
    const mx = -dx*s, mz = -dy*s;
    E.cam.target.x += (mx*cos - mz*sin);
    E.cam.target.z += (mx*sin + mz*cos);
  };

  dom.addEventListener("pointerdown", ev => {
    setPointer(ev);
    dom.setPointerCapture(ev.pointerId);
    lastX = ev.clientX; lastY = ev.clientY;
    if (ev.button === 1 || (ev.button === 0 && E.keys.space)){ orbiting = true; ev.preventDefault(); return; }
    E.updateCursorWorld();
    if (E.onPointer.down) E.onPointer.down(ev);
  });

  dom.addEventListener("pointermove", ev => {
    setPointer(ev);
    const dx = ev.clientX - lastX, dy = ev.clientY - lastY;
    lastX = ev.clientX; lastY = ev.clientY;
    E.drag = {dx, dy};
    if (orbiting){
      E.cam.yaw -= dx*.006;
      E.cam.pitch += dy*.005;
      return;
    }
    E.updateCursorWorld();
    if (E.onPointer.move) E.onPointer.move(ev);
  });

  addEventListener("pointerup", ev => {
    if (orbiting && (ev.button === 1 || ev.button === 0)){ orbiting = false; return; }
    if (E.onPointer.up) E.onPointer.up(ev);
  });

  dom.addEventListener("dblclick", ev => { setPointer(ev); if (E.onPointer.dbl) E.onPointer.dbl(ev); });

  dom.addEventListener("wheel", ev => {
    ev.preventDefault();
    E.cam.dist *= (1 + Math.sign(ev.deltaY) * .11 * DB.TUNING.camera.zoomSpeed);
  }, {passive:false});

  addEventListener("keydown", ev => {
    const k = ev.key.toLowerCase();
    E.keys[k === " " ? "space" : k] = true;
    E.keys.shift = ev.shiftKey;
    if (k === " " && ev.target === document.body) ev.preventDefault();
  });
  addEventListener("keyup", ev => {
    const k = ev.key.toLowerCase();
    E.keys[k === " " ? "space" : k] = false;
    E.keys.shift = ev.shiftKey;
  });
  addEventListener("blur", () => { for (const k in E.keys) E.keys[k] = false; });
}

E.updateCursorWorld = function (){
  E.ray.setFromCamera(E.pointer, E.camera);
  const hit = E.ray.ray.intersectPlane(new T.Plane(new T.Vector3(0,1,0), 0), new T.Vector3());
  if (hit) E.cursorWorld.copy(hit);
  return E.cursorWorld;
};

E.pick = function (objects){
  E.ray.setFromCamera(E.pointer, E.camera);
  const hits = E.ray.intersectObjects(objects, true);
  return hits.length ? hits[0] : null;
};

E.project = function (v3){
  const p = v3.clone().project(E.camera);
  const w = E.container.clientWidth, h = E.container.clientHeight;
  return {x:(p.x*.5+.5)*w, y:(-p.y*.5+.5)*h, behind:p.z > 1};
};

/* ═══ PRIMITIVE MESH FACTORY ═════════════════════════════════ */
const box = (w,h,d,c) => new T.Mesh(new T.BoxGeometry(w,h,d), mat(c));
const cyl = (rt,rb,h,c,seg) => new T.Mesh(new T.CylinderGeometry(rt,rb,h,seg||8), mat(c));
const cone = (r,h,c,seg) => new T.Mesh(new T.ConeGeometry(r,h,seg||8), mat(c));
const sph = (r,c,seg) => new T.Mesh(new T.SphereGeometry(r,seg||10,seg||8), mat(c));
E.prim = {box, cyl, cone, sph};

function shade(m){ m.castShadow = true; m.receiveShadow = true; return m; }
function grp(children){
  const g = new T.Group();
  children.forEach(c => { shade(c); g.add(c); });
  return g;
}

/* ── trees / rocks / veins ───────────────────────────────────── */
/* Flora built from a NATURE.flora entry. */
E.makeFlora = function (def, scale){
  const s = (scale || 1) * (def.scale || 1);
  const g = new T.Group();
  if (def.kind === "grass"){
    for (let i = 0; i < 7; i++){
      const b = new T.Mesh(new T.ConeGeometry(.07*s, (.5 + Math.random()*.55)*s, 3), mat(def.colour));
      b.position.set((Math.random()-.5)*1.5*s, .3*s, (Math.random()-.5)*1.5*s);
      b.rotation.z = (Math.random()-.5)*.5;
      b.receiveShadow = true;
      g.add(b);
    }
    return g;
  }
  if (def.kind === "bush"){
    const body = new T.Mesh(new T.SphereGeometry(.72*s, 8, 6), mat(def.colour));
    body.scale.y = .8; body.position.y = .6*s;
    shade(body); g.add(body);
    for (let i = 0; i < 6; i++){
      const b = sph(.11*s, def.berry, 5);
      const a = Math.random()*6.28, r = .55*s;
      b.position.set(Math.cos(a)*r, (.45 + Math.random()*.55)*s, Math.sin(a)*r);
      shade(b); g.add(b);
    }
    return g;
  }
  // trees
  const trunk = cyl(.15*s, .21*s, 1.5*s, def.trunk || "#6B4B26");
  trunk.position.y = .75*s;
  shade(trunk); g.add(trunk);
  if (def.shape === "pine"){
    for (let i = 0; i < 3; i++){
      const c = cone((1.05 - i*.26)*s, (1.5 - i*.2)*s, def.colour, 7);
      c.position.y = (1.9 + i*.95)*s;
      shade(c); g.add(c);
    }
  } else if (def.shape === "round"){
    const c = new T.Mesh(new T.SphereGeometry(1.05*s, 8, 6), mat(def.colour));
    c.position.y = 2.4*s; c.scale.y = 1.15;
    shade(c); g.add(c);
  } else {
    const c1 = cone(1.05*s, 2.0*s, def.colour, 7); c1.position.y = 2.1*s;
    const c2 = cone(.78*s, 1.5*s, def.colour, 7);  c2.position.y = 3.1*s;
    shade(c1); shade(c2); g.add(c1, c2);
  }
  return g;
};

E.makeNode = function (kind, scale){
  const s = scale || 1;
  if (kind === "tree"){
    const trunk = cyl(.16*s, .22*s, 1.5*s, "#6B4B26");
    trunk.position.y = .75*s;
    const c1 = cone(1.05*s, 2.0*s, "#3E6B3A", 7); c1.position.y = 2.1*s;
    const c2 = cone(.78*s, 1.5*s, "#4C7C46", 7);  c2.position.y = 3.1*s;
    return grp([trunk, c1, c2]);
  }
  if (kind === "rock"){
    const g = new T.Group();
    for (let i = 0; i < 3; i++){
      const r = new T.Mesh(new T.DodecahedronGeometry((.5 + Math.random()*.42)*s, 0), mat("#7C8AA6"));
      r.position.set((Math.random()-.5)*1.2*s, .34*s + Math.random()*.2, (Math.random()-.5)*1.2*s);
      r.rotation.set(Math.random(), Math.random(), Math.random());
      shade(r); g.add(r);
    }
    return g;
  }
  if (kind === "deposit"){
    // a proper gold deposit — a worked mound with a lot in it
    const g = new T.Group();
    const mound = new T.Mesh(new T.SphereGeometry(1.5*s, 10, 6, 0, Math.PI*2, 0, Math.PI/2), mat("#5E6270"));
    mound.scale.y = .7; mound.position.y = .05;
    shade(mound); g.add(mound);
    for (let i = 0; i < 7; i++){
      const n = new T.Mesh(new T.DodecahedronGeometry((.2 + Math.random()*.2)*s, 0), mat("#D9A43F"));
      const a = Math.random()*6.28, r = Math.random()*1.2*s;
      n.position.set(Math.cos(a)*r, .3*s + Math.random()*.7*s, Math.sin(a)*r);
      n.rotation.set(Math.random(), Math.random(), Math.random());
      shade(n); g.add(n);
    }
    const pick = cyl(.05,.05, 1.5*s, "#6B4B26", 5);
    pick.position.set(1.1*s, .75*s, 0); pick.rotation.z = .6;
    shade(pick); g.add(pick);
    return g;
  }
  // gold vein
  const base = new T.Mesh(new T.DodecahedronGeometry(.72*s, 0), mat("#6E7285"));
  base.position.y = .5*s;
  const g = grp([base]);
  for (let i = 0; i < 3; i++){
    const n = sph(.2*s, "#D9A43F", 6);
    n.position.set((Math.random()-.5)*1.0*s, .55*s + Math.random()*.5, (Math.random()-.5)*1.0*s);
    shade(n); g.add(n);
  }
  return g;
};

/* ═══ PARTS ══════════════════════════════════════════════════
   A building can be described as a plain list of primitives. Anything
   with a `parts` array is built from it, which is what the in-game
   modeller edits. Buildings without one are still built procedurally,
   and captureParts() can read those back into an editable list. */
const SHAPES = {
  box:      p => new T.BoxGeometry(p.w||1, p.h||1, p.d||1,
                    Math.max(1,p.segX||1), Math.max(1,p.segY||1), Math.max(1,p.segZ||1)),
  cylinder: p => new T.CylinderGeometry(p.rt===undefined?(p.r||.5):p.rt, p.rb===undefined?(p.r||.5):p.rb,
                    p.h||1, p.seg||8, Math.max(1,p.segY||1), !!p.open),
  cone:     p => new T.ConeGeometry(p.r||.5, p.h||1, p.seg||8, Math.max(1,p.segY||1), !!p.open),
  sphere:   p => new T.SphereGeometry(p.r||.5, p.seg||10, Math.max(4,(p.seg||10)-2),
                    0, p.arc===undefined?Math.PI*2:p.arc, 0, p.arcY===undefined?Math.PI:p.arcY),
  dodeca:   p => new T.DodecahedronGeometry(p.r||.5, p.detail||0),
  icosa:    p => new T.IcosahedronGeometry(p.r||.5, p.detail||0),
  octa:     p => new T.OctahedronGeometry(p.r||.5, p.detail||0),
  tetra:    p => new T.TetrahedronGeometry(p.r||.5, p.detail||0),
  torus:    p => new T.TorusGeometry(p.r||.6, p.tube||.12, p.segY||8, p.seg||16,
                    p.arc===undefined?Math.PI*2:p.arc),
  torusKnot:p => new T.TorusKnotGeometry(p.r||.6, p.tube||.14, p.seg||64, p.segY||8),
  capsule:  p => new T.CapsuleGeometry(p.r||.2, p.h||.6, 3, p.seg||6),
  circle:   p => new T.CircleGeometry(p.r||1, p.seg||20),
  ring:     p => new T.RingGeometry(p.rt===undefined?.4:p.rt, p.r||1, p.seg||24),
  plane:    p => new T.PlaneGeometry(p.w||1, p.h||1, Math.max(1,p.segX||1), Math.max(1,p.segY||1)),
  wedge:    p => {
    /* a right-angled prism: a ramp, a lean-to roof, a buttress */
    const w = p.w||1, h = p.h||1, d = p.d||1;
    const g = new T.BufferGeometry();
    const v = [
      -w/2,-h/2,-d/2,  w/2,-h/2,-d/2,  w/2,-h/2, d/2, -w/2,-h/2, d/2,
      -w/2, h/2,-d/2,  w/2, h/2,-d/2
    ];
    const idx = [0,1,2, 0,2,3, 0,4,5, 0,5,1, 3,2,5, 3,5,4, 0,3,4, 1,5,2];
    g.setAttribute("position", new T.Float32BufferAttribute(v, 3));
    g.setIndex(idx);
    g.computeVertexNormals();
    return g;
  },
  mesh:     p => {
    /* geometry brought in from an OBJ, stored as raw triangles */
    const g = new T.BufferGeometry();
    const pos = p.verts && p.verts.length ? p.verts : [0,0,0, 1,0,0, 0,1,0];
    g.setAttribute("position", new T.Float32BufferAttribute(pos, 3));
    if (p.indices && p.indices.length) g.setIndex(p.indices);
    g.computeVertexNormals();
    return g;
  }
};
E.SHAPES = SHAPES;
E.shapeNames = Object.keys(SHAPES);

/* Build one primitive from a descriptor. */
E.makePart = function (p){
  const geo = (SHAPES[p.shape] || SHAPES.box)(p);
  const m = p.glow
    ? new T.MeshBasicMaterial({color:new T.Color(p.colour || "#ffffff"),
        transparent:p.opacity !== undefined && p.opacity < 1, opacity:p.opacity === undefined ? 1 : p.opacity})
    : new T.MeshLambertMaterial({color:new T.Color(p.colour || "#8A93AC"),
        transparent:p.opacity !== undefined && p.opacity < 1, opacity:p.opacity === undefined ? 1 : p.opacity,
        side:(p.shape === "circle" || p.shape === "plane") ? T.DoubleSide : T.FrontSide});
  const mesh = new T.Mesh(geo, m);
  mesh.position.set(p.x || 0, p.y || 0, p.z || 0);
  mesh.rotation.set(p.rx || 0, p.ry || 0, p.rz || 0);
  if (p.sx || p.sy || p.sz) mesh.scale.set(p.sx || 1, p.sy || 1, p.sz || 1);
  if (!p.glow){ mesh.castShadow = true; mesh.receiveShadow = true; }
  mesh.userData.part = p;
  return mesh;
};

/* A whole building from a parts list. */
E.buildFromParts = function (parts, tier, enemy){
  const g = new T.Group();
  const t = Math.max(1, tier || 1);
  (parts || []).forEach(p => {
    if (p.hidden) return;
    if (p.minTier && t < p.minTier) return;
    const mesh = E.makePart(enemy ? Object.assign({}, p, {colour:"#5E3634"}) : p);
    if (p.light){
      const L = new T.PointLight(new T.Color(p.lightColour || p.colour || "#FFD9A0"),
                                 p.lightPower === undefined ? 1.2 : p.lightPower,
                                 p.lightRange || 18);
      L.position.set(p.x || 0, p.y || 0, p.z || 0);
      g.add(L);
    }
    g.add(mesh);
  });
  g.userData.parts = parts;
  return g;
};

/* Read an existing procedurally-built mesh back into an editable list,
   so every building already in the game opens in the modeller. */
E.captureParts = function (group){
  const out = [];
  group.traverse(o => {
    if (!o.isMesh || !o.geometry) return;
    const g = o.geometry, t = g.type || "";
    const par = g.parameters || {};
    const wp = new T.Vector3(), wq = new T.Quaternion(), ws = new T.Vector3();
    o.updateWorldMatrix(true, false);
    o.matrixWorld.decompose(wp, wq, ws);
    const e = new T.Euler().setFromQuaternion(wq);
    const base = {
      x:+wp.x.toFixed(3), y:+wp.y.toFixed(3), z:+wp.z.toFixed(3),
      rx:+e.x.toFixed(3), ry:+e.y.toFixed(3), rz:+e.z.toFixed(3),
      sx:+ws.x.toFixed(3), sy:+ws.y.toFixed(3), sz:+ws.z.toFixed(3),
      colour:"#" + (o.material && o.material.color ? o.material.color.getHexString() : "8a93ac"),
      glow:!!(o.material && o.material.isMeshBasicMaterial)
    };
    if (/Box/.test(t))            out.push(Object.assign(base, {shape:"box", w:par.width, h:par.height, d:par.depth}));
    else if (/Cylinder/.test(t))  out.push(Object.assign(base, {shape:"cylinder", rt:par.radiusTop, rb:par.radiusBottom, h:par.height, seg:par.radialSegments}));
    else if (/Cone/.test(t))      out.push(Object.assign(base, {shape:"cone", r:par.radius, h:par.height, seg:par.radialSegments}));
    else if (/Sphere/.test(t))    out.push(Object.assign(base, {shape:"sphere", r:par.radius, seg:par.widthSegments}));
    else if (/Dodecahedron/.test(t)) out.push(Object.assign(base, {shape:"dodeca", r:par.radius}));
    else if (/Torus/.test(t))     out.push(Object.assign(base, {shape:"torus", r:par.radius, tube:par.tube, seg:par.tubularSegments}));
    else if (/Capsule/.test(t))   out.push(Object.assign(base, {shape:"capsule", r:par.radius, h:par.length, seg:par.capSegments}));
    else if (/Circle/.test(t))    out.push(Object.assign(base, {shape:"circle", r:par.radius, seg:par.segments}));
    else if (/Plane/.test(t))     out.push(Object.assign(base, {shape:"plane", w:par.width, h:par.height}));
  });
  return out;
};

/* ── buildings ───────────────────────────────────────────────── */
/* Which authored model a tier should use: its own, else the nearest
   lower tier that has one, else the plain parts list. */
E.partsForTier = function (type, tier){
  const def = DB.BUILDINGS[type];
  if (!def) return null;
  const t = Math.max(1, tier || 1);
  if (def.models){
    for (let i = t; i >= 1; i--){
      const m = def.models[i] || def.models[String(i)];
      if (m && m.length) return m;
    }
  }
  return (def.parts && def.parts.length) ? def.parts : null;
};

E.makeBuilding = function (type, tier, enemy){
  /* an authored model always wins over the procedural shape */
  const authored = E.partsForTier(type, tier);
  if (authored) return E.buildFromParts(authored, tier, enemy);
  return E.makeBuildingProcedural(type, tier, enemy);
};

/* ── gizmos ──────────────────────────────────────────────────
   Three handle sets, each axis tagged so a drag knows what it moves. */
E.makeGizmo = function (mode){
  const g = new T.Group();
  const AX = [
    {k:"x", col:"#E05A5A", dir:new T.Vector3(1,0,0)},
    {k:"y", col:"#5AE07A", dir:new T.Vector3(0,1,0)},
    {k:"z", col:"#5A8AE0", dir:new T.Vector3(0,0,1)}
  ];
  const mat = c => new T.MeshBasicMaterial({color:new T.Color(c), depthTest:false, transparent:true, opacity:.95});

  AX.forEach(a => {
    if (mode === "rotate"){
      const ring = new T.Mesh(new T.TorusGeometry(3, .09, 6, 40), mat(a.col));
      if (a.k === "x") ring.rotation.y = Math.PI/2;
      if (a.k === "y") ring.rotation.x = Math.PI/2;
      ring.userData.axis = a.k;
      ring.renderOrder = 999;
      g.add(ring);
      return;
    }
    // shaft
    const shaft = new T.Mesh(new T.CylinderGeometry(.06, .06, 3, 6), mat(a.col));
    shaft.position.copy(a.dir).multiplyScalar(1.5);
    if (a.k === "x") shaft.rotation.z = -Math.PI/2;
    if (a.k === "z") shaft.rotation.x = Math.PI/2;
    shaft.userData.axis = a.k;
    shaft.renderOrder = 999;
    g.add(shaft);
    // head: arrow for move, cube for scale
    const head = mode === "scale"
      ? new T.Mesh(new T.BoxGeometry(.45,.45,.45), mat(a.col))
      : new T.Mesh(new T.ConeGeometry(.22, .7, 8), mat(a.col));
    head.position.copy(a.dir).multiplyScalar(3.2);
    if (mode !== "scale"){
      if (a.k === "x") head.rotation.z = -Math.PI/2;
      if (a.k === "z") head.rotation.x = Math.PI/2;
    }
    head.userData.axis = a.k;
    head.renderOrder = 999;
    g.add(head);
  });

  if (mode === "scale"){
    const c = new T.Mesh(new T.BoxGeometry(.4,.4,.4),
      new T.MeshBasicMaterial({color:"#E8D9A8", depthTest:false, transparent:true, opacity:.95}));
    c.userData.axis = "all";
    c.renderOrder = 999;
    g.add(c);
  }
  g.userData.mode = mode;
  return g;
};

/* A collider box you cannot mistake for geometry. */
E.makeColliderBox = function (col){
  const g = new T.Group();
  const box = new T.Mesh(new T.BoxGeometry(1,1,1),
    new T.MeshBasicMaterial({color:"#46E0C8", wireframe:true, depthTest:false, transparent:true, opacity:.9}));
  const fill = new T.Mesh(new T.BoxGeometry(1,1,1),
    new T.MeshBasicMaterial({color:"#46E0C8", transparent:true, opacity:.12, depthWrite:false}));
  box.renderOrder = 998; fill.renderOrder = 997;
  g.add(fill); g.add(box);
  g.userData = {box, fill};
  E.setCollider(g, col);
  return g;
};
E.setCollider = function (g, c){
  if (!g || !c) return;
  g.position.set(c.x || 0, c.y || 0, c.z || 0);
  g.rotation.set(c.rx || 0, c.ry || 0, c.rz || 0);
  g.scale.set(Math.max(.01, c.w || 1), Math.max(.01, c.h || 1), Math.max(.01, c.d || 1));
};

/* ── OBJ import ──────────────────────────────────────────────
   Positions and faces only — enough to bring a shape in and treat it
   as one more primitive. */
E.parseOBJ = function (text){
  const verts = [], out = [], idx = [];
  const lines = text.split(/\r?\n/);
  for (const line of lines){
    if (line[0] === "v" && line[1] === " "){
      const p = line.trim().split(/\s+/);
      verts.push([+p[1], +p[2], +p[3]]);
    } else if (line[0] === "f" && line[1] === " "){
      const p = line.trim().split(/\s+/).slice(1)
        .map(tok => parseInt(tok.split("/")[0], 10))
        .map(i => i < 0 ? verts.length + i : i - 1);
      for (let i = 1; i < p.length - 1; i++){
        idx.push(p[0], p[i], p[i+1]);
      }
    }
  }
  if (!verts.length) throw new Error("No vertices found in that OBJ.");
  // flatten to raw triangles so the part carries its own geometry
  const flat = [];
  idx.forEach(i => { const v = verts[i]; if (v) flat.push(v[0], v[1], v[2]); });
  if (!flat.length) throw new Error("No faces found in that OBJ.");
  // normalise into a sane size
  let min = [Infinity,Infinity,Infinity], max = [-Infinity,-Infinity,-Infinity];
  for (let i = 0; i < flat.length; i += 3){
    for (let a = 0; a < 3; a++){
      min[a] = Math.min(min[a], flat[i+a]);
      max[a] = Math.max(max[a], flat[i+a]);
    }
  }
  const span = Math.max(max[0]-min[0], max[1]-min[1], max[2]-min[2]) || 1;
  const k = 4 / span;
  const cx = (min[0]+max[0])/2, cy = min[1], cz = (min[2]+max[2])/2;
  for (let i = 0; i < flat.length; i += 3){
    flat[i]   = +((flat[i]   - cx) * k).toFixed(4);
    flat[i+1] = +((flat[i+1] - cy) * k).toFixed(4);
    flat[i+2] = +((flat[i+2] - cz) * k).toFixed(4);
  }
  return {verts:flat, tris:flat.length/9};
};

E.makeBuildingProcedural = function (type, tier, enemy){
  const d = DB.BUILDINGS[type];
  const g = new T.Group();
  const t = Math.max(1, tier || 1);
  const h = d.height * (1 + (t-1)*.16);
  const bodyCol = enemy ? "#5E3634" : d.colour;

  if (type === "wall"){
    const b = box(d.w, h, d.d, bodyCol); b.position.y = h/2; g.add(shade(b));
    const cap = box(d.w*1.06, .22, d.d*1.06, enemy ? "#7A3B38" : "#93A0BA");
    cap.position.y = h + .1; g.add(shade(cap));
    return g;
  }
  if (type === "gate"){
    const l = box(.7, h, d.d, bodyCol); l.position.set(-d.w/2+.35, h/2, 0); g.add(shade(l));
    const r = box(.7, h, d.d, bodyCol); r.position.set(d.w/2-.35, h/2, 0); g.add(shade(r));
    const top = box(d.w, .55, d.d, "#A8752A"); top.position.y = h - .3; g.add(shade(top));
    return g;
  }
  if (type === "tower"){
    const b = cyl(d.w*.42, d.w*.5, h, bodyCol, 8); b.position.y = h/2; g.add(shade(b));
    const bal = cyl(d.w*.58, d.w*.58, .4, "#93A0BA", 8); bal.position.y = h; g.add(shade(bal));
    const rf = cone(d.w*.6, 1.7, d.roof, 8); rf.position.y = h + 1.05; g.add(shade(rf));
    return g;
  }
  if (type === "store"){
    // an open-sided timber frame with heaps of goods stacked around it
    const floor = box(d.w, .3, d.d, "#6B5B3A"); floor.position.y = .15; g.add(shade(floor));
    [[-1,-1],[1,-1],[-1,1],[1,1]].forEach(p => {
      const post = cyl(.16,.18, h*.8, "#5A4630", 6);
      post.position.set(p[0]*(d.w/2-.3), h*.4, p[1]*(d.d/2-.3));
      g.add(shade(post));
    });
    const roof = cone(Math.max(d.w,d.d)*.82, h*.5, d.roof, 4);
    roof.rotation.y = Math.PI/4; roof.position.y = h*.8 + h*.25;
    g.add(shade(roof));

    // the heaps — scaled live from what the realm is holding
    const woodPile = new T.Group();
    for (let i = 0; i < 9; i++){
      const l = cyl(.16,.16, 1.5, "#7A5B33", 6);
      l.rotation.z = Math.PI/2;
      l.rotation.y = (i%3)*.35;
      l.position.set((i%3)*.42 - .42, .18 + Math.floor(i/3)*.32, (i%2)*.2);
      woodPile.add(shade(l));
    }
    woodPile.position.set(-(d.w/2 + 1.5), 0, 0);
    g.add(woodPile);

    const stonePile = new T.Group();
    for (let i = 0; i < 8; i++){
      const r = new T.Mesh(new T.DodecahedronGeometry(.3 + Math.random()*.16, 0), mat("#8C9AB6"));
      const a = (i/8)*6.28;
      r.position.set(Math.cos(a)*.5, .25 + (i%3)*.28, Math.sin(a)*.5);
      r.rotation.set(Math.random(), Math.random(), Math.random());
      stonePile.add(shade(r));
    }
    stonePile.position.set(d.w/2 + 1.5, 0, 0);
    g.add(stonePile);

    const foodPile = new T.Group();
    for (let i = 0; i < 6; i++){
      const sack = new T.Mesh(new T.SphereGeometry(.3, 7, 5), mat("#B8A472"));
      sack.scale.y = 1.25;
      sack.position.set((i%3)*.55 - .55, .3, Math.floor(i/3)*.5);
      foodPile.add(shade(sack));
    }
    foodPile.position.set(0, 0, d.d/2 + 1.5);
    g.add(foodPile);

    g.userData.piles = {wood:woodPile, stone:stonePile, food:foodPile};
    return g;
  }
  if (type === "mageTower"){
    const base = cyl(d.w*.5, d.w*.62, h*.7, bodyCol, 8); base.position.y = h*.35; g.add(shade(base));
    const ring = new T.Mesh(new T.TorusGeometry(d.w*.62, .12, 6, 16), mat(d.roof));
    ring.rotation.x = Math.PI/2; ring.position.y = h*.7; g.add(shade(ring));
    const top = cone(d.w*.6, h*.34, d.roof, 8); top.position.y = h*.7 + h*.17; g.add(shade(top));
    const orb = new T.Mesh(new T.SphereGeometry(.42, 10, 8),
      new T.MeshBasicMaterial({color:"#B9A6F0"}));
    orb.position.y = h + .5; g.add(orb);
    const glow = new T.PointLight("#9E86E8", 1.3, 22); glow.position.y = h + .5; g.add(glow);
    for (let i = 0; i < 3; i++){
      const w = box(.5, .7, .1, "#2A2340");
      const a = i*2.1;
      w.position.set(Math.sin(a)*d.w*.5, h*.42, Math.cos(a)*d.w*.5);
      w.lookAt(Math.sin(a)*10, h*.42, Math.cos(a)*10);
      g.add(shade(w));
    }
    g.userData.orb = orb;
    return g;
  }
  if (type === "torch"){
    const post = cyl(.11,.15, h*.8, "#4A3A24", 6); post.position.y = h*.4; g.add(shade(post));
    const bowl = cyl(.34,.2,.36,"#5A5A62",7); bowl.position.y = h*.8 + .1; g.add(shade(bowl));
    const flame = cone(.28, .9, "#E8A33F", 6);
    flame.position.y = h*.8 + .62;
    flame.material = new T.MeshBasicMaterial({color:"#F2B44A"});
    g.add(flame);
    const light = new T.PointLight("#FFB558", 1.5, d.effect.light, 1.6);
    light.position.y = h*.8 + .5;
    g.add(light);
    g.userData.flame = flame;
    return g;
  }
  if (type === "mill"){
    const b = box(d.w*.7, h*.5, d.d*.7, bodyCol); b.position.y = h*.25; g.add(shade(b));
    const cap = cone(d.w*.55, 1.3, d.roof, 6); cap.position.y = h*.5 + .65; g.add(shade(cap));
    const hub = cyl(.16,.16,.4,"#4A3A24",6); hub.rotation.x = Math.PI/2;
    hub.position.set(0, h*.42, d.d*.38); g.add(shade(hub));
    const sails = new T.Group();
    for (let i = 0; i < 4; i++){
      const s = box(.16, 3.0, .5, "#C8B45A");
      s.position.set(0, 0, 0); s.rotation.z = i*Math.PI/2;
      s.translateY(1.5);
      sails.add(shade(s));
    }
    sails.position.set(0, h*.42, d.d*.44);
    g.add(sails);
    g.userData.spin = sails;
    return g;
  }
  if (type === "stable"){
    const b = box(d.w, h*.55, d.d, bodyCol); b.position.y = h*.275; g.add(shade(b));
    const roof = box(d.w*1.08, .35, d.d*1.08, d.roof); roof.position.y = h*.55 + .18; g.add(shade(roof));
    for (let i = 0; i < 3; i++){
      const post = cyl(.14,.14, h*.5, "#5A4630", 6);
      post.position.set(-d.w/2 + .5 + i*(d.w-1)/2, h*.25, d.d/2 + 1.0);
      g.add(shade(post));
    }
    const awn = box(d.w, .18, 2.0, d.roof); awn.position.set(0, h*.5, d.d/2 + 1.0); g.add(shade(awn));
    return g;
  }
  if (type === "siege"){
    const b = box(d.w, h*.5, d.d, bodyCol); b.position.y = h*.25; g.add(shade(b));
    const beam1 = cyl(.2,.2, d.w*1.2, "#4A3A24", 6); beam1.rotation.z = Math.PI/2;
    beam1.position.set(0, h*.62, -d.d*.3); g.add(shade(beam1));
    const beam2 = cyl(.2,.2, d.w*1.2, "#4A3A24", 6); beam2.rotation.z = Math.PI/2;
    beam2.position.set(0, h*.62, d.d*.3); g.add(shade(beam2));
    const log = cyl(.34,.34, 3.2, "#6B5B3A", 8); log.rotation.x = Math.PI/2;
    log.position.set(0, h*.42, 0); g.add(shade(log));
    return g;
  }
  if (type === "blacksmith"){
    const b = box(d.w, h*.58, d.d, bodyCol); b.position.y = h*.29; g.add(shade(b));
    const roof = cone(Math.max(d.w,d.d)*.76, h*.4, d.roof, 4);
    roof.rotation.y = Math.PI/4; roof.position.y = h*.58 + h*.2; g.add(shade(roof));
    const chim = box(.7, 1.8, .7, "#5A5A62"); chim.position.set(d.w*.3, h*.58 + .9, -d.d*.28);
    g.add(shade(chim));
    const forge = sph(.42, "#D9663F", 7); forge.position.set(-d.w*.22, .5, d.d/2 + .2);
    g.add(shade(forge));
    return g;
  }
  if (type === "wonder"){
    /* A stepped ziggurat under a floating, turning crystal, ringed by
       obelisks and lit from within. Nothing else on the map looks like it. */
    const tiers = 5;
    for (let i = 0; i < tiers; i++){
      const w = d.w - i*2.1;
      const s = box(w, 2.2, w, i % 2 ? "#C8BFA4" : bodyCol);
      s.position.y = 1.1 + i*2.2;
      g.add(shade(s));
      // a gold band around each step
      const band = box(w + .3, .3, w + .3, d.roof);
      band.position.y = 2.2 + i*2.2;
      g.add(shade(band));
    }
    const capY = tiers*2.2;

    // a broad stair up the south face
    for (let i = 0; i < 8; i++){
      const st = box(4.5, .5, 1.1, "#B7AE94");
      st.position.set(0, .3 + i*1.35, d.d/2 - i*1.0);
      g.add(shade(st));
    }

    // obelisks at the corners
    [[-1,-1],[1,-1],[-1,1],[1,1]].forEach(p => {
      const ob = cyl(.35, .6, 9, d.roof, 6);
      ob.position.set(p[0]*(d.w/2 - .8), 4.5, p[1]*(d.d/2 - .8));
      g.add(shade(ob));
      const tipO = cone(.5, 1.6, "#F0E4B8", 6);
      tipO.position.set(p[0]*(d.w/2 - .8), 9.8, p[1]*(d.d/2 - .8));
      g.add(shade(tipO));
    });

    // the shrine at the summit
    const shrine = cyl(2.6, 3.0, 3.4, "#E4DCC2", 8);
    shrine.position.y = capY + 1.7;
    g.add(shade(shrine));
    const roofW = cone(3.6, 3.0, d.roof, 8);
    roofW.position.y = capY + 4.9;
    g.add(shade(roofW));

    // the crystal, floating and turning
    const crystal = new T.Mesh(new T.OctahedronGeometry(2.4, 0),
      new T.MeshBasicMaterial({color:"#FFF0C0", transparent:true, opacity:.92}));
    crystal.position.y = capY + 10;
    g.add(crystal);
    const halo = new T.Mesh(new T.TorusGeometry(4.2, .22, 8, 32),
      new T.MeshBasicMaterial({color:d.roof, transparent:true, opacity:.6}));
    halo.rotation.x = Math.PI/2;
    halo.position.y = capY + 10;
    g.add(halo);
    const beacon = new T.PointLight("#FFE9A8", 2.6, 90);
    beacon.position.y = capY + 10;
    g.add(beacon);

    g.userData.spin = crystal;
    g.userData.halo = halo;
    g.userData.beacon = beacon;
    return g;
  }
  if (type === "temple"){
    /* The great temple. Three stepped tiers, a colonnade, a worship floor
       and a spire — and a set of parts that get re-shaped by alignment. */
    const stepped = [];
    for (let i = 0; i < 3; i++){
      const w = d.w - i*1.6;
      const s = box(w, .7, w, i === 0 ? "#B7BECD" : bodyCol);
      s.position.y = .35 + i*.7;
      stepped.push(s); g.add(shade(s));
    }
    const plinthTop = 2.1;

    // colonnade: twelve columns around the edge
    const cols = [];
    for (let i = 0; i < 12; i++){
      const a = (i/12)*Math.PI*2;
      const r = d.w/2 - 1.2;
      const c = cyl(.42, .48, h*.44, bodyCol, 8);
      c.position.set(Math.cos(a)*r, plinthTop + h*.22, Math.sin(a)*r);
      cols.push(c); g.add(shade(c));
    }

    // the worship floor — where a dropped villager becomes a worshipper
    const floor = new T.Mesh(new T.CircleGeometry(d.w*.3, 24),
      new T.MeshLambertMaterial({color:d.roof}));
    floor.rotation.x = -Math.PI/2;
    floor.position.y = plinthTop + .02;
    g.add(floor);

    const architrave = box(d.w - 1.4, .8, d.d - 1.4, bodyCol);
    architrave.position.y = plinthTop + h*.44 + .4;
    g.add(shade(architrave));

    const roof = cone(d.w*.72, h*.3, d.roof, 4);
    roof.rotation.y = Math.PI/4;
    roof.position.y = plinthTop + h*.44 + .8 + h*.15;
    g.add(shade(roof));

    const spire = cone(.8, h*.26, d.roof, 6);
    spire.position.y = plinthTop + h*.44 + .8 + h*.3 + h*.13;
    g.add(shade(spire));

    const halo = new T.Mesh(new T.TorusGeometry(d.w*.34, .16, 8, 28),
      new T.MeshBasicMaterial({color:d.roof, transparent:true, opacity:.75}));
    halo.rotation.x = Math.PI/2;
    halo.position.y = plinthTop + h*.9;
    g.add(halo);

    /* the temple throws real light across the town */
    const glow = new T.PointLight("#FFE6B0", 2.2, 62);
    glow.position.y = plinthTop + h*.6;
    g.add(glow);
    const floorGlow = new T.PointLight("#FFF2D0", 1.3, 26);
    floorGlow.position.y = plinthTop + 1.5;
    g.add(floorGlow);
    const beam = new T.Mesh(new T.CylinderGeometry(d.w*.26, d.w*.30, h*.9, 12, 1, true),
      new T.MeshBasicMaterial({color:d.roof, transparent:true, opacity:.16, side:T.DoubleSide, depthWrite:false}));
    beam.position.y = plinthTop + h*.45;
    g.add(beam);

    g.userData.glow = glow;
    g.userData.floorGlow = floorGlow;
    g.userData.beam = beam;
    g.userData.alignParts = [roof, spire, architrave].concat(cols);
    g.userData.halo = halo;
    g.userData.floor = floor;
    g.userData.spire = spire;
    g.userData.worshipRadius = d.w*.3;
    return g;
  }
  if (type === "keep"){
    const b = box(d.w, h*.62, d.d, bodyCol); b.position.y = h*.31; g.add(shade(b));
    for (let i = 0; i < 4; i++){
      const tw = cyl(.8, .9, h*.95, bodyCol, 8);
      tw.position.set((i<2?-1:1)*(d.w/2), h*.475, (i%2?-1:1)*(d.d/2));
      g.add(shade(tw));
      const cap = cone(1.0, 1.5, d.roof, 8); cap.position.copy(tw.position); cap.position.y = h*.95 + .75;
      g.add(shade(cap));
    }
    const keepRoof = box(d.w*.86, .4, d.d*.86, d.roof); keepRoof.position.y = h*.62 + .2;
    g.add(shade(keepRoof));
    return g;
  }
  // generic hall: body + pitched roof + door
  const body = box(d.w, h*.62, d.d, bodyCol);
  body.position.y = h*.31; g.add(shade(body));
  if (d.roof){
    const roof = cone(Math.max(d.w,d.d)*.78, h*.5, d.roof, 4);
    roof.rotation.y = Math.PI/4;
    roof.position.y = h*.62 + h*.25;
    g.add(shade(roof));
  }
  const door = box(.8, Math.min(1.4, h*.36), .12, "#3A2A1C");
  door.position.set(0, Math.min(.7, h*.18), d.d/2 + .06);
  g.add(shade(door));
  // tier pips
  for (let i = 0; i < t; i++){
    const p = box(.22, .22, .22, "#D9A43F");
    p.position.set(-d.w/2 + .4 + i*.36, h*.62 + .18, d.d/2 - .3);
    g.add(shade(p));
  }
  return g;
};

E.makeGhost = function (type){
  const d = DB.BUILDINGS[type];
  const g = new T.Group();
  const m = new T.MeshBasicMaterial({color:"#46988C", transparent:true, opacity:.4, depthWrite:false});
  const b = new T.Mesh(new T.BoxGeometry(d.w, d.height*.7, d.d), m);
  b.position.y = d.height*.35;
  g.add(b);
  const ring = new T.Mesh(new T.RingGeometry(Math.max(d.w,d.d)*.62, Math.max(d.w,d.d)*.72, 24),
    new T.MeshBasicMaterial({color:"#46988C", transparent:true, opacity:.7, side:T.DoubleSide, depthWrite:false}));
  ring.rotation.x = -Math.PI/2; ring.position.y = .08;
  g.add(ring);
  g.userData.body = b; g.userData.ring = ring;
  return g;
};

/* ── units ───────────────────────────────────────────────────── */
E.makeUnit = function (cls){
  const d = DB.CLASSES[cls];
  const g = new T.Group();
  const H = d.height;

  const legs = cyl(d.radius*.62, d.radius*.72, H*.34, d.accent, 6);
  legs.position.y = H*.17; g.add(shade(legs));

  const torso = box(d.radius*1.55, H*.38, d.radius*1.05, d.colour);
  torso.position.y = H*.34 + H*.19; g.add(shade(torso));

  const head = sph(d.radius*.56, "#D8C4A8", 8);
  head.position.y = H*.82; g.add(shade(head));

  const gearGroup = new T.Group();
  g.add(gearGroup);

  // selection / state ring, built early so every branch below can hand it back
  const ring = new T.Mesh(new T.RingGeometry(d.radius*1.5, d.radius*1.9, 18),
    new T.MeshBasicMaterial({color:"#D9A43F", transparent:true, opacity:0, side:T.DoubleSide, depthWrite:false}));
  ring.rotation.x = -Math.PI/2; ring.position.y = .06;
  g.add(ring);

  if (d.family === "beast"){
    g.remove(legs); g.remove(torso); g.remove(head);
    const body = new T.Mesh(new T.SphereGeometry(d.radius*1.05, 9, 7), mat(d.colour));
    body.scale.set(1.0, .92, 1.45); body.position.y = H*.62;
    const hd = new T.Mesh(new T.SphereGeometry(d.radius*.5, 8, 6), mat(d.accent));
    hd.position.set(0, H*.78, d.radius*1.3);
    const feet = [];
    [[-.55,.6],[.55,.6],[-.55,-.6],[.55,-.6]].forEach(p => {
      const l = cyl(d.radius*.17, d.radius*.2, H*.5, d.accent, 5);
      l.position.set(p[0]*d.radius*1.3, H*.25, p[1]*d.radius*1.4);
      feet.push(l);
    });
    [body, hd].concat(feet).forEach(m => g.add(shade(m)));
    if (cls === "deer"){
      [-1,1].forEach(s => {
        const a = cyl(.05,.05, .8, "#D8C4A8", 5);
        a.position.set(s*d.radius*.3, H*.95, d.radius*1.2); a.rotation.z = s*.4;
        g.add(shade(a));
        const b2 = cyl(.04,.04, .4, "#D8C4A8", 5);
        b2.position.set(s*d.radius*.55, H*1.12, d.radius*1.2); b2.rotation.z = s*.9;
        g.add(shade(b2));
      });
    }
    g.userData = {torso:body, head:hd, legs:feet, ring, gearGroup, cls};
    return g;
  }
  if (d.family === "monster"){
    head.material = mat(d.accent);
    const horn1 = cone(.1, .42, "#E8E0D0", 5); horn1.position.set(-d.radius*.34, H*.98, 0);
    const horn2 = cone(.1, .42, "#E8E0D0", 5); horn2.position.set(d.radius*.34, H*.98, 0);
    g.add(shade(horn1), shade(horn2));
  }
  if (cls === "ranger" || cls === "archer"){
    const bow = new T.Mesh(new T.TorusGeometry(.36, .05, 5, 10, Math.PI*1.25), mat("#6B4B26"));
    bow.position.set(d.radius*1.0, H*.56, 0); bow.rotation.y = Math.PI/2;
    gearGroup.add(shade(bow));
  } else if (cls === "druid"){
    const staff = cyl(.06,.06, H*.95, "#6B4B26", 6);
    staff.position.set(d.radius*1.0, H*.5, 0); gearGroup.add(shade(staff));
    const orb = sph(.16, "#7FE0A0", 7); orb.position.set(d.radius*1.0, H*.98, 0);
    gearGroup.add(shade(orb));
  } else if (cls === "pikeman"){
    const pike = cyl(.05,.05, H*1.5, "#8A6A4A", 6);
    pike.position.set(d.radius*1.0, H*.72, 0); gearGroup.add(shade(pike));
    const tip = cone(.1,.34,"#C6CBDA",5); tip.position.set(d.radius*1.0, H*1.5, 0);
    gearGroup.add(shade(tip));
  } else if (cls === "ram"){
    torso.visible = false; head.visible = false;
    const frame = box(1.5, .7, 2.6, "#5A4630"); frame.position.y = H*.5; gearGroup.add(shade(frame));
    const log = cyl(.34,.34, 3.0, d.colour, 8); log.rotation.x = Math.PI/2;
    log.position.set(0, H*.62, .2); gearGroup.add(shade(log));
    const cap = cone(.42, .7, "#4A4A55", 6); cap.rotation.x = Math.PI/2;
    cap.position.set(0, H*.62, 1.8); gearGroup.add(shade(cap));
    [[-.75,.9],[.75,.9],[-.75,-.9],[.75,-.9]].forEach(p => {
      const w = cyl(.36,.36,.2,"#3E341F",8); w.rotation.z = Math.PI/2;
      w.position.set(p[0], .36, p[1]); gearGroup.add(shade(w));
    });
  } else if (cls === "scout"){
    const horse = new T.Mesh(new T.SphereGeometry(d.radius*.8, 8, 6), mat(d.accent));
    horse.scale.set(.9, .8, 1.5); horse.position.y = H*.42; gearGroup.add(shade(horse));
    [[-.4,.5],[.4,.5],[-.4,-.5],[.4,-.5]].forEach(p => {
      const l = cyl(.11,.13, H*.4, d.accent, 5);
      l.position.set(p[0], H*.2, p[1]); gearGroup.add(shade(l));
    });
    torso.position.y = H*.72; head.position.y = H*.98;
    const blade = box(.1, H*.4, .15, "#C6CBDA");
    blade.position.set(d.radius*1.05, H*.8, 0); gearGroup.add(shade(blade));
  } else if (d.family === "hero" || d.family === "soldier"){
    const blade = box(.1, H*.5, .16, "#C6CBDA");
    blade.position.set(d.radius*1.05, H*.6, 0); gearGroup.add(shade(blade));
  }

  g.userData = {torso, head, legs, ring, gearGroup, cls};
  return g;
};

/* ── the creatures ───────────────────────────────────────────── */
E.makeCreature = function (kind){
  const d = DB.CREATURES[kind] || DB.CREATURES.ox;
  const g = new T.Group();
  const legs = [];
  let body, head, collar, tail;

  function foot(x, z, r, h){
    const l = cyl(r*.9, r, h, d.accent, 6);
    l.position.set(x, h/2, z);
    legs.push(l); return l;
  }
  const parts = [];

  if (d.shape === "ox"){
    body = new T.Mesh(new T.BoxGeometry(2.6, 2.0, 3.6), mat(d.colour));
    body.position.y = 2.6;
    head = box(1.5, 1.3, 1.4, d.colour); head.position.set(0, 2.9, 2.4);
    const snout = box(.9, .7, .8, d.accent); snout.position.set(0, 2.6, 3.1);
    const h1 = cone(.22, 1.1, "#E8E0D0", 5); h1.position.set(-.8, 3.6, 2.3); h1.rotation.z = .7;
    const h2 = cone(.22, 1.1, "#E8E0D0", 5); h2.position.set(.8, 3.6, 2.3); h2.rotation.z = -.7;
    tail = cyl(.1,.22, 1.6, d.accent, 5); tail.position.set(0, 2.6, -2.0); tail.rotation.x = 1.1;
    parts.push(body, head, snout, h1, h2, tail);
    [[-1.0,1.3],[1.0,1.3],[-1.0,-1.3],[1.0,-1.3]].forEach(p => parts.push(foot(p[0], p[1], .40, 1.7)));
    collar = new T.Mesh(new T.TorusGeometry(.95, .14, 6, 14), mat("#D9A43F"));
    collar.position.set(0, 2.95, 1.7); collar.rotation.x = Math.PI/2.2;
  }
  else if (d.shape === "wolf"){
    body = new T.Mesh(new T.SphereGeometry(1.05, 10, 8), mat(d.colour));
    body.scale.set(1.0, .95, 1.9); body.position.y = 2.0;
    head = new T.Mesh(new T.SphereGeometry(.62, 9, 7), mat(d.colour)); head.position.set(0, 2.35, 1.9);
    const snout = cone(.34, 1.0, d.accent, 6); snout.position.set(0, 2.2, 2.6); snout.rotation.x = Math.PI/2;
    const e1 = cone(.2, .62, d.accent, 5); e1.position.set(-.32, 2.85, 1.75);
    const e2 = cone(.2, .62, d.accent, 5); e2.position.set(.32, 2.85, 1.75);
    tail = cone(.2, 1.8, d.colour, 6); tail.position.set(0, 2.3, -2.1); tail.rotation.x = -.8;
    parts.push(body, head, snout, e1, e2, tail);
    [[-.62,.95],[.62,.95],[-.62,-.95],[.62,-.95]].forEach(p => parts.push(foot(p[0], p[1], .24, 1.5)));
    collar = new T.Mesh(new T.TorusGeometry(.6, .1, 6, 14), mat("#D9A43F"));
    collar.position.set(0, 2.25, 1.4); collar.rotation.x = Math.PI/2.4;
  }
  else if (d.shape === "ape"){
    body = new T.Mesh(new T.SphereGeometry(1.5, 11, 9), mat(d.colour));
    body.scale.set(1.3, 1.25, 1.0); body.position.y = 3.0;
    const belly = new T.Mesh(new T.SphereGeometry(1.1, 9, 7), mat(d.accent));
    belly.scale.set(1.0, .95, .7); belly.position.set(0, 2.6, .85);
    head = new T.Mesh(new T.SphereGeometry(.78, 10, 8), mat(d.colour)); head.position.set(0, 4.5, .25);
    const face = new T.Mesh(new T.SphereGeometry(.5, 8, 6), mat("#C8A98A"));
    face.scale.set(.9, .8, .6); face.position.set(0, 4.4, .82);
    const arm1 = cyl(.32,.36, 2.9, d.colour, 6); arm1.position.set(-1.75, 2.8, .2); arm1.rotation.z = .22;
    const arm2 = cyl(.32,.36, 2.9, d.colour, 6); arm2.position.set(1.75, 2.8, .2); arm2.rotation.z = -.22;
    parts.push(body, belly, head, face, arm1, arm2);
    [[-.75,.1],[.75,.1]].forEach(p => parts.push(foot(p[0], p[1], .46, 1.6)));
    collar = new T.Mesh(new T.TorusGeometry(.8, .13, 6, 14), mat("#D9A43F"));
    collar.position.set(0, 3.95, .3); collar.rotation.x = Math.PI/2.3;
  }
  else { // tortoise
    const shell = new T.Mesh(new T.SphereGeometry(2.1, 12, 8, 0, Math.PI*2, 0, Math.PI/2), mat(d.accent));
    shell.position.y = 1.6; shell.scale.set(1.15, .85, 1.35);
    body = new T.Mesh(new T.SphereGeometry(1.75, 10, 7), mat(d.colour));
    body.scale.set(1.1, .55, 1.3); body.position.y = 1.5;
    head = new T.Mesh(new T.SphereGeometry(.6, 9, 7), mat(d.colour)); head.position.set(0, 1.9, 2.5);
    const neck = cyl(.34,.4, 1.1, d.colour, 6); neck.position.set(0, 1.75, 2.0); neck.rotation.x = 1.4;
    for (let i = 0; i < 5; i++){
      const s = cone(.3, .7, "#8FA55C", 5);
      const a = (i/5)*Math.PI - Math.PI/2;
      s.position.set(Math.sin(a)*1.4, 2.5, Math.cos(a)*1.0 - .2);
      parts.push(s);
    }
    tail = cone(.16, .8, d.colour, 5); tail.position.set(0, 1.5, -2.2); tail.rotation.x = -1.4;
    parts.push(shell, body, head, neck, tail);
    [[-1.2,1.1],[1.2,1.1],[-1.2,-1.1],[1.2,-1.1]].forEach(p => parts.push(foot(p[0], p[1], .38, 1.0)));
    collar = new T.Mesh(new T.TorusGeometry(.55, .11, 6, 14), mat("#D9A43F"));
    collar.position.set(0, 1.85, 1.95); collar.rotation.x = Math.PI/2.6;
  }

  const eye1 = sph(.13, "#F2E6C8", 6), eye2 = sph(.13, "#F2E6C8", 6);
  eye1.position.copy(head.position).add(new T.Vector3(-.28, .18, .52));
  eye2.position.copy(head.position).add(new T.Vector3(.28, .18, .52));
  parts.push(eye1, eye2, collar);

  parts.forEach(m => { shade(m); g.add(m); });
  legs.forEach(l => { if (g.children.indexOf(l) < 0){ shade(l); g.add(l); } });
  g.userData = {body, head, legs, collar, tail, kind};
  return g;
};

/* ── the hand ────────────────────────────────────────────────── */
E.makeHand = function (){
  const g = new T.Group();
  const m = new T.MeshLambertMaterial({color:"#EDE3D0", transparent:true, opacity:.9,
                                       emissive:new T.Color("#4A4230")});
  const palm = new T.Mesh(new T.BoxGeometry(1.5, .45, 1.6), m);
  g.add(palm);
  for (let i = 0; i < 4; i++){
    const f = new T.Mesh(new T.CapsuleGeometry(.16, .8, 3, 6), m);
    f.position.set(-.55 + i*.37, -.1, 1.15);
    f.rotation.x = .5 + i*.05;
    g.add(f);
  }
  const thumb = new T.Mesh(new T.CapsuleGeometry(.18, .7, 3, 6), m);
  thumb.position.set(-.85, -.1, .3); thumb.rotation.z = .9; thumb.rotation.x = .35;
  g.add(thumb);
  const glow = new T.PointLight("#FFE9B0", .55, 16);
  glow.position.y = -1; g.add(glow);
  g.userData = {palm, glow, mat:m};
  return g;
};

/* ── the leash ───────────────────────────────────────────────── */
E.makeLeash = function (){
  const pts = [];
  for (let i = 0; i < 18; i++) pts.push(new T.Vector3());
  const geo = new T.BufferGeometry().setFromPoints(pts);
  const line = new T.Line(geo, new T.LineBasicMaterial({color:"#D9A43F", transparent:true, opacity:.9}));
  line.frustumCulled = false;
  line.userData.pts = pts;
  return line;
};
E.updateLeash = function (line, from, to, slack){
  const pts = line.userData.pts, n = pts.length - 1;
  const sag = Math.max(0, (from.distanceTo(to) < slack ? slack - from.distanceTo(to) : 0)) * .45;
  for (let i = 0; i <= n; i++){
    const t = i/n;
    pts[i].lerpVectors(from, to, t);
    pts[i].y -= Math.sin(t*Math.PI) * sag;
  }
  line.geometry.setFromPoints(pts);
  line.geometry.attributes.position.needsUpdate = true;
  line.geometry.computeBoundingSphere();
};

/* ── flags ───────────────────────────────────────────────────── */
E.makeFlag = function (kind){
  const d = DB.FLAGS[kind], g = new T.Group();
  const pole = cyl(.09,.09, 5.0, "#6B4B26", 6); pole.position.y = 2.5; g.add(shade(pole));
  const cloth = new T.Mesh(new T.PlaneGeometry(2.2, 1.4), new T.MeshLambertMaterial({color:d.colour, side:T.DoubleSide}));
  cloth.position.set(1.15, 4.2, 0); g.add(shade(cloth));
  const ring = new T.Mesh(new T.RingGeometry(3.4, 3.9, 32),
    new T.MeshBasicMaterial({color:d.colour, transparent:true, opacity:.5, side:T.DoubleSide, depthWrite:false}));
  ring.rotation.x = -Math.PI/2; ring.position.y = .1; g.add(ring);
  g.userData = {cloth, ring};
  return g;
};

/* ── squad banner ────────────────────────────────────────────── */
E.makeBanner = function (colour){
  const g = new T.Group();
  const pole = cyl(.1,.1, 4.2, "#4A4A55", 6); pole.position.y = 2.1; g.add(shade(pole));
  const cloth = box(1.6, 1.0, .1, colour); cloth.position.set(.85, 3.5, 0); g.add(shade(cloth));
  const base = cyl(.7,.9,.3, "#4A4A55", 8); base.position.y = .15; g.add(shade(base));
  const ring = new T.Mesh(new T.RingGeometry(2.4, 2.8, 28),
    new T.MeshBasicMaterial({color:colour, transparent:true, opacity:.45, side:T.DoubleSide, depthWrite:false}));
  ring.rotation.x = -Math.PI/2; ring.position.y = .08; g.add(ring);
  g.userData = {cloth, ring};
  return g;
};

/* ── projectiles / effects ───────────────────────────────────── */
E.makeProjectile = function (kind){
  if (kind === "arrow"){
    const m = cyl(.04,.04,.9,"#D8C4A8",5); m.rotation.x = Math.PI/2; return m;
  }
  if (kind === "roots"){
    const m = sph(.26,"#5F9159",6); return m;
  }
  return sph(.24, "#8E7BC8", 6);
};

E.makeRing = function (colour, r){
  const m = new T.Mesh(new T.RingGeometry(r*.86, r, 40),
    new T.MeshBasicMaterial({color:colour, transparent:true, opacity:.65, side:T.DoubleSide, depthWrite:false}));
  m.rotation.x = -Math.PI/2; m.position.y = .12;
  return m;
};

/* A little cluster of motes that flutters up off an awestruck head. */
E.makeAwe = function (colour){
  const g = new T.Group();
  const m = new T.MeshBasicMaterial({color:colour || "#F2D68A", transparent:true, opacity:.95});
  for (let i = 0; i < 5; i++){
    const p = new T.Mesh(new T.TetrahedronGeometry(.11 + Math.random()*.07), m.clone());
    p.userData.drift = {
      x:(Math.random()-.5)*.55,
      y:.85 + Math.random()*.7,
      z:(Math.random()-.5)*.55,
      spin:(Math.random()-.5)*4,
      delay:i*.09
    };
    p.position.set((Math.random()-.5)*.3, 0, (Math.random()-.5)*.3);
    g.add(p);
  }
  return g;
};

E.makeRootCage = function (){
  const g = new T.Group();
  for (let i = 0; i < 5; i++){
    const s = cone(.1, 1.1, "#4C7C46", 5);
    const a = (i/5)*Math.PI*2;
    s.position.set(Math.cos(a)*.42, .55, Math.sin(a)*.42);
    s.rotation.z = Math.cos(a)*.32; s.rotation.x = -Math.sin(a)*.32;
    g.add(s);
  }
  return g;
};

/* One-off offscreen render of a creature, for the chooser cards. */
E.previewCreature = function (kind, w, h){
  const r = new T.WebGLRenderer({antialias:true, alpha:true, preserveDrawingBuffer:true});
  r.setSize(w, h);
  const s = new T.Scene();
  s.add(new T.HemisphereLight("#A8BCE0", "#20242E", 1.1));
  const dl = new T.DirectionalLight("#FFF0D8", 1.0);
  dl.position.set(6, 10, 8); s.add(dl);
  const m = E.makeCreature(kind);
  m.rotation.y = -0.7;
  s.add(m);
  const bb = new T.Box3().setFromObject(m);
  const size = bb.getSize(new T.Vector3()), mid = bb.getCenter(new T.Vector3());
  const span = Math.max(size.x, size.y, size.z) || 6;
  const cam = new T.PerspectiveCamera(38, w/h, .1, 200);
  cam.position.set(mid.x + span*1.15, mid.y + span*.72, mid.z + span*1.5);
  cam.lookAt(mid);
  r.render(s, cam);
  const url = r.domElement.toDataURL("image/png");
  r.dispose();
  return url;
};

E.render = function (){ E.renderer.render(E.scene, E.camera); };

global.ENGINE = E;
})(window);
/* ===== sim.js ===== */
/* ═══════════════════════════════════════════════════════════════
   SOVEREIGN AEGIS — SIM
   The world: entities, skills and XP, jobs, construction, combat,
   flags and missions, squads, spells, alignment, the creature and
   the hand. Reads every number from DB, so the editor can change
   the game while it is running.
   ═══════════════════════════════════════════════════════════════ */
(function (global) {
"use strict";

const T = global.THREE, DB = global.DB, E = global.ENGINE;
const rnd = (a,b) => a + Math.random()*(b-a);
const pick = a => a[Math.floor(Math.random()*a.length)];
const clamp = (v,a,b) => v<a?a:v>b?b:v;
const d2 = (a,b) => Math.hypot(a.x-b.x, a.z-b.z);

let nextId = 1;

const W = {
  time:0, paused:false, speed:1,
  res:{wood:0, stone:0, gold:0, food:0, iron:0, goods:0},
  appeal:0,
  energy:30, energyCap:120, align:0, age:0,
  units:[], buildings:[], nodes:[], decor:[], projectiles:[], effects:[], carts:[],
  flags:{}, flagList:[], squads:[], missions:[], kills:0,
  clock:{day:0, year:0, hour:0}, gameMode:"single",
  creature:null, hand:null, leash:{attached:null, mesh:null},
  held:null, selected:null, hovered:null,
  blocked:new Set(), pickables:[], log:[],
  buffs:{quicken:0, aegis:0},
  villageCentre:{x:0, z:0},
  onLog:null, onEvent:null
};

/* ═══ names ══════════════════════════════════════════════════ */
const FIRST = ["Grimwald","Bors","Yvane","Ilric","Sable","Nix","Aldreth","Vane","Hallow","Ceth","Rooke","Mab",
  "Dunmar","Oriel","Perrin","Ysolde","Garrick","Thessaly","Brannoc","Ewart","Sela","Onric","Wrenna","Cadmar",
  "Lisbet","Halvard","Maerwyn","Toft","Ingrid","Bede","Alwin","Sorrel","Kestrel","Fenn","Ruark","Dilla"];
const EPITHET = ["the Stout","Quickstring","Copperhand","of the Downs","Fenwalker","Ashen","Longshadow","Greyhand",
  "of Aldermarch","the Patient","Coldwater","Thistle","the Younger","Ironshod","Nettle","Rooksbane"];
const used = new Set();
function makeName(family){
  for (let i = 0; i < 60; i++){
    const n = family === "folk" ? pick(FIRST) : pick(FIRST) + " " + pick(EPITHET);
    if (!used.has(n)){ used.add(n); return n; }
  }
  return pick(FIRST) + " " + (nextId);
}

/* ═══ logging ════════════════════════════════════════════════ */
function log(html, cls){
  W.log.unshift({html, cls:cls||"", t:W.time});
  if (W.log.length > 90) W.log.pop();
  if (W.onLog) W.onLog();
}
W.logMsg = log;

/* ═══ skills ═════════════════════════════════════════════════ */
function lvl(u, skill){ return DB.levelFor(u.xp[skill] || 0); }
function addXp(u, skill, amount){
  if (!u.xp || amount <= 0) return;
  const before = DB.levelFor(u.xp[skill] || 0);
  u.xp[skill] = (u.xp[skill] || 0) + amount;
  const after = DB.levelFor(u.xp[skill]);
  if (after > before){
    u.levelUps = (u.levelUps || 0) + 1;
    if (skill === "hitpoints"){
      const gain = (after - before) * 3;
      u.maxHp += gain; u.hp += gain;
    }
    if (u.family !== "monster" && after % 5 === 0)
      log('<b>' + u.name + '</b> reaches <span class="g">' + DB.SKILLS[skill].label + ' ' + after + '</span>.');
  }
}
W.lvl = lvl; W.addXp = addXp;

function combatLevel(u){
  const a = lvl(u,"attack"), s = lvl(u,"strength"), d = lvl(u,"defence"),
        h = lvl(u,"hitpoints"), r = lvl(u,"ranged"), m = lvl(u,"magic");
  return Math.floor((d + h + Math.max(a+s, r*1.5, m*1.5)) / 3.2) || 1;
}
W.combatLevel = combatLevel;

/* ═══ inventory / gear ═══════════════════════════════════════ */
function give(u, itemId, qty){
  const slot = u.inv.find(i => i.id === itemId);
  if (slot) slot.qty += (qty||1); else u.inv.push({id:itemId, qty:qty||1});
}
function equipValue(u, field){
  let v = 0;
  ["weapon","armour"].forEach(s => { const it = u.equip[s] && DB.ITEMS[u.equip[s]]; if (it && it[field]) v += it[field]; });
  return v;
}
function toolBonus(u, skill){
  let v = 0;
  u.inv.forEach(s => { const it = DB.ITEMS[s.id]; if (it && it.skill === skill) v += it.bonus || 0; });
  return v;
}

/* ═══ spatial blocking ═══════════════════════════════════════ */
const GS = 2;
const gk = (x,z) => Math.round(x/GS) + ":" + Math.round(z/GS);
function rebuildBlocking(){
  W.blocked.clear();
  W.buildings.forEach(b => {
    if (!b.def.blocks || !b.built) return;
    const hw = b.def.w/2, hd = b.def.d/2;
    for (let x = b.x-hw; x <= b.x+hw; x += GS)
      for (let z = b.z-hd; z <= b.z+hd; z += GS)
        W.blocked.add(gk(x,z) + (b.def.blocks === 2 ? "|g" : ""));
  });
}
function passable(x, z, hostile){
  if (W.blocked.has(gk(x,z))) return false;
  if (W.blocked.has(gk(x,z) + "|g")) return !hostile;
  return true;
}

/* ═══ movement ═══════════════════════════════════════════════ */
function moveTo(u, tx, tz, dt, speedMul){
  const dx = tx-u.x, dz = tz-u.z, d = Math.hypot(dx,dz);
  if (d < .001) return 0;
  const folkBonus = u.family === "folk" ? 1 + tech("folkSpeed") : 1;
  const sp = u.def.speed * (speedMul||1) * folkBonus * (W.buffs.quicken > 0 ? 1.35 : 1) * (u.frozen > 0 ? 0 : 1);
  const step = Math.min(sp*dt, d);
  const nx = u.x + dx/d*step, nz = u.z + dz/d*step;
  const hostile = u.faction === "monster";
  let moved = false;
  if (passable(nx, u.z, hostile)){ u.x = nx; moved = true; }
  if (passable(u.x, nz, hostile)){ u.z = nz; moved = true; }
  if (!moved){
    u.stuck = (u.stuck||0) + dt;
    const side = (u.sideBias || (u.sideBias = Math.random()<.5?1:-1));
    const px = -dz/d*step*side, pz = dx/d*step*side;
    if (passable(u.x+px, u.z+pz, hostile)){ u.x += px; u.z += pz; }
  } else u.stuck = 0;
  const lim = DB.TUNING.world.size/2 - 3;
  u.x = clamp(u.x, -lim, lim); u.z = clamp(u.z, -lim, lim);
  if (step > .0001) u.facing = Math.atan2(dx, dz);
  return Math.hypot(tx-u.x, tz-u.z);
}
function wallAhead(u){
  const a = u.facing || 0;
  const px = u.x + Math.sin(a)*1.6, pz = u.z + Math.cos(a)*1.6;
  return W.buildings.find(b => b.def.blocks && b.built &&
    Math.abs(b.x-px) <= b.def.w/2+.4 && Math.abs(b.z-pz) <= b.def.d/2+.4);
}

/* ═══ entity factories ═══════════════════════════════════════ */
function spawnUnit(cls, x, z, faction, opts){
  const def = DB.CLASSES[cls];
  const u = {
    id:nextId++, cls, def, family:def.family, faction:faction || (def.family === "monster" ? "monster" : "player"),
    name:makeName(def.family), x, z, y:0, facing:rnd(0,6.28),
    hp:def.hp, maxHp:def.hp, mp:def.mp||0, maxMp:def.mp||0,
    xp:{}, inv:[], equip:{weapon:null, armour:null},
    gold:0, owed:0, job:"idle", state:"idle", think:0, atkCd:0, frozen:0,
    bornAt:W.time, ageOffset:rnd(16, 44), thought:"", gearStep:0,
    target:null, homeBuilding:opts && opts.home || null, squad:null, slot:-1,
    greed:(def.greed||0)*rnd(.85,1.15), courage:(def.courage||0)*rnd(.85,1.15), duty:(def.duty||0)*rnd(.85,1.15)
  };
  Object.keys(DB.SKILLS).forEach(s => u.xp[s] = 0);
  Object.keys(def.baseSkills || {}).forEach(s => {
    const L = def.baseSkills[s] + Math.round(rnd(-1,2));
    u.xp[s] = DB.XP_TABLE[Math.max(0, Math.min(98, L-1))];
  });
  u.maxHp = def.hp + lvl(u,"hitpoints")*3;
  u.hp = u.maxHp;
  if (def.family === "folk"){
    if (Math.random() < .5) give(u, "bread", 1 + Math.floor(Math.random()*2));
    // everyone gets their own span, rolled from the band in DB.TIME
    u.lifespan = rnd(DB.TIME.lifespanMin, DB.TIME.lifespanMax);
    u.birthAgeYears = rnd(DB.TIME.childhoodYears + 2, 40);
    u.bornYear = worldYears();
  }
  if (def.family === "hero"){
    u.gold = Math.round(rnd(0, 60));
    give(u, "bread", 1);
  }
  const mesh = E.makeUnit(cls);
  mesh.position.set(x, 0, z);
  mesh.userData.entity = u;
  E.scene.add(mesh);
  u.mesh = mesh;
  W.units.push(u);
  W.pickables.push(mesh);
  return u;
}
W.spawnUnit = spawnUnit;

function removeUnit(u){
  const i = W.units.indexOf(u); if (i >= 0) W.units.splice(i,1);
  const p = W.pickables.indexOf(u.mesh); if (p >= 0) W.pickables.splice(p,1);
  E.scene.remove(u.mesh);
  if (u.squad){ const s = u.squad; const j = s.units.indexOf(u); if (j >= 0) s.units.splice(j,1); }
  if (W.selected === u) W.selected = null;
  if (W.held === u) W.held = null;
}

function placeBuilding(type, x, z, opts){
  opts = opts || {};
  const def = DB.BUILDINGS[type];
  const b = {
    id:nextId++, type, def, x, z, tier:opts.tier || 1,
    hp:def.hp, maxHp:def.hp, built:!!opts.instant || def.work === 0,
    prog:0, enemy:!!opts.enemy, cd:0, storeTimer:0
  };
  b.maxHp = def.hp * (1 + (b.tier-1)*.4) * (1 + tech("buildingHp"));
  b.hp = b.built ? b.maxHp : b.maxHp*.35;
  // a site must be supplied with timber before anyone can raise it
  b.woodNeed = b.built ? 0 : Math.max(10, Math.round((def.cost.wood || 40) * .5 + def.work));
  b.woodIn = 0;
  const mesh = E.makeBuilding(type, b.tier, b.enemy);
  mesh.position.set(x, 0, z);
  mesh.userData.entity = b;
  if (!b.built) mesh.traverse(o => { if (o.material){ o.material = o.material.clone(); o.material.transparent = true; o.material.opacity = .35; } });
  E.scene.add(mesh);
  b.mesh = mesh;
  W.buildings.push(b);
  W.pickables.push(mesh);
  rebuildBlocking();
  return b;
}
W.placeBuilding = placeBuilding;

function finishBuilding(b){
  b.built = true; b.hp = b.maxHp;
  E.scene.remove(b.mesh);
  const p = W.pickables.indexOf(b.mesh); if (p >= 0) W.pickables.splice(p,1);
  const mesh = E.makeBuilding(b.type, b.tier, b.enemy);
  mesh.position.set(b.x, 0, b.z);
  mesh.userData.entity = b;
  E.scene.add(mesh);
  b.mesh = mesh;
  W.pickables.push(mesh);
  rebuildBlocking();
  log('<span class="t">⌂</span> <b>' + b.def.label + '</b> raised.');
  if (b.def.guild || b.type === "temple") applyAlignmentVisual();
  if (W.onEvent) W.onEvent("built", b);
}
function removeBuilding(b){
  const i = W.buildings.indexOf(b); if (i >= 0) W.buildings.splice(i,1);
  const p = W.pickables.indexOf(b.mesh); if (p >= 0) W.pickables.splice(p,1);
  E.scene.remove(b.mesh);
  if (W.selected === b) W.selected = null;
  rebuildBlocking();
}

/* Flora from a NATURE.flora definition — trees, bushes and grass. */
function spawnFlora(id, x, z){
  const def = DB.NATURE.flora[id];
  if (!def) return null;
  const scale = rnd(.85, 1.2);
  const n = {id:nextId++, flora:id, def, kind:def.kind === "tree" ? "tree" : def.kind,
             yields:def.yields, x, z, amount:def.amount, max:def.amount || 1,
             respawnTime:def.regrow, respawn:0, scale, isNode:true,
             decorative:!!def.decorative, label:def.label};
  const mesh = E.makeFlora(def, scale);
  mesh.position.set(x, 0, z);
  mesh.rotation.y = rnd(0, 6.28);
  if (!def.decorative) mesh.userData.entity = n;
  E.scene.add(mesh);
  n.mesh = mesh;
  if (!def.decorative){ W.nodes.push(n); W.pickables.push(mesh); }
  else W.decor.push(n);
  return n;
}

function spawnNode(kind, x, z){
  const amount = kind === "tree" ? 160 : kind === "rock" ? 260 : kind === "deposit" ? 520 : 190;
  const n = {id:nextId++, kind, x, z, amount, max:amount, respawn:0,
             scale:rnd(.85,1.25), isNode:true};
  const mesh = E.makeNode(kind, n.scale);
  mesh.position.set(x, 0, z);
  mesh.rotation.y = rnd(0,6.28);
  mesh.userData.entity = n;
  E.scene.add(mesh);
  n.mesh = mesh;
  W.nodes.push(n);
  W.pickables.push(mesh);
  return n;
}

/* ═══ nature distribution ════════════════════════════════════
   Reads NATURE.flora / .fauna / .minerals and scatters them by their
   own dist rules: which band of the map, how many clumps, how tight,
   and how far apart individuals must stand. */
function zoneOf(name){
  const z = DB.NATURE.zones[name] || DB.NATURE.zones.any;
  const half = DB.TUNING.world.size/2 - 6;
  return {x1:Math.max(-half, z.x1), x2:Math.min(half, z.x2), z1:-half, z2:half};
}
function tooClose(x, z, gap){
  if (gap <= 0) return false;
  for (const n of W.nodes) if (Math.hypot(n.x-x, n.z-z) < gap) return true;
  return false;
}
function distributeNature(){
  const N = DB.NATURE;

  Object.keys(N.flora).forEach(id => {
    const f = N.flora[id], d = f.dist || {};
    const zone = zoneOf(d.zone || "any");
    const clumps = Math.round((d.clumps || 3) * (d.density === undefined ? 1 : d.density));
    for (let c = 0; c < clumps; c++){
      const cx = rnd(zone.x1, zone.x2), cz = rnd(zone.z1, zone.z2);
      const per = Math.round(rnd(5, 11) * (d.density === undefined ? 1 : d.density)) + 2;
      for (let i = 0; i < per; i++){
        const a = rnd(0,6.28), r = Math.sqrt(Math.random()) * (d.spread || 10);
        const x = cx + Math.cos(a)*r, z = cz + Math.sin(a)*r;
        if (x < zone.x1 || x > zone.x2) continue;
        if (!f.decorative && tooClose(x, z, d.minGap || 2)) continue;
        spawnFlora(id, x, z);
      }
    }
  });

  Object.keys(N.minerals).forEach(id => {
    const m = N.minerals[id], d = m.dist || {};
    const zone = zoneOf(d.zone || "any");
    for (let c = 0; c < (d.clumps || 2); c++){
      const cx = rnd(zone.x1, zone.x2), cz = rnd(zone.z1, zone.z2);
      for (let i = 0; i < (d.count || 5); i++){
        const a = rnd(0,6.28), r = Math.sqrt(Math.random()) * (d.spread || 7);
        const x = cx + Math.cos(a)*r, z = cz + Math.sin(a)*r;
        if (x < zone.x1 || x > zone.x2) continue;
        if (tooClose(x, z, 2.2)) continue;
        const n = spawnNode(m.kind, x, z);
        if (n && m.amount){ n.amount = m.amount; n.max = m.amount; }
      }
    }
  });

  Object.keys(N.fauna).forEach(id => {
    const f = N.fauna[id], d = f.dist || {};
    if (!DB.CLASSES[f.cls]) return;
    const zone = zoneOf(d.zone || "any");
    for (let h = 0; h < (d.herds || 1); h++){
      const cx = rnd(zone.x1, zone.x2), cz = rnd(zone.z1, zone.z2);
      const anchor = {x:cx, z:cz};
      const size = Math.round(rnd((d.size||[3,5])[0], (d.size||[3,5])[1]));
      for (let i = 0; i < size; i++){
        const a = rnd(0,6.28), r = Math.sqrt(Math.random()) * (d.spread || 6);
        const b = spawnUnit(f.cls, cx + Math.cos(a)*r, cz + Math.sin(a)*r, "wild");
        b.anchor = anchor;
      }
    }
  });
}
W.distributeNature = distributeNature;

/* ═══ world build ════════════════════════════════════════════ */
function buildWorld(){
  const M = DB.MAP, TN = DB.TUNING;
  W.res.wood = TN.economy.startWood; W.res.stone = TN.economy.startStone;
  W.res.gold = TN.economy.startGold; W.res.food = TN.economy.startFood;
  W.villageCentre = {x:M.villageCentre.x, z:M.villageCentre.z};

  /* NATURE owns what grows and grazes where; the old fixed clusters in
     MAP are only used if the nature tables are emptied out. */
  if (Object.keys(DB.NATURE.flora).length) distributeNature();
  else M.nodeClusters.forEach(c => {
    for (let i = 0; i < c.count; i++){
      const a = rnd(0,6.28), r = Math.sqrt(Math.random())*c.spread;
      spawnNode(c.kind, c.x + Math.cos(a)*r, c.z + Math.sin(a)*r);
    }
  });
  M.buildings.forEach(b => placeBuilding(b.type, b.x, b.z, {tier:b.tier, instant:true}));
  (M.enemyBuildings||[]).forEach(b => placeBuilding(b.type, b.x, b.z, {tier:b.tier, instant:true, enemy:true}));

  // wall runs: a straight line of 2m segments between two points
  (M.wallRuns || []).forEach(run => {
    const dx = run.x2 - run.x1, dz = run.z2 - run.z1;
    const steps = Math.max(1, Math.round(Math.hypot(dx, dz) / 2));
    for (let i = 0; i <= steps; i++){
      const x = Math.round((run.x1 + dx*(i/steps))/2)*2;
      const z = Math.round((run.z1 + dz*(i/steps))/2)*2;
      const clash = W.buildings.some(b => Math.abs(b.x-x) < (b.def.w+2)/2 && Math.abs(b.z-z) < (b.def.d+2)/2);
      if (!clash) placeBuilding(run.type || "wall", x, z, {instant:true});
    }
  });

  if (!Object.keys(DB.NATURE.fauna).length) (M.herds || []).forEach(h => {
    const anchor = {x:h.x, z:h.z};
    for (let i = 0; i < h.count; i++){
      const a = rnd(0,6.28), r = Math.sqrt(Math.random())*h.spread;
      const b = spawnUnit(h.kind, h.x + Math.cos(a)*r, h.z + Math.sin(a)*r, "wild");
      b.anchor = anchor;
    }
  });

  M.spawns.forEach(s => {
    const lair = {id:s.id, x:s.x, z:s.z, kind:s.kind, every:s.every, cap:s.cap, label:s.label,
                  timer:rnd(0, s.every), alive:0, isLair:true,
                  hp:DB.THREATS.lairHp, maxHp:DB.THREATS.lairHp,
                  dead:false, respawnIn:0, homeX:s.x, homeZ:s.z};
    const g = new T.Group();
    const pit = E.prim.cyl(s.radius, s.radius*.6, 1.2, "#3A2020", 10); pit.position.y = .6;
    const spike1 = E.prim.cone(.3, 2.4, "#5E3634", 5); spike1.position.set(-s.radius*.5, 1.2, 0);
    const spike2 = E.prim.cone(.3, 2.8, "#5E3634", 5); spike2.position.set(s.radius*.5, 1.4, .6);
    [pit, spike1, spike2].forEach(m => { m.castShadow = m.receiveShadow = true; g.add(m); });
    g.position.set(s.x, 0, s.z);
    g.userData.entity = lair;
    E.scene.add(g);
    lair.mesh = g;
    W.pickables.push(g);
    W.lairs = W.lairs || [];
    W.lairs.push(lair);
  });

  const keep = W.buildings.find(b => b.type === "keep");
  for (let i = 0; i < TN.population.startVillagers; i++){
    const u = spawnUnit("villager", keep.x + rnd(-8,8), keep.z + rnd(-8,8), "player");
    u.job = i < 2 ? "forester" : i < 4 ? "miner" : i < 6 ? "builder" : "idle";
  }

  /* Two companies of eight adventurers, one of each class. They are
     ordinary heroes: they appraise flags, and they can be talked into
     breaking a lair or holding a line by price alone. */
  (M.startingCompanies || []).forEach(co => {
    const home = nearest({x:co.x, z:co.z}, W.buildings, b => b.def.guild && b.built)
              || W.buildings.find(b => b.type === "keep");
    co.roster.forEach((cls, i) => {
      if (!DB.CLASSES[cls]) return;
      const a = (i/co.roster.length) * 6.28;
      const u = spawnUnit(cls, co.x + Math.cos(a)*4, co.z + Math.sin(a)*4, "player", {home});
      u.company = co.name;
      const ladder = DB.GEAR_LADDER[cls];
      if (ladder){ u.equip.weapon = ladder[0]; give(u, ladder[0]); u.gearStep = 1; }
      u.gold = Math.round(rnd(20, 90));
    });
    log('<span class="g">✦</span> <b>' + co.name + '</b> musters — ' + co.roster.length + ' for hire.');
  });

  /* Squads at the encampment: soldiers who obey the banner, not a price. */
  (M.startingSquads || []).forEach(spec => {
    const home = nearest({x:spec.x, z:spec.z}, W.buildings, b => b.type === "barracks" && b.built)
              || W.buildings.find(b => b.type === "keep");
    if (!home) return;
    const s = makeSquad(home);
    s.name = spec.name;
    if (spec.colour){
      s.colour = spec.colour;
      s.mesh.userData.cloth.material = E.mat(spec.colour);
      s.mesh.userData.ring.material.color.set(spec.colour);
    }
    moveBanner(s, spec.x, spec.z);
    spec.roster.forEach((cls, i) => {
      if (!DB.CLASSES[cls]) return;
      const u = spawnUnit(cls, spec.x + rnd(-4,4), spec.z + rnd(-4,4), "player");
      u.squad = s; u.slot = s.units.length; u.state = "march";
      if (!DB.CLASSES[cls].siege){
        const ladder = DB.GEAR_LADDER.soldier;
        u.equip.weapon = ladder[0]; u.equip.armour = ladder[1];
        give(u, ladder[0]); give(u, ladder[1]);
      }
      give(u, "bread", 2);
      s.units.push(u);
    });
    log('<span class="t">▮</span> <b>' + s.name + '</b> stands at the encampment — ' + s.units.length + ' under arms.');
  });

  // the hand
  W.hand = E.makeHand();
  W.hand.position.set(0, 6, 0);
  E.scene.add(W.hand);

  /* The three summoning flags stand outside the keep from the first
     frame. Pick one up with the right button and plant it anywhere,
     or use the Flags panel. */
  const keepB = W.buildings.find(b => b.type === "keep");
  let fi = 0;
  Object.keys(DB.FLAGS).forEach(kind => {
    const fx = keepB.x + 7 + fi*3, fz = keepB.z + 8;
    setFlag(kind, fx, fz, UIPrice(kind), null, true);
    fi++;
  });

  W.leash.mesh = E.makeLeash();
  W.leash.mesh.visible = false;
  E.scene.add(W.leash.mesh);

  // escort cart for missions
  spawnCart();

  rollMissions();
  log('<span class="t">›</span> ' + M.name + ' stands. ' + TN.population.startVillagers + ' folk, one guild, four lairs east.');
  log('<span class="g">›</span> Right-drag to pan, wheel to zoom, middle-drag to turn. Hold <b>space</b> and drag to orbit.');
}

/* The creature is chosen, not given. Until one is picked the realm runs
   without it — the leash has nothing to hook to. */
W.chooseCreature = function (kind){
  const cd = DB.CREATURES[kind];
  if (!cd) return null;
  if (W.creature){
    E.scene.remove(W.creature.mesh);
    const p = W.pickables.indexOf(W.creature.mesh); if (p >= 0) W.pickables.splice(p,1);
  }
  const keep = W.buildings.find(b => b.type === "keep");
  const x = keep.x + 18, z = keep.z + 15;
  const def = {
    label:cd.label, family:"creature", colour:cd.colour, accent:cd.accent,
    hp:cd.hp, speed:cd.speed, radius:cd.radius, height:cd.height,
    attackRange:cd.attackRange, attackSpeed:cd.attackSpeed, damage:cd.damage,
    baseSkills:cd.baseSkills, desc:cd.trait
  };
  const mesh = E.makeCreature(cd.shape);
  mesh.position.set(x, 0, z);
  E.scene.add(mesh);
  const c = {
    id:nextId++, cls:"creature", kind, def, family:"creature", faction:"player",
    name:cd.label, x, z, y:0, facing:0,
    hp:cd.hp, maxHp:cd.hp, mp:0, maxMp:0, xp:{}, inv:[], equip:{weapon:null, armour:null},
    gold:0, owed:0, mesh, state:"wander", thought:"", think:0, atkCd:0, frozen:0,
    bornAt:W.time, ageOffset:4, hunger:0, mood:0, wanderT:0, tx:x, tz:z,
    petting:0, lastThought:0, job:"—", regen:cd.regen || 0, hungerRate:cd.hungerRate,
    fed:0, girth:1
  };
  Object.keys(DB.SKILLS).forEach(s => c.xp[s] = 0);
  Object.keys(cd.baseSkills).forEach(s => c.xp[s] = DB.XP_TABLE[Math.max(0, cd.baseSkills[s]-1)]);
  mesh.userData.entity = c;
  W.pickables.push(mesh);
  W.creature = c;
  W.leash.attached = null;
  applyAlignmentVisual();
  log('<span class="g">✦</span> <b>' + cd.label + '</b> answers. ' + cd.trait);
  return c;
};

/* ── full restart, in place ──────────────────────────────────── */
W.reset = function (){
  const drop = m => { if (m) E.scene.remove(m); };
  W.units.forEach(u => drop(u.mesh));
  W.buildings.forEach(b => drop(b.mesh));
  W.nodes.forEach(n => drop(n.mesh));
  W.decor.forEach(n => drop(n.mesh));
  (W.lairs || []).forEach(l => drop(l.mesh));
  W.carts.forEach(c => drop(c.mesh));
  W.projectiles.forEach(p => drop(p.mesh));
  W.effects.forEach(f => drop(f.mesh));
  W.squads.forEach(s => drop(s.mesh));
  W.flagList.forEach(f => drop(f.mesh));
  if (W.creature) drop(W.creature.mesh);
  drop(W.hand);
  drop(W.leash.mesh);

  W.units = []; W.buildings = []; W.nodes = []; W.decor = []; W.projectiles = []; W.effects = [];
  W.carts = []; W.lairs = []; W.squads = []; W.pickables = []; W.missions = []; W.log = [];
  W.flags = {}; W.flagList = []; W.blocked.clear();
  W.clock = {day:0, year:0, hour:0};
  W.creature = null; W.hand = null; W.leash = {attached:null, mesh:null};
  W.held = null; W.selected = null; W.hovered = null;
  W.time = 0; W.paused = false; W.speed = 1; W.age = 0; W.kills = 0;
  W.energy = 30; W.align = 0;
  W.researched = {};
  W.buffs = {quicken:0, aegis:0};
  W.warned = {};
  popT = 0; guildT = 5; settleT = 3;
  used.clear();

  buildWorld();
  if (W.onReset) W.onReset();
  log('<span class="t">↻</span> The realm is begun again.');
};

function spawnCart(){
  const g = new T.Group();
  const body = E.prim.box(2.4, 1.1, 1.5, "#8A6A4A"); body.position.y = .95;
  const w1 = E.prim.cyl(.5,.5,.2,"#5A4630",10); w1.rotation.z = Math.PI/2; w1.position.set(-.8,.5,.85);
  const w2 = w1.clone(); w2.position.z = -.85;
  const w3 = w1.clone(); w3.position.set(.8,.5,.85);
  const w4 = w1.clone(); w4.position.set(.8,.5,-.85);
  [body,w1,w2,w3,w4].forEach(m => { m.castShadow = m.receiveShadow = true; g.add(m); });
  const keep = W.buildings.find(b => b.type === "keep");
  g.position.set(keep.x + 6, 0, keep.z + 22);
  E.scene.add(g);
  const cart = {id:nextId++, isCart:true, name:"Laden Cart", x:keep.x+6, z:keep.z+22,
                hp:120, maxHp:120, mesh:g, moving:false, route:null, routeI:0, speed:2.2,
                def:{label:"Cart", speed:2.2, radius:1}, family:"cart", faction:"player", inv:[], xp:{}, equip:{}};
  g.userData.entity = cart;
  W.carts.push(cart);
  W.pickables.push(g);
  return cart;
}

/* ═══ resources ══════════════════════════════════════════════ */
function afford(cost){ return Object.keys(cost||{}).every(k => W.res[k] >= cost[k]); }
function pay(cost){ Object.keys(cost||{}).forEach(k => W.res[k] -= cost[k]); }
W.afford = afford; W.pay = pay;

/* building lookups */
function has(type){ return W.buildings.some(b => b.type === type && b.built && !b.enemy); }
function get(type){ return W.buildings.filter(b => b.type === type && b.built && !b.enemy); }
function best(type){ return get(type).sort((a,b) => b.tier - a.tier)[0] || null; }
/* generic nearest-of-a-list, by plain x/z distance */
function nearest(from, list, filter){
  let pickBest = null, bd = Infinity;
  for (const it of list){
    if (!it || (filter && !filter(it))) continue;
    const d = d2(from, it);
    if (d < bd){ bd = d; pickBest = it; }
  }
  return pickBest;
}
W.has = has; W.get = get; W.best = best;

/* Any store, storehouse or warehouse will take a load — gatherers walk
   to whichever is nearest, so a far corner stops being a trek. */
function storeBuilding(near){
  const drops = W.buildings.filter(b => b.built && !b.enemy &&
    (b.type === "store" || b.type === "keep" ||
     (b.def.effect && b.def.effect.dropOff)));
  if (!drops.length) return null;
  if (!near) return drops[0];
  return nearest(near, drops);
}
function popCap(){
  let c = DB.TUNING.population.baseCap;
  W.buildings.forEach(b => { if (b.built && b.def.effect && b.def.effect.popCap) c += b.def.effect.popCap * b.tier; });
  return c;
}
W.popCap = popCap;

function nearestBuilding(u, filter){
  let best = null, bd = Infinity;
  W.buildings.forEach(b => {
    if (!b.built || (filter && !filter(b))) return;
    const d = d2(u,b); if (d < bd){ bd = d; best = b; }
  });
  return best;
}
function nearestNode(u, kinds){
  let best = null, bd = Infinity;
  W.nodes.forEach(n => {
    if (n.amount <= 0 || kinds.indexOf(n.kind) < 0) return;
    const d = d2(u,n); if (d < bd){ bd = d; best = n; }
  });
  return best;
}
/* What a node gives up when worked — flora declare it, older nodes infer it. */
function yieldOf(n){
  if (n.yields) return n.yields;
  if (n.kind === "tree") return "wood";
  if (n.kind === "vein" || n.kind === "deposit") return "gold";
  if (n.kind === "bush") return "food";
  return "stone";
}
function nearestYield(u, wants){
  let best = null, bd = Infinity;
  W.nodes.forEach(n => {
    if (n.amount <= 0 || wants.indexOf(yieldOf(n)) < 0) return;
    const d = d2(u,n); if (d < bd){ bd = d; best = n; }
  });
  return best;
}
function nearestEnemy(u, range, faction){
  let best = null, bd = range === undefined ? Infinity : range;
  const foes = (faction || u.faction) === "monster"
    ? W.units.filter(x => x.faction === "player" && x.hp > 0)
             .concat(W.creature && W.creature.hp > 0 ? [W.creature] : [])
    : W.units.filter(x => x.faction === "monster" && x.hp > 0);
  foes.forEach(f => { const d = d2(u,f); if (d < bd){ bd = d; best = f; } });
  return best;
}
W.nearestEnemy = nearestEnemy;

/* ═══ combat ═════════════════════════════════════════════════ */
/* Towers and other non-skilled attackers pass through here too, so every
   lookup has to survive an entity with no skill table and no equipment. */
/* ── research ─────────────────────────────────────────────────
   W.researched is a set of ids; tech() sums one effect field over
   everything bought so far. Every system that cares reads it live. */
W.researched = {};
function tech(field){
  let v = 0;
  Object.keys(W.researched).forEach(id => {
    const r = DB.RESEARCH[id];
    if (r && r.effect[field]) v += r.effect[field];
  });
  return v;
}
W.tech = tech;
W.canResearch = function (id){
  const r = DB.RESEARCH[id];
  if (!r || W.researched[id]) return false;
  if (r.age > W.age) return false;
  if (r.needs && !W.researched[r.needs]) return false;
  return afford(r.cost);
};
W.buyResearch = function (id){
  const r = DB.RESEARCH[id];
  if (!W.canResearch(id)) return false;
  pay(r.cost);
  W.researched[id] = true;
  log('<span class="g">✦</span> Researched <b class="g">' + r.label + '</b> — ' + r.desc);
  if (r.effect.buildingHp){
    W.buildings.forEach(b => {
      const nm = b.def.hp * (1 + (b.tier-1)*.4) * (1 + tech("buildingHp"));
      const frac = b.hp / b.maxHp;
      b.maxHp = nm; b.hp = nm * frac;
    });
  }
  return true;
};

function smithy(field){
  const b = W.buildings.find(x => x.type === "blacksmith" && x.built);
  return b ? 1 + b.def.effect[field]*b.tier : 1;
}
function attackPower(u){
  const isRanged = u.def.projectile === "arrow";
  const isMagic = u.def.projectile === "roots" || u.def.projectile === "bolt";
  const skill = !u.xp ? 0
    : isRanged ? lvl(u,"ranged")
    : isMagic ? lvl(u,"magic")
    : (lvl(u,"attack") + lvl(u,"strength"))/2;
  let raw = (u.def.damage || 4) + skill*.8 + (u.equip ? equipValue(u,"atk")*.6 : 0);
  if (u.faction === "player"){
    raw += isRanged ? tech("rangedDamage") : isMagic ? 0 : tech("meleeDamage");
    raw *= smithy("attackBonus");
  }
  return raw;
}
function defencePower(u){
  if (!u || !u.xp) return 0;                    // buildings, carts, lairs
  let raw = lvl(u,"defence")*.7 + (u.equip ? equipValue(u,"def")*.8 : 0);
  if (u.faction === "player"){ raw += tech("armour"); raw *= smithy("defenceBonus"); }
  return raw;
}
function isBuilding(e){ return !!(e && e.def && e.built !== undefined); }

function dealDamage(src, tgt, amount, magical){
  if (!tgt || tgt.hp <= 0) return 0;
  let dmg = Math.max(1, amount - defencePower(tgt)*(magical ? .4 : .8));
  const ours = tgt.faction === "player" || (isBuilding(tgt) && !tgt.enemy);
  if (W.buffs.aegis > 0 && ours) dmg *= .5;
  tgt.hp -= dmg;
  if (src && src.xp){
    const xpk = DB.TUNING.combat.xpPerDamage;
    if (src.def.projectile === "arrow") addXp(src,"ranged", dmg*xpk);
    else if (magical) addXp(src,"magic", dmg*xpk);
    else { addXp(src,"attack", dmg*xpk*.5); addXp(src,"strength", dmg*xpk*.5); }
    addXp(src,"hitpoints", dmg*xpk*.33);
  }
  if (tgt.xp){ addXp(tgt,"defence", dmg*DB.TUNING.combat.xpPerDamage*.4); addXp(tgt,"hitpoints", dmg*.8); }
  if (tgt.hp <= 0) onDeath(tgt, src);
  return dmg;
}
W.dealDamage = dealDamage;

function onDeath(u, killer){
  if (u && u.isLair){ damageLair(u, 0, killer); return; }
  if (isBuilding(u)){
    if (u.type === "keep"){
      log('<span class="r">☠</span> <b>The Keep has fallen.</b> The realm is finished here.');
      W.paused = true;
    } else log('<span class="r">✕</span> The ' + u.def.label.toLowerCase() + ' is destroyed.');
    removeBuilding(u);
    return;
  }
  if (u.isCart){ log('<span class="r">✕</span> The cart is destroyed.'); failMissionsFor("cart"); return; }
  if (u === W.creature){ u.hp = u.maxHp*.3; u.thought = "I nearly died."; return; }
  if (u.faction === "monster"){
    W.kills++;
    const flag = W.flags.attack;
    if (killer && killer.faction === "player" && killer.family === "hero" && flag){
      payBounty(killer, flag.price, u);
    } else if (killer && killer.family === "hero"){
      log('<b>' + killer.name + '</b> puts down a ' + u.def.label.toLowerCase() + ' for nothing but the exercise.');
    }
    if (killer && killer === W.creature){
      shiftAlign(DB.ALIGNMENT.deltas.killMonster);
      W.growCreature(killer, 34 + (u.def.bounty || 1) * 16);   // it feeds on what it kills
    }
    if (killer && killer.faction === "player") shiftAlign(DB.ALIGNMENT.deltas.killMonster);
    if (u.lair) u.lair.alive--;
    removeUnit(u);
    checkMissions();
    return;
  }
  // player-side death
  if (u.family === "folk"){
    log('<span class="r">✕</span> <b>' + u.name + '</b> is killed.');
    if (killer && killer === W.creature) shiftAlign(DB.ALIGNMENT.deltas.creatureEatsFolk);
    removeUnit(u);
    return;
  }
  if (u.family === "hero"){
    u.hp = 0; u.state = "down"; u.downT = 14;
    u.gold = Math.round(u.gold*.5);
    log('<b>' + u.name + '</b> falls. They will be carried home.');
    return;
  }
  if (u.family === "soldier"){
    log('<span class="r">✕</span> ' + u.def.label + ' <b>' + u.name + '</b> is cut down.');
    removeUnit(u);
    return;
  }
}

function fireProjectile(src, tgt, kind, damageOverride){
  const mesh = E.makeProjectile(kind);
  mesh.position.set(src.x, (src.def.height || 2)*.6, src.z);
  E.scene.add(mesh);
  W.projectiles.push({mesh, src, tgt, kind, speed:kind === "arrow" ? 34 : 22,
    damage:damageOverride !== undefined ? damageOverride : attackPower(src),
    magical:kind !== "arrow"});
}

/* ═══ bounty economy ═════════════════════════════════════════ */
function payBounty(hero, price, victim){
  const pay = Math.max(0, Math.min(price, W.res.gold));
  const short = price - pay;
  W.res.gold -= pay; hero.gold += pay;
  const what = victim ? victim.def.label.toLowerCase() : "the mark";
  if (short > 0){
    hero.owed += short;
    log('<b>' + hero.name + '</b> drops a ' + what + ' — treasury short, <span class="r">' + Math.round(short) + 'g unpaid</span>.');
  } else {
    log('<b>' + hero.name + '</b> drops a ' + what + ' — claims <span class="g">' + pay + 'g</span>.');
  }
}

/* ═══ flags ══════════════════════════════════════════════════ */
function UIPrice(kind){ return DB.FLAGS[kind].basePrice; }

/* Flags are a list now, not one-per-colour: plant as many of each as the
   definition allows, price them individually, hide them, or pin one to a
   moving charge — a cart, a villager, or the creature. */
function addFlag(kind, x, z, price, attachTo, quiet){
  const def = DB.FLAGS[kind];
  if (!def) return null;
  const mine = W.flagList.filter(f => f.kind === kind);
  if (mine.length >= (def.maxFlags || 6)){
    log('<span class="r">⚑</span> No more ' + def.label.toLowerCase() + ' flags to give.');
    return null;
  }
  const mesh = E.makeFlag(kind);
  mesh.position.set(x, 0, z);
  E.scene.add(mesh);
  const f = {
    id:nextId++, kind, x, z,
    price:price === undefined ? def.basePrice : price,
    mesh, attachTo:attachTo || null, held:0, hidden:false,
    def, isFlag:true, name:def.label + " Flag",
    label:def.label + " " + (mine.length + 1)
  };
  mesh.userData.entity = f;
  W.pickables.push(mesh);
  W.flagList.push(f);
  W.flags[kind] = f;                       // newest of this colour, for older callers
  W.units.forEach(u => { if (u.family === "hero") u.think = 0; });
  if (!quiet)
    log('<span class="g">⚑</span> <b>' + f.label + '</b> planted at <span class="g">' + f.price + 'g</span>.');
  if (W.onEvent) W.onEvent("flag", f);
  return f;
}
W.addFlag = addFlag;

function removeFlag(f){
  if (!f) return;
  const i = W.flagList.indexOf(f);
  if (i >= 0) W.flagList.splice(i, 1);
  E.scene.remove(f.mesh);
  const p = W.pickables.indexOf(f.mesh); if (p >= 0) W.pickables.splice(p, 1);
  if (W.held === f) W.held = null;
  W.units.forEach(u => { if (u.flagRef === f){ u.flagRef = null; u.flag = null; u.state = "return"; } });
  W.flags[f.kind] = W.flagList.filter(x => x.kind === f.kind).slice(-1)[0] || null;
}
W.removeFlag = removeFlag;

W.setFlagHidden = function (f, hidden){
  if (!f) return;
  f.hidden = !!hidden;
  f.mesh.visible = !hidden;
};

/* Kept for compatibility: replaces every flag of a colour with one. */
function setFlag(kind, x, z, price, attachTo, quiet){
  W.flagList.filter(f => f.kind === kind).forEach(removeFlag);
  return addFlag(kind, x, z, price, attachTo, quiet);
}
function clearFlag(kind){
  W.flagList.filter(f => f.kind === kind).forEach(removeFlag);
  W.flags[kind] = null;
}
W.setFlag = setFlag; W.clearFlag = clearFlag;

function appraise(u, f){
  if (!f) return -999;
  const A = f.def.appeal;
  const d = d2(u, f);
  const nearFoes = W.units.filter(m => m.faction === "monster" && d2(m,f) < 16).length;
  const danger = (16 + nearFoes*13) * A.risk;
  const courage = u.courage + (W.buffs.aegis > 0 ? .3 : 0);
  const price = f.price * (1 + tech("bountyDiscount"));   // heraldry: same coin buys more willingness
  return (price * (0.5 + u.greed)) / (1 + u.gold/110)
       + u.duty*A.dutyWeight + combatLevel(u)*1.4 + u.gearStep*4
       - danger*(1.3 - courage)
       - u.owed*.45
       - d*A.distWeight;
}

/* ═══ missions ═══════════════════════════════════════════════ */
function rollMissions(){
  W.missions = [];
  const lairs = W.lairs || [];
  const picks = DB.MISSIONS.slice();
  for (let i = 0; i < 3 && picks.length; i++){
    const tpl = picks.splice(Math.floor(Math.random()*picks.length),1)[0];
    const m = {id:tpl.id + "_" + nextId++, tpl, flag:tpl.flag, label:tpl.label, brief:tpl.brief,
               reward:tpl.reward, need:tpl.need, prog:0, done:false, failed:false, active:false};
    if (tpl.target === "lair"){
      const l = pick(lairs); m.lair = l;
      m.label = tpl.label.replace("{lair}", l ? l.label : "lair");
      m.x = l ? l.x : 0; m.z = l ? l.z : 0;
    } else if (tpl.target === "gate"){
      m.label = tpl.label.replace("{place}","line").replace("{t}", tpl.need);
      m.x = W.villageCentre.x + 30; m.z = W.villageCentre.z;
    } else if (tpl.target === "cart"){
      m.label = tpl.label.replace("{place}","far market");
      m.cart = W.carts[0];
      m.x = W.villageCentre.x + 40; m.z = W.villageCentre.z - 30;
    } else {
      m.label = tpl.label.replace("{n}", tpl.need);
      m.baseKills = W.kills;
    }
    W.missions.push(m);
  }
}
W.rollMissions = rollMissions;

function checkMissions(){
  W.missions.forEach(m => {
    if (m.done || m.failed) return;
    const tpl = m.tpl;
    if (tpl.target === "kills"){
      m.prog = W.kills - (m.baseKills||0);
      if (m.prog >= m.need) completeMission(m);
    } else if (tpl.target === "lair" && m.lair){
      const near = W.units.filter(u => u.faction === "monster" && d2(u, m.lair) < 14).length;
      m.prog = Math.max(m.prog, m.need - near);
      if (near === 0 && W.flags.attack && d2(W.flags.attack, m.lair) < 18) completeMission(m);
    }
  });
}
function completeMission(m){
  m.done = true;
  W.res.gold += m.reward.gold;
  const heroes = W.units.filter(u => u.family === "hero");
  heroes.forEach(h => addXp(h, "attack", m.reward.xp / Math.max(1,heroes.length)));
  log('<span class="g">★</span> Mission complete — <b>' + m.label + '</b>. <span class="g">+' + m.reward.gold + 'g</span>');
  if (W.onEvent) W.onEvent("mission", m);
}
function failMissionsFor(target){
  W.missions.forEach(m => { if (m.tpl.target === target && !m.done){ m.failed = true; } });
}

/* ═══ squads ═════════════════════════════════════════════════ */
const SQUAD_COLOURS = ["#D9A43F","#4E7FC8","#5F9159","#C8504A"];
function makeSquad(barracks){
  const idx = W.squads.length;
  const s = {id:nextId++, name:"Squad " + String.fromCharCode(65+idx), colour:SQUAD_COLOURS[idx % 4],
             units:[], banner:{x:barracks.x + 6, z:barracks.z + 6}, facing:0, engage:16, home:barracks,
             stance:"hold"};
  const mesh = E.makeBanner(s.colour);
  mesh.position.set(s.banner.x, 0, s.banner.z);
  mesh.userData.entity = s;
  E.scene.add(mesh);
  s.mesh = mesh;
  W.squads.push(s);
  W.pickables.push(mesh);
  log('<span class="t">▮</span> <b>' + s.name + '</b> mustered. Move its banner and it marches.');
  return s;
}
W.makeSquad = makeSquad;

function slotPos(s, i){
  const per = 4, row = Math.floor(i/per), col = i%per;
  const sp = 2.0;
  const lx = (col - (per-1)/2) * sp, lz = -row * sp;
  const c = Math.cos(s.facing), sn = Math.sin(s.facing);
  return {x:s.banner.x + lx*c - lz*sn, z:s.banner.z + lx*sn + lz*c};
}
function moveBanner(s, x, z){
  s.facing = Math.atan2(x - s.banner.x, z - s.banner.z);
  s.banner.x = x; s.banner.z = z;
  s.mesh.position.set(x, 0, z);
  s.units.forEach(u => u.state = "march");
}
W.moveBanner = moveBanner;

function trainSoldier(squad, cls){
  const def = DB.CLASSES[cls];
  if (def.needs && !has(def.needs)){
    log('<span class="r">!</span> A ' + DB.BUILDINGS[def.needs].label.toLowerCase() + ' is needed first.');
    return null;
  }
  if (!afford(def.trainCost)) { log('<span class="r">!</span> Not enough for a ' + def.label.toLowerCase() + '.'); return null; }
  pay(def.trainCost);
  const b = squad.home;
  const u = spawnUnit(cls, b.x + rnd(-3,3), b.z + rnd(-3,3), "player");
  u.squad = squad; u.slot = squad.units.length; u.state = "march";
  if (!def.siege){
    const ladder = DB.GEAR_LADDER.soldier;
    u.equip.weapon = ladder[0]; u.equip.armour = ladder[1];
    give(u, ladder[0]); give(u, ladder[1]);
  }
  give(u,"bread",2);
  squad.units.push(u);
  log('<b>' + u.name + '</b> joins ' + squad.name + ' as a ' + def.label.toLowerCase() + '.');
  return u;
}
W.trainSoldier = trainSoldier;

/* ═══ alignment ══════════════════════════════════════════════ */
function shiftAlign(d){
  W.align = clamp(W.align + d, -DB.ALIGNMENT.range, DB.ALIGNMENT.range);
  applyAlignmentVisual();
}
W.shiftAlign = shiftAlign;
function alignBand(){
  if (W.align > 25) return "good";
  if (W.align < -25) return "evil";
  return "neutral";
}
W.alignBand = alignBand;
function applyAlignmentVisual(){
  const band = alignBand(), A = DB.ALIGNMENT[band];
  W.buildings.filter(b => b.type === "temple").forEach(t => {
    const ud = t.mesh.userData;
    if (ud.alignParts) ud.alignParts.forEach(p => { p.material = E.mat(A.accent); });
    if (ud.floor) ud.floor.material = E.mat(A.colour);
    if (ud.halo){
      ud.halo.material.color.set(A.accent);
      // benevolence wears a wide bright halo; tyranny pulls it in tight and dim
      const f = (W.align + DB.ALIGNMENT.range) / (DB.ALIGNMENT.range*2);
      ud.halo.scale.setScalar(.55 + f*.9);
      ud.halo.material.opacity = .25 + f*.7;
    }
    if (ud.spire){
      // the spire rears up when good, hunches when evil
      const f = (W.align + DB.ALIGNMENT.range) / (DB.ALIGNMENT.range*2);
      ud.spire.scale.set(1, .5 + f*1.4, 1);
    }
    // the light it throws takes the same colour, and brightens with grace
    const f = (W.align + DB.ALIGNMENT.range) / (DB.ALIGNMENT.range*2);
    if (ud.glow){ ud.glow.color.set(A.accent); ud.glow.intensity = .7 + f*2.4; ud.glow.distance = 40 + f*44; }
    if (ud.floorGlow){ ud.floorGlow.color.set(A.colour); ud.floorGlow.intensity = .5 + f*1.5; }
    if (ud.beam){ ud.beam.material.color.set(A.accent); ud.beam.material.opacity = .06 + f*.22; }
  });
  if (W.creature){
    const c = W.creature.mesh.userData;
    if (c.collar) c.collar.material = E.mat(A.accent);
  }
}

/* ═══ spells ═════════════════════════════════════════════════ */
function castSpell(id, x, z){
  const sp = DB.SPELLS[id];
  if (!sp) return false;
  if (W.energy < sp.cost){ log('<span class="r">!</span> Not enough spell energy for ' + sp.label + '.'); return false; }
  W.energy -= sp.cost;
  shiftAlign(sp.align);
  const ring = E.makeRing(sp.colour, sp.radius);
  ring.position.set(x, .14, z);
  E.scene.add(ring);
  W.effects.push({mesh:ring, life:1.0, max:1.0, kind:"ring"});
  // a miracle is worth stopping work for
  amaze(x, z, sp.radius + 22, sp.colour, 2.8);

  const inR = ent => Math.hypot(ent.x-x, ent.z-z) <= sp.radius;
  const friends = W.units.filter(u => u.faction === "player" && u.hp > 0 && inR(u));
  const foes = W.units.filter(u => u.faction === "monster" && u.hp > 0 && inR(u));

  if (id === "heal"){
    friends.concat(W.creature && inR(W.creature) ? [W.creature] : []).forEach(u => {
      u.hp = Math.min(u.maxHp, u.hp + u.maxHp*.5);
      if (u.state === "down"){ u.state = "idle"; u.hp = u.maxHp*.6; }
    });
    log('<span class="v">✦</span> <b>Mend</b> — ' + friends.length + ' mended.');
  } else if (id === "bless"){
    W.buffs.quicken = sp.dur;
    log('<span class="v">✦</span> <b>Quicken</b> falls over the land.');
  } else if (id === "shield"){
    W.buffs.aegis = sp.dur;
    log('<span class="v">✦</span> <b>Aegis</b> — the realm takes half of what it is given.');
  } else if (id === "roots"){
    foes.forEach(f => { f.frozen = sp.dur; addRootCage(f, sp.dur); });
    log('<span class="v">✦</span> <b>Binding</b> — ' + foes.length + ' held fast.');
  } else if (id === "lightning"){
    const all = foes.concat(friends);
    all.forEach(u => dealDamage(null, u, sp.damage, true));
    const hitFolk = friends.filter(f => f.family === "folk").length;
    if (hitFolk) shiftAlign(DB.ALIGNMENT.deltas.lightningFolk);
    log('<span class="v">✦</span> <b>Levinbolt</b> — ' + all.length + ' struck' + (hitFolk ? ', <span class="r">' + hitFolk + ' of them yours</span>' : '') + '.');
  } else if (id === "firestorm"){
    W.effects.push({kind:"fire", x, z, r:sp.radius, life:sp.dur, max:sp.dur, dps:sp.damage, mesh:null});
    shiftAlign(DB.ALIGNMENT.deltas.burnLand);
    log('<span class="v">✦</span> <b>Firestorm</b> — the ground burns.');
  }
  witnessSpell(id, x, z);
  if (W.onEvent) W.onEvent("spell", sp);
  return true;
}

/* ── the creature learns by watching ─────────────────────────
   Every casting it can see counts. Easy miracles come after a handful
   of sightings; the destructive ones take many times more. Level sets
   the odds of it working, and level 10 makes it stronger besides. */
function spellWatchesFor(id, level){
  const L = DB.SPELL_LEARNING;
  const base = L.watchesForLevel[Math.max(0, Math.min(L.watchesForLevel.length-1, level))];
  const diff = L.difficulty[id] === undefined ? 1 : L.difficulty[id];
  return Math.ceil(base * diff);
}
W.spellWatchesFor = spellWatchesFor;

function witnessSpell(id, x, z){
  const c = W.creature;
  if (!c) return;
  if (Math.hypot(c.x - x, c.z - z) > 60) return;        // it has to be able to see it
  c.spellLore = c.spellLore || {};
  const lore = c.spellLore[id] = c.spellLore[id] || {watched:0, level:0};
  lore.watched++;
  const L = DB.SPELL_LEARNING;
  while (lore.level < L.maxLevel && lore.watched >= spellWatchesFor(id, lore.level)){
    lore.level++;
    const pct = Math.round(L.successByLevel[lore.level-1] * 100);
    log('<span class="v">✦</span> <b>' + c.name + '</b> learns <b>' + DB.SPELLS[id].label +
        '</b> to level ' + lore.level + ' — ' + pct + '% to get it right' +
        (lore.level >= L.maxLevel ? ', and far stronger for it' : '') + '.');
  }
}
W.witnessSpell = witnessSpell;

/* The creature trying a miracle of its own. */
W.creatureCast = function (id, x, z){
  const c = W.creature;
  if (!c || !c.spellLore || !c.spellLore[id]) return false;
  const lore = c.spellLore[id];
  if (lore.level < 1) return false;
  const L = DB.SPELL_LEARNING;
  const chance = L.successByLevel[Math.min(L.successByLevel.length-1, lore.level-1)];
  if (Math.random() > chance){
    c.lastThought = 0; c.thought = "That was meant to work.";
    log('<b>' + c.name + '</b> fumbles <b>' + DB.SPELLS[id].label + '</b>.');
    return false;
  }
  const sp = DB.SPELLS[id];
  const power = lore.level >= L.maxLevel ? L.masteryBonus : 1;
  const ring = E.makeRing(sp.colour, sp.radius * power);
  ring.position.set(x, .14, z);
  E.scene.add(ring);
  W.effects.push({mesh:ring, life:1, max:1, kind:"ring"});
  const inR = e => Math.hypot(e.x-x, e.z-z) <= sp.radius * power;
  if (id === "heal"){
    W.units.filter(u => u.faction === "player" && u.hp > 0 && inR(u))
           .forEach(u => u.hp = Math.min(u.maxHp, u.hp + u.maxHp*.5*power));
  } else if (id === "lightning" || id === "firestorm"){
    W.units.filter(u => u.faction === "monster" && u.hp > 0 && inR(u))
           .forEach(u => dealDamage(c, u, (sp.damage||30)*power, true));
  } else if (id === "roots"){
    W.units.filter(u => u.faction === "monster" && u.hp > 0 && inR(u))
           .forEach(u => { u.frozen = sp.dur*power; addRootCage(u, sp.dur*power); });
  } else if (id === "bless"){ W.buffs.quicken = sp.dur*power; }
  else if (id === "shield"){ W.buffs.aegis = sp.dur*power; }
  log('<b>' + c.name + '</b> works <b>' + sp.label + '</b> unaided' +
      (power > 1 ? ' — <span class="g">and it lands like a hammer</span>' : '') + '.');
  amaze(x, z, sp.radius + 24, sp.colour, 3);
  return true;
};
W.castSpell = castSpell;

function addRootCage(u, dur){
  const cage = E.makeRootCage();
  cage.position.set(u.x, 0, u.z);
  E.scene.add(cage);
  W.effects.push({mesh:cage, kind:"cage", follow:u, life:dur, max:dur});
}

/* ═══ awe ════════════════════════════════════════════════════
   Anything wondrous within earshot stops your folk where they stand.
   They turn to face the hand, motes rise off them, then they go back
   to whatever they were doing. */
function amaze(x, z, radius, colour, strength){
  const seen = W.units.filter(u =>
    (u.family === "folk" || u.family === "hero" || u.family === "soldier") &&
    u.hp > 0 && !u.heldBy && Math.hypot(u.x-x, u.z-z) < radius);
  seen.forEach(u => {
    if (u.awe > 0 || u.aweCd > 0) return;         // already gawping, or lately amazed
    u.awe = (strength || 2.2) * rnd(.8, 1.25);
    u.aweCd = u.awe + rnd(7, 14);
    const motes = E.makeAwe(colour);
    motes.position.set(u.x, (u.def.height || 1.6) * 1.05, u.z);
    E.scene.add(motes);
    W.effects.push({mesh:motes, kind:"awe", follow:u, life:u.awe, max:u.awe});
  });
  return seen.length;
}
W.amaze = amaze;

/* ═══ the hand ═══════════════════════════════════════════════ */
/* What the hand may pick up: trees, boulders, ore, people, monsters,
   beasts and carts. Never a building, a lair or the creature itself —
   a building has no flight tick, so lifting one used to strand it in
   mid-air with nothing to bring it down. */
/* Pull a bundle off one of the store's heaps: a carryable lump of the
   realm's own stock that can be dropped anywhere, including onto a
   half-built site to supply it. */
function grabFromPile(store, kind, amount){
  const have = W.res[kind] || 0;
  const take = Math.min(amount, Math.floor(have));
  if (take < 5) return null;
  W.res[kind] -= take;
  const bundleKind = kind === "wood" ? "tree" : kind === "stone" ? "rock" : "vein";
  const n = spawnNode(bundleKind, store.x, store.z);
  n.amount = take; n.max = take;
  n.yields = kind; n.isBundle = true; n.respawnTime = 0;
  n.label = take + " " + kind;
  log('<span class="t">▣</span> ' + take + ' ' + kind + ' pulled from the store.');
  return n;
}
W.grabFromPile = grabFromPile;

function grab(ent){
  if (!ent) return;
  if (ent === W.creature) return;
  if (ent.isLair) return;
  /* the store's heaps: grabbing one pulls a bundle out of the stockpile */
  if (isBuilding(ent) && ent.type === "store" && ent.built){
    const order = ["wood","stone","food"].filter(k => (W.res[k] || 0) >= 5);
    if (!order.length) return;
    const kind = order[(W.pileGrab = ((W.pileGrab || 0) + 1)) % order.length];
    const bundle = grabFromPile(ent, kind, 25);
    if (!bundle) return;
    W.held = bundle;
    bundle.heldBy = "hand";
    return;
  }
  if (isBuilding(ent)) return;
  if (ent.units && ent.banner) return;          // squad banners
  W.held = ent;
  ent.heldBy = "hand";
  if (ent.mesh) ent.mesh.userData.grabbed = true;
  if (ent.isNode) ent.thoughtless = true;
  if (ent.family === "folk") ent.thought = "Put me down!";
  if (ent.family === "beast") ent.spooked = 4;
}
const SNAP = 2;
const snapTo = v => Math.round(v/SNAP)*SNAP;

/* Which works are under this spot? A site short of timber wins over a
   merely damaged neighbour — otherwise a wall the site was placed
   against swallows the delivery. */
function worksUnder(ent, pad){
  const p = pad === undefined ? 2.5 : pad;
  const box = x => !x.enemy &&
    Math.abs(x.x-ent.x) < x.def.w/2 + p && Math.abs(x.z-ent.z) < x.def.d/2 + p;
  return nearest(ent, W.buildings, x => box(x) && !x.built && x.woodIn < x.woodNeed)
      || nearest(ent, W.buildings, x => box(x) && x.built && x.hp < x.maxHp)
      || null;
}

/* A node spent by being thrown into something useful. */
function consumeNode(n){
  n.amount = 0;
  n.respawn = n.kind === "tree" ? 70 : 0;
  if (n.mesh) n.mesh.visible = false;
}

/* Let go softly and it is set down on the grid where the hand was.
   Let go with the hand moving and it is thrown. */
const THROW_MIN = 2.2;          // world units/sec below which it is a drop

function release(vx, vz){
  const ent = W.held;
  if (!ent) return;
  W.held = null;
  ent.heldBy = null;
  const speed = Math.hypot(vx || 0, vz || 0);

  /* Hand still: let it go straight down from where it is. No arc, no
     sideways drift — it simply falls out of the hand. */
  if (speed < THROW_MIN){
    ent.flight = {vx:0, vy:0, vz:0, t:0, dropped:true};
    return;
  }

  /* Hand moving: it leaves along the cursor's own vector, at its speed. */
  ent.flight = {vx:vx, vy:Math.min(9, 1.6 + speed*.22), vz:vz, t:0};
  if (ent.family === "folk"){
    shiftAlign(DB.ALIGNMENT.deltas.tossVillager);
    ent.thought = "Aaaaah—";
  }
  amaze(ent.x, ent.z, 26, ent.isNode ? "#C8B45A" : "#E8D9A8", 2.4);
}

/* Put a held thing back on the ground, aligned to the same grid the
   buildings use so it lines up with everything else. */
/* Dropping something onto a building that wants it. Returns true if the
   building took it, in which case the thing is gone. */
function deliverToBuilding(ent){
  const b = nearest(ent, W.buildings, x =>
    x.built && !x.enemy &&
    Math.abs(x.x-ent.x) < x.def.w/2 + 2.5 && Math.abs(x.z-ent.z) < x.def.d/2 + 2.5);
  if (!b) return false;

  // resources into the village store
  if (ent.isNode && ent.amount > 0 && (b.type === "store" || b.type === "keep")){
    const kind = yieldOf(ent);
    const amount = Math.round(ent.amount);
    W.res[kind] = (W.res[kind] || 0) + amount;
    log('<span class="t">▣</span> ' + amount + ' ' + kind + ' added to the store.');
    amaze(b.x, b.z, 18, "#7FD8A0", 1.8);
    consumeNode(ent);
    return true;
  }
  // a villager laid on the temple floor becomes a worshipper
  if (ent.family === "folk" && b.type === "temple"){
    ent.job = "worshipper";
    ent.pinnedJob = true;
    ent.node = null; ent.site = null; ent.prey = null;
    ent.thought = "I will pray, then.";
    log('<b>' + ent.name + '</b> is given to the temple and becomes a <b>worshipper</b>.');
    amaze(b.x, b.z, 20, "#E0C060", 2.4);
    shiftAlign(1.5);
    return false;                    // they stay in the world, just re-tasked
  }
  return false;
}

function setDown(ent){
  ent.flight = null;
  ent.y = 0;
  if (deliverToBuilding(ent)) return;

  /* Timber set down onto the works is tipped straight in — supplying a
     site outright, or patching a building that has taken damage. */
  if (ent.isNode && yieldOf(ent) === "wood" && ent.amount > 0){
    const b = worksUnder(ent, 2.5);
    if (b && !b.built && b.woodIn < b.woodNeed){
      b.woodIn = b.woodNeed;
      log('<span class="t">⌂</span> Timber laid on the <b>' + b.def.label.toLowerCase() +
          '</b> site — fully supplied.');
      amaze(b.x, b.z, 22, "#7FD8A0", 2.2);
      consumeNode(ent);
      return;
    }
    if (b && b.built && b.hp < b.maxHp){
      b.hp = Math.min(b.maxHp, b.hp + b.maxHp*.45);
      log('<span class="t">⚒</span> Timber patches the <b>' + b.def.label.toLowerCase() + '</b>.');
      amaze(b.x, b.z, 20, "#7FD8A0", 2.0);
      consumeNode(ent);
      return;
    }
  }

  if (ent.isNode || ent.isFlag){ ent.x = snapTo(ent.x); ent.z = snapTo(ent.z); }
  if (ent.mesh) ent.mesh.position.set(ent.x, 0, ent.z);
  if (ent.family === "folk") ent.thought = "";
  if (ent.isFlag){
    ent.attachTo = null;
    W.units.forEach(u => { if (u.family === "hero") u.think = 0; });
    log('<span class="g">⚑</span> The <b>' + ent.def.label.toLowerCase() +
        ' flag</b> is planted at <span class="g">' + ent.price + 'g</span>.');
  }
}
W.setDown = setDown;
W.grab = grab; W.release = release;

function updateFlight(ent, dt){
  const f = ent.flight;
  f.t += dt;
  f.vy -= 22*dt;
  ent.x += f.vx*dt; ent.z += f.vz*dt;
  ent.y = (ent.y||0) + f.vy*dt;
  if (ent.y <= 0){
    ent.y = 0;
    const impact = Math.hypot(f.vx, f.vz) + Math.abs(f.vy);
    ent.flight = null;
    if (deliverToBuilding(ent)) return;
    if (ent.isNode){
      ent.x = snapTo(ent.x); ent.z = snapTo(ent.z);      // land on the grid
      // timber thrown onto the works supplies or mends them outright
      const isTimber = yieldOf(ent) === "wood";
      const site = worksUnder(ent, 5);
      if (isTimber && site && !site.built && site.woodIn < site.woodNeed){
        site.woodIn = site.woodNeed;
        log('<span class="t">⌂</span> Timber lands on the <b>' + site.def.label.toLowerCase() +
            '</b> site — fully supplied. Builders can raise it now.');
        amaze(site.x, site.z, 24, "#7FD8A0", 2.4);
        consumeNode(ent);
        return;
      }
      if (isTimber && site && site.built && site.hp < site.maxHp){
        site.hp = Math.min(site.maxHp, site.hp + site.maxHp*.45);
        log('<span class="t">⚒</span> Timber patches the <b>' + site.def.label.toLowerCase() + '</b>.');
        amaze(site.x, site.z, 22, "#7FD8A0", 2.0);
        consumeNode(ent);
        return;
      }
      if (!f.dropped){
        W.units.forEach(u => { if (d2(u,ent) < 4) dealDamage(null, u, impact*1.4, false); });
        log('<span class="r">☄</span> ' + (isTimber ? "A felled trunk" : "A boulder") +
            ' lands — ' + Math.round(impact) + ' force.');
        amaze(ent.x, ent.z, 24, "#C8B45A", 2.2);
      }
    } else if (ent.hp !== undefined && impact > 12 && !f.dropped){
      dealDamage(null, ent, (impact-10)*2.2, false);
    }
    if (ent.isFlag){
      ent.attachTo = null;
      W.units.forEach(u => { if (u.family === "hero") u.think = 0; });
    }
    if (ent.mesh) ent.mesh.position.set(ent.x, 0, ent.z);
  }
}

/* ═══ villager jobs ══════════════════════════════════════════ */
function villagerStep(u, dt){
  const job = u.job;
  const store = storeBuilding(u);

  if (job === "idle"){ wander(u, dt, W.villageCentre, 14); return; }

  if (job === "forester" || job === "miner" || job === "forager"){
    const wants = job === "forester" ? ["wood"] : job === "miner" ? ["stone","gold"] : ["food"];
    const skill = job === "forester" ? "woodcutting" : job === "miner" ? "mining" : "farming";
    const capacity = DB.TUNING.economy.depositAmount * (1 + tech("carry"));
    if (u.carry >= capacity){
      if (!store){ u.carry = 0; return; }
      if (moveTo(u, store.x, store.z, dt) < 3.2){
        W.res[u.carryType] += u.carry;
        if (W.onEvent) W.onEvent("deposit", {u, amount:u.carry, type:u.carryType});
        u.carry = 0; u.carryType = null;
      }
      return;
    }
    if (!u.node || u.node.amount <= 0) u.node = nearestYield(u, wants);
    if (!u.node){ wander(u, dt, W.villageCentre, 12); return; }
    if (moveTo(u, u.node.x, u.node.z, dt) < 2.2){
      const camp = nearestBuilding(u, b => b.type === (job === "forester" ? "lumber" : "mine"));
      const campBonus = (camp && d2(u,camp) < 30) ? camp.def.effect.gatherBonus * camp.tier : 0;
      const techBonus = job === "forester" ? tech("woodRate") : tech("oreRate");
      const L = lvl(u, skill) + toolBonus(u, skill);
      const rate = (1 + L*.05 + campBonus + techBonus) * (W.buffs.quicken > 0 ? 1.5 : 1);
      u.work = (u.work||0) + dt*rate;
      if (u.work >= DB.TUNING.economy.gatherTime){
        u.work = 0;
        const take = Math.min(4 + Math.floor(L/12), u.node.amount);
        u.node.amount -= take;
        u.carry = (u.carry||0) + take;
        u.carryType = yieldOf(u.node);
        addXp(u, skill, take*7);
        if (u.node.amount <= 0){
          u.node.respawn = u.node.respawnTime || (u.node.kind === "tree" ? 55 : 999);
          u.node.mesh.visible = false;
        }
      }
    }
    return;
  }

  if (job === "builder"){
    if (!u.site || !W.buildings.includes(u.site) || u.site.built){
      u.site = W.buildings.find(b => !b.built && !b.enemy) ||
               W.buildings.find(b => b.built && !b.enemy && b.hp < b.maxHp*.9) || null;
      if (!u.site) u.site = considerHouse(u);
    }
    if (!u.site){ wander(u, dt, W.villageCentre, 12); return; }
    const reach = Math.max(u.site.def.w, u.site.def.d)/2 + 1.8;

    /* A site short of timber is supplied first: fetch from the store,
       carry it over, tip it in. Then raise it. */
    if (!u.site.built && u.site.woodIn < u.site.woodNeed){
      if (u.hauling > 0){
        if (moveTo(u, u.site.x, u.site.z, dt) < reach){
          u.site.woodIn = Math.min(u.site.woodNeed, u.site.woodIn + u.hauling);
          u.hauling = 0;
        }
      } else {
        const src = store;
        if (!src) { wander(u, dt, W.villageCentre, 10); return; }
        if (moveTo(u, src.x, src.z, dt) < 3.4){
          const want = Math.min(15, u.site.woodNeed - u.site.woodIn);
          if (W.res.wood >= want){ W.res.wood -= want; u.hauling = want; }
          else { once("nowood", '<span class="r">!</span> No timber in the store for the works.'); }
        }
      }
      return;
    }

    if (moveTo(u, u.site.x, u.site.z, dt) < reach){
      const L = lvl(u,"construction") + toolBonus(u,"construction");
      const rate = DB.TUNING.economy.buildRate * (1 + L*.06 + tech("buildRate")) * (W.buffs.quicken > 0 ? 1.5 : 1);
      if (!u.site.built){
        u.site.prog += dt*rate;
        addXp(u,"construction", dt*rate*9);
        u.site.mesh.traverse(o => { if (o.material && o.material.transparent)
          o.material.opacity = .35 + .6*Math.min(1, u.site.prog/u.site.def.work); });
        if (u.site.prog >= u.site.def.work){ finishBuilding(u.site); u.site = null; }
      } else {
        u.site.hp = Math.min(u.site.maxHp, u.site.hp + 16*dt*rate);
        addXp(u,"construction", dt*rate*4);
        if (u.site.hp >= u.site.maxHp) u.site = null;
      }
    }
    return;
  }

  if (job === "artisan"){
    if (!u.shop || W.buildings.indexOf(u.shop) < 0 || !u.shop.built ||
        !(u.shop.def.effect && u.shop.def.effect.converts)){
      u.shop = nearestBuilding(u, b => b.def.effect && b.def.effect.converts);
    }
    if (!u.shop){ wander(u, dt, W.villageCentre, 12); return; }
    if (moveTo(u, u.shop.x, u.shop.z, dt) < Math.max(u.shop.def.w, u.shop.def.d)*.7){
      addXp(u, "smithing", dt*7);
    }
    return;
  }

  if (job === "worshipper"){
    const temple = nearestBuilding(u, b => b.type === "temple");
    if (!temple){ u.job = "idle"; return; }
    const a = (u.id % 8) / 8 * 6.28;
    const r = temple.def.w * .42;
    if (moveTo(u, temple.x + Math.cos(a)*r, temple.z + Math.sin(a)*r, dt, .8) < 2.5){
      const L = lvl(u,"prayer");
      // bound worshippers give roughly double what a wandering acolyte does
      const gain = temple.def.effect.prayerRate * temple.tier * 2 * (1 + L*.05 + tech("prayerRate")) * dt;
      W.energy = Math.min(energyCap(), W.energy + gain);
      addXp(u, "prayer", dt*12);
      shiftAlign(DB.ALIGNMENT.deltas.prayerTick * dt * 2);
      u.praying = true;
    }
    return;
  }

  if (job === "acolyte"){
    const temple = nearestBuilding(u, b => b.type === "temple");
    if (!temple){ wander(u, dt, W.villageCentre, 12); return; }
    if (moveTo(u, temple.x, temple.z + temple.def.d*.7, dt) < 3.5){
      const L = lvl(u,"prayer");
      const gain = temple.def.effect.prayerRate * temple.tier * (1 + L*.045 + tech("prayerRate")) * dt;
      W.energy = Math.min(energyCap(), W.energy + gain);
      addXp(u,"prayer", dt*7);
      shiftAlign(DB.ALIGNMENT.deltas.prayerTick*dt);
      u.praying = true;
    } else u.praying = false;
    return;
  }

  if (job === "hunter"){
    u.atkCd = (u.atkCd || 0) - dt;
    if (u.carry >= 1){
      const drop = nearestBuilding(u, b => b.type === "mill") || store;
      if (!drop){ u.carry = 0; return; }
      if (moveTo(u, drop.x, drop.z, dt) < 3.4){ W.res.food += u.carry; u.carry = 0; }
      return;
    }
    if (!u.prey || u.prey.hp <= 0 || W.units.indexOf(u.prey) < 0)
      u.prey = nearest(u, W.units, x => x.family === "beast" && x.hp > 0);
    if (!u.prey){ wander(u, dt, W.villageCentre, 16); return; }
    if (moveTo(u, u.prey.x, u.prey.z, dt, 1.05) < 2.2 && u.atkCd <= 0){
      u.atkCd = 1.1;
      const power = 6 + lvl(u,"ranged")*.9;
      u.prey.hp -= power;
      addXp(u, "ranged", power*3);
      if (u.prey.hp <= 0){
        u.carry = u.prey.def.food;
        addXp(u, "farming", u.prey.def.food*4);
        log('<b>' + u.name + '</b> brings down a ' + u.prey.def.label.toLowerCase() + '.');
        removeUnit(u.prey);
        u.prey = null;
      }
    }
    return;
  }

  if (job === "farmer"){
    const farm = nearestBuilding(u, b => b.type === "farm");
    if (!farm){ wander(u, dt, W.villageCentre, 12); return; }
    if (moveTo(u, farm.x + rnd(-2,2), farm.z + rnd(-2,2), dt) < 4){
      const L = lvl(u,"farming");
      W.res.food += farm.def.effect.foodRate * farm.tier * (1 + L*.04) * dt * .5;
      addXp(u,"farming", dt*6);
    }
    return;
  }
  wander(u, dt, W.villageCentre, 12);
}
function energyCap(){
  const t = W.buildings.find(b => b.type === "temple" && b.built);
  let cap = t ? t.def.effect.energyCap * t.tier : 60;
  // anything at all that declares an energyBonus raises the ceiling
  W.buildings.forEach(b => {
    if (b.built && !b.enemy && b.def.effect && b.def.effect.energyBonus)
      cap += b.def.effect.energyBonus * b.tier;
  });
  return cap;
}
W.energyCap = energyCap;

function considerHouse(u){
  if (W.units.filter(x => x.family === "folk").length < popCap() - 1) return null;
  if (W.res.wood < DB.BUILDINGS.house.cost.wood + 40) return null;
  for (let i = 0; i < 26; i++){
    const a = rnd(0,6.28), r = rnd(10, 34);
    const x = W.villageCentre.x + Math.cos(a)*r, z = W.villageCentre.z + Math.sin(a)*r;
    if (x > 10) continue;
    const clear = W.buildings.every(b => Math.hypot(b.x-x, b.z-z) > (b.def.civic ? 8 : 6.5)) &&
                  W.nodes.every(n => n.amount <= 0 || Math.hypot(n.x-x, n.z-z) > 3.2);
    if (clear){
      pay(DB.BUILDINGS.house.cost);
      const b = placeBuilding("house", x, z);
      log('<b>' + u.name + '</b> sites a house out past the works.');
      return b;
    }
  }
  return null;
}

function wander(u, dt, centre, radius){
  if (!u.wx || Math.hypot(u.x-u.wx, u.z-u.wz) < 1.2 || (u.wanderT -= dt) <= 0){
    const a = rnd(0,6.28), r = Math.sqrt(Math.random())*radius;
    u.wx = centre.x + Math.cos(a)*r; u.wz = centre.z + Math.sin(a)*r;
    u.wanderT = rnd(4,9);
  }
  moveTo(u, u.wx, u.wz, dt, .45);
}

/* ═══ wildlife ═══════════════════════════════════════════════ */
function beastStep(u, dt){
  const d = u.def;
  // anything armed and close enough sends them running
  const threat = W.units.filter(x => (x.faction === "monster" || x.job === "hunter" || x.family === "hero")
                                     && x.hp > 0 && d2(x,u) < d.skittish)
                        .sort((a,b) => d2(a,u) - d2(b,u))[0]
              || (W.creature && d2(W.creature,u) < d.skittish + 6 ? W.creature : null);
  if (threat){
    u.spooked = 2.2;
    const ax = u.x - threat.x, az = u.z - threat.z, m = Math.hypot(ax,az) || 1;
    moveTo(u, u.x + ax/m*14, u.z + az/m*14, dt, 1);
    return;
  }
  if (u.spooked > 0) u.spooked -= dt;
  // flocking: sheep drift back toward the herd anchor and toward each other
  if (d.herds && u.anchor){
    const kin = W.units.filter(x => x.cls === u.cls && x !== u && d2(x,u) < 12);
    let cx = u.anchor.x, cz = u.anchor.z;
    if (kin.length){
      cx = kin.reduce((s,k) => s+k.x, 0)/kin.length*.6 + u.anchor.x*.4;
      cz = kin.reduce((s,k) => s+k.z, 0)/kin.length*.6 + u.anchor.z*.4;
    }
    if (!u.wx || Math.hypot(u.x-u.wx, u.z-u.wz) < 1 || (u.wanderT -= dt) <= 0){
      u.wx = cx + rnd(-5,5); u.wz = cz + rnd(-5,5); u.wanderT = rnd(3,8);
    }
    moveTo(u, u.wx, u.wz, dt, .34);
    return;
  }
  wander(u, dt, u.anchor || {x:u.x, z:u.z}, 16);
}

/* ═══ hero AI ════════════════════════════════════════════════ */
function heroStep(u, dt){
  if (u.state === "down"){
    u.downT -= dt;
    if (u.downT <= 0){
      const h = u.homeBuilding || W.buildings.find(b => b.type === "keep");
      u.x = h.x; u.z = h.z; u.hp = u.maxHp*.6; u.state = "idle";
      log('<b>' + u.name + '</b> is back on their feet.');
    }
    return;
  }
  u.think -= dt; u.atkCd -= dt;

  const courage = u.courage + (W.buffs.aegis > 0 ? .3 : 0);
  if (u.hp < u.maxHp*DB.TUNING.combat.fleeThreshold && u.state !== "flee"){
    u.state = "flee"; u.flag = null;
    if (Math.random() < .4) log('<b>' + u.name + '</b> breaks off — <span class="r">"no coin is worth this."</span>');
  }

  // druids mend allies whenever something needs it
  if (u.cls === "druid" && u.atkCd <= 0){
    const hurt = W.units.filter(x => x.faction === "player" && x.hp > 0 && x.hp < x.maxHp*.7 && d2(x,u) < u.def.healRange)
                        .sort((a,b) => (a.hp/a.maxHp) - (b.hp/b.maxHp))[0];
    if (hurt){
      const amt = u.def.healPower * (1 + lvl(u,"herblore")*.05);
      hurt.hp = Math.min(hurt.maxHp, hurt.hp + amt);
      addXp(u,"herblore", amt*DB.TUNING.combat.xpPerHeal);
      addXp(u,"magic", amt);
      u.atkCd = u.def.attackSpeed;
      shiftAlign(.05);
      const ring = E.makeRing("#5F9159", 1.4);
      ring.position.set(hurt.x, .3, hurt.z);
      E.scene.add(ring);
      W.effects.push({mesh:ring, life:.5, max:.5, kind:"ring"});
      return;
    }
  }

  switch (u.state){
    case "idle": {
      const mk = W.buildings.find(b => b.type === "market" && b.built);
      const ladder = DB.GEAR_LADDER[u.cls] || [];
      if (mk && u.gearStep < Math.min(ladder.length, mk.def.effect.gearTier * mk.tier)){
        const item = DB.ITEMS[ladder[u.gearStep]];
        if (item && u.gold >= item.value){ u.state = "shop"; u.dest = mk; u.buying = ladder[u.gearStep]; break; }
      }
      const tv = W.buildings.find(b => b.type === "tavern" && b.built);
      if (tv && u.gold > 90 && Math.random() < dt*.3){ u.state = "shop"; u.dest = tv; u.buying = null; break; }

      if (u.think <= 0){
        let bestFlag = null, bestScore = 18;
        W.flagList.forEach(f => {
          if (f.hidden) return;                       // a hidden flag is not on offer
          if (u.def.noDefend && f.kind === "defend") return;   // barbarians will not stand a line
          const s = appraise(u, f);
          if (s > bestScore){ bestScore = s; bestFlag = f; }
        });
        if (bestFlag){
          u.flagRef = bestFlag; u.flag = bestFlag.kind; u.state = "onflag";
          if (Math.random() < .3){
            const line = bestFlag.price === 0 ? "duty alone, then" :
              (u.gold < 50 ? "I need that " + bestFlag.price + "g" : bestFlag.price + "g will do");
            log('<b>' + u.name + '</b> takes <b>' + bestFlag.label + '</b> — <span class="g">"' + line + '."</span>');
          }
          break;
        }
        u.think = rnd(2.5, 5);
        if (Math.random() < .12 && W.flagList.length){
          const why = u.owed > 20 ? "pay the " + Math.round(u.owed) + "g you owe me first"
            : (u.gold > 140 ? "I'm carrying " + u.gold + "g already"
            : (courage < .55 ? "not for that price" : "raise it and I'll think again"));
          log('<b>' + u.name + '</b> stays put — <span class="r">"' + why + '."</span>');
        }
      }
      const near = nearestEnemy(u, 16);
      if (near && (u.duty > .5 || courage > .85)){ u.state = "fight"; u.target = near; break; }
      const home = u.homeBuilding || W.buildings.find(b => b.type === "keep");
      wander(u, dt, home, 10);
      break;
    }

    case "shop": {
      const d = u.dest;
      if (!d || !d.built){ u.state = "idle"; break; }
      if (moveTo(u, d.x, d.z, dt, .9) < 3.4){
        if (u.buying){
          const item = DB.ITEMS[u.buying];
          u.gold -= item.value;
          give(u, u.buying);
          if (item.kind === "weapon") u.equip.weapon = u.buying;
          if (item.kind === "armour") u.equip.armour = u.buying;
          u.gearStep++;
          const tax = Math.round(item.value * d.def.effect.taxRate * (1 + (d.tier-1)*.2));
          W.res.gold += tax;
          addXp(u,"smithing", item.value*.4);
          log('<b>' + u.name + '</b> buys <span class="g">' + item.label + '</span> for ' + item.value +
              'g — <span class="t">' + tax + 'g</span> in tax.');
        } else {
          const spent = Math.round(u.gold * rnd(.25,.5));
          u.gold -= spent;
          const tax = Math.round(spent * d.def.effect.taxRate * (1 + (d.tier-1)*.2));
          W.res.gold += tax;
          u.hp = Math.min(u.maxHp, u.hp + u.maxHp*.3);
          log('<b>' + u.name + '</b> spends ' + spent + 'g at the tavern — <span class="t">' + tax + 'g</span> in tax.');
        }
        u.state = "idle"; u.think = rnd(1,3);
      }
      break;
    }

    case "onflag": {
      const f = u.flagRef;
      if (!f || W.flagList.indexOf(f) < 0 || f.hidden){ u.flagRef = null; u.flag = null; u.state = "return"; break; }
      const fx = f.attachTo ? f.attachTo.x : f.x, fz = f.attachTo ? f.attachTo.z : f.z;

      if (f.kind === "attack"){
        const foe = nearestEnemy(u, 22);
        if (foe){ u.target = foe; u.state = "fight"; break; }
        // nothing left alive: knock the spawn point itself down
        const lair = nearest(u, W.lairs || [], l => !l.dead && Math.hypot(l.x-fx, l.z-fz) < 18);
        if (lair){
          if (moveTo(u, lair.x, lair.z, dt) < u.def.attackRange + 2 && u.atkCd <= 0){
            u.atkCd = u.def.attackSpeed;
            damageLair(lair, attackPower(u), u);
          }
          break;
        }
        if (moveTo(u, fx, fz, dt) < 4){ u.holdT = (u.holdT||0) + dt; if (u.holdT > 5){ u.holdT = 0; u.state = "return"; } }
      }
      else if (f.kind === "defend"){
        const foe = nearestEnemy(u, 16);
        if (foe && d2(foe, f) < 20){ u.target = foe; u.state = "fight"; break; }
        if (moveTo(u, fx + Math.sin(u.id)*3, fz + Math.cos(u.id)*3, dt, .8) < 4){
          f.held += dt;
          u.retainer = (u.retainer||0) + dt;
          if (u.retainer >= 5){
            u.retainer = 0;
            const p = Math.min(f.price, W.res.gold);
            W.res.gold -= p; u.gold += p;
            if (p < f.price) u.owed += f.price - p;
          }
        }
      }
      else { // follow — a cart, a villager, or the creature
        const c = f.attachTo;
        if (!c || (c.hp !== undefined && c.hp <= 0)){ u.state = "return"; break; }
        const foe = nearestEnemy(u, 18);
        if (foe && d2(foe, c) < 20){ u.target = foe; u.state = "fight"; break; }
        const a = (u.id % 6) / 6 * 6.28;
        const ring = (c.def && c.def.radius ? c.def.radius : 1) + 3.5;
        if (moveTo(u, c.x + Math.cos(a)*ring, c.z + Math.sin(a)*ring, dt, .95) < ring + 2){
          u.retainer = (u.retainer||0) + dt;
          if (u.retainer >= 5){
            u.retainer = 0;
            const p = Math.min(f.price, W.res.gold);
            W.res.gold -= p; u.gold += p;
            if (p < f.price) u.owed += f.price - p;
          }
        }
      }
      break;
    }

    case "fight": {
      const t = u.target;
      if (!t || t.hp <= 0){ u.target = null; u.state = u.flag ? "onflag" : "idle"; break; }
      const range = u.def.attackRange;
      const d = d2(u, t);
      if (d > range) moveTo(u, t.x, t.z, dt);
      else if (u.atkCd <= 0){
        u.atkCd = u.def.attackSpeed;
        u.facing = Math.atan2(t.x-u.x, t.z-u.z);
        if (u.def.projectile){
          fireProjectile(u, t, u.def.projectile);
          if (u.cls === "druid"){ t.frozen = u.def.rootDuration; addRootCage(t, u.def.rootDuration); }
        } else dealDamage(u, t, attackPower(u), false);
      }
      break;
    }

    case "flee": {
      const h = u.homeBuilding || W.buildings.find(b => b.type === "keep");
      if (moveTo(u, h.x, h.z, dt, 1.2) < 4){
        u.hp = Math.min(u.maxHp, u.hp + u.maxHp*.2*dt);
        if (u.hp > u.maxHp*.92){ u.state = "idle"; u.think = rnd(3,6); }
      }
      break;
    }
    case "return": {
      const h = u.homeBuilding || W.buildings.find(b => b.type === "keep");
      if (moveTo(u, h.x, h.z, dt, .85) < 4){ u.state = "idle"; u.think = rnd(.5,2); u.flag = null; }
      break;
    }
  }
}

/* ═══ soldier AI ═════════════════════════════════════════════ */
function soldierStep(u, dt){
  u.atkCd -= dt;
  const s = u.squad;
  if (!s){ wander(u, dt, W.villageCentre, 8); return; }
  const slot = slotPos(s, u.slot >= 0 ? u.slot : s.units.indexOf(u));

  let foe = nearestEnemy(u, s.engage);
  const foeNearBanner = nearestEnemy(s, s.engage + 6);
  // rams ignore anything that can step aside — they want stonework and lairs
  if (u.def.siege){
    const structures = W.buildings.filter(b => b.enemy && b.built).concat(W.lairs || []);
    const target = nearest(s, structures, b => d2(s, b) < s.engage + 14);
    foe = target || null;
  }
  const engage = foe || (u.def.siege ? null : foeNearBanner);

  if (engage && engage.hp > 0){
    u.state = "swarm"; u.target = engage;
    const range = u.def.attackRange, d = d2(u, engage);
    if (d > range) moveTo(u, engage.x, engage.z, dt);
    else if (u.atkCd <= 0){
      u.atkCd = u.def.attackSpeed;
      u.facing = Math.atan2(engage.x-u.x, engage.z-u.z);
      if (u.def.projectile) fireProjectile(u, engage, u.def.projectile);
      else dealDamage(u, engage, attackPower(u), false);
    }
    return;
  }
  // no enemy: march back into formation and hold
  const d = moveTo(u, slot.x, slot.z, dt, u.state === "march" ? 1 : .8);
  u.state = d < 1.2 ? "hold" : "march";
  if (u.state === "hold") u.facing = s.facing;
}

/* ═══ monster AI ═════════════════════════════════════════════ */
function monsterStep(u, dt){
  u.atkCd -= dt;
  if (u.frozen > 0) { u.frozen -= dt; return; }
  const keep = W.buildings.find(b => b.type === "keep");
  const prey = nearestEnemy(u, 24, "monster");
  const tgt = prey || keep;
  if (!tgt) return;
  const range = u.def.attackRange;
  const d = d2(u, tgt);
  if (d > range) moveTo(u, tgt.x, tgt.z, dt);
  else if (u.atkCd <= 0){
    u.atkCd = u.def.attackSpeed;
    u.facing = Math.atan2(tgt.x-u.x, tgt.z-u.z);
    if (u.def.projectile) fireProjectile(u, tgt, u.def.projectile);
    else if (tgt.hp !== undefined) dealDamage(u, tgt, attackPower(u), false);
  }
  // chew through walls when the line stops them
  if (u.stuck > .4){
    const w = wallAhead(u);
    if (w && u.atkCd <= 0){
      u.atkCd = 1.0;
      w.hp -= attackPower(u)*1.7;
      if (w.hp <= 0){
        log('<span class="r">✕</span> A ' + w.def.label.toLowerCase() + ' section is torn down.');
        removeBuilding(w);
      }
    }
    u.stuck = 0;
  }
}

/* ═══ creature ═══════════════════════════════════════════════ */
function think(c, bucket){
  const list = DB.CREATURE.thoughts[bucket];
  if (!list) return;
  if (W.time - (c.lastThought||0) < 3.5) return;
  c.lastThought = W.time;
  c.thought = pick(list);
}
/* It grows on what it eats and what it kills. Girth drives the mesh
   scale, its reach, its damage and how much punishment it can take. */
function growCreature(c, amount){
  c.fed = (c.fed || 0) + amount;
  const combat = (lvl(c,"attack") + lvl(c,"strength") + lvl(c,"hitpoints")) / 3;
  const target = 1 + Math.min(1.4, c.fed/900) + Math.min(.6, Math.max(0, combat - 34)/60);
  if (Math.abs(target - c.girth) < .001) return;
  c.girth = target;
  const cd = DB.CREATURES[c.kind];
  c.mesh.scale.setScalar(c.girth);
  c.def.height = cd.height * c.girth;
  c.def.radius = cd.radius * c.girth;
  c.def.attackRange = cd.attackRange * (1 + (c.girth-1)*.7);
  c.def.damage = cd.damage * (1 + (c.girth-1)*1.1);
  const newMax = cd.hp * (1 + (c.girth-1)*1.3);
  const frac = c.hp / c.maxHp;
  c.maxHp = newMax; c.hp = newMax * frac;
}
W.growCreature = growCreature;

function creatureStep(c, dt){
  c.atkCd -= dt;
  c.hunger = Math.min(100, c.hunger + (c.hungerRate || DB.CREATURE.hungerRate)*dt);
  if (c.regen) c.hp = Math.min(c.maxHp, c.hp + c.regen*dt);
  growCreature(c, 0);                       // keep girth in step with its levels

  if (c.petting > 0){ c.petting -= dt; think(c,"petted"); }

  if (W.leash.attached === c){
    const hand = W.hand.position;
    const d = Math.hypot(hand.x - c.x, hand.z - c.z);
    if (d > DB.CREATURE.leashPull){
      moveTo(c, hand.x, hand.z, dt, 1.15);
      think(c,"leashed");
    } else {
      const foe = nearestEnemy(c, 18);
      if (foe) fightAs(c, foe, dt);
      else idleCreature(c, dt, {x:hand.x, z:hand.z}, 7);
    }
    return;
  }
  const foe = nearestEnemy(c, 22);
  if (foe){ fightAs(c, foe, dt); return; }
  if (c.hunger > 70){
    think(c,"hungry");
    const folk = W.units.filter(u => u.family === "folk" && d2(u,c) < 26)
                        .sort((a,b) => d2(a,c) - d2(b,c))[0];
    if (folk && alignBand() === "evil"){
      if (moveTo(c, folk.x, folk.z, dt) < 3){
        onDeath(folk, c);
        c.hunger = 0;
        growCreature(c, 90);
        log('<span class="r">☠</span> ' + c.name + ' eats <b>' + folk.name + '</b> and swells.');
      }
      return;
    }
    // failing that, graze on the herds
    const beast = nearest(c, W.units, u => u.family === "beast" && u.hp > 0 && d2(u,c) < 40);
    if (beast){
      if (moveTo(c, beast.x, beast.z, dt) < c.def.attackRange){
        growCreature(c, beast.def.food * 1.6);
        c.hunger = 0;
        log('<b>' + c.name + '</b> eats a ' + beast.def.label.toLowerCase() + '.');
        removeUnit(beast);
      }
      return;
    }
    if (W.res.food > 10){
      W.res.food -= 10; c.hunger = 0; c.thought = "That will do.";
      growCreature(c, 26);
    }
  }
  idleCreature(c, dt, W.villageCentre, DB.CREATURE.wanderRadius);
}
function fightAs(c, foe, dt){
  think(c,"fighting");
  const d = d2(c, foe);
  if (d > c.def.attackRange) moveTo(c, foe.x, foe.z, dt);
  else if (c.atkCd <= 0){
    c.atkCd = c.def.attackSpeed;
    c.facing = Math.atan2(foe.x-c.x, foe.z-c.z);
    dealDamage(c, foe, attackPower(c), false);
  }
}
function idleCreature(c, dt, centre, radius){
  think(c,"idle");
  if (!c.tx || Math.hypot(c.x-c.tx, c.z-c.tz) < 2 || (c.wanderT -= dt) <= 0){
    const a = rnd(0,6.28), r = Math.sqrt(Math.random())*radius;
    c.tx = centre.x + Math.cos(a)*r; c.tz = centre.z + Math.sin(a)*r;
    c.wanderT = rnd(5,11);
  }
  moveTo(c, c.tx, c.tz, dt, .5);
}
function creatureFeedback(c, colour, text){
  const ring = E.makeRing(colour, c.def.radius*1.6);
  ring.position.set(c.x, .2, c.z);
  E.scene.add(ring);
  W.effects.push({mesh:ring, life:.7, max:.7, kind:"ring"});
  const motes = E.makeAwe(colour);
  motes.position.set(c.x, c.def.height*.95, c.z);
  E.scene.add(motes);
  W.effects.push({mesh:motes, kind:"awe", follow:c, life:1.4, max:1.4});
  if (text) log(text);
}
W.petCreature = function (){
  const c = W.creature;
  if (!c) return;
  c.petting = 2.5; c.mood = clamp(c.mood + 6, -100, 100);
  think(c,"petted"); c.lastThought = 0;
  shiftAlign(.4);
  creatureFeedback(c, "#7FD8A0", '<span class="t">♥</span> You stroke <b>' + c.name +
    '</b> — <span class="v">"' + c.thought + '"</span>');
  amaze(c.x, c.z, 18, "#7FD8A0", 1.6);
};
W.slapCreature = function (){
  const c = W.creature;
  if (!c) return;
  c.mood = clamp(c.mood - 12, -100, 100);
  c.hp = Math.max(1, c.hp - 8);
  c.lastThought = 0; think(c,"slapped");
  shiftAlign(-1.2);
  creatureFeedback(c, "#C8504A", '<span class="r">✋</span> You strike <b>' + c.name +
    '</b> — <span class="v">"' + c.thought + '"</span>');
  amaze(c.x, c.z, 22, "#C8504A", 2.0);
};
W.hugCreature = function (){
  const c = W.creature;
  if (!c) return;
  c.mood = clamp(c.mood + 14, -100, 100);
  c.hp = Math.min(c.maxHp, c.hp + c.maxHp*.06);
  c.lastThought = 0; think(c,"hugged");
  shiftAlign(1.2);
  creatureFeedback(c, "#E8C46A", '<span class="g">◎</span> You hold <b>' + c.name +
    '</b> close — <span class="v">"' + c.thought + '"</span>');
  amaze(c.x, c.z, 20, "#E8C46A", 2.2);
};

/* ═══ lairs / spawning ═══════════════════════════════════════ */
/* A lair can be beaten down. What happens next is set in DB.THREATS:
   it comes back where it was, somewhere new, or not at all. */
function damageLair(lair, amount, killer){
  if (!lair || lair.dead) return;
  lair.hp -= amount;
  if (lair.hp > 0) return;
  lair.hp = 0;
  lair.dead = true;
  lair.mesh.visible = false;
  lair.respawnIn = DB.THREATS.respawnMode === "never" ? -1 : DB.THREATS.respawnDelaySeconds;
  log('<span class="t">★</span> <b>' + lair.label + '</b> is torn down' +
      (killer && killer.name ? ' by <b>' + killer.name + '</b>' : '') + '.');
  amaze(lair.x, lair.z, 40, "#D9A43F", 3);
  if (W.onEvent) W.onEvent("lairDown", lair);
}
W.damageLair = damageLair;

function lairStep(dt){
  if (!DB.THREATS.enabled) return;
  const total = W.units.filter(u => u.faction === "monster").length;
  (W.lairs||[]).forEach(l => {
    if (l.dead){
      if (l.respawnIn < 0) return;                    // "never"
      l.respawnIn -= dt;
      if (l.respawnIn > 0) return;
      if (DB.THREATS.respawnMode === "new"){
        const r = DB.THREATS.wanderRadius;
        const lim = DB.TUNING.world.size/2 - 10;
        l.x = clamp(l.x + rnd(-r, r), 20, lim);
        l.z = clamp(l.z + rnd(-r, r), -lim, lim);
        l.mesh.position.set(l.x, 0, l.z);
      }
      l.dead = false; l.hp = l.maxHp; l.alive = 0;
      l.mesh.visible = true;
      log('<span class="r">▲</span> <b>' + l.label + '</b> stirs again.');
      return;
    }
    l.timer -= dt;
    if (l.timer > 0) return;
    const escalation = 1 - Math.min(.65, (W.time/60) * DB.THREATS.escalatePerMinute);
    const modeMul = W.gameMode === "siege" ? .5 : 1;
    l.timer = l.every * Math.max(.3, escalation) * modeMul * (1 + Math.random()*.3);
    if (l.alive >= l.cap || total >= DB.TUNING.lairs.maxAlive) return;
    const u = spawnUnit(l.kind, l.x + rnd(-3,3), l.z + rnd(-3,3), "monster");
    u.lair = l; l.alive++;
  });
}

/* ═══ the clock ══════════════════════════════════════════════
   Real seconds → in-world hours → days → years, all set in DB.TIME.
   Everyone carries their own lifespan and dies when they reach it. */
function worldDays(){
  const T = DB.TIME;
  const hours = W.time / Math.max(.05, T.secondsPerHour);
  return hours / Math.max(1, T.hoursPerDay);
}
W.worldDays = worldDays;
function worldYears(){ return worldDays() / Math.max(1, DB.TIME.daysPerYear); }
W.worldYears = worldYears;
function ageOf(u){ return (u.birthAgeYears || 0) + (worldYears() - (u.bornYear || 0)); }
W.ageOf = ageOf;

function clockStep(dt){
  const T = DB.TIME;
  const d = worldDays();
  W.clock.day = Math.floor(d % Math.max(1, T.daysPerYear));
  W.clock.year = Math.floor(d / Math.max(1, T.daysPerYear));
  W.clock.hour = Math.floor((W.time / Math.max(.05, T.secondsPerHour)) % Math.max(1, T.hoursPerDay));

  W.ageT = (W.ageT || 0) - dt;
  if (W.ageT > 0) return;
  W.ageT = 2;
  for (let i = W.units.length - 1; i >= 0; i--){
    const u = W.units[i];
    if (u.family !== "folk" || u.hp <= 0) continue;
    if (ageOf(u) >= u.lifespan){
      log('<b>' + u.name + '</b> dies of old age at ' + Math.floor(u.lifespan) + '.');
      removeUnit(u);
    }
  }
}

/* ── breeding ────────────────────────────────────────────────
   Breeders raise families. They will exceed the housing if there is
   timber for another house, so the village keeps growing. */
function breedStep(dt){
  const T = DB.TIME;
  W.breedT = (W.breedT || 0) - dt;
  if (W.breedT > 0) return;
  W.breedT = 3;

  const breeders = W.units.filter(u =>
    u.family === "folk" && u.hp > 0 && u.job === "breeder" &&
    ageOf(u) >= T.breedingMinAge && ageOf(u) <= T.breedingMaxAge);
  if (breeders.length < 1) return;

  const dayNow = worldDays();
  breeders.forEach(p => {
    if (p.nextChildDay === undefined) p.nextChildDay = dayNow + T.breedingCooldownDays * rnd(.5, 1);
    if (dayNow < p.nextChildDay) return;

    const skill = lvl(p, "breeding");
    // a creche nearby, and a town worth living in, both shorten the wait
    let ease = 1 - skill*.04;
    const creche = nearestBuilding(p, b => b.def.effect && b.def.effect.breedBonus);
    if (creche && d2(p, creche) < 30) ease *= 1 - creche.def.effect.breedBonus;
    ease /= Math.max(.5, W.appealFactor());
    p.nextChildDay = dayNow + Math.max(20, T.breedingCooldownDays * ease) * rnd(.8, 1.2);

    // room is made, not waited for: raise a house if the cap is reached
    if (W.units.filter(u => u.family === "folk").length >= popCap()){
      if (W.res.wood >= DB.BUILDINGS.house.cost.wood + 20){
        const made = considerHouseAt(p);
        if (!made) return;                       // nowhere to put one — no child yet
      } else return;                             // no timber, no room, no child
    }
    const twins = Math.random() < Math.min(.25, skill * .012) ? 2 : 1;
    for (let i = 0; i < twins; i++){
      const kid = spawnUnit("villager", p.x + rnd(-2,2), p.z + rnd(-2,2), "player");
      kid.birthAgeYears = 0;
      kid.bornYear = worldYears();
      kid.lifespan = rnd(DB.TIME.lifespanMin, DB.TIME.lifespanMax);
      kid.job = "idle";
      addXp(p, "breeding", 220);
    }
    log('<b>' + p.name + '</b> raises ' + (twins > 1 ? twins + ' children' : 'a child') + '.');
  });
}

/* A house sited near a given villager, used by breeding. */
function considerHouseAt(u){
  for (let i = 0; i < 30; i++){
    const a = rnd(0,6.28), r = rnd(8, 38);
    const x = W.villageCentre.x + Math.cos(a)*r, z = W.villageCentre.z + Math.sin(a)*r;
    if (x > 10) continue;
    const clear = W.buildings.every(b => Math.hypot(b.x-x, b.z-z) > (b.def.civic ? 7 : 6)) &&
                  W.nodes.every(n => n.amount <= 0 || Math.hypot(n.x-x, n.z-z) > 3);
    if (clear){
      pay(DB.BUILDINGS.house.cost);
      placeBuilding("house", x, z);
      return true;
    }
  }
  return false;
}

/* ═══ guilds / population ════════════════════════════════════ */
let popT = 0, guildT = 5, settleT = 3;
/* Folk find their own work. Any idler will take up the trade that is
   furthest below the staffing floor, so every job reaches three hands
   before anyone doubles up. Set someone by hand and they stay put. */
const SELF_ASSIGN = ["forester","miner","builder","farmer","acolyte","hunter","forager"];
let assignT = 0;
function selfAssign(dt){
  assignT -= dt;
  if (assignT > 0) return;
  assignT = 2.5;
  const floor = DB.TUNING.population.staffFloor === undefined ? 3 : DB.TUNING.population.staffFloor;
  const idle = W.units.filter(u => u.family === "folk" && u.job === "idle" && !u.pinnedJob);
  if (!idle.length) return;

  const count = j => W.units.filter(u => u.family === "folk" && u.job === j).length;
  for (const u of idle){
    // only trades whose building actually exists are worth staffing
    const viable = SELF_ASSIGN.filter(j => {
      if (j === "acolyte") return has("temple");
      if (j === "farmer")  return has("farm");
      if (j === "forager") return W.nodes.some(n => n.amount > 0 && yieldOf(n) === "food");
      if (j === "hunter")  return W.units.some(x => x.family === "beast" && x.hp > 0);
      return true;
    });
    const short = viable.filter(j => count(j) < floor);
    const pool = short.length ? short : viable;
    if (!pool.length) return;
    pool.sort((a,b) => count(a) - count(b));
    u.job = pool[0];
    u.node = null; u.site = null; u.prey = null;
  }
}

function growth(dt){
  popT -= dt;
  if (popT <= 0){
    popT = DB.TUNING.population.growthEvery;
    const folk = W.units.filter(u => u.family === "folk").length;
    if (folk < popCap()){
      const keep = W.buildings.find(b => b.type === "keep");
      const u = spawnUnit("villager", keep.x + rnd(-6,6), keep.z + rnd(-6,6), "player");
      u.job = "idle";
    }
  }
  guildT -= dt;
  if (guildT <= 0){
    guildT = 18;
    for (const b of W.buildings){
      if (!b.built || !b.def.guild || b.enemy) continue;
      if (!DB.CLASSES[b.def.guild]){          // a guild naming a class that isn't defined
        once("guild-" + b.def.guild,
             '<span class="r">!</span> The ' + b.def.label.toLowerCase() +
             ' has no <b>' + b.def.guild + '</b> class defined to recruit.');
        continue;
      }
      const mine = W.units.filter(u => u.homeBuilding === b).length;
      if (mine < b.def.effect.recruits * b.tier){
        const u = spawnUnit(b.def.guild, b.x + rnd(-4,4), b.z + rnd(-4,4), "player", {home:b});
        const ladder = DB.GEAR_LADDER[b.def.guild];
        if (ladder){ u.equip.weapon = ladder[0]; give(u, ladder[0]); u.gearStep = 1; }
        log('<b>' + u.name + '</b> the ' + u.def.label.toLowerCase() + ' takes a room at the ' + b.def.label.toLowerCase() + '.');
        break;
      }
    }
  }
  settleT -= dt;
  if (settleT <= 0){
    settleT = 2;
    const cred = W.units.filter(u => u.owed > 0).sort((a,b) => b.owed-a.owed)[0];
    if (cred && W.res.gold > 180){
      const p = Math.min(cred.owed, W.res.gold - 150);
      cred.owed -= p; cred.gold += p; W.res.gold -= p;
      log('<span class="t">✓</span> Arrears settled — <b>' + cred.name + '</b> paid <span class="g">' + Math.round(p) + 'g</span>.');
    }
  }
}

/* ═══ what buildings do just by standing there ═══════════════
   One pass over every finished building, reading the generic effect
   keys. Anything added in the editor with these keys works at once. */
function buildingEffects(dt){
  let appeal = 0;
  W.buildings.forEach(b => {
    if (!b.built || b.enemy) return;
    const eff = b.def.effect || {};
    const tier = b.tier;

    // passive trickle
    if (eff.produces){
      Object.keys(eff.produces).forEach(k => {
        const amt = eff.produces[k] * tier * dt;
        if (k === "energy") W.energy = Math.min(energyCap(), W.energy + amt);
        else W.res[k] = (W.res[k] || 0) + amt;
      });
    }

    // converters: one artisan on site turns one resource into another
    if (eff.converts){
      const c = eff.converts;
      const staffed = W.units.some(u => u.family === "folk" && u.job === "artisan" &&
                                        d2(u, b) < Math.max(b.def.w, b.def.d));
      if (staffed){
        b.convT = (b.convT || 0) + dt * tier;
        if (b.convT >= c.every){
          b.convT = 0;
          const canPay = Object.keys(c.in).every(k => (W.res[k] || 0) >= c.in[k]);
          if (canPay){
            Object.keys(c.in).forEach(k => W.res[k] -= c.in[k]);
            Object.keys(c.out).forEach(k => W.res[k] = (W.res[k] || 0) + c.out[k]);
            b.lastMade = Object.keys(c.out)[0];
          }
        }
      }
    }

    if (eff.appeal) appeal += eff.appeal * tier;

    // healing ground
    if (eff.heal){
      const r = Math.max(b.def.w, b.def.d) * .8 + 4;
      W.units.forEach(u => {
        if (u.faction !== "player" || u.hp <= 0 || u.hp >= u.maxHp) return;
        if (d2(u, b) < r) u.hp = Math.min(u.maxHp, u.hp + eff.heal * tier * dt);
      });
    }

    // a garrison keeps its own defenders standing
    if (eff.garrison){
      const want = eff.garrison.count * tier;
      const mine = W.units.filter(u => u.garrisonOf === b && u.hp > 0).length;
      b.garrT = (b.garrT || 0) - dt;
      if (mine < want && b.garrT <= 0 && DB.CLASSES[eff.garrison.cls]){
        b.garrT = 12;
        const g = spawnUnit(eff.garrison.cls, b.x + rnd(-3,3), b.z + rnd(-3,3), "player");
        g.garrisonOf = b;
        g.homeBuilding = b;
      }
    }

    // heroes train peacefully at the fairgrounds
    if (eff.trainHeroes){
      W.units.forEach(u => {
        if (u.family !== "hero" || u.hp <= 0) return;
        if (d2(u, b) > Math.max(b.def.w, b.def.d)) return;
        addXp(u, "attack", eff.trainHeroes * tier * dt * 12);
        addXp(u, "defence", eff.trainHeroes * tier * dt * 8);
      });
    }

    if (eff.alignDrift) shiftAlign(eff.alignDrift * tier * dt);
  });
  W.appeal = appeal;
}

/* Garrison troops hold their post rather than wandering. */
function garrisonStep(u, dt){
  const b = u.garrisonOf;
  if (!b || W.buildings.indexOf(b) < 0){ u.garrisonOf = null; return false; }
  u.atkCd -= dt;
  const foe = nearestEnemy(u, 16);
  if (foe && d2(foe, b) < 22){
    if (d2(u, foe) > u.def.attackRange) moveTo(u, foe.x, foe.z, dt);
    else if (u.atkCd <= 0){
      u.atkCd = u.def.attackSpeed;
      u.facing = Math.atan2(foe.x-u.x, foe.z-u.z);
      dealDamage(u, foe, attackPower(u), false);
    }
    return true;
  }
  const a = (u.id % 4) / 4 * 6.28;
  moveTo(u, b.x + Math.cos(a)*4, b.z + Math.sin(a)*4, dt, .6);
  return true;
}

/* Appeal raises birth rates and steadies heroes; squalor does the reverse. */
W.appealFactor = function (){
  return 1 + Math.max(-.5, Math.min(1.5, (W.appeal || 0) / 60));
};

/* ═══ the store's heaps ══════════════════════════════════════
   The piles beside the store swell with what the realm is holding,
   so you can read the treasury off the ground at a glance. */
function storePiles(){
  const s = W.buildings.find(b => b.type === "store" && b.built);
  if (!s || !s.mesh.userData.piles) return;
  const p = s.mesh.userData.piles;
  const scale = (amount, full) => {
    const f = Math.max(0, Math.min(1, amount / full));
    return .18 + f * 1.5;
  };
  const set = (grp, v) => {
    if (!grp) return;
    grp.scale.set(v, v, v);
    grp.visible = v > .22;
  };
  set(p.wood,  scale(W.res.wood,  1400));
  set(p.stone, scale(W.res.stone, 1400));
  set(p.food,  scale(W.res.food,   900));
}

/* ═══ towers ═════════════════════════════════════════════════ */
function towerStep(dt){
  W.buildings.forEach(b => {
    if ((b.type !== "tower" && b.type !== "mageTower") || !b.built) return;
    if (b.type === "mageTower"){
      b.cd -= dt;
      if (b.cd > 0) return;
      const eff = b.def.effect;
      const foe = nearestEnemy(b, eff.range * (1 + (b.tier-1)*.2));
      if (!foe) return;
      b.cd = eff.rate;
      fireProjectile({x:b.x, z:b.z, def:{height:b.def.height, projectile:"bolt"}, faction:"player"},
                     foe, "bolt", eff.damage * b.tier);
      return;
    }
    b.cd -= dt;
    if (b.cd > 0) return;
    const eff = b.def.effect;
    const foe = nearestEnemy(b, eff.range * (1 + (b.tier-1)*.25 + tech("towerRange")));
    if (!foe) return;
    b.cd = eff.rate / (1 + tech("towerRate"));
    fireProjectile({x:b.x, z:b.z, def:{height:b.def.height, projectile:"arrow"}, faction:"player"},
                   foe, "arrow", eff.damage * b.tier);
  });
}

/* ═══ main update ════════════════════════════════════════════ */
W.update = function (dt){
  if (W.paused) return;
  dt *= W.speed;
  W.time += dt;
  W.res.gold += DB.TUNING.economy.tithe * dt;
  get("mill").forEach(m => { W.res.food += m.def.effect.foodTithe * m.tier * dt; });
  Object.keys(W.buffs).forEach(k => { if (W.buffs[k] > 0) W.buffs[k] -= dt; });

  // node regrowth
  W.nodes.forEach(n => {
    if (n.amount <= 0 && n.respawn > 0){
      n.respawn -= dt * (W.buffs.quicken > 0 ? 2 : 1);
      if (n.respawn <= 0){ n.amount = n.max; n.mesh.visible = true; n.mesh.scale.setScalar(1); }
    }
    // worked nodes visibly shrink as they are used up
    else if (n.amount > 0 && n.max > 0 && !n.decorative){
      const f = .45 + .55 * (n.amount / n.max);
      if (Math.abs(n.mesh.scale.x - f) > .01) n.mesh.scale.setScalar(f);
    }
  });

  clockStep(dt);
  lairStep(dt);
  growth(dt);
  selfAssign(dt);
  breedStep(dt);
  buildingEffects(dt);
  towerStep(dt);
  storePiles();
  checkMissions();

  for (let i = W.units.length-1; i >= 0; i--){
    const u = W.units[i];
    if (u.frozen > 0) u.frozen -= dt;
    if (u.flight){ updateFlight(u, dt); syncMesh(u); continue; }
    if (u.heldBy){ syncMesh(u); continue; }
    if (u.hp <= 0 && u.state !== "down"){ continue; }
    if (u.aweCd > 0) u.aweCd -= dt;
    if (u.awe > 0){
      // stopped dead, turned toward the hand, staring
      u.awe -= dt;
      if (W.hand) u.facing = Math.atan2(W.hand.position.x - u.x, W.hand.position.z - u.z);
      syncMesh(u);
      continue;
    }
    if (u.family === "folk") villagerStep(u, dt);
    else if (u.family === "hero") heroStep(u, dt);
    else if (u.family === "soldier"){ if (!garrisonStep(u, dt)) soldierStep(u, dt); }
    else if (u.family === "monster") monsterStep(u, dt);
    else if (u.family === "beast") beastStep(u, dt);
    syncMesh(u);
  }

  if (W.creature){
    if (W.creature.flight) updateFlight(W.creature, dt);
    else creatureStep(W.creature, dt);
    syncMesh(W.creature);
    // folk stop and stare when the thing wanders past them
    W.aweT = (W.aweT || 0) - dt;
    if (W.aweT <= 0){
      W.aweT = 2.5;
      amaze(W.creature.x, W.creature.z, 15, "#D9A43F", 1.8);
    }
  }

  W.nodes.concat(W.carts).forEach(n => {
    if (n.flight){ updateFlight(n, dt); n.mesh.position.set(n.x, n.y||0, n.z); }
    else if (n.heldBy) n.mesh.position.set(n.x, n.y||0, n.z);
  });

  // carts on escort routes
  W.carts.forEach(c => {
    if (!c.moving) return;
    const t = c.route[c.routeI];
    if (!t) { c.moving = false; onCartArrived(c); return; }
    const d = Math.hypot(t.x-c.x, t.z-c.z);
    const step = Math.min(c.speed*dt, d);
    c.x += (t.x-c.x)/d*step; c.z += (t.z-c.z)/d*step;
    c.mesh.position.set(c.x, 0, c.z);
    c.mesh.rotation.y = Math.atan2(t.x-c.x, t.z-c.z);
    if (d < 1.5) c.routeI++;
  });

  // projectiles
  for (let i = W.projectiles.length-1; i >= 0; i--){
    const p = W.projectiles[i];
    if (!p.tgt || p.tgt.hp <= 0){ E.scene.remove(p.mesh); W.projectiles.splice(i,1); continue; }
    const tx = p.tgt.x, ty = (p.tgt.def.height||1.5)*.6, tz = p.tgt.z;
    const dx = tx-p.mesh.position.x, dy = ty-p.mesh.position.y, dz = tz-p.mesh.position.z;
    const d = Math.hypot(dx,dy,dz);
    const step = p.speed*dt;
    if (d <= step){
      dealDamage(p.src.xp ? p.src : null, p.tgt, p.damage, p.magical);
      E.scene.remove(p.mesh); W.projectiles.splice(i,1); continue;
    }
    p.mesh.position.x += dx/d*step; p.mesh.position.y += dy/d*step; p.mesh.position.z += dz/d*step;
    p.mesh.lookAt(tx, ty, tz);
  }

  // effects
  for (let i = W.effects.length-1; i >= 0; i--){
    const f = W.effects[i];
    f.life -= dt;
    if (f.kind === "ring" && f.mesh){
      const k = 1 - f.life/f.max;
      f.mesh.scale.setScalar(1 + k*.6);
      f.mesh.material.opacity = .65 * (1-k);
    }
    if (f.kind === "cage" && f.mesh && f.follow) f.mesh.position.set(f.follow.x, 0, f.follow.z);
    if (f.kind === "awe" && f.mesh){
      const age = f.max - f.life;
      if (f.follow) f.mesh.position.set(f.follow.x, (f.follow.def.height||1.6)*1.05, f.follow.z);
      f.mesh.children.forEach(p => {
        const d = p.userData.drift, t = Math.max(0, age - d.delay);
        p.position.x = d.x * t;
        p.position.z = d.z * t;
        p.position.y = d.y * t + Math.sin(t*5 + d.delay*9)*.06;
        p.rotation.y += d.spin * dt;
        p.rotation.x += d.spin * dt * .6;
        p.material.opacity = Math.max(0, .95 * (1 - age/f.max));
      });
    }
    if (f.kind === "fire"){
      W.units.forEach(u => { if (Math.hypot(u.x-f.x, u.z-f.z) < f.r) dealDamage(null, u, f.dps*dt, true); });
    }
    if (f.life <= 0){ if (f.mesh) E.scene.remove(f.mesh); W.effects.splice(i,1); }
  }

  // things that turn: mill sails, the wonder's crystal
  W.buildings.forEach(b => {
    const ud = b.mesh && b.mesh.userData;
    if (!ud) return;
    if (ud.spin) ud.spin.rotation.y += dt * (b.type === "wonder" ? .55 : 1.4);
    if (b.type === "wonder"){
      if (ud.spin) ud.spin.position.y += Math.sin(W.time*1.1) * dt * .8;
      if (ud.halo){ ud.halo.rotation.z += dt*.7; ud.halo.material.opacity = .45 + Math.sin(W.time*1.6)*.2; }
      if (ud.beacon) ud.beacon.intensity = 2.2 + Math.sin(W.time*1.6)*.7;
    }
  });

  // flag visuals — every planted flag, pinned ones riding their charge
  W.flagList.forEach(f => {
    if (f.attachTo && f !== W.held){
      f.x = f.attachTo.x; f.z = f.attachTo.z;
      f.mesh.position.set(f.x, 0, f.z);
    }
    if (f.hidden) return;
    f.mesh.userData.cloth.rotation.y = Math.sin(W.time*3 + f.id)*.22;
    f.mesh.userData.ring.material.opacity = .35 + Math.sin(W.time*2 + f.id)*.14;
  });

  // hand + leash
  if (W.leash.attached){
    W.leash.mesh.visible = true;
    const c = W.leash.attached;
    E.updateLeash(W.leash.mesh, W.hand.position,
      new T.Vector3(c.x, (c.def.height||2)*.62, c.z), DB.CREATURE.leashPull);
  } else W.leash.mesh.visible = false;

  if (W.held && W.held.mesh){
    const h = W.hand.position;
    W.held.x = h.x; W.held.z = h.z; W.held.y = Math.max(0, h.y - 1.6);
    W.held.mesh.position.set(h.x, W.held.y, h.z);
  }
};

function shadeDown(hex){
  const n = parseInt(hex.slice(1), 16);
  const r = Math.round(((n>>16)&255)*.62), g = Math.round(((n>>8)&255)*.62), b = Math.round((n&255)*.62);
  return "#" + ((1<<24) + (r<<16) + (g<<8) + b).toString(16).slice(1);
}
function syncMesh(u){
  if (!u.mesh) return;
  u.mesh.position.set(u.x, u.y||0, u.z);
  u.mesh.rotation.y = u.facing || 0;
  // folk wear their trade: the torso takes the job's colour
  if (u.family === "folk" && u.job !== u.wornJob){
    u.wornJob = u.job;
    const jc = DB.JOBS[u.job] ? DB.JOBS[u.job].colour : "#B9C0D4";
    if (u.mesh.userData.torso) u.mesh.userData.torso.material = E.mat(jc);
    if (u.mesh.userData.legs && u.mesh.userData.legs.material)
      u.mesh.userData.legs.material = E.mat(DB.JOBS[u.job] ? shadeDown(jc) : "#8A93AC");
  }
  const bob = (u.state === "march" || u.state === "swarm" || u.state === "fight") ? Math.abs(Math.sin(W.time*9 + u.id))*.09 : 0;
  if (u.mesh.userData.torso) u.mesh.userData.torso.position.y = (u.def.height*.53) + bob;
  const ring = u.mesh.userData.ring;
  if (ring){
    let op = 0, col = null;
    if (W.selected === u){ op = .9; col = "#D9A43F"; }
    else if (W.hovered === u){ op = .5; col = "#C6CBDA"; }
    else if (u.squad){ op = .35; col = u.squad.colour; }
    else if (u.flag && W.flags[u.flag]){ op = .35; col = DB.FLAGS[u.flag].colour; }
    ring.material.opacity = op;
    if (col) ring.material.color.set(col);
  }
  if (u.hp <= 0 && u.state === "down") u.mesh.rotation.z = 1.4;
  else u.mesh.rotation.z = 0;
  if (u.frozen > 0) u.mesh.position.y = (u.y||0);
}

function onCartArrived(c){
  log('<span class="g">★</span> The cart reaches its destination intact.');
  W.missions.forEach(m => { if (m.tpl.target === "cart" && !m.done) completeMission(m); });
  if (W.flags.escort) clearFlag("escort");
}
W.startCart = function (){
  const c = W.carts[0];
  if (!c || c.moving) return c;
  c.route = [{x:W.villageCentre.x+20, z:W.villageCentre.z-24},
             {x:W.villageCentre.x+52, z:W.villageCentre.z-30}];
  c.routeI = 0; c.moving = true;
  log('<span class="t">▸</span> The cart rolls out. Post an <b>escort flag</b> on it.');
  return c;
};

/* ═══ description for tooltips / inspector ═══════════════════ */
W.describe = function (ent){
  if (!ent) return null;
  if (ent.isNode){
    return {kind:"node", title:ent.kind === "tree" ? "Woodland" : ent.kind === "rock" ? "Stone Seam" : "Gold Vein",
            sub:"Resource node", rows:[["Remaining", Math.round(ent.amount) + " / " + ent.max],
            ["Yields", ent.kind === "tree" ? "Wood" : ent.kind === "vein" ? "Gold" : "Stone"],
            ["Regrows", ent.kind === "tree" ? "Yes" : "No"]]};
  }
  if (ent.isFlag){
    const takers = W.units.filter(u => u.family === "hero" && u.flag === ent.kind).length;
    return {kind:"flag", title:ent.def.label + " Flag", sub:"Pick it up and plant it where you want it",
            desc:ent.def.desc,
            rows:[["Price", ent.price + "g"], ["Takers", takers],
                  ["Paid", ent.kind === "attack" ? "per kill" : ent.kind === "defend" ? "per 5s held" : "on arrival"]]};
  }
  if (ent.isLair){
    return {kind:"lair", title:ent.label, sub:"Monster lair",
            rows:[["Breeds", ent.kind], ["Every", ent.every.toFixed(1) + "s"], ["Alive", ent.alive + " / " + ent.cap]]};
  }
  if (ent.units && ent.banner){
    return {kind:"squad", title:ent.name, sub:"Squad — direct command",
            rows:[["Soldiers", ent.units.length], ["Stance", ent.stance], ["Engage range", ent.engage + "m"]]};
  }
  if (ent.def && ent.built !== undefined){
    const rows = [["Tier", ent.tier], ["Structure", Math.round(ent.hp) + " / " + Math.round(ent.maxHp)]];
    if (!ent.built) rows.push(["Progress", Math.round(ent.prog/ent.def.work*100) + "%"]);
    Object.keys(ent.def.effect||{}).forEach(k => rows.push([k, ent.def.effect[k]]));
    return {kind:"building", title:ent.def.label, sub:ent.enemy ? "Enemy structure" : "Structure",
            desc:ent.def.desc, rows, ent};
  }
  // unit
  const skills = Object.keys(DB.SKILLS)
    .map(s => ({id:s, label:DB.SKILLS[s].label, lvl:lvl(ent,s), xp:Math.round(ent.xp[s]||0), colour:DB.SKILLS[s].colour}))
    .filter(s => s.lvl > 1 || s.xp > 0)
    .sort((a,b) => b.lvl - a.lvl);
  const age = Math.floor((ent.ageOffset||20) + (W.time/60)*DB.TUNING.ageing.yearsPerMinute);
  const busy = ent.family === "folk" ? DB.JOBS[ent.job].label
             : ent.state === "onflag" ? (W.flags[ent.flag] ? W.flags[ent.flag].def.label + " contract" : "contract")
             : ent.state;
  return {
    kind:"unit", ent,
    title:ent.name, sub:ent.def.label + " · combat " + combatLevel(ent) + " · age " + age,
    hp:[Math.round(ent.hp), Math.round(ent.maxHp)],
    mp:ent.maxMp ? [Math.round(ent.mp), Math.round(ent.maxMp)] : null,
    busy, gold:Math.round(ent.gold||0), owed:Math.round(ent.owed||0),
    thought:ent.thought,
    skills:skills.slice(0, 8),
    inv:(ent.inv||[]).map(i => ({label:DB.ITEMS[i.id] ? DB.ITEMS[i.id].label : i.id, qty:i.qty})),
    equip:{weapon:ent.equip && ent.equip.weapon ? DB.ITEMS[ent.equip.weapon].label : "—",
           armour:ent.equip && ent.equip.armour ? DB.ITEMS[ent.equip.armour].label : "—"}
  };
};

W.removeUnitPublic = removeUnit;
W.buildWorld = buildWorld;
W.rebuildBlocking = rebuildBlocking;
W.finishBuilding = finishBuilding;
W.removeBuilding = removeBuilding;
W.storeBuilding = storeBuilding;
W.applyAlignmentVisual = applyAlignmentVisual;
W.d2 = d2;

global.SIM = W;
})(window);
/* ===== ui.js ===== */
/* ═══════════════════════════════════════════════════════════════
   SOVEREIGN AEGIS — UI
   HUD, rails, hover cards, the selected-entity dock, and the live
   data editor (Ctrl+E) which walks DB generically: anything with a
   number, string or boolean value becomes editable while running.
   ═══════════════════════════════════════════════════════════════ */
(function (global) {
"use strict";

const DB = global.DB, W = global.SIM, E = global.ENGINE;
const $ = id => document.getElementById(id);
const el = (tag, cls, html) => { const n = document.createElement(tag); if (cls) n.className = cls; if (html != null) n.innerHTML = html; return n; };

const UI = {tool:null, tab:{left:"build", right:"flags"},
            prices:{attack:60, defend:30, follow:90}, dragSquad:null};

/* ═══ tool state ═════════════════════════════════════════════ */
UI.setTool = function (t){
  UI.tool = t;
  document.querySelectorAll("[data-tool]").forEach(b =>
    b.setAttribute("aria-pressed", String(!!t && b.dataset.tool === t.key)));
  const lbl = $("tool-label");
  if (!t) lbl.textContent = "No tool — click a thing to select it, drag it to pick it up";
  else if (t.kind === "build") lbl.innerHTML = "Placing <b>" + DB.BUILDINGS[t.type].label + "</b> — click the ground, Esc to cancel";
  else if (t.kind === "flag") lbl.innerHTML = "Planting the <b>" + DB.FLAGS[t.type].label + " flag</b> — click a target";
  else if (t.kind === "banner") lbl.innerHTML = "Moving <b>" + t.squad.name + "</b>'s banner — click where it should stand";
  if (window.MAIN && window.MAIN.updateGhost) window.MAIN.updateGhost();
};

/* ═══ HUD ════════════════════════════════════════════════════ */
function syncHud(){
  $("r-wood").textContent = Math.floor(W.res.wood);
  $("r-stone").textContent = Math.floor(W.res.stone);
  $("r-gold").textContent = Math.floor(W.res.gold);
  $("r-food").textContent = Math.floor(W.res.food);
  $("r-iron").textContent = Math.floor(W.res.iron || 0);
  $("r-goods").textContent = Math.floor(W.res.goods || 0);
  $("r-appeal").textContent = Math.round(W.appeal || 0);
  const folk = W.units.filter(u => u.family === "folk").length;
  $("r-pop").textContent = folk + "/" + W.popCap();
  $("r-heroes").textContent = W.units.filter(u => u.family === "hero").length;
  $("r-soldiers").textContent = W.units.filter(u => u.family === "soldier").length;
  $("r-threats").textContent = W.units.filter(u => u.faction === "monster").length;
  $("r-age").textContent = DB.AGES[W.age].label;
  $("r-realm").textContent = (W.godName ? W.godName + " · " : "") + (W.villageName || DB.MAP.name) +
    (W.continentName ? ", " + W.continentName : "") + (W.worldName ? " · " + W.worldName : "");
  $("r-realm").title = "God, village, continent, world";

  const cap = W.energyCap();
  $("r-energy").textContent = Math.floor(W.energy);
  $("r-energy-cap").textContent = Math.floor(cap);
  $("energy-fill").style.width = (W.energy/cap*100) + "%";

  const a = W.align, band = W.alignBand();
  $("align-marker").style.left = ((a + DB.ALIGNMENT.range) / (DB.ALIGNMENT.range*2) * 100) + "%";
  $("align-label").textContent = DB.ALIGNMENT[band].label;
  $("align-label").className = "align-label a-" + band;
}

/* ═══ left rail — build / train / recruit ════════════════════ */
const BUILD_GROUPS = [
  {label:"Civic", types:["keep","store","storehouse","warehouse","house","hut","villa","manor"]},
  {label:"Gathering", types:["lumber","mine","stonecutter","gatherHut","hunterHut","fisher","farm","mill","well"]},
  {label:"Workshops", types:["workshop","smelter","bakery","brewery","weaver","jeweler","weaponsmith","blacksmith"]},
  {label:"Trade", types:["market","tavern","tradingPost","bazaar","gambling","dock","feitoria"]},
  {label:"Comfort", types:["baths","hospital","gardens","amphitheatre","fairgrounds","creche","cemetery","graveyard","prison"]},
  {label:"Defences", types:["wall","palisade","gate","tower","ballista","guardhouse","outpost","torch"]},
  {label:"Faith & Learning", types:["temple","chapel","university","library","mageTower","dispenser"]},
  {label:"Guilds", types:["warriorGuild","rangerLodge","druidGrove","rogueDen","conclave","barbarianHall","crypt","dwarfHall","elvenLounge","gnomeHovel"]},
  {label:"Soldiery", types:["barracks","archery","stable","siege","armory"]},
  {label:"Wonder", types:["wonder"]}
];
function costHtml(cost){
  const map = {wood:"c-wood", stone:"c-stone", gold:"c-gold", food:"c-food",
               iron:"c-iron", goods:"c-goods"};
  return Object.keys(cost||{}).map(k =>
    '<span class="' + (map[k] || "dim") + '">' + cost[k] + " " +
    (k === "stone" ? "st" : k === "goods" ? "gd" : k.slice(0,1)) + "</span>").join(" ");
}
function buildPalette(){
  const host = $("panel-build");
  host.innerHTML = "";
  BUILD_GROUPS.forEach(g => {
    host.appendChild(el("h4", null, g.label));
    g.types.forEach(type => {
      const d = DB.BUILDINGS[type];
      if (!d){ console.warn("build palette: no such building", type); return; }
      const b = el("button", "pbtn");
      b.type = "button"; b.dataset.tool = "build:" + type;
      b.innerHTML = '<span class="n">' + d.label + '</span><span class="c">' + costHtml(d.cost) +
        (d.age ? ' <span class="dim">· ' + DB.AGES[d.age].label.split(" ")[0] + '</span>' : '') + '</span>';
      b.title = d.desc;
      b.addEventListener("click", () => {
        if (UI.tool && UI.tool.key === b.dataset.tool) return UI.setTool(null);
        UI.setTool({kind:"build", type, key:b.dataset.tool});
      });
      host.appendChild(b);
    });
  });
}
function syncPalette(){
  document.querySelectorAll('[data-tool^="build:"]').forEach(b => {
    const type = b.dataset.tool.split(":")[1], d = DB.BUILDINGS[type];
    b.disabled = d.age > W.age || !W.afford(d.cost);
  });
}

function buildTrain(){
  const host = $("panel-train");
  host.innerHTML = "";
  const barracks = W.buildings.filter(b => b.type === "barracks" && b.built);
  if (!barracks.length){
    host.appendChild(el("p","hint","Raise a <b>Barracks</b> to muster soldiers. Soldiers obey your banner and nothing else."));
    return;
  }
  host.appendChild(el("h4", null, "Muster"));
  const mk = el("button","pbtn");
  mk.type = "button";
  mk.innerHTML = '<span class="n">New squad</span><span class="c dim">from the barracks</span>';
  mk.disabled = W.squads.length >= barracks.reduce((s,b) => s + b.def.effect.squads*b.tier, 0);
  mk.addEventListener("click", () => { W.makeSquad(barracks[0]); rebuildPanels(); });
  host.appendChild(mk);

  if (!W.squads.length){ host.appendChild(el("p","hint","No squads yet.")); return; }
  host.appendChild(el("h4", null, "Train into squad"));
  const sel = el("select","sel");
  W.squads.forEach((s,i) => { const o = el("option",null,s.name); o.value = i; sel.appendChild(o); });
  host.appendChild(sel);
  ["pikeman","swordsman","archer","scout","ram"].forEach(cls => {
    const d = DB.CLASSES[cls];
    const need = d.needs && !W.buildings.some(b => b.type === d.needs && b.built);
    const b = el("button","pbtn");
    b.type = "button";
    b.innerHTML = '<span class="n">' + d.label + '</span><span class="c">' + costHtml(d.trainCost) +
      (need ? ' <span class="c-red">· needs ' + DB.BUILDINGS[d.needs].label + '</span>' : '') + '</span>';
    b.title = d.desc;
    b.disabled = !W.afford(d.trainCost) || need;
    b.addEventListener("click", () => {
      const s = W.squads[+sel.value] || W.squads[0];
      W.trainSoldier(s, cls);
      rebuildPanels();
    });
    host.appendChild(b);
  });
}

function buildJobs(){
  const host = $("panel-jobs");
  host.innerHTML = "";
  host.appendChild(el("h4", null, "Assign your folk"));
  Object.keys(DB.JOBS).forEach(id => {
    const j = DB.JOBS[id];
    const row = el("div","jrow");
    row.innerHTML = '<span class="sw" style="background:' + j.colour + '"></span>' +
                    '<span class="jn">' + j.label + '</span><span class="jc" data-job="' + id + '">0</span>';
    row.title = j.desc;
    const minus = el("button","sbtn","−"), plus = el("button","sbtn","+");
    minus.type = plus.type = "button";
    minus.setAttribute("aria-label", "Take one villager off " + j.label);
    plus.setAttribute("aria-label", "Put one villager on " + j.label);
    if (id === "idle"){ minus.style.visibility = plus.style.visibility = "hidden"; }
    minus.addEventListener("click", () => {
      const v = W.units.find(u => u.family === "folk" && u.job === id);
      if (v){ v.job = "idle"; v.node = null; v.site = null; }
      syncJobs();
    });
    plus.addEventListener("click", () => {
      const v = W.units.find(u => u.family === "folk" && u.job === "idle");
      if (v){ v.job = id; v.node = null; v.site = null; }
      syncJobs();
    });
    row.appendChild(minus); row.appendChild(plus);
    host.appendChild(row);
  });
}
function syncJobs(){
  const idle = W.units.filter(u => u.family === "folk" && u.job === "idle").length;
  Object.keys(DB.JOBS).forEach(id => {
    const n = W.units.filter(u => u.family === "folk" && u.job === id).length;
    const c = document.querySelector('[data-job="' + id + '"]');
    if (c) c.textContent = n;
  });
  $("panel-jobs").querySelectorAll(".jrow").forEach((row, i) => {
    const id = Object.keys(DB.JOBS)[i];
    const [minus, plus] = row.querySelectorAll(".sbtn");
    plus.disabled = idle === 0;
    minus.disabled = W.units.filter(u => u.family === "folk" && u.job === id).length === 0;
  });
}

/* ═══ right rail — flags / missions / squads / creature ══════ */
function buildFlags(){
  const host = $("panel-flags");
  host.innerHTML = "";
  host.appendChild(el("p","hint","Adventurers are not commanded. They read the price, weigh it against their purse and their nerve, and decide. Plant as many flags as you like — each carries its own price."));

  /* every flag standing on the map, with its own slider */
  if (W.flagList.length){
    host.appendChild(el("h4", null, "Planted (" + W.flagList.length + ")"));
    W.flagList.forEach(f => {
      const card = el("div","flagcard");
      card.style.setProperty("--fc", f.def.colour);
      const takers = W.units.filter(u => u.flagRef === f).length;
      card.innerHTML =
        '<div class="fh"><span class="fdot"></span><b>' + f.label + '</b>' +
        '<span class="fkey">' + takers + ' on it</span></div>' +
        (f.attachTo ? '<p class="fd">Pinned to <b>' + (f.attachTo.name || "a charge") + '</b></p>' : '');
      const row = el("div","frow");
      const slider = el("input");
      slider.type = "range"; slider.min = f.def.minPrice; slider.max = f.def.maxPrice;
      slider.step = 10; slider.value = f.price;
      slider.setAttribute("aria-label", f.label + " price");
      const val = el("span","fval", f.price + "g");
      slider.addEventListener("input", () => {
        f.price = +slider.value; val.textContent = f.price + "g";
        W.units.forEach(u => { if (u.family === "hero" && u.state === "idle") u.think = 0; });
      });
      row.appendChild(slider); row.appendChild(val);
      card.appendChild(row);

      const btns = el("div","frow");
      const eye = el("button","tbtn", f.hidden ? "Show" : "Hide");
      eye.type = "button";
      eye.addEventListener("click", () => { W.setFlagHidden(f, !f.hidden); rebuildPanels(); });
      const foc = el("button","tbtn","Focus");
      foc.type = "button";
      foc.addEventListener("click", () => E.focusOn(f.x, f.z, 40));
      const del = el("button","tbtn warn","Pull up");
      del.type = "button";
      del.addEventListener("click", () => { W.removeFlag(f); rebuildPanels(); });
      btns.appendChild(eye); btns.appendChild(foc); btns.appendChild(del);
      card.appendChild(btns);

      if (f.kind === "follow"){
        const fr = el("div","frow");
        const pin = el("button","tbtn","Pin to creature");
        pin.type = "button";
        pin.disabled = !W.creature;
        pin.addEventListener("click", () => {
          f.attachTo = W.creature;
          W.units.forEach(u => { if (u.family === "hero") u.think = 0; });
          W.logMsg('<span class="g">⚑</span> <b>' + f.label + '</b> now follows <b>' + W.creature.name + '</b>.');
          rebuildPanels();
        });
        const cart = el("button","tbtn","Pin to cart");
        cart.type = "button";
        cart.disabled = !W.carts.length;
        cart.addEventListener("click", () => {
          f.attachTo = W.carts[0];
          W.units.forEach(u => { if (u.family === "hero") u.think = 0; });
          rebuildPanels();
        });
        const un = el("button","tbtn","Unpin");
        un.type = "button";
        un.addEventListener("click", () => { f.attachTo = null; rebuildPanels(); });
        fr.appendChild(pin); fr.appendChild(cart); fr.appendChild(un);
        card.appendChild(fr);
      }
      host.appendChild(card);
    });
  }

  host.appendChild(el("h4", null, "Plant a new flag"));
  Object.keys(DB.FLAGS).forEach(kind => {
    const d = DB.FLAGS[kind];
    const card = el("div","flagcard");
    card.style.setProperty("--fc", d.colour);
    card.innerHTML =
      '<div class="fh"><span class="fdot"></span><b>' + d.label + ' flag</b><span class="fkey">' + d.key + '</span></div>' +
      '<p class="fd">' + d.desc + '</p>';
    const row = el("div","frow");
    const slider = el("input");
    slider.type = "range"; slider.min = d.minPrice; slider.max = d.maxPrice; slider.step = 10;
    slider.value = UI.prices[kind];
    slider.setAttribute("aria-label", d.label + " flag price");
    const val = el("span","fval", UI.prices[kind] + "g");
    slider.addEventListener("input", () => {
      UI.prices[kind] = +slider.value;
      val.textContent = UI.prices[kind] + "g";
      if (W.flags[kind]){
        W.flags[kind].price = UI.prices[kind];
        W.units.forEach(u => { if (u.family === "hero" && u.state === "idle") u.think = 0; });
      }
    });
    row.appendChild(slider); row.appendChild(val);
    card.appendChild(row);
    const btns = el("div","frow");
    const planted = W.flagList.filter(f => f.kind === kind).length;
    const plant = el("button","tbtn","Plant (" + planted + "/" + (d.maxFlags||6) + ")");
    plant.type = "button"; plant.dataset.tool = "flag:" + kind;
    plant.disabled = planted >= (d.maxFlags || 6);
    plant.addEventListener("click", () => {
      if (UI.tool && UI.tool.key === plant.dataset.tool) return UI.setTool(null);
      UI.setTool({kind:"flag", type:kind, key:plant.dataset.tool});
    });
    const recall = el("button","tbtn","Pull all up");
    recall.type = "button";
    recall.addEventListener("click", () => { W.clearFlag(kind); rebuildPanels(); });
    btns.appendChild(plant); btns.appendChild(recall);
    if (kind === "follow"){
      const roll = el("button","tbtn","Send cart");
      roll.type = "button";
      roll.addEventListener("click", () => {
        const c = W.startCart();
        if (c) W.addFlag("follow", c.x, c.z, UI.prices.follow, c);
        rebuildPanels();
      });
      btns.appendChild(roll);
    }
    card.appendChild(btns);
    host.appendChild(card);
  });
}
function syncFlags(){ /* the flags panel is rebuilt by worldSignature changes */ }

function buildMissions(){
  const host = $("panel-missions");
  host.innerHTML = "";
  const roll = el("button","tbtn","Draw new contracts");
  roll.type = "button";
  roll.addEventListener("click", () => { W.rollMissions(); rebuildPanels(); });
  host.appendChild(roll);
  W.missions.forEach(m => {
    const fdef = DB.FLAGS[m.flag];
    if (!fdef) return;                       // a mission naming a flag that no longer exists
    const c = el("div","mcard" + (m.done ? " done" : m.failed ? " failed" : ""));
    c.style.setProperty("--fc", fdef.colour);
    c.innerHTML = '<div class="mh"><span class="fdot"></span><b>' + m.label + '</b></div>' +
      '<p class="fd">' + m.brief + '</p>' +
      '<p class="fd"><span class="dim">Wants a</span> <b style="color:' + fdef.colour + '">' +
        fdef.label + ' flag</b> · <span class="c-gold">' + m.reward.gold + 'g</span> + ' + m.reward.xp + ' xp</p>';
    if (m.done) c.appendChild(el("p","fstat ok","Complete."));
    else if (m.failed) c.appendChild(el("p","fstat bad","Failed."));
    else {
      const go = el("button","tbtn","Focus & arm flag");
      go.type = "button";
      go.addEventListener("click", () => {
        E.focusOn(m.x, m.z, 46);
        UI.setTool({kind:"flag", type:m.flag, key:"flag:"+m.flag});
      });
      c.appendChild(go);
    }
    host.appendChild(c);
  });
}

function buildSquads(){
  const host = $("panel-squads");
  host.innerHTML = "";
  if (!W.squads.length){
    host.appendChild(el("p","hint","No squads. Raise a <b>Barracks</b>, muster a squad, then drag its banner — they march in formation and swarm anything that comes inside the banner's watch."));
    return;
  }
  W.squads.forEach(s => {
    const c = el("div","mcard");
    c.style.setProperty("--fc", s.colour);
    c.innerHTML = '<div class="mh"><span class="fdot"></span><b>' + s.name + '</b>' +
      '<span class="dim"> · ' + s.units.length + ' under arms</span></div>';
    const counts = {};
    s.units.forEach(u => counts[u.def.label] = (counts[u.def.label]||0) + 1);
    c.appendChild(el("p","fd", Object.keys(counts).map(k => counts[k] + " " + k).join(" · ") || "empty"));
    const row = el("div","frow");
    const mv = el("button","tbtn","Move banner");
    mv.type = "button";
    mv.addEventListener("click", () => UI.setTool({kind:"banner", squad:s, key:"banner:"+s.id}));
    const fo = el("button","tbtn","Focus");
    fo.type = "button";
    fo.addEventListener("click", () => E.focusOn(s.banner.x, s.banner.z, 40));
    row.appendChild(mv); row.appendChild(fo);
    const rng = el("input");
    rng.type = "range"; rng.min = 6; rng.max = 34; rng.value = s.engage;
    rng.title = "Engage range";
    rng.addEventListener("input", () => { s.engage = +rng.value; });
    c.appendChild(row);
    c.appendChild(el("p","fd dim","Engage range"));
    c.appendChild(rng);
    host.appendChild(c);
  });
}

function buildCreature(){
  const host = $("panel-creature");
  host.innerHTML = "";
  host.appendChild(el("p","hint","Double-click the creature to hook the leash. Drag across it to pet, flick down hard to slap, hold still to hug."));
  const c = el("div","mcard");
  c.style.setProperty("--fc","#A87C4A");
  c.innerHTML = '<div class="mh"><span class="fdot"></span><b>The Creature</b></div>' +
    '<p class="fd" id="cr-thought">—</p>' +
    '<p class="fd" id="cr-stats">—</p>';
  const row = el("div","frow");
  const leash = el("button","tbtn","Leash");
  leash.type = "button"; leash.id = "cr-leash";
  leash.addEventListener("click", () => {
    W.leash.attached = W.leash.attached ? null : W.creature;
    syncCreature();
  });
  const foc = el("button","tbtn","Focus");
  foc.type = "button";
  foc.addEventListener("click", () => E.focusOn(W.creature.x, W.creature.z, 34));
  const feed = el("button","tbtn","Feed (20 food)");
  feed.type = "button";
  feed.addEventListener("click", () => {
    if (W.res.food < 20) return;
    W.res.food -= 20; W.creature.hunger = 0; W.creature.mood += 8;
    W.creature.lastThought = 0; W.creature.thought = "Good. More.";
    W.shiftAlign(DB.ALIGNMENT.deltas.feedFolk);
  });
  row.appendChild(leash); row.appendChild(foc); row.appendChild(feed);
  c.appendChild(row);
  host.appendChild(c);
}
function syncCreature(){
  const c = W.creature;
  if (!c) return;
  const t = $("cr-thought"), s = $("cr-stats"), l = $("cr-leash");
  if (t) t.innerHTML = c.thought ? '<em>"' + c.thought + '"</em>' : "<span class=dim>…</span>";
  if (s) s.innerHTML = "HP " + Math.round(c.hp) + "/" + Math.round(c.maxHp) +
    " · hunger " + Math.round(c.hunger) + "% · mood " + Math.round(c.mood);
  if (l){ l.textContent = W.leash.attached ? "Unhook leash" : "Leash"; l.setAttribute("aria-pressed", String(!!W.leash.attached)); }
}

/* ═══ spell bar ══════════════════════════════════════════════ */
function buildSpells(){
  const host = $("spellbar");
  host.innerHTML = "";
  Object.keys(DB.SPELLS).forEach(id => {
    const sp = DB.SPELLS[id];
    const b = el("button","spell");
    b.type = "button"; b.dataset.spell = id;
    b.style.setProperty("--sc", sp.colour);
    b.innerHTML = '<span class="sk">' + sp.key + '</span><span class="sn">' + sp.label + '</span>' +
                  '<span class="sc">' + sp.cost + '</span>';
    b.title = sp.desc + "  (align " + (sp.align > 0 ? "+" : "") + sp.align + ")";
    b.addEventListener("click", () => { UI.setTool({kind:"spell", type:id, key:"spell:"+id}); });
    host.appendChild(b);
  });
}
function syncSpells(){
  document.querySelectorAll("[data-spell]").forEach(b => {
    const sp = DB.SPELLS[b.dataset.spell];
    b.classList.toggle("off", W.energy < sp.cost);
    b.setAttribute("aria-pressed", String(!!UI.tool && UI.tool.kind === "spell" && UI.tool.type === b.dataset.spell));
  });
}

/* ═══ log ════════════════════════════════════════════════════ */
function syncLog(){
  const host = $("log");
  host.innerHTML = W.log.slice(0, 9).map((l,i) =>
    '<div class="' + (i===0 ? "new " : "") + l.cls + '">' + l.html + "</div>").join("");
}
W.onLog = syncLog;

/* ═══ hover card ═════════════════════════════════════════════ */
const tip = () => $("tip");
UI.showTip = function (ent, sx, sy){
  const t = tip();
  const d = W.describe(ent);
  if (!d){ t.hidden = true; return; }
  let html = '<div class="tt"><b>' + d.title + '</b><span class="dim">' + d.sub + '</span></div>';
  if (d.kind === "unit"){
    html += '<div class="tbars">' +
      '<div class="tb"><i>HP</i><div class="bar"><span style="width:' + (d.hp[0]/d.hp[1]*100) + '%;background:#C8504A"></span></div><u>' + d.hp[0] + '/' + d.hp[1] + '</u></div>';
    if (d.mp) html += '<div class="tb"><i>MP</i><div class="bar"><span style="width:' + (d.mp[0]/d.mp[1]*100) + '%;background:#8E7BC8"></span></div><u>' + d.mp[0] + '/' + d.mp[1] + '</u></div>';
    html += '</div>';
    html += '<div class="trow"><span class="dim">Doing</span> ' + d.busy + '</div>';
    if (d.gold || d.owed) html += '<div class="trow"><span class="dim">Purse</span> <span class="c-gold">' + d.gold + 'g</span>' +
      (d.owed ? ' <span class="c-red">owed ' + d.owed + 'g</span>' : '') + '</div>';
    html += '<div class="tsk">' + d.skills.map(s =>
      '<span class="skl" style="--kc:' + s.colour + '"><i>' + s.label.slice(0,4) + '</i><b>' + s.lvl + '</b></span>').join("") + '</div>';
    html += '<div class="trow"><span class="dim">Wielding</span> ' + d.equip.weapon + ' · ' + d.equip.armour + '</div>';
    html += '<div class="trow"><span class="dim">Carrying</span> ' +
      (d.inv.length ? d.inv.map(i => i.label + (i.qty > 1 ? " ×" + i.qty : "")).join(", ") : "nothing") + '</div>';
    if (d.thought) html += '<div class="trow think">"' + d.thought + '"</div>';
  } else {
    if (d.desc) html += '<div class="trow dim">' + d.desc + '</div>';
    html += d.rows.map(r => '<div class="trow"><span class="dim">' + r[0] + '</span> ' + r[1] + '</div>').join("");
  }
  t.innerHTML = html;
  t.hidden = false;
  const r = t.getBoundingClientRect();
  const pad = 14;
  let x = sx + pad, y = sy + pad;
  if (x + r.width > innerWidth - 8) x = sx - r.width - pad;
  if (y + r.height > innerHeight - 8) y = sy - r.height - pad;
  t.style.left = Math.max(8, x) + "px";
  t.style.top = Math.max(8, y) + "px";
};
UI.hideTip = function (){ tip().hidden = true; };

/* ═══ selected dock ══════════════════════════════════════════ */
function syncDock(){
  const host = $("dock-body"), sel = W.selected;
  if (!sel){ $("dock").classList.add("empty"); host.innerHTML = '<span class="dim">Nothing selected. Click a villager, a hero, a building or the creature.</span>'; return; }
  $("dock").classList.remove("empty");
  const d = W.describe(sel);
  let html = '<div class="dk-head"><b>' + d.title + '</b><span class="dim">' + d.sub + '</span></div>';

  if (d.kind === "unit"){
    html += '<div class="dk-cols">';
    html += '<div class="dk-col"><h5>Condition</h5>' +
      '<div class="tb"><i>HP</i><div class="bar"><span style="width:' + (d.hp[0]/d.hp[1]*100) + '%;background:#C8504A"></span></div><u>' + d.hp[0] + '/' + d.hp[1] + '</u></div>' +
      (d.mp ? '<div class="tb"><i>MP</i><div class="bar"><span style="width:' + (d.mp[0]/d.mp[1]*100) + '%;background:#8E7BC8"></span></div><u>' + d.mp[0] + '/' + d.mp[1] + '</u></div>' : '') +
      '<p class="fd"><span class="dim">Doing</span> ' + d.busy + '</p>' +
      '<p class="fd"><span class="dim">Purse</span> <span class="c-gold">' + d.gold + 'g</span>' +
      (d.owed ? ' <span class="c-red">· owed ' + d.owed + 'g</span>' : '') + '</p>' +
      (d.thought ? '<p class="fd think">"' + d.thought + '"</p>' : '') + '</div>';

    const ent = d.ent;
    const full = Object.keys(DB.SKILLS).map(s => ({id:s, l:DB.SKILLS[s], lvl:W.lvl(ent,s), xp:Math.round(ent.xp[s]||0)}))
      .sort((a,b) => b.lvl - a.lvl || b.xp - a.xp);
    html += '<div class="dk-col wide"><h5>Skills</h5><div class="skgrid">' + full.map(s => {
      const p = DB.xpProgress(s.xp);
      return '<div class="skcell" title="' + s.l.note + '"><i style="color:' + s.l.colour + '">' + s.l.label + '</i>' +
        '<b>' + s.lvl + '</b><div class="bar sm"><span style="width:' + (p.frac*100) + '%;background:' + s.l.colour + '"></span></div></div>';
    }).join("") + '</div></div>';

    html += '<div class="dk-col"><h5>Kit</h5>' +
      '<p class="fd"><span class="dim">Weapon</span> ' + d.equip.weapon + '</p>' +
      '<p class="fd"><span class="dim">Armour</span> ' + d.equip.armour + '</p>' +
      '<h5>Inventory</h5><div class="invlist">' +
      (d.inv.length ? d.inv.map(i => '<span class="inv">' + i.label + (i.qty>1 ? ' <b>×'+i.qty+'</b>' : '') + '</span>').join("") : '<span class="dim">empty</span>') +
      '</div>';
    // this one villager's trade, set by hand
    if (d.ent.family === "folk"){
      html += '<h5>Put them to</h5><div class="jobpick">' + Object.keys(DB.JOBS).map(j =>
        '<button class="jobbtn' + (d.ent.job === j ? " on" : "") + '" data-setjob="' + j +
        '" title="' + DB.JOBS[j].desc + '"><i style="background:' + DB.JOBS[j].colour + '"></i>' +
        DB.JOBS[j].label + '</button>').join("") + '</div>';
    }
    html += '</div></div>';
  } else {
    html += '<div class="dk-cols"><div class="dk-col wide">';
    if (d.desc) html += '<p class="fd dim">' + d.desc + '</p>';
    html += d.rows.map(r => '<p class="fd"><span class="dim">' + r[0] + '</span> ' + r[1] + '</p>').join("");
    html += '</div>';
    // research offered by this building
    const offers = d.ent && d.ent.built && !d.ent.enemy
      ? Object.keys(DB.RESEARCH).filter(id => DB.RESEARCH[id].at === d.ent.type) : [];
    if (offers.length){
      html += '<div class="dk-col wide"><h5>Research</h5><div class="resgrid">' + offers.map(id => {
        const r = DB.RESEARCH[id];
        const owned = !!W.researched[id];
        const locked = r.age > W.age || (r.needs && !W.researched[r.needs]);
        const can = W.canResearch(id);
        return '<button class="resbtn' + (owned ? " owned" : "") + '" data-res="' + id + '"' +
          (owned || !can ? " disabled" : "") + ' title="' + r.desc + '">' +
          '<span class="n">' + r.label + (owned ? " ✓" : "") + '</span>' +
          '<span class="c">' + (owned ? '<span class="c-teal">researched</span>'
            : locked ? '<span class="c-red">' + (r.age > W.age ? DB.AGES[r.age].label : "needs " + DB.RESEARCH[r.needs].label) + '</span>'
            : costHtml(r.cost)) + '</span></button>';
      }).join("") + '</div></div>';
    }

    if (d.kind === "building" && d.ent && !d.ent.enemy){
      const b = d.ent;
      html += '<div class="dk-col"><h5>Works</h5>';
      if (b.built && b.tier < 4){
        const cost = {};
        Object.keys(b.def.cost).forEach(k => cost[k] = Math.round(b.def.cost[k] * b.tier * 1.7));
        html += '<p class="fd">' + costHtml(cost) + '</p>' +
          '<button class="tbtn" id="dk-upgrade"' + (W.afford(cost) ? "" : " disabled") +
          '>Raise to tier ' + (b.tier+1) + '</button>';
      } else if (b.built){
        html += '<p class="fd c-gold">Fully built out.</p>';
      }
      const missing = Math.max(0, b.maxHp - b.hp);
      if (b.built && missing > 1){
        const woodCost = Math.ceil(missing / 6);
        html += '<p class="fd" style="margin-top:.35rem"><span class="dim">Damage</span> ' +
          Math.round(missing) + '</p>' +
          '<button class="tbtn" id="dk-repair" data-wood="' + woodCost + '"' +
          (W.res.wood >= woodCost ? "" : " disabled") + '>Repair — ' + woodCost + ' wood</button>' +
          '<p class="fd dim">Or throw a tree at it.</p>';
      }
      if (!b.built){
        html += '<p class="fd"><span class="dim">Timber delivered</span> ' +
          Math.round(b.woodIn || 0) + ' / ' + Math.round(b.woodNeed || 0) + '</p>' +
          '<p class="fd dim">Builders bring it. Throwing a tree onto the site finishes the supply at once.</p>';
      }
      html += '</div>';
    }
    html += '</div>';
  }
  host.innerHTML = html;
  host.querySelectorAll("[data-res]").forEach(btn => {
    btn.addEventListener("click", () => { if (W.buyResearch(btn.dataset.res)) syncDock(); });
  });
  host.querySelectorAll("[data-setjob]").forEach(btn => {
    btn.addEventListener("click", () => {
      const u = W.selected;
      if (!u || u.family !== "folk") return;
      u.job = btn.dataset.setjob; u.node = null; u.site = null; u.prey = null;
      u.pinnedJob = true;                      // hand-picked: they stay put
      W.logMsg('<b>' + u.name + '</b> is put to ' + DB.JOBS[u.job].label.toLowerCase() + '.');
      syncJobs(); syncDock();
    });
  });
  const rep = $("dk-repair");
  if (rep) rep.addEventListener("click", () => {
    const b = W.selected, wood = +rep.dataset.wood;
    if (!b || W.res.wood < wood) return;
    W.res.wood -= wood; b.hp = b.maxHp;
    W.logMsg('<span class="t">⚒</span> <b>' + b.def.label + '</b> repaired for ' + wood + ' wood.');
    syncDock();
  });
  const up = $("dk-upgrade");
  if (up) up.addEventListener("click", () => {
    const b = W.selected, cost = {};
    Object.keys(b.def.cost).forEach(k => cost[k] = Math.round(b.def.cost[k] * b.tier * 1.7));
    if (!W.afford(cost)) return;
    W.pay(cost);
    b.tier++; b.maxHp = b.def.hp * (1 + (b.tier-1)*.4); b.hp = b.maxHp;
    E.scene.remove(b.mesh);
    const p = W.pickables.indexOf(b.mesh); if (p >= 0) W.pickables.splice(p,1);
    const mesh = E.makeBuilding(b.type, b.tier, b.enemy);
    mesh.position.set(b.x, 0, b.z); mesh.userData.entity = b;
    E.scene.add(mesh); b.mesh = mesh; W.pickables.push(mesh);
    W.logMsg('<span class="t">▲</span> <b>' + b.def.label + '</b> raised to tier ' + b.tier + '.');
    W.applyAlignmentVisual();
    rebuildPanels();
  });
}

/* ═══ age advance ════════════════════════════════════════════ */
function syncAge(){
  const btn = $("btn-age"), lbl = $("age-cost");
  if (W.age >= DB.AGES.length-1){ btn.disabled = true; lbl.textContent = "Imperial — the summit"; return; }
  const next = DB.AGES[W.age+1];
  const keep = W.buildings.find(b => b.type === "keep");
  const needKeep = !keep || keep.tier < next.keepTier;
  btn.disabled = !W.afford(next.cost) || needKeep;
  lbl.innerHTML = costHtml(next.cost) + (needKeep ? ' <span class="c-red">· Keep tier ' + next.keepTier + '</span>' : '');
}

/* ═══════════════════════════════════════════════════════════════
   THE EDITOR — walks DB generically, plus a live entity inspector
   ═══════════════════════════════════════════════════════════════ */
const EDITOR = {open:false, tab:"data", path:[]};

function fieldRow(obj, key, label, onChange){
  const v = obj[key];
  const row = el("div","erow");
  row.appendChild(el("label", null, label || key));
  let input;
  if (typeof v === "boolean"){
    input = el("input"); input.type = "checkbox"; input.checked = v;
    input.addEventListener("change", () => { obj[key] = input.checked; if (onChange) onChange(); });
  } else if (typeof v === "number"){
    input = el("input"); input.type = "number"; input.value = v;
    input.step = Math.abs(v) < 3 ? "0.05" : "1";
    input.addEventListener("input", () => { const n = parseFloat(input.value); if (!isNaN(n)){ obj[key] = n; if (onChange) onChange(); } });
  } else {
    input = el("input"); input.type = "text"; input.value = v;
    input.addEventListener("input", () => { obj[key] = input.value; if (onChange) onChange(); });
  }
  row.appendChild(input);
  return row;
}

function walk(obj, host, depth, onChange){
  Object.keys(obj).forEach(k => {
    const v = obj[k];
    if (v === null || v === undefined) return;
    if (typeof v === "function") return;
    if (Array.isArray(v)){
      const det = el("details","enode");
      det.appendChild(el("summary", null, k + ' <span class="dim">[' + v.length + ']</span>'));
      const inner = el("div","ebody");
      v.forEach((item, i) => {
        if (typeof item === "object" && item !== null){
          const d2n = el("details","enode");
          d2n.appendChild(el("summary", null, (item.label || item.type || item.id || item.kind || ("#" + i))));
          const b2 = el("div","ebody");
          walk(item, b2, depth+1, onChange);
          d2n.appendChild(b2);
          inner.appendChild(d2n);
        } else {
          inner.appendChild(fieldRow(v, i, "#" + i, onChange));
        }
      });
      det.appendChild(inner);
      host.appendChild(det);
      return;
    }
    if (typeof v === "object"){
      const det = el("details","enode");
      if (depth < 1) det.open = false;
      det.appendChild(el("summary", null, (v.label || k)));
      const inner = el("div","ebody");
      walk(v, inner, depth+1, onChange);
      det.appendChild(inner);
      host.appendChild(det);
      return;
    }
    host.appendChild(fieldRow(obj, k, k, onChange));
  });
}

/* Templates for "add new" — a fresh entry starts as a copy of a sane one. */
const ADD_TEMPLATES = {
  "Classes":       () => JSON.parse(JSON.stringify(DB.CLASSES.villager)),
  "Buildings":     () => JSON.parse(JSON.stringify(DB.BUILDINGS.hut)),
  "Flags":         () => JSON.parse(JSON.stringify(DB.FLAGS.attack)),
  "Spells":        () => JSON.parse(JSON.stringify(DB.SPELLS.heal)),
  "Items":         () => JSON.parse(JSON.stringify(DB.ITEMS.bread)),
  "Skills":        () => ({label:"New Skill", colour:"#8A93AC", note:"What it does."}),
  "Jobs":          () => ({label:"New Job", colour:"#8A93AC", skill:null, desc:"What they do."}),
  "Creatures":     () => JSON.parse(JSON.stringify(DB.CREATURES.ox)),
  "Research":      () => JSON.parse(JSON.stringify(DB.RESEARCH.forging)),
  "Nature — flora":   () => JSON.parse(JSON.stringify(DB.NATURE.flora.oak)),
  "Nature — fauna":   () => JSON.parse(JSON.stringify(DB.NATURE.fauna.sheep)),
  "Nature — minerals":() => JSON.parse(JSON.stringify(DB.NATURE.minerals.rock)),
  "Nature — zones":   () => ({x1:-40, x2:40})
};

function collectionTools(name, obj, rerender){
  const bar = el("div","erow-btns");
  if (Array.isArray(obj)){
    const add = el("button","tbtn","+ Add entry");
    add.addEventListener("click", () => {
      const t = ADD_TEMPLATES[name];
      obj.push(t ? t() : JSON.parse(JSON.stringify(obj[0] || {})));
      rerender();
    });
    bar.appendChild(add);
    return bar;
  }
  const add = el("button","tbtn","+ Add entry");
  add.addEventListener("click", () => {
    const id = prompt("Id for the new entry (no spaces):", "new_" + Object.keys(obj).length);
    if (!id) return;
    if (obj[id]){ alert("That id already exists."); return; }
    const t = ADD_TEMPLATES[name];
    const first = obj[Object.keys(obj)[0]];
    obj[id] = t ? t() : JSON.parse(JSON.stringify(first || {}));
    if (obj[id] && typeof obj[id] === "object" && "label" in obj[id]) obj[id].label = id;
    rerender();
  });
  const ren = el("button","tbtn","Rename entry");
  ren.addEventListener("click", () => {
    const from = prompt("Which id do you want to rename?\n\n" + Object.keys(obj).join(", "));
    if (!from || !obj[from]) return;
    const to = prompt("New id for “" + from + "”:", from);
    if (!to || to === from) return;
    if (obj[to]){ alert("That id already exists."); return; }
    const rebuilt = {};
    Object.keys(obj).forEach(k => { rebuilt[k === from ? to : k] = obj[k]; });
    Object.keys(obj).forEach(k => delete obj[k]);
    Object.keys(rebuilt).forEach(k => obj[k] = rebuilt[k]);
    rerender();
  });
  const del = el("button","tbtn warn","Remove entry");
  del.addEventListener("click", () => {
    const id = prompt("Which id do you want to remove?\n\n" + Object.keys(obj).join(", "));
    if (!id || !obj[id]) return;
    delete obj[id];
    rerender();
  });
  bar.appendChild(add); bar.appendChild(ren); bar.appendChild(del);
  return bar;
}

function buildEditor(){
  const host = $("editor-body");
  host.innerHTML = "";
  if (EDITOR.tab === "data"){
    const groups = {
      "Tuning":DB.TUNING, "Ages":DB.AGES, "Classes":DB.CLASSES, "Buildings":DB.BUILDINGS,
      "Flags":DB.FLAGS, "Spells":DB.SPELLS, "Items":DB.ITEMS, "Skills":DB.SKILLS,
      "Jobs":DB.JOBS, "Research":DB.RESEARCH, "Alignment":DB.ALIGNMENT,
      "Creature":DB.CREATURE, "Creatures":DB.CREATURES, "Missions":DB.MISSIONS
    };
    Object.keys(groups).forEach(g => {
      const det = el("details","enode top");
      det.appendChild(el("summary", null, g));
      const body = el("div","ebody");
      const editable = typeof groups[g] === "object" && g !== "Tuning" && g !== "Alignment" && g !== "Creature";
      if (editable) body.appendChild(collectionTools(g, groups[g], () => { buildEditor(); UI.rebuildPanels(); }));
      walk(groups[g], body, 0, () => {});
      det.appendChild(body);
      host.appendChild(det);
    });
  }
  else if (EDITOR.tab === "nature"){
    host.appendChild(el("p","hint",
      "Flora, fauna and minerals, and the rules that decide where each ends up. " +
      "<b>zone</b> picks the band of the map (player / wild / monster / any); <b>clumps</b> is how many patches; " +
      "<b>spread</b> how wide each patch is; <b>density</b> scales the count; <b>minGap</b> keeps individuals apart. " +
      "Changes take effect on <b>Restart</b>."));
    const groups = {
      "Nature — flora":DB.NATURE.flora,
      "Nature — fauna":DB.NATURE.fauna,
      "Nature — minerals":DB.NATURE.minerals,
      "Nature — zones":DB.NATURE.zones
    };
    Object.keys(groups).forEach(g => {
      const det = el("details","enode top");
      det.open = g === "Nature — flora";
      det.appendChild(el("summary", null, g.replace("Nature — ", "")));
      const body = el("div","ebody");
      body.appendChild(collectionTools(g, groups[g], () => { buildEditor(); }));
      walk(groups[g], body, 0, () => {});
      det.appendChild(body);
      host.appendChild(det);
    });
    const row = el("div","erow-btns");
    const re = el("button","tbtn","Restart into these rules");
    re.addEventListener("click", () => { W.reset(); UI.rebuildPanels(); UI.toggleEditor(false); UI.toggleChooser(true); });
    row.appendChild(re);
    host.appendChild(row);
  }
  else if (EDITOR.tab === "map"){
    host.appendChild(el("p","hint","Edit the starting map, then <b>Apply &amp; restart</b> to run it. Export the JSON to keep a scenario."));
    const det = el("details","enode top"); det.open = true;
    det.appendChild(el("summary", null, "Map — " + DB.MAP.name));
    const body = el("div","ebody");
    walk(DB.MAP, body, 0, () => {});
    det.appendChild(body);
    host.appendChild(det);

    const row = el("div","erow-btns");
    const apply = el("button","tbtn","Apply & restart");
    apply.addEventListener("click", () => location.reload());
    const exp = el("button","tbtn","Export JSON");
    exp.addEventListener("click", () => {
      const data = JSON.stringify({map:DB.MAP, tuning:DB.TUNING, classes:DB.CLASSES, buildings:DB.BUILDINGS}, null, 2);
      const blob = new Blob([data], {type:"application/json"});
      const a = el("a"); a.href = URL.createObjectURL(blob); a.download = "sovereign-aegis-scenario.json"; a.click();
    });
    const imp = el("button","tbtn","Import JSON");
    const file = el("input"); file.type = "file"; file.accept = "application/json"; file.hidden = true;
    imp.addEventListener("click", () => file.click());
    file.addEventListener("change", () => {
      const f = file.files[0]; if (!f) return;
      const rd = new FileReader();
      rd.onload = () => {
        try {
          const j = JSON.parse(rd.result);
          if (j.map) Object.assign(DB.MAP, j.map);
          if (j.tuning) Object.assign(DB.TUNING, j.tuning);
          if (j.classes) Object.assign(DB.CLASSES, j.classes);
          if (j.buildings) Object.assign(DB.BUILDINGS, j.buildings);
          localStorage.setItem("aegis-scenario", rd.result);
          alert("Scenario loaded. Reloading to apply.");
          location.reload();
        } catch (e){ alert("Could not read that file: " + e.message); }
      };
      rd.readAsText(f);
    });
    row.appendChild(apply); row.appendChild(exp); row.appendChild(imp); row.appendChild(file);
    host.appendChild(row);

    const save = el("button","tbtn","Save current tuning to this browser");
    save.addEventListener("click", () => {
      localStorage.setItem("aegis-scenario", JSON.stringify({map:DB.MAP, tuning:DB.TUNING, classes:DB.CLASSES, buildings:DB.BUILDINGS}));
      W.logMsg('<span class="t">✓</span> Tuning saved to this browser.');
    });
    const clr = el("button","tbtn","Clear saved tuning");
    clr.addEventListener("click", () => { localStorage.removeItem("aegis-scenario"); location.reload(); });
    const row2 = el("div","erow-btns");
    row2.appendChild(save); row2.appendChild(clr);
    host.appendChild(row2);
  }
  else {
    // live entities
    const search = el("input","esearch");
    search.type = "search"; search.placeholder = "Filter by name, class or building…";
    host.appendChild(search);
    const list = el("div","elist");
    host.appendChild(list);
    const detail = el("div","edetail");
    host.appendChild(detail);

    function renderList(){
      const q = search.value.toLowerCase();
      const rows = [];
      W.units.forEach(u => rows.push({label:u.name + " — " + u.def.label, ent:u}));
      if (W.creature) rows.push({label:"The Creature", ent:W.creature});
      W.buildings.forEach(b => rows.push({label:b.def.label + " @ " + Math.round(b.x) + "," + Math.round(b.z), ent:b}));
      (W.lairs||[]).forEach(l => rows.push({label:l.label + " — lair", ent:l}));
      list.innerHTML = "";
      rows.filter(r => !q || r.label.toLowerCase().includes(q)).slice(0, 120).forEach(r => {
        const b = el("button","erowbtn", r.label);
        b.addEventListener("click", () => { renderDetail(r.ent); W.selected = r.ent; });
        list.appendChild(b);
      });
    }
    function renderDetail(ent){
      detail.innerHTML = "";
      const head = el("h4", null, (ent.name || ent.def && ent.def.label || "Entity"));
      detail.appendChild(head);
      const core = el("div","ebody");
      ["hp","maxHp","mp","maxMp","gold","owed","x","z","tier","greed","courage","duty","hunger","mood","engage"]
        .forEach(k => { if (typeof ent[k] === "number") core.appendChild(fieldRow(ent, k, k, () => {
          if (ent.mesh && (k === "x" || k === "z")) ent.mesh.position.set(ent.x, ent.y||0, ent.z);
        })); });
      if (ent.job !== undefined){
        const row = el("div","erow");
        row.appendChild(el("label", null, "job"));
        const sel = el("select");
        Object.keys(DB.JOBS).forEach(j => { const o = el("option", null, DB.JOBS[j].label); o.value = j; if (ent.job === j) o.selected = true; sel.appendChild(o); });
        sel.addEventListener("change", () => { ent.job = sel.value; ent.node = null; ent.site = null; syncJobs(); });
        row.appendChild(sel);
        core.appendChild(row);
      }
      detail.appendChild(core);
      if (ent.xp){
        detail.appendChild(el("h4", null, "Skill XP"));
        const sk = el("div","ebody");
        Object.keys(DB.SKILLS).forEach(s => {
          const row = el("div","erow");
          row.appendChild(el("label", null, DB.SKILLS[s].label + " (lv " + W.lvl(ent,s) + ")"));
          const inp = el("input"); inp.type = "number"; inp.value = Math.round(ent.xp[s]||0);
          inp.addEventListener("input", () => {
            const n = parseFloat(inp.value);
            if (!isNaN(n)){ ent.xp[s] = n; row.querySelector("label").textContent = DB.SKILLS[s].label + " (lv " + W.lvl(ent,s) + ")"; }
          });
          row.appendChild(inp);
          sk.appendChild(row);
        });
        detail.appendChild(sk);
      }
      if (ent.inv){
        detail.appendChild(el("h4", null, "Inventory"));
        const iv = el("div","ebody");
        ent.inv.forEach((slot,i) => iv.appendChild(fieldRow(slot, "qty", DB.ITEMS[slot.id] ? DB.ITEMS[slot.id].label : slot.id, () => {})));
        const add = el("div","erow");
        add.appendChild(el("label", null, "give item"));
        const sel = el("select");
        Object.keys(DB.ITEMS).forEach(id => { const o = el("option", null, DB.ITEMS[id].label); o.value = id; sel.appendChild(o); });
        sel.addEventListener("change", () => {
          const s = ent.inv.find(x => x.id === sel.value);
          if (s) s.qty++; else ent.inv.push({id:sel.value, qty:1});
          renderDetail(ent);
        });
        add.appendChild(sel);
        iv.appendChild(add);
        detail.appendChild(iv);
      }
      if (ent.equip){
        detail.appendChild(el("h4", null, "Equipment"));
        const eq = el("div","ebody");
        ["weapon","armour"].forEach(slot => {
          const row = el("div","erow");
          row.appendChild(el("label", null, slot));
          const sel = el("select");
          const none = el("option", null, "—"); none.value = ""; sel.appendChild(none);
          Object.keys(DB.ITEMS).filter(id => DB.ITEMS[id].kind === (slot === "weapon" ? "weapon" : "armour"))
            .forEach(id => { const o = el("option", null, DB.ITEMS[id].label); o.value = id; if (ent.equip[slot] === id) o.selected = true; sel.appendChild(o); });
          sel.addEventListener("change", () => { ent.equip[slot] = sel.value || null; });
          row.appendChild(sel);
          eq.appendChild(row);
        });
        detail.appendChild(eq);
      }
    }
    search.addEventListener("input", renderList);
    renderList();
    if (W.selected) renderDetail(W.selected);
  }
}

UI.toggleEditor = function (force){
  EDITOR.open = force === undefined ? !EDITOR.open : force;
  $("editor").hidden = !EDITOR.open;
  W.paused = EDITOR.open;
  $("btn-pause").textContent = W.paused ? "Resume" : "Pause";
  if (EDITOR.open) buildEditor();
};

/* ═══ wiring ═════════════════════════════════════════════════ */
function tabs(hostId, panels, side){
  const host = $(hostId);
  host.innerHTML = "";
  Object.keys(panels).forEach(k => {
    const b = el("button","tab", panels[k]);
    b.type = "button"; b.dataset.tab = k;
    b.addEventListener("click", () => {
      UI.tab[side] = k;
      host.querySelectorAll(".tab").forEach(x => x.setAttribute("aria-pressed", String(x.dataset.tab === k)));
      Object.keys(panels).forEach(p => { const el2 = $("panel-" + p); if (el2) el2.hidden = p !== k; });
    });
    host.appendChild(b);
  });
  host.querySelector(".tab").click();
}

function rebuildPanels(){
  buildPalette(); buildTrain(); buildJobs();
  buildFlags(); buildMissions(); buildSquads(); buildCreature();
  syncJobs();
  const cur = UI.tab;
  ["build","train","jobs"].forEach(p => { const n = $("panel-" + p); if (n) n.hidden = p !== cur.left; });
  ["flags","missions","squads","creature","logtab"].forEach(p => { const n = $("panel-" + p); if (n) n.hidden = p !== cur.right; });
}
UI.rebuildPanels = rebuildPanels;

/* ═══ whole-state JSON ═══════════════════════════════════════
   Everything: the definition tables you can edit, and the living world.
   The same shape the PHP save endpoint stores. */
UI.exportBundle = function (){
  return {
    format:"sovereign-aegis/1",
    savedAt:new Date().toISOString(),
    definitions:{
      TUNING:DB.TUNING, TIME:DB.TIME, THREATS:DB.THREATS, SPELL_LEARNING:DB.SPELL_LEARNING,
      GAME_MODES:DB.GAME_MODES, AGES:DB.AGES, CLASSES:DB.CLASSES, BUILDINGS:DB.BUILDINGS,
      FLAGS:DB.FLAGS, SPELLS:DB.SPELLS, ITEMS:DB.ITEMS, SKILLS:DB.SKILLS, JOBS:DB.JOBS,
      RESEARCH:DB.RESEARCH, ALIGNMENT:DB.ALIGNMENT, CREATURE:DB.CREATURE,
      CREATURES:DB.CREATURES, MISSIONS:DB.MISSIONS, NATURE:DB.NATURE, MAP:DB.MAP,
      PART_PRESETS:DB.PART_PRESETS
    },
    world:(global.NET && global.NET.snapshot) ? global.NET.snapshot() : null
  };
};

UI.importBundle = function (bundle){
  if (!bundle || !bundle.definitions) throw new Error("That is not a Sovereign Aegis state file.");
  const d = bundle.definitions;
  const merge = (target, src) => { if (src) Object.keys(src).forEach(k => target[k] = src[k]); };
  merge(DB.TUNING, d.TUNING); merge(DB.TIME, d.TIME); merge(DB.THREATS, d.THREATS);
  merge(DB.SPELL_LEARNING, d.SPELL_LEARNING); merge(DB.GAME_MODES, d.GAME_MODES);
  merge(DB.CLASSES, d.CLASSES); merge(DB.BUILDINGS, d.BUILDINGS); merge(DB.FLAGS, d.FLAGS);
  merge(DB.SPELLS, d.SPELLS); merge(DB.ITEMS, d.ITEMS); merge(DB.SKILLS, d.SKILLS);
  merge(DB.JOBS, d.JOBS); merge(DB.RESEARCH, d.RESEARCH); merge(DB.CREATURES, d.CREATURES);
  merge(DB.NATURE, d.NATURE); merge(DB.MAP, d.MAP); merge(DB.PART_PRESETS, d.PART_PRESETS);
  if (d.AGES) DB.AGES.length = 0, d.AGES.forEach(a => DB.AGES.push(a));
  if (d.MISSIONS) DB.MISSIONS.length = 0, d.MISSIONS.forEach(m => DB.MISSIONS.push(m));
  try { localStorage.setItem("aegis-scenario", JSON.stringify({
    map:DB.MAP, tuning:DB.TUNING, classes:DB.CLASSES, buildings:DB.BUILDINGS})); } catch (e){}
  W.logMsg('<span class="t">✓</span> Definitions imported. Restarting into them.');
  W.reset();
  rebuildPanels();
  UI.toggleChooser(true);
};

/* ═══ creature chooser ═══════════════════════════════════════ */
let creaturePreviews = null;
/* Server state: the save files, the mode, and the clock — all set before
   you pick a creature, and all editable later. */
function buildServerState(){
  const mode = $("in-mode");
  if (mode && !mode.options.length){
    Object.keys(DB.GAME_MODES).forEach(k => {
      const o = el("option", null, DB.GAME_MODES[k].label);
      o.value = k;
      if (k === "single") o.selected = true;
      mode.appendChild(o);
    });
    mode.addEventListener("change", () => {
      W.gameMode = mode.value;
      if (mode.value === "sandbox") DB.THREATS.enabled = false;
      const tb = $("btn-threats");
      if (tb){ tb.textContent = "Threats: " + (DB.THREATS.enabled ? "on" : "off");
               tb.setAttribute("aria-pressed", String(DB.THREATS.enabled)); }
    });
  }
  const bind = (id, obj, key) => {
    const n = $(id);
    if (!n) return;
    n.value = obj[key];
    n.oninput = () => { const v = parseFloat(n.value); if (!isNaN(v)) obj[key] = v; };
  };
  bind("in-sph", DB.TIME, "secondsPerHour");
  bind("in-hpd", DB.TIME, "hoursPerDay");
  bind("in-dpy", DB.TIME, "daysPerYear");
  bind("in-lifemin", DB.TIME, "lifespanMin");
  bind("in-lifemax", DB.TIME, "lifespanMax");

  const row = $("savefile-row");
  if (!row) return;
  row.innerHTML = "";
  const NETX = global.NET;
  if (NETX && NETX.online && NETX.loggedIn && NETX.saves.length){
    NETX.saves.forEach(s => {
      const chip = el("button","savechip",
        "<b>" + s.village_name + "</b> · " + s.god_name + " · slot " + s.slot);
      chip.type = "button";
      chip.addEventListener("click", async () => {
        try { await NETX.load(s.id); UI.toggleChooser(false); }
        catch (e){ alert(e.message); }
      });
      row.appendChild(chip);
    });
  } else {
    row.appendChild(el("p","hint",
      NETX && NETX.online
        ? "Sign in to keep save files on the server. Until then, <b>Save JSON</b> writes the whole state to a file."
        : "Running from a file, so there are no server saves. <b>Save JSON</b> and <b>Import JSON</b> carry the whole state."));
  }
  const fresh = el("button","savechip on","+ New world");
  fresh.type = "button";
  fresh.addEventListener("click", () => { W.reset(); rebuildPanels(); });
  row.appendChild(fresh);
}
UI.buildServerState = buildServerState;

function buildChooser(){
  buildServerState();
  const grid = $("cr-grid");
  if (!grid) return;
  grid.innerHTML = "";
  if (!creaturePreviews){
    creaturePreviews = {};
    Object.keys(DB.CREATURES).forEach(k => {
      try { creaturePreviews[k] = E.previewCreature(k, 340, 240); }
      catch (e){ creaturePreviews[k] = null; }
    });
  }
  Object.keys(DB.CREATURES).forEach(k => {
    const c = DB.CREATURES[k];
    const card = el("button", "cr-card");
    card.type = "button";
    const img = creaturePreviews[k]
      ? '<img src="' + creaturePreviews[k] + '" alt="" style="width:100%;height:120px;object-fit:contain;' +
        'background:var(--ink);border:1px solid var(--line)">'
      : '<div style="height:120px;background:var(--ink);border:1px solid var(--line)"></div>';
    card.innerHTML = img +
      '<h3 style="color:' + c.colour + '">' + c.label + '</h3>' +
      '<p>' + c.trait + '</p>' +
      '<div class="cr-stats">' +
        '<span>HP <b>' + c.hp + '</b></span>' +
        '<span>Damage <b>' + c.damage + '</b></span>' +
        '<span>Speed <b>' + c.speed.toFixed(1) + '</b></span>' +
        '<span>Reach <b>' + c.attackRange.toFixed(1) + '</b></span>' +
      '</div>';
    card.addEventListener("click", () => {
      const val = (id, fallback) => (($(id) && $(id).value) || "").trim() || fallback;
      const god  = val("in-god", "Aegis");
      const wld  = val("in-world", "Enroth");
      const cont = val("in-continent", "Varda");
      const vill = val("in-village", DB.MAP.name);
      W.godName = god; W.worldName = wld; W.continentName = cont; W.villageName = vill;
      W.gameMode = ($("in-mode") && $("in-mode").value) || "single";
      DB.MAP.name = vill;
      W.chooseCreature(k);
      W.logMsg('<span class="g">❖</span> <b>' + god + '</b> takes <b>' + vill + '</b> of ' +
               cont + ', in the world of ' + wld + ', into their keeping.');
      UI.toggleChooser(false);
      UI.tab.right = "creature";
      rebuildPanels();
      E.focusOn(W.creature.x, W.creature.z, 34);
    });
    grid.appendChild(card);
  });
}
UI.toggleChooser = function (force){
  const open = force === undefined ? $("chooser").hidden : force;
  if (open) buildChooser();
  $("chooser").hidden = !open;
};

/* ═══ controls sheet ═════════════════════════════════════════ */
UI.toggleControls = function (force){
  const open = force === undefined ? $("controls").hidden : force;
  $("controls").hidden = !open;
};

UI.init = function (){
  tabs("tabs-left", {build:"Build", train:"Train", jobs:"Folk"}, "left");
  tabs("tabs-right", {flags:"Flags", missions:"Missions", squads:"Squads", creature:"Creature"}, "right");
  buildSpells();
  rebuildPanels();

  $("btn-age").addEventListener("click", () => {
    if (W.age >= DB.AGES.length-1) return;
    const next = DB.AGES[W.age+1], keep = W.buildings.find(b => b.type === "keep");
    if (!W.afford(next.cost) || !keep || keep.tier < next.keepTier) return;
    W.pay(next.cost); W.age++;
    W.logMsg('<span class="g">❖</span> The realm enters the <b class="g">' + next.label + '</b>.');
    rebuildPanels();
  });
  $("btn-pause").addEventListener("click", () => {
    W.paused = !W.paused;
    $("btn-pause").textContent = W.paused ? "Resume" : "Pause";
  });
  $("btn-speed").addEventListener("click", () => {
    W.speed = W.speed === 1 ? 2 : W.speed === 2 ? 4 : 1;
    $("btn-speed").textContent = "×" + W.speed;
  });
  $("btn-editor").addEventListener("click", () => UI.toggleEditor());
  $("editor-close").addEventListener("click", () => UI.toggleEditor(false));
  document.querySelectorAll("[data-etab]").forEach(b => {
    b.addEventListener("click", () => {
      EDITOR.tab = b.dataset.etab;
      document.querySelectorAll("[data-etab]").forEach(x => x.setAttribute("aria-pressed", String(x === b)));
      buildEditor();
    });
  });
  $("btn-cancel").addEventListener("click", () => { UI.setTool(null); W.selected = null; });

  /* ── whole-state JSON, next to the data editor ── */
  $("btn-export").addEventListener("click", () => {
    const bundle = UI.exportBundle();
    const blob = new Blob([JSON.stringify(bundle, null, 2)], {type:"application/json"});
    const a = el("a");
    a.href = URL.createObjectURL(blob);
    a.download = (W.villageName || DB.MAP.name).replace(/\W+/g,"_") + "_state.json";
    a.click();
    W.logMsg('<span class="t">✓</span> State written to JSON.');
  });
  $("btn-import").addEventListener("click", () => $("import-file").click());
  $("import-file").addEventListener("change", ev => {
    const file = ev.target.files[0];
    if (!file) return;
    const rd = new FileReader();
    rd.onload = () => {
      try { UI.importBundle(JSON.parse(rd.result)); }
      catch (e){ alert("Could not read that file: " + e.message); }
      ev.target.value = "";
    };
    rd.readAsText(file);
  });

  /* ── threats on/off ── */
  const tb = $("btn-threats");
  tb.addEventListener("click", () => {
    DB.THREATS.enabled = !DB.THREATS.enabled;
    tb.textContent = "Threats: " + (DB.THREATS.enabled ? "on" : "off");
    tb.setAttribute("aria-pressed", String(DB.THREATS.enabled));
    if (!DB.THREATS.enabled){
      W.units.filter(u => u.faction === "monster").forEach(u => W.removeUnitPublic(u));
      W.logMsg('<span class="t">✓</span> Threats stilled. The lairs go quiet.');
    } else W.logMsg('<span class="r">▲</span> Threats loosed.');
  });

  $("btn-controls").addEventListener("click", () => UI.toggleControls());
  $("controls-close").addEventListener("click", () => UI.toggleControls(false));
  $("btn-creature").addEventListener("click", () => UI.toggleChooser());
  // the realm pill is a hot-swap: jump to any other village this god has saved
  $("r-realm").addEventListener("click", () => {
    UI.toggleChooser(true);
    const row = $("savefile-row");
    if (row) row.scrollIntoView({block:"nearest"});
  });
  $("chooser-close").addEventListener("click", () => UI.toggleChooser(false));

  $("btn-restart").addEventListener("click", () => {
    UI.setTool(null);
    W.reset();
    UI.rebuildPanels();
    E.focusOn(W.villageCentre.x + 6, W.villageCentre.z, DB.TUNING.camera.startDist);
    UI.toggleChooser(true);
  });

  UI.setTool(null);
  UI.toggleControls(true);      // first-timers get the sheet up front
  setTimeout(() => UI.toggleChooser(true), 60);
};

/* The rails are rebuilt whenever the world changes shape underneath them —
   otherwise the Train tab keeps saying "raise a barracks" after you have. */
function worldSignature(){
  return W.buildings.length + "|" +
         W.buildings.filter(b => b.built).length + "|" +
         W.squads.length + "|" +
         W.squads.reduce((s,q) => s + q.units.length, 0) + "|" +
         W.age + "|" +
         W.units.filter(u => u.family === "folk").length + "|" +
         W.missions.filter(m => m.done || m.failed).length + "|" +
         W.flagList.length + "|" +
         W.flagList.map(f => f.hidden ? 1 : 0).join("") + "|" +
         W.flagList.filter(f => f.attachTo).length + "|" +
         W.units.filter(u => u.flagRef).length;
}
let lastSig = "", acc = 0;
UI.tick = function (dt){
  acc += dt;
  syncCreature();
  if (acc < .2) return;
  acc = 0;
  const sig = worldSignature();
  if (sig !== lastSig){
    lastSig = sig;
    rebuildPanels();
  }
  syncHud(); syncPalette(); syncJobs(); syncFlags(); syncSpells(); syncAge(); syncDock();
};

global.UI = UI;
})(window);
/* ===== net.js ===== */
/* ═══════════════════════════════════════════════════════════════
   SOVEREIGN AEGIS — NET
   Account and save/load against godsim.php. The login workflow is the
   same one index1.php uses: username-or-email + password against
   FSG_users, a PHP session, and a guest identity when signed out.
   ═══════════════════════════════════════════════════════════════ */
(function (global) {
"use strict";

const DB = global.DB, W = global.SIM, UI = global.UI;
const BOOT = global.GODSIM_BOOT || {};
const API = BOOT.apiUrl || "godsim.php";
const $ = id => document.getElementById(id);

const NET = {
  online: false,                       // true once the API answers
  loggedIn: !!BOOT.loggedIn,
  username: BOOT.username || "Guest",
  userId: BOOT.userId || 0,
  saves: [],
  slot: 1,
  busy: false
};

async function call(action, body, method){
  const opts = {method:method || "POST", headers:{"Content-Type":"application/json"},
                credentials:"same-origin"};
  if (opts.method === "POST") opts.body = JSON.stringify(body || {});
  const res = await fetch(API + "?action=" + encodeURIComponent(action), opts);
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); }
  catch (e){ throw new Error("Server did not return JSON (" + res.status + ")"); }
  if (!json.ok) throw new Error(json.error || ("Request failed (" + res.status + ")"));
  return json;
}
NET.call = call;

/* ── serialise the running world ─────────────────────────────── */
NET.snapshot = function (){
  const c = W.creature;
  return {
    godName:W.godName || "Aegis", worldName:W.worldName || "Enroth",
    continentName:W.continentName || "Varda", villageName:W.villageName || DB.MAP.name,
    creatureKind:c ? c.kind : "ox", creatureName:c ? c.name : "The Ox",
    age:W.age, align:W.align, energy:W.energy, time:W.time, kills:W.kills,
    res:{wood:W.res.wood, stone:W.res.stone, gold:W.res.gold, food:W.res.food},
    researched:W.researched || {},
    units:W.units.map(u => ({
      id:u.id, cls:u.cls, family:u.family, faction:u.faction, name:u.name,
      job:u.job, pinnedJob:!!u.pinnedJob, x:u.x, z:u.z,
      hp:u.hp, maxHp:u.maxHp, mp:u.mp, maxMp:u.maxMp,
      gold:u.gold, owed:u.owed, gearStep:u.gearStep,
      weapon:u.equip && u.equip.weapon, armour:u.equip && u.equip.armour,
      bornAt:u.bornAt, ageOffset:u.ageOffset, state:u.state,
      xp:u.xp, inv:u.inv
    })),
    buildings:W.buildings.map(b => ({
      id:b.id, type:b.type, tier:b.tier, x:b.x, z:b.z, hp:b.hp, maxHp:b.maxHp,
      built:b.built, prog:b.prog, woodIn:b.woodIn, woodNeed:b.woodNeed, enemy:b.enemy
    })),
    nodes:W.nodes.map(n => ({
      id:n.id, flora:n.flora || null, kind:n.kind, yields:n.yields || null,
      x:n.x, z:n.z, amount:n.amount, max:n.max, respawn:n.respawn, scale:n.scale
    })),
    flags:Object.keys(W.flags).reduce((o,k) => {
      const f = W.flags[k];
      if (f) o[k] = {x:f.x, z:f.z, price:f.price, held:f.held,
                     attachTo:f.attachTo ? f.attachTo.id : null};
      return o;
    }, {}),
    squads:W.squads.map(s => ({id:s.id, name:s.name, colour:s.colour,
      bx:s.banner.x, bz:s.banner.z, facing:s.facing, engage:s.engage, stance:s.stance})),
    missions:W.missions.map(m => ({tpl:m.tpl.id, label:m.label, flag:m.flag,
      prog:m.prog, need:m.need, gold:m.reward.gold, xp:m.reward.xp,
      done:m.done, failed:m.failed})),
    gameMode:W.gameMode,
    clock:{year:W.clock.year, day:W.clock.day, hour:W.clock.hour},
    time_settings:{
      secondsPerHour:DB.TIME.secondsPerHour, hoursPerDay:DB.TIME.hoursPerDay,
      daysPerYear:DB.TIME.daysPerYear, lifespanMin:DB.TIME.lifespanMin, lifespanMax:DB.TIME.lifespanMax
    },
    threats:{
      enabled:DB.THREATS.enabled, respawnMode:DB.THREATS.respawnMode,
      respawnDelaySeconds:DB.THREATS.respawnDelaySeconds
    },
    lairs:(W.lairs || []).map(l => ({
      key:l.id, label:l.label, kind:l.kind, x:l.x, z:l.z,
      homeX:l.homeX, homeZ:l.homeZ, hp:l.hp, maxHp:l.maxHp,
      every:l.every, cap:l.cap, dead:!!l.dead, respawnIn:l.respawnIn
    })),
    /* the creature, whole: its shape, its speed, what it has eaten and
       every miracle it has watched you work */
    creature:c ? {
      kind:c.kind, name:c.name, x:c.x, z:c.z,
      hp:c.hp, maxHp:c.maxHp,
      girth:c.girth, scale:c.girth, fed:c.fed,
      hunger:c.hunger, mood:c.mood,
      speed:c.def.speed, radius:c.def.radius, height:c.def.height,
      damage:c.def.damage, attackRange:c.def.attackRange,
      leashed:!!W.leash.attached,
      xp:c.xp,
      spellLore:c.spellLore || {}
    } : null
  };
};

/* ── actions ─────────────────────────────────────────────────── */
NET.refreshStatus = async function (){
  try {
    const r = await call("status", null, "GET");
    NET.online = true;
    NET.loggedIn = !!r.loggedIn;
    NET.username = r.loggedIn ? r.user.username : (r.guestName || "Guest");
    NET.userId = r.loggedIn ? r.user.id : 0;
    if (NET.loggedIn) await NET.refreshSaves();
  } catch (e){
    NET.online = false;                       // running from file:// or offline
  }
  paint();
};

NET.refreshSaves = async function (){
  try {
    const r = await call("listSaves", null, "GET");
    NET.saves = r.saves || [];
  } catch (e){ NET.saves = []; }
};

NET.login = async function (username, password){
  const r = await call("login", {username, password});
  NET.loggedIn = true; NET.username = r.user.username; NET.userId = r.user.id;
  await NET.refreshSaves();
  W.logMsg('<span class="t">✓</span> Signed in as <b>' + NET.username + '</b>.');
  paint();
};

NET.register = async function (fields){
  const r = await call("register", fields);
  NET.loggedIn = true; NET.username = r.user.username; NET.userId = r.user.id;
  W.logMsg('<span class="t">✓</span> Account made. Welcome, <b>' + NET.username + '</b>.');
  paint();
};

NET.logout = async function (){
  await call("logout", {});
  NET.loggedIn = false; NET.userId = 0; NET.saves = [];
  const r = await call("status", null, "GET").catch(() => null);
  NET.username = (r && r.guestName) || "Guest";
  W.logMsg('<span class="dim">Signed out.</span>');
  paint();
};

/* Everything the modeller authored, in the shape the PHP expects. */
NET.modelPayload = function (){
  const models = [];
  Object.keys(DB.BUILDINGS).forEach(key => {
    const d = DB.BUILDINGS[key];
    if (!d.models && !d.parts) return;
    const tiers = Math.max(1, d.tiers || 1);
    for (let t = 1; t <= tiers; t++){
      const parts = (d.models && (d.models[t] || d.models[String(t)])) || (t === 1 ? d.parts : null);
      if (!parts || !parts.length) continue;
      models.push({key, tier:t, label:d.label || key, iconDir:d.iconDir || "",
                   prefabDir:d.prefabDir || "", description:d.description || "",
                   tooltip:d.tooltip || "", tiers, parts, collider:d.collider || {}});
    }
  });
  return {models, presets:DB.PART_PRESETS};
};

NET.saveModels = async function (){
  if (!NET.loggedIn) throw new Error("Sign in first.");
  const r = await call("saveModels", NET.modelPayload());
  W.logMsg('<span class="t">✓</span> ' + r.models + ' building models and ' +
           r.presets + ' saved parts written to the server.');
  return r;
};

NET.loadModels = async function (){
  if (!NET.loggedIn) throw new Error("Sign in first.");
  const r = await call("loadModels", null, "GET");
  (r.models || []).forEach(row => {
    const d = DB.BUILDINGS[row.building_key];
    if (!d) return;
    d.models = d.models || {};
    try { d.models[+row.tier] = JSON.parse(row.parts_json); } catch (e){ return; }
    if (+row.tier === 1) d.parts = d.models[1];
    d.tiers = Math.max(1, +row.tier_count || 1);
    d.iconDir = row.icon_dir; d.prefabDir = row.prefab_dir;
    d.description = row.description || ""; d.tooltip = row.tooltip || "";
    try { d.collider = JSON.parse(row.collider_json); } catch (e){}
  });
  (r.presets || []).forEach(row => {
    try { DB.PART_PRESETS[row.part_key] = {label:row.label, parts:JSON.parse(row.parts_json)}; }
    catch (e){}
  });
  W.logMsg('<span class="t">✓</span> Models loaded from the server.');
  if (UI.rebuildPanels) UI.rebuildPanels();
  return r;
};

NET.save = async function (slot){
  if (!NET.loggedIn) throw new Error("Sign in first.");
  NET.busy = true; paint();
  try {
    const r = await call("saveWorld", {slot:slot || NET.slot, world:NET.snapshot()});
    W.logMsg('<span class="t">✓</span> World saved to slot ' + r.slot + '.');
    await NET.refreshSaves();
  } finally { NET.busy = false; paint(); }
};

/* Loading rebuilds the world from the map, then overwrites the parts we
   stored. Anything not stored (meshes, AI targets) is rebuilt fresh. */
NET.load = async function (saveId){
  if (!NET.loggedIn) throw new Error("Sign in first.");
  NET.busy = true; paint();
  try {
    const r = await call("loadWorld", {saveId}, "GET");
    applySave(r);
    W.logMsg('<span class="t">✓</span> Loaded <b>' + r.save.village_name + '</b>.');
  } finally { NET.busy = false; paint(); }
};

function applySave(r){
  const s = r.save;
  W.reset();
  W.godName = s.god_name; W.worldName = s.world_name;
  W.continentName = s.continent_name; W.villageName = s.village_name;
  DB.MAP.name = s.village_name;
  W.age = +s.age_index; W.align = +s.alignment;
  W.energy = +s.spell_energy; W.time = +s.sim_time; W.kills = +s.kills;

  const res = (r.resources || [])[0];
  if (res){ W.res.wood = +res.wood; W.res.stone = +res.stone;
            W.res.gold = +res.gold; W.res.food = +res.food; }

  (r.research || []).forEach(row => { W.researched[row.research_key] = true; });

  // buildings: clear the generated ones, put the stored ones down
  W.buildings.slice().forEach(b => W.removeBuilding(b));
  (r.buildings || []).forEach(row => {
    const b = W.placeBuilding(row.type_key, +row.pos_x, +row.pos_z,
      {tier:+row.tier, instant:+row.is_built === 1, enemy:+row.is_enemy === 1});
    if (b){ b.hp = +row.hp; b.maxHp = +row.max_hp;
            b.prog = +row.progress; b.woodIn = +row.wood_in; b.woodNeed = +row.wood_need; }
  });

  // units
  W.units.slice().forEach(u => { if (u.mesh) W.removeUnitPublic(u); });
  const skillsBy = {}, itemsBy = {};
  (r.skills || []).forEach(x => { (skillsBy[x.runtime_id] = skillsBy[x.runtime_id] || {})[x.skill_key] = +x.xp; });
  (r.items  || []).forEach(x => { (itemsBy[x.runtime_id]  = itemsBy[x.runtime_id]  || []).push({id:x.item_key, qty:+x.qty}); });
  (r.units || []).forEach(row => {
    if (!DB.CLASSES[row.class_key]) return;
    const u = W.spawnUnit(row.class_key, +row.pos_x, +row.pos_z, row.faction);
    u.name = row.unit_name; u.job = row.job; u.pinnedJob = +row.pinned_job === 1;
    u.hp = +row.hp; u.maxHp = +row.max_hp; u.mp = +row.mp; u.maxMp = +row.max_mp;
    u.gold = +row.gold; u.owed = +row.owed; u.gearStep = +row.gear_step;
    u.equip.weapon = row.equip_weapon; u.equip.armour = row.equip_armour;
    u.bornAt = +row.born_at; u.ageOffset = +row.age_offset; u.state = row.state;
    if (skillsBy[row.runtime_id]) Object.assign(u.xp, skillsBy[row.runtime_id]);
    if (itemsBy[row.runtime_id]) u.inv = itemsBy[row.runtime_id];
  });

  // creature
  const c = (r.creature || [])[0];
  if (c){
    W.chooseCreature(c.kind);
    const cr = W.creature;
    cr.name = c.creature_name; cr.x = +c.pos_x; cr.z = +c.pos_z;
    cr.hp = +c.hp; cr.maxHp = +c.max_hp; cr.fed = +c.fed;
    cr.hunger = +c.hunger; cr.mood = +c.mood;
    (r.creatureSkills || []).forEach(x => cr.xp[x.skill_key] = +x.xp);
    cr.spellLore = {};
    (r.creatureSpells || []).forEach(x => {
      cr.spellLore[x.spell_key] = {watched:+x.watched, level:+x.spell_level};
    });
    cr.girth = +c.girth || 1;
    W.growCreature(cr, 0);
    if (+c.leashed === 1) W.leash.attached = cr;
  }

  // clock, mode and threat rules
  const ws = (r.worldState || [])[0];
  if (ws){
    W.gameMode = ws.game_mode;
    DB.TIME.secondsPerHour = +ws.seconds_per_hour;
    DB.TIME.hoursPerDay = +ws.hours_per_day;
    DB.TIME.daysPerYear = +ws.days_per_year;
    DB.TIME.lifespanMin = +ws.lifespan_min;
    DB.TIME.lifespanMax = +ws.lifespan_max;
    DB.THREATS.enabled = +ws.threats_enabled === 1;
    DB.THREATS.respawnMode = ws.respawn_mode;
    DB.THREATS.respawnDelaySeconds = +ws.respawn_delay;
  }
  // threat spawners
  (r.lairs || []).forEach(row => {
    const l = (W.lairs || []).find(x => String(x.id) === String(row.lair_key));
    if (!l) return;
    l.x = +row.pos_x; l.z = +row.pos_z;
    l.hp = +row.hp; l.maxHp = +row.max_hp;
    l.dead = +row.is_dead === 1; l.respawnIn = +row.respawn_in;
    l.mesh.position.set(l.x, 0, l.z);
    l.mesh.visible = !l.dead;
  });

  // flags
  (r.flags || []).forEach(row => {
    W.setFlag(row.flag_kind, +row.pos_x, +row.pos_z, +row.price, null, true);
  });

  W.applyAlignmentVisual();
  UI.rebuildPanels();
}

/* ── the account panel ───────────────────────────────────────── */
function paint(){
  const btn = $("btn-account");
  if (btn){
    btn.textContent = NET.online
      ? (NET.loggedIn ? "☰ " + NET.username : "Sign in")
      : "Offline";
    btn.disabled = !NET.online;
    btn.title = NET.online ? "" : "Saving needs the game served by godsim.php";
  }
  const body = $("account-body");
  if (!body || $("account").hidden) return;
  renderAccount();
}

function renderAccount(){
  const body = $("account-body");
  if (!body) return;
  body.innerHTML = "";

  if (!NET.loggedIn){
    body.innerHTML =
      '<div class="acct-grid">' +
        '<form class="acct-card" id="form-login">' +
          '<h3>Sign in</h3>' +
          '<label>Username or email<input name="username" autocomplete="username" required></label>' +
          '<label>Password<input name="password" type="password" autocomplete="current-password" required></label>' +
          '<button class="tbtn" type="submit">Sign in</button>' +
          '<p class="fd" id="login-msg"></p>' +
        '</form>' +
        '<form class="acct-card" id="form-register">' +
          '<h3>Make an account</h3>' +
          '<label>Username<input name="username" required></label>' +
          '<label>Email<input name="email" type="email" required></label>' +
          '<label>Password<input name="password" type="password" autocomplete="new-password" required></label>' +
          '<label>Repeat password<input name="password2" type="password" required></label>' +
          '<label class="acct-check"><input name="over18" type="checkbox"> I am over 18</label>' +
          '<label class="acct-check"><input name="privacy" type="checkbox"> I agree to the privacy policy</label>' +
          '<button class="tbtn" type="submit">Create</button>' +
          '<p class="fd" id="reg-msg">8+ characters with an uppercase, a lowercase, a number and a symbol.</p>' +
        '</form>' +
      '</div>';

    $("form-login").addEventListener("submit", async ev => {
      ev.preventDefault();
      const f = new FormData(ev.target);
      try { await NET.login(f.get("username"), f.get("password")); renderAccount(); }
      catch (e){ $("login-msg").innerHTML = '<span class="c-red">' + e.message + '</span>'; }
    });
    $("form-register").addEventListener("submit", async ev => {
      ev.preventDefault();
      const f = new FormData(ev.target);
      try {
        await NET.register({username:f.get("username"), email:f.get("email"),
          password:f.get("password"), password2:f.get("password2"),
          over18:!!f.get("over18"), privacy:!!f.get("privacy")});
        renderAccount();
      } catch (e){ $("reg-msg").innerHTML = '<span class="c-red">' + e.message + '</span>'; }
    });
    return;
  }

  const rows = NET.saves.map(s =>
    '<tr><td>' + s.slot + '</td><td><b>' + s.village_name + '</b><br>' +
    '<span class="dim">' + s.god_name + ' · ' + s.continent_name + ' · ' + s.world_name + '</span></td>' +
    '<td>' + DB.AGES[Math.max(0, Math.min(DB.AGES.length-1, +s.age_index))].label + '</td>' +
    '<td>' + Math.round(+s.sim_time) + 's</td>' +
    '<td><button class="tbtn" data-load="' + s.id + '">Load</button> ' +
        '<button class="tbtn warn" data-del="' + s.id + '">Delete</button></td></tr>').join("");

  body.innerHTML =
    '<div class="acct-card wide">' +
      '<h3>Signed in as ' + NET.username + '</h3>' +
      '<div class="frow">' +
        '<label class="dim" style="font:var(--ui) var(--font-mono)">Slot ' +
          '<input id="save-slot" type="number" min="1" max="9" value="' + NET.slot + '" style="width:4rem"></label>' +
        '<button class="tbtn" id="btn-save-world">Save this world</button>' +
        '<button class="tbtn" id="btn-signout">Sign out</button>' +
      '</div>' +
      (NET.saves.length
        ? '<table class="acct-table"><thead><tr><th>Slot</th><th>World</th><th>Age</th><th>Played</th><th></th></tr></thead>' +
          '<tbody>' + rows + '</tbody></table>'
        : '<p class="fd dim">No saved worlds yet.</p>') +
      '<p class="fd" id="acct-msg"></p>' +
    '</div>';

  $("btn-save-world").addEventListener("click", async () => {
    NET.slot = +$("save-slot").value || 1;
    try { await NET.save(NET.slot); renderAccount(); }
    catch (e){ $("acct-msg").innerHTML = '<span class="c-red">' + e.message + '</span>'; }
  });
  $("btn-signout").addEventListener("click", async () => { await NET.logout(); renderAccount(); });
  body.querySelectorAll("[data-load]").forEach(b => b.addEventListener("click", async () => {
    try { await NET.load(+b.dataset.load); UI.toggleAccount(false); }
    catch (e){ $("acct-msg").innerHTML = '<span class="c-red">' + e.message + '</span>'; }
  }));
  body.querySelectorAll("[data-del]").forEach(b => b.addEventListener("click", async () => {
    if (!confirm("Delete that world?")) return;
    try { await call("deleteSave", {saveId:+b.dataset.del}); await NET.refreshSaves(); renderAccount(); }
    catch (e){ $("acct-msg").innerHTML = '<span class="c-red">' + e.message + '</span>'; }
  }));
}

UI.toggleAccount = function (force){
  const panel = $("account");
  if (!panel) return;
  const open = force === undefined ? panel.hidden : force;
  panel.hidden = !open;
  if (open) renderAccount();
};

NET.init = function (){
  const btn = $("btn-account");
  if (btn) btn.addEventListener("click", () => UI.toggleAccount());
  const close = $("account-close");
  if (close) close.addEventListener("click", () => UI.toggleAccount(false));
  NET.refreshStatus();
};

global.NET = NET;
})(window);
/* ===== modeller.js ===== */
/* ═══════════════════════════════════════════════════════════════
   SOVEREIGN AEGIS — BUILDING MODELLER
   Every building loads in as a list of primitives; the procedural ones
   are captured back into editable parts automatically.

   Shift-click the list to select several. Drag the gizmo to move,
   rotate or scale everything selected at once. Weld a selection into a
   reusable compound part. Author a different model per tier. Give each
   building its icon path, prefab path, description and tooltip.
   Everything here rides out in the JSON export and the MySQL tables.
   ═══════════════════════════════════════════════════════════════ */
(function (global) {
"use strict";

const T = global.THREE, DB = global.DB, E = global.ENGINE, W = global.SIM, UI = global.UI;
const $ = id => document.getElementById(id);
const el = (tag, cls, html) => { const n = document.createElement(tag); if (cls) n.className = cls; if (html != null) n.innerHTML = html; return n; };
const clone = o => JSON.parse(JSON.stringify(o));

const M = {
  open:false, type:null, tier:1, parts:[], sel:[], dirty:false,
  gizmoMode:"move",            // none | move | rotate | scale
  editMode:"object",           // object | vertex | edge | face
  showCollider:false,
  scene:null, camera:null, renderer:null, group:null, gizmo:null, colliderMesh:null,
  raf:0, cam:{yaw:.7, pitch:.5, dist:26, target:new T.Vector3(0,3,0)},
  drag:null, faceSel:[]
};

/* ═══ preview scene ══════════════════════════════════════════ */
function initView(){
  if (M.renderer) return;
  const host = $("mod-view");
  M.scene = new T.Scene();
  M.scene.background = new T.Color("#0A0E18");
  M.scene.add(new T.HemisphereLight("#93A8D0", "#20242E", .95));
  const dl = new T.DirectionalLight("#FFF0D8", .95);
  dl.position.set(12, 20, 14);
  M.scene.add(dl);
  const grid = new T.GridHelper(60, 30, "#2E463E", "#26362F");
  grid.material.opacity = .5; grid.material.transparent = true;
  M.scene.add(grid);
  M.camera = new T.PerspectiveCamera(45, 1, .1, 600);
  M.renderer = new T.WebGLRenderer({antialias:true});
  M.renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
  host.appendChild(M.renderer.domElement);
  M.group = new T.Group();
  M.scene.add(M.group);
  bindView(M.renderer.domElement);
}

function sizeView(){
  const host = $("mod-view");
  const w = host.clientWidth || 600, h = host.clientHeight || 400;
  if (M.camera.aspect !== w/h){ M.camera.aspect = w/h; M.camera.updateProjectionMatrix(); }
  M.renderer.setSize(w, h, false);
}

function ndc(ev, dom){
  const r = dom.getBoundingClientRect();
  return new T.Vector2(((ev.clientX-r.left)/r.width)*2-1, -((ev.clientY-r.top)/r.height)*2+1);
}

/* ═══ input ══════════════════════════════════════════════════ */
function bindView(dom){
  let orbit = false, lx = 0, ly = 0, moved = 0;

  dom.addEventListener("pointerdown", ev => {
    dom.setPointerCapture(ev.pointerId);
    lx = ev.clientX; ly = ev.clientY; moved = 0;

    // a gizmo handle takes priority over everything
    if (M.gizmoMode !== "none" && M.gizmo && M.sel.length && ev.button === 0){
      const ray = new T.Raycaster();
      ray.setFromCamera(ndc(ev, dom), M.camera);
      const hit = ray.intersectObjects(M.gizmo.children, true)[0];
      if (hit && hit.object.userData.axis){
        beginDrag(hit.object.userData.axis, ev, dom);
        return;
      }
    }
    if (ev.button === 2 || ev.shiftKey === false && ev.button === 1){ orbit = true; return; }
    orbit = (ev.button === 2 || ev.button === 1);
    if (ev.button === 0) M.pendingPick = true;
    else M.pendingPick = false;
    if (ev.button === 0 && !M.pendingPick) orbit = true;
  });

  dom.addEventListener("pointermove", ev => {
    const dx = ev.clientX - lx, dy = ev.clientY - ly;
    lx = ev.clientX; ly = ev.clientY;
    moved += Math.abs(dx) + Math.abs(dy);

    if (M.drag){ updateDrag(ev, dom); return; }
    if (orbit || (M.pendingPick && moved > 5 && !M.drag)){
      M.cam.yaw -= dx * .008;
      M.cam.pitch = Math.max(-.25, Math.min(1.45, M.cam.pitch + dy * .006));
      if (moved > 5) M.pendingPick = false;
    }
  });

  dom.addEventListener("pointerup", ev => {
    if (M.drag){ endDrag(); orbit = false; M.pendingPick = false; return; }
    if (M.pendingPick && moved <= 5) pickAt(ev, dom);
    orbit = false; M.pendingPick = false;
  });

  dom.addEventListener("contextmenu", ev => ev.preventDefault());
  dom.addEventListener("wheel", ev => {
    ev.preventDefault();
    M.cam.dist = Math.max(4, Math.min(200, M.cam.dist * (1 + Math.sign(ev.deltaY)*.12)));
  }, {passive:false});
}

/* Click in the viewport: pick a part, or a face when in face mode. */
function pickAt(ev, dom){
  const ray = new T.Raycaster();
  ray.setFromCamera(ndc(ev, dom), M.camera);
  const hit = ray.intersectObjects(M.group.children, true)[0];
  if (!hit){ if (!ev.shiftKey){ M.sel = []; M.faceSel = []; refresh(); } return; }

  if (M.editMode === "face" && hit.face){
    const key = M.parts.indexOf(hit.object.userData.part) + ":" + hit.faceIndex;
    if (ev.shiftKey){
      const i = M.faceSel.indexOf(key);
      if (i >= 0) M.faceSel.splice(i,1); else M.faceSel.push(key);
    } else M.faceSel = [key];
    refresh();
    return;
  }
  const idx = M.parts.indexOf(hit.object.userData.part);
  if (idx < 0) return;
  if (ev.shiftKey){
    const at = M.sel.indexOf(idx);
    if (at >= 0) M.sel.splice(at, 1); else M.sel.push(idx);
  } else M.sel = [idx];
  refresh();
}

/* ═══ gizmo dragging ═════════════════════════════════════════ */
function selectionCentre(){
  if (!M.sel.length) return new T.Vector3();
  const c = new T.Vector3();
  M.sel.forEach(i => {
    const p = M.parts[i];
    c.add(new T.Vector3(p.x || 0, p.y || 0, p.z || 0));
  });
  return c.multiplyScalar(1 / M.sel.length);
}

function dragPlane(axisKey, origin){
  // a plane containing the axis and facing the camera as much as possible
  const camDir = new T.Vector3().subVectors(M.camera.position, origin).normalize();
  let n;
  if (axisKey === "all") n = camDir;
  else {
    const ax = axisKey === "x" ? new T.Vector3(1,0,0)
             : axisKey === "y" ? new T.Vector3(0,1,0) : new T.Vector3(0,0,1);
    n = new T.Vector3().crossVectors(ax, new T.Vector3().crossVectors(camDir, ax)).normalize();
    if (!isFinite(n.x) || n.lengthSq() < .01) n = camDir;
  }
  return new T.Plane().setFromNormalAndCoplanarPoint(n, origin);
}

function rayPoint(ev, dom, plane){
  const ray = new T.Raycaster();
  ray.setFromCamera(ndc(ev, dom), M.camera);
  const out = new T.Vector3();
  return ray.ray.intersectPlane(plane, out) ? out : null;
}

function beginDrag(axis, ev, dom){
  const origin = selectionCentre();
  const plane = dragPlane(axis, origin);
  const start = rayPoint(ev, dom, plane);
  if (!start) return;
  M.drag = {
    axis, plane, origin, start,
    before:M.sel.map(i => clone(M.parts[i])),
    mode:M.gizmoMode
  };
}

function updateDrag(ev, dom){
  const d = M.drag;
  const now = rayPoint(ev, dom, d.plane);
  if (!now) return;
  const delta = new T.Vector3().subVectors(now, d.start);

  M.sel.forEach((partIdx, n) => {
    const p = M.parts[partIdx], b = d.before[n];
    if (d.mode === "move"){
      const step = ev.ctrlKey ? .5 : 0;                    // ctrl snaps to half-units
      const snap = v => step ? Math.round(v/step)*step : +v.toFixed(3);
      if (d.axis === "x" || d.axis === "all") p.x = snap((b.x||0) + delta.x);
      if (d.axis === "y" || d.axis === "all") p.y = snap((b.y||0) + delta.y);
      if (d.axis === "z" || d.axis === "all") p.z = snap((b.z||0) + delta.z);
    }
    else if (d.mode === "rotate"){
      // angle swept about the axis, measured on the drag plane
      const v0 = new T.Vector3().subVectors(d.start, d.origin);
      const v1 = new T.Vector3().subVectors(now, d.origin);
      const axV = d.axis === "x" ? new T.Vector3(1,0,0)
                : d.axis === "y" ? new T.Vector3(0,1,0) : new T.Vector3(0,0,1);
      let ang = Math.atan2(
        new T.Vector3().crossVectors(v0, v1).dot(axV),
        v0.dot(v1));
      if (ev.ctrlKey) ang = Math.round(ang / (Math.PI/12)) * (Math.PI/12);
      const key = d.axis === "x" ? "rx" : d.axis === "y" ? "ry" : "rz";
      p[key] = +(((b[key]||0) + ang)).toFixed(3);
      // orbit the part around the selection centre so a group turns together
      if (M.sel.length > 1){
        const rel = new T.Vector3((b.x||0)-d.origin.x, (b.y||0)-d.origin.y, (b.z||0)-d.origin.z);
        rel.applyAxisAngle(axV, ang);
        p.x = +(d.origin.x + rel.x).toFixed(3);
        p.y = +(d.origin.y + rel.y).toFixed(3);
        p.z = +(d.origin.z + rel.z).toFixed(3);
      }
    }
    else if (d.mode === "scale"){
      const reach = Math.max(.001, d.start.distanceTo(d.origin));
      let k = now.distanceTo(d.origin) / reach;
      k = Math.max(.05, Math.min(20, k));
      const apply = (key, on) => { if (on) p[key] = +(((b[key] === undefined ? 1 : b[key])) * k).toFixed(3); };
      apply("sx", d.axis === "x" || d.axis === "all");
      apply("sy", d.axis === "y" || d.axis === "all");
      apply("sz", d.axis === "z" || d.axis === "all");
      if (M.sel.length > 1){
        p.x = +(d.origin.x + ((b.x||0)-d.origin.x)*k).toFixed(3);
        p.y = +(d.origin.y + ((b.y||0)-d.origin.y)*k).toFixed(3);
        p.z = +(d.origin.z + ((b.z||0)-d.origin.z)*k).toFixed(3);
      }
    }
  });
  M.dirty = true;
  rebuildPreview();
}
function endDrag(){ M.drag = null; renderParts(); }

/* ═══ frame ══════════════════════════════════════════════════ */
function frame(){
  if (!M.open){ M.raf = 0; return; }
  M.raf = requestAnimationFrame(frame);
  sizeView();
  const c = M.cam;
  M.camera.position.set(
    c.target.x + Math.sin(c.yaw)*Math.cos(c.pitch)*c.dist,
    c.target.y + Math.sin(c.pitch)*c.dist,
    c.target.z + Math.cos(c.yaw)*Math.cos(c.pitch)*c.dist);
  M.camera.lookAt(c.target);
  if (M.gizmo){
    const p = selectionCentre();
    M.gizmo.position.copy(p);
    const s = Math.max(.35, c.dist / 26);        // keep it a usable size at any zoom
    M.gizmo.scale.setScalar(s);
  }
  M.renderer.render(M.scene, M.camera);
}

/* ═══ model ══════════════════════════════════════════════════ */
function currentDef(){ return DB.BUILDINGS[M.type]; }

function loadType(type, tier){
  const def = DB.BUILDINGS[type];
  if (!def) return;
  M.type = type;
  M.tier = tier || 1;
  M.sel = []; M.faceSel = []; M.dirty = false;
  Object.keys(DB.BUILDING_META_DEFAULTS).forEach(k => {
    if (def[k] === undefined) def[k] = DB.BUILDING_META_DEFAULTS[k];
  });
  if (!def.collider) def.collider = {w:def.w||3, h:def.height||3, d:def.d||3, x:0, y:(def.height||3)/2, z:0, rx:0, ry:0, rz:0};

  const authored = def.models && (def.models[M.tier] || def.models[String(M.tier)]);
  if (authored && authored.length) M.parts = clone(authored);
  else if (def.parts && def.parts.length) M.parts = clone(def.parts);
  else {
    const tmp = E.makeBuildingProcedural(type, M.tier, false);
    M.parts = E.captureParts(tmp);
    tmp.traverse(o => { if (o.geometry) o.geometry.dispose(); });
  }
  M.parts.forEach((p, i) => { if (!p.name) p.name = p.shape + " " + i; });
  M.cam.target.set(0, (def.height || 4) * .45, 0);
  M.cam.dist = Math.max(14, (Math.max(def.w || 4, def.d || 4) + (def.height || 4)) * 1.5);
  refresh();
}

function rebuildPreview(){
  while (M.group.children.length){
    const c = M.group.children.pop();
    M.group.remove(c);
    if (c.geometry && c.userData.temp) c.geometry.dispose();
  }
  M.parts.forEach((p, i) => {
    if (p.hidden) return;
    const mesh = E.makePart(p);
    mesh.userData.part = p;
    M.group.add(mesh);
    if (M.sel.indexOf(i) >= 0){
      const hl = new T.BoxHelper(mesh, new T.Color("#D9A43F"));
      hl.userData.temp = true;
      M.group.add(hl);
    }
  });

  // selected faces, drawn as bright overlays
  if (M.editMode === "face" && M.faceSel.length){
    M.faceSel.forEach(key => {
      const [pi, fi] = key.split(":").map(Number);
      const src = M.group.children.find(c => c.userData.part === M.parts[pi]);
      if (!src || !src.geometry) return;
      const g = src.geometry;
      const pos = g.attributes.position;
      const idx = g.index;
      const a = idx ? idx.getX(fi*3) : fi*3;
      const b = idx ? idx.getX(fi*3+1) : fi*3+1;
      const c2 = idx ? idx.getX(fi*3+2) : fi*3+2;
      const tri = new T.BufferGeometry();
      tri.setAttribute("position", new T.Float32BufferAttribute([
        pos.getX(a),pos.getY(a),pos.getZ(a),
        pos.getX(b),pos.getY(b),pos.getZ(b),
        pos.getX(c2),pos.getY(c2),pos.getZ(c2)], 3));
      const m = new T.Mesh(tri, new T.MeshBasicMaterial({color:"#FFD34A", side:T.DoubleSide,
        transparent:true, opacity:.75, depthTest:false}));
      m.position.copy(src.position); m.rotation.copy(src.rotation); m.scale.copy(src.scale);
      m.userData.temp = true; m.renderOrder = 996;
      M.group.add(m);
    });
  }

  // vertex / edge display
  if (M.editMode === "vertex" || M.editMode === "edge"){
    M.sel.forEach(i => {
      const src = M.group.children.find(c => c.userData.part === M.parts[i]);
      if (!src) return;
      const helper = M.editMode === "vertex"
        ? new T.Points(src.geometry.clone(), new T.PointsMaterial({color:"#46E0C8", size:.22, depthTest:false}))
        : new T.LineSegments(new T.WireframeGeometry(src.geometry),
            new T.LineBasicMaterial({color:"#46E0C8", depthTest:false}));
      helper.position.copy(src.position); helper.rotation.copy(src.rotation); helper.scale.copy(src.scale);
      helper.userData.temp = true; helper.renderOrder = 995;
      M.group.add(helper);
    });
  }

  // gizmo
  if (M.gizmo){ M.scene.remove(M.gizmo); M.gizmo = null; }
  if (M.gizmoMode !== "none" && M.sel.length && M.editMode === "object"){
    M.gizmo = E.makeGizmo(M.gizmoMode);
    M.scene.add(M.gizmo);
  }

  // collider
  if (M.colliderMesh){ M.scene.remove(M.colliderMesh); M.colliderMesh = null; }
  if (M.showCollider && currentDef()){
    M.colliderMesh = E.makeColliderBox(currentDef().collider);
    M.scene.add(M.colliderMesh);
  }
}

function refresh(){ rebuildPreview(); renderList(); renderParts(); }

/* ═══ left rail: types ═══════════════════════════════════════ */
function renderList(){
  const host = $("mod-list");
  host.innerHTML = "";
  host.appendChild(el("h4", null, "Buildings"));
  Object.keys(DB.BUILDINGS).forEach(type => {
    const d = DB.BUILDINGS[type];
    const b = el("button", "modrow" + (type === M.type ? " on" : ""));
    b.type = "button";
    b.innerHTML = '<span class="sw" style="background:' + (d.colour || "#888") + '"></span>' +
                  '<span class="push">' + d.label + '</span>' +
                  ((d.models || d.parts) ? '<span class="dim">✎</span>' : '');
    b.addEventListener("click", () => {
      if (M.dirty && !confirm("Discard unsaved changes to " + currentDef().label + "?")) return;
      loadType(type, 1);
    });
    host.appendChild(b);
  });

  if (Object.keys(DB.PART_PRESETS).length){
    host.appendChild(el("h4", null, "Saved parts"));
    Object.keys(DB.PART_PRESETS).forEach(id => {
      const pr = DB.PART_PRESETS[id];
      const b = el("button", "modrow");
      b.type = "button";
      b.innerHTML = '<span class="sw" style="background:' + (pr.parts[0] && pr.parts[0].colour || "#888") + '"></span>' +
                    '<span class="push">' + pr.label + '</span><span class="dim">+</span>';
      b.title = "Insert this part";
      b.addEventListener("click", () => {
        const added = clone(pr.parts);
        added.forEach(p => { p.name = (p.name || pr.label); });
        const from = M.parts.length;
        M.parts = M.parts.concat(added);
        M.sel = added.map((_, i) => from + i);
        M.dirty = true;
        refresh();
      });
      host.appendChild(b);
    });
  }
}

/* ═══ right rail: parts + fields ═════════════════════════════ */
function textField(label, obj, key, placeholder){
  const row = el("div", "pfield");
  row.appendChild(el("label", null, label));
  const inp = el("input");
  inp.type = "text";
  inp.value = obj[key] === undefined ? "" : obj[key];
  if (placeholder) inp.placeholder = placeholder;
  inp.addEventListener("input", () => { obj[key] = inp.value; M.dirty = true; });
  row.appendChild(inp);
  return row;
}
function num(label, obj, key, step, after){
  const row = el("div", "pfield");
  row.appendChild(el("label", null, label));
  const inp = el("input");
  inp.type = "number"; inp.step = step || .1;
  inp.value = obj[key] === undefined ? "" : obj[key];
  inp.addEventListener("input", () => {
    const v = parseFloat(inp.value);
    obj[key] = isNaN(v) ? undefined : v;
    M.dirty = true;
    if (after) after(); else rebuildPreview();
  });
  row.appendChild(inp);
  return row;
}
function triple(label, obj, keys, after){
  const row = el("div", "pfield");
  row.appendChild(el("label", null, label));
  const g = el("div", "pgrid3");
  keys.forEach(k => {
    const inp = el("input");
    inp.type = "number"; inp.step = .1; inp.title = k;
    inp.value = obj[k] === undefined ? (k[0] === "s" ? 1 : 0) : obj[k];
    inp.addEventListener("input", () => {
      const v = parseFloat(inp.value);
      obj[k] = isNaN(v) ? (k[0] === "s" ? 1 : 0) : v;
      M.dirty = true;
      if (after) after(); else rebuildPreview();
    });
    g.appendChild(inp);
  });
  row.appendChild(g);
  return row;
}

function renderParts(){
  const host = $("mod-parts");
  host.innerHTML = "";
  const def = currentDef();
  if (!def){ host.appendChild(el("p","hint","Pick a building.")); return; }

  /* ── tiers ── */
  const tierBar = el("div", "pfield");
  tierBar.appendChild(el("label", null, "tier"));
  const tsel = el("select");
  for (let i = 1; i <= Math.max(1, def.tiers || 1); i++){
    const o = el("option", null, "Tier " + i + ((def.models && def.models[i]) ? " ✎" : ""));
    o.value = i;
    if (i === M.tier) o.selected = true;
    tsel.appendChild(o);
  }
  tsel.addEventListener("change", () => {
    if (M.dirty && !confirm("Discard unsaved changes to tier " + M.tier + "?")) { tsel.value = M.tier; return; }
    loadType(M.type, +tsel.value);
  });
  tierBar.appendChild(tsel);
  host.appendChild(tierBar);
  host.appendChild(num("how many tiers", def, "tiers", 1, () => renderParts()));

  /* ── building metadata ── */
  host.appendChild(el("h4", null, "Building"));
  host.appendChild(textField("icon dir", def, "iconDir", "art/icons/hut.png"));
  host.appendChild(textField("prefab dir", def, "prefabDir", "Prefabs/Hut.prefab"));
  host.appendChild(textField("description", def, "description", "Shown in the dossier"));
  host.appendChild(textField("tooltip", def, "tooltip", "Shown on hover"));

  /* ── modes ── */
  host.appendChild(el("h4", null, "Mode"));
  const modeRow = el("div", "modebar");
  ["object","vertex","edge","face"].forEach(m => {
    const b = el("button", "tbtn" + (M.editMode === m ? " on" : ""), m);
    b.type = "button";
    b.setAttribute("aria-pressed", String(M.editMode === m));
    b.addEventListener("click", () => { M.editMode = m; M.faceSel = []; refresh(); });
    modeRow.appendChild(b);
  });
  host.appendChild(modeRow);

  const gizRow = el("div", "modebar");
  ["none","move","rotate","scale"].forEach(m => {
    const b = el("button", "tbtn" + (M.gizmoMode === m ? " on" : ""), m);
    b.type = "button";
    b.setAttribute("aria-pressed", String(M.gizmoMode === m));
    b.addEventListener("click", () => { M.gizmoMode = m; rebuildPreview(); renderParts(); });
    gizRow.appendChild(b);
  });
  host.appendChild(gizRow);

  if (M.editMode === "face"){
    const fbar = el("div", "erow-btns");
    const delF = el("button", "tbtn warn", "Delete faces (" + M.faceSel.length + ")");
    delF.type = "button";
    delF.addEventListener("click", deleteSelectedFaces);
    const loop = el("button", "tbtn", "Insert edge loop");
    loop.type = "button";
    loop.addEventListener("click", insertEdgeLoop);
    fbar.appendChild(delF); fbar.appendChild(loop);
    host.appendChild(fbar);
  }

  /* ── collider ── */
  host.appendChild(el("h4", null, "Collider"));
  const cbar = el("div", "erow-btns");
  const ctog = el("button", "tbtn" + (M.showCollider ? " on" : ""), M.showCollider ? "Hide collider" : "Show collider");
  ctog.type = "button";
  ctog.addEventListener("click", () => { M.showCollider = !M.showCollider; rebuildPreview(); renderParts(); });
  const cfit = el("button", "tbtn", "Fit to model");
  cfit.type = "button";
  cfit.addEventListener("click", fitCollider);
  cbar.appendChild(ctog); cbar.appendChild(cfit);
  host.appendChild(cbar);
  if (M.showCollider){
    const upd = () => { if (M.colliderMesh) E.setCollider(M.colliderMesh, def.collider); };
    host.appendChild(triple("size", def.collider, ["w","h","d"], upd));
    host.appendChild(triple("pos",  def.collider, ["x","y","z"], upd));
    host.appendChild(triple("rot",  def.collider, ["rx","ry","rz"], upd));
  }

  /* ── the parts hierarchy ── */
  host.appendChild(el("h4", null, "Parts · " + M.parts.length + (M.sel.length ? " · " + M.sel.length + " selected" : "")));
  const bar = el("div", "erow-btns");
  const add = el("button", "tbtn", "+ Add");
  add.type = "button";
  add.addEventListener("click", () => {
    M.parts.push({shape:"box", name:"part " + M.parts.length, w:2, h:2, d:2, x:0, y:1, z:0, colour:"#8A93AC"});
    M.sel = [M.parts.length - 1];
    M.dirty = true; refresh();
  });
  const impObj = el("button", "tbtn", "Import OBJ");
  impObj.type = "button";
  impObj.addEventListener("click", () => $("mod-objfile").click());
  const savePart = el("button", "tbtn", "Save new part");
  savePart.type = "button";
  savePart.disabled = !M.sel.length;
  savePart.addEventListener("click", saveSelectionAsPart);
  bar.appendChild(add); bar.appendChild(impObj); bar.appendChild(savePart);
  host.appendChild(bar);

  const list = el("div", "partlist");
  M.parts.forEach((p, i) => {
    const on = M.sel.indexOf(i) >= 0;
    const r = el("div", "modrow" + (on ? " on" : ""));
    r.innerHTML = '<span class="sw" style="background:' + (p.colour || "#888") + '"></span>';
    const nameBtn = el("span", "push", p.name || p.shape);
    nameBtn.title = "Click to select · shift-click to add · double-click to rename";
    nameBtn.addEventListener("click", ev => {
      if (ev.shiftKey){
        const at = M.sel.indexOf(i);
        if (at >= 0) M.sel.splice(at, 1); else M.sel.push(i);
      } else M.sel = [i];
      refresh();
    });
    nameBtn.addEventListener("dblclick", ev => {
      ev.stopPropagation();
      const n = prompt("Name this part:", p.name || p.shape);
      if (n){ p.name = n; M.dirty = true; renderParts(); }
    });
    r.appendChild(nameBtn);
    const eye = el("span", "dim", p.hidden ? "○" : "●");
    eye.style.cursor = "pointer";
    eye.title = "Show / hide";
    eye.addEventListener("click", ev => { ev.stopPropagation(); p.hidden = !p.hidden; M.dirty = true; refresh(); });
    r.appendChild(eye);
    list.appendChild(r);
  });
  host.appendChild(list);

  /* ── the selected part's fields ── */
  if (M.sel.length > 1){
    host.appendChild(el("p", "hint", "<b>" + M.sel.length + " parts selected.</b> The gizmo moves, turns and scales them together. Fields below edit the first."));
  }
  const p = M.parts[M.sel[0]];
  if (!p) return;

  host.appendChild(el("h4", null, "Part"));
  host.appendChild(textField("name", p, "name"));

  const shapeRow = el("div", "pfield");
  shapeRow.appendChild(el("label", null, "shape"));
  const sel = el("select");
  E.shapeNames.forEach(s => {
    const o = el("option", null, s); o.value = s;
    if (s === p.shape) o.selected = true;
    sel.appendChild(o);
  });
  sel.addEventListener("change", () => { p.shape = sel.value; M.dirty = true; refresh(); });
  shapeRow.appendChild(sel);
  host.appendChild(shapeRow);

  const S = p.shape;
  if (S === "box" || S === "plane" || S === "wedge"){
    host.appendChild(num("width", p, "w"));
    host.appendChild(num("height", p, "h"));
    if (S !== "plane") host.appendChild(num("depth", p, "d"));
    host.appendChild(triple("segments", p, ["segX","segY","segZ"]));
  } else if (S === "cylinder"){
    host.appendChild(num("top r", p, "rt"));
    host.appendChild(num("base r", p, "rb"));
    host.appendChild(num("height", p, "h"));
    host.appendChild(num("sides", p, "seg", 1));
  } else if (S === "cone" || S === "capsule"){
    host.appendChild(num("radius", p, "r"));
    host.appendChild(num("height", p, "h"));
    host.appendChild(num("sides", p, "seg", 1));
  } else if (S === "torus" || S === "torusKnot"){
    host.appendChild(num("radius", p, "r"));
    host.appendChild(num("tube", p, "tube"));
    host.appendChild(num("sides", p, "seg", 1));
  } else if (S === "ring"){
    host.appendChild(num("inner r", p, "rt"));
    host.appendChild(num("outer r", p, "r"));
    host.appendChild(num("sides", p, "seg", 1));
  } else if (S === "mesh"){
    host.appendChild(el("p", "hint", "Imported geometry · " + ((p.verts||[]).length/9|0) + " triangles"));
  } else {
    host.appendChild(num("radius", p, "r"));
    host.appendChild(num("detail", p, "detail", 1));
  }

  host.appendChild(el("h4", null, "Transform"));
  host.appendChild(triple("pos", p, ["x","y","z"]));
  host.appendChild(triple("rot", p, ["rx","ry","rz"]));
  host.appendChild(triple("scale", p, ["sx","sy","sz"]));

  host.appendChild(el("h4", null, "Look"));
  const cRow = el("div", "pfield");
  cRow.appendChild(el("label", null, "colour"));
  const col = el("input");
  col.type = "color"; col.value = (p.colour || "#8a93ac").slice(0,7);
  col.addEventListener("input", () => {
    (M.sel.length > 1 ? M.sel : [M.sel[0]]).forEach(i => M.parts[i].colour = col.value);
    M.dirty = true; refresh();
  });
  cRow.appendChild(col);
  host.appendChild(cRow);
  host.appendChild(num("opacity", p, "opacity", .05));

  const boolRow = (label, key) => {
    const r = el("div", "pfield");
    r.appendChild(el("label", null, label));
    const c = el("input"); c.type = "checkbox"; c.checked = !!p[key];
    c.addEventListener("change", () => {
      (M.sel.length > 1 ? M.sel : [M.sel[0]]).forEach(i => M.parts[i][key] = c.checked);
      M.dirty = true; refresh();
    });
    r.appendChild(c);
    return r;
  };
  host.appendChild(boolRow("glows", "glow"));
  host.appendChild(boolRow("casts light", "light"));
  if (p.light){
    host.appendChild(num("light range", p, "lightRange", 1));
    host.appendChild(num("light power", p, "lightPower", .1));
  }
  host.appendChild(num("min tier", p, "minTier", 1));

  const btns = el("div", "erow-btns");
  const dup = el("button", "tbtn", "Duplicate");
  dup.type = "button";
  dup.addEventListener("click", () => {
    const copies = M.sel.map(i => { const c = clone(M.parts[i]); c.x = (c.x||0)+1; return c; });
    const from = M.parts.length;
    M.parts = M.parts.concat(copies);
    M.sel = copies.map((_, i) => from + i);
    M.dirty = true; refresh();
  });
  const del = el("button", "tbtn warn", "Delete");
  del.type = "button";
  del.addEventListener("click", deleteSelectedParts);
  btns.appendChild(dup); btns.appendChild(del);
  host.appendChild(btns);
}

function deleteSelectedParts(){
  if (!M.sel.length) return;
  M.parts = M.parts.filter((_, i) => M.sel.indexOf(i) < 0);
  M.sel = [];
  M.dirty = true; refresh();
}

/* ═══ face editing ═══════════════════════════════════════════
   Primitives are baked to a raw triangle "mesh" part the first time you
   cut into them, after which faces can be deleted individually. */
function bakeToMesh(idx){
  const p = M.parts[idx];
  if (p.shape === "mesh") return p;
  const geo = (E.SHAPES[p.shape] || E.SHAPES.box)(p);
  const nonIdx = geo.index ? geo.toNonIndexed() : geo;
  const pos = nonIdx.attributes.position.array;
  const baked = {
    shape:"mesh", name:(p.name || p.shape) + " (mesh)",
    verts:Array.from(pos).map(v => +v.toFixed(4)),
    x:p.x, y:p.y, z:p.z, rx:p.rx, ry:p.ry, rz:p.rz,
    sx:p.sx, sy:p.sy, sz:p.sz,
    colour:p.colour, glow:p.glow, opacity:p.opacity,
    light:p.light, lightRange:p.lightRange, lightPower:p.lightPower, minTier:p.minTier
  };
  M.parts[idx] = baked;
  geo.dispose();
  return baked;
}

function deleteSelectedFaces(){
  if (!M.faceSel.length) return;
  const byPart = {};
  M.faceSel.forEach(k => {
    const [pi, fi] = k.split(":").map(Number);
    (byPart[pi] = byPart[pi] || []).push(fi);
  });
  Object.keys(byPart).forEach(key => {
    const pi = +key;
    const p = bakeToMesh(pi);
    const drop = byPart[pi].slice().sort((a,b) => b-a);
    drop.forEach(fi => { p.verts.splice(fi*9, 9); });
  });
  M.faceSel = [];
  M.dirty = true; refresh();
  W.logMsg('<span class="t">✎</span> Faces removed.');
}

/* A loop cut: raise the segment count along an axis so the primitive
   gains a ring of new edges. On baked meshes each selected triangle is
   split at its midpoints instead. */
function insertEdgeLoop(){
  if (!M.sel.length){ alert("Select a part first."); return; }
  M.sel.forEach(i => {
    const p = M.parts[i];
    if (p.shape === "mesh"){
      // subdivide every triangle once
      const v = p.verts, out = [];
      for (let k = 0; k < v.length; k += 9){
        const A = v.slice(k,k+3), B = v.slice(k+3,k+6), C = v.slice(k+6,k+9);
        const mid = (a,b) => [(a[0]+b[0])/2, (a[1]+b[1])/2, (a[2]+b[2])/2];
        const AB = mid(A,B), BC = mid(B,C), CA = mid(C,A);
        out.push(...A,...AB,...CA, ...AB,...B,...BC, ...CA,...BC,...C, ...AB,...BC,...CA);
      }
      p.verts = out.map(n => +n.toFixed(4));
    } else {
      p.segY = Math.max(1, (p.segY || 1) + 1);
      if (p.shape === "box" || p.shape === "plane") p.segX = Math.max(1, (p.segX || 1) + 1);
    }
  });
  M.dirty = true; refresh();
  W.logMsg('<span class="t">✎</span> Edge loop inserted.');
}

/* ═══ compound parts ═════════════════════════════════════════ */
function saveSelectionAsPart(){
  if (!M.sel.length) return;
  const suggested = M.parts[M.sel[0]].name || "part";
  const name = prompt("Name for this part (" + M.sel.length + " piece" + (M.sel.length>1?"s":"") + "):", suggested);
  if (!name) return;
  const id = name.replace(/\W+/g, "_").toLowerCase();
  // recentre the group on its own origin so it drops in cleanly
  const c = selectionCentre();
  const parts = M.sel.map(i => {
    const p = clone(M.parts[i]);
    p.x = +((p.x||0) - c.x).toFixed(3);
    p.y = +((p.y||0) - c.y).toFixed(3);
    p.z = +((p.z||0) - c.z).toFixed(3);
    return p;                       // colour, glow and light all ride along
  });
  DB.PART_PRESETS[id] = {label:name, parts};
  W.logMsg('<span class="t">✎</span> Saved part <b>' + name + '</b> — ' + parts.length +
           ' piece' + (parts.length>1?'s':'') + ', reusable from the left rail.');
  renderList();
}

/* ═══ collider ═══════════════════════════════════════════════ */
function fitCollider(){
  const def = currentDef();
  if (!def || !M.parts.length) return;
  const g = new T.Group();
  M.parts.forEach(p => { if (!p.hidden) g.add(E.makePart(p)); });
  const box = new T.Box3().setFromObject(g);
  const size = box.getSize(new T.Vector3()), mid = box.getCenter(new T.Vector3());
  def.collider = {
    w:+size.x.toFixed(2), h:+size.y.toFixed(2), d:+size.z.toFixed(2),
    x:+mid.x.toFixed(2), y:+mid.y.toFixed(2), z:+mid.z.toFixed(2), rx:0, ry:0, rz:0
  };
  g.traverse(o => { if (o.geometry) o.geometry.dispose(); });
  M.dirty = true;
  if (!M.showCollider) M.showCollider = true;
  refresh();
}

/* ═══ saving ═════════════════════════════════════════════════ */
function saveToType(){
  const def = currentDef();
  if (!def) return;
  def.models = def.models || {};
  def.models[M.tier] = clone(M.parts);
  if (M.tier === 1) def.parts = clone(M.parts);
  M.dirty = false;
  let n = 0;
  W.buildings.filter(b => b.type === M.type).forEach(b => {
    E.scene.remove(b.mesh);
    const p = W.pickables.indexOf(b.mesh); if (p >= 0) W.pickables.splice(p, 1);
    const mesh = E.makeBuilding(b.type, b.tier, b.enemy);
    mesh.position.set(b.x, 0, b.z);
    mesh.userData.entity = b;
    E.scene.add(mesh);
    b.mesh = mesh;
    W.pickables.push(mesh);
    n++;
  });
  W.applyAlignmentVisual();
  W.logMsg('<span class="t">✎</span> <b>' + def.label + '</b> tier ' + M.tier +
           ' saved — ' + n + ' rebuilt on the map.');
  refresh();
}

function newType(){
  const id = prompt("Id for the new building (no spaces):", "myBuilding");
  if (!id) return;
  if (DB.BUILDINGS[id]){ alert("That id already exists."); return; }
  const base = currentDef() || DB.BUILDINGS.hut;
  DB.BUILDINGS[id] = clone(base);
  DB.BUILDINGS[id].label = id;
  DB.BUILDINGS[id].models = {1:clone(M.parts)};
  DB.BUILDINGS[id].parts = clone(M.parts);
  W.logMsg('<span class="t">✎</span> New building type <b>' + id + '</b> created.');
  if (UI.rebuildPanels) UI.rebuildPanels();
  loadType(id, 1);
}

/* ═══ open / close ═══════════════════════════════════════════ */
UI.toggleModeller = function (force){
  const panel = $("modeller");
  if (!panel) return;
  const open = force === undefined ? panel.hidden : force;
  panel.hidden = !open;
  M.open = open;
  if (open){
    initView();
    if (!M.type) loadType(Object.keys(DB.BUILDINGS)[0], 1);
    else refresh();
    if (!M.raf) M.raf = requestAnimationFrame(frame);
  }
};

M.init = function (){
  const on = (id, ev, fn) => { const n = $(id); if (n) n.addEventListener(ev, fn); };
  on("btn-modeller", "click", () => UI.toggleModeller());
  on("modeller-close", "click", () => UI.toggleModeller(false));
  on("mod-save", "click", saveToType);
  on("mod-newtype", "click", newType);
  on("mod-revert", "click", () => {
    const def = currentDef();
    if (!def) return;
    if (def.models) delete def.models[M.tier];
    if (M.tier === 1) delete def.parts;
    loadType(M.type, M.tier);
    W.logMsg('<span class="dim">Reverted ' + def.label + ' tier ' + M.tier + '.</span>');
  });
  on("mod-push", "click", async () => {
    if (!global.NET || !global.NET.online){ alert("Serve the game from godsim.php to save models to MySQL."); return; }
    try { await global.NET.saveModels(); }
    catch (e){ alert(e.message); }
  });
  on("mod-pull", "click", async () => {
    if (!global.NET || !global.NET.online){ alert("Serve the game from godsim.php to load models from MySQL."); return; }
    try { await global.NET.loadModels(); loadType(M.type || Object.keys(DB.BUILDINGS)[0], 1); }
    catch (e){ alert(e.message); }
  });
  on("mod-objfile", "change", ev => {
    const f = ev.target.files[0];
    if (!f) return;
    const rd = new FileReader();
    rd.onload = () => {
      try {
        const r = E.parseOBJ(rd.result);
        M.parts.push({shape:"mesh", name:f.name.replace(/\.obj$/i,""), verts:r.verts,
                      x:0, y:0, z:0, colour:"#9AA3B8"});
        M.sel = [M.parts.length-1];
        M.dirty = true; refresh();
        W.logMsg('<span class="t">✎</span> Imported <b>' + f.name + '</b> — ' + r.tris + ' triangles.');
      } catch (e){ alert("Could not read that OBJ: " + e.message); }
      ev.target.value = "";
    };
    rd.readAsText(f);
  });

  addEventListener("keydown", ev => {
    if (!M.open) return;
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(ev.target.tagName)) return;
    const k = ev.key.toLowerCase();
    if (k === "delete" || k === "backspace"){
      ev.preventDefault();
      if (M.editMode === "face" && M.faceSel.length) deleteSelectedFaces();
      else deleteSelectedParts();
    }
    if (k === "q") { M.gizmoMode = "none";   rebuildPreview(); renderParts(); }
    if (k === "w") { M.gizmoMode = "move";   rebuildPreview(); renderParts(); }
    if (k === "e") { M.gizmoMode = "rotate"; rebuildPreview(); renderParts(); }
    if (k === "r") { M.gizmoMode = "scale";  rebuildPreview(); renderParts(); }
    if (k === "a" && ev.ctrlKey){ ev.preventDefault(); M.sel = M.parts.map((_, i) => i); refresh(); }
  });
};

M.saveToType = saveToType;
global.MODELLER = M;
})(window);
/* ===== main.js ===== */
/* ═══════════════════════════════════════════════════════════════
   SOVEREIGN AEGIS — MAIN
   Boot, the god-hand's input grammar, and the frame loop.
   ═══════════════════════════════════════════════════════════════ */
(function (global) {
"use strict";

const T = global.THREE, DB = global.DB, E = global.ENGINE, W = global.SIM, UI = global.UI;
const MAIN = {ghost:null};
global.MAIN = MAIN;   // published first: a later UI fault must not hide the loop

/* ── saved tuning ────────────────────────────────────────────── */
try {
  const saved = localStorage.getItem("aegis-scenario");
  if (saved){
    const j = JSON.parse(saved);
    if (j.map) Object.assign(DB.MAP, j.map);
    if (j.tuning) Object.assign(DB.TUNING, j.tuning);
    if (j.classes) Object.assign(DB.CLASSES, j.classes);
    if (j.buildings) Object.assign(DB.BUILDINGS, j.buildings);
  }
} catch (e){ console.warn("Saved scenario ignored:", e.message); }

/* ── build ghost (defined before boot: UI.init calls it) ─────── */
MAIN.updateGhost = function (){
  if (MAIN.ghost){ E.scene.remove(MAIN.ghost); MAIN.ghost = null; }
  const t = UI.tool;
  if (!E.scene) return;
  if (t && t.kind === "build"){
    MAIN.ghost = E.makeGhost(t.type);
    E.scene.add(MAIN.ghost);
  } else if (t && t.kind === "spell"){
    MAIN.ghost = E.makeRing(DB.SPELLS[t.type].colour, DB.SPELLS[t.type].radius);
    E.scene.add(MAIN.ghost);
  }
};

/* ── boot ────────────────────────────────────────────────────── */
E.init(document.getElementById("viewport"));
W.buildWorld();
try { UI.init(); }
catch (e){ console.error("UI failed to initialise — the world still runs:", e); }
try { if (global.NET) global.NET.init(); }
catch (e){ console.error("Account panel unavailable:", e); }
try { if (global.MODELLER) global.MODELLER.init(); }
catch (e){ console.error("Building modeller unavailable:", e); }
E.focusOn(W.villageCentre.x + 6, W.villageCentre.z, DB.TUNING.camera.startDist);
W.applyAlignmentVisual();

function placementValid(type, x, z){
  const d = DB.BUILDINGS[type];
  if (!W.afford(d.cost)) return false;
  if (x > 14) return false;                       // not on the monsters' ground
  const clashB = W.buildings.some(b =>
    Math.abs(b.x-x) < (b.def.w + d.w)/2 && Math.abs(b.z-z) < (b.def.d + d.d)/2);
  if (clashB) return false;
  const clashN = W.nodes.some(n => n.amount > 0 && Math.hypot(n.x-x, n.z-z) < Math.max(d.w,d.d)/2 + .8);
  return !clashN;
}

/* ═══ input grammar ═══════════════════════════════════════════
   LEFT   on terrain  — drag to pan the camera
   LEFT   on a thing  — click to select; drag across the creature to pet it
   RIGHT  on a thing  — hold to grab it in the hand, release moving to throw
   MIDDLE / space+drag — orbit          wheel — zoom
   ═══════════════════════════════════════════════════════════ */
const press = {active:false, btn:0, ent:null, t0:0, sx:0, sy:0, grabbed:false, panning:false,
               vx:0, vz:0, lastX:0, lastZ:0, creature:false, slapT:0, samples:[]};
let paintLast = null;

/* World-space cursor velocity over the last `window` ms, in units/second.
   Returns {vx, vz, speed}. Zero if the hand has been still. */
const THROW_WINDOW = 110;
function releaseVelocity(){
  const s = press.samples;
  const now = performance.now();
  if (s.length < 2) return {vx:0, vz:0, speed:0};
  const last = s[s.length-1];
  // a pause before letting go means a deliberate drop, not a throw
  if (now - last.t > THROW_WINDOW) return {vx:0, vz:0, speed:0};
  let first = s[0];
  for (let i = s.length-1; i >= 0; i--){
    if (last.t - s[i].t <= THROW_WINDOW){ first = s[i]; } else break;
  }
  const dt = (last.t - first.t) / 1000;
  if (dt <= 0.001) return {vx:0, vz:0, speed:0};
  const vx = (last.x - first.x) / dt;
  const vz = (last.z - first.z) / dt;
  return {vx, vz, speed:Math.hypot(vx, vz)};
}

function entityAt(){
  const hit = E.pick(W.pickables);
  if (!hit) return null;
  let o = hit.object;
  while (o && !o.userData.entity) o = o.parent;
  return o ? o.userData.entity : null;
}

E.onPointer.down = function (ev){
  const t = UI.tool;
  const cw = E.cursorWorld;

  /* right button is the hand — it grabs, and nothing else */
  if (ev.button === 2){
    const ent = entityAt();
    press.active = true; press.btn = 2; press.ent = ent; press.t0 = performance.now();
    press.sx = E.screen.x; press.sy = E.screen.y;
    press.grabbed = false; press.panning = false; press.creature = false;
    press.lastX = cw.x; press.lastZ = cw.z; press.vx = 0; press.vz = 0;
    if (ent) W.grab(ent), press.grabbed = !!W.held;
    return;
  }
  if (ev.button !== 0) return;

  if (t){
    if (t.kind === "build"){
      const d = DB.BUILDINGS[t.type];
      const snap = v => Math.round(v/2)*2;
      const x = snap(cw.x), z = snap(cw.z);
      if (!placementValid(t.type, x, z)){
        W.logMsg('<span class="r">!</span> Cannot raise a ' + d.label.toLowerCase() + ' there.');
        return;
      }
      W.pay(d.cost);
      W.placeBuilding(t.type, x, z, {instant:d.work === 0});
      if (d.work > 0) W.logMsg('<span class="t">▣</span> ' + d.label + ' site marked — builders needed.');
      paintLast = {x, z};
      if (t.type !== "wall" && t.type !== "gate") UI.setTool(null);
      UI.rebuildPanels();
      return;
    }
    if (t.kind === "flag"){
      let attach = null;
      const ent = entityAt();
      // a follow flag dropped on something moving pins itself to it
      if (t.type === "follow" && ent &&
          (ent.isCart || ent.family === "folk" || ent === W.creature ||
           ent.family === "hero" || ent.family === "soldier")) attach = ent;
      W.addFlag(t.type, cw.x, cw.z, UI.prices[t.type], attach);
      UI.setTool(null);
      UI.rebuildPanels();
      return;
    }
    if (t.kind === "banner"){
      W.moveBanner(t.squad, cw.x, cw.z);
      UI.setTool(null);
      return;
    }
    if (t.kind === "spell"){
      W.castSpell(t.type, cw.x, cw.z);
      UI.setTool(null);
      return;
    }
  }

  const ent = entityAt();
  press.active = true; press.btn = 0; press.ent = ent; press.t0 = performance.now();
  press.sx = E.screen.x; press.sy = E.screen.y; press.grabbed = false;
  press.creature = !!(W.creature && ent === W.creature);
  press.panning = !ent;                       // empty terrain: this drag moves the camera
  press.lastX = cw.x; press.lastZ = cw.z; press.vx = 0; press.vz = 0;
  press.samples = [{x:cw.x, z:cw.z, t:press.t0}];
  press.pathLen = 0; press.peakSpeed = 0; press.lastMoveT = press.t0; press.petted = false;
};

E.onPointer.move = function (ev){
  const cw = E.cursorWorld;

  // the hand tracks the cursor at all times
  W.hand.position.set(cw.x, (W.held ? 3.4 : 6.2) + Math.sin(W.time*1.6)*.18, cw.z);
  W.hand.rotation.y = E.cam.yaw;

  if (UI.tool && UI.tool.kind === "build" && MAIN.ghost){
    const snap = v => Math.round(v/2)*2;
    const x = snap(cw.x), z = snap(cw.z);
    MAIN.ghost.position.set(x, 0, z);
    const ok = placementValid(UI.tool.type, x, z);
    const col = ok ? "#46988C" : "#C8504A";
    MAIN.ghost.userData.body.material.color.set(col);
    MAIN.ghost.userData.ring.material.color.set(col);
    // drag-paint wall runs
    if (press.active && (UI.tool.type === "wall" || UI.tool.type === "gate") && ok){
      if (!paintLast || Math.hypot(paintLast.x-x, paintLast.z-z) >= 2){
        const d = DB.BUILDINGS[UI.tool.type];
        if (W.afford(d.cost)){
          W.pay(d.cost);
          W.placeBuilding(UI.tool.type, x, z, {instant:d.work === 0});
          paintLast = {x, z};
        }
      }
    }
    return;
  }
  if (UI.tool && UI.tool.kind === "spell" && MAIN.ghost) MAIN.ghost.position.set(cw.x, .14, cw.z);

  if (!press.active) return;

  // left-drag on bare ground drags the map under the cursor
  if (press.panning && press.btn === 0){
    if (E.drag) E.panBy(E.drag.dx, E.drag.dy);
    return;
  }

  /* Sample the cursor's path over the ground with timestamps. At release
     we look only at the last ~110ms: if the hand was still, the thing is
     dropped straight down; if it was moving, it leaves at that speed and
     in that direction. */
  press.samples.push({x:cw.x, z:cw.z, t:performance.now()});
  if (press.samples.length > 12) press.samples.shift();
  press.lastX = cw.x; press.lastZ = cw.z;

  /* Creature handling is measured in SCREEN pixels, not world units —
     world deltas scale with zoom, so a stroke that read as a slap when
     zoomed out read as nothing at all when zoomed in. */
  const now = performance.now();
  const stepPx = E.drag ? Math.hypot(E.drag.dx, E.drag.dy) : 0;
  const stepMs = Math.max(1, now - (press.lastMoveT || press.t0));
  press.lastMoveT = now;
  const pxPerMs = stepPx / stepMs;
  press.peakSpeed = Math.max(press.peakSpeed || 0, pxPerMs);
  press.pathLen = (press.pathLen || 0) + stepPx;

  if (press.creature && press.btn === 0){
    // every stroke across it counts as a stroke
    if (press.pathLen > 55 && now - press.t0 > 140){
      W.petCreature();
      press.pathLen = 0;
      press.petted = true;
    }
  }
};

E.onPointer.up = function (ev){
  if (!press.active) return;
  const wasBtn = press.btn;
  press.active = false;
  paintLast = null;
  const held = performance.now() - press.t0;
  const drag = Math.hypot(E.screen.x - press.sx, E.screen.y - press.sy);

  if (wasBtn === 2){
    if (press.grabbed){ const v = releaseVelocity(); W.release(v.vx, v.vz); press.grabbed = false; }
    press.panning = false;
    return;
  }
  if (press.panning){ press.panning = false; return; }

  if (press.creature){
    const fast = (press.peakSpeed || 0) > 1.35;        // px per ms — a real flick
    const total = (press.pathLen || 0) + drag;
    if (fast && total > 40){ W.slapCreature(); }
    else if (held > 550 && total < 26){ W.hugCreature(); }
    else if (press.petted){ /* already stroked on the way through */ }
    else if (total < 10){ W.selected = W.creature; }
    press.creature = false; press.petted = false;
    return;
  }
  if (drag < 8){
    W.selected = press.ent || null;
    if (press.ent && press.ent.units && press.ent.banner)
      UI.setTool({kind:"banner", squad:press.ent, key:"banner:"+press.ent.id});
  }
};

E.onPointer.dbl = function (){
  const ent = entityAt();
  if (ent === W.creature){
    W.leash.attached = W.leash.attached ? null : W.creature;
    W.creature.lastThought = 0;
    W.creature.thought = W.leash.attached ? "Pulled again." : "Free.";
    W.logMsg(W.leash.attached ? '<span class="g">⚯</span> The leash takes hold.' : '<span class="t">⚯</span> The leash falls away.');
    return;
  }
  if (ent && ent.x !== undefined) E.focusOn(ent.x, ent.z);
};

/* ── keyboard ────────────────────────────────────────────────── */
addEventListener("keydown", ev => {
  if (ev.target && /^(INPUT|TEXTAREA|SELECT)$/.test(ev.target.tagName)) return;
  const k = ev.key;
  if (k === "Escape"){ UI.setTool(null); UI.toggleEditor(false); return; }
  if ((ev.ctrlKey || ev.metaKey) && k.toLowerCase() === "e"){ ev.preventDefault(); UI.toggleEditor(); return; }
  const spellId = Object.keys(DB.SPELLS).find(id => DB.SPELLS[id].key === k);
  if (spellId){ W.castSpell(spellId, E.cursorWorld.x, E.cursorWorld.z); return; }
  if (k.toLowerCase() === "l"){
    W.leash.attached = W.leash.attached ? null : W.creature;
    return;
  }
  if (k === "[" ) { W.speed = Math.max(1, W.speed/2); document.getElementById("btn-speed").textContent = "×" + W.speed; }
  if (k === "]" ) { W.speed = Math.min(4, W.speed*2); document.getElementById("btn-speed").textContent = "×" + W.speed; }
  const fk = Object.keys(DB.FLAGS).find(f => DB.FLAGS[f].key === k.toUpperCase());
  if (fk && ev.shiftKey){ UI.setTool({kind:"flag", type:fk, key:"flag:"+fk}); }
});

/* ── hover ───────────────────────────────────────────────────── */
let hoverT = 0;
function updateHover(dt){
  hoverT -= dt;
  if (hoverT > 0) return;
  hoverT = .09;
  if (!E.screen) return;
  const ent = entityAt();
  W.hovered = ent;
  if (ent && ent !== W.held) UI.showTip(ent, E.screen.cx, E.screen.cy);
  else UI.hideTip();
}

/* ── labels over civic buildings ─────────────────────────────── */
const labelHost = document.getElementById("labels");
const labels = new Map();
function updateLabels(){
  const seen = new Set();
  W.buildings.forEach(b => {
    if (!b.def.civic || b.def.blocks) return;
    if (Math.hypot(b.x - E.cam.target.x, b.z - E.cam.target.z) > 70) return;
    seen.add(b.id);
    let n = labels.get(b.id);
    if (!n){
      n = document.createElement("div");
      n.className = "wlabel";
      labelHost.appendChild(n);
      labels.set(b.id, n);
    }
    const p = E.project(new T.Vector3(b.x, b.def.height*1.02, b.z));
    if (p.behind || E.cam.dist > 86){ n.style.display = "none"; return; }
    n.style.display = "";
    n.style.transform = "translate(-50%,-100%) translate(" + p.x + "px," + p.y + "px)";
    n.innerHTML = b.def.label + (b.built ? '<i>Tier ' + b.tier + '</i>' : '<i class="wip">' + Math.round(b.prog/b.def.work*100) + '%</i>');
  });
  labels.forEach((n, id) => { if (!seen.has(id)){ n.remove(); labels.delete(id); } });
}
W.onReset = function (){
  labels.forEach(n => n.remove());
  labels.clear();
  if (MAIN.ghost){ E.scene.remove(MAIN.ghost); MAIN.ghost = null; }
  press.active = false; press.ent = null; press.grabbed = false; press.panning = false;
};

/* ── loop ────────────────────────────────────────────────────── */
let last = performance.now();
let faults = 0;
function frame(now){
  const dt = Math.min((now - last)/1000, .05);
  last = now;
  try {
    E.updateCamera(dt);
    W.update(dt);
    updateHover(dt);
    updateLabels();
    UI.tick(dt);
    E.render();
  } catch (e){
    // never let one bad frame kill the loop — report it once and carry on
    if (faults++ < 5) console.error("frame fault:", e);
    if (faults === 5) console.error("further frame faults will be suppressed");
  }
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

/* keep the renderer sized to its box even when the page reflows */
if (window.ResizeObserver) new ResizeObserver(() => E.resize()).observe(document.getElementById("viewport"));

global.MAIN = MAIN;
})(window);
