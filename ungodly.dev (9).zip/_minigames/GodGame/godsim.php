<?php
/**
 * ==============================================================================
 * NAMESPACE: RobinHooleProduction
 * CONTEXT: root/godsim.php — Project Sovereign Aegis (god sim)
 * DESCRIPTION: Serves the game and its API. Login mirrors index1.php exactly:
 *              session_start(), $_SESSION['user_id'] / ['username'], a guest
 *              fallback, POST actions register/login/logout, FSG_users, and
 *              password_hash / password_verify. Credentials come from
 *              _private/databaseCredentials.php — never inline.
 * TABLES: FSG_users (shared, read-only here) + FSG_GODSIM_* (see schema.sql)
 * ==============================================================================
 */

declare(strict_types=1);
session_start();

/* -------------------------------------------------------------------------
 * Database — same credential file the rest of the suite uses.
 * ---------------------------------------------------------------------- */
function godsim_db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $credentialsPath = __DIR__ . '/_private/databaseCredentials.php';
    if (!is_file($credentialsPath)) {
        throw new RuntimeException('Missing _private/databaseCredentials.php');
    }
    require $credentialsPath;
    foreach (['dbHost', 'dbUser', 'dbPass', 'dbName'] as $needed) {
        if (!isset(${$needed})) throw new RuntimeException("Missing credential: {$needed}");
    }
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
    return $pdo;
}

function godsim_json(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function godsim_body(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') return $_POST ?: [];
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : ($_POST ?: []);
}

function godsim_text(mixed $v, int $max = 255): string
{
    if (is_bool($v)) return $v ? '1' : '0';
    if (!is_scalar($v)) return '';
    return mb_substr(trim((string)$v), 0, $max);
}

function godsim_num(mixed $v): float
{
    return is_numeric($v) ? (float)$v : 0.0;
}

/* Same policy as index1.php: 8+, one lower, one upper, one digit, one symbol. */
function godsim_password_ok(string $password): bool
{
    return (bool)preg_match('/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z0-9]).{8,}/', $password);
}

/* -------------------------------------------------------------------------
 * Session identity — real user, else a stable guest, exactly as index1.php.
 * ---------------------------------------------------------------------- */
$is_real_user = isset($_SESSION['user_id']);
if (!$is_real_user && !isset($_SESSION['guest_name'])) {
    $_SESSION['guest_name'] = 'Guest_' . random_int(1000, 9999);
}
$player_username = $is_real_user ? ($_SESSION['username'] ?? 'Player') : $_SESSION['guest_name'];

function godsim_current_user_id(): int
{
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
}

function godsim_require_login(): int
{
    $uid = godsim_current_user_id();
    if ($uid <= 0) godsim_json(['ok' => false, 'error' => 'Not logged in.'], 401);
    return $uid;
}

/* -------------------------------------------------------------------------
 * Schema bootstrap — creates the FSG_GODSIM_* tables if they are absent.
 * Mirrors fsgAuth_ensureAccountTables(). Full DDL also lives in schema.sql.
 * ---------------------------------------------------------------------- */
function godsim_ensure_tables(PDO $pdo): void
{
    static $done = false;
    if ($done) return;
    $charset = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_saves (
        id INT NOT NULL AUTO_INCREMENT,
        user_id INT NOT NULL,
        slot TINYINT NOT NULL DEFAULT 1,
        god_name VARCHAR(64) NOT NULL DEFAULT 'Aegis',
        world_name VARCHAR(64) NOT NULL DEFAULT 'Enroth',
        continent_name VARCHAR(64) NOT NULL DEFAULT 'Varda',
        village_name VARCHAR(64) NOT NULL DEFAULT 'Aldermarch',
        creature_kind VARCHAR(32) NOT NULL DEFAULT 'ox',
        creature_name VARCHAR(64) NOT NULL DEFAULT 'The Ox',
        age_index TINYINT NOT NULL DEFAULT 0,
        alignment DECIMAL(6,2) NOT NULL DEFAULT 0.00,
        spell_energy DECIMAL(8,2) NOT NULL DEFAULT 30.00,
        sim_time DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        kills INT NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uniq_FSG_GODSIM_saves_user_slot (user_id, slot),
        KEY idx_FSG_GODSIM_saves_user (user_id, is_active)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_resources (
        save_id INT NOT NULL,
        wood DECIMAL(12,2) NOT NULL DEFAULT 0,
        stone DECIMAL(12,2) NOT NULL DEFAULT 0,
        gold DECIMAL(12,2) NOT NULL DEFAULT 0,
        food DECIMAL(12,2) NOT NULL DEFAULT 0,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (save_id)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_units (
        id BIGINT NOT NULL AUTO_INCREMENT,
        save_id INT NOT NULL,
        runtime_id INT NOT NULL,
        class_key VARCHAR(32) NOT NULL,
        family VARCHAR(16) NOT NULL,
        faction VARCHAR(16) NOT NULL DEFAULT 'player',
        unit_name VARCHAR(64) NOT NULL,
        job VARCHAR(32) NOT NULL DEFAULT 'idle',
        pinned_job TINYINT(1) NOT NULL DEFAULT 0,
        pos_x DECIMAL(9,3) NOT NULL DEFAULT 0,
        pos_z DECIMAL(9,3) NOT NULL DEFAULT 0,
        hp DECIMAL(9,2) NOT NULL DEFAULT 0,
        max_hp DECIMAL(9,2) NOT NULL DEFAULT 0,
        mp DECIMAL(9,2) NOT NULL DEFAULT 0,
        max_mp DECIMAL(9,2) NOT NULL DEFAULT 0,
        gold DECIMAL(10,2) NOT NULL DEFAULT 0,
        owed DECIMAL(10,2) NOT NULL DEFAULT 0,
        gear_step TINYINT NOT NULL DEFAULT 0,
        equip_weapon VARCHAR(32) NULL DEFAULT NULL,
        equip_armour VARCHAR(32) NULL DEFAULT NULL,
        born_at DECIMAL(12,2) NOT NULL DEFAULT 0,
        age_offset DECIMAL(6,2) NOT NULL DEFAULT 20,
        state VARCHAR(24) NOT NULL DEFAULT 'idle',
        PRIMARY KEY (id),
        UNIQUE KEY uniq_FSG_GODSIM_units_save_runtime (save_id, runtime_id),
        KEY idx_FSG_GODSIM_units_save_family (save_id, family)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_unit_skills (
        save_id INT NOT NULL, runtime_id INT NOT NULL,
        skill_key VARCHAR(24) NOT NULL, xp DECIMAL(14,2) NOT NULL DEFAULT 0,
        PRIMARY KEY (save_id, runtime_id, skill_key)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_unit_items (
        save_id INT NOT NULL, runtime_id INT NOT NULL,
        item_key VARCHAR(32) NOT NULL, qty INT NOT NULL DEFAULT 1,
        PRIMARY KEY (save_id, runtime_id, item_key)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_buildings (
        id BIGINT NOT NULL AUTO_INCREMENT,
        save_id INT NOT NULL, runtime_id INT NOT NULL,
        type_key VARCHAR(32) NOT NULL, tier TINYINT NOT NULL DEFAULT 1,
        pos_x DECIMAL(9,3) NOT NULL DEFAULT 0, pos_z DECIMAL(9,3) NOT NULL DEFAULT 0,
        hp DECIMAL(10,2) NOT NULL DEFAULT 0, max_hp DECIMAL(10,2) NOT NULL DEFAULT 0,
        is_built TINYINT(1) NOT NULL DEFAULT 0, progress DECIMAL(9,3) NOT NULL DEFAULT 0,
        wood_in DECIMAL(9,2) NOT NULL DEFAULT 0, wood_need DECIMAL(9,2) NOT NULL DEFAULT 0,
        is_enemy TINYINT(1) NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY uniq_FSG_GODSIM_buildings_save_runtime (save_id, runtime_id)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_nodes (
        id BIGINT NOT NULL AUTO_INCREMENT,
        save_id INT NOT NULL, runtime_id INT NOT NULL,
        flora_key VARCHAR(32) NULL DEFAULT NULL, kind VARCHAR(16) NOT NULL,
        yields VARCHAR(16) NULL DEFAULT NULL,
        pos_x DECIMAL(9,3) NOT NULL DEFAULT 0, pos_z DECIMAL(9,3) NOT NULL DEFAULT 0,
        amount DECIMAL(9,2) NOT NULL DEFAULT 0, max_amount DECIMAL(9,2) NOT NULL DEFAULT 0,
        respawn DECIMAL(9,2) NOT NULL DEFAULT 0, scale DECIMAL(5,3) NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        UNIQUE KEY uniq_FSG_GODSIM_nodes_save_runtime (save_id, runtime_id)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_flags (
        save_id INT NOT NULL, flag_kind VARCHAR(16) NOT NULL,
        pos_x DECIMAL(9,3) NOT NULL DEFAULT 0, pos_z DECIMAL(9,3) NOT NULL DEFAULT 0,
        price INT NOT NULL DEFAULT 0, held_secs DECIMAL(9,2) NOT NULL DEFAULT 0,
        attached_to INT NULL DEFAULT NULL,
        PRIMARY KEY (save_id, flag_kind)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_squads (
        id BIGINT NOT NULL AUTO_INCREMENT,
        save_id INT NOT NULL, runtime_id INT NOT NULL,
        squad_name VARCHAR(32) NOT NULL, colour VARCHAR(9) NOT NULL DEFAULT '#D9A43F',
        banner_x DECIMAL(9,3) NOT NULL DEFAULT 0, banner_z DECIMAL(9,3) NOT NULL DEFAULT 0,
        facing DECIMAL(6,3) NOT NULL DEFAULT 0, engage_range DECIMAL(6,2) NOT NULL DEFAULT 16,
        stance VARCHAR(16) NOT NULL DEFAULT 'hold',
        PRIMARY KEY (id),
        UNIQUE KEY uniq_FSG_GODSIM_squads_save_runtime (save_id, runtime_id)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_research (
        save_id INT NOT NULL, research_key VARCHAR(32) NOT NULL,
        bought_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (save_id, research_key)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_missions (
        id BIGINT NOT NULL AUTO_INCREMENT,
        save_id INT NOT NULL, template_key VARCHAR(32) NOT NULL,
        label VARCHAR(128) NOT NULL, flag_kind VARCHAR(16) NOT NULL,
        progress INT NOT NULL DEFAULT 0, needed INT NOT NULL DEFAULT 1,
        reward_gold INT NOT NULL DEFAULT 0, reward_xp INT NOT NULL DEFAULT 0,
        is_done TINYINT(1) NOT NULL DEFAULT 0, is_failed TINYINT(1) NOT NULL DEFAULT 0,
        PRIMARY KEY (id), KEY idx_FSG_GODSIM_missions_save (save_id)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_creature (
        save_id INT NOT NULL, kind VARCHAR(24) NOT NULL DEFAULT 'ox',
        creature_name VARCHAR(64) NOT NULL DEFAULT 'The Ox',
        pos_x DECIMAL(9,3) NOT NULL DEFAULT 0, pos_z DECIMAL(9,3) NOT NULL DEFAULT 0,
        hp DECIMAL(10,2) NOT NULL DEFAULT 0, max_hp DECIMAL(10,2) NOT NULL DEFAULT 0,
        girth DECIMAL(6,3) NOT NULL DEFAULT 1, fed DECIMAL(10,2) NOT NULL DEFAULT 0,
        hunger DECIMAL(6,2) NOT NULL DEFAULT 0, mood DECIMAL(6,2) NOT NULL DEFAULT 0,
        leashed TINYINT(1) NOT NULL DEFAULT 0,
        PRIMARY KEY (save_id)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_creature_skills (
        save_id INT NOT NULL, skill_key VARCHAR(24) NOT NULL,
        xp DECIMAL(14,2) NOT NULL DEFAULT 0,
        PRIMARY KEY (save_id, skill_key)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_scenarios (
        id INT NOT NULL AUTO_INCREMENT, user_id INT NOT NULL,
        scenario_name VARCHAR(96) NOT NULL, is_public TINYINT(1) NOT NULL DEFAULT 0,
        payload LONGTEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uniq_FSG_GODSIM_scenarios_user_name (user_id, scenario_name)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_events (
        id BIGINT NOT NULL AUTO_INCREMENT, save_id INT NOT NULL,
        sim_time DECIMAL(12,2) NOT NULL DEFAULT 0, event_type VARCHAR(32) NOT NULL,
        message VARCHAR(512) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY idx_FSG_GODSIM_events_save_time (save_id, sim_time)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_creature_spells (
        save_id INT NOT NULL, spell_key VARCHAR(24) NOT NULL,
        watched INT NOT NULL DEFAULT 0, spell_level TINYINT NOT NULL DEFAULT 0,
        PRIMARY KEY (save_id, spell_key)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_lairs (
        id BIGINT NOT NULL AUTO_INCREMENT, save_id INT NOT NULL,
        lair_key VARCHAR(32) NOT NULL, label VARCHAR(64) NOT NULL,
        spawn_class VARCHAR(32) NOT NULL,
        pos_x DECIMAL(9,3) NOT NULL DEFAULT 0, pos_z DECIMAL(9,3) NOT NULL DEFAULT 0,
        home_x DECIMAL(9,3) NOT NULL DEFAULT 0, home_z DECIMAL(9,3) NOT NULL DEFAULT 0,
        hp DECIMAL(9,2) NOT NULL DEFAULT 400, max_hp DECIMAL(9,2) NOT NULL DEFAULT 400,
        spawn_every DECIMAL(7,2) NOT NULL DEFAULT 7, spawn_cap INT NOT NULL DEFAULT 9,
        is_dead TINYINT(1) NOT NULL DEFAULT 0, respawn_in DECIMAL(9,2) NOT NULL DEFAULT 0,
        PRIMARY KEY (id), UNIQUE KEY uniq_FSG_GODSIM_lairs_save_key (save_id, lair_key)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_world_state (
        save_id INT NOT NULL,
        game_mode VARCHAR(24) NOT NULL DEFAULT 'single',
        seconds_per_hour DECIMAL(7,3) NOT NULL DEFAULT 6,
        hours_per_day INT NOT NULL DEFAULT 24,
        days_per_year INT NOT NULL DEFAULT 365,
        lifespan_min INT NOT NULL DEFAULT 70,
        lifespan_max INT NOT NULL DEFAULT 110,
        threats_enabled TINYINT(1) NOT NULL DEFAULT 1,
        respawn_mode VARCHAR(16) NOT NULL DEFAULT 'same',
        respawn_delay DECIMAL(9,2) NOT NULL DEFAULT 90,
        clock_year INT NOT NULL DEFAULT 0, clock_day INT NOT NULL DEFAULT 0,
        clock_hour INT NOT NULL DEFAULT 0,
        PRIMARY KEY (save_id)
    ) {$charset}");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_GODSIM_player_stats (
        user_id INT NOT NULL,
        worlds_started INT NOT NULL DEFAULT 0,
        total_sim_time DECIMAL(14,2) NOT NULL DEFAULT 0,
        monsters_killed INT NOT NULL DEFAULT 0,
        villagers_lost INT NOT NULL DEFAULT 0,
        buildings_raised INT NOT NULL DEFAULT 0,
        miracles_cast INT NOT NULL DEFAULT 0,
        best_alignment DECIMAL(6,2) NOT NULL DEFAULT 0,
        worst_alignment DECIMAL(6,2) NOT NULL DEFAULT 0,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (user_id)
    ) {$charset}");

    $done = true;
}

/* -------------------------------------------------------------------------
 * Save ownership guard
 * ---------------------------------------------------------------------- */
function godsim_owned_save(PDO $pdo, int $saveId, int $userId): array
{
    $stmt = $pdo->prepare("SELECT * FROM FSG_GODSIM_saves WHERE id = ? AND user_id = ?");
    $stmt->execute([$saveId, $userId]);
    $row = $stmt->fetch();
    if (!$row) godsim_json(['ok' => false, 'error' => 'No such save.'], 404);
    return $row;
}

/* =========================================================================
 *  API
 * ====================================================================== */
$action = $_GET['action'] ?? ($_POST['action'] ?? '');

if ($action !== '') {
    try {
        $body = godsim_body();
        if ($action === '' && isset($body['action'])) $action = godsim_text($body['action'], 32);

        /* ---- health ---- */
        if ($action === 'health') {
            godsim_db();
            godsim_json(['ok' => true, 'api' => 'godsim', 'database' => 'connected']);
        }

        /* ---- who am I ---- */
        if ($action === 'status') {
            godsim_json([
                'ok'       => true,
                'loggedIn' => $is_real_user,
                'user'     => $is_real_user
                    ? ['id' => godsim_current_user_id(), 'username' => $player_username]
                    : null,
                'guestName' => $is_real_user ? null : $player_username,
            ]);
        }

        /* ---- register (same rules as index1.php) ---- */
        if ($action === 'register') {
            $user   = godsim_text($body['username'] ?? '', 64);
            $email  = strtolower(godsim_text($body['email'] ?? '', 255));
            $pass1  = (string)($body['password'] ?? '');
            $pass2  = (string)($body['password2'] ?? $pass1);
            $over18 = !empty($body['over18']) ? 1 : 0;
            $privacy= !empty($body['privacy']) ? 1 : 0;

            if ($user === '' || $email === '')      godsim_json(['ok' => false, 'error' => 'Username and email are required.'], 422);
            if (!$over18 || !$privacy)              godsim_json(['ok' => false, 'error' => 'You must be over 18 and agree to the privacy policy.'], 422);
            if ($pass1 !== $pass2)                  godsim_json(['ok' => false, 'error' => 'Passwords do not match.'], 422);
            if (!godsim_password_ok($pass1))        godsim_json(['ok' => false, 'error' => 'Password needs 8+ characters with an uppercase, a lowercase, a number and a symbol.'], 422);

            $pdo = godsim_db();
            $chk = $pdo->prepare("SELECT id FROM FSG_users WHERE username = ? OR email = ?");
            $chk->execute([$user, $email]);
            if ($chk->fetch()) godsim_json(['ok' => false, 'error' => 'Username or email already registered.'], 409);

            $hash = password_hash($pass1, PASSWORD_DEFAULT);
            $ins = $pdo->prepare("INSERT INTO FSG_users (username, email, password, is_over_18, agreed_privacy)
                                  VALUES (?, ?, ?, ?, ?)");
            $ins->execute([$user, $email, $hash, $over18, $privacy]);

            $_SESSION['user_id']  = (int)$pdo->lastInsertId();
            $_SESSION['username'] = $user;
            unset($_SESSION['guest_name']);
            godsim_json(['ok' => true, 'loggedIn' => true,
                         'user' => ['id' => (int)$_SESSION['user_id'], 'username' => $user]]);
        }

        /* ---- login (username OR email, exactly like index1.php) ---- */
        if ($action === 'login') {
            $user = godsim_text($body['username'] ?? '', 255);
            $pass = (string)($body['password'] ?? '');
            $pdo  = godsim_db();
            $stmt = $pdo->prepare("SELECT id, username, password FROM FSG_users
                                   WHERE (username = ? OR email = ?) LIMIT 1");
            $stmt->execute([$user, $user]);
            $row = $stmt->fetch();
            if ($row && password_verify($pass, $row['password'])) {
                $_SESSION['user_id']  = (int)$row['id'];
                $_SESSION['username'] = $row['username'];
                unset($_SESSION['guest_name']);
                godsim_json(['ok' => true, 'loggedIn' => true,
                             'user' => ['id' => (int)$row['id'], 'username' => $row['username']]]);
            }
            godsim_json(['ok' => false, 'error' => 'Invalid credentials.'], 401);
        }

        /* ---- logout ---- */
        if ($action === 'logout') {
            unset($_SESSION['user_id'], $_SESSION['username']);
            $_SESSION['guest_name'] = 'Guest_' . random_int(1000, 9999);
            godsim_json(['ok' => true, 'loggedIn' => false, 'guestName' => $_SESSION['guest_name']]);
        }

        /* ---- list this player's worlds ---- */
        if ($action === 'listSaves') {
            $uid = godsim_require_login();
            $pdo = godsim_db();
            godsim_ensure_tables($pdo);
            $stmt = $pdo->prepare("SELECT id, slot, god_name, world_name, continent_name, village_name,
                                          creature_kind, creature_name, age_index, alignment, sim_time,
                                          kills, updated_at
                                   FROM FSG_GODSIM_saves
                                   WHERE user_id = ? AND is_active = 1
                                   ORDER BY updated_at DESC");
            $stmt->execute([$uid]);
            godsim_json(['ok' => true, 'saves' => $stmt->fetchAll()]);
        }

        /* ---- write a whole world ---- */
        if ($action === 'saveWorld') {
            $uid = godsim_require_login();
            $pdo = godsim_db();
            godsim_ensure_tables($pdo);

            $slot  = max(1, min(9, (int)($body['slot'] ?? 1)));
            $world = is_array($body['world'] ?? null) ? $body['world'] : [];

            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare("INSERT INTO FSG_GODSIM_saves
                        (user_id, slot, god_name, world_name, continent_name, village_name,
                         creature_kind, creature_name, age_index, alignment, spell_energy, sim_time, kills)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON DUPLICATE KEY UPDATE
                        god_name=VALUES(god_name), world_name=VALUES(world_name),
                        continent_name=VALUES(continent_name), village_name=VALUES(village_name),
                        creature_kind=VALUES(creature_kind), creature_name=VALUES(creature_name),
                        age_index=VALUES(age_index), alignment=VALUES(alignment),
                        spell_energy=VALUES(spell_energy), sim_time=VALUES(sim_time), kills=VALUES(kills)");
                $stmt->execute([
                    $uid, $slot,
                    godsim_text($world['godName'] ?? 'Aegis', 64),
                    godsim_text($world['worldName'] ?? 'Enroth', 64),
                    godsim_text($world['continentName'] ?? 'Varda', 64),
                    godsim_text($world['villageName'] ?? 'Aldermarch', 64),
                    godsim_text($world['creatureKind'] ?? 'ox', 32),
                    godsim_text($world['creatureName'] ?? 'The Ox', 64),
                    (int)($world['age'] ?? 0),
                    godsim_num($world['align'] ?? 0),
                    godsim_num($world['energy'] ?? 30),
                    godsim_num($world['time'] ?? 0),
                    (int)($world['kills'] ?? 0),
                ]);

                $find = $pdo->prepare("SELECT id FROM FSG_GODSIM_saves WHERE user_id = ? AND slot = ?");
                $find->execute([$uid, $slot]);
                $saveId = (int)$find->fetchColumn();

                foreach (['FSG_GODSIM_resources','FSG_GODSIM_units','FSG_GODSIM_unit_skills',
                          'FSG_GODSIM_unit_items','FSG_GODSIM_buildings','FSG_GODSIM_nodes',
                          'FSG_GODSIM_flags','FSG_GODSIM_squads','FSG_GODSIM_research',
                          'FSG_GODSIM_missions','FSG_GODSIM_creature','FSG_GODSIM_creature_skills',
                          'FSG_GODSIM_creature_spells','FSG_GODSIM_lairs','FSG_GODSIM_world_state'] as $t) {
                    $pdo->prepare("DELETE FROM {$t} WHERE save_id = ?")->execute([$saveId]);
                }

                $res = $world['res'] ?? [];
                $pdo->prepare("INSERT INTO FSG_GODSIM_resources (save_id, wood, stone, gold, food)
                               VALUES (?,?,?,?,?)")
                    ->execute([$saveId, godsim_num($res['wood'] ?? 0), godsim_num($res['stone'] ?? 0),
                               godsim_num($res['gold'] ?? 0), godsim_num($res['food'] ?? 0)]);

                $uStmt = $pdo->prepare("INSERT INTO FSG_GODSIM_units
                    (save_id, runtime_id, class_key, family, faction, unit_name, job, pinned_job,
                     pos_x, pos_z, hp, max_hp, mp, max_mp, gold, owed, gear_step,
                     equip_weapon, equip_armour, born_at, age_offset, state)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                $sStmt = $pdo->prepare("INSERT INTO FSG_GODSIM_unit_skills (save_id, runtime_id, skill_key, xp)
                                        VALUES (?,?,?,?)");
                $iStmt = $pdo->prepare("INSERT INTO FSG_GODSIM_unit_items (save_id, runtime_id, item_key, qty)
                                        VALUES (?,?,?,?)");
                foreach (($world['units'] ?? []) as $u) {
                    $rid = (int)($u['id'] ?? 0);
                    $uStmt->execute([
                        $saveId, $rid, godsim_text($u['cls'] ?? '', 32), godsim_text($u['family'] ?? '', 16),
                        godsim_text($u['faction'] ?? 'player', 16), godsim_text($u['name'] ?? '', 64),
                        godsim_text($u['job'] ?? 'idle', 32), !empty($u['pinnedJob']) ? 1 : 0,
                        godsim_num($u['x'] ?? 0), godsim_num($u['z'] ?? 0),
                        godsim_num($u['hp'] ?? 0), godsim_num($u['maxHp'] ?? 0),
                        godsim_num($u['mp'] ?? 0), godsim_num($u['maxMp'] ?? 0),
                        godsim_num($u['gold'] ?? 0), godsim_num($u['owed'] ?? 0),
                        (int)($u['gearStep'] ?? 0),
                        $u['weapon'] ?? null, $u['armour'] ?? null,
                        godsim_num($u['bornAt'] ?? 0), godsim_num($u['ageOffset'] ?? 20),
                        godsim_text($u['state'] ?? 'idle', 24),
                    ]);
                    foreach (($u['xp'] ?? []) as $skill => $xp) {
                        $sStmt->execute([$saveId, $rid, godsim_text($skill, 24), godsim_num($xp)]);
                    }
                    foreach (($u['inv'] ?? []) as $slotItem) {
                        $iStmt->execute([$saveId, $rid, godsim_text($slotItem['id'] ?? '', 32),
                                         (int)($slotItem['qty'] ?? 1)]);
                    }
                }

                $bStmt = $pdo->prepare("INSERT INTO FSG_GODSIM_buildings
                    (save_id, runtime_id, type_key, tier, pos_x, pos_z, hp, max_hp,
                     is_built, progress, wood_in, wood_need, is_enemy)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
                foreach (($world['buildings'] ?? []) as $b) {
                    $bStmt->execute([
                        $saveId, (int)($b['id'] ?? 0), godsim_text($b['type'] ?? '', 32),
                        (int)($b['tier'] ?? 1), godsim_num($b['x'] ?? 0), godsim_num($b['z'] ?? 0),
                        godsim_num($b['hp'] ?? 0), godsim_num($b['maxHp'] ?? 0),
                        !empty($b['built']) ? 1 : 0, godsim_num($b['prog'] ?? 0),
                        godsim_num($b['woodIn'] ?? 0), godsim_num($b['woodNeed'] ?? 0),
                        !empty($b['enemy']) ? 1 : 0,
                    ]);
                }

                $nStmt = $pdo->prepare("INSERT INTO FSG_GODSIM_nodes
                    (save_id, runtime_id, flora_key, kind, yields, pos_x, pos_z, amount, max_amount, respawn, scale)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?)");
                foreach (($world['nodes'] ?? []) as $n) {
                    $nStmt->execute([
                        $saveId, (int)($n['id'] ?? 0), $n['flora'] ?? null,
                        godsim_text($n['kind'] ?? '', 16), $n['yields'] ?? null,
                        godsim_num($n['x'] ?? 0), godsim_num($n['z'] ?? 0),
                        godsim_num($n['amount'] ?? 0), godsim_num($n['max'] ?? 0),
                        godsim_num($n['respawn'] ?? 0), godsim_num($n['scale'] ?? 1),
                    ]);
                }

                $fStmt = $pdo->prepare("INSERT INTO FSG_GODSIM_flags
                    (save_id, flag_kind, pos_x, pos_z, price, held_secs, attached_to)
                    VALUES (?,?,?,?,?,?,?)");
                foreach (($world['flags'] ?? []) as $kind => $f) {
                    if (!is_array($f)) continue;
                    $fStmt->execute([$saveId, godsim_text($kind, 16), godsim_num($f['x'] ?? 0),
                                     godsim_num($f['z'] ?? 0), (int)($f['price'] ?? 0),
                                     godsim_num($f['held'] ?? 0), $f['attachTo'] ?? null]);
                }

                $qStmt = $pdo->prepare("INSERT INTO FSG_GODSIM_squads
                    (save_id, runtime_id, squad_name, colour, banner_x, banner_z, facing, engage_range, stance)
                    VALUES (?,?,?,?,?,?,?,?,?)");
                foreach (($world['squads'] ?? []) as $q) {
                    $qStmt->execute([$saveId, (int)($q['id'] ?? 0), godsim_text($q['name'] ?? '', 32),
                                     godsim_text($q['colour'] ?? '#D9A43F', 9),
                                     godsim_num($q['bx'] ?? 0), godsim_num($q['bz'] ?? 0),
                                     godsim_num($q['facing'] ?? 0), godsim_num($q['engage'] ?? 16),
                                     godsim_text($q['stance'] ?? 'hold', 16)]);
                }

                $rStmt = $pdo->prepare("INSERT INTO FSG_GODSIM_research (save_id, research_key) VALUES (?,?)");
                foreach (array_keys($world['researched'] ?? []) as $key) {
                    $rStmt->execute([$saveId, godsim_text($key, 32)]);
                }

                $mStmt = $pdo->prepare("INSERT INTO FSG_GODSIM_missions
                    (save_id, template_key, label, flag_kind, progress, needed, reward_gold, reward_xp, is_done, is_failed)
                    VALUES (?,?,?,?,?,?,?,?,?,?)");
                foreach (($world['missions'] ?? []) as $m) {
                    $mStmt->execute([$saveId, godsim_text($m['tpl'] ?? '', 32), godsim_text($m['label'] ?? '', 128),
                                     godsim_text($m['flag'] ?? '', 16), (int)($m['prog'] ?? 0), (int)($m['need'] ?? 1),
                                     (int)($m['gold'] ?? 0), (int)($m['xp'] ?? 0),
                                     !empty($m['done']) ? 1 : 0, !empty($m['failed']) ? 1 : 0]);
                }

                if (!empty($world['creature']) && is_array($world['creature'])) {
                    $c = $world['creature'];
                    $pdo->prepare("INSERT INTO FSG_GODSIM_creature
                        (save_id, kind, creature_name, pos_x, pos_z, hp, max_hp, girth, fed, hunger, mood, leashed)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)")
                        ->execute([$saveId, godsim_text($c['kind'] ?? 'ox', 24), godsim_text($c['name'] ?? '', 64),
                                   godsim_num($c['x'] ?? 0), godsim_num($c['z'] ?? 0),
                                   godsim_num($c['hp'] ?? 0), godsim_num($c['maxHp'] ?? 0),
                                   godsim_num($c['girth'] ?? 1), godsim_num($c['fed'] ?? 0),
                                   godsim_num($c['hunger'] ?? 0), godsim_num($c['mood'] ?? 0),
                                   !empty($c['leashed']) ? 1 : 0]);
                    $csStmt = $pdo->prepare("INSERT INTO FSG_GODSIM_creature_skills (save_id, skill_key, xp)
                                             VALUES (?,?,?)");
                    foreach (($c['xp'] ?? []) as $skill => $xp) {
                        $csStmt->execute([$saveId, godsim_text($skill, 24), godsim_num($xp)]);
                    }
                }

                /* clock, mode and threat rules */
                $clock = $world['clock'] ?? [];
                $tm = $world['time'] ?? [];
                $th = $world['threats'] ?? [];
                $pdo->prepare("INSERT INTO FSG_GODSIM_world_state
                    (save_id, game_mode, seconds_per_hour, hours_per_day, days_per_year,
                     lifespan_min, lifespan_max, threats_enabled, respawn_mode, respawn_delay,
                     clock_year, clock_day, clock_hour)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)")
                    ->execute([$saveId, godsim_text($world['gameMode'] ?? 'single', 24),
                        godsim_num($tm['secondsPerHour'] ?? 6), (int)($tm['hoursPerDay'] ?? 24),
                        (int)($tm['daysPerYear'] ?? 365), (int)($tm['lifespanMin'] ?? 70),
                        (int)($tm['lifespanMax'] ?? 110), !empty($th['enabled']) ? 1 : 0,
                        godsim_text($th['respawnMode'] ?? 'same', 16),
                        godsim_num($th['respawnDelaySeconds'] ?? 90),
                        (int)($clock['year'] ?? 0), (int)($clock['day'] ?? 0), (int)($clock['hour'] ?? 0)]);

                /* threat spawners */
                $lStmt = $pdo->prepare("INSERT INTO FSG_GODSIM_lairs
                    (save_id, lair_key, label, spawn_class, pos_x, pos_z, home_x, home_z,
                     hp, max_hp, spawn_every, spawn_cap, is_dead, respawn_in)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                foreach (($world['lairs'] ?? []) as $l) {
                    $lStmt->execute([$saveId, godsim_text($l['key'] ?? '', 32),
                        godsim_text($l['label'] ?? '', 64), godsim_text($l['kind'] ?? '', 32),
                        godsim_num($l['x'] ?? 0), godsim_num($l['z'] ?? 0),
                        godsim_num($l['homeX'] ?? 0), godsim_num($l['homeZ'] ?? 0),
                        godsim_num($l['hp'] ?? 0), godsim_num($l['maxHp'] ?? 0),
                        godsim_num($l['every'] ?? 7), (int)($l['cap'] ?? 9),
                        !empty($l['dead']) ? 1 : 0, godsim_num($l['respawnIn'] ?? 0)]);
                }

                /* what the creature has learnt by watching */
                $clStmt = $pdo->prepare("INSERT INTO FSG_GODSIM_creature_spells
                    (save_id, spell_key, watched, spell_level) VALUES (?,?,?,?)");
                foreach ((($world['creature']['spellLore'] ?? []) ?: []) as $key => $lore) {
                    $clStmt->execute([$saveId, godsim_text($key, 24),
                        (int)($lore['watched'] ?? 0), (int)($lore['level'] ?? 0)]);
                }

                $pdo->prepare("INSERT INTO FSG_GODSIM_player_stats
                        (user_id, worlds_started, total_sim_time, monsters_killed)
                        VALUES (?, 1, ?, ?)
                    ON DUPLICATE KEY UPDATE
                        total_sim_time = GREATEST(total_sim_time, VALUES(total_sim_time)),
                        monsters_killed = GREATEST(monsters_killed, VALUES(monsters_killed))")
                    ->execute([$uid, godsim_num($world['time'] ?? 0), (int)($world['kills'] ?? 0)]);

                $pdo->commit();
                godsim_json(['ok' => true, 'saveId' => $saveId, 'slot' => $slot]);
            } catch (Throwable $e) {
                $pdo->rollBack();
                throw $e;
            }
        }

        /* ---- read a whole world back ---- */
        if ($action === 'loadWorld') {
            $uid = godsim_require_login();
            $pdo = godsim_db();
            godsim_ensure_tables($pdo);
            $saveId = (int)($_GET['saveId'] ?? ($body['saveId'] ?? 0));
            $save = godsim_owned_save($pdo, $saveId, $uid);

            $grab = function (string $sql) use ($pdo, $saveId) {
                $s = $pdo->prepare($sql);
                $s->execute([$saveId]);
                return $s->fetchAll();
            };
            godsim_json([
                'ok'        => true,
                'save'      => $save,
                'resources' => $grab("SELECT * FROM FSG_GODSIM_resources WHERE save_id = ?"),
                'units'     => $grab("SELECT * FROM FSG_GODSIM_units WHERE save_id = ?"),
                'skills'    => $grab("SELECT * FROM FSG_GODSIM_unit_skills WHERE save_id = ?"),
                'items'     => $grab("SELECT * FROM FSG_GODSIM_unit_items WHERE save_id = ?"),
                'buildings' => $grab("SELECT * FROM FSG_GODSIM_buildings WHERE save_id = ?"),
                'nodes'     => $grab("SELECT * FROM FSG_GODSIM_nodes WHERE save_id = ?"),
                'flags'     => $grab("SELECT * FROM FSG_GODSIM_flags WHERE save_id = ?"),
                'squads'    => $grab("SELECT * FROM FSG_GODSIM_squads WHERE save_id = ?"),
                'research'  => $grab("SELECT * FROM FSG_GODSIM_research WHERE save_id = ?"),
                'missions'  => $grab("SELECT * FROM FSG_GODSIM_missions WHERE save_id = ?"),
                'creature'  => $grab("SELECT * FROM FSG_GODSIM_creature WHERE save_id = ?"),
                'creatureSkills' => $grab("SELECT * FROM FSG_GODSIM_creature_skills WHERE save_id = ?"),
                'creatureSpells' => $grab("SELECT * FROM FSG_GODSIM_creature_spells WHERE save_id = ?"),
                'lairs'      => $grab("SELECT * FROM FSG_GODSIM_lairs WHERE save_id = ?"),
                'worldState' => $grab("SELECT * FROM FSG_GODSIM_world_state WHERE save_id = ?"),
            ]);
        }

        if ($action === 'deleteSave') {
            $uid = godsim_require_login();
            $pdo = godsim_db();
            godsim_ensure_tables($pdo);
            $saveId = (int)($body['saveId'] ?? 0);
            godsim_owned_save($pdo, $saveId, $uid);
            $pdo->prepare("UPDATE FSG_GODSIM_saves SET is_active = 0 WHERE id = ?")->execute([$saveId]);
            godsim_json(['ok' => true]);
        }

        /* ---- scenarios: the in-game data editor's export target ---- */
        if ($action === 'saveScenario') {
            $uid = godsim_require_login();
            $pdo = godsim_db();
            godsim_ensure_tables($pdo);
            $name = godsim_text($body['name'] ?? 'Untitled', 96);
            $payload = json_encode($body['payload'] ?? [], JSON_UNESCAPED_SLASHES);
            $pdo->prepare("INSERT INTO FSG_GODSIM_scenarios (user_id, scenario_name, is_public, payload)
                           VALUES (?,?,?,?)
                           ON DUPLICATE KEY UPDATE payload = VALUES(payload), is_public = VALUES(is_public)")
                ->execute([$uid, $name, !empty($body['isPublic']) ? 1 : 0, $payload]);
            godsim_json(['ok' => true]);
        }

        if ($action === 'listScenarios') {
            $uid = godsim_require_login();
            $pdo = godsim_db();
            godsim_ensure_tables($pdo);
            $s = $pdo->prepare("SELECT id, scenario_name, is_public, updated_at
                                FROM FSG_GODSIM_scenarios
                                WHERE user_id = ? OR is_public = 1 ORDER BY updated_at DESC");
            $s->execute([$uid]);
            godsim_json(['ok' => true, 'scenarios' => $s->fetchAll()]);
        }

        if ($action === 'loadScenario') {
            $uid = godsim_require_login();
            $pdo = godsim_db();
            godsim_ensure_tables($pdo);
            $id = (int)($_GET['id'] ?? ($body['id'] ?? 0));
            $s = $pdo->prepare("SELECT payload FROM FSG_GODSIM_scenarios
                                WHERE id = ? AND (user_id = ? OR is_public = 1)");
            $s->execute([$id, $uid]);
            $row = $s->fetch();
            if (!$row) godsim_json(['ok' => false, 'error' => 'No such scenario.'], 404);
            godsim_json(['ok' => true, 'payload' => json_decode($row['payload'], true)]);
        }

        /* ---- the realm ledger ---- */
        if ($action === 'logEvents') {
            $uid = godsim_require_login();
            $pdo = godsim_db();
            godsim_ensure_tables($pdo);
            $saveId = (int)($body['saveId'] ?? 0);
            godsim_owned_save($pdo, $saveId, $uid);
            $stmt = $pdo->prepare("INSERT INTO FSG_GODSIM_events (save_id, sim_time, event_type, message)
                                   VALUES (?,?,?,?)");
            foreach (($body['events'] ?? []) as $e) {
                $stmt->execute([$saveId, godsim_num($e['t'] ?? 0),
                                godsim_text($e['type'] ?? 'log', 32), godsim_text($e['msg'] ?? '', 512)]);
            }
            godsim_json(['ok' => true]);
        }

        if ($action === 'stats') {
            $uid = godsim_require_login();
            $pdo = godsim_db();
            godsim_ensure_tables($pdo);
            $s = $pdo->prepare("SELECT * FROM FSG_GODSIM_player_stats WHERE user_id = ?");
            $s->execute([$uid]);
            godsim_json(['ok' => true, 'stats' => $s->fetch() ?: null]);
        }

        godsim_json(['ok' => false, 'error' => 'Unknown action.'], 404);
    } catch (Throwable $e) {
        godsim_json(['ok' => false, 'error' => $e->getMessage()], 500);
    }
}

/* =========================================================================
 *  No action: serve the game itself.
 * ====================================================================== */
$bootstrap = json_encode([
    'loggedIn'  => $is_real_user,
    'username'  => $player_username,
    'userId'    => godsim_current_user_id(),
    'apiUrl'    => basename(__FILE__),
], JSON_UNESCAPED_SLASHES);

$html = @file_get_contents(__DIR__ . '/index.html');
if ($html === false) {
    http_response_code(500);
    echo 'index.html is missing next to godsim.php.';
    exit;
}
$inject = "<script>window.GODSIM_BOOT = {$bootstrap};</script>";
$html = str_replace('</head>', $inject . "\n</head>", $html);

header('Content-Type: text/html; charset=utf-8');
echo $html;
