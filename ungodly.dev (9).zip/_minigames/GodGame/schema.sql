-- ============================================================================
--  PROJECT SOVEREIGN AEGIS — GOD SIM
--  MySQL schema. Every table is prefixed FSG_GODSIM_.
--
--  Depends on the existing shared account table FSG_users (id, username, ...)
--  created by _private/AuthShared.php. Nothing here alters that table.
--
--  Safe to run repeatedly: every statement is CREATE TABLE IF NOT EXISTS.
--  Character set matches the rest of the suite: utf8mb4 / utf8mb4_unicode_ci.
-- ============================================================================

-- ---------------------------------------------------------------------------
--  1. SAVES — one row per world a player has going
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_saves (
  id                INT NOT NULL AUTO_INCREMENT,
  user_id           INT NOT NULL,
  slot              TINYINT NOT NULL DEFAULT 1,
  god_name          VARCHAR(64)  NOT NULL DEFAULT 'Aegis',
  world_name        VARCHAR(64)  NOT NULL DEFAULT 'Enroth',
  continent_name    VARCHAR(64)  NOT NULL DEFAULT 'Varda',
  village_name      VARCHAR(64)  NOT NULL DEFAULT 'Aldermarch',
  creature_kind     VARCHAR(32)  NOT NULL DEFAULT 'ox',
  creature_name     VARCHAR(64)  NOT NULL DEFAULT 'The Ox',
  age_index         TINYINT NOT NULL DEFAULT 0,
  alignment         DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  spell_energy      DECIMAL(8,2) NOT NULL DEFAULT 30.00,
  sim_time          DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  kills             INT NOT NULL DEFAULT 0,
  is_active         TINYINT(1) NOT NULL DEFAULT 1,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_FSG_GODSIM_saves_user_slot (user_id, slot),
  KEY idx_FSG_GODSIM_saves_user (user_id, is_active),
  KEY idx_FSG_GODSIM_saves_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  2. RESOURCES — the stockpile, one row per save
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_resources (
  save_id     INT NOT NULL,
  wood        DECIMAL(12,2) NOT NULL DEFAULT 0,
  stone       DECIMAL(12,2) NOT NULL DEFAULT 0,
  gold        DECIMAL(12,2) NOT NULL DEFAULT 0,
  food        DECIMAL(12,2) NOT NULL DEFAULT 0,
  updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (save_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  3. UNITS — every villager, hero, soldier, beast and monster
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_units (
  id            BIGINT NOT NULL AUTO_INCREMENT,
  save_id       INT NOT NULL,
  runtime_id    INT NOT NULL,
  class_key     VARCHAR(32) NOT NULL,
  family        VARCHAR(16) NOT NULL,
  faction       VARCHAR(16) NOT NULL DEFAULT 'player',
  unit_name     VARCHAR(64) NOT NULL,
  job           VARCHAR(32) NOT NULL DEFAULT 'idle',
  pinned_job    TINYINT(1) NOT NULL DEFAULT 0,
  pos_x         DECIMAL(9,3) NOT NULL DEFAULT 0,
  pos_z         DECIMAL(9,3) NOT NULL DEFAULT 0,
  hp            DECIMAL(9,2) NOT NULL DEFAULT 0,
  max_hp        DECIMAL(9,2) NOT NULL DEFAULT 0,
  mp            DECIMAL(9,2) NOT NULL DEFAULT 0,
  max_mp        DECIMAL(9,2) NOT NULL DEFAULT 0,
  gold          DECIMAL(10,2) NOT NULL DEFAULT 0,
  owed          DECIMAL(10,2) NOT NULL DEFAULT 0,
  gear_step     TINYINT NOT NULL DEFAULT 0,
  equip_weapon  VARCHAR(32) NULL DEFAULT NULL,
  equip_armour  VARCHAR(32) NULL DEFAULT NULL,
  born_at       DECIMAL(12,2) NOT NULL DEFAULT 0,
  age_offset    DECIMAL(6,2) NOT NULL DEFAULT 20,
  state         VARCHAR(24) NOT NULL DEFAULT 'idle',
  PRIMARY KEY (id),
  UNIQUE KEY uniq_FSG_GODSIM_units_save_runtime (save_id, runtime_id),
  KEY idx_FSG_GODSIM_units_save_family (save_id, family),
  KEY idx_FSG_GODSIM_units_save_job (save_id, job)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  4. UNIT SKILLS — RuneScape-style XP, one row per unit per skill
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_unit_skills (
  save_id     INT NOT NULL,
  runtime_id  INT NOT NULL,
  skill_key   VARCHAR(24) NOT NULL,
  xp          DECIMAL(14,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (save_id, runtime_id, skill_key),
  KEY idx_FSG_GODSIM_unit_skills_skill (save_id, skill_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  5. UNIT INVENTORY
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_unit_items (
  save_id     INT NOT NULL,
  runtime_id  INT NOT NULL,
  item_key    VARCHAR(32) NOT NULL,
  qty         INT NOT NULL DEFAULT 1,
  PRIMARY KEY (save_id, runtime_id, item_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  6. BUILDINGS
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_buildings (
  id          BIGINT NOT NULL AUTO_INCREMENT,
  save_id     INT NOT NULL,
  runtime_id  INT NOT NULL,
  type_key    VARCHAR(32) NOT NULL,
  tier        TINYINT NOT NULL DEFAULT 1,
  pos_x       DECIMAL(9,3) NOT NULL DEFAULT 0,
  pos_z       DECIMAL(9,3) NOT NULL DEFAULT 0,
  hp          DECIMAL(10,2) NOT NULL DEFAULT 0,
  max_hp      DECIMAL(10,2) NOT NULL DEFAULT 0,
  is_built    TINYINT(1) NOT NULL DEFAULT 0,
  progress    DECIMAL(9,3) NOT NULL DEFAULT 0,
  wood_in     DECIMAL(9,2) NOT NULL DEFAULT 0,
  wood_need   DECIMAL(9,2) NOT NULL DEFAULT 0,
  is_enemy    TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_FSG_GODSIM_buildings_save_runtime (save_id, runtime_id),
  KEY idx_FSG_GODSIM_buildings_save_type (save_id, type_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  7. RESOURCE NODES — trees, bushes, seams, veins, deposits
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_nodes (
  id          BIGINT NOT NULL AUTO_INCREMENT,
  save_id     INT NOT NULL,
  runtime_id  INT NOT NULL,
  flora_key   VARCHAR(32) NULL DEFAULT NULL,
  kind        VARCHAR(16) NOT NULL,
  yields      VARCHAR(16) NULL DEFAULT NULL,
  pos_x       DECIMAL(9,3) NOT NULL DEFAULT 0,
  pos_z       DECIMAL(9,3) NOT NULL DEFAULT 0,
  amount      DECIMAL(9,2) NOT NULL DEFAULT 0,
  max_amount  DECIMAL(9,2) NOT NULL DEFAULT 0,
  respawn     DECIMAL(9,2) NOT NULL DEFAULT 0,
  scale       DECIMAL(5,3) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_FSG_GODSIM_nodes_save_runtime (save_id, runtime_id),
  KEY idx_FSG_GODSIM_nodes_save_kind (save_id, kind)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  8. FLAGS — attack / defend / escort, and what they are paying
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_flags (
  save_id     INT NOT NULL,
  flag_kind   VARCHAR(16) NOT NULL,
  pos_x       DECIMAL(9,3) NOT NULL DEFAULT 0,
  pos_z       DECIMAL(9,3) NOT NULL DEFAULT 0,
  price       INT NOT NULL DEFAULT 0,
  held_secs   DECIMAL(9,2) NOT NULL DEFAULT 0,
  attached_to INT NULL DEFAULT NULL,
  PRIMARY KEY (save_id, flag_kind)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  9. SQUADS and their banners
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_squads (
  id           BIGINT NOT NULL AUTO_INCREMENT,
  save_id      INT NOT NULL,
  runtime_id   INT NOT NULL,
  squad_name   VARCHAR(32) NOT NULL,
  colour       VARCHAR(9)  NOT NULL DEFAULT '#D9A43F',
  banner_x     DECIMAL(9,3) NOT NULL DEFAULT 0,
  banner_z     DECIMAL(9,3) NOT NULL DEFAULT 0,
  facing       DECIMAL(6,3) NOT NULL DEFAULT 0,
  engage_range DECIMAL(6,2) NOT NULL DEFAULT 16,
  stance       VARCHAR(16) NOT NULL DEFAULT 'hold',
  PRIMARY KEY (id),
  UNIQUE KEY uniq_FSG_GODSIM_squads_save_runtime (save_id, runtime_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 10. RESEARCH bought at the blacksmith and university
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_research (
  save_id      INT NOT NULL,
  research_key VARCHAR(32) NOT NULL,
  bought_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (save_id, research_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 11. MISSIONS
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_missions (
  id            BIGINT NOT NULL AUTO_INCREMENT,
  save_id       INT NOT NULL,
  template_key  VARCHAR(32) NOT NULL,
  label         VARCHAR(128) NOT NULL,
  flag_kind     VARCHAR(16) NOT NULL,
  progress      INT NOT NULL DEFAULT 0,
  needed        INT NOT NULL DEFAULT 1,
  reward_gold   INT NOT NULL DEFAULT 0,
  reward_xp     INT NOT NULL DEFAULT 0,
  is_done       TINYINT(1) NOT NULL DEFAULT 0,
  is_failed     TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY idx_FSG_GODSIM_missions_save (save_id, is_done, is_failed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 12. CREATURE — one per save
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_creature (
  save_id     INT NOT NULL,
  kind        VARCHAR(24) NOT NULL DEFAULT 'ox',
  creature_name VARCHAR(64) NOT NULL DEFAULT 'The Ox',
  pos_x       DECIMAL(9,3) NOT NULL DEFAULT 0,
  pos_z       DECIMAL(9,3) NOT NULL DEFAULT 0,
  hp          DECIMAL(10,2) NOT NULL DEFAULT 0,
  max_hp      DECIMAL(10,2) NOT NULL DEFAULT 0,
  girth       DECIMAL(6,3) NOT NULL DEFAULT 1,
  fed         DECIMAL(10,2) NOT NULL DEFAULT 0,
  hunger      DECIMAL(6,2) NOT NULL DEFAULT 0,
  mood        DECIMAL(6,2) NOT NULL DEFAULT 0,
  leashed     TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (save_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 13. CREATURE SKILLS
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_creature_skills (
  save_id   INT NOT NULL,
  skill_key VARCHAR(24) NOT NULL,
  xp        DECIMAL(14,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (save_id, skill_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 14. SCENARIOS — edited definition tables (nature, classes, buildings...)
--     Stored whole as JSON so the in-game editor can round-trip anything.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_scenarios (
  id            INT NOT NULL AUTO_INCREMENT,
  user_id       INT NOT NULL,
  scenario_name VARCHAR(96) NOT NULL,
  is_public     TINYINT(1) NOT NULL DEFAULT 0,
  payload       LONGTEXT NOT NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_FSG_GODSIM_scenarios_user_name (user_id, scenario_name),
  KEY idx_FSG_GODSIM_scenarios_public (is_public, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 15. EVENT LOG — the realm ledger, kept for replay and for the player's history
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_events (
  id         BIGINT NOT NULL AUTO_INCREMENT,
  save_id    INT NOT NULL,
  sim_time   DECIMAL(12,2) NOT NULL DEFAULT 0,
  event_type VARCHAR(32) NOT NULL,
  message    VARCHAR(512) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_FSG_GODSIM_events_save_time (save_id, sim_time),
  KEY idx_FSG_GODSIM_events_type (save_id, event_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 16. CREATURE SPELL LORE — what it has watched and how well it has learnt
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_creature_spells (
  save_id    INT NOT NULL,
  spell_key  VARCHAR(24) NOT NULL,
  watched    INT NOT NULL DEFAULT 0,
  spell_level TINYINT NOT NULL DEFAULT 0,
  PRIMARY KEY (save_id, spell_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 17. THREAT SPAWNERS — lairs, their health, and their respawn rule
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_lairs (
  id           BIGINT NOT NULL AUTO_INCREMENT,
  save_id      INT NOT NULL,
  lair_key     VARCHAR(32) NOT NULL,
  label        VARCHAR(64) NOT NULL,
  spawn_class  VARCHAR(32) NOT NULL,
  pos_x        DECIMAL(9,3) NOT NULL DEFAULT 0,
  pos_z        DECIMAL(9,3) NOT NULL DEFAULT 0,
  home_x       DECIMAL(9,3) NOT NULL DEFAULT 0,
  home_z       DECIMAL(9,3) NOT NULL DEFAULT 0,
  hp           DECIMAL(9,2) NOT NULL DEFAULT 400,
  max_hp       DECIMAL(9,2) NOT NULL DEFAULT 400,
  spawn_every  DECIMAL(7,2) NOT NULL DEFAULT 7,
  spawn_cap    INT NOT NULL DEFAULT 9,
  is_dead      TINYINT(1) NOT NULL DEFAULT 0,
  respawn_in   DECIMAL(9,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_FSG_GODSIM_lairs_save_key (save_id, lair_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 18. WORLD CLOCK & MODE — one row per save
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_world_state (
  save_id          INT NOT NULL,
  game_mode        VARCHAR(24) NOT NULL DEFAULT 'single',
  seconds_per_hour DECIMAL(7,3) NOT NULL DEFAULT 6,
  hours_per_day    INT NOT NULL DEFAULT 24,
  days_per_year    INT NOT NULL DEFAULT 365,
  lifespan_min     INT NOT NULL DEFAULT 70,
  lifespan_max     INT NOT NULL DEFAULT 110,
  threats_enabled  TINYINT(1) NOT NULL DEFAULT 1,
  respawn_mode     VARCHAR(16) NOT NULL DEFAULT 'same',
  respawn_delay    DECIMAL(9,2) NOT NULL DEFAULT 90,
  clock_year       INT NOT NULL DEFAULT 0,
  clock_day        INT NOT NULL DEFAULT 0,
  clock_hour       INT NOT NULL DEFAULT 0,
  PRIMARY KEY (save_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 19. PLAYER STATS — lifetime totals across all saves, for the profile page
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FSG_GODSIM_player_stats (
  user_id          INT NOT NULL,
  worlds_started   INT NOT NULL DEFAULT 0,
  total_sim_time   DECIMAL(14,2) NOT NULL DEFAULT 0,
  monsters_killed  INT NOT NULL DEFAULT 0,
  villagers_lost   INT NOT NULL DEFAULT 0,
  buildings_raised INT NOT NULL DEFAULT 0,
  miracles_cast    INT NOT NULL DEFAULT 0,
  best_alignment   DECIMAL(6,2) NOT NULL DEFAULT 0,
  worst_alignment  DECIMAL(6,2) NOT NULL DEFAULT 0,
  updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
