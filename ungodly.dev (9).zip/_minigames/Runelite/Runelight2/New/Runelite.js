(() => {
  const items = {};
  const addItem = (id, name, icon, type, extra = {}) => { items[id] = { id, name, icon, type, value: 1, stackable: false, ...extra }; };
  const gear = (material, label, tier, color, bonuses) => {
    const prefix = material;
    const price = 35 * tier;
    [
      ['helm', `${label} Helm`, 'head', '🪖', { defence: bonuses.defence + 2 }],
      ['body', `${label} Platebody`, 'body', '🥋', { defence: bonuses.defence + 7 }],
      ['legs', `${label} Platelegs`, 'legs', '👖', { defence: bonuses.defence + 5 }],
      ['boots', `${label} Boots`, 'feet', '🥾', { defence: bonuses.defence + 1 }],
      ['gloves', `${label} Gloves`, 'hands', '🧤', { defence: bonuses.defence + 1 }],
      ['shield', `${label} Kiteshield`, 'shield', '🛡️', { defence: bonuses.defence + 4 }]
    ].forEach(([suffix, name, slot, icon, stats]) => addItem(`${prefix}_${suffix}`, name, icon, 'armor', { slot, tier, color, stats, value: price + stats.defence * 4 }));
    [
      ['dagger', `${label} Dagger`, '🗡️', { attack: bonuses.attack + 2, strength: bonuses.strength }],
      ['sword', `${label} Sword`, '⚔️', { attack: bonuses.attack + 5, strength: bonuses.strength + 3 }],
      ['longsword', `${label} Longsword`, '🗡️', { attack: bonuses.attack + 7, strength: bonuses.strength + 5 }],
      ['battleaxe', `${label} Battleaxe`, '🪓', { attack: bonuses.attack + 4, strength: bonuses.strength + 9 }],
      ['pickaxe', `${label} Pickaxe`, '⛏️', { attack: bonuses.attack + 2, strength: bonuses.strength + 2, miningPower: tier }],
      ['hatchet', `${label} Hatchet`, '🪓', { attack: bonuses.attack + 2, strength: bonuses.strength + 3, woodcutPower: tier }]
    ].forEach(([suffix, name, icon, stats]) => addItem(`${prefix}_${suffix}`, name, icon, 'weapon', { slot: 'weapon', tier, color, combatStyle: 'melee', toolType: suffix === 'pickaxe' ? 'pickaxe' : suffix === 'hatchet' ? 'axe' : 'sword', stats, value: price + 25 }));
  };

  addItem('coins','Coins','🟡','currency',{stackable:true,value:1});
  addItem('bones','Bones','🦴','resource',{action:'Bury',prayerXp:5,value:2});
  addItem('big_bones','Big Bones','🦴','resource',{action:'Bury',prayerXp:15,value:16});
  addItem('dragon_bones','Dragon Bones','☠️','resource',{action:'Bury',prayerXp:72,value:150});
  addItem('bucket','Bucket','🪣','tool',{value:5});
  addItem('milk','Bucket of Milk','🥛','resource',{value:15});
  addItem('tinderbox','Tinderbox','🔥','tool',{value:10});
  addItem('small_fishing_net','Small Fishing Net','🕸️','tool',{value:15});
  addItem('fishing_rod','Fishing Rod','🎣','tool',{value:30});
  addItem('needle','Needle','🪡','tool',{value:5});
  addItem('thread','Thread','🧵','resource',{stackable:true,value:2});
  addItem('knife','Knife','🔪','tool',{value:8});
  addItem('hammer','Hammer','🔨','tool',{value:10});
  addItem('chisel','Chisel','🔧','tool',{value:10});
  addItem('shears','Shears','✂️','tool',{value:10});
  addItem('rope','Rope','🪢','tool',{value:20});
  addItem('sewer_key','Sewer Key','🗝️','quest',{value:0});
  addItem('warehouse_key','Warehouse Key','🔑','quest',{value:0});

  ['normal','oak','willow','maple','yew'].forEach((wood,i)=>addItem(`${wood}_logs`,`${wood[0].toUpperCase()+wood.slice(1)} Logs`,'🪵','resource',{value:[8,18,35,65,120][i]}));
  ['normal','oak','willow','maple','yew'].forEach((wood,i)=>addItem(`${wood}_unstrung_bow`,`${wood[0].toUpperCase()+wood.slice(1)} Unstrung Bow`,'🏹','resource',{value:[15,30,55,95,180][i]}));
  ['normal','oak','willow','maple','yew'].forEach((wood,i)=>addItem(`${wood}_shortbow`,`${wood[0].toUpperCase()+wood.slice(1)} Shortbow`,'🏹','weapon',{slot:'weapon',combatStyle:'ranged',toolType:'bow',tier:i+1,stats:{ranged:3+i*4,rangedStrength:2+i*3},value:[30,60,105,180,320][i]}));
  ['normal','oak','willow','maple','yew'].forEach((wood,i)=>addItem(`${wood}_longbow`,`${wood[0].toUpperCase()+wood.slice(1)} Longbow`,'🏹','weapon',{slot:'weapon',combatStyle:'ranged',toolType:'bow',tier:i+1,stats:{ranged:5+i*5,rangedStrength:3+i*4},value:[42,80,140,240,420][i]}));
  addItem('arrow_shafts','Arrow Shafts','➖','resource',{stackable:true,value:1});
  addItem('headless_arrows','Headless Arrows','➶','resource',{stackable:true,value:2});
  addItem('feather','Feather','🪶','resource',{stackable:true,value:2});
  ['bronze','iron','steel'].forEach((m,i)=>{
    addItem(`${m}_arrowtips`,`${m[0].toUpperCase()+m.slice(1)} Arrowtips`,'🔺','resource',{stackable:true,value:3+i*3});
    addItem(`${m}_arrow`,`${m[0].toUpperCase()+m.slice(1)} Arrow`,'🏹','ammo',{slot:'ammo',stackable:true,tier:i+1,stats:{rangedStrength:3+i*4},value:3+i*3});
  });
  addItem('flax','Flax','🌾','resource',{value:5});
  addItem('bowstring','Bow String','🧵','resource',{value:12});
  addItem('wool','Wool','☁️','resource',{value:4});
  addItem('ball_of_wool','Ball of Wool','🧶','resource',{value:9});

  ['copper','tin','iron','coal','silver','gold'].forEach((ore,i)=>addItem(`${ore}_ore`,`${ore[0].toUpperCase()+ore.slice(1)} Ore`,['🟠','⚪','🟤','⚫','◻️','🟡'][i],'resource',{value:[12,12,25,40,55,80][i]}));
  ['bronze','iron','steel','silver','gold'].forEach((bar,i)=>addItem(`${bar}_bar`,`${bar[0].toUpperCase()+bar.slice(1)} Bar`,'▰','resource',{value:[30,60,110,120,180][i]}));

  addItem('cowhide','Cowhide','🐄','resource',{value:12});
  addItem('leather','Leather','🟫','resource',{value:20});
  addItem('hard_leather','Hard Leather','🟤','resource',{value:45});
  addItem('silk','Silk','🎀','resource',{value:35});
  addItem('bear_fur','Bear Fur','🐻','resource',{value:25});
  addItem('wolf_pelt','Wolf Pelt','🐺','resource',{value:30});
  addItem('green_dragonhide','Green Dragonhide','🦎','resource',{value:200});
  addItem('rat_tail','Rat Tail','〰️','resource',{value:6});
  addItem('slime_core','Slime Core','🟢','resource',{value:42});
  addItem('cave_fang','Cave Fang','🦷','resource',{value:38});
  addItem('dark_essence','Dark Essence','🟣','resource',{value:140});
  addItem('golem_core','Golem Core','🔘','resource',{value:300});

  addItem('raw_shrimp','Raw Shrimp','🦐','food',{value:6});
  addItem('cooked_shrimp','Cooked Shrimp','🍤','food',{action:'Eat',heal:4,value:12});
  addItem('raw_trout','Raw Trout','🐟','food',{value:15});
  addItem('cooked_trout','Cooked Trout','🍣','food',{action:'Eat',heal:8,value:30});
  addItem('raw_beef','Raw Beef','🥩','food',{value:10});
  addItem('cooked_beef','Cooked Meat','🍖','food',{action:'Eat',heal:6,value:20});
  addItem('raw_rat_meat','Raw Rat Meat','🥩','food',{value:4});
  addItem('cooked_rat_meat','Cooked Rat Meat','🍖','food',{action:'Eat',heal:3,value:9});
  addItem('burnt_food','Burnt Food','⬛','trash',{value:1});
  addItem('cabbage','Cabbage','🥬','food',{action:'Eat',heal:3,value:15});
  addItem('bread','Bread','🍞','food',{action:'Eat',heal:5,value:22});
  addItem('wheat','Wheat','🌾','resource',{value:8});
  addItem('flour','Pot of Flour','🥣','resource',{value:16});
  addItem('barley_seed','Barley Seed','🌱','seed',{stackable:true,value:5});
  addItem('cabbage_seed','Cabbage Seed','🌱','seed',{stackable:true,value:8});
  addItem('barley','Barley','🌾','resource',{value:20});
  addItem('garden_berries','Sunberries','🫐','food',{action:'Eat',heal:2,stackable:true,value:12});
  addItem('apple','Garden Apple','🍎','food',{action:'Eat',heal:4,stackable:true,value:18});
  addItem('carrot','Garden Carrot','🥕','food',{action:'Eat',heal:3,stackable:true,value:14});
  addItem('garden_herbs','Fresh Garden Herbs','🌿','resource',{stackable:true,value:24});

  ['mind','air','water','earth','fire','body','chaos','death','nature','law'].forEach((r,i)=>addItem(`${r}_rune`,`${r[0].toUpperCase()+r.slice(1)} Rune`,['🧠','💨','💧','🌍','🔥','🫀','🌀','💀','🍃','⚖️'][i],'rune',{stackable:true,value:[5,4,4,4,6,8,18,35,60,90][i]}));
  addItem('basic_staff','Staff of Air','🪄','weapon',{slot:'weapon',combatStyle:'magic',toolType:'staff',stats:{magic:8},value:75});
  addItem('fire_staff','Staff of Fire','🪄','weapon',{slot:'weapon',combatStyle:'magic',toolType:'staff',stats:{magic:15},value:175});

  gear('bronze','Bronze',1,'#b87333',{attack:1,strength:1,defence:1});
  gear('iron','Iron',2,'#a8adb3',{attack:5,strength:5,defence:5});
  gear('steel','Steel',3,'#707b87',{attack:10,strength:10,defence:10});
  gear('mithril','Mithril',4,'#456e9a',{attack:16,strength:16,defence:16});
  addItem('bronze_axe','Bronze Axe','🪓','weapon',{slot:'weapon',tier:1,color:'#b87333',combatStyle:'melee',toolType:'axe',stats:{attack:3,strength:4,woodcutPower:1},value:25,legacyAliasFor:'bronze_hatchet'});
  addItem('bronze_platebody','Bronze Platebody','🥋','armor',{slot:'body',tier:1,color:'#b87333',stats:{defence:8},value:120,legacyAliasFor:'bronze_body'});
  addItem('bronze_platelegs','Bronze Platelegs','👖','armor',{slot:'legs',tier:1,color:'#b87333',stats:{defence:6},value:90,legacyAliasFor:'bronze_legs'});

  addItem('leather_cowl','Leather Cowl','🧢','armor',{slot:'head',tier:1,stats:{defence:2,ranged:1},value:35});
  addItem('leather_body','Leather Body','🦺','armor',{slot:'body',tier:1,stats:{defence:7,ranged:4},value:90});
  addItem('leather_chaps','Leather Chaps','👖','armor',{slot:'legs',tier:1,stats:{defence:5,ranged:3},value:70});
  addItem('leather_boots','Leather Boots','🥾','armor',{slot:'feet',tier:1,stats:{defence:1,ranged:1},value:25});
  addItem('leather_gloves','Leather Gloves','🧤','armor',{slot:'hands',tier:1,stats:{defence:1,ranged:1},value:25});
  addItem('leather_vambraces','Leather Vambraces','🧤','armor',{slot:'hands',tier:1,stats:{defence:2,ranged:2},value:35});
  addItem('studded_body','Studded Leather Body','🦺','armor',{slot:'body',tier:2,stats:{defence:11,ranged:7},value:165});
  addItem('studded_chaps','Studded Leather Chaps','👖','armor',{slot:'legs',tier:2,stats:{defence:8,ranged:5},value:125});
  addItem('sewer_king_blade','Sewer King Blade','🗡️','weapon',{slot:'weapon',combatStyle:'melee',toolType:'sword',tier:6,stats:{attack:32,strength:38},value:2500,rare:true});
  addItem('plagueguard_body','Plagueguard Chestpiece','🥋','armor',{slot:'body',tier:6,stats:{defence:36,poisonResist:50},value:3200,rare:true});
  addItem('dragonfire_blade','Dragonfire Blade','🔥','weapon',{slot:'weapon',combatStyle:'melee',toolType:'sword',tier:8,stats:{attack:52,strength:58},value:12000,rare:true});
  addItem('king_rat_pet','King Rat Pet','🐀','pet',{value:1,rare:true});
  addItem('dragon_pet','Baby Dragon Pet','🐉','pet',{value:1,rare:true});
  addItem('spellbook','Personal Spellbook','📕','spellbook',{value:0,bound:true,container:'spellbook',action:'Open'});
  addItem('oak_plank','Oak Plank','🪵','resource',{stackable:true,value:38});
  addItem('steel_nails','Steel Nails','🔩','resource',{stackable:true,value:4});
  addItem('pet_bedding','Soft Pet Bedding','🧺','resource',{stackable:true,value:55});
  addItem('arcane_lens','Arcane Lens','🔮','resource',{value:180});

  const recipes = [];
  const recipe = (id,name,skill,level,station,inputs,outputs,xp,icon,extra={}) => recipes.push({id,name,skill,level,station,inputs,outputs,xp,icon,...extra});
  recipe('smelt_bronze','Smelt Bronze Bar','smithing',1,'furnace',{copper_ore:1,tin_ore:1},{bronze_bar:1},18,'▰');
  recipe('smelt_iron','Smelt Iron Bar','smithing',15,'furnace',{iron_ore:1},{iron_bar:1},30,'▰',{successChance:.75});
  recipe('smelt_steel','Smelt Steel Bar','smithing',30,'furnace',{iron_ore:1,coal_ore:2},{steel_bar:1},48,'▰');
  recipe('smelt_silver','Smelt Silver Bar','smithing',40,'furnace',{silver_ore:1},{silver_bar:1},55,'▰');
  recipe('smelt_gold','Smelt Gold Bar','smithing',50,'furnace',{gold_ore:1},{gold_bar:1},72,'▰');
  ['bronze','iron','steel'].forEach((m,mi)=>{
    const level=[1,15,30][mi], bar=`${m}_bar`;
    const defs=[['dagger',1],['sword',1],['longsword',2],['battleaxe',3],['pickaxe',2],['hatchet',2],['helm',2],['body',5],['legs',3],['boots',1],['gloves',1],['shield',3]];
    defs.forEach(([part,bars],idx)=>recipe(`smith_${m}_${part}`,`Smith ${items[`${m}_${part}`].name}`,'smithing',level+Math.floor(idx/3),'anvil',{[bar]:bars},{[`${m}_${part}`]:1},bars*25+mi*20,items[`${m}_${part}`].icon));
    recipe(`smith_${m}_arrowtips`,`Smith ${items[`${m}_arrowtips`].name}`,'smithing',level,'anvil',{[bar]:1},{[`${m}_arrowtips`]:15},35+mi*22,'🔺');
  });
  recipe('tan_leather','Tan Cowhide','crafting',1,'tannery',{cowhide:1,coins:1},{leather:1},8,'🟫');
  recipe('tan_hard_leather','Harden Leather','crafting',15,'tannery',{leather:2,coins:3},{hard_leather:1},18,'🟤');
  [['cowl',1,1],['body',3,4],['chaps',2,3],['boots',1,1],['gloves',1,1],['vambraces',1,2]].forEach(([part,leather,level])=>recipe(`craft_leather_${part}`,`Craft ${items[`leather_${part}`].name}`,'crafting',level,'crafting_table',{leather,thread:1},{[`leather_${part}`]:1},leather*18,items[`leather_${part}`].icon));
  recipe('craft_studded_body','Craft Studded Body','crafting',25,'crafting_table',{leather_body:1,steel_bar:1,thread:1},{studded_body:1},90,'🦺');
  recipe('craft_studded_chaps','Craft Studded Chaps','crafting',22,'crafting_table',{leather_chaps:1,steel_bar:1,thread:1},{studded_chaps:1},70,'👖');
  recipe('spin_flax','Spin Bow String','crafting',10,'spinning_wheel',{flax:1},{bowstring:1},15,'🧵');
  recipe('spin_wool','Spin Ball of Wool','crafting',1,'spinning_wheel',{wool:1},{ball_of_wool:1},8,'🧶');
  ['normal','oak','willow','maple','yew'].forEach((wood,i)=>{
    const level=[1,15,30,45,60][i];
    recipe(`fletch_${wood}_short_unstrung`,`Fletch ${items[`${wood}_unstrung_bow`].name}`,'fletching',level,'any',{[`${wood}_logs`]:1,knife:1},{[`${wood}_unstrung_bow`]:1},20+i*22,'🏹');
    recipe(`string_${wood}_shortbow`,`String ${items[`${wood}_shortbow`].name}`,'fletching',level,'any',{[`${wood}_unstrung_bow`]:1,bowstring:1},{[`${wood}_shortbow`]:1},20+i*22,'🏹');
    recipe(`fletch_${wood}_longbow`,`Fletch ${items[`${wood}_longbow`].name}`,'fletching',level+5,'any',{[`${wood}_logs`]:1,knife:1,bowstring:1},{[`${wood}_longbow`]:1},28+i*28,'🏹');
  });
  recipe('fletch_shafts','Cut Arrow Shafts','fletching',1,'any',{normal_logs:1,knife:1},{arrow_shafts:15},12,'➖');
  recipe('feather_shafts','Make Headless Arrows','fletching',1,'any',{arrow_shafts:15,feather:15},{headless_arrows:15},15,'➶');
  ['bronze','iron','steel'].forEach((m,i)=>recipe(`tip_${m}_arrows`,`Make ${items[`${m}_arrow`].name}s`,'fletching',[1,15,30][i],'any',{headless_arrows:15,[`${m}_arrowtips`]:15},{[`${m}_arrow`]:15},25+i*25,'🏹'));
  [['shrimp',1,20],['trout',15,50],['beef',1,30],['rat_meat',1,16]].forEach(([food,level,xp])=>recipe(`cook_${food}`,`Cook ${food.replace('_',' ')}`,'cooking',level,'range',{[`raw_${food}`]:1},{[`cooked_${food}`]:1},xp,'🍖'));
  recipe('mill_flour','Mill Wheat','cooking',1,'mill',{wheat:1},{flour:1},10,'🥣');
  recipe('bake_bread','Bake Bread','cooking',1,'range',{flour:1},{bread:1},35,'🍞');
  ['normal','oak','willow','maple','yew'].forEach((wood,i)=>recipe(`burn_${wood}_logs`,`Burn ${items[`${wood}_logs`].name}`,'firemaking',[1,15,30,45,60][i],'any',{[`${wood}_logs`]:1,tinderbox:1},{},40+i*28,'🔥'));
  recipe('saw_oak_planks','Saw Oak Planks','crafting',12,'sawmill',{oak_logs:1},{oak_plank:2},28,'🪵');
  recipe('smith_steel_nails','Smith Steel Nails','smithing',30,'anvil',{steel_bar:1},{steel_nails:15},42,'🔩');
  recipe('sew_pet_bedding','Sew Pet Bedding','crafting',18,'crafting_table',{ball_of_wool:3,thread:2},{pet_bedding:1},55,'🧺');
  recipe('shape_arcane_lens','Shape Arcane Lens','crafting',25,'crafting_table',{gold_bar:1,chisel:1,law_rune:1},{arcane_lens:1},90,'🔮');

  const enemies = {
    chicken:{id:'chicken',name:'Chicken',level:1,hp:6,aggro:false,speed:1.2,attackSpeed:2.4,maxHit:1,xp:10,color:'#eee9d9',shape:'chicken',drops:[{item:'bones',chance:1,min:1,max:1},{item:'feather',chance:1,min:5,max:15},{item:'raw_beef',chance:.1,min:1,max:1}]},
    cow:{id:'cow',name:'Cow',level:2,hp:12,aggro:false,speed:1.0,attackSpeed:2.4,maxHit:1,xp:18,color:'#9a642e',shape:'cow',drops:[{item:'bones',chance:1,min:1,max:1},{item:'cowhide',chance:1,min:1,max:1},{item:'raw_beef',chance:1,min:1,max:1}]},
    goblin:{id:'goblin',name:'Goblin',level:5,hp:15,aggro:true,speed:1.5,attackSpeed:2.2,maxHit:3,xp:28,color:'#3e963d',shape:'humanoid',drops:[{item:'bones',chance:1,min:1,max:1},{item:'coins',chance:.75,min:3,max:18},{item:'bronze_sword',chance:.08,min:1,max:1},{item:'mind_rune',chance:.12,min:2,max:8}]},
    bear:{id:'bear',name:'Bear',level:12,hp:25,aggro:true,speed:1.3,attackSpeed:2.6,maxHit:5,xp:55,color:'#5b351d',shape:'bear',drops:[{item:'big_bones',chance:1,min:1,max:1},{item:'bear_fur',chance:1,min:1,max:1},{item:'coins',chance:.45,min:15,max:45}]},
    spider:{id:'spider',name:'Giant Spider',level:20,hp:35,aggro:true,speed:1.8,attackSpeed:2.0,maxHit:6,xp:80,color:'#22201e',shape:'spider',drops:[{item:'silk',chance:.65,min:1,max:2},{item:'coins',chance:.35,min:20,max:70},{item:'chaos_rune',chance:.08,min:3,max:10}]},
    skeleton:{id:'skeleton',name:'Skeleton',level:25,hp:45,aggro:true,speed:1.4,attackSpeed:2.3,maxHit:7,xp:110,color:'#ddd7c8',shape:'skeleton',drops:[{item:'bones',chance:1,min:1,max:1},{item:'coins',chance:.55,min:25,max:90},{item:'iron_sword',chance:.06,min:1,max:1},{item:'death_rune',chance:.03,min:2,max:5}]},
    rat:{id:'rat',name:'Sewer Rat',level:3,hp:10,aggro:true,speed:2.1,attackSpeed:1.9,maxHit:2,xp:17,color:'#776b61',shape:'rat',drops:[{item:'bones',chance:1,min:1,max:1},{item:'raw_rat_meat',chance:.75,min:1,max:1},{item:'rat_tail',chance:.5,min:1,max:1},{item:'coins',chance:.35,min:1,max:6}]},
    cave_rat:{id:'cave_rat',name:'Cave Rat',level:8,hp:22,aggro:true,speed:2.3,attackSpeed:1.8,maxHit:4,xp:38,color:'#42342e',shape:'rat',drops:[{item:'bones',chance:1,min:1,max:1},{item:'raw_rat_meat',chance:1,min:1,max:2},{item:'cave_fang',chance:.35,min:1,max:1},{item:'iron_ore',chance:.12,min:1,max:2}]},
    sewer_slime:{id:'sewer_slime',name:'Sewer Slime',level:11,hp:30,aggro:true,speed:.8,attackSpeed:2.8,maxHit:5,xp:52,color:'#4da657',shape:'slime',drops:[{item:'slime_core',chance:.55,min:1,max:1},{item:'water_rune',chance:.45,min:2,max:9},{item:'sewer_key',chance:.08,min:1,max:1,unique:true}]},
    brigand:{id:'brigand',name:'Road Brigand',level:15,hp:38,aggro:true,speed:1.7,attackSpeed:2.1,maxHit:6,xp:72,color:'#6c3131',shape:'humanoid',drops:[{item:'bones',chance:1,min:1,max:1},{item:'coins',chance:.9,min:25,max:100},{item:'steel_dagger',chance:.05,min:1,max:1},{item:'warehouse_key',chance:.04,min:1,max:1}]},
    wolf:{id:'wolf',name:'Grey Wolf',level:18,hp:42,aggro:true,speed:2.2,attackSpeed:1.9,maxHit:7,xp:85,color:'#747b82',shape:'wolf',drops:[{item:'bones',chance:1,min:1,max:1},{item:'wolf_pelt',chance:.8,min:1,max:1},{item:'raw_beef',chance:.65,min:1,max:2}]},
    dark_wizard:{id:'dark_wizard',name:'Dark Wizard',level:28,hp:55,aggro:true,speed:1.2,attackSpeed:2.4,maxHit:10,xp:140,color:'#542d72',shape:'wizard',combatStyle:'magic',drops:[{item:'bones',chance:1,min:1,max:1},{item:'chaos_rune',chance:.65,min:4,max:16},{item:'death_rune',chance:.18,min:2,max:8},{item:'fire_staff',chance:.025,min:1,max:1},{item:'dark_essence',chance:.08,min:1,max:1}]},
    moss_giant:{id:'moss_giant',name:'Moss Giant',level:32,hp:75,aggro:true,speed:1.0,attackSpeed:2.8,maxHit:11,xp:190,color:'#3d7346',shape:'giant',drops:[{item:'big_bones',chance:1,min:1,max:1},{item:'nature_rune',chance:.12,min:2,max:6},{item:'steel_battleaxe',chance:.04,min:1,max:1},{item:'coins',chance:.7,min:75,max:260}]},
    ogre:{id:'ogre',name:'Ogre',level:38,hp:90,aggro:true,speed:1.1,attackSpeed:3.0,maxHit:14,xp:240,color:'#889650',shape:'giant',drops:[{item:'big_bones',chance:1,min:1,max:1},{item:'steel_legs',chance:.025,min:1,max:1},{item:'coins',chance:.75,min:100,max:350},{item:'law_rune',chance:.08,min:1,max:4}]}
  };

  const bosses = {
    sewer_king:{id:'sewer_king',name:'The Sewer King',level:35,hp:180,aggro:true,speed:2.0,attackSpeed:1.8,maxHit:12,xp:620,color:'#8a6652',shape:'king_rat',boss:true,drops:[{item:'big_bones',chance:1,min:2,max:2},{item:'coins',chance:1,min:400,max:900},{item:'sewer_key',chance:1,min:1,max:1,unique:true},{item:'king_rat_pet',chance:.005,min:1,max:1,unique:true},{item:'slime_core',chance:.5,min:3,max:8}]},
    iron_golem:{id:'iron_golem',name:'Iron Golem',level:46,hp:260,aggro:true,speed:.8,attackSpeed:3.1,maxHit:17,xp:900,color:'#737b82',shape:'golem',boss:true,drops:[{item:'big_bones',chance:1,min:2,max:3},{item:'iron_bar',chance:1,min:4,max:10},{item:'steel_bar',chance:.55,min:2,max:6},{item:'golem_core',chance:.2,min:1,max:1},{item:'mithril_sword',chance:.015,min:1,max:1}]},
    red_dragon:{id:'red_dragon',name:'Red Dragon',level:50,hp:320,aggro:true,speed:1.1,attackSpeed:2.5,maxHit:22,xp:1300,color:'#a32620',shape:'dragon',boss:true,combatStyle:'magic',drops:[{item:'dragon_bones',chance:1,min:1,max:1},{item:'green_dragonhide',chance:1,min:1,max:2},{item:'coins',chance:1,min:800,max:2500},{item:'dragonfire_blade',chance:.008,min:1,max:1,unique:true},{item:'dragon_pet',chance:.002,min:1,max:1,unique:true}]}
  };

  const npcs = {
    banker:{id:'banker',name:'Banker Ada',role:'bank',color:'#d9c9a0',building:'Grand Bank',dialogue:['Your valuables are safe beneath Crownstone.']},
    shopkeeper:{id:'shopkeeper',name:'Shopkeeper Giles',role:'shop',shop:'general_store',color:'#d4a735',building:'General Store',dialogue:['Everything an adventurer needs, except good judgment.']},
    blacksmith:{id:'blacksmith',name:'Smith Brann',role:'craft',station:'anvil',shop:'armor_shop',color:'#985b3b',building:'Forge',dialogue:['Ore becomes opportunity under a proper hammer.']},
    smelter:{id:'smelter',name:'Furnace Keeper Iona',role:'craft',station:'furnace',color:'#d36b3a',building:'Forge',dialogue:['Mind the heat. Steel needs coal and patience.']},
    fletcher:{id:'fletcher',name:'Fletcher Rowan',role:'craft',station:'fletching_bench',shop:'ranger_shop',color:'#5d8e45',building:'Fletching Hall',dialogue:['A bow begins as a log and ends as a promise.']},
    tanner:{id:'tanner',name:'Tanner Ellis',role:'craft',station:'tannery',color:'#765039',building:'Tannery',quest:'apprentice_crafter',dialogue:['Bring hides and a few coins. I will make them workable.']},
    weaver:{id:'weaver',name:'Weaver Tessa',role:'craft',station:'spinning_wheel',color:'#9c6cab',building:'Weaver Hall',quest:'spider_thread',dialogue:['Flax becomes bow string here. Wool becomes thread.']},
    chef:{id:'chef',name:'Master Chef Horace',role:'craft',station:'range',color:'#db645a',building:'Golden Ladle Inn',quest:'cooks_assistant',dialogue:['The city guard eats like an army because it is one.']},
    wizard:{id:'wizard',name:'Wizard Gray',role:'quest',shop:'magic_shop',color:'#4fa3d6',building:'Arcane Tower',quest:'thirsty_mage',dialogue:['A bucket of milk steadies the hands before spellwork.']},
    huntsman:{id:'huntsman',name:'Huntsman Vale',role:'slayer',color:'#4f7738',building:'Ranger Lodge',quest:'bear_hunt',dialogue:['I assign dangerous work to people who look capable.']},
    guildmaster:{id:'guildmaster',name:'Guildmaster Orin',role:'quest',color:'#d49d39',building:'Adventurers Guild',quest:'dragon_slayer',dialogue:['The eastern wastes belong to a dragon. Change that.']},
    priest:{id:'priest',name:'Priest Mara',role:'prayer',color:'#ded8bd',building:'Temple',dialogue:['Bury bones respectfully and your devotion will grow.']},
    farmer:{id:'farmer',name:'Farmer Bryn',role:'farm',color:'#9a8439',building:'Market Farm',dialogue:['Plant seeds in the city allotment and return after they grow.']},
    guard:{id:'guard',name:'Crownstone Guard',role:'guard',color:'#7184a0',building:'Guard Barracks',dialogue:['Keep your weapon sheathed inside the walls.']},
    sewer_keeper:{id:'sewer_keeper',name:'Drainmaster Pell',role:'quest',color:'#65716c',building:'Sewer Works',quest:'sewer_key',dialogue:['The old sewer chest has a lock. The key vanished among the slimes.']}
  };

  const shops = {
    general_store:{id:'general_store',name:'Crownstone General Store',buyMultiplier:1.15,sellMultiplier:.45,stock:{bucket:20,tinderbox:20,small_fishing_net:10,fishing_rod:10,knife:20,hammer:20,needle:20,thread:100,rope:10,bronze_pickaxe:8,bronze_hatchet:8,bronze_sword:8,air_rune:200,mind_rune:200,water_rune:150,earth_rune:150,fire_rune:150,body_rune:100,chaos_rune:60,death_rune:30,nature_rune:25,law_rune:25,cabbage_seed:50,barley_seed:50}},
    ranger_shop:{id:'ranger_shop',name:'Rowan’s Bow Shop',buyMultiplier:1.2,sellMultiplier:.5,stock:{normal_shortbow:10,oak_shortbow:6,bronze_arrow:500,iron_arrow:200,feather:500,bowstring:60}},
    armor_shop:{id:'armor_shop',name:'Brann’s Armor Counter',buyMultiplier:1.3,sellMultiplier:.5,stock:{bronze_helm:5,bronze_body:3,bronze_legs:3,bronze_boots:5,bronze_gloves:5,bronze_shield:4,bronze_dagger:6,bronze_sword:6,bronze_longsword:4,bronze_battleaxe:4,iron_helm:4,iron_body:2,iron_legs:2,iron_boots:4,iron_gloves:4,iron_shield:3,iron_dagger:4,iron_sword:4,iron_longsword:3,iron_battleaxe:3,steel_helm:2,steel_body:1,steel_legs:1,steel_boots:2,steel_gloves:2,steel_shield:2,steel_dagger:2,steel_sword:2,steel_longsword:1,steel_battleaxe:1,leather_cowl:8,leather_body:6,leather_chaps:6,leather_boots:8,leather_gloves:8}},
    magic_shop:{id:'magic_shop',name:'Gray’s Rune & Staff Shop',buyMultiplier:1.25,sellMultiplier:.5,stock:{basic_staff:8,fire_staff:3,air_rune:500,mind_rune:500,water_rune:300,earth_rune:300,fire_rune:300,body_rune:200,chaos_rune:100,death_rune:50,nature_rune:35,law_rune:35}}
  };

  const quests = {
    thirsty_mage:{id:'thirsty_mage',name:'The Thirsty Mage',giver:'wizard',summary:'Bring Wizard Gray a bucket of milk.',requirements:{},objectives:[{type:'item',item:'milk',qty:1}],rewards:{xp:{magic:150},items:{air_rune:50,mind_rune:25},coins:100}},
    cooks_assistant:{id:'cooks_assistant',name:"The Baker's Feast",giver:'chef',summary:'Bring cooked meat, shrimp, and bread to the Master Chef.',objectives:[{type:'item',item:'cooked_beef',qty:1},{type:'item',item:'cooked_shrimp',qty:1},{type:'item',item:'bread',qty:1}],rewards:{xp:{cooking:350},items:{cabbage_seed:10},coins:250}},
    goblin_slayer:{id:'goblin_slayer',name:'Goblin Menace',giver:'guard',summary:'Defeat ten goblins outside the south gate.',objectives:[{type:'kill',enemy:'goblin',qty:10}],rewards:{xp:{attack:250,strength:250,defence:250},items:{iron_sword:1},coins:400}},
    spider_thread:{id:'spider_thread',name:"The Spider's Thread",giver:'weaver',summary:'Bring Weaver Tessa five silk.',objectives:[{type:'item',item:'silk',qty:5}],rewards:{xp:{crafting:400},items:{bowstring:15},coins:350}},
    bear_hunt:{id:'bear_hunt',name:'Bear Hunt',giver:'huntsman',summary:'Bring three bear furs.',objectives:[{type:'item',item:'bear_fur',qty:3}],rewards:{xp:{slayer:450,ranged:200},items:{oak_shortbow:1,iron_arrow:100},coins:500}},
    apprentice_crafter:{id:'apprentice_crafter',name:'Apprentice Crafter',giver:'tanner',summary:'Craft and return a leather body.',objectives:[{type:'item',item:'leather_body',qty:1}],rewards:{xp:{crafting:500},items:{hard_leather:4,thread:30},coins:400}},
    sewer_key:{id:'sewer_key',name:'Key Beneath the City',giver:'sewer_keeper',summary:'Find the sewer key and open the locked treasure chest.',objectives:[{type:'flag',flag:'sewer_chest_opened',qty:1}],rewards:{xp:{slayer:800,attack:500,defence:500},items:{coins:1200},coins:0}},
    dragon_slayer:{id:'dragon_slayer',name:'Dragon Slayer',giver:'guildmaster',summary:'Slay the red dragon and return dragon bones.',objectives:[{type:'kill',enemy:'red_dragon',qty:1},{type:'item',item:'dragon_bones',qty:1}],rewards:{xp:{attack:1200,strength:1200,defence:1200},items:{mithril_body:1},coins:3000}}
  };

  const slayerTasks = [
    {id:'rats',name:'Sewer Cleanup',enemyPool:['rat','cave_rat'],min:15,max:35,minLevel:1,rewardXp:8},
    {id:'goblins',name:'Goblin Patrol',enemyPool:['goblin'],min:20,max:45,minLevel:1,rewardXp:10},
    {id:'beasts',name:'Forest Predators',enemyPool:['wolf','bear'],min:15,max:30,minLevel:10,rewardXp:14},
    {id:'sewer_horrors',name:'Sewer Horrors',enemyPool:['sewer_slime','cave_rat'],min:20,max:40,minLevel:15,rewardXp:18},
    {id:'giants',name:'Heavy Problems',enemyPool:['moss_giant','ogre'],min:12,max:25,minLevel:30,rewardXp:25},
    {id:'dark_magic',name:'Dark Magic Purge',enemyPool:['dark_wizard','skeleton'],min:15,max:30,minLevel:25,rewardXp:24}
  ];

  const spells = {
    wind_strike:{id:'wind_strike',name:'Wind Strike',level:1,maxHit:3,xp:6,icon:'🌪️',runes:{air_rune:1,mind_rune:1}},
    water_strike:{id:'water_strike',name:'Water Strike',level:5,maxHit:5,xp:9,icon:'💧',runes:{air_rune:1,water_rune:1,mind_rune:1}},
    earth_strike:{id:'earth_strike',name:'Earth Strike',level:9,maxHit:7,xp:12,icon:'🌍',runes:{air_rune:1,earth_rune:2,mind_rune:1}},
    fire_strike:{id:'fire_strike',name:'Fire Strike',level:13,maxHit:9,xp:15,icon:'🔥',runes:{air_rune:2,fire_rune:3,mind_rune:1}},
    varrock_teleport:{id:'varrock_teleport',name:'Crownstone Teleport',level:25,teleport:'city',xp:35,icon:'🏰',runes:{air_rune:3,fire_rune:1,law_rune:1}}
  };

  spells.house_teleport={id:'house_teleport',name:'Player House Teleport',level:1,teleport:'house',xp:15,icon:'🏠',runes:{law_rune:1,air_rune:1}};
  Object.values(npcs).forEach(npc=>{
    npc.inventory=Array.isArray(npc.inventory)?npc.inventory:['spellbook'];
    npc.spellbook=npc.spellbook||{learned:npc.role==='guard'?['wind_strike']:npc.role==='quest'||npc.role==='craft'?['wind_strike','water_strike']:[]};
  });

  const prayers = {
    thick_skin:{id:'thick_skin',name:'Thick Skin',level:1,icon:'🛡️',drain:.18,bonuses:{defence:.05}},
    burst_strength:{id:'burst_strength',name:'Burst of Strength',level:4,icon:'💪',drain:.22,bonuses:{strength:.05}},
    clarity_thought:{id:'clarity_thought',name:'Clarity of Thought',level:7,icon:'🎯',drain:.22,bonuses:{attack:.05}},
    rock_skin:{id:'rock_skin',name:'Rock Skin',level:10,icon:'🪨',drain:.32,bonuses:{defence:.1}},
    rapid_heal:{id:'rapid_heal',name:'Rapid Heal',level:22,icon:'❤️',drain:.45,bonuses:{regen:2}},
    protect_melee:{id:'protect_melee',name:'Protect from Melee',level:43,icon:'⚔️',drain:.8,bonuses:{protectMelee:.4}}
  };

  const areas = {
    city:{id:'city',name:'Crownstone City',center:[0,0],size:1500,ground:'#75935c',music:'city',safe:true,unlocked:true},
    forest:{id:'forest',name:'Greenwood Forest',center:[-1550,150],size:1450,ground:'#547749',music:'forest',safe:false,unlocked:true},
    mine:{id:'mine',name:'Crownstone Mine',center:[1450,250],size:1200,ground:'#777064',music:'mine',safe:false,unlocked:true},
    southlands:{id:'southlands',name:'South Road',center:[0,1650],size:1500,ground:'#8b8b5a',music:'field',safe:false,unlocked:true},
    east_wastes:{id:'east_wastes',name:'Eastern Wastes',center:[1800,1600],size:1450,ground:'#8b684e',music:'wastes',safe:false,unlocked:false,requireQuest:'dragon_slayer'},
    sewer:{id:'sewer',name:'Crownstone Sewers',center:[8000,8000],size:1500,ground:'#39453e',music:'sewer',safe:false,unlocked:true}
  };

  const achievements = {
    first_blood:{id:'first_blood',name:'First Blood',description:'Defeat any enemy.',condition:{type:'kills',count:1},reward:{coins:25}},
    city_industry:{id:'city_industry',name:'City Industry',description:'Complete one recipe in Smithing, Crafting, Fletching, and Cooking.',condition:{type:'craftedSkills',skills:['smithing','crafting','fletching','cooking']},reward:{coins:500}},
    rat_problem:{id:'rat_problem',name:'Rat Problem',description:'Defeat 50 rats or cave rats.',condition:{type:'enemyKills',enemies:['rat','cave_rat'],count:50},reward:{items:{steel_sword:1}}},
    sewer_secret:{id:'sewer_secret',name:'Beneath Crownstone',description:'Open the locked sewer treasure chest.',condition:{type:'flag',flag:'sewer_chest_opened'},reward:{coins:1000}},
    total_250:{id:'total_250',name:'Developing Adventurer',description:'Reach total level 250.',condition:{type:'totalLevel',count:250},reward:{coins:2500}}
  };

  const randomEvents = {
    falling_star:{id:'falling_star',name:'Fallen Star',chancePerMinute:.08,duration:180,area:'mine',rewardTable:[{item:'iron_ore',chance:.6,min:2,max:8},{item:'coal_ore',chance:.35,min:2,max:6},{item:'gold_ore',chance:.05,min:1,max:2}]},
    wandering_merchant:{id:'wandering_merchant',name:'Wandering Merchant',chancePerMinute:.05,duration:240,area:'city'},
    goblin_raid:{id:'goblin_raid',name:'Goblin Raid',chancePerMinute:.035,duration:300,area:'southlands',spawnEnemy:'goblin',count:12}
  };

  const harvestables = {
    sunberry_bush:{id:'sunberry_bush',name:'Sunberry Bush',icon:'🫐',item:'garden_berries',skill:'farming',level:1,xp:14,qty:[1,3],respawnSeconds:28,shape:'bush',color:'#47713f',produceColor:'#8e315f'},
    apple_tree:{id:'apple_tree',name:'Garden Apple Tree',icon:'🍎',item:'apple',skill:'farming',level:5,xp:24,qty:[1,2],respawnSeconds:42,shape:'tree',color:'#4c783f',produceColor:'#bd3535'},
    carrot_patch:{id:'carrot_patch',name:'Carrot Patch',icon:'🥕',item:'carrot',skill:'farming',level:3,xp:18,qty:[1,3],respawnSeconds:32,shape:'patch',color:'#4f843e',produceColor:'#d66a24'},
    herb_bed:{id:'herb_bed',name:'Kitchen Herb Bed',icon:'🌿',item:'garden_herbs',skill:'farming',level:8,xp:30,qty:[1,2],respawnSeconds:48,shape:'herbs',color:'#3f7f4d',produceColor:'#86b65a'}
  };

  const minigames = {
    garden_rune_match:{id:'garden_rune_match',name:'Garden Rune Match',icon:'🧩',description:'Match six pairs of garden runes as quickly as possible.',pairCount:6,timeLimitSeconds:60,symbols:['🌱','🦋','🍎','🌿','🐕','🐈','⛲','🏹'],rewards:{coins:45,xp:{farming:35},items:{garden_berries:2}}}
  };

  const world = {
    cityBuildings:[
      {id:'bank',name:'Grand Bank',x:-260,z:-220,w:220,d:150,h:120,color:'#8b8274',doorSide:'south',station:'bank'},
      {id:'general_store',name:'General Store',x:40,z:-260,w:180,d:130,h:95,color:'#8a5d39',doorSide:'south',station:'shop'},
      {id:'forge',name:'Forge',x:300,z:-180,w:210,d:160,h:105,color:'#6e4c3d',doorSide:'west',station:'anvil'},
      {id:'fletching_hall',name:'Fletching Hall',x:-380,z:50,w:190,d:150,h:100,color:'#6f7646',doorSide:'east',station:'fletching_bench'},
      {id:'tannery',name:'Tannery',x:-100,z:80,w:170,d:140,h:90,color:'#725139',doorSide:'south',station:'tannery'},
      {id:'weaver_hall',name:'Weaver Hall',x:150,z:70,w:175,d:145,h:95,color:'#796080',doorSide:'south',station:'spinning_wheel'},
      {id:'inn',name:'Golden Ladle Inn',x:400,z:100,w:230,d:180,h:115,color:'#8d5c40',doorSide:'west',station:'range'},
      {id:'tower',name:'Arcane Tower',x:-390,z:-380,w:145,d:145,h:180,color:'#526e8e',doorSide:'east',station:'magic'},
      {id:'ranger_lodge',name:'Ranger Lodge',x:-500,z:300,w:180,d:150,h:100,color:'#546f3e',doorSide:'east',station:'slayer'},
      {id:'guild',name:'Adventurers Guild',x:120,z:360,w:260,d:180,h:130,color:'#8a7048',doorSide:'north',station:'guild'},
      {id:'temple',name:'Temple',x:420,z:360,w:210,d:170,h:125,color:'#b0aa91',doorSide:'north',station:'altar'},
      {id:'barracks',name:'Guard Barracks',x:520,z:-320,w:210,d:160,h:115,color:'#68758c',doorSide:'west',station:'guards'},
      {id:'sewer_works',name:'Sewer Works',x:-80,z:-470,w:180,d:120,h:80,color:'#56645e',doorSide:'north',station:'sewer_entrance'},
      {id:'market_farm',name:'Market Farm',x:-250,z:470,w:150,d:105,h:72,color:'#7a6f3f',doorSide:'east',station:'farm'}
    ],
    npcSpawns:[
      {npc:'banker',x:-260,z:-170},{npc:'shopkeeper',x:40,z:-210},{npc:'blacksmith',x:300,z:-120},{npc:'smelter',x:345,z:-120},{npc:'fletcher',x:-350,z:60},{npc:'tanner',x:-100,z:130},{npc:'weaver',x:150,z:120},{npc:'chef',x:380,z:150},{npc:'wizard',x:-350,z:-350},{npc:'huntsman',x:-460,z:300},{npc:'guildmaster',x:120,z:310},{npc:'priest',x:420,z:310},{npc:'farmer',x:-170,z:360},{npc:'sewer_keeper',x:-80,z:-420},
      {npc:'guard',x:-50,z:-610},{npc:'guard',x:50,z:-610},{npc:'guard',x:620,z:0},{npc:'guard',x:-620,z:0}
    ],
    resourceSpawns:[
      {kind:'tree_normal',x:-1000,z:-150,count:18,radius:500,level:1},{kind:'tree_oak',x:-1300,z:150,count:10,radius:420,level:15},{kind:'tree_willow',x:-1500,z:500,count:8,radius:380,level:30},{kind:'tree_maple',x:-1750,z:150,count:6,radius:350,level:45},{kind:'rock_copper',x:1200,z:-100,count:8,radius:280,level:1},{kind:'rock_tin',x:1450,z:0,count:8,radius:280,level:1},{kind:'rock_iron',x:1550,z:300,count:10,radius:300,level:15},{kind:'rock_coal',x:1700,z:450,count:10,radius:320,level:30},{kind:'fishing_net',x:-700,z:700,count:5,radius:180,level:1},{kind:'fishing_rod',x:-850,z:880,count:5,radius:180,level:20},{kind:'flax',x:-320,z:520,count:20,radius:130,level:1},{kind:'wheat',x:120,z:610,count:18,radius:150,level:1}
    ],
    enemySpawns:[
      {enemy:'chicken',x:-250,z:700,count:10,radius:240},{enemy:'cow',x:-700,z:350,count:10,radius:300},{enemy:'goblin',x:0,z:1050,count:14,radius:450},{enemy:'bear',x:-1500,z:-100,count:8,radius:450},{enemy:'spider',x:-1700,z:650,count:9,radius:420},{enemy:'skeleton',x:1000,z:1200,count:8,radius:450},{enemy:'brigand',x:0,z:1600,count:9,radius:480},{enemy:'wolf',x:-900,z:1350,count:9,radius:450},{enemy:'dark_wizard',x:1200,z:1600,count:7,radius:400},{enemy:'moss_giant',x:1700,z:900,count:6,radius:350},{enemy:'ogre',x:2100,z:1400,count:6,radius:400},{enemy:'red_dragon',x:2350,z:1900,count:1,radius:40,boss:true},
      {enemy:'rat',x:7800,z:7900,count:18,radius:480,area:'sewer'},{enemy:'cave_rat',x:8350,z:8100,count:12,radius:400,area:'sewer'},{enemy:'sewer_slime',x:8050,z:8500,count:10,radius:420,area:'sewer'},{enemy:'sewer_king',x:8600,z:8600,count:1,radius:30,area:'sewer',boss:true},{enemy:'iron_golem',x:1700,z:250,count:1,radius:30,boss:true}
    ],
    specialObjects:[
      {id:'sewer_ladder_down',type:'travel',name:'Climb down sewer ladder',x:-80,z:-510,targetArea:'sewer',target:[7700,7700],icon:'🕳️'},
      {id:'sewer_ladder_up',type:'travel',name:'Climb up to Crownstone',x:7700,z:7700,targetArea:'city',target:[-80,-540],icon:'🪜'},
      {id:'sewer_key_cache',type:'pickup',name:'Search broken drain',x:8250,z:8450,item:'sewer_key',onceFlag:'sewer_key_cache_taken',icon:'🔍'},
      {id:'sewer_treasure',type:'locked_chest',name:'Locked Sewer Treasure Chest',x:8750,z:8750,key:'sewer_key',rewards:{sewer_king_blade:1,plagueguard_body:1,coins:1500},flag:'sewer_chest_opened',icon:'🧰'},
      {id:'silk_stall',type:'thieving_stall',name:'Silk Stall',x:70,z:-80,item:'silk',level:1,xp:40,icon:'🎀'},
      {id:'city_bank',type:'station',name:'Bank Booth',x:-260,z:-135,station:'bank',icon:'🏦'},
      {id:'city_shop',type:'station',name:'General Store Counter',x:40,z:-175,station:'shop',shop:'general_store',icon:'🛒'},
      {id:'city_furnace',type:'station',name:'Furnace',x:260,z:-105,station:'furnace',icon:'🔥'},
      {id:'city_anvil',type:'station',name:'Anvil',x:330,z:-105,station:'anvil',icon:'⚒️'},
      {id:'city_fletching',type:'station',name:'Fletching Bench',x:-320,z:60,station:'fletching_bench',icon:'🏹'},
      {id:'city_tannery',type:'station',name:'Tanning Rack',x:-70,z:130,station:'tannery',icon:'🟫'},
      {id:'city_spinning',type:'station',name:'Spinning Wheel',x:180,z:120,station:'spinning_wheel',icon:'🧶'},
      {id:'city_range',type:'station',name:'Cooking Range',x:350,z:150,station:'range',icon:'🍳'},
      {id:'city_altar',type:'station',name:'Temple Altar',x:420,z:280,station:'altar',icon:'🙏'},
      {id:'city_farm',type:'farm_patch',name:'City Allotment',x:-180,z:500,station:'farm',icon:'🌱'}
    ]
  };

  Object.assign(areas,{
    city:{id:'city',name:'Crownstone City',center:[0,0],size:2100,ground:'#7f8f6a',music:'city',safe:true,unlocked:true,baseY:0,priority:10},
    forest:{id:'forest',name:'Greenwood Forest',center:[-5200,0],size:2600,ground:'#50784a',music:'forest',safe:false,unlocked:true,baseY:0,priority:4},
    mine:{id:'mine',name:'Crownstone Mine',center:[5200,0],size:2500,ground:'#777064',music:'mine',safe:false,unlocked:true,baseY:0,priority:4},
    southlands:{id:'southlands',name:'South Road',center:[0,5400],size:3000,ground:'#858759',music:'field',safe:false,unlocked:true,baseY:0,priority:3},
    east_wastes:{id:'east_wastes',name:'Eastern Wastes',center:[5400,5400],size:2600,ground:'#8b684e',music:'wastes',safe:false,unlocked:false,requireQuest:'dragon_slayer',baseY:0,priority:5},
    house:{id:'house',name:`${'Player'}-Owned House`,center:[16000,0],size:1150,ground:'#687f55',music:'home',safe:true,unlocked:true,baseY:0,priority:20},
    sewer:{id:'sewer',name:'Crownstone Sewers',center:[30000,30000],size:1850,ground:'#39453e',music:'sewer',safe:false,unlocked:true,baseY:-60,priority:30}
  });

  npcs.carpenter={id:'carpenter',name:'Carpenter Nessa',role:'craft',station:'sawmill',color:'#9b7447',building:'Carpenters Guild',dialogue:['Oak logs become useful planks at the saw bench.'],inventory:['spellbook'],spellbook:{learned:['wind_strike']}};
  shops.general_store.stock.oak_plank=60;
  shops.general_store.stock.steel_nails=300;
  shops.general_store.stock.ball_of_wool=60;

  const buildingLayout = [
    {id:'bank',name:'Grand Bank',icon:'🏦',use:'Store and withdraw items',district:'West Market',x:-1050,z:-820,w:290,d:210,h:140,color:'#8b8274',doorSide:'south',station:'bank'},
    {id:'general_store',name:'General Store',icon:'🛒',use:'Buy tools, runes, seeds, and supplies',district:'West Market',x:-470,z:-850,w:240,d:180,h:115,color:'#8a5d39',doorSide:'south',station:'shop'},
    {id:'forge',name:'Forge',icon:'⚒️',use:'Smelt ore and smith equipment',district:'Foundry Ward',x:500,z:-900,w:330,d:240,h:135,color:'#6e4c3d',doorSide:'south',station:'anvil'},
    {id:'barracks',name:'Guard Barracks',icon:'🛡️',use:'City guards and combat quest',district:'Foundry Ward',x:1200,z:-900,w:300,d:220,h:140,color:'#68758c',doorSide:'south',station:'guards'},
    {id:'sewer_works',name:'Sewer Works',icon:'🕳️',use:'Entrance to the sewer dungeon',district:'South Gate',x:420,z:-1430,w:270,d:175,h:105,color:'#56645e',doorSide:'north',station:'sewer_entrance'},
    {id:'fletching_hall',name:'Fletching Hall',icon:'🏹',use:'Make bows, shafts, and arrows',district:'Craft Row',x:-1120,z:-120,w:280,d:210,h:125,color:'#6f7646',doorSide:'east',station:'fletching_bench'},
    {id:'tannery',name:'Tannery',icon:'🟫',use:'Tan hides into leather',district:'Craft Row',x:-500,z:-80,w:250,d:190,h:110,color:'#725139',doorSide:'south',station:'tannery'},
    {id:'weaver_hall',name:'Weaver Hall',icon:'🧶',use:'Spin flax and wool',district:'Craft Row',x:350,z:-170,w:250,d:190,h:115,color:'#796080',doorSide:'south',station:'spinning_wheel'},
    {id:'inn',name:'Golden Ladle Inn',icon:'🍳',use:'Cook food and begin the chef quest',district:'East Market',x:850,z:-100,w:330,d:250,h:145,color:'#8d5c40',doorSide:'west',station:'range'},
    {id:'tower',name:'Arcane Tower',icon:'✨',use:'Buy runes, staves, and take a magic quest',district:'North Heights',x:-1150,z:900,w:230,d:230,h:220,color:'#526e8e',doorSide:'east',station:'magic'},
    {id:'ranger_lodge',name:'Ranger Lodge',icon:'☠️',use:'Receive Slayer assignments and buy bows',district:'North Heights',x:-470,z:900,w:280,d:210,h:125,color:'#546f3e',doorSide:'east',station:'slayer'},
    {id:'guild',name:'Adventurers Guild',icon:'⚔️',use:'Major quests and adventuring services',district:'North Heights',x:350,z:930,w:360,d:250,h:160,color:'#8a7048',doorSide:'north',station:'guild'},
    {id:'temple',name:'Temple',icon:'🙏',use:'Restore Prayer points',district:'North Heights',x:1030,z:930,w:300,d:230,h:155,color:'#b0aa91',doorSide:'north',station:'altar'},
    {id:'market_farm',name:'Market Farm',icon:'🌱',use:'Plant and harvest crops',district:'Garden Ward',x:-1050,z:1430,w:250,d:170,h:95,color:'#7a6f3f',doorSide:'east',station:'farm'},
    {id:'carpenters_guild',name:'Carpenters Guild',icon:'🪚',use:'Saw logs into house-building planks',district:'Garden Ward',x:350,z:1400,w:310,d:210,h:130,color:'#806044',doorSide:'south',station:'sawmill'}
  ];
  world.cityBuildings=buildingLayout;
  world.cityRoads=[
    {id:'king_road',name:'King Road',x:0,z:0,w:190,d:3500,width:190},
    {id:'central_boulevard',name:'Central Boulevard',x:0,z:100,w:3500,d:190,width:190},
    {id:'market_way',name:'Market Way',x:0,z:-625,w:3100,d:180,width:180},
    {id:'north_heights_way',name:'North Heights Way',x:0,z:700,w:3150,d:180,width:180},
    {id:'garden_lane',name:'Garden Lane',x:-150,z:1580,w:2500,d:170,width:170},
    {id:'west_craft_lane',name:'West Craft Lane',x:-800,z:430,w:160,d:2350,width:160},
    {id:'east_market_lane',name:'East Market Lane',x:600,z:350,w:160,d:2150,width:160},
    {id:'sewer_spur',name:'Sewer Works Spur',x:225,z:-1600,w:520,d:150,width:150}
  ];
  world.npcSpawns=[
    {npc:'banker',x:-1050,z:-650},{npc:'shopkeeper',x:-470,z:-690},{npc:'blacksmith',x:450,z:-690},{npc:'smelter',x:570,z:-690},
    {npc:'fletcher',x:-930,z:-120},{npc:'tanner',x:-500,z:85},{npc:'weaver',x:350,z:-25},{npc:'chef',x:620,z:-100},
    {npc:'wizard',x:-990,z:900},{npc:'huntsman',x:-280,z:900},{npc:'guildmaster',x:350,z:755},{npc:'priest',x:1030,z:775},
    {npc:'farmer',x:-875,z:1430},{npc:'sewer_keeper',x:420,z:-1600},{npc:'carpenter',x:350,z:1600},
    {npc:'guard',x:-140,z:-1720},{npc:'guard',x:140,z:-1720},{npc:'guard',x:1720,z:0},{npc:'guard',x:-1720,z:0},{npc:'guard',x:0,z:1720},{npc:'guard',x:930,z:-760}
  ];
  world.resourceSpawns=[
    {kind:'tree_normal',x:-4200,z:-400,count:30,radius:900,level:1},{kind:'tree_oak',x:-5200,z:200,count:20,radius:760,level:15},{kind:'tree_willow',x:-6000,z:800,count:16,radius:650,level:30},{kind:'tree_maple',x:-6300,z:-600,count:12,radius:620,level:45},{kind:'tree_yew',x:-7000,z:500,count:8,radius:520,level:60},
    {kind:'rock_copper',x:4100,z:-650,count:14,radius:500,level:1},{kind:'rock_tin',x:4800,z:-400,count:14,radius:500,level:1},{kind:'rock_iron',x:5350,z:250,count:18,radius:600,level:15},{kind:'rock_coal',x:6100,z:650,count:16,radius:620,level:30},{kind:'rock_silver',x:6500,z:-500,count:8,radius:400,level:40},{kind:'rock_gold',x:7000,z:400,count:7,radius:380,level:50},
    {kind:'fishing_net',x:-2600,z:2500,count:8,radius:330,level:1},{kind:'fishing_rod',x:-3100,z:2900,count:8,radius:330,level:20},{kind:'flax',x:-1180,z:1320,count:28,radius:190,level:1},{kind:'wheat',x:-750,z:1500,count:24,radius:210,level:1}
  ];
  world.enemySpawns=[
    {enemy:'chicken',x:-1200,z:2450,count:14,radius:420,area:'southlands'},{enemy:'cow',x:-2700,z:800,count:14,radius:520,area:'forest'},{enemy:'goblin',x:0,z:2850,count:18,radius:700,area:'southlands'},
    {enemy:'bear',x:-5600,z:-500,count:11,radius:680,area:'forest'},{enemy:'spider',x:-6200,z:1100,count:12,radius:600,area:'forest'},{enemy:'skeleton',x:3300,z:4300,count:12,radius:680,area:'southlands'},
    {enemy:'brigand',x:0,z:5000,count:13,radius:760,area:'southlands'},{enemy:'wolf',x:-3800,z:3100,count:13,radius:700,area:'forest'},{enemy:'dark_wizard',x:3900,z:5100,count:10,radius:600,area:'east_wastes'},
    {enemy:'moss_giant',x:5800,z:2500,count:9,radius:560,area:'mine'},{enemy:'ogre',x:6200,z:5000,count:9,radius:620,area:'east_wastes'},{enemy:'red_dragon',x:7000,z:6500,count:1,radius:40,area:'east_wastes',boss:true},
    {enemy:'rat',x:29400,z:29400,count:22,radius:620,area:'sewer'},{enemy:'cave_rat',x:30200,z:29800,count:16,radius:560,area:'sewer'},{enemy:'sewer_slime',x:29800,z:30700,count:14,radius:580,area:'sewer'},
    {enemy:'sewer_king',x:30900,z:30900,count:1,radius:30,area:'sewer',boss:true},{enemy:'iron_golem',x:6000,z:0,count:1,radius:30,area:'mine',boss:true}
  ];
  world.terrainRegions=[
    {id:'overworld',name:'Overworld Ground',x:0,z:2600,w:16000,d:16000,y:-0.65,color:'#657f50'},
    {id:'house_ground',name:'House Grounds',x:16000,z:0,w:2300,d:2300,y:-0.35,color:'#66804f'},
    {id:'sewer_ground',name:'Sewer Foundation',x:30000,z:30000,w:3700,d:3700,y:-60.5,color:'#39453e'}
  ];
  world.specialObjects=[
    {id:'house_portal_out',type:'travel',visual:'portal',name:'Portal to Crownstone City Center',x:16000,z:120,targetArea:'city',target:[0,0],icon:'🌀'},
    {id:'city_home_portal',type:'travel',visual:'portal',name:'Portal to Your Player-Owned House',x:0,z:0,targetArea:'house',target:[16000,160],icon:'🏠'},
    {id:'sewer_ladder_down',type:'travel',visual:'ladder',name:'Climb down sewer ladder',x:420,z:-1550,targetArea:'sewer',target:[29050,29050],icon:'🕳️'},
    {id:'sewer_ladder_up',type:'travel',visual:'ladder',name:'Climb up to Crownstone',x:29050,z:29050,targetArea:'city',target:[420,-1600],icon:'🪜'},
    {id:'sewer_key_cache',type:'pickup',name:'Search broken drain',x:30100,z:30550,item:'sewer_key',onceFlag:'sewer_key_cache_taken',icon:'🔍'},
    {id:'sewer_treasure',type:'locked_chest',name:'Locked Sewer Treasure Chest',x:31100,z:31100,key:'sewer_key',rewards:{sewer_king_blade:1,plagueguard_body:1,coins:1500},flag:'sewer_chest_opened',icon:'🧰'},
    {id:'silk_stall',type:'thieving_stall',name:'Silk Stall',x:-200,z:-570,item:'silk',level:1,xp:40,icon:'🎀'},
    {id:'city_bank',type:'station',name:'Bank Booth — Store Items',x:-1050,z:-670,station:'bank',icon:'🏦'},
    {id:'city_shop',type:'station',name:'General Store Counter — Buy & Sell',x:-470,z:-715,station:'shop',shop:'general_store',icon:'🛒'},
    {id:'city_furnace',type:'station',name:'Furnace — Smelt Bars',x:420,z:-710,station:'furnace',icon:'🔥'},
    {id:'city_anvil',type:'station',name:'Anvil — Smith Equipment',x:570,z:-710,station:'anvil',icon:'⚒️'},
    {id:'city_fletching',type:'station',name:'Fletching Bench — Make Bows & Arrows',x:-935,z:-120,station:'fletching_bench',icon:'🏹'},
    {id:'city_tannery',type:'station',name:'Tanning Rack — Tan Hides',x:-500,z:70,station:'tannery',icon:'🟫'},
    {id:'city_spinning',type:'station',name:'Spinning Wheel — Spin Fibres',x:350,z:-25,station:'spinning_wheel',icon:'🧶'},
    {id:'city_range',type:'station',name:'Cooking Range — Cook Food',x:640,z:-100,station:'range',icon:'🍳'},
    {id:'city_altar',type:'station',name:'Temple Altar — Restore Prayer',x:1030,z:775,station:'altar',icon:'🙏'},
    {id:'city_farm',type:'farm_patch',name:'City Allotment — Plant Seeds',x:-875,z:1430,station:'farm',icon:'🌱'},
    {id:'city_sawmill',type:'station',name:'Saw Bench — Make Oak Planks',x:350,z:1550,station:'sawmill',icon:'🪚'},
    {id:'house_bank',type:'station',name:'House Bank Chest',x:15750,z:-140,station:'bank',icon:'🧰'},
    {id:'house_range',type:'station',name:'House Cooking Range',x:15880,z:-150,station:'range',icon:'🍳'},
    {id:'house_crafting',type:'station',name:'House Crafting Table',x:16020,z:-150,station:'crafting_table',icon:'🧵'},
    {id:'house_altar',type:'station',name:'House Altar',x:16160,z:-150,station:'altar',icon:'🙏'},
    {id:'house_bed',type:'rest',name:'Rest in Your Bed',x:15780,z:280,icon:'🛏️'},
    {id:'house_spell_lectern',type:'spellbook',name:'Spellbook Lectern',x:16160,z:260,icon:'📕'},
    {id:'house_arcane_door',type:'house_unlock',name:'Locked Arcane Study',x:16330,z:250,requirements:{oak_plank:8,steel_nails:20,arcane_lens:1},flag:'house_arcane_study_unlocked',unlockName:'Arcane Study',icon:'🔒'},
    {id:'house_pet_door',type:'house_unlock',name:'Locked Pet Room',x:16330,z:-180,requirements:{oak_plank:6,steel_nails:10,pet_bedding:1,rope:2},flag:'house_pet_room_unlocked',unlockName:'Pet Room',icon:'🔒'},
    {id:'house_enchanting_desk',type:'spellbook',name:'Arcane Study Spell Desk',x:16500,z:260,visibleWhenFlag:'house_arcane_study_unlocked',icon:'🔮'},
    {id:'house_pet_manager',type:'pet_manager',name:'Pet Room Adoption Board',x:16500,z:-180,visibleWhenFlag:'house_pet_room_unlocked',icon:'🐾'}
  ];
  world.playerHouse={center:[16000,0],w:1000,d:760,rooms:[
    {id:'main_hall',name:'Main Hall',x:16000,z:60,w:500,d:360,unlocked:true,color:'#8b7458'},
    {id:'kitchen',name:'Kitchen & Workshop',x:15860,z:-170,w:360,d:250,unlocked:true,color:'#7d684f'},
    {id:'bedroom',name:'Bedroom',x:15820,z:280,w:280,d:230,unlocked:true,color:'#745f55'},
    {id:'chapel',name:'Chapel',x:16170,z:-170,w:230,d:250,unlocked:true,color:'#8d846b'},
    {id:'arcane_study',name:'Arcane Study',x:16500,z:260,w:300,d:260,flag:'house_arcane_study_unlocked',color:'#5e587f'},
    {id:'pet_room',name:'Pet Room',x:16500,z:-180,w:300,d:260,flag:'house_pet_room_unlocked',color:'#7d6659'}
  ]};
  world.decorationZones=[
    {type:'lamp',x1:-1650,z1:-1650,x2:1650,z2:1650,step:260,count:0},
    {type:'market_clutter',x:-760,z:-500,count:36,radius:520},
    {type:'garden',x:-850,z:1150,count:80,radius:520},
    {type:'residential',x:850,z:1250,count:55,radius:560},
    {type:'forest_floor',x:-5200,z:0,count:180,radius:2200},
    {type:'mine_clutter',x:5200,z:0,count:100,radius:1900}
  ];

  const animals={
    butterfly:{id:'butterfly',name:'Butterfly',icon:'🦋',shape:'butterfly',color:'#e8a8e8',secondaryColor:'#73bde8',speed:1.8,adoptable:false,temporaryFollow:false},
    dog:{id:'dog',name:'Friendly Dog',icon:'🐕',shape:'dog',color:'#9b6d45',secondaryColor:'#5a3828',speed:2.2,adoptable:true,temporaryFollow:true,followSeconds:[12,28]},
    cat:{id:'cat',name:'Curious Cat',icon:'🐈',shape:'cat',color:'#777b82',secondaryColor:'#d1c9b8',speed:2.4,adoptable:true,temporaryFollow:true,followSeconds:[10,24]}
  };
  world.animalSpawns=[
    {animal:'butterfly',x:-900,z:1150,count:28,radius:650,area:'city'},
    {animal:'butterfly',x:-5200,z:200,count:45,radius:1900,area:'forest'},
    {animal:'dog',x:-350,z:350,count:8,radius:1200,area:'city'},
    {animal:'cat',x:450,z:500,count:10,radius:1250,area:'city'},
    {animal:'cat',x:16000,z:0,count:2,radius:340,area:'house'}
  ];
  world.harvestableSpawns=[
    {harvestable:'apple_tree',x:15340,z:-650,count:3,radius:75,area:'house'},
    {harvestable:'sunberry_bush',x:15490,z:-800,count:5,radius:72,area:'house'},
    {harvestable:'carrot_patch',x:15680,z:-800,count:6,radius:64,area:'house'},
    {harvestable:'herb_bed',x:15820,z:-735,count:5,radius:58,area:'house'}
  ];

  world.resourceSpawns.push(
    {kind:'tree_normal',x:15370,z:650,count:6,radius:105,level:1,area:'house'},
    {kind:'tree_oak',x:16610,z:640,count:4,radius:95,level:15,area:'house'},
    {kind:'flax',x:15470,z:-650,count:12,radius:105,level:1,area:'house'},
    {kind:'wheat',x:15630,z:-710,count:12,radius:100,level:1,area:'house'},
    {kind:'fishing_net',x:16000,z:760,count:1,radius:0,level:1,area:'house'}
  );
  world.specialObjects.push(
    {id:'house_front_door',type:'door',name:'Front Garden Door',x:16000,z:-380,openFlag:'house_front_door_open',openAngle:-1.5708,icon:'🚪'},
    {id:'house_back_door',type:'door',name:'Back Yard Door',x:16000,z:380,openFlag:'house_back_door_open',openAngle:1.5708,icon:'🚪'},
    {id:'house_healing_fountain',type:'healing_fountain',name:'Restorative Home Fountain',x:16000,z:-610,icon:'⛲'},
    {id:'house_outdoor_farm',type:'farm_patch',name:'Home Garden Allotment',x:15640,z:-585,station:'farm',icon:'🌱'},
    {id:'house_outdoor_range',type:'station',name:'Outdoor Cooking Hearth',x:16430,z:-610,station:'range',icon:'🔥'},
    {id:'house_training_dummy',type:'training_dummy',name:'Home Combat Training Dummy',x:16410,z:570,icon:'🎯'},
    {id:'house_garden_game',type:'minigame',name:'Garden Rune Match Table',x:16180,z:760,game:'garden_rune_match',icon:'🧩'}
  );
  world.playerHouse.doors=[
    {id:'house_front_door',name:'Front Garden Door',x:16000,z:-380,openFlag:'house_front_door_open'},
    {id:'house_back_door',name:'Back Yard Door',x:16000,z:380,openFlag:'house_back_door_open'}
  ];
  world.playerHouse.outdoorActivities=[
    {id:'house_healing_fountain',name:'Restorative fountain',effect:'Full heal and +1 hitpoint per second for 10 minutes'},
    {id:'house_outdoor_farm',name:'Garden allotment',skill:'farming'},
    {id:'house_fishing_pond',name:'Fishing pond',skill:'fishing'},
    {id:'house_woodcutting_grove',name:'Normal and oak grove',skill:'woodcutting'},
    {id:'house_outdoor_range',name:'Outdoor cooking hearth',skill:'cooking'},
    {id:'house_training_dummy',name:'Combat training dummy',skill:'attack and strength'},
    {id:'house_garden_game',name:'Garden Rune Match',skill:'farming',effect:'Memory matching game with coins, Farming XP, and garden produce'}
  ];

  const skills = ['attack','strength','defence','ranged','magic','prayer','hitpoints','woodcutting','firemaking','fishing','cooking','mining','smithing','farming','thieving','crafting','fletching','slayer'].reduce((o,id)=>{o[id]={id,name:id[0].toUpperCase()+id.slice(1),icon:{attack:'⚔️',strength:'💪',defence:'🛡️',ranged:'🏹',magic:'✨',prayer:'🙏',hitpoints:'❤️',woodcutting:'🪓',firemaking:'🔥',fishing:'🎣',cooking:'🍳',mining:'⛏️',smithing:'⚒️',farming:'🌱',thieving:'🕵️',crafting:'🧵',fletching:'🏹',slayer:'☠️'}[id]};return o;},{});

  window.DEFAULT_GAME_DATA = {
    meta:{gameId:'runelite_primitive_realm',name:'RuneLite: Primitive Realm',schemaVersion:8,contentVersion:4,tablePrefix:'FSG_Runelite_',mapSize:34000,serverAuthoritativePersistence:true},
    settings:{inventorySlots:28,maxBankSlots:800,walkSpeed:90,runSpeed:155,enemyRespawnSeconds:22,resourceRespawnSeconds:15,autosaveSeconds:25,aggroLeash:320,guardAssistRadius:300,dayLengthMinutes:24,houseRoofIndoorOpacity:.14,fountainRegenSeconds:600,fountainRegenPerSecond:1},
    skills,items,recipes,enemies,bosses,animals,harvestables,minigames,npcs,shops,quests,slayerTasks,spells,prayers,areas,achievements,randomEvents,world
  };
})();

(() => {
'use strict';

const API_URL = 'Runelite.php';
const $ = (id) => document.getElementById(id);
const clone = (value) => JSON.parse(JSON.stringify(value));
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const distance2D = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
const randomInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const uid = (prefix = 'id') => `${prefix}_${Math.random().toString(36).slice(2, 10)}_${Date.now().toString(36)}`;
const esc = (s) => String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

class PrimitiveRealmGame {
  constructor() {
    this.data = clone(window.DEFAULT_GAME_DATA);
    this.playerColor = '#2f6ee5';
    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.clock = new THREE.Clock();
    this.raycaster = new THREE.Raycaster();
    this.pointer = new THREE.Vector2();
    this.worldRoot = new THREE.Group();
    this.fxRoot = new THREE.Group();
    this.playerMesh = null;
    this.playerArmPivot = null;
    this.playerToolRoot = null;
    this.terrainMeshes = [];
    this.houseRoofMeshes = [];
    this.houseInteriorActive = false;
    this.regenAccumulator = 0;
    this.interactives = [];
    this.obstacles = [];
    this.enemies = new Map();
    this.npcActors = new Map();
    this.animalActors = new Map();
    this.resources = new Map();
    this.harvestables = new Map();
    this.specials = new Map();
    this.groundItems = new Map();
    this.projectiles = [];
    this.pendingAction = null;
    this.actionToken = 0;
    this.activeModal = null;
    this.activeTab = 'inventory';
    this.selectedSpell = null;
    this.selectedPrayer = new Set();
    this.audioEnabled = true;
    this.audioContext = null;
    this.cameraMode = 'follow';
    this.cameraYaw = Math.PI * .25;
    this.cameraPitch = .72;
    this.cameraDistance = 520;
    this.draggingCamera = false;
    this.lastMouse = {x:0,y:0};
    this.lastTimestamp = performance.now();
    this.worldTime = 8;
    this.randomEventAccumulator = 0;
    this.autosaveAccumulator = 0;
    this.minimapAccumulator = 0;
    this.server = {online:false, authenticated:false, isAdmin:false, revision:0, status:'Local mode'};
    this.sessionId = localStorage.getItem('FSG_Runelite_SessionId') || `RL-${crypto.getRandomValues(new Uint32Array(2)).join('-')}`;
    localStorage.setItem('FSG_Runelite_SessionId', this.sessionId);
    this.state = this.createInitialState();
    this.animation = {toolSwing:0, bowDraw:0, hurt:0};
    this.eventQueue = [];
    this.dragPayload = null;
    this.draggingItem = false;
    this.boundLoop = this.loop.bind(this);
  }

  createInitialState() {
    const skills = {};
    Object.keys(this.data.skills).forEach(id => {
      const startingLevel = id === 'hitpoints' ? 10 : 1;
      skills[id] = {level:startingLevel, xp:0};
    });
    const inventory=Array(this.data.settings.inventorySlots).fill(null);
    [
      {id:'spellbook',qty:1},{id:'bronze_hatchet',qty:1},{id:'bronze_pickaxe',qty:1},{id:'tinderbox',qty:1},
      {id:'small_fishing_net',qty:1},{id:'bucket',qty:1},{id:'knife',qty:1},{id:'hammer',qty:1},
      {id:'needle',qty:1},{id:'thread',qty:30},{id:'chisel',qty:1},{id:'coins',qty:100}
    ].forEach((stack,index)=>inventory[index]=stack);
    return {
      schemaVersion:this.data.meta.schemaVersion,
      name:'Zezima', color:this.playerColor,
      area:'house', position:{x:16000,z:160}, target:{x:16000,z:160},
      hp:20, maxHp:20, prayer:1, maxPrayer:1, runEnergy:100, runEnabled:true,
      skills,
      inventory,
      spellbook:{itemId:'spellbook',learned:Object.keys(this.data.spells),activeBook:'standard'},
      hotbar:Array(10).fill(null),
      equipment:{head:null,body:null,legs:null,feet:null,hands:null,weapon:null,shield:null,ammo:null,cape:null,neck:null,ring:null}, ammoQty:0,
      bank:[{id:'coins',qty:250},{id:'mind_rune',qty:30},{id:'air_rune',qty:50},{id:'fire_rune',qty:30},{id:'law_rune',qty:4},{id:'cabbage_seed',qty:10},{id:'barley_seed',qty:10}],
      quests:Object.fromEntries(Object.keys(this.data.quests).map(id => [id,{state:0,progress:{}}])),
      collection:{}, kills:{}, crafted:{}, flags:{}, achievements:{}, adoptedPets:{}, minigames:{},
      preferences:{disableIndoorCameraSpin:true}, buffs:{homeFountainRegenUntil:0,houseTrainingCooldownUntil:0},
      slayerTask:null, combatTarget:null, attackCooldown:0, combatStyle:'accurate',
      wanted:0, poison:0, farm:{stage:0,seed:null,plantedAt:0},
      recentLevels:[], playSeconds:0, saveRevision:0, lastSavedAt:null
    };
  }

  normalizeState() {
    const initial=this.createInitialState();
    const current=this.state&&typeof this.state==='object'?this.state:{};
    this.state={...initial,...current};
    this.state.skills={...initial.skills,...(current.skills||{})};
    this.state.equipment={...initial.equipment,...(current.equipment||{})};
    this.state.quests={...initial.quests,...(current.quests||{})};
    Object.keys(this.state.quests).forEach(id=>this.state.quests[id]={state:0,progress:{},...(this.state.quests[id]||{}),progress:{...((this.state.quests[id]||{}).progress||{})}});
    this.state.collection={...(current.collection||{})};
    this.state.kills={...(current.kills||{})};
    this.state.crafted={...(current.crafted||{})};
    this.state.flags={...(current.flags||{})};
    this.state.achievements={...(current.achievements||{})};
    this.state.adoptedPets={...(current.adoptedPets||{})};
    this.state.minigames={...(current.minigames||{})};
    this.state.preferences={...initial.preferences,...(current.preferences||{})};
    this.state.buffs={...initial.buffs,...(current.buffs||{})};
    this.state.spellbook={...initial.spellbook,...(current.spellbook||{})};
    this.state.spellbook.learned=[...new Set((this.state.spellbook.learned||[]).filter(id=>this.data.spells[id]))];
    if(!this.state.spellbook.learned.length)this.state.spellbook.learned=Object.keys(this.data.spells);
    this.state.hotbar=Array.from({length:10},(_,i)=>this.data.spells[(current.hotbar||[])[i]]?(current.hotbar||[])[i]:null);
    const compact=Array.isArray(current.inventory)?current.inventory.filter(Boolean).map(stack=>({id:stack.id,qty:Math.max(1,Number(stack.qty)||1)})):[];
    const slots=Array(this.data.settings.inventorySlots).fill(null);
    compact.slice(0,slots.length).forEach((stack,index)=>slots[index]=stack);
    this.state.inventory=slots;
    if(!this.state.inventory.some(stack=>stack?.id==='spellbook')){
      const empty=this.state.inventory.findIndex(stack=>!stack);
      if(empty>=0)this.state.inventory[empty]={id:'spellbook',qty:1};
      else this.state.inventory[0]={id:'spellbook',qty:1};
    }
    this.state.bank=Array.isArray(current.bank)?current.bank.filter(Boolean):initial.bank;
    const incomingSchema=Number(current.schemaVersion||0);
    if(incomingSchema<6&&!this.state.flags.house_intro_migrated){this.state.area='house';this.state.position={x:16000,z:160};this.state.flags.house_intro_migrated=true;}
    this.state.schemaVersion=this.data.meta.schemaVersion;
    this.state.position=this.state.position||{x:16000,z:160};
    this.state.area=this.data.areas[this.state.area]?this.state.area:this.detectAreaAt(this.state.position.x,this.state.position.z);
    this.state.target={...this.state.position};
  }

  async boot() {
    document.querySelectorAll('.color-chip').forEach(button => button.addEventListener('click', () => {
      document.querySelectorAll('.color-chip').forEach(b => b.classList.remove('selected'));
      button.classList.add('selected');
      this.playerColor = button.dataset.color;
    }));
    $('enter-world').addEventListener('click', async () => {
      this.state.name = $('character-name').value.trim() || 'Adventurer';
      this.state.color = this.playerColor;
      $('enter-world').disabled = true;
      $('enter-world').textContent = 'Loading realm...';
      await this.loadRemoteContent();
      await this.loadPlayerState();
      this.start();
    });
  }

  start() {
    this.normalizeState();
    $('boot-screen').classList.remove('visible');
    $('game-root').classList.remove('hidden');
    this.initThree();
    this.buildWorld();
    this.bindUI();
    this.applyPlayerStateToWorld();
    this.switchTab('inventory');
    this.updateHUD();
    this.addChat('system', `Welcome home, ${this.state.name}. Use the portal to enter Crownstone City.`);
    this.addChat('system', this.server.online ? 'Connected to server save services.' : 'Server unavailable: local JSON recovery save is active.');
    this.addChat('action', 'Right-click people, creatures, resources, buildings, and objects for actions.');
    requestAnimationFrame(this.boundLoop);
  }

  initThree() {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#8ab0c9');
    this.scene.fog = new THREE.Fog('#8ab0c9', 1100, 3800);
    this.camera = new THREE.PerspectiveCamera(52, innerWidth / innerHeight, 1, 15000);
    this.renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:'high-performance'});
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.setSize(innerWidth, innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    $('viewport').appendChild(this.renderer.domElement);
    this.scene.add(this.worldRoot, this.fxRoot);

    const hemi = new THREE.HemisphereLight('#d9f0ff', '#4e4a39', 2.15);
    this.scene.add(hemi);
    const sun = new THREE.DirectionalLight('#fff4d6', 2.8);
    sun.position.set(-700, 1100, -450);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -1800; sun.shadow.camera.right = 1800;
    sun.shadow.camera.top = 1800; sun.shadow.camera.bottom = -1800;
    this.scene.add(sun);
    this.sun = sun;

    this.createPlayer();
    this.renderer.domElement.addEventListener('mousemove', e => this.onPointerMove(e));
    this.renderer.domElement.addEventListener('mousedown', e => this.onPointerDown(e));
    this.renderer.domElement.addEventListener('mouseup', () => this.draggingCamera = false);
    this.renderer.domElement.addEventListener('wheel', e => {
      this.cameraDistance = clamp(this.cameraDistance + e.deltaY * .35, 180, 920);
    }, {passive:true});
    this.renderer.domElement.addEventListener('contextmenu', e => e.preventDefault());
    window.addEventListener('resize', () => this.resize());
    window.addEventListener('beforeunload', () => this.saveLocal());
    window.addEventListener('keydown', e => this.onKey(e));
  }

  createPlayer() {
    const root = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({color:this.state.color, roughness:.8});
    const skinMat = new THREE.MeshStandardMaterial({color:'#c9976f', roughness:.85});
    const darkMat = new THREE.MeshStandardMaterial({color:'#2a2827'});
    const body = new THREE.Mesh(new THREE.CylinderGeometry(14, 17, 38, 10), bodyMat);
    body.position.y = 36; body.castShadow = true;
    const head = new THREE.Mesh(new THREE.SphereGeometry(12, 12, 9), skinMat);
    head.position.y = 65; head.castShadow = true;
    const leg1 = new THREE.Mesh(new THREE.BoxGeometry(10, 24, 10), darkMat);
    const leg2 = leg1.clone(); leg1.position.set(-7,12,0); leg2.position.set(7,12,0);
    const armPivot = new THREE.Group(); armPivot.position.set(17,52,0);
    const arm = new THREE.Mesh(new THREE.BoxGeometry(8,28,8), skinMat); arm.position.y = -13;
    armPivot.add(arm);
    const toolRoot = new THREE.Group(); toolRoot.position.set(0,-27,0); armPivot.add(toolRoot);
    const arm2 = new THREE.Mesh(new THREE.BoxGeometry(8,28,8), skinMat); arm2.position.set(-17,39,0);
    root.add(body,head,leg1,leg2,armPivot,arm2);
    root.traverse(o => {if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});
    this.playerMesh = root;
    this.playerArmPivot = armPivot;
    this.playerToolRoot = toolRoot;
    this.worldRoot.add(root);
    this.updateHeldItem();
  }

  buildWorld() {
    this.clearWorldExceptPlayer();
    this.buildTerrains();
    this.buildRoadsAndWalls();
    this.createPlayerHouse();
    this.data.world.cityBuildings.forEach(def => this.createBuilding(def));
    this.data.world.npcSpawns.forEach((def,i) => this.createNPC(def, i));
    this.data.world.resourceSpawns.forEach((def,i) => this.createResourceGroup(def, i));
    this.data.world.enemySpawns.forEach((def,i) => this.createEnemyGroup(def, i));
    (this.data.world.animalSpawns||[]).forEach((def,i) => this.createAnimalGroup(def, i));
    (this.data.world.harvestableSpawns||[]).forEach((def,i) => this.createHarvestableGroup(def, i));
    this.data.world.specialObjects.forEach((def,i) => this.createSpecial(def, i));
    this.createSewerArchitecture();
    this.createDecorations();
    this.refreshHouseObjects();
    this.refreshQuestMarkers();
  }

  clearWorldExceptPlayer() {
    [...this.worldRoot.children].forEach(child => { if (child !== this.playerMesh) this.worldRoot.remove(child); });
    this.terrainMeshes=[]; this.houseRoofMeshes=[]; this.houseInteriorActive=false; this.interactives=[]; this.obstacles=[];
    this.enemies.clear(); this.npcActors.clear(); this.animalActors.clear(); this.resources.clear(); this.harvestables.clear(); this.specials.clear(); this.groundItems.clear();
  }

  makeMaterial(color, extra={}) { return new THREE.MeshStandardMaterial({color,roughness:.82,metalness:.03,...extra}); }
  addInteractive(object, payload) {
    object.userData.interactive = payload;
    object.traverse(o => { o.userData.interactiveRoot = object; });
    this.interactives.push(object);
  }

  buildTerrains() {
    const regions=this.data.world.terrainRegions||[];
    regions.forEach(region=>{
      const ground=new THREE.Mesh(new THREE.BoxGeometry(region.w,2,region.d),this.makeMaterial(region.color));
      ground.position.set(region.x,(region.y??0)-1,region.z);
      ground.receiveShadow=true;
      ground.userData.groundArea=region.id;
      ground.userData.region=region;
      this.worldRoot.add(ground);
      this.terrainMeshes.push(ground);
    });
    ['forest','mine','southlands','east_wastes'].forEach((id,index)=>{const area=this.data.areas[id];const patch=new THREE.Mesh(new THREE.BoxGeometry(area.size*2,.26,area.size*2),this.makeMaterial(area.ground));patch.position.set(area.center[0],-.48+index*.035,area.center[1]);patch.receiveShadow=true;patch.userData.groundArea=id;this.worldRoot.add(patch);this.terrainMeshes.push(patch);});
  }

  detectAreaAt(x,z) {
    const matches=Object.values(this.data.areas).filter(area=>Math.abs(x-area.center[0])<=area.size&&Math.abs(z-area.center[1])<=area.size);
    matches.sort((a,b)=>(b.priority||0)-(a.priority||0));
    return matches[0]?.id||'southlands';
  }

  areaY(x,z) {
    const id=this.detectAreaAt(x,z);
    return this.data.areas[id]?.baseY||0;
  }

  getBuildingDoorPosition(def, offset=0) {
    const side=def.doorSide||'south';
    if(side==='north')return {x:def.x,z:def.z-def.d/2-offset,side};
    if(side==='east')return {x:def.x+def.w/2+offset,z:def.z,side};
    if(side==='west')return {x:def.x-def.w/2-offset,z:def.z,side};
    return {x:def.x,z:def.z+def.d/2+offset,side:'south'};
  }

  nearestRoadPoint(x,z) {
    const roads=this.data.world.cityRoads||[];let best=null;
    roads.forEach(road=>{
      const horizontal=road.w>=road.d;
      const point=horizontal?{x:clamp(x,road.x-road.w/2,road.x+road.w/2),z:road.z}:{x:road.x,z:clamp(z,road.z-road.d/2,road.z+road.d/2)};
      const dist=Math.hypot(point.x-x,point.z-z);
      if(!best||dist<best.dist)best={...point,dist,road};
    });
    return best;
  }

  createRoadMesh(x,z,w,d,material,y=.02) {
    if(w<=0||d<=0)return;
    const road=new THREE.Mesh(new THREE.BoxGeometry(w,.72,d),material);road.position.set(x,y,z);road.receiveShadow=true;this.worldRoot.add(road);
  }

  createBuildingConnector(def,roadMat) {
    const entrance=this.getBuildingDoorPosition(def,34),nearest=this.nearestRoadPoint(entrance.x,entrance.z);if(!nearest)return;
    const width=82;
    if(Math.abs(nearest.x-entrance.x)>3)this.createRoadMesh((nearest.x+entrance.x)/2,entrance.z,Math.abs(nearest.x-entrance.x)+width,width,roadMat,.065);
    if(Math.abs(nearest.z-entrance.z)>3)this.createRoadMesh(nearest.x,(nearest.z+entrance.z)/2,width,Math.abs(nearest.z-entrance.z)+width,roadMat,.067);
  }

  buildRoadsAndWalls() {
    const plaza=new THREE.Mesh(new THREE.BoxGeometry(560,.74,560),this.makeMaterial('#7c806f'));
    plaza.position.set(0,.01,180);plaza.receiveShadow=true;this.worldRoot.add(plaza);
    const roadMat=this.makeMaterial('#958875');
    (this.data.world.cityRoads||[]).forEach((road,index)=>this.createRoadMesh(road.x,road.z,road.w,road.d,roadMat,.035+index*.001));
    this.data.world.cityBuildings.forEach(def=>this.createBuildingConnector(def,roadMat));
    const wallMat=this.makeMaterial('#8c887c'),extent=1800,gateHalf=125;
    const segments=[
      [-(extent+gateHalf)/2,-extent,extent-gateHalf,42],[(extent+gateHalf)/2,-extent,extent-gateHalf,42],
      [-(extent+gateHalf)/2,extent,extent-gateHalf,42],[(extent+gateHalf)/2,extent,extent-gateHalf,42],
      [-extent,-(extent+gateHalf)/2,42,extent-gateHalf],[-extent,(extent+gateHalf)/2,42,extent-gateHalf],
      [extent,-(extent+gateHalf)/2,42,extent-gateHalf],[extent,(extent+gateHalf)/2,42,extent-gateHalf]
    ];
    segments.forEach(([x,z,w,d])=>{const wall=new THREE.Mesh(new THREE.BoxGeometry(w,98,d),wallMat);wall.position.set(x,49,z);wall.castShadow=true;wall.receiveShadow=true;this.worldRoot.add(wall);this.obstacles.push({x,z,w,d});});
    [[-extent,-extent],[-extent,extent],[extent,-extent],[extent,extent]].forEach(([x,z])=>{const tower=new THREE.Mesh(new THREE.CylinderGeometry(48,56,135,12),wallMat);tower.position.set(x,67.5,z);tower.castShadow=true;this.worldRoot.add(tower);});
    [[0,-extent,0],[0,extent,Math.PI],[extent,0,-Math.PI/2],[-extent,0,Math.PI/2]].forEach(([x,z,rot])=>{
      const gate=new THREE.Group();gate.position.set(x,0,z);gate.rotation.y=rot;
      const p1=new THREE.Mesh(new THREE.BoxGeometry(40,130,52),wallMat);p1.position.set(-120,65,0);const p2=p1.clone();p2.position.x=120;
      const arch=new THREE.Mesh(new THREE.BoxGeometry(280,34,52),wallMat);arch.position.y=114;gate.add(p1,p2,arch);gate.traverse(o=>{if(o.isMesh)o.castShadow=true;});this.worldRoot.add(gate);
    });
    const fountainBase=new THREE.Mesh(new THREE.CylinderGeometry(90,105,20,24),this.makeMaterial('#aeb2ad'));fountainBase.position.set(0,10,260);
    const fountainWater=new THREE.Mesh(new THREE.CylinderGeometry(72,72,7,24),this.makeMaterial('#55a5c5',{transparent:true,opacity:.75}));fountainWater.position.set(0,22,260);
    const fountainColumn=new THREE.Mesh(new THREE.CylinderGeometry(10,16,75,12),this.makeMaterial('#b9b7aa'));fountainColumn.position.set(0,55,260);this.worldRoot.add(fountainBase,fountainWater,fountainColumn);
  }

  createPlayerHouse() {
    const house=this.data.world.playerHouse;if(!house)return;
    const [cx,cz]=house.center;
    const foundation=new THREE.Mesh(new THREE.BoxGeometry(house.w,.8,house.d),this.makeMaterial('#735f48'));foundation.position.set(cx,.1,cz);foundation.receiveShadow=true;this.worldRoot.add(foundation);this.terrainMeshes.push(foundation);
    const wallMat=this.makeMaterial('#d2c39f'),roofMat=this.makeMaterial('#59443a',{transparent:true,opacity:1,depthWrite:true});
    const doorGap=120,frontSegment=(house.w-doorGap)/2,frontOffset=doorGap/2+frontSegment/2;
    const walls=[
      [cx-house.w/2,cz,24,house.d],[cx+house.w/2,cz,24,house.d],
      [cx-frontOffset,cz-house.d/2,frontSegment,24],[cx+frontOffset,cz-house.d/2,frontSegment,24],
      [cx-frontOffset,cz+house.d/2,frontSegment,24],[cx+frontOffset,cz+house.d/2,frontSegment,24]
    ];
    walls.forEach(([x,z,w,d])=>{const wall=new THREE.Mesh(new THREE.BoxGeometry(w,92,d),wallMat);wall.position.set(x,46,z);wall.castShadow=true;this.worldRoot.add(wall);this.obstacles.push({x,z,w,d});});
    house.rooms.forEach((room,index)=>{
      const rug=new THREE.Mesh(new THREE.BoxGeometry(room.w-28,.22,room.d-28),this.makeMaterial(room.color));rug.position.set(room.x,.52+index*.002,room.z);rug.receiveShadow=true;this.worldRoot.add(rug);
      const label=this.makeTextSprite(room.name,room.flag&&!this.state.flags[room.flag]?'#db9a9a':'#f1dfa1',30);label.position.set(room.x,78,room.z);this.worldRoot.add(label);
      if(room.flag){const thickness=16,innerDoorGap=96;const roomWalls=[[room.x+room.w/2,room.z,thickness,room.d],[room.x,room.z-room.d/2,room.w,thickness],[room.x,room.z+room.d/2,room.w,thickness],[room.x-room.w/2,room.z-(room.d+innerDoorGap)/4,thickness,(room.d-innerDoorGap)/2],[room.x-room.w/2,room.z+(room.d+innerDoorGap)/4,thickness,(room.d-innerDoorGap)/2]];roomWalls.forEach(([x,z,w,d])=>{const inner=new THREE.Mesh(new THREE.BoxGeometry(w,80,d),wallMat);inner.position.set(x,40,z);inner.castShadow=true;this.worldRoot.add(inner);this.obstacles.push({x,z,w,d});});}
    });
    const roofA=new THREE.Mesh(new THREE.BoxGeometry(house.w*.48,12,house.d*.95),roofMat);roofA.position.set(cx-house.w*.25,104,cz);roofA.rotation.z=.18;
    const roofB=roofA.clone();roofB.material=roofMat;roofB.position.x=cx+house.w*.25;roofB.rotation.z=-.18;
    roofA.userData.houseRoof=true;roofB.userData.houseRoof=true;this.houseRoofMeshes.push(roofA,roofB);this.worldRoot.add(roofA,roofB);
    const banner=this.makeTextSprite(`🏠 ${this.state.name}'s Player-Owned House`,'#ffe38b',46);banner.position.set(cx,150,cz-house.d/2+25);this.worldRoot.add(banner);
    this.createHouseFurniture(cx,cz);
  }

  createHouseFurniture(cx,cz) {
    const wood=this.makeMaterial('#6c4930'),cloth=this.makeMaterial('#8b6672'),metal=this.makeMaterial('#555d62',{metalness:.25});
    const table=new THREE.Mesh(new THREE.BoxGeometry(90,10,50),wood);table.position.set(cx,35,40);this.worldRoot.add(table);
    [-34,34].forEach(x=>[-15,15].forEach(z=>{const leg=new THREE.Mesh(new THREE.BoxGeometry(7,34,7),wood);leg.position.set(cx+x,17,40+z);this.worldRoot.add(leg);}));
    const bed=new THREE.Mesh(new THREE.BoxGeometry(115,26,58),cloth);bed.position.set(cx-220,16,285);this.worldRoot.add(bed);
    for(let i=0;i<4;i++){const shelf=new THREE.Mesh(new THREE.BoxGeometry(70,10,22),wood);shelf.position.set(cx+155,35+i*24,285);this.worldRoot.add(shelf);}
    const chest=new THREE.Mesh(new THREE.BoxGeometry(58,38,42),metal);chest.position.set(cx-250,20,-140);this.worldRoot.add(chest);
  }

  createBuilding(def) {
    const group=new THREE.Group();group.position.set(def.x,0,def.z);group.name=def.name;
    const wall=new THREE.Mesh(new THREE.BoxGeometry(def.w,def.h,def.d),this.makeMaterial(def.color));wall.position.y=def.h/2;wall.castShadow=true;wall.receiveShadow=true;
    const roof=new THREE.Mesh(new THREE.ConeGeometry(Math.max(def.w,def.d)*.72,def.h*.45,4),this.makeMaterial('#4c342a'));roof.rotation.y=Math.PI/4;roof.position.y=def.h*1.2;roof.scale.z=def.d/def.w;roof.castShadow=true;
    const door=new THREE.Mesh(new THREE.BoxGeometry(54,72,8),this.makeMaterial('#3f2a1c'));
    const doorIcon=this.makeTextSprite(def.icon||'•','#fff2a8',34);
    const side=def.doorSide||'south';
    if(side==='north'){door.position.set(0,36,-def.d/2-5);door.rotation.y=Math.PI;doorIcon.position.set(0,82,-def.d/2-9);}
    else if(side==='east'){door.position.set(def.w/2+5,36,0);door.rotation.y=Math.PI/2;doorIcon.position.set(def.w/2+9,82,0);}
    else if(side==='west'){door.position.set(-def.w/2-5,36,0);door.rotation.y=-Math.PI/2;doorIcon.position.set(-def.w/2-9,82,0);}
    else {door.position.set(0,36,def.d/2+5);doorIcon.position.set(0,82,def.d/2+9);}
    const sign=this.makeTextSprite(`${def.icon||'🏠'} ${def.name}`,'#f2d36b',48);sign.position.set(0,def.h+52,0);
    const useSign=this.makeTextSprite(def.use||`Use ${def.station||'building'}`,'#bfe7ff',27);useSign.position.set(0,def.h+18,0);useSign.userData.buildingUse=true;
    group.add(wall,roof,door,sign,useSign,doorIcon);group.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});this.worldRoot.add(group);
    this.obstacles.push({x:def.x,z:def.z,w:def.w,d:def.d});
    const approach=this.getBuildingDoorPosition(def,72);
    this.addInteractive(group,{kind:'building',id:def.id,name:`${def.icon||'🏠'} ${def.name} — ${def.use||'Enter / use'}`,station:def.station,use:def.use,x:approach.x,z:approach.z,buildingX:def.x,buildingZ:def.z,doorSide:side});
  }

  makeTextSprite(text, color='#ffffff', fontSize=42) {
    const canvas=document.createElement('canvas'); const c=canvas.getContext('2d');
    c.font=`bold ${fontSize}px VT323, monospace`; const width=Math.ceil(c.measureText(text).width+24);
    canvas.width=Math.max(128,width); canvas.height=64; c.font=`bold ${fontSize}px VT323, monospace`; c.textAlign='center'; c.textBaseline='middle';
    c.fillStyle='rgba(0,0,0,.58)'; c.fillRect(0,7,canvas.width,50); c.fillStyle=color; c.fillText(text,canvas.width/2,33);
    const texture=new THREE.CanvasTexture(canvas); texture.colorSpace=THREE.SRGBColorSpace;
    const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:texture,transparent:true,depthWrite:false})); sprite.scale.set(canvas.width*.65,42,1); return sprite;
  }

  createNPC(def, index) {
    const data=this.data.npcs[def.npc];if(!data)return;
    const root=new THREE.Group();root.position.set(def.x,this.areaY(def.x,def.z),def.z);
    const body=new THREE.Mesh(new THREE.CylinderGeometry(11,15,35,8),this.makeMaterial(data.color));body.position.y=30;
    const head=new THREE.Mesh(new THREE.SphereGeometry(10,10,8),this.makeMaterial('#c89a72'));head.position.y=56;
    root.add(body,head);root.traverse(o=>{if(o.isMesh)o.castShadow=true;});
    const serviceIcon=data.shop?'🛒 ':data.role==='bank'?'🏦 ':data.role==='craft'?'🛠 ':data.role==='slayer'?'☠️ ':data.role==='prayer'?'🙏 ':'';
    const label=this.makeTextSprite(`${serviceIcon}${data.name}`,'#f0d66f',28);label.position.y=86;root.add(label);
    const questIds=Object.values(this.data.quests).filter(q=>q.giver===def.npc).map(q=>q.id);
    if(questIds.length){const questMark=this.makeTextSprite('!','#ffe34f',50);questMark.position.y=124;questMark.userData.questMarkerList=questIds;root.add(questMark);}
    this.worldRoot.add(root);
    const id=`npc_${def.npc}_${index}`;
    const actor={id,npcId:def.npc,data,mesh:root,home:{x:def.x,z:def.z},target:{x:def.x,z:def.z},area:def.area||'city',scheduleOffset:index*.71,health:40,maxHealth:40,dead:false};
    this.npcActors.set(id,actor);
    this.addInteractive(root,{kind:'npc',id,name:data.name,x:def.x,z:def.z});
  }

  createAnimalGroup(def,index) {
    const template=this.data.animals?.[def.animal];if(!template)return;
    for(let i=0;i<def.count;i++){
      const angle=Math.random()*Math.PI*2,r=Math.sqrt(Math.random())*def.radius;
      this.createAnimal(template,def.x+Math.cos(angle)*r,def.z+Math.sin(angle)*r,`${def.animal}_${index}_${i}`,def.area||this.detectAreaAt(def.x,def.z));
    }
  }

  createAnimal(template,x,z,id,area) {
    const root=new THREE.Group();root.position.set(x,this.areaY(x,z),z);
    const mat=this.makeMaterial(template.color),accent=this.makeMaterial(template.secondaryColor||template.color),dark=this.makeMaterial('#302720');
    if(template.shape==='butterfly'){
      const body=new THREE.Mesh(new THREE.CylinderGeometry(1.3,1.8,12,6),dark);body.rotation.z=Math.PI/2;body.position.y=20;root.add(body);
      const wingGeo=new THREE.SphereGeometry(8,8,5);const left=new THREE.Mesh(wingGeo,mat),right=new THREE.Mesh(wingGeo,accent);left.scale.set(1,.18,1.35);right.scale.copy(left.scale);left.position.set(-5,21,0);right.position.set(5,21,0);left.userData.wingSide=-1;right.userData.wingSide=1;root.add(left,right);
    }else{
      const body=new THREE.Mesh(new THREE.BoxGeometry(template.shape==='dog'?34:30,22,16),mat);body.position.y=22;
      const head=new THREE.Mesh(new THREE.BoxGeometry(17,18,16),accent);head.position.set(20,30,0);
      root.add(body,head);[-11,11].forEach(px=>[-5,5].forEach(pz=>{const leg=new THREE.Mesh(new THREE.BoxGeometry(5,17,5),dark);leg.position.set(px,9,pz);root.add(leg);}));
      const tail=new THREE.Mesh(new THREE.CylinderGeometry(2,3,25,6),mat);tail.position.set(-25,28,0);tail.rotation.z=template.shape==='cat'?-1.05:-.72;root.add(tail);
      if(template.shape==='cat')[-1,1].forEach(side=>{const ear=new THREE.Mesh(new THREE.ConeGeometry(4,9,4),accent);ear.position.set(20,43,side*5);root.add(ear);});
    }
    root.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});
    const adopted=!!this.state.adoptedPets?.[id];
    if(template.adoptable){const label=this.makeTextSprite(`${adopted?'♥ ':''}${template.name}`,adopted?'#ffb5d8':'#d9d1b8',22);label.position.y=58;label.userData.animalLabel=true;root.add(label);}
    this.worldRoot.add(root);
    const actor={id,templateId:template.id,data:template,mesh:root,x,z,home:{x,z},target:{x,z},area,adopted,followUntil:adopted?Infinity:0,wanderCooldown:0,curiosityCooldown:4+Math.random()*8,phase:Math.random()*Math.PI*2};
    this.animalActors.set(id,actor);this.addInteractive(root,{kind:'animal',id,name:template.name,x,z});
  }

  refreshAnimalLabel(actor) {
    const old=actor.mesh.children.find(c=>c.userData.animalLabel);if(old)actor.mesh.remove(old);
    if(!actor.data.adoptable)return;
    const label=this.makeTextSprite(`${actor.adopted?'♥ ':''}${actor.data.name}`,actor.adopted?'#ffb5d8':'#d9d1b8',22);label.position.y=58;label.userData.animalLabel=true;actor.mesh.add(label);
  }

  petAnimal(id) {
    const actor=this.animalActors.get(id);if(!actor)return;
    if(actor.data.shape==='butterfly'){this.addChat('action','The butterfly dances through the air.');return;}
    const [min,max]=actor.data.followSeconds||[10,20];actor.followUntil=performance.now()+randomInt(min,max)*1000;actor.curiosityCooldown=30;
    this.addChat('action',`${actor.data.name} happily follows you for a while.`);
  }

  adoptAnimal(id) {
    const actor=this.animalActors.get(id);if(!actor||!actor.data.adoptable)return;
    actor.adopted=true;actor.followUntil=Infinity;this.state.adoptedPets[id]={id,species:actor.templateId,name:actor.data.name,adoptedAt:new Date().toISOString()};
    this.refreshAnimalLabel(actor);this.recordEvent('pet_adopted',{animalId:id,species:actor.templateId});this.addChat('quest',`You adopt ${actor.data.name}. It will now keep following you.`);this.toast(`${actor.data.name} adopted!`,'rare');this.saveSoon();
  }

  releaseAnimal(id) {
    const actor=this.animalActors.get(id);if(!actor)return;delete this.state.adoptedPets[id];actor.adopted=false;actor.followUntil=0;this.refreshAnimalLabel(actor);this.recordEvent('pet_released',{animalId:id,species:actor.templateId});this.saveSoon();
  }

  updateAnimals(dt) {
    const now=performance.now();
    this.animalActors.forEach(actor=>{
      if(actor.adopted&&actor.area!==this.state.area){actor.area=this.state.area;actor.x=this.state.position.x+randomInt(-45,45);actor.z=this.state.position.z+randomInt(-45,45);actor.mesh.position.set(actor.x,this.areaY(actor.x,actor.z),actor.z);}
      const sameArea=actor.area===this.state.area;actor.mesh.visible=sameArea;if(!sameArea)return;
      actor.phase+=dt*(actor.data.shape==='butterfly'?9:2);
      if(actor.data.shape==='butterfly'){
        actor.mesh.position.y=this.areaY(actor.x,actor.z)+24+Math.sin(actor.phase)*9;
        actor.mesh.children.filter(c=>c.userData.wingSide).forEach(wing=>wing.scale.y=.12+Math.abs(Math.sin(actor.phase))*.42);
      }
      const playerDist=distance2D(actor,this.state.position);
      actor.curiosityCooldown=Math.max(0,actor.curiosityCooldown-dt);
      if(!actor.adopted&&actor.data.temporaryFollow&&playerDist<95&&actor.curiosityCooldown<=0&&Math.random()<dt*.16){const [min,max]=actor.data.followSeconds||[10,20];actor.followUntil=now+randomInt(min,max)*1000;actor.curiosityCooldown=35;}
      const following=actor.adopted||now<actor.followUntil;
      if(following){
        const angle=(Number.parseInt(actor.id.replace(/\D/g,''),10)||1)*1.77;const tx=this.state.position.x+Math.cos(angle)*38,tz=this.state.position.z+Math.sin(angle)*38;
        if(distance2D(actor,{x:tx,z:tz})>18)this.moveActor(actor,tx,tz,actor.data.speed*38*dt);
      }else{
        actor.wanderCooldown-=dt;if(actor.wanderCooldown<=0){actor.target={x:actor.home.x+randomInt(-150,150),z:actor.home.z+randomInt(-150,150)};actor.wanderCooldown=3+Math.random()*6;}
        if(distance2D(actor,actor.target)>7)this.moveActor(actor,actor.target.x,actor.target.z,actor.data.speed*14*dt);
      }
      actor.mesh.position.y=actor.data.shape==='butterfly'?actor.mesh.position.y:this.areaY(actor.x,actor.z);actor.mesh.lookAt((following?this.state.position.x:actor.target.x),actor.mesh.position.y,(following?this.state.position.z:actor.target.z));
      const payload=actor.mesh.userData.interactive;if(payload){payload.x=actor.x;payload.z=actor.z;}
    });
  }

  createResourceGroup(def,index) {
    for(let i=0;i<def.count;i++){
      const angle=Math.random()*Math.PI*2, r=Math.sqrt(Math.random())*def.radius;
      const x=def.x+Math.cos(angle)*r,z=def.z+Math.sin(angle)*r;
      this.createResource({...def,x,z,id:`resource_${index}_${i}`});
    }
  }

  createResource(def) {
    const root=new THREE.Group(); root.position.set(def.x,0,def.z);
    let name='Resource',skill='woodcutting',item='normal_logs',tool='axe',color='#4f8a43',xp=25,shape='tree';
    if(def.kind.startsWith('tree_')){
      const wood=def.kind.replace('tree_',''); name=`${wood[0].toUpperCase()+wood.slice(1)} Tree`; item=`${wood}_logs`; xp={normal:25,oak:40,willow:70,maple:100,yew:175}[wood]||25;
      const trunk=new THREE.Mesh(new THREE.CylinderGeometry(7,9,40,8),this.makeMaterial('#6f4527')); trunk.position.y=20;
      const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(27,1),this.makeMaterial({normal:'#4f8a43',oak:'#397747',willow:'#2f7f58',maple:'#627d3a',yew:'#284b39'}[wood])); crown.position.y=55;
      root.add(trunk,crown);
    } else if(def.kind.startsWith('rock_')){
      const ore=def.kind.replace('rock_',''); name=`${ore[0].toUpperCase()+ore.slice(1)} Ore Rock`; item=`${ore}_ore`; skill='mining'; tool='pickaxe'; shape='rock'; xp={copper:30,tin:30,iron:60,coal:90,silver:110,gold:140}[ore]||30;
      const rock=new THREE.Mesh(new THREE.DodecahedronGeometry(22,0),this.makeMaterial({copper:'#b46a3c',tin:'#aeb7bd',iron:'#756e67',coal:'#313033',silver:'#c9cbd0',gold:'#d3ab37'}[ore])); rock.scale.set(1.25,.85,1); rock.position.y=17; root.add(rock);
    } else if(def.kind.startsWith('fishing_')){
      name=def.kind==='fishing_net'?'Net Fishing Spot':'Rod Fishing Spot'; skill='fishing'; tool=def.kind==='fishing_net'?'net':'rod'; item=def.kind==='fishing_net'?'raw_shrimp':'raw_trout'; xp=def.kind==='fishing_net'?20:50; shape='fish';
      const water=new THREE.Mesh(new THREE.CylinderGeometry(32,32,3,20),this.makeMaterial('#3d8db4',{transparent:true,opacity:.75})); water.position.y=2; root.add(water);
      for(let j=0;j<3;j++){const fish=new THREE.Mesh(new THREE.ConeGeometry(4,12,6),this.makeMaterial('#b8d2dc'));fish.rotation.z=Math.PI/2;fish.position.set((j-1)*12,5,(j%2)*9-4);root.add(fish);}
    } else if(def.kind==='flax'||def.kind==='wheat'){
      name=def.kind==='flax'?'Flax Plant':'Wheat Plant'; skill='farming'; tool=null; item=def.kind; xp=12; shape='plant';
      for(let j=0;j<5;j++){const stalk=new THREE.Mesh(new THREE.CylinderGeometry(1,1,24,5),this.makeMaterial(def.kind==='flax'?'#7d99d6':'#d3ae49'));stalk.position.set((j-2)*4,12,(j%2)*4);root.add(stalk);}
    }
    root.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}}); this.worldRoot.add(root);
    const resource={id:def.id,name,kind:def.kind,mesh:root,x:def.x,z:def.z,skill,item,tool,xp,level:def.level||1,depleted:false,respawnAt:0,shape};
    this.resources.set(def.id,resource); this.addInteractive(root,{kind:'resource',id:def.id,name,x:def.x,z:def.z});
  }

  createHarvestableGroup(def,index) {
    const template=this.data.harvestables?.[def.harvestable];if(!template)return;
    for(let i=0;i<def.count;i++){
      const angle=i/Math.max(1,def.count)*Math.PI*2+(index*.37),r=def.radius*(.35+.65*((i%5)/4));
      this.createHarvestable(template,def.x+Math.cos(angle)*r,def.z+Math.sin(angle)*r,`harvestable_${index}_${i}`,def.area||this.detectAreaAt(def.x,def.z));
    }
  }

  createHarvestable(template,x,z,id,area) {
    const root=new THREE.Group();root.position.set(x,this.areaY(x,z),z);const green=this.makeMaterial(template.color),produce=this.makeMaterial(template.produceColor||'#d95c4f'),soil=this.makeMaterial('#5b3f27');
    if(template.shape==='tree'){
      const trunk=new THREE.Mesh(new THREE.CylinderGeometry(5,7,34,7),this.makeMaterial('#694529'));trunk.position.y=17;const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(22,1),green);crown.position.y=46;root.add(trunk,crown);
      for(let i=0;i<5;i++){const fruit=new THREE.Mesh(new THREE.SphereGeometry(3.5,7,5),produce);fruit.position.set(Math.cos(i*1.7)*14,45+(i%2)*9,Math.sin(i*1.7)*13);root.add(fruit);}
    }else if(template.shape==='bush'){
      const bush=new THREE.Mesh(new THREE.IcosahedronGeometry(16,1),green);bush.position.y=13;root.add(bush);for(let i=0;i<6;i++){const berry=new THREE.Mesh(new THREE.SphereGeometry(2.7,6,4),produce);berry.position.set(Math.cos(i)*12,14+(i%3)*5,Math.sin(i)*11);root.add(berry);}
    }else{
      const bed=new THREE.Mesh(new THREE.BoxGeometry(34,5,28),soil);bed.position.y=2.5;root.add(bed);
      for(let i=0;i<7;i++){const plant=new THREE.Mesh(template.shape==='patch'?new THREE.ConeGeometry(3.5,12,6):new THREE.IcosahedronGeometry(4.5,1),i%2?green:produce);plant.position.set((i%4-1.5)*7,8,Math.floor(i/4)*9-4);root.add(plant);}
    }
    const label=this.makeTextSprite(`${template.icon} ${template.name}`,'#d9f2ae',22);label.position.y=template.shape==='tree'?78:48;root.add(label);root.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});this.worldRoot.add(root);
    const harvestable={id,templateId:template.id,data:template,mesh:root,x,z,area,depleted:false,respawnAt:0};this.harvestables.set(id,harvestable);this.addInteractive(root,{kind:'harvestable',id,name:template.name,x,z});
  }

  createEnemyGroup(def,index) {
    const database=def.boss?this.data.bosses:this.data.enemies; const template=database[def.enemy]; if(!template)return;
    for(let i=0;i<def.count;i++){
      const angle=Math.random()*Math.PI*2,r=Math.sqrt(Math.random())*def.radius;
      this.createEnemy(template,def.x+Math.cos(angle)*r,def.z+Math.sin(angle)*r,`${def.enemy}_${index}_${i}`,def.area||this.detectAreaAt(def.x,def.z));
    }
  }

  createEnemy(template,x,z,id,area=this.detectAreaAt(x,z)) {
    const root=this.makeCreatureMesh(template); root.position.set(x,this.areaY(x,z),z); this.worldRoot.add(root);
    const label=this.makeTextSprite(`${template.name} (Lvl ${template.level})`,template.boss?'#e09aff':'#f1d878',26); label.position.y=template.shape==='dragon'?135:template.shape==='giant'?105:80; root.add(label);
    const bar=this.makeHealthBar(); bar.position.y=label.position.y-23; root.add(bar);
    const enemy={id,templateId:template.id,data:template,mesh:root,x,z,spawn:{x,z},target:{x,z},hp:template.hp,maxHp:template.hp,dead:false,respawnAt:0,attackCooldown:Math.random()*1.5,wanderCooldown:0,healthBar:bar,combatTarget:null,lastAttacker:null,guardAssistCooldown:0,area};
    this.enemies.set(id,enemy); this.addInteractive(root,{kind:'enemy',id,name:template.name,x,z});
  }

  makeCreatureMesh(data) {
    const g=new THREE.Group(), mat=this.makeMaterial(data.color), dark=this.makeMaterial('#2c2723'), bone=this.makeMaterial('#d8d1c0');
    const box=(w,h,d,m=mat,x=0,y=h/2,z=0)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);g.add(o);return o;};
    const sphere=(r,m=mat,x=0,y=r,z=0)=>{const o=new THREE.Mesh(new THREE.SphereGeometry(r,10,8),m);o.position.set(x,y,z);g.add(o);return o;};
    if(['humanoid','wizard','skeleton'].includes(data.shape)){
      const bodyMat=data.shape==='skeleton'?bone:mat; box(data.shape==='giant'?32:22,data.shape==='giant'?58:42,18,bodyMat,0,data.shape==='giant'?40:30,0); sphere(data.shape==='giant'?17:12,data.shape==='skeleton'?bone:this.makeMaterial('#b68c69'),0,data.shape==='giant'?82:59,0);
      box(7,35,7,bodyMat,-13,29,0); box(7,35,7,bodyMat,13,29,0);
      if(data.shape==='wizard'){const hat=new THREE.Mesh(new THREE.ConeGeometry(18,34,8),dark);hat.position.y=88;g.add(hat);}
    } else if(data.shape==='cow'||data.shape==='bear'||data.shape==='wolf'){
      box(data.shape==='bear'?46:42,data.shape==='bear'?30:24,data.shape==='bear'?30:24,mat,0,28,0); sphere(data.shape==='bear'?16:13,mat,22,36,0);
      [-15,15].forEach(px=>[-9,9].forEach(pz=>box(7,24,7,dark,px,12,pz)));
    } else if(data.shape==='chicken'){sphere(12,mat,0,20,0);sphere(7,this.makeMaterial('#e6d9c8'),8,30,0);box(5,8,5,this.makeMaterial('#c3382f'),12,28,0);}
    else if(data.shape==='rat'||data.shape==='king_rat'){
      const scale=data.shape==='king_rat'?2.1:1; sphere(13*scale,mat,0,17*scale,0);sphere(9*scale,mat,16*scale,19*scale,0);
      const tail=new THREE.Mesh(new THREE.CylinderGeometry(1.5*scale,2*scale,34*scale,7),this.makeMaterial('#b88177'));tail.rotation.z=Math.PI/2;tail.position.set(-24*scale,14*scale,0);g.add(tail);
      if(data.shape==='king_rat'){const crown=new THREE.Mesh(new THREE.ConeGeometry(10,18,5),this.makeMaterial('#d3ad35',{metalness:.5}));crown.position.set(15,64,0);g.add(crown);}
    } else if(data.shape==='spider'){sphere(16,mat,0,20,0);for(let i=0;i<8;i++){const leg=new THREE.Mesh(new THREE.CylinderGeometry(2,2,34,6),mat);leg.rotation.z=(i<4?1:-1)*Math.PI/3;leg.rotation.y=(i%4-.5)*.35;leg.position.set(i<4?-15:15,14,(i%4-1.5)*8);g.add(leg);}}
    else if(data.shape==='slime'){const o=new THREE.Mesh(new THREE.SphereGeometry(20,12,8),mat);o.scale.y=.7;o.position.y=15;g.add(o);}
    else if(data.shape==='giant'){box(42,70,32,mat,0,48,0);sphere(20,this.makeMaterial('#8f8f63'),0,94,0);box(12,55,12,mat,-28,53,0);box(12,55,12,mat,28,53,0);}
    else if(data.shape==='golem'){box(45,66,36,mat,0,50,0);sphere(20,mat,0,100,0);box(18,62,18,mat,-34,56,0);box(18,62,18,mat,34,56,0);}
    else if(data.shape==='dragon'){
      box(82,55,45,mat,0,55,0);sphere(23,mat,46,75,0);box(18,50,18,mat,-25,26,-12);box(18,50,18,mat,25,26,12);
      [-1,1].forEach(side=>{const wing=new THREE.Mesh(new THREE.ConeGeometry(55,95,3),this.makeMaterial('#d14a2e'));wing.rotation.z=side*Math.PI/2.8;wing.rotation.y=Math.PI/2;wing.position.set(0,85,side*45);g.add(wing);});
    } else {sphere(18,mat,0,20,0);}
    g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}}); return g;
  }

  makeHealthBar() {
    const group=new THREE.Group();
    const bg=new THREE.Mesh(new THREE.PlaneGeometry(46,6),new THREE.MeshBasicMaterial({color:'#722b2b',side:THREE.DoubleSide,depthTest:false}));
    const fill=new THREE.Mesh(new THREE.PlaneGeometry(44,4),new THREE.MeshBasicMaterial({color:'#42ad55',side:THREE.DoubleSide,depthTest:false})); fill.position.z=.1; fill.userData.isFill=true;
    group.add(bg,fill); group.rotation.x=-Math.PI/6; group.visible=false; return group;
  }

  updateHealthBar(enemy) {
    const fill=enemy.healthBar.children.find(c=>c.userData.isFill); if(!fill)return;
    const ratio=clamp(enemy.hp/enemy.maxHp,0,1); fill.scale.x=ratio; fill.position.x=-22*(1-ratio); enemy.healthBar.visible=ratio<1&&ratio>0;
  }

  createSpecial(def,index) {
    const root=new THREE.Group();const baseY=this.areaY(def.x,def.z);root.position.set(def.x,baseY,def.z);
    const baseMat=this.makeMaterial(def.type==='locked_chest'?'#7a4b27':def.type==='travel'?'#505a52':def.type==='house_unlock'?'#75433e':'#8a6f3e');
    if(def.type==='travel'&&def.visual==='portal'){
      const ring=new THREE.Mesh(new THREE.TorusGeometry(34,7,10,28),this.makeMaterial('#6f78d8',{emissive:'#272b76',emissiveIntensity:1.4}));ring.position.y=42;root.add(ring);
      const core=new THREE.Mesh(new THREE.CircleGeometry(27,28),new THREE.MeshBasicMaterial({color:'#7fd8ff',transparent:true,opacity:.42,side:THREE.DoubleSide,depthWrite:false}));core.position.y=42;root.add(core);
      const label=this.makeTextSprite(def.icon||'🌀','#bfeaff',34);label.position.y=93;root.add(label);
    } else if(def.type==='travel'){
      const rim=new THREE.Mesh(new THREE.TorusGeometry(28,5,8,20),baseMat);rim.rotation.x=Math.PI/2;rim.position.y=3;root.add(rim);
      for(let i=0;i<5;i++){const rung=new THREE.Mesh(new THREE.BoxGeometry(38,3,5),this.makeMaterial('#8b6b45'));rung.position.set(0,i*8+5,0);root.add(rung);}
    } else if(def.type==='door'){
      const width=108,pivot=new THREE.Group();pivot.position.set(-width/2,0,0);
      const panel=new THREE.Mesh(new THREE.BoxGeometry(width,88,12),this.makeMaterial('#563722'));panel.position.set(width/2,44,0);
      const brace=new THREE.Mesh(new THREE.BoxGeometry(width-12,8,15),this.makeMaterial('#88613c'));brace.position.set(width/2,45,0);
      const handle=new THREE.Mesh(new THREE.SphereGeometry(4,8,6),this.makeMaterial('#d4b052',{metalness:.55}));handle.position.set(width-13,46,8);
      pivot.add(panel,brace,handle);root.add(pivot);root.userData.doorPivot=pivot;
      const label=this.makeTextSprite(`🚪 ${def.name}`,'#ffe0a1',27);label.position.y=108;label.userData.houseDoorLabel=true;root.add(label);
      this.obstacles.push({x:def.x,z:def.z,w:112,d:22,flag:def.openFlag});
    } else if(def.type==='healing_fountain'){
      const stone=this.makeMaterial('#a9aaa4'),water=this.makeMaterial('#5bc1dd',{transparent:true,opacity:.78,emissive:'#164e60',emissiveIntensity:.35});
      const basin=new THREE.Mesh(new THREE.CylinderGeometry(58,66,18,20),stone);basin.position.y=9;
      const pool=new THREE.Mesh(new THREE.CylinderGeometry(49,49,5,20),water);pool.position.y=20;
      const column=new THREE.Mesh(new THREE.CylinderGeometry(7,12,58,12),stone);column.position.y=46;
      const spray=new THREE.Mesh(new THREE.SphereGeometry(10,12,8),water);spray.position.y=80;root.add(basin,pool,column,spray);
      const label=this.makeTextSprite('⛲ Drink: full heal + 10 minute regeneration','#b9f5ff',27);label.position.y=116;root.add(label);
    } else if(def.type==='minigame'){
      const table=new THREE.Mesh(new THREE.BoxGeometry(86,12,58),this.makeMaterial('#684a32'));table.position.y=35;root.add(table);
      [-30,30].forEach(px=>[-18,18].forEach(pz=>{const leg=new THREE.Mesh(new THREE.BoxGeometry(7,34,7),this.makeMaterial('#4d3424'));leg.position.set(px,17,pz);root.add(leg);}));
      for(let i=0;i<6;i++){const tile=new THREE.Mesh(new THREE.BoxGeometry(16,4,16),this.makeMaterial(i%2?'#6b78ba':'#73945c',{emissive:i%2?'#1d2550':'#1e4020',emissiveIntensity:.25}));tile.position.set((i%3-1)*22,43,Math.floor(i/3)*22-11);root.add(tile);}
      const label=this.makeTextSprite(`🧩 ${def.name}`,'#d8e6ff',27);label.position.y=92;root.add(label);
    } else if(def.type==='training_dummy'){
      const post=new THREE.Mesh(new THREE.CylinderGeometry(6,8,70,8),this.makeMaterial('#6b482e'));post.position.y=35;
      const body=new THREE.Mesh(new THREE.CylinderGeometry(18,18,42,10),this.makeMaterial('#8c6b45'));body.position.y=63;
      const head=new THREE.Mesh(new THREE.SphereGeometry(13,10,8),this.makeMaterial('#b48a5a'));head.position.y=96;
      const arm=new THREE.Mesh(new THREE.BoxGeometry(72,8,8),this.makeMaterial('#6b482e'));arm.position.y=72;root.add(post,body,head,arm);
      const label=this.makeTextSprite('🎯 Train Attack & Strength','#ffe49c',27);label.position.y=128;root.add(label);
    } else if(def.type==='locked_chest'){
      const box=new THREE.Mesh(new THREE.BoxGeometry(52,30,36),baseMat);box.position.y=15;const lid=new THREE.Mesh(new THREE.BoxGeometry(56,14,40),this.makeMaterial('#9a6533'));lid.position.y=37;root.add(box,lid);
    } else if(def.type==='house_unlock'){
      const door=new THREE.Mesh(new THREE.BoxGeometry(22,85,88),baseMat);door.position.y=42.5;const lock=new THREE.Mesh(new THREE.BoxGeometry(10,16,16),this.makeMaterial('#d1aa3e',{metalness:.5}));lock.position.set(-13,48,0);root.add(door,lock);
      const label=this.makeTextSprite(`🔒 ${def.unlockName||def.name}`,'#ffb6a9',28);label.position.y=108;root.add(label);this.obstacles.push({x:def.x,z:def.z,w:28,d:92,flag:def.flag});
    } else if(def.type==='thieving_stall'){
      const stall=new THREE.Mesh(new THREE.BoxGeometry(70,36,45),this.makeMaterial('#75334b'));stall.position.y=18;const canopy=new THREE.Mesh(new THREE.BoxGeometry(82,10,55),this.makeMaterial('#b45172'));canopy.position.y=58;root.add(stall,canopy);
    } else if(def.type==='station'){
      if(def.station==='furnace'){const f=new THREE.Mesh(new THREE.CylinderGeometry(22,27,48,10),this.makeMaterial('#5f4b45'));f.position.y=24;root.add(f);}
      else if(def.station==='anvil'){const a=new THREE.Mesh(new THREE.BoxGeometry(50,16,24),this.makeMaterial('#444a50',{metalness:.5}));a.position.y=28;const stand=new THREE.Mesh(new THREE.BoxGeometry(18,28,18),this.makeMaterial('#383d42',{metalness:.4}));stand.position.y=14;root.add(a,stand);}
      else if(def.station==='altar'){const a=new THREE.Mesh(new THREE.BoxGeometry(70,35,45),this.makeMaterial('#c7c0a8'));a.position.y=18;root.add(a);}
      else if(def.station==='bank'){const chest=new THREE.Mesh(new THREE.BoxGeometry(62,40,45),this.makeMaterial('#6c482c'));chest.position.y=20;const band=new THREE.Mesh(new THREE.BoxGeometry(66,8,49),this.makeMaterial('#596066',{metalness:.4}));band.position.y=31;root.add(chest,band);}
      else if(def.station==='sawmill'){const table=new THREE.Mesh(new THREE.BoxGeometry(80,18,44),this.makeMaterial('#765338'));table.position.y=30;const saw=new THREE.Mesh(new THREE.CylinderGeometry(18,18,3,18),this.makeMaterial('#879096',{metalness:.55}));saw.rotation.x=Math.PI/2;saw.position.set(0,42,0);root.add(table,saw);}
      else {const table=new THREE.Mesh(new THREE.BoxGeometry(65,13,38),this.makeMaterial('#765338'));table.position.y=32;root.add(table);[-24,24].forEach(x=>[-12,12].forEach(z=>{const leg=new THREE.Mesh(new THREE.BoxGeometry(6,30,6),this.makeMaterial('#5d3d29'));leg.position.set(x,15,z);root.add(leg);}));}
      const marker=this.makeTextSprite(`${def.icon||'🛠'} ${def.name}`,'#c8ecff',24);marker.position.y=78;root.add(marker);
    } else if(def.type==='farm_patch'){
      const soil=new THREE.Mesh(new THREE.BoxGeometry(95,5,75),this.makeMaterial('#5a3e27'));soil.position.y=2.5;root.add(soil);
    } else if(def.type==='rest'){
      const bed=new THREE.Mesh(new THREE.BoxGeometry(90,24,48),this.makeMaterial('#8b6672'));bed.position.y=12;root.add(bed);
    } else if(def.type==='spellbook'){
      const stand=new THREE.Mesh(new THREE.CylinderGeometry(16,22,52,8),this.makeMaterial('#6b4b33'));stand.position.y=26;
      const book=new THREE.Mesh(new THREE.BoxGeometry(38,7,28),this.makeMaterial('#9b3d3d'));book.position.y=56;book.rotation.z=.08;root.add(stand,book);
    } else if(def.type==='pet_manager'){
      const board=new THREE.Mesh(new THREE.BoxGeometry(72,58,8),this.makeMaterial('#73523b'));board.position.y=44;const paw=this.makeTextSprite('🐾','#ffd5e2',36);paw.position.y=46;paw.position.z=6;root.add(board,paw);
    } else {
      const marker=new THREE.Mesh(new THREE.DodecahedronGeometry(18),baseMat);marker.position.y=18;root.add(marker);
    }
    root.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});this.worldRoot.add(root);
    const id=def.id||`special_${index}`;const special={...def,id,mesh:root};this.specials.set(id,special);
    if(def.visibleWhenFlag)root.visible=!!this.state.flags[def.visibleWhenFlag];
    if(def.hiddenWhenFlag||def.type==='house_unlock')root.visible=!this.state.flags[def.hiddenWhenFlag||def.flag];
    this.addInteractive(root,{kind:'special',id,name:def.name,x:def.x,z:def.z});if(def.type==='door')this.applyDoorState(special,false);
  }

  createSewerArchitecture() {
    const baseY=this.data.areas.sewer.baseY||-60,wallMat=this.makeMaterial('#48514c'),waterMat=this.makeMaterial('#2a6c61',{transparent:true,opacity:.72});
    const corridors=[[29400,29400,1050,260],[30000,29850,260,1100],[30000,30600,1250,260],[30750,30600,260,1200],[30900,31200,900,260]];
    corridors.forEach(([x,z,w,d],index)=>{
      const channel=new THREE.Mesh(new THREE.BoxGeometry(w,2.4,d),waterMat);channel.position.set(x,baseY+.7+index*.045,z);this.worldRoot.add(channel);
      [[x-w/2,z,24,d],[x+w/2,z,24,d],[x,z-d/2,w,24],[x,z+d/2,w,24]].forEach(([wx,wz,ww,wd])=>{const wall=new THREE.Mesh(new THREE.BoxGeometry(ww,82,wd),wallMat);wall.position.set(wx,baseY+41,wz);wall.castShadow=true;this.worldRoot.add(wall);});
    });
    for(let i=0;i<26;i++){
      const pipe=new THREE.Mesh(new THREE.CylinderGeometry(7,7,145,8),this.makeMaterial('#5d625f',{metalness:.2}));pipe.rotation.z=Math.PI/2;pipe.position.set(28700+i*95,baseY+72,28750+(i%4)*780);this.worldRoot.add(pipe);
    }
  }

  createDecorationProp(type,x,z,index=0) {
    const y=this.areaY(x,z),wood=this.makeMaterial('#6d4c31'),stone=this.makeMaterial('#77766f'),green=this.makeMaterial('#66864e');let root=new THREE.Group();root.position.set(x,y,z);
    if(type==='lamp'){
      const post=new THREE.Mesh(new THREE.CylinderGeometry(3,4,68,8),this.makeMaterial('#3c3a35'));post.position.y=34;const glow=new THREE.Mesh(new THREE.SphereGeometry(7,8,6),new THREE.MeshBasicMaterial({color:'#ffd67d'}));glow.position.y=72;root.add(post,glow);
    }else if(type==='bench'){
      const seat=new THREE.Mesh(new THREE.BoxGeometry(65,8,22),wood);seat.position.y=24;const back=new THREE.Mesh(new THREE.BoxGeometry(65,30,7),wood);back.position.set(0,40,-9);root.add(seat,back);[-25,25].forEach(px=>{const leg=new THREE.Mesh(new THREE.BoxGeometry(6,24,6),stone);leg.position.set(px,12,0);root.add(leg);});
    }else if(type==='barrel'){
      const barrel=new THREE.Mesh(new THREE.CylinderGeometry(15,17,32,10),wood);barrel.position.y=16;const band1=new THREE.Mesh(new THREE.TorusGeometry(16,2,5,10),stone);band1.rotation.x=Math.PI/2;band1.position.y=8;const band2=band1.clone();band2.position.y=24;root.add(barrel,band1,band2);
    }else if(type==='crate'){
      const crate=new THREE.Mesh(new THREE.BoxGeometry(32,32,32),wood);crate.position.y=16;root.add(crate);
    }else if(type==='cart'){
      const cart=new THREE.Mesh(new THREE.BoxGeometry(70,28,42),wood);cart.position.y=32;root.add(cart);[-28,28].forEach(px=>{const wheel=new THREE.Mesh(new THREE.TorusGeometry(13,3,6,12),stone);wheel.rotation.y=Math.PI/2;wheel.position.set(px,18,23);root.add(wheel);});
    }else if(type==='flower'){
      const stem=new THREE.Mesh(new THREE.CylinderGeometry(1,1,13,5),green);stem.position.y=6.5;const bloom=new THREE.Mesh(new THREE.SphereGeometry(4,6,5),this.makeMaterial(index%3===0?'#d86a8c':index%3===1?'#e0c75b':'#8a7ed9'));bloom.position.y=15;root.add(stem,bloom);
    }else if(type==='boulder'){
      const rock=new THREE.Mesh(new THREE.DodecahedronGeometry(8+index%12,0),stone);rock.position.y=8;root.add(rock);
    }else if(type==='mining_cart'){
      const cart=new THREE.Mesh(new THREE.BoxGeometry(42,24,30),this.makeMaterial('#555a5c',{metalness:.3}));cart.position.y=25;root.add(cart);[-14,14].forEach(px=>{const wheel=new THREE.Mesh(new THREE.CylinderGeometry(7,7,4,10),stone);wheel.rotation.x=Math.PI/2;wheel.position.set(px,10,16);root.add(wheel);});
    }else if(type==='shrub'){
      const shrub=new THREE.Mesh(new THREE.IcosahedronGeometry(10+index%8,1),green);shrub.position.y=10;root.add(shrub);
    }
    root.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});this.worldRoot.add(root);return root;
  }

  createDecorations() {
    for(let v=-1560;v<=1560;v+=260){this.createDecorationProp('lamp',v,-1680);this.createDecorationProp('lamp',v,1680);this.createDecorationProp('lamp',-1680,v);this.createDecorationProp('lamp',1680,v);}
    for(let v=-1450;v<=1450;v+=300){this.createDecorationProp('lamp',v,105);this.createDecorationProp('lamp',105,v);}
    [[-250,320],[250,320],[-250,200],[250,200],[-820,-540],[-650,-540],[700,-500],[900,-500]].forEach(([x,z],i)=>this.createDecorationProp('bench',x,z,i));
    for(let i=0;i<48;i++){const a=i*.71,r=330+(i%7)*58,x=-650+Math.cos(a)*r,z=-540+Math.sin(a)*r;this.createDecorationProp(i%5===0?'cart':i%2?'crate':'barrel',x,z,i);}
    for(let i=0;i<110;i++){const a=i*2.399,r=80+Math.sqrt(i/110)*650,x=-900+Math.cos(a)*r,z=1250+Math.sin(a)*r;this.createDecorationProp(i%5===0?'shrub':'flower',x,z,i);}
    for(let i=0;i<140;i++){const a=i*1.731,r=300+Math.sqrt(i/140)*1900,x=-5200+Math.cos(a)*r,z=Math.sin(a)*r;this.createDecorationProp(i%4===0?'boulder':'shrub',x,z,i);}
    for(let i=0;i<70;i++){const a=i*1.31,r=350+Math.sqrt(i/70)*1650,x=5200+Math.cos(a)*r,z=Math.sin(a)*r;this.createDecorationProp(i%3===0?'mining_cart':'boulder',x,z,i);}
    const homeMat=['#8a6a50','#6e7b83','#7f7254','#765b66'];
    const homes=[[-1450,500],[-1450,1050],[-850,580],[-300,560],[680,520],[1350,520],[1450,1050],[750,1350],[1250,1450]];
    homes.forEach(([x,z],i)=>{const h=new THREE.Group();h.position.set(x,0,z);const body=new THREE.Mesh(new THREE.BoxGeometry(190,105,150),this.makeMaterial(homeMat[i%homeMat.length]));body.position.y=52.5;const roof=new THREE.Mesh(new THREE.ConeGeometry(145,65,4),this.makeMaterial('#4c342a'));roof.rotation.y=Math.PI/4;roof.position.y=135;h.add(body,roof);h.traverse(o=>{if(o.isMesh)o.castShadow=true;});this.worldRoot.add(h);});
    this.createHomeGardenDecorations();
  }

  createHomeGardenDecorations() {
    const wood=this.makeMaterial('#765236'),stone=this.makeMaterial('#9a9488'),soil=this.makeMaterial('#64452d');
    const fence=(x,z,w,d)=>{const rail=new THREE.Mesh(new THREE.BoxGeometry(w,12,d),wood);rail.position.set(x,24,z);rail.castShadow=true;this.worldRoot.add(rail);};
    fence(15520,-910,620,9);fence(15210,-710,9,410);fence(15830,-710,9,410);fence(15355,-510,280,9);fence(15715,-510,230,9);
    for(let x=15210;x<=15830;x+=78){const post=new THREE.Mesh(new THREE.BoxGeometry(10,34,10),wood);post.position.set(x,17,-910);this.worldRoot.add(post);}for(let z=-900;z<=-520;z+=75){[-1,1].forEach(side=>{const post=new THREE.Mesh(new THREE.BoxGeometry(10,34,10),wood);post.position.set(side<0?15210:15830,17,z);this.worldRoot.add(post);});}
    const gardenSoil=new THREE.Mesh(new THREE.BoxGeometry(540,.5,300),soil);gardenSoil.position.set(15520,.28,-710);gardenSoil.receiveShadow=true;this.worldRoot.add(gardenSoil);
    for(let z=-880;z<=-520;z+=70){const step=new THREE.Mesh(new THREE.CylinderGeometry(16,18,3,9),stone);step.position.set(16000,1.5,z);this.worldRoot.add(step);}
    const gardenSign=this.makeTextSprite('🌿 Harvest Garden — apples, sunberries, carrots & herbs','#d9f2ae',26);gardenSign.position.set(15520,72,-905);this.worldRoot.add(gardenSign);
    const gameSign=this.makeTextSprite('🧩 Garden Rune Match','#d5ddff',25);gameSign.position.set(16180,102,760);this.worldRoot.add(gameSign);
  }

  bindUI() {
    $('main-tabs').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>this.switchTab(b.dataset.tab)));
    $('toggle-run').addEventListener('click',()=>{this.state.runEnabled=!this.state.runEnabled;this.updateHUD();});
    $('surface-home').addEventListener('click',()=>this.teleport('city',0,0));
    $('player-home').addEventListener('click',()=>this.teleport('house',16000,160));
    $('camera-mode').addEventListener('click',()=>{this.cameraMode=this.cameraMode==='follow'?'orbit':'follow';this.toast(`Camera: ${this.cameraMode}`);});
    const indoorSpinToggle=$('disable-indoor-camera-spin');indoorSpinToggle.checked=!!this.state.preferences.disableIndoorCameraSpin;indoorSpinToggle.addEventListener('change',()=>{this.state.preferences.disableIndoorCameraSpin=indoorSpinToggle.checked;this.addChat('system',indoorSpinToggle.checked?'Indoor camera auto-spinning is disabled.':'Indoor camera auto-spinning is enabled.');this.saveSoon();});
    $('toggle-audio').addEventListener('click',()=>{this.audioEnabled=!this.audioEnabled;$('toggle-audio').textContent=this.audioEnabled?'🔊':'🔇';});
    $('open-guide').addEventListener('click',()=>this.openGuide());
    $('open-developer').addEventListener('click',()=>this.openDeveloper());
    $('collapse-chat').addEventListener('click',()=>{const log=$('chat-log');log.classList.toggle('hidden');$('chat-panel').style.height=log.classList.contains('hidden')?'62px':'230px';});
    const viewport=$('viewport');
    document.addEventListener('contextmenu',e=>{if(!$('game-root').classList.contains('hidden'))e.preventDefault();},{capture:true});
    viewport.addEventListener('dragover',e=>{if(!this.dragPayload)return;e.preventDefault();this.updatePointerFromClient(e.clientX,e.clientY);const tip=$('drag-tooltip');tip.textContent=this.dragPayload.type==='item'?'Drop item on the world':'Drag the spell onto a hotbar slot';tip.style.left=`${e.clientX+14}px`;tip.style.top=`${e.clientY+14}px`;tip.classList.remove('hidden');});
    viewport.addEventListener('dragleave',()=> $('drag-tooltip').classList.add('hidden'));
    viewport.addEventListener('drop',e=>{e.preventDefault();$('drag-tooltip').classList.add('hidden');if(this.dragPayload?.type==='item'){this.updatePointerFromClient(e.clientX,e.clientY);const ground=this.pickGround();if(this.dragPayload.container==='inventory')this.dropInventoryItem(this.dragPayload.index,this.dragPayload.qty,ground?.point||null);else if(this.dragPayload.container==='equipment')this.dropEquippedItem(this.dragPayload.index,ground?.point||null);}this.clearDragPayload();});
    this.renderHotbar();
  }

  updatePointerFromClient(clientX,clientY) {
    const rect=this.renderer.domElement.getBoundingClientRect();this.pointer.x=((clientX-rect.left)/rect.width)*2-1;this.pointer.y=-((clientY-rect.top)/rect.height)*2+1;
  }

  onPointerMove(e) {
    const rect=this.renderer.domElement.getBoundingClientRect(); this.pointer.x=((e.clientX-rect.left)/rect.width)*2-1;this.pointer.y=-((e.clientY-rect.top)/rect.height)*2+1;
    if(this.draggingCamera){this.cameraYaw-=(e.clientX-this.lastMouse.x)*.006;this.cameraPitch=clamp(this.cameraPitch+(e.clientY-this.lastMouse.y)*.004,.35,1.05);}
    this.lastMouse={x:e.clientX,y:e.clientY};
    const hit=this.pickInteractive(); const label=$('hover-label');
    if(hit){const payload=hit.object.userData.interactiveRoot.userData.interactive;label.textContent=payload.name;label.style.left=`${e.clientX+14}px`;label.style.top=`${e.clientY+14}px`;label.style.display='block';}else label.style.display='none';
  }

  onPointerDown(e) {
    if(this.activeModal)return;
    this.updatePointerFromClient(e.clientX,e.clientY);
    if(e.button===1){this.draggingCamera=true;this.lastMouse={x:e.clientX,y:e.clientY};return;}
    const hit=this.pickInteractive();
    if(e.button===2){this.showWorldContextMenu(e.clientX,e.clientY,hit);return;}
    if(e.button===0){
      this.hideContextMenu();
      if(hit){const payload=hit.object.userData.interactiveRoot.userData.interactive;this.performDefaultInteraction(payload);}
      else {const ground=this.pickGround();if(ground)this.moveTo(ground.point.x,ground.point.z);}
    }
  }

  onKey(e) {
    if(e.key==='Escape'){this.closeModal();this.hideContextMenu();this.cancelAction();this.state.combatTarget=null;}
    if(e.key.toLowerCase()==='r'){this.state.runEnabled=!this.state.runEnabled;this.updateHUD();}
    if(e.key.toLowerCase()==='i')this.switchTab('inventory');
    if(e.key.toLowerCase()==='d'&&e.ctrlKey){e.preventDefault();this.openDeveloper();}
    if(!e.ctrlKey&&!e.altKey&&!e.metaKey&&/^[0-9]$/.test(e.key)&&!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)){const slot=e.key==='0'?9:Number(e.key)-1;this.useHotbarSlot(slot);}
  }

  pickInteractive() {
    this.raycaster.setFromCamera(this.pointer,this.camera); const hits=this.raycaster.intersectObjects(this.interactives,true);
    return hits.find(h=>h.object.userData.interactiveRoot&&h.object.userData.interactiveRoot.visible);
  }
  pickGround() { this.raycaster.setFromCamera(this.pointer,this.camera); return this.raycaster.intersectObjects(this.terrainMeshes,false)[0]||null; }

  performDefaultInteraction(payload) {
    if(payload.kind==='enemy')this.startCombat(payload.id);
    else if(payload.kind==='resource')this.queueInteraction(payload,()=>this.gatherResource(payload.id),65);
    else if(payload.kind==='harvestable')this.queueInteraction(payload,()=>this.harvestGardenObject(payload.id),60);
    else if(payload.kind==='npc')this.queueInteraction(payload,()=>this.talkToNPC(payload.id),65);
    else if(payload.kind==='special')this.queueInteraction(payload,()=>this.useSpecial(payload.id),70);
    else if(payload.kind==='building')this.queueInteraction(payload,()=>this.useBuilding(payload),90);
    else if(payload.kind==='groundItem')this.queueInteraction(payload,()=>this.pickupGroundItem(payload.id),55);
    else if(payload.kind==='animal')this.queueInteraction(payload,()=>this.petAnimal(payload.id),55);
  }

  showWorldContextMenu(x,y,hit) {
    const actions=[];
    if(hit){
      const p=hit.object.userData.interactiveRoot.userData.interactive;
      if(p.kind==='enemy'){
        actions.push(['Attack',()=>this.startCombat(p.id)]);
        const e=this.enemies.get(p.id); if(e?.data.id==='cow')actions.push(['Milk',()=>this.queueInteraction(p,()=>this.milkCow(e),60)]);
        actions.push(['Examine',()=>this.examineEnemy(p.id)]);
      } else if(p.kind==='resource'){
        const r=this.resources.get(p.id); actions.push([this.resourceVerb(r),()=>this.queueInteraction(p,()=>this.gatherResource(p.id),65)],['Examine',()=>this.addChat('system',`${r.name}. Requires level ${r.level} ${this.data.skills[r.skill].name}.`)]);
      } else if(p.kind==='harvestable'){
        const h=this.harvestables.get(p.id);actions.push(['Harvest',()=>this.queueInteraction(p,()=>this.harvestGardenObject(p.id),60)],['Examine',()=>this.addChat('system',`${h.data.name}. Produces ${this.data.items[h.data.item]?.name||h.data.item}; Farming level ${h.data.level}.`)]);
      } else if(p.kind==='npc'){
        const n=this.npcActors.get(p.id);actions.push([`Talk-to ${n.data.name}`,()=>this.queueInteraction(p,()=>this.talkToNPC(p.id),65)]);
        if(n.data.shop||n.data.role==='shop')actions.push(['Trade',()=>this.queueInteraction(p,()=>this.openShop(n.data.shop||'general_store'),65)]);
        if(n.data.role==='bank')actions.push(['Bank',()=>this.queueInteraction(p,()=>this.openBank(),65)]);
        if(n.data.role==='slayer')actions.push(['Get Slayer task',()=>this.queueInteraction(p,()=>this.assignSlayerTask(),65)]);
        actions.push([`Pickpocket ${n.data.name}`,()=>this.queueInteraction(p,()=>this.pickpocketNPC(n),55)]);
        actions.push([`Attack ${n.data.name}`,()=>this.attackNPC(n)]);
        actions.push(['Examine',()=>this.addChat('system',`${n.data.name}, ${n.data.building}.`)]);
      } else if(p.kind==='animal'){
        const animal=this.animalActors.get(p.id);if(animal){
          actions.push([animal.data.shape==='butterfly'?'Watch':'Pet',()=>this.queueInteraction(p,()=>this.petAnimal(p.id),55)]);
          if(animal.data.adoptable&&!animal.adopted)actions.push(['Adopt',()=>this.queueInteraction(p,()=>this.adoptAnimal(p.id),55)]);
          if(animal.adopted)actions.push(['Release',()=>this.releaseAnimal(p.id)]);
          actions.push(['Examine',()=>this.addChat('system',`${animal.data.name}. ${animal.adopted?'This animal belongs to you.':'It may follow friendly adventurers for a while.'}`)]);
        }
      } else if(p.kind==='special'){const s=this.specials.get(p.id);const verb=s?.type==='door'?(this.state.flags[s.openFlag]?'Close':'Open'):s?.type==='healing_fountain'?'Drink':s?.type==='training_dummy'?'Train':s?.type==='minigame'?'Play':'Use';const action=s?.type==='door'?()=>this.interactWithDoor(s):()=>this.queueInteraction(p,()=>this.useSpecial(p.id),70);actions.push([verb,action],['Examine',()=>this.addChat('system',s?.name||p.name)]);}
      else if(p.kind==='building'){actions.push(['Enter / use',()=>this.queueInteraction(p,()=>this.useBuilding(p),90)],['Examine',()=>this.addChat('system',p.name)]);}
      else if(p.kind==='groundItem'){const gi=this.groundItems.get(p.id);actions.push([`Take ${this.data.items[gi.itemId].name}`,()=>this.queueInteraction(p,()=>this.pickupGroundItem(p.id),55)],['Examine',()=>this.addChat('system',`${gi.qty} × ${this.data.items[gi.itemId].name}`)]);}
    }
    const ground=this.pickGround(); if(ground)actions.push(['Walk here',()=>this.moveTo(ground.point.x,ground.point.z)]);
    this.showContextMenu(x,y,hit?hit.object.userData.interactiveRoot.userData.interactive.name:'Choose option',actions);
  }

  showContextMenu(x,y,title,actions) {
    const menu=$('context-menu');menu.innerHTML=`<div class="menu-title">${esc(title)}</div>`;
    actions.forEach(([label,fn])=>{const b=document.createElement('button');b.textContent=label;b.addEventListener('click',()=>{this.hideContextMenu();fn();});menu.appendChild(b);});
    menu.style.left=`${Math.min(x,innerWidth-230)}px`;menu.style.top=`${Math.min(y,innerHeight-actions.length*36-50)}px`;menu.classList.remove('hidden');
  }
  hideContextMenu(){ $('context-menu').classList.add('hidden'); }

  moveTo(x,z) { this.pendingAction=null;this.state.combatTarget=null;this.state.target={x,z};this.spawnClickMarker(x,z); }
  queueInteraction(payload,callback,range) { this.pendingAction={payload,callback,range};this.state.target={x:payload.x,z:payload.z}; }
  cancelAction(){this.pendingAction=null;this.actionToken++;$('action-progress').classList.add('hidden');}

  useBuilding(payload) {
    if(payload.station==='bank')this.openBank();
    else if(payload.station==='shop')this.openShop('general_store');
    else if(['anvil','furnace','range','tannery','spinning_wheel','fletching_bench','crafting_table','sawmill'].includes(payload.station))this.openCrafting(payload.station);
    else if(payload.station==='altar')this.restorePrayer();
    else this.addChat('system',`You enter ${payload.name}.`);
  }

  useSpecial(id) {
    const s=this.specials.get(id);if(!s)return;
    if(s.type==='travel')this.teleport(s.targetArea,s.target[0],s.target[1]);
    else if(s.type==='pickup'){
      if(this.state.flags[s.onceFlag]){this.addChat('system','The cache is empty.');return;}
      if(this.addItem(s.item,1)){this.state.flags[s.onceFlag]=true;this.addChat('loot',`You find ${this.data.items[s.item].name}.`);this.recordCollection(s.item);s.mesh.visible=false;}
    } else if(s.type==='locked_chest')this.openLockedChest(s);
    else if(s.type==='thieving_stall')this.thieveStall(s);
    else if(s.type==='house_unlock')this.unlockHouseRoom(s);
    else if(s.type==='door')this.interactWithDoor(s);
    else if(s.type==='minigame')this.openGardenMinigame(s.game);
    else if(s.type==='healing_fountain')this.drinkHealingFountain(s);
    else if(s.type==='training_dummy')this.trainAtHouseDummy(s);
    else if(s.type==='rest'){this.state.hp=this.state.maxHp;this.state.prayer=this.state.maxPrayer;this.state.runEnergy=100;this.addChat('action','You rest in your own bed and recover completely.');this.updateHUD();}
    else if(s.type==='spellbook')this.openSpellbook();
    else if(s.type==='pet_manager')this.openPetManager();
    else if(s.type==='station'){
      if(s.station==='bank')this.openBank();else if(s.station==='shop')this.openShop(s.shop||'general_store');
      else if(s.station==='altar')this.restorePrayer();else this.openCrafting(s.station);
    } else if(s.type==='farm_patch')this.handleFarmPatch(s);
  }

  interactWithDoor(door) {
    if(!door)return;
    if(distance2D(this.state.position,door)<=145){this.toggleHouseDoor(door);return;}
    const side=this.state.position.z<door.z?-1:1,approach={kind:'special',id:door.id,name:door.name,x:door.x,z:door.z+side*92};
    this.queueInteraction(approach,()=>this.toggleHouseDoor(door),38);
    this.addChat('system',`You walk to the reachable side of ${door.name}.`);
  }

  toggleHouseDoor(door) {
    const open=!this.state.flags[door.openFlag];this.state.flags[door.openFlag]=open;this.applyDoorState(door,true);this.recordEvent('house_door_toggled',{doorId:door.id,open});this.saveSoon();
  }

  applyDoorState(door,announce=false) {
    const open=!!this.state.flags[door.openFlag],pivot=door.mesh?.userData?.doorPivot,target=open?(door.openAngle||-Math.PI/2):0;
    door.targetAngle=target;
    if(pivot&&!announce)pivot.rotation.y=target;
    const payload=door.mesh?.userData?.interactive;if(payload)payload.name=`${open?'Open':'Closed'} ${door.name}`;
    if(announce){this.addChat('action',`You ${open?'open':'close'} ${door.name}.`);this.playSfx('coin');}
  }

  updateDoors(dt) {
    this.specials.forEach(door=>{if(door.type!=='door')return;const pivot=door.mesh?.userData?.doorPivot;if(!pivot)return;const target=Number.isFinite(door.targetAngle)?door.targetAngle:(this.state.flags[door.openFlag]?(door.openAngle||-Math.PI/2):0);const delta=target-pivot.rotation.y;pivot.rotation.y+=delta*Math.min(1,dt*10);if(Math.abs(delta)<.004)pivot.rotation.y=target;});
  }

  drinkHealingFountain() {
    const seconds=Number(this.data.settings.fountainRegenSeconds||600);this.state.hp=this.state.maxHp;this.state.buffs.homeFountainRegenUntil=Date.now()+seconds*1000;this.regenAccumulator=0;
    this.addChat('action',`You drink from the restorative fountain. Your health is fully restored and you will recover ${this.data.settings.fountainRegenPerSecond||1} hitpoint per second for ${Math.round(seconds/60)} minutes.`);
    this.toast('Restorative fountain regeneration active','level');this.recordEvent('healing_fountain_used',{durationSeconds:seconds,healPerSecond:this.data.settings.fountainRegenPerSecond||1});this.updateHUD();this.saveSoon();
  }

  trainAtHouseDummy() {
    const now=Date.now();if(now<Number(this.state.buffs.houseTrainingCooldownUntil||0)){this.addChat('system',`The training dummy needs ${Math.ceil((this.state.buffs.houseTrainingCooldownUntil-now)/1000)} seconds before another focused drill.`);return;}
    this.state.buffs.houseTrainingCooldownUntil=now+8000;this.playToolAnimation('sword');this.addXp('attack',8);this.addXp('strength',8);this.addChat('action','You complete a focused drill on the home training dummy.');this.recordEvent('house_training_drill',{attackXp:8,strengthXp:8});this.saveSoon();
  }

  isInsidePlayerHouse() {
    if(this.state.area!=='house')return false;const house=this.data.world.playerHouse;if(!house)return false;const [cx,cz]=house.center||[16000,0];
    if(Math.abs(this.state.position.x-cx)<=house.w/2-12&&Math.abs(this.state.position.z-cz)<=house.d/2-12)return true;
    return (house.rooms||[]).some(room=>(!room.flag||this.state.flags[room.flag])&&Math.abs(this.state.position.x-room.x)<=room.w/2&&Math.abs(this.state.position.z-room.z)<=room.d/2);
  }

  updateHouseInteriorState(force=false) {
    const inside=this.isInsidePlayerHouse();if(!force&&inside===this.houseInteriorActive){this.updateHouseStatusText();return;}
    this.houseInteriorActive=inside;const opacity=inside?Number(this.data.settings.houseRoofIndoorOpacity||.14):1;
    this.houseRoofMeshes.forEach(roof=>{roof.material.transparent=inside;roof.material.opacity=opacity;roof.material.depthWrite=!inside;roof.material.needsUpdate=true;});
    const control=$('indoor-camera-control');if(control)control.classList.toggle('hidden',!inside);this.updateHouseStatusText();
  }

  updateHouseStatusText() {
    const toggle=$('disable-indoor-camera-spin');if(toggle&&toggle.checked!==!!this.state.preferences.disableIndoorCameraSpin)toggle.checked=!!this.state.preferences.disableIndoorCameraSpin;
  }

  updateBuffs(dt) {
    const remaining=Math.max(0,Number(this.state.buffs.homeFountainRegenUntil||0)-Date.now());
    if(remaining>0){this.regenAccumulator+=dt;const ticks=Math.floor(this.regenAccumulator);if(ticks>0){this.regenAccumulator-=ticks;const amount=ticks*Number(this.data.settings.fountainRegenPerSecond||1);this.state.hp=Math.min(this.state.maxHp,this.state.hp+amount);}}
    else {this.regenAccumulator=0;if(this.state.buffs.homeFountainRegenUntil)this.state.buffs.homeFountainRegenUntil=0;}
  }

  unlockHouseRoom(door) {
    if(this.state.flags[door.flag]){this.addChat('system',`${door.unlockName} is already unlocked.`);return;}
    const missing=Object.entries(door.requirements||{}).filter(([id,qty])=>this.itemCount(id)<qty);
    if(missing.length){this.addChat('system',`To unlock ${door.unlockName}, you still need ${missing.map(([id,qty])=>`${qty-this.itemCount(id)} ${this.data.items[id]?.name||id}`).join(', ')}.`);return;}
    Object.entries(door.requirements||{}).forEach(([id,qty])=>this.removeItem(id,qty));
    this.state.flags[door.flag]=true;this.recordEvent('house_room_unlocked',{room:door.unlockName,flag:door.flag,requirements:door.requirements});this.addChat('quest',`${door.unlockName} is now part of your player-owned house.`);this.toast(`${door.unlockName} unlocked!`,'rare');this.refreshHouseObjects();this.saveSoon();
  }

  refreshHouseObjects() {
    this.specials.forEach(s=>{
      if(s.visibleWhenFlag)s.mesh.visible=!!this.state.flags[s.visibleWhenFlag];
      if(s.hiddenWhenFlag||s.type==='house_unlock')s.mesh.visible=!this.state.flags[s.hiddenWhenFlag||s.flag];
      if(s.type==='door')this.applyDoorState(s,false);
    });
  }

  openPetManager() {
    const pets=Object.values(this.state.adoptedPets||{}),body=document.createElement('div');
    body.innerHTML=`<p>Your adopted dogs and cats follow permanently and travel between regions with you.</p><div class="collection-list">${pets.length?pets.map(p=>`<div class="collection-card"><b>🐾 ${esc(p.name)}</b><small>${esc(p.species)} — adopted ${esc(p.adoptedAt||'')}</small></div>`).join(''):'<p>You have not adopted a dog or cat yet. Right-click one in the city and choose Adopt.</p>'}</div>`;
    this.openModal('Player House Pet Room',body);
  }

  openLockedChest(chest) {
    if(this.state.flags[chest.flag]){this.addChat('system','The treasure chest is already empty.');return;}
    if(!this.hasItem(chest.key,1)){this.addChat('system',`The chest is locked. You need ${this.data.items[chest.key].name}.`);return;}
    this.removeItem(chest.key,1);
    Object.entries(chest.rewards).forEach(([id,qty])=>{this.addItem(id,qty);this.recordCollection(id);});
    this.state.flags[chest.flag]=true;this.recordEvent('chest_opened',{chestId:chest.id,rewards:chest.rewards});this.addChat('quest','The sewer key turns. Inside are a powerful blade and chestpiece.');this.toast('Sewer treasure unlocked!','rare');
    this.updateQuestProgress();this.checkAchievements();this.renderCurrentTab();this.saveSoon();
  }

  teleport(area,x,z) {
    this.cancelAction();this.state.area=area;this.state.position={x,z};this.state.target={x,z};this.playerMesh.position.set(x,this.data.areas[area]?.baseY||0,z);
    this.animalActors.forEach(actor=>{if(actor.adopted){actor.area=area;actor.x=x+randomInt(-45,45);actor.z=z+randomInt(-45,45);actor.mesh.position.set(actor.x,this.areaY(actor.x,actor.z),actor.z);}});
    this.addChat('system',`You enter ${this.data.areas[area].name}.`);this.updateHouseInteriorState(true);this.updateHUD();this.drawMinimap();
  }

  resourceVerb(r){return r.skill==='woodcutting'?'Chop':r.skill==='mining'?'Mine':r.skill==='fishing'?'Fish':'Gather';}
  toolForResource(r){if(r.tool==='axe')return this.findTool('axe');if(r.tool==='pickaxe')return this.findTool('pickaxe');if(r.tool==='net')return this.hasItem('small_fishing_net')?'small_fishing_net':null;if(r.tool==='rod')return this.hasItem('fishing_rod')?'fishing_rod':null;return true;}
  findTool(type){const equipped=this.state.equipment.weapon;if(equipped&&this.data.items[equipped]?.toolType===type)return equipped;return this.state.inventory.find(s=>s&&this.data.items[s.id]?.toolType===type)?.id||null;}

  gatherResource(id) {
    const r=this.resources.get(id);if(!r||r.depleted)return;
    if(this.state.skills[r.skill].level<r.level){this.addChat('system',`You need level ${r.level} ${this.data.skills[r.skill].name}.`);return;}
    if(r.tool&&!this.toolForResource(r)){this.addChat('system',`You need the correct ${r.tool}.`);return;}
    if(!this.hasInventorySpace(r.item)){this.addChat('system','Your inventory is full.');return;}
    this.performTimedAction(`${this.resourceVerb(r)} ${r.name}...`,1.15+Math.random()*.85,()=>{
      if(this.addItem(r.item,1)){this.addXp(r.skill,r.xp);this.playSfx(r.skill==='woodcutting'?'chop':r.skill==='mining'?'mine':r.skill==='fishing'?'fish':'gather');this.recordEvent('resource_gathered',{resource:r.kind,item:r.item,skill:r.skill,xp:r.xp});this.playToolAnimation(r.tool||'gather');this.addChat('action',`You obtain ${this.data.items[r.item].name}.`);}
      if(Math.random()<.58){r.depleted=true;r.respawnAt=performance.now()+this.data.settings.resourceRespawnSeconds*1000;r.mesh.visible=false;}
    });
  }

  harvestGardenObject(id) {
    const h=this.harvestables.get(id);if(!h||h.depleted)return;
    const d=h.data;if(this.state.skills[d.skill].level<d.level){this.addChat('system',`You need level ${d.level} ${this.data.skills[d.skill].name}.`);return;}
    if(!this.hasInventorySpace(d.item)){this.addChat('system','Your inventory is full.');return;}
    this.performTimedAction(`Harvesting ${d.name}...`,.75+Math.random()*.45,()=>{
      const qty=randomInt(d.qty?.[0]||1,d.qty?.[1]||1);if(this.addItem(d.item,qty)){this.addXp(d.skill,d.xp);this.recordCollection(d.item);this.recordEvent('garden_harvested',{harvestableId:d.id,item:d.item,qty,xp:d.xp});this.addChat('loot',`You harvest ${qty} ${this.data.items[d.item].name}.`);}
      h.depleted=true;h.respawnAt=performance.now()+(d.respawnSeconds||35)*1000;h.mesh.visible=false;
    });
  }

  openGardenMinigame(gameId='garden_rune_match') {
    const game=this.data.minigames?.[gameId];if(!game)return;
    const stats=this.state.minigames[gameId]||{plays:0,wins:0,bestSeconds:null};this.state.minigames[gameId]=stats;stats.plays++;
    const symbols=[...game.symbols].slice(0,game.pairCount),cards=[...symbols,...symbols].sort(()=>Math.random()-.5);let first=null,lock=false,matched=0,finished=false;const started=performance.now();
    const body=document.createElement('div');body.className='minigame-panel';body.innerHTML=`<p>${esc(game.description)}</p><div class="minigame-status" id="minigame-status">Match all ${game.pairCount} pairs.</div><div class="memory-grid" id="memory-grid"></div>`;
    const modal=this.openModal(game.name,body);const grid=body.querySelector('#memory-grid'),status=body.querySelector('#minigame-status');
    cards.forEach((symbol,index)=>{const card=document.createElement('button');card.className='memory-card';card.dataset.symbol=symbol;card.dataset.index=index;card.textContent='?';card.onclick=()=>{
      if(lock||finished||card.classList.contains('matched')||card===first)return;card.textContent=symbol;card.classList.add('revealed');
      if(!first){first=card;return;}lock=true;
      if(first.dataset.symbol===card.dataset.symbol){first.classList.add('matched');card.classList.add('matched');first=null;lock=false;matched+=2;status.textContent=`${matched/2} / ${game.pairCount} pairs matched.`;
        if(matched===cards.length){finished=true;const seconds=Math.round((performance.now()-started)/100)/10;stats.wins++;stats.bestSeconds=stats.bestSeconds===null?seconds:Math.min(stats.bestSeconds,seconds);this.addItem('coins',game.rewards.coins||0);Object.entries(game.rewards.items||{}).forEach(([item,qty])=>this.addItem(item,qty));Object.entries(game.rewards.xp||{}).forEach(([skill,xp])=>this.addXp(skill,xp));this.recordEvent('minigame_completed',{gameId,seconds,rewards:game.rewards});status.innerHTML=`Completed in <b>${seconds.toFixed(1)} seconds</b>. Best: <b>${stats.bestSeconds.toFixed(1)} seconds</b>. Rewards delivered.`;this.addChat('quest',`You complete ${game.name} in ${seconds.toFixed(1)} seconds.`);this.saveSoon();}
      }else{const previous=first;setTimeout(()=>{previous.textContent='?';card.textContent='?';previous.classList.remove('revealed');card.classList.remove('revealed');first=null;lock=false;},650);}
    };grid.appendChild(card);});
    const timeout=setTimeout(()=>{if(finished||!modal.isConnected)return;finished=true;status.textContent='Time expired. Close the table and try again.';grid.querySelectorAll('button').forEach(b=>b.disabled=true);},(game.timeLimitSeconds||60)*1000);
    modal.querySelector('.modal-close').addEventListener('click',()=>clearTimeout(timeout),{once:true});
  }

  performTimedAction(label,seconds,callback) {
    this.cancelAction();const token=++this.actionToken,panel=$('action-progress'),fill=$('action-progress-fill');panel.classList.remove('hidden');$('action-progress-label').textContent=label;fill.style.width='0%';
    const start=performance.now();const tick=()=>{if(token!==this.actionToken)return;const p=clamp((performance.now()-start)/(seconds*1000),0,1);fill.style.width=`${p*100}%`;if(p<1)requestAnimationFrame(tick);else{panel.classList.add('hidden');callback();this.renderCurrentTab();this.updateHUD();this.saveSoon();}};requestAnimationFrame(tick);
  }

  milkCow(enemy) {
    if(!this.hasItem('bucket',1)){this.addChat('system','You need an empty bucket.');return;}
    this.performTimedAction('Milking cow...',1.4,()=>{this.removeItem('bucket',1);this.addItem('milk',1);this.addXp('farming',15);this.addChat('action','You fill the bucket with milk.');});
  }

  thieveStall(stall) {
    if(this.state.skills.thieving.level<(stall.level||1)){this.addChat('system',`You need level ${stall.level} Thieving.`);return;}
    this.performTimedAction(`Stealing from ${stall.name}...`,1.2,()=>{
      if(Math.random()<.2){this.damagePlayer(2,'a city guard');this.state.wanted=Math.max(this.state.wanted,20);this.addChat('combat','You are caught stealing.');}
      else if(this.addItem(stall.item,1)){this.addXp('thieving',stall.xp||40);this.addChat('loot',`You steal ${this.data.items[stall.item].name}.`);this.recordCollection(stall.item);}
    });
  }

  handleFarmPatch() {
    const farm=this.state.farm;
    if(farm.stage===0){
      const seeds=['barley_seed','cabbage_seed'].filter(id=>this.hasItem(id));
      if(!seeds.length){this.addChat('system','You need seeds to plant this allotment.');return;}
      this.openChoice('Plant Seed',seeds.map(id=>({label:`${this.data.items[id].icon} ${this.data.items[id].name}`,action:()=>{this.removeItem(id,1);farm.seed=id;farm.stage=1;farm.plantedAt=Date.now();this.addXp('farming',18);this.addChat('action',`You plant ${this.data.items[id].name}.`);this.closeModal();}})));
    } else {
      const elapsed=(Date.now()-farm.plantedAt)/1000;const needed=farm.seed==='cabbage_seed'?90:65;
      if(elapsed<needed){this.addChat('system',`The crop is growing. ${Math.ceil(needed-elapsed)} seconds remain.`);}
      else {const crop=farm.seed==='cabbage_seed'?'cabbage':'barley';const qty=randomInt(3,7);if(this.addItem(crop,qty)){this.addXp('farming',qty*22);this.addChat('loot',`You harvest ${qty} ${this.data.items[crop].name}.`);farm.stage=0;farm.seed=null;farm.plantedAt=0;}}
    }
  }

  talkToNPC(id) {
    const actor=this.npcActors.get(id);if(!actor)return;const npc=actor.data;
    this.addChat('quest',`${npc.name}: “${npc.dialogue[0]}”`);
    if(npc.quest)this.handleQuestNPC(npc.quest);
    else if(npc.role==='bank')this.openBank();
    else if(npc.role==='shop')this.openShop(npc.shop||'general_store');
    else if(npc.role==='craft')this.openCrafting(npc.station);
    else if(npc.role==='slayer')this.assignSlayerTask();
    else if(npc.role==='prayer')this.restorePrayer();
  }

  handleQuestNPC(questId) {
    const q=this.data.quests[questId],state=this.state.quests[questId];if(!q||!state)return;
    if(state.state===0){state.state=1;this.addChat('quest',`Quest started: ${q.name}. ${q.summary}`);this.toast(`Quest started: ${q.name}`);}
    else if(state.state===1&&this.questComplete(q,state)){this.completeQuest(q,state);}
    else if(state.state===1)this.addChat('quest',`${q.name}: ${this.questProgressText(q,state)}`);
    else this.addChat('quest',`${q.name} is complete.`);
    this.refreshQuestMarkers();this.renderCurrentTab();
  }

  refreshQuestMarkers(){this.npcActors.forEach(actor=>actor.mesh.children.forEach(child=>{if(child.userData.questMarkerList)child.visible=child.userData.questMarkerList.some(id=>this.state.quests[id]?.state===0);}));}

  questComplete(q,state) {
    return q.objectives.every(obj=>{
      if(obj.type==='item')return this.itemCount(obj.item)>=obj.qty;
      if(obj.type==='kill')return (state.progress[obj.enemy]||0)>=obj.qty;
      if(obj.type==='flag')return !!this.state.flags[obj.flag];
      return false;
    });
  }

  questProgressText(q,state) {
    return q.objectives.map(obj=>obj.type==='item'?`${this.itemCount(obj.item)}/${obj.qty} ${this.data.items[obj.item].name}`:obj.type==='kill'?`${state.progress[obj.enemy]||0}/${obj.qty} ${obj.enemy.replaceAll('_',' ')}`:`${this.state.flags[obj.flag]?'Done':'Not done'} ${obj.flag.replaceAll('_',' ')}`).join(', ');
  }

  completeQuest(q,state) {
    q.objectives.filter(o=>o.type==='item').forEach(o=>this.removeItem(o.item,o.qty));
    Object.entries(q.rewards.xp||{}).forEach(([skill,xp])=>this.addXp(skill,xp));
    Object.entries(q.rewards.items||{}).forEach(([id,qty])=>this.addItem(id,qty));
    if(q.rewards.coins)this.addItem('coins',q.rewards.coins);
    state.state=2;this.refreshQuestMarkers();this.recordEvent('quest_completed',{questId:q.id,rewards:q.rewards});this.addChat('quest',`Quest complete: ${q.name}!`);this.toast(`Quest complete: ${q.name}`,'rare');this.checkAchievements();this.saveSoon();
  }

  updateQuestProgress(enemyId=null) {
    Object.entries(this.data.quests).forEach(([qid,q])=>{
      const state=this.state.quests[qid];if(state.state!==1)return;
      if(enemyId)q.objectives.filter(o=>o.type==='kill'&&o.enemy===enemyId).forEach(o=>state.progress[enemyId]=(state.progress[enemyId]||0)+1);
    });
  }

  assignSlayerTask() {
    if(this.state.slayerTask&&this.state.slayerTask.remaining>0){this.addChat('quest',`Current task: ${this.state.slayerTask.remaining} ${this.state.slayerTask.name}.`);return;}
    const level=this.state.skills.slayer.level;const options=this.data.slayerTasks.filter(t=>t.minLevel<=level);const def=options[randomInt(0,options.length-1)];const target=def.enemyPool[randomInt(0,def.enemyPool.length-1)];const amount=randomInt(def.min,def.max);
    this.state.slayerTask={taskId:def.id,enemy:target,name:this.enemyTemplate(target)?.name||target,remaining:amount,total:amount,rewardXp:def.rewardXp};
    this.addChat('quest',`New Slayer task: defeat ${amount} ${this.state.slayerTask.name}.`);this.toast('New Slayer task');this.updateHUD();
  }

  pickpocketNPC(actor) {
    if(actor.data.role==='guard'){this.state.wanted=Math.max(this.state.wanted,25);this.damagePlayer(3,'an angry guard');this.addChat('combat','The guard catches your hand.');return;}
    this.performTimedAction(`Pickpocketing ${actor.data.name}...`,.9,()=>{
      const chance=.45+this.state.skills.thieving.level*.01;
      if(Math.random()<chance){const coins=randomInt(3,25);this.addItem('coins',coins);this.addXp('thieving',22);this.addChat('loot',`You steal ${coins} coins.`);}
      else{this.state.wanted=Math.max(this.state.wanted,18);this.damagePlayer(randomInt(1,3),actor.data.name);this.addChat('combat','You are caught pickpocketing.');}
    });
  }

  attackNPC(actor) {
    this.state.wanted=Math.max(this.state.wanted,45);this.addChat('combat',`You attack ${actor.data.name}. The city guard is alerted.`);this.damageNPC(actor,randomInt(1,this.playerMaxHit()));
  }
  damageNPC(actor,amount){actor.health=Math.max(0,actor.health-amount);this.playToolAnimation('sword');if(actor.health<=0){actor.dead=true;actor.mesh.visible=false;setTimeout(()=>{actor.health=actor.maxHealth;actor.dead=false;actor.mesh.visible=true;actor.mesh.position.set(actor.home.x,0,actor.home.z);},25000);}}

  startCombat(id) {
    const enemy=this.enemies.get(id);if(!enemy||enemy.dead)return;this.cancelAction();this.state.combatTarget=id;enemy.combatTarget='player';enemy.lastAttacker='player';this.addChat('combat',`You engage ${enemy.data.name}.`);
  }

  playerMaxHit() {
    const weapon=this.state.equipment.weapon?this.data.items[this.state.equipment.weapon]:null;
    const style=weapon?.combatStyle||'melee';
    if(style==='ranged'){const ammo=this.state.equipment.ammo?this.data.items[this.state.equipment.ammo]:null;return Math.max(1,Math.floor(this.state.skills.ranged.level/5+((weapon.stats?.rangedStrength||0)+(ammo?.stats?.rangedStrength||0))/4));}
    if(style==='magic'&&this.selectedSpell)return this.data.spells[this.selectedSpell].maxHit;
    return Math.max(1,Math.floor(this.state.skills.strength.level/5+(weapon?.stats?.strength||0)/4)+1);
  }

  updateCombat(dt) {
    if(this.state.attackCooldown>0)this.state.attackCooldown-=dt;
    const id=this.state.combatTarget;if(!id)return;const enemy=this.enemies.get(id);if(!enemy||enemy.dead){this.state.combatTarget=null;return;}
    const dist=distance2D(this.state.position,enemy);
    const weapon=this.state.equipment.weapon?this.data.items[this.state.equipment.weapon]:null;
    const style=weapon?.combatStyle||'melee';const range=style==='melee'?62:style==='ranged'?320:280;
    if(dist>range){this.state.target={x:enemy.x,z:enemy.z};return;}
    this.state.target={...this.state.position};
    if(this.state.attackCooldown<=0){
      if(style==='magic'&&this.selectedSpell){if(!this.castSelectedSpell(enemy))return;}
      else {
        if(style==='ranged'){if(!this.state.equipment.ammo||this.state.ammoQty<=0){this.addChat('system','You need equipped ammunition to use this bow.');this.state.combatTarget=null;return;}this.state.ammoQty--;if(this.state.ammoQty<=0){this.state.equipment.ammo=null;this.addChat('system','You have used your last arrow.');}}
        const accuracy=this.playerAccuracy(style,enemy);const hit=Math.random()<accuracy?randomInt(0,this.playerMaxHit()):0;
        this.damageEnemy(enemy,hit,style);this.playToolAnimation(style==='ranged'?'bow':'sword');if(style==='ranged')this.spawnProjectile(this.playerMesh.position,enemy.mesh.position,'#d2b27c',.65);
        const xp=Math.max(1,hit*4);if(style==='ranged')this.addXp('ranged',xp);else{const skill=this.state.combatStyle==='aggressive'?'strength':this.state.combatStyle==='defensive'?'defence':'attack';this.addXp(skill,xp);}
        this.addXp('hitpoints',Math.max(1,hit*1.33));
      }
      this.state.attackCooldown=weapon?.toolType==='battleaxe'?2.6:style==='ranged'?2.2:2.0;
    }
  }

  playerAccuracy(style,enemy) {
    const weapon=this.state.equipment.weapon?this.data.items[this.state.equipment.weapon]:null;
    const level=style==='ranged'?this.state.skills.ranged.level:style==='magic'?this.state.skills.magic.level:this.state.skills.attack.level;
    const bonus=style==='ranged'?(weapon?.stats?.ranged||0):style==='magic'?(weapon?.stats?.magic||0):(weapon?.stats?.attack||0);
    return clamp(.55+(level+bonus-enemy.data.level)*.012,.18,.94);
  }

  castSelectedSpell(enemy) {
    const spell=this.data.spells[this.selectedSpell];if(!spell)return false;
    if(this.state.skills.magic.level<spell.level){this.addChat('system',`You need level ${spell.level} Magic.`);this.state.combatTarget=null;return false;}
    for(const [rune,qty] of Object.entries(spell.runes||{}))if(this.itemCount(rune)<qty){this.addChat('system',`You do not have enough ${this.data.items[rune].name}.`);this.state.combatTarget=null;return false;}
    Object.entries(spell.runes||{}).forEach(([id,qty])=>this.removeItem(id,qty));const hit=randomInt(0,spell.maxHit);this.playSfx('cast');this.damageEnemy(enemy,hit,'magic');this.addXp('magic',spell.xp+hit*2);this.addXp('hitpoints',Math.max(1,hit));this.spawnProjectile(this.playerMesh.position,enemy.mesh.position,spell.icon==='🔥'?'#ff673d':'#76cbe8',.45);this.playToolAnimation('staff');return true;
  }

  damageEnemy(enemy,amount,style='melee') {
    enemy.hp=Math.max(0,enemy.hp-amount);enemy.combatTarget='player';enemy.lastAttacker='player';this.updateHealthBar(enemy);this.floatText(amount?`-${amount}`:'0',enemy.mesh.position,amount?'#ff5a52':'#a9b0b5');
    this.playSfx(amount?'hit':'miss');this.addChat('combat',amount?`You hit ${enemy.data.name} for ${amount}.`:`You miss ${enemy.data.name}.`);
    if(enemy.hp<=0)this.killEnemy(enemy,style);
  }

  killEnemy(enemy) {
    enemy.dead=true;enemy.mesh.visible=false;enemy.respawnAt=performance.now()+this.data.settings.enemyRespawnSeconds*1000;this.state.combatTarget=null;
    const id=enemy.data.id;this.state.kills[id]=(this.state.kills[id]||0)+1;this.recordEvent('enemy_killed',{enemy:id,boss:!!enemy.data.boss,drops:enemy.data.drops});this.updateQuestProgress(id);this.updateSlayer(id);this.rollDrops(enemy);this.checkAchievements();this.addChat('combat',`${enemy.data.name} is defeated.`);this.saveSoon();
  }

  updateSlayer(enemyId) {
    const task=this.state.slayerTask;if(!task||task.enemy!==enemyId||task.remaining<=0)return;task.remaining--;this.addXp('slayer',task.rewardXp);
    if(task.remaining<=0){const reward=task.total*8;this.addItem('coins',reward);this.addXp('slayer',task.total*12);this.addChat('quest',`Slayer task complete. You receive ${reward} coins.`);this.toast('Slayer task complete!','rare');}
    this.updateHUD();
  }

  rollDrops(enemy) {
    enemy.data.drops.forEach(drop=>{
      const uniqueOwned=drop.unique&&this.state.collection[drop.item];if(uniqueOwned&&drop.item==='sewer_key')return;
      if(Math.random()<=drop.chance){const qty=randomInt(drop.min||1,drop.max||1);this.spawnGroundItem(drop.item,qty,enemy.x+randomInt(-22,22),enemy.z+randomInt(-22,22),enemy.data.boss?600:300);}
    });
  }

  spawnGroundItem(itemId,qty,x,z,lifetime=300) {
    const item=this.data.items[itemId];if(!item)return;const id=uid('ground');const root=new THREE.Group();root.position.set(x,this.areaY(x,z)+2,z);
    const box=new THREE.Mesh(new THREE.BoxGeometry(16,8,16),this.makeMaterial(item.rare?'#9d5fce':'#b58a39',{emissive:item.rare?'#391452':'#201500'}));box.position.y=6;root.add(box);const label=this.makeTextSprite(`${item.icon} ${item.name}${qty>1?` ×${qty}`:''}`,item.rare?'#e6b2ff':'#f4dc80',24);label.position.y=35;root.add(label);this.worldRoot.add(root);
    const gi={id,itemId,qty,x,z,mesh:root,expiresAt:Date.now()+lifetime*1000};this.groundItems.set(id,gi);this.addInteractive(root,{kind:'groundItem',id,name:item.name,x,z});
  }

  pickupGroundItem(id) {
    const gi=this.groundItems.get(id);if(!gi)return;if(this.addItem(gi.itemId,gi.qty)){this.recordCollection(gi.itemId);this.worldRoot.remove(gi.mesh);this.groundItems.delete(id);this.addChat('loot',`You pick up ${gi.qty} × ${this.data.items[gi.itemId].name}.`);this.renderCurrentTab();this.saveSoon();}
  }

  updateEnemies(dt) {
    const now=performance.now();
    this.enemies.forEach(enemy=>{
      if(enemy.dead){if(now>=enemy.respawnAt){enemy.dead=false;enemy.hp=enemy.maxHp;enemy.x=enemy.spawn.x;enemy.z=enemy.spawn.z;enemy.mesh.position.set(enemy.x,this.areaY(enemy.x,enemy.z),enemy.z);enemy.mesh.visible=true;enemy.combatTarget=null;this.updateHealthBar(enemy);}return;}
      enemy.attackCooldown-=dt;const playerDist=distance2D(enemy,this.state.position);const sameArea=enemy.area===this.state.area;
      if(!sameArea)return;
      if(!enemy.combatTarget&&enemy.data.aggro&&!this.data.areas[this.state.area].safe&&playerDist<Math.min(220,80+enemy.data.level*4))enemy.combatTarget='player';
      enemy.guardAssistCooldown=Math.max(0,enemy.guardAssistCooldown-dt);
      if(enemy.combatTarget==='player'&&this.state.area==='city'&&Math.hypot(enemy.x,enemy.z)<1800&&enemy.guardAssistCooldown<=0){const guard=[...this.npcActors.values()].find(n=>n.data.role==='guard'&&distance2D({x:n.mesh.position.x,z:n.mesh.position.z},enemy)<360);if(guard){this.damageEnemy(enemy,randomInt(3,8),'guard');enemy.guardAssistCooldown=2.2;this.addChat('combat',`${guard.data.name} helps you fight ${enemy.data.name}.`);}}
      if(enemy.combatTarget==='player'){
        if(playerDist>this.data.settings.aggroLeash&&distance2D(enemy,enemy.spawn)>this.data.settings.aggroLeash){enemy.combatTarget=null;enemy.target={...enemy.spawn};}
        else if(playerDist>48){const speed=enemy.data.speed*32;this.moveActor(enemy,this.state.position.x,this.state.position.z,speed*dt);}
        else if(enemy.attackCooldown<=0){const raw=randomInt(0,enemy.data.maxHit);const dmg=this.reduceDamage(raw,enemy.data.combatStyle||'melee');this.damagePlayer(dmg,enemy.data.name);enemy.attackCooldown=enemy.data.attackSpeed;this.floatText(dmg?`-${dmg}`:'0',this.playerMesh.position,dmg?'#ff5c55':'#aab0b4');}
      } else {
        enemy.wanderCooldown-=dt;if(enemy.wanderCooldown<=0){enemy.target={x:enemy.spawn.x+randomInt(-150,150),z:enemy.spawn.z+randomInt(-150,150)};enemy.wanderCooldown=3+Math.random()*5;}
        if(distance2D(enemy,enemy.target)>8)this.moveActor(enemy,enemy.target.x,enemy.target.z,enemy.data.speed*12*dt);
      }
      enemy.mesh.lookAt(enemy.target.x,enemy.mesh.position.y,enemy.target.z);
    });
  }

  moveActor(actor,x,z,amount) {
    const dx=x-actor.x,dz=z-actor.z,d=Math.hypot(dx,dz)||1;actor.x+=dx/d*amount;actor.z+=dz/d*amount;actor.mesh.position.x=actor.x;actor.mesh.position.z=actor.z;actor.mesh.position.y=this.areaY(actor.x,actor.z);
  }

  equipmentStats() {
    const total={attack:0,strength:0,defence:0,ranged:0,rangedStrength:0,magic:0,poisonResist:0};
    Object.values(this.state.equipment).filter(Boolean).forEach(id=>{const s=this.data.items[id]?.stats||{};Object.keys(total).forEach(k=>total[k]+=s[k]||0);});return total;
  }
  reduceDamage(raw,style) {
    const stats=this.equipmentStats(),defLevel=this.state.skills.defence.level;let reduction=clamp((stats.defence+defLevel)*.006,0,.62);
    if(style==='melee'&&this.selectedPrayer.has('protect_melee'))reduction+=this.data.prayers.protect_melee.bonuses.protectMelee;
    return Math.max(0,Math.floor(raw*(1-clamp(reduction,0,.85))));
  }

  damagePlayer(amount,source='an enemy') {
    this.state.hp=Math.max(0,this.state.hp-amount);this.animation.hurt=.3;this.addChat('combat',`${source} hits you for ${amount}.`);this.updateHUD();if(this.state.hp<=0)this.playerDeath();
  }

  playerDeath() {
    this.addChat('combat','You have died. Your inventory falls where you stood.');
    const x=this.state.position.x,z=this.state.position.z;
    this.state.inventory.filter(Boolean).forEach((stack,i)=>{if(!this.data.items[stack.id]?.bound)this.spawnGroundItem(stack.id,stack.qty,x+(i%7-3)*24,z+(Math.floor(i/7)-1)*24,600);});
    Object.entries(this.state.equipment).filter(([,id])=>Boolean(id)).forEach(([slot,id],i)=>this.spawnGroundItem(id,slot==='ammo'?Math.max(1,this.state.ammoQty):1,x+(i%5-2)*28,z+65+Math.floor(i/5)*28,600));
    this.state.inventory=Array(this.data.settings.inventorySlots).fill(null);this.state.inventory[0]={id:'spellbook',qty:1};Object.keys(this.state.equipment).forEach(k=>this.state.equipment[k]=null);this.state.ammoQty=0;
    ['bronze_hatchet','bronze_pickaxe','tinderbox','small_fishing_net','knife'].forEach(id=>this.addItem(id,1));
    this.state.hp=this.state.maxHp;this.state.prayer=this.state.maxPrayer;this.state.combatTarget=null;this.updateHeldItem();this.teleport('house',16000,160);this.renderCurrentTab();this.saveSoon();
  }

  updatePlayer(dt) {
    const pos=this.state.position,target=this.state.target;const d=Math.hypot(target.x-pos.x,target.z-pos.z);
    if(d>3){const running=this.state.runEnabled&&this.state.runEnergy>1;const speed=(running?this.data.settings.runSpeed:this.data.settings.walkSpeed)*dt;const nx=pos.x+(target.x-pos.x)/d*Math.min(speed,d),nz=pos.z+(target.z-pos.z)/d*Math.min(speed,d);
      if(!this.collides(nx,nz)){pos.x=nx;pos.z=nz;this.playerMesh.position.x=nx;this.playerMesh.position.z=nz;this.playerMesh.lookAt(target.x,this.playerMesh.position.y,target.z);}else{this.state.target={...pos};this.pendingAction=null;}
      if(running)this.state.runEnergy=Math.max(0,this.state.runEnergy-dt*2.1);
    } else {this.state.runEnergy=Math.min(100,this.state.runEnergy+dt*.75);if(this.pendingAction){const p=this.pendingAction;if(distance2D(pos,p.payload)<=p.range){this.pendingAction=null;p.callback();}}}
    this.playerMesh.position.y=this.areaY(pos.x,pos.z);
    const detected=this.detectAreaAt(pos.x,pos.z);if(detected!==this.state.area){this.state.area=detected;this.updateHUD();}
    this.state.playSeconds+=dt;
  }
  collides(x,z){return this.obstacles.some(o=>(!o.flag||!this.state.flags[o.flag])&&Math.abs(x-o.x)<o.w/2+13&&Math.abs(z-o.z)<o.d/2+13);}

  updateNPCs(dt) {
    this.npcActors.forEach(n=>{
      if(n.dead)return;let tx=n.home.x,tz=n.home.z;
      if(n.data.role==='guard'){const angle=(this.worldTime*.17+n.scheduleOffset)%(Math.PI*2),radius=1450+(n.scheduleOffset%3)*90;tx=Math.cos(angle)*radius;tz=Math.sin(angle)*radius;}
      else {tx=n.home.x+Math.sin(this.worldTime*.35+n.scheduleOffset)*22;tz=n.home.z+Math.cos(this.worldTime*.27+n.scheduleOffset)*18;}
      if(distance2D({x:n.mesh.position.x,z:n.mesh.position.z},{x:tx,z:tz})>10){const dx=tx-n.mesh.position.x,dz=tz-n.mesh.position.z,d=Math.hypot(dx,dz)||1;n.mesh.position.x+=dx/d*18*dt;n.mesh.position.z+=dz/d*18*dt;n.mesh.position.y=this.areaY(n.mesh.position.x,n.mesh.position.z);n.mesh.lookAt(tx,n.mesh.position.y,tz);const payload=n.mesh.userData.interactive;if(payload){payload.x=n.mesh.position.x;payload.z=n.mesh.position.z;}}
    });
    if(this.state.wanted>0&&this.state.area==='city'){this.state.wanted=Math.max(0,this.state.wanted-dt);const guard=[...this.npcActors.values()].find(n=>n.data.role==='guard'&&distance2D({x:n.mesh.position.x,z:n.mesh.position.z},this.state.position)<150);if(guard&&Math.random()<dt*.8)this.damagePlayer(randomInt(1,4),'a Crownstone guard');}
  }

  updateResources(){const now=performance.now();this.resources.forEach(r=>{if(r.depleted&&now>=r.respawnAt){r.depleted=false;r.mesh.visible=true;}});}
  updateHarvestables(){const now=performance.now();this.harvestables.forEach(h=>{if(h.depleted&&now>=h.respawnAt){h.depleted=false;h.mesh.visible=true;}});}
  updateGroundItems(){const now=Date.now();this.groundItems.forEach((g,id)=>{if(now>=g.expiresAt){this.worldRoot.remove(g.mesh);this.groundItems.delete(id);}});}

  updatePrayers(dt) {
    if(!this.selectedPrayer.size)return;let drain=0;this.selectedPrayer.forEach(id=>drain+=this.data.prayers[id]?.drain||0);this.state.prayer=Math.max(0,this.state.prayer-drain*dt);
    if(this.state.prayer<=0){this.selectedPrayer.clear();this.addChat('system','You have run out of prayer points.');this.renderCurrentTab();}
  }

  updateRandomEvents(dt) {
    this.randomEventAccumulator+=dt;if(this.randomEventAccumulator<60)return;this.randomEventAccumulator=0;
    Object.values(this.data.randomEvents).forEach(event=>{if(Math.random()<event.chancePerMinute){this.addChat('quest',`World event: ${event.name}!`);this.toast(`World event: ${event.name}`,'rare');if(event.spawnEnemy){for(let i=0;i<event.count;i++){const t=this.data.enemies[event.spawnEnemy];this.createEnemy(t,randomInt(-500,500),randomInt(2500,3400),uid(event.spawnEnemy),'southlands');}}if(event.id==='falling_star')this.spawnGroundItem('gold_ore',randomInt(2,5),5200+randomInt(-450,450),randomInt(-450,450),event.duration);}});
  }

  updateDayNight(dt) {
    this.worldTime=(this.worldTime+dt*(24/(this.data.settings.dayLengthMinutes*60)))%24;const daylight=clamp(Math.sin((this.worldTime-6)/24*Math.PI*2)*.5+.55,.12,1);this.sun.intensity=.7+daylight*2.6;this.scene.background.set(daylight<.35?'#27364d':'#8ab0c9');this.scene.fog.color.copy(this.scene.background);
  }

  updateCamera() {
    const p=this.playerMesh.position,allowFollowRotation=this.cameraMode==='follow'&&!(this.houseInteriorActive&&this.state.preferences.disableIndoorCameraSpin);if(allowFollowRotation){const targetYaw=this.playerMesh.rotation.y+Math.PI;this.cameraYaw+=(targetYaw-this.cameraYaw)*.015;}
    const horizontal=Math.cos(this.cameraPitch)*this.cameraDistance;const offset=new THREE.Vector3(Math.sin(this.cameraYaw)*horizontal,Math.sin(this.cameraPitch)*this.cameraDistance,Math.cos(this.cameraYaw)*horizontal);
    this.camera.position.lerp(p.clone().add(offset),.12);this.camera.lookAt(p.x,p.y+35,p.z);
  }

  playToolAnimation(type){this.animation.toolSwing=1;this.updateHeldItem(type);}
  updateAnimations(dt) {
    if(this.animation.toolSwing>0){this.animation.toolSwing=Math.max(0,this.animation.toolSwing-dt*2.7);const p=1-this.animation.toolSwing;this.playerArmPivot.rotation.x=-1.2+Math.sin(p*Math.PI)*2.15;this.playerArmPivot.rotation.z=-.3;}else{this.playerArmPivot.rotation.x=0;this.playerArmPivot.rotation.z=0;}
    if(this.animation.hurt>0){this.animation.hurt-=dt;this.playerMesh.rotation.z=Math.sin(this.animation.hurt*40)*.08;}else this.playerMesh.rotation.z=0;
    this.projectiles=this.projectiles.filter(p=>{p.t+=dt*p.speed;p.mesh.position.lerpVectors(p.from,p.to,clamp(p.t,0,1));if(p.t>=1){this.fxRoot.remove(p.mesh);return false;}return true;});
  }

  updateHeldItem(forceType=null) {
    while(this.playerToolRoot.children.length)this.playerToolRoot.remove(this.playerToolRoot.children[0]);
    const id=this.state.equipment.weapon||this.state.inventory.find(s=>s&&this.data.items[s.id]?.toolType)?.id;const item=this.data.items[id];const type=forceType||item?.toolType||'none';if(type==='none')return;
    const metal=this.makeMaterial(item?.color||'#8d9298',{metalness:.35}),wood=this.makeMaterial('#6f472b');
    if(type==='axe'||type==='pickaxe'){
      const handle=new THREE.Mesh(new THREE.CylinderGeometry(2.4,2.8,42,7),wood);handle.position.y=-17;
      let head;if(type==='pickaxe'){head=new THREE.Mesh(new THREE.ConeGeometry(5,34,5),metal);head.rotation.z=Math.PI/2;head.position.set(0,-38,0);}else{head=new THREE.Mesh(new THREE.BoxGeometry(22,13,5),metal);head.position.set(7,-38,0);}this.playerToolRoot.add(handle,head);
    } else if(type==='bow'){
      const bow=new THREE.Mesh(new THREE.TorusGeometry(18,2,6,18,Math.PI),wood);bow.rotation.y=Math.PI/2;bow.rotation.z=Math.PI/2;bow.position.y=-20;this.playerToolRoot.add(bow);
    } else if(type==='staff'){
      const staff=new THREE.Mesh(new THREE.CylinderGeometry(2.5,3,55,7),wood);staff.position.y=-24;const gem=new THREE.Mesh(new THREE.OctahedronGeometry(7),this.makeMaterial('#61bde0',{emissive:'#17435a'}));gem.position.y=-54;this.playerToolRoot.add(staff,gem);
    } else {
      const blade=new THREE.Mesh(new THREE.BoxGeometry(6,42,3),metal);blade.position.y=-26;const guard=new THREE.Mesh(new THREE.BoxGeometry(18,4,5),this.makeMaterial('#bd9040',{metalness:.4}));guard.position.y=-5;this.playerToolRoot.add(blade,guard);
    }
  }

  spawnProjectile(fromObj,toObj,color,speed) {
    const mesh=new THREE.Mesh(new THREE.SphereGeometry(4,8,6),new THREE.MeshBasicMaterial({color}));this.fxRoot.add(mesh);this.projectiles.push({mesh,from:fromObj.clone().add(new THREE.Vector3(0,45,0)),to:toObj.clone().add(new THREE.Vector3(0,35,0)),t:0,speed});
  }

  floatText(text,worldPos,color) {
    const p=worldPos.clone().project(this.camera);const el=document.createElement('div');el.className='xp-drop';el.textContent=text;el.style.color=color;el.style.left=`${(p.x*.5+.5)*innerWidth}px`;el.style.top=`${(-p.y*.5+.5)*innerHeight}px`;$('game-root').appendChild(el);setTimeout(()=>el.remove(),1250);
  }


  playSfx(type) {
    if(!this.audioEnabled)return;
    try{
      this.audioContext=this.audioContext||new (window.AudioContext||window.webkitAudioContext)();
      const ctx=this.audioContext,osc=ctx.createOscillator(),gain=ctx.createGain(),now=ctx.currentTime;osc.connect(gain);gain.connect(ctx.destination);gain.gain.setValueAtTime(.12,now);
      const config={hit:[150,55,.14,'sawtooth'],miss:[300,120,.09,'sine'],chop:[220,130,.08,'square'],mine:[175,85,.09,'square'],fish:[420,510,.12,'sine'],gather:[330,390,.1,'triangle'],coin:[980,1320,.18,'sine'],level:[260,525,.55,'triangle'],cast:[390,840,.25,'sine']}[type]||[260,220,.08,'sine'];
      osc.type=config[3];osc.frequency.setValueAtTime(config[0],now);osc.frequency.exponentialRampToValueAtTime(Math.max(30,config[1]),now+config[2]);gain.gain.exponentialRampToValueAtTime(.001,now+config[2]);osc.start(now);osc.stop(now+config[2]);
    }catch(e){}
  }

  spawnClickMarker(x,z) {
    const ring=new THREE.Mesh(new THREE.RingGeometry(10,15,18),new THREE.MeshBasicMaterial({color:'#f5df78',side:THREE.DoubleSide,transparent:true,opacity:.9}));ring.rotation.x=-Math.PI/2;ring.position.set(x,this.areaY(x,z)+1,z);this.fxRoot.add(ring);let life=1;const tick=()=>{life-=.06;ring.material.opacity=Math.max(0,life);ring.scale.setScalar(1+(1-life)*.8);if(life>0)requestAnimationFrame(tick);else this.fxRoot.remove(ring);};tick();
  }

  createFire(x,z) {
    const group=new THREE.Group();group.position.set(x,this.areaY(x,z)+2,z);const logs=new THREE.Mesh(new THREE.BoxGeometry(34,7,8),this.makeMaterial('#5f3d26'));logs.rotation.y=Math.PI/4;const logs2=logs.clone();logs2.rotation.y=-Math.PI/4;const flame=new THREE.Mesh(new THREE.ConeGeometry(13,35,8),this.makeMaterial('#ff8a2f',{emissive:'#8b2600'}));flame.position.y=20;group.add(logs,logs2,flame);this.worldRoot.add(group);setTimeout(()=>this.worldRoot.remove(group),60000);
  }

  addXp(skillId,amount) {
    const skill=this.state.skills[skillId];if(!skill)return;skill.xp+=amount;let required=this.xpForLevel(skill.level+1);let leveled=false;
    while(skill.xp>=required&&skill.level<99){skill.level++;leveled=true;required=this.xpForLevel(skill.level+1);this.state.recentLevels.unshift(`${this.data.skills[skillId].name} ${skill.level}`);this.state.recentLevels=this.state.recentLevels.slice(0,5);this.toast(`${this.data.skills[skillId].name} level ${skill.level}!`,'level');this.addChat('system',`Congratulations, your ${this.data.skills[skillId].name} is now level ${skill.level}.`);}
    if(skillId==='hitpoints')this.state.maxHp=10+Math.floor((skill.level-10)*1.5);if(skillId==='prayer'){this.state.maxPrayer=skill.level;}
    if(amount>0)this.floatXp(skillId,amount);if(leveled){this.playSfx('level');this.updateHUD();}
  }
  xpForLevel(level){let points=0;for(let i=1;i<level;i++)points+=Math.floor(i+300*Math.pow(2,i/7));return Math.floor(points/4);}
  floatXp(skillId,amount){const el=document.createElement('div');el.className='xp-drop';el.textContent=`${this.data.skills[skillId].icon} +${Math.floor(amount)} XP`;el.style.left=`${innerWidth-410}px`;el.style.top='80px';$('game-root').appendChild(el);setTimeout(()=>el.remove(),1250);}
  totalLevel(){return Object.values(this.state.skills).reduce((a,s)=>a+s.level,0);}
  combatLevel(){const s=this.state.skills;return Math.floor((s.defence.level+s.hitpoints.level+Math.floor(s.prayer.level/2))*.25+Math.max((s.attack.level+s.strength.level)*.325,s.ranged.level*.4875,s.magic.level*.4875));}

  hasInventorySpace(itemId){const item=this.data.items[itemId];return !!(item?.stackable&&this.state.inventory.some(s=>s?.id===itemId)||this.state.inventory.some(s=>!s));}
  itemCount(itemId,source='inventory'){const arr=source==='bank'?this.state.bank:this.state.inventory;return arr.filter(Boolean).filter(s=>s.id===itemId).reduce((a,s)=>a+s.qty,0)+(source==='inventory'?Object.values(this.state.equipment).filter(id=>id===itemId).length:0);}
  hasItem(itemId,qty=1){return this.itemCount(itemId)>=qty;}
  addItem(itemId,qty=1,target='inventory') {
    const item=this.data.items[itemId];if(!item||qty<=0)return false;const arr=target==='bank'?this.state.bank:this.state.inventory;
    if(item.stackable){const stack=arr.find(s=>s?.id===itemId);if(stack){stack.qty+=qty;return true;}}
    if(target==='bank'){
      if(arr.filter(Boolean).length+qty>this.data.settings.maxBankSlots)return false;
      for(let i=0;i<qty;i++)arr.push({id:itemId,qty:1});return true;
    }
    const empty=[];for(let i=0;i<this.data.settings.inventorySlots;i++)if(!arr[i])empty.push(i);
    if(empty.length<qty)return false;for(let i=0;i<qty;i++)arr[empty[i]]={id:itemId,qty:1};return true;
  }
  removeItem(itemId,qty=1,source='inventory') {
    const arr=source==='bank'?this.state.bank:this.state.inventory;let remaining=qty;
    for(let i=arr.length-1;i>=0&&remaining>0;i--){const stack=arr[i];if(!stack||stack.id!==itemId)continue;const take=Math.min(stack.qty,remaining);stack.qty-=take;remaining-=take;if(stack.qty<=0){if(source==='bank')arr.splice(i,1);else arr[i]=null;}}
    return remaining===0;
  }

  recordCollection(itemId){if(!this.state.collection[itemId]){this.state.collection[itemId]={firstAt:new Date().toISOString(),count:0};this.toast(`Collection log: ${this.data.items[itemId].name}`,this.data.items[itemId].rare?'rare':'');}this.state.collection[itemId].count++;}

  checkAchievements() {
    Object.values(this.data.achievements).forEach(a=>{if(this.state.achievements[a.id])return;let ok=false,c=a.condition;
      if(c.type==='kills')ok=Object.values(this.state.kills).reduce((x,y)=>x+y,0)>=c.count;
      else if(c.type==='enemyKills')ok=c.enemies.reduce((sum,id)=>sum+(this.state.kills[id]||0),0)>=c.count;
      else if(c.type==='flag')ok=!!this.state.flags[c.flag];
      else if(c.type==='totalLevel')ok=this.totalLevel()>=c.count;
      else if(c.type==='craftedSkills')ok=c.skills.every(s=>this.state.crafted[s]);
      if(ok){this.state.achievements[a.id]={at:new Date().toISOString()};if(a.reward.coins)this.addItem('coins',a.reward.coins);Object.entries(a.reward.items||{}).forEach(([id,q])=>this.addItem(id,q));this.addChat('quest',`Achievement unlocked: ${a.name}`);this.toast(`Achievement: ${a.name}`,'rare');}
    });
  }

  switchTab(tab){this.activeTab=tab;$('main-tabs').querySelectorAll('button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));this.renderCurrentTab();}
  renderCurrentTab(){const root=$('tab-content');if(!root)return;if(this.activeTab==='inventory')this.renderInventory(root);else if(this.activeTab==='equipment')this.renderEquipment(root);else if(this.activeTab==='skills')this.renderSkills(root);else if(this.activeTab==='combat')this.renderCombat(root);else if(this.activeTab==='magic')this.renderMagic(root);else if(this.activeTab==='prayer')this.renderPrayer(root);else if(this.activeTab==='quests')this.renderQuests(root);else if(this.activeTab==='collection')this.renderCollection(root);}

  renderInventory(root) {
    root.innerHTML=`<p class="inventory-help">Drag items between slots like Tibia. Shift-drag a stack to choose an amount. Drag an item onto the 3D world to drop it.</p><div class="inventory-grid"></div><div style="margin-top:8px;display:flex;gap:5px"><button class="rs-button" id="inventory-sort">Sort</button><button class="rs-button" id="open-icon-editor">Icon Editor</button><button class="rs-button" id="inventory-json">Export Save</button></div>`;
    const grid=root.querySelector('.inventory-grid');
    for(let i=0;i<this.data.settings.inventorySlots;i++){
      const stack=this.state.inventory[i],slot=document.createElement('div');slot.className='slot';slot.dataset.index=i;
      slot.addEventListener('dragover',e=>{if(this.dragPayload?.type==='item'&&['inventory','equipment'].includes(this.dragPayload.container)){e.preventDefault();slot.classList.add('drag-over');}});
      slot.addEventListener('dragleave',()=>slot.classList.remove('drag-over'));
      slot.addEventListener('drop',e=>{e.preventDefault();slot.classList.remove('drag-over');if(this.dragPayload?.type==='item'){if(this.dragPayload.container==='inventory')this.moveInventoryStack(this.dragPayload.index,i,this.dragPayload.qty);else if(this.dragPayload.container==='equipment')this.unequipToInventorySlot(this.dragPayload.index,i);}this.clearDragPayload();});
      if(stack){const item=this.data.items[stack.id];slot.classList.toggle('bound',!!item?.bound);slot.draggable=true;slot.innerHTML=`<span class="item-icon">${item?.icon||'?'}</span>${stack.qty>1?`<span class="qty">${stack.qty}</span>`:''}`;slot.title=item?.name||stack.id;
        slot.addEventListener('dragstart',e=>this.beginItemDrag(e,'inventory',i,stack));slot.addEventListener('dragend',()=>{slot.classList.remove('dragging');this.clearDragPayload();});
        slot.addEventListener('click',()=>{if(!this.draggingItem)this.defaultItemAction(i);});slot.addEventListener('contextmenu',e=>{e.preventDefault();this.showItemMenu(e.clientX,e.clientY,i);});
      }
      grid.appendChild(slot);
    }
    $('inventory-sort').onclick=()=>{const sorted=this.state.inventory.filter(Boolean).sort((a,b)=>(this.data.items[a.id]?.type||'').localeCompare(this.data.items[b.id]?.type||'')||(this.data.items[a.id]?.name||'').localeCompare(this.data.items[b.id]?.name||''));this.state.inventory=Array(this.data.settings.inventorySlots).fill(null);sorted.forEach((stack,i)=>this.state.inventory[i]=stack);this.renderCurrentTab();};
    $('open-icon-editor').onclick=()=>this.openIconEditor();$('inventory-json').onclick=()=>this.exportSave();
  }

  beginItemDrag(event,container,index,stack) {
    let qty=stack.qty;if(event.shiftKey&&stack.qty>1){const requested=Number(prompt(`Move how many ${this.data.items[stack.id].name}?`,String(Math.max(1,Math.floor(stack.qty/2)))));if(!Number.isFinite(requested)||requested<1){event.preventDefault();return;}qty=clamp(Math.floor(requested),1,stack.qty);}
    this.dragPayload={type:'item',container,index,qty,itemId:stack.id};this.draggingItem=true;event.currentTarget.classList.add('dragging');event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',stack.id);event.dataTransfer.setData('application/x-runelite-item',JSON.stringify(this.dragPayload));
  }

  clearDragPayload(){this.dragPayload=null;this.draggingItem=false;$('drag-tooltip')?.classList.add('hidden');document.querySelectorAll('.drag-over,.dragging').forEach(el=>el.classList.remove('drag-over','dragging'));}

  moveInventoryStack(from,to,qty) {
    if(from===to)return;const source=this.state.inventory[from];if(!source)return;qty=clamp(qty||source.qty,1,source.qty);const target=this.state.inventory[to],item=this.data.items[source.id];
    if(target?.id===source.id&&item.stackable){target.qty+=qty;source.qty-=qty;if(source.qty<=0)this.state.inventory[from]=null;}
    else if(!target){this.state.inventory[to]={id:source.id,qty};source.qty-=qty;if(source.qty<=0)this.state.inventory[from]=null;}
    else if(qty===source.qty){this.state.inventory[to]=source;this.state.inventory[from]=target;}
    else {this.addChat('system','A split stack can only be moved into an empty slot or merged with the same item.');return;}
    this.recordEvent('inventory_moved',{itemId:source.id,qty,from,to});this.renderCurrentTab();this.saveSoon();
  }

  defaultItemAction(index){const stack=this.state.inventory[index];if(!stack)return;const item=this.data.items[stack.id];if(item.type==='spellbook')this.openSpellbook();else if(item.type==='weapon'||item.type==='armor'||item.type==='ammo')this.equipItem(index);else if(item.action==='Eat')this.eatItem(index);else if(item.action==='Bury')this.buryItem(index);else if(item.type==='resource'||item.type==='tool')this.openCrafting('any',stack.id);}
  showItemMenu(x,y,index){const stack=this.state.inventory[index];if(!stack)return;const item=this.data.items[stack.id],actions=[];
    if(item.type==='spellbook')actions.push(['Open spellbook',()=>this.openSpellbook()]);
    if(['weapon','armor','ammo'].includes(item.type))actions.push(['Equip',()=>this.equipItem(index)]);
    if(item.action==='Eat')actions.push(['Eat',()=>this.eatItem(index)]);if(item.action==='Bury')actions.push(['Bury',()=>this.buryItem(index)]);
    if(item.id.endsWith('_logs'))actions.push(['Light fire',()=>this.craftRecipe(`burn_${item.id.replace('_logs','')}_logs`)]);
    if(stack.qty>1)actions.push(['Split stack',()=>{const qty=Number(prompt(`Split how many ${item.name}?`,String(Math.floor(stack.qty/2))));if(Number.isFinite(qty)&&qty>0&&qty<stack.qty){const empty=this.state.inventory.findIndex(s=>!s);if(empty>=0)this.moveInventoryStack(index,empty,Math.floor(qty));else this.addChat('system','No empty inventory slot.');}}]);
    if(item.type!=='spellbook')actions.push(['Use in crafting',()=>this.openCrafting('any',item.id)]);
    if(!item.bound)actions.push(['Drop',()=>this.dropInventoryItem(index)]);
    actions.push(['Examine',()=>this.addChat('system',`${item.name}. Type: ${item.type}. ${item.bound?'Bound to this character. ':''}Value: ${item.value} coins.`)]);this.showContextMenu(x,y,item.name,actions);
  }
  equipItem(index){const stack=this.state.inventory[index];if(!stack)return;const item=this.data.items[stack.id],slot=item.slot;if(!slot)return;this.equipInventoryToSlot(index,slot,stack.qty);}
  equipInventoryToSlot(index,slot,qty=null){
    const stack=this.state.inventory[index];if(!stack)return;const item=this.data.items[stack.id];if(item?.slot!==slot){this.addChat('system',`${item?.name||stack.id} cannot be worn in the ${slot} slot.`);return;}
    const old=this.state.equipment[slot],oldQty=slot==='ammo'?Math.max(1,this.state.ammoQty||1):1;
    if(slot==='ammo'){
      const moveQty=clamp(qty||stack.qty,1,stack.qty);
      if(old===stack.id){this.state.ammoQty=(this.state.ammoQty||0)+moveQty;stack.qty-=moveQty;if(stack.qty<=0)this.state.inventory[index]=null;}
      else {
        const movingWhole=moveQty===stack.qty,oldItem=this.data.items[old],oldCanStack=old&&oldItem?.stackable&&this.state.inventory.some((s,i)=>i!==index&&s?.id===old),otherEmpty=this.state.inventory.some((s,i)=>i!==index&&!s);
        if(old&&!movingWhole&&!oldCanStack&&!otherEmpty){this.addChat('system','There is no inventory space for your currently equipped ammunition.');return;}
        this.state.equipment.ammo=stack.id;this.state.ammoQty=moveQty;stack.qty-=moveQty;if(stack.qty<=0)this.state.inventory[index]=null;
        if(old){if(!this.state.inventory[index])this.state.inventory[index]={id:old,qty:oldQty};else this.addItem(old,oldQty);}
      }
    }else{
      this.state.equipment[slot]=stack.id;this.state.inventory[index]=null;
      if(old)this.state.inventory[index]={id:old,qty:1};
    }
    this.recordEvent('item_equipped',{itemId:stack.id,slot});this.updateHeldItem();this.renderCurrentTab();this.updateHUD();this.saveSoon();
  }
  unequipToInventorySlot(slot,targetIndex){
    const id=this.state.equipment[slot];if(!id)return;const qty=slot==='ammo'?Math.max(1,this.state.ammoQty||1):1,target=this.state.inventory[targetIndex],item=this.data.items[id];
    if(target?.id===id&&item?.stackable)target.qty+=qty;
    else if(!target)this.state.inventory[targetIndex]={id,qty};
    else {this.addChat('system','That inventory slot is occupied. Drag to an empty slot or matching stack.');return;}
    this.state.equipment[slot]=null;if(slot==='ammo')this.state.ammoQty=0;this.recordEvent('item_unequipped',{itemId:id,slot,targetIndex});this.updateHeldItem();this.renderCurrentTab();this.updateHUD();this.saveSoon();
  }
  dropEquippedItem(slot,point=null){
    const id=this.state.equipment[slot];if(!id)return;const item=this.data.items[id],qty=slot==='ammo'?Math.max(1,this.state.ammoQty||1):1;if(item?.bound){this.addChat('system',`${item.name} is bound and cannot be dropped.`);return;}
    const x=point?.x??this.state.position.x+randomInt(-22,22),z=point?.z??this.state.position.z+randomInt(-22,22);this.spawnGroundItem(id,qty,x,z);this.state.equipment[slot]=null;if(slot==='ammo')this.state.ammoQty=0;this.recordEvent('equipped_item_dropped',{itemId:id,qty,slot,x,z});this.addChat('action',`You drop ${qty} × ${item.name}.`);this.updateHeldItem();this.renderCurrentTab();this.updateHUD();this.saveSoon();
  }
  eatItem(index){const stack=this.state.inventory[index];if(!stack)return;const item=this.data.items[stack.id];if(this.state.hp>=this.state.maxHp){this.addChat('system','You are already at full health.');return;}this.state.hp=Math.min(this.state.maxHp,this.state.hp+(item.heal||0));this.removeInventoryIndex(index,1);this.addChat('action',`You eat ${item.name} and heal ${item.heal}.`);this.renderCurrentTab();this.updateHUD();}
  buryItem(index){const stack=this.state.inventory[index];if(!stack)return;const item=this.data.items[stack.id];this.addXp('prayer',item.prayerXp||5);this.removeInventoryIndex(index,1);this.addChat('action',`You bury ${item.name}.`);this.renderCurrentTab();}
  removeInventoryIndex(index,qty){const stack=this.state.inventory[index];if(!stack)return;stack.qty-=qty;if(stack.qty<=0)this.state.inventory[index]=null;}
  dropInventoryItem(index,qty=null,point=null){const stack=this.state.inventory[index];if(!stack)return;const item=this.data.items[stack.id];if(item?.bound){this.addChat('system',`${item.name} is bound to your character and cannot be dropped.`);return;}qty=clamp(qty||stack.qty,1,stack.qty);const x=point?.x??this.state.position.x+randomInt(-22,22),z=point?.z??this.state.position.z+randomInt(-22,22);this.spawnGroundItem(stack.id,qty,x,z);stack.qty-=qty;if(stack.qty<=0)this.state.inventory[index]=null;this.addChat('action',`You drop ${qty} × ${item.name}.`);this.recordEvent('item_dropped',{itemId:item.id,qty,x,z});this.renderCurrentTab();this.saveSoon();}

  openSpellbook(){const body=document.createElement('div');body.innerHTML='<p>These are the spells learned by this character. Drag any learned spell onto the hotbar.</p><div class="spell-grid" id="spellbook-grid"></div>';const grid=body.querySelector('#spellbook-grid');this.state.spellbook.learned.forEach(id=>{const spell=this.data.spells[id];if(spell)grid.appendChild(this.makeSpellCard(spell));});this.openModal(`${this.state.name}'s Spellbook`,body);}
  makeSpellCard(spell){const have=Object.entries(spell.runes||{}).every(([id,q])=>this.itemCount(id)>=q),level=this.state.skills.magic.level>=spell.level,b=document.createElement('button');b.className=`spell-card learned ${this.selectedSpell===spell.id?'active':''}`;b.classList.toggle('locked',!level);b.draggable=true;b.innerHTML=`<b>${spell.icon} ${spell.name}</b><small>Magic ${spell.level}. ${Object.entries(spell.runes||{}).map(([id,q])=>`${q} ${this.data.items[id]?.name||id}`).join(', ')||'No runes'} ${have?'':'— missing runes'}</small>`;b.onclick=()=>this.activateSpell(spell.id);b.addEventListener('dragstart',e=>{this.dragPayload={type:'spell',spellId:spell.id};e.dataTransfer.effectAllowed='copy';e.dataTransfer.setData('application/x-runelite-spell',spell.id);b.classList.add('dragging');});b.addEventListener('dragend',()=>{b.classList.remove('dragging');this.clearDragPayload();});return b;}
  activateSpell(spellId){const spell=this.data.spells[spellId];if(!spell||!this.state.spellbook.learned.includes(spellId))return;if(this.state.skills.magic.level<spell.level){this.addChat('system',`You need Magic level ${spell.level}.`);return;}if(spell.teleport){if(!this.consumeSpellRunes(spell))return;const target=spell.teleport==='house'?['house',16000,160]:['city',0,0];this.teleport(target[0],target[1],target[2]);this.addXp('magic',spell.xp);this.recordEvent('spell_cast',{spellId});return;}this.selectedSpell=this.selectedSpell===spellId?null:spellId;this.addChat('action',this.selectedSpell?`${spell.name} is selected. Click an enemy to attack.`:`${spell.name} is no longer selected.`);this.renderCurrentTab();this.renderHotbar();}
  consumeSpellRunes(spell){const missing=Object.entries(spell.runes||{}).filter(([id,q])=>this.itemCount(id)<q);if(missing.length){this.addChat('system',`You lack ${missing.map(([id,q])=>`${q} ${this.data.items[id]?.name||id}`).join(', ')}.`);return false;}Object.entries(spell.runes||{}).forEach(([id,q])=>this.removeItem(id,q));return true;}
  renderHotbar(){const root=$('hotbar-slots');if(!root)return;root.innerHTML='';for(let i=0;i<10;i++){const id=this.state.hotbar[i],spell=id?this.data.spells[id]:null,slot=document.createElement('button');slot.className='hotbar-slot';slot.dataset.slot=i;slot.innerHTML=`<span class="hotkey">${i===9?0:i+1}</span>${spell?`<span class="spell-icon">${spell.icon}</span><span class="hotbar-name">${esc(spell.name)}</span>`:''}`;slot.title=spell?`${spell.name} — key ${i===9?0:i+1}`:`Drop a spell here — key ${i===9?0:i+1}`;slot.onclick=()=>this.useHotbarSlot(i);slot.addEventListener('dragover',e=>{if(this.dragPayload?.type==='spell'){e.preventDefault();slot.classList.add('drag-over');}});slot.addEventListener('dragleave',()=>slot.classList.remove('drag-over'));slot.addEventListener('drop',e=>{e.preventDefault();slot.classList.remove('drag-over');if(this.dragPayload?.type==='spell')this.assignSpellToHotbar(this.dragPayload.spellId,i);this.clearDragPayload();});slot.addEventListener('contextmenu',e=>{e.preventDefault();this.state.hotbar[i]=null;this.renderHotbar();this.saveSoon();});root.appendChild(slot);}}
  assignSpellToHotbar(spellId,index){if(!this.state.spellbook.learned.includes(spellId))return;this.state.hotbar[index]=spellId;this.recordEvent('hotbar_assigned',{spellId,index});this.renderHotbar();this.saveSoon();}
  useHotbarSlot(index){const id=this.state.hotbar[index];if(id)this.activateSpell(id);}

  renderEquipment(root) {
    const slots=['head','neck','cape','weapon','body','shield','hands','legs','feet','ring','ammo'];root.innerHTML=`<p class="inventory-help">Drag wearable items from inventory onto matching equipment slots. Drag worn items back to inventory or onto the world.</p><div class="equipment-layout"></div><div id="equipment-stats" class="stat-list"></div>`;const layout=root.querySelector('.equipment-layout');
    slots.forEach(slot=>{
      const id=this.state.equipment[slot],item=id?this.data.items[id]:null,el=document.createElement('div');el.className='equipment-slot';el.dataset.slot=slot;
      el.innerHTML=item?`<span style="font-size:27px">${item.icon}</span><small>${esc(slot)}${slot==='ammo'?` ×${this.state.ammoQty}`:''}</small>`:`<span>·</span><small>${esc(slot)}</small>`;
      el.addEventListener('dragover',e=>{if(this.dragPayload?.type==='item'&&this.dragPayload.container==='inventory'&&this.data.items[this.dragPayload.itemId]?.slot===slot){e.preventDefault();el.classList.add('drag-over');}});
      el.addEventListener('dragleave',()=>el.classList.remove('drag-over'));
      el.addEventListener('drop',e=>{e.preventDefault();el.classList.remove('drag-over');if(this.dragPayload?.type==='item'&&this.dragPayload.container==='inventory')this.equipInventoryToSlot(this.dragPayload.index,slot,this.dragPayload.qty);this.clearDragPayload();});
      if(item){el.draggable=true;el.title=`Drag ${item.name} to inventory or world`;el.addEventListener('dragstart',e=>this.beginItemDrag(e,'equipment',slot,{id,qty:slot==='ammo'?Math.max(1,this.state.ammoQty||1):1}));el.addEventListener('dragend',()=>this.clearDragPayload());el.addEventListener('click',()=>{const empty=this.state.inventory.findIndex(s=>!s||s.id===id&&item.stackable);if(empty<0)this.addChat('system','Your inventory is full.');else this.unequipToInventorySlot(slot,empty);});}
      layout.appendChild(el);
    });
    const stats=this.equipmentStats();$('equipment-stats').innerHTML=Object.entries(stats).map(([k,v])=>`<span>${esc(k)}</span><b>${v}</b>`).join('');
  }
  renderSkills(root){root.innerHTML='<div class="skill-grid"></div>';const grid=root.firstChild;Object.values(this.data.skills).forEach(def=>{const s=this.state.skills[def.id],next=this.xpForLevel(s.level+1),row=document.createElement('div');row.className='skill-row';row.innerHTML=`<span>${def.icon}</span><span>${def.name}</span><b>${s.level}</b><small>${Math.floor(s.xp).toLocaleString()} / ${next.toLocaleString()} XP</small>`;grid.appendChild(row);});}
  renderCombat(root){const weapon=this.state.equipment.weapon?this.data.items[this.state.equipment.weapon]:null;root.innerHTML=`<h3>${weapon?.icon||'👊'} ${esc(weapon?.name||'Unarmed')}</h3><div class="combat-style-grid"></div><div class="detail-list" style="margin-top:8px"><span>Max hit</span><b>${this.playerMaxHit()}</b><span>Combat level</span><b>${this.combatLevel()}</b><span>Wanted</span><b>${Math.ceil(this.state.wanted)}</b></div>`;const grid=root.querySelector('.combat-style-grid');[['accurate','Accurate','Attack XP'],['aggressive','Aggressive','Strength XP'],['defensive','Defensive','Defence XP']].forEach(([id,name,xp])=>{const b=document.createElement('button');b.className=`combat-style ${this.state.combatStyle===id?'active':''}`;b.innerHTML=`<b>${name}</b><small>${xp}</small>`;b.onclick=()=>{this.state.combatStyle=id;this.renderCurrentTab();};grid.appendChild(b);});}
  renderMagic(root){root.innerHTML='<p>Your spell list belongs to the Personal Spellbook item in your inventory.</p><button class="rs-button primary" id="open-spellbook-tab">📕 Open Spellbook</button><div class="spell-grid" id="magic-preview" style="margin-top:8px"></div>';$('open-spellbook-tab').onclick=()=>this.openSpellbook();const grid=$('magic-preview');this.state.spellbook.learned.slice(0,6).forEach(id=>{const spell=this.data.spells[id];if(spell)grid.appendChild(this.makeSpellCard(spell));});}
  renderPrayer(root){root.innerHTML='<div class="prayer-grid"></div>';const grid=root.firstChild;Object.values(this.data.prayers).forEach(p=>{const unlocked=this.state.skills.prayer.level>=p.level,b=document.createElement('button');b.className=`prayer-card ${this.selectedPrayer.has(p.id)?'active':''}`;b.disabled=!unlocked;b.innerHTML=`<b>${p.icon} ${p.name}</b><small>Level ${p.level}; drain ${p.drain.toFixed(2)}/sec</small>`;b.onclick=()=>{if(this.selectedPrayer.has(p.id))this.selectedPrayer.delete(p.id);else if(this.state.prayer>0)this.selectedPrayer.add(p.id);this.renderCurrentTab();};grid.appendChild(b);});}
  renderQuests(root){root.innerHTML='<div class="quest-list"></div>';const list=root.firstChild;Object.values(this.data.quests).forEach(q=>{const s=this.state.quests[q.id],el=document.createElement('div');el.className=`quest-card ${s.state===2?'complete':s.state===1?'started':''}`;el.innerHTML=`<b>${s.state===2?'✓ ':s.state===1?'• ':''}${q.name}</b><small>${s.state===0?q.summary:s.state===2?'Complete':this.questProgressText(q,s)}</small>`;list.appendChild(el);});}
  renderCollection(root){const total=Object.keys(this.data.items).length,found=Object.keys(this.state.collection).length;root.innerHTML=`<p>Collection: <b>${found}/${total}</b></p><div class="collection-list"></div>`;const list=root.querySelector('.collection-list');Object.values(this.data.items).filter(i=>i.rare||this.state.collection[i.id]).sort((a,b)=>Number(!!this.state.collection[b.id])-Number(!!this.state.collection[a.id])).forEach(item=>{const c=this.state.collection[item.id],el=document.createElement('div');el.className='collection-card';el.innerHTML=`<b>${c?item.icon:'❔'} ${c?item.name:'Unknown rare drop'}</b><small>${c?`Found ${c.count} time(s)`:'Not yet discovered'}</small>`;list.appendChild(el);});}

  openCrafting(station='any',focusItem=null) {
    const recipes=this.data.recipes.filter(r=>(station==='any'||r.station===station||r.station==='any')&&(!focusItem||r.inputs[focusItem]));
    const body=document.createElement('div');body.innerHTML=`<div class="recipe-grid"></div>`;const grid=body.firstChild;
    recipes.forEach(r=>{const can=this.canCraft(r),card=document.createElement('div');card.className=`recipe-card ${can?'':'disabled'}`;card.innerHTML=`<div class="big">${r.icon}</div><b>${r.name}</b><small>${this.data.skills[r.skill].name} ${r.level}</small><small>${Object.entries(r.inputs).map(([id,q])=>`${q} ${this.data.items[id]?.name||id}`).join(', ')}</small><small>Produces: ${Object.entries(r.outputs).map(([id,q])=>`${q} ${this.data.items[id]?.name||id}`).join(', ')||'fire'}</small>`;card.onclick=()=>this.craftRecipe(r.id);grid.appendChild(card);});
    this.openModal(station==='any'?'Crafting & Production':`Station: ${station.replaceAll('_',' ')}`,body);
  }
  canCraft(r){return this.state.skills[r.skill].level>=r.level&&Object.entries(r.inputs).every(([id,q])=>this.itemCount(id)>=q)&&Object.entries(r.outputs).every(([id,q])=>this.hasInventorySpace(id)||this.itemCount(id)>0);}
  craftRecipe(id){const r=this.data.recipes.find(x=>x.id===id);if(!r)return;if(!this.canCraft(r)){this.addChat('system','You lack the skill, materials, tool, or inventory space.');return;}
    this.performTimedAction(r.name+'...',1.0+Object.values(r.inputs).reduce((a,b)=>a+b,0)*.15,()=>{Object.entries(r.inputs).forEach(([item,q])=>{if(this.data.items[item]?.type!=='tool')this.removeItem(item,q);});const success=r.successChance===undefined||Math.random()<r.successChance;if(success){if(r.skill==='firemaking')this.createFire(this.state.position.x,this.state.position.z);Object.entries(r.outputs).forEach(([item,q])=>this.addItem(item,q));this.addXp(r.skill,r.xp);this.state.crafted[r.skill]=(this.state.crafted[r.skill]||0)+1;this.recordEvent('recipe_crafted',{recipeId:r.id,skill:r.skill,outputs:r.outputs,xp:r.xp});this.addChat('action',`${r.name} succeeds.`);Object.keys(r.outputs).forEach(id=>this.recordCollection(id));}else this.addChat('action',`${r.name} fails and the material is lost.`);this.checkAchievements();this.closeModal();});
  }

  openBank(){const body=document.createElement('div');body.className='split-layout';body.innerHTML='<section class="panel-section"><h3>Bank Storage</h3><p class="inventory-help">Drag items between the bank and inventory. Shift-drag to split a stack.</p><div class="bank-grid container-drop-zone" id="bank-storage"></div></section><section class="panel-section"><h3>Inventory</h3><div class="bank-grid container-drop-zone" id="bank-inventory"></div></section>';this.openModal('Bank of Crownstone',body);this.renderBank();}
  renderBank(){const bank=$('bank-storage'),inv=$('bank-inventory');if(!bank||!inv)return;bank.innerHTML='';inv.innerHTML='';
    const bindZone=(zone,target)=>{zone.ondragover=e=>{if(this.dragPayload?.type==='item'&&this.dragPayload.container!==target){e.preventDefault();zone.classList.add('drag-over');}};zone.ondragleave=()=>zone.classList.remove('drag-over');zone.ondrop=e=>{e.preventDefault();zone.classList.remove('drag-over');if(this.dragPayload?.type==='item'&&this.dragPayload.container!==target)this.transferContainerItem(this.dragPayload.container,this.dragPayload.index,target,this.dragPayload.qty);this.clearDragPayload();};};
    bindZone(bank,'bank');bindZone(inv,'inventory');
    this.state.bank.filter(Boolean).forEach((stack,index)=>bank.appendChild(this.makeItemCard(stack,()=>this.transferContainerItem('bank',index,'inventory',stack.qty),{container:'bank',index,stack})));
    this.state.inventory.forEach((stack,index)=>{if(stack)inv.appendChild(this.makeItemCard(stack,()=>this.transferContainerItem('inventory',index,'bank',stack.qty),{container:'inventory',index,stack}));});
  }
  transferContainerItem(source,index,target,qty){const arr=source==='bank'?this.state.bank:this.state.inventory,stack=arr[index];if(!stack)return;const item=this.data.items[stack.id];if(target==='bank'&&item?.bound){this.addChat('system',`${item.name} is bound to this character and cannot be banked.`);return;}qty=clamp(qty||stack.qty,1,stack.qty);if(!this.addItem(stack.id,qty,target)){this.addChat('system',target==='bank'?'Your bank is full.':'Your inventory is full.');return;}stack.qty-=qty;if(stack.qty<=0){if(source==='bank')arr.splice(index,1);else arr[index]=null;}this.recordEvent('container_transfer',{itemId:stack.id,qty,source,target});this.renderBank();this.renderCurrentTab();this.saveSoon();}
  makeItemCard(stack,onClick,dragInfo=null){const item=this.data.items[stack.id],el=document.createElement('div');el.className='item-card';el.innerHTML=`<div class="big">${item?.icon||'?'}</div><b>${esc(item?.name||stack.id)}</b><small>Quantity: ${stack.qty}</small>`;el.onclick=onClick;if(dragInfo){el.draggable=true;el.addEventListener('dragstart',e=>this.beginItemDrag(e,dragInfo.container,dragInfo.index,dragInfo.stack));el.addEventListener('dragend',()=>this.clearDragPayload());}return el;}

  openShop(shopId){const shop=this.data.shops[shopId]||this.data.shops.general_store,body=document.createElement('div');body.className='split-layout';body.innerHTML=`<section class="panel-section"><h3>Shop Stock</h3><div class="shop-grid" id="shop-stock"></div></section><section class="panel-section"><h3>Your Inventory</h3><div class="shop-grid" id="shop-inventory"></div></section>`;this.openModal(shop.name,body);this.renderShop(shop);}
  renderShop(shop){const stock=$('shop-stock'),inv=$('shop-inventory');if(!stock||!inv)return;stock.innerHTML='';inv.innerHTML='';Object.entries(shop.stock).forEach(([id,qty])=>{const price=Math.max(1,Math.ceil(this.data.items[id].value*shop.buyMultiplier));const el=this.makeItemCard({id,qty},()=>{if(this.itemCount('coins')<price){this.addChat('system','You do not have enough coins.');return;}if(this.addItem(id,1)){this.removeItem('coins',price);shop.stock[id]--;this.playSfx('coin');this.recordEvent('shop_buy',{shopId:shop.id,itemId:id,qty:1,price});this.addChat('loot',`You buy ${this.data.items[id].name} for ${price} coins.`);this.renderShop(shop);this.renderCurrentTab();}});el.insertAdjacentHTML('beforeend',`<small>Buy: ${price} coins</small>`);stock.appendChild(el);});this.state.inventory.forEach((s,i)=>{if(!s||s.id==='coins'||this.data.items[s.id]?.bound)return;const price=Math.max(1,Math.floor(this.data.items[s.id].value*shop.sellMultiplier));const el=this.makeItemCard(s,()=>{this.removeInventoryIndex(i,1);this.addItem('coins',price);this.playSfx('coin');shop.stock[s.id]=(shop.stock[s.id]||0)+1;this.recordEvent('shop_sell',{shopId:shop.id,itemId:s.id,qty:1,price});this.addChat('loot',`You sell ${this.data.items[s.id].name} for ${price} coins.`);this.renderShop(shop);this.renderCurrentTab();});el.insertAdjacentHTML('beforeend',`<small>Sell: ${price} coins</small>`);inv.appendChild(el);});}

  openIconEditor(){const body=document.createElement('div');body.innerHTML='<p>Change any icon. Changes are part of the editable content registry and can be exported or pushed from the Developer Panel.</p><div class="shop-grid" id="icon-edit-grid"></div>';const grid=body.querySelector('#icon-edit-grid');Object.values(this.data.items).forEach(item=>{const card=document.createElement('label');card.className='item-card';card.innerHTML=`<b>${esc(item.name)}</b><input class="data-input" value="${esc(item.icon)}" maxlength="8">`;card.querySelector('input').addEventListener('change',e=>{item.icon=e.target.value||'❔';this.renderCurrentTab();});grid.appendChild(card);});this.openModal('Customize Item Icons',body);}

  openGuide(){const body=document.createElement('div');body.className='guide-content';body.innerHTML=`
    <h2>RuneLite: Primitive Realm Guide</h2><p>This build preserves the original right-click RuneScape-style loop and expands it into a large 3D primitive world.</p>
    <h3>Controls</h3><p>Drag inventory items between slots and containers like Tibia; Shift-drag splits stacks, and dragging onto the world drops the item. Drag learned spells from the Personal Spellbook onto the numbered hotbar. <code>Left-click</code> walks or performs the default action. <code>Right-click</code> opens every available action, including opening and closing house doors. Middle-drag rotates the camera. Mouse wheel zooms. While inside the house, use the corner checkbox to stop the follow camera from spinning back behind the character. <code>R</code> toggles run, <code>I</code> opens inventory, and <code>Esc</code> cancels actions.</p>
    <h3>Your Player-Owned House</h3><p>New and migrated characters begin inside their furnished home with a bank chest, cooking range, crafting table, altar, bed, spellbook lectern, and portal. When you enter a room, the ceiling becomes mostly transparent. The front and back wall openings contain right-clickable doors. Outside are a restorative fountain, garden allotment, cooking hearth, fishing pond, woodcutting grove, flax and wheat plots, a combat training dummy, four renewable harvestable garden types, and the Garden Rune Match minigame. Drinking from the fountain fully heals you and grants +1 hitpoint per second for ten minutes. The Arcane Study and Pet Room are the only locked rooms. Oak planks, steel nails, an arcane lens, pet bedding, and rope can all be produced or obtained through the expanded industry chains.</p>
    <h3>Crownstone City</h3><p>Click the house portal to arrive at the city-center fountain. The enlarged city is divided into clearly signed districts containing a bank, general store, forge, fletching hall, tannery, weaver, inn, wizard tower, ranger lodge, guild, temple, barracks, farm, carpenters guild, and sewer works. Every interactive building displays its icon, name, and use. Buildings now face the roads through their configured door side, receive a generated connector path, and use solid collision rather than allowing the player to walk through their footprint.</p>
    <h3>Animals & Adoption</h3><p>Butterflies decorate gardens and forests. Friendly dogs and curious cats may follow you temporarily after you approach or pet them. Right-click a dog or cat and choose Adopt to make it a persistent companion; adopted animals travel between regions with you and are recorded in the character save and event history.</p>
    <h3>Sewers</h3><p>Use the ladder in Sewer Works. Fight sewer rats, cave rats, slimes, and the Sewer King. Find the key in a broken drain or as a rare slime drop, then unlock the treasure chest for the Sewer King Blade and Plagueguard Chestpiece.</p>
    <h3>Industry</h3><p>Mine copper, tin, iron, and coal; smelt bronze, iron, and steel; smith complete armor sets, shields, tools, and weapon families. Chop trees; cut bows and arrow shafts; spin flax into bow strings; add feathers and metal arrowheads. Tan hides and sew leather sets. Fish, cook, farm, steal, pray, use magic, complete quests, and take Slayer assignments.</p>
    <h3>Persistence</h3><p>The game auto-saves locally and attempts server saves through <code>Runelite.php</code>. The developer panel exports/imports the entire content registry and player state as JSON. The SQL schema uses only <code>FSG_Runelite_</code> tables.</p>`;this.openModal('Official Player Guide',body);}

  openDeveloper() {
    const body=document.createElement('div');body.className='developer-layout';body.innerHTML=`<nav class="developer-nav" id="developer-nav"></nav><section class="developer-main"><div class="developer-toolbar"><button class="rs-button good" id="dev-apply">Apply JSON</button><button class="rs-button" id="dev-export">Export Registry</button><button class="rs-button" id="dev-import">Import Registry</button><button class="rs-button" id="dev-save-player">Save Player Now</button><button class="rs-button" id="dev-load-player">Load Player Save</button><button class="rs-button" id="dev-save-server">Push to Server</button><button class="rs-button" id="dev-load-server">Pull from Server</button><button class="rs-button" id="dev-drop-table">Readable Drop Tables</button><button class="rs-button" id="dev-catalog">Object & Data Catalog</button><button class="rs-button" id="dev-layout">World Layout Audit</button><button class="rs-button" id="dev-events">Player Event Log</button><button class="rs-button danger" id="dev-reset">Reset Category</button><input type="file" id="dev-file" accept="application/json" hidden></div><textarea id="developer-editor" class="developer-editor" spellcheck="false"></textarea><div class="developer-status" id="developer-status"></div></section>`;
    const modal=this.openModal('Developer Data Console',body,'developer-window');const categories=['playerState','settings','skills','items','recipes','enemies','bosses','animals','harvestables','minigames','npcs','shops','quests','slayerTasks','spells','prayers','areas','achievements','randomEvents','world'];let active='items';const nav=$('developer-nav'),editor=$('developer-editor'),status=$('developer-status');
    const categoryValue=()=>active==='playerState'?this.state:this.data[active];const load=()=>{editor.value=JSON.stringify(categoryValue(),null,2);status.textContent=`Editing ${active}. ${this.countCategory(categoryValue())} records. Server: ${this.server.status}.`;nav.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b.dataset.category===active));};
    categories.forEach(c=>{const b=document.createElement('button');b.dataset.category=c;b.textContent=`${c} (${this.countCategory(c==='playerState'?this.state:this.data[c])})`;b.onclick=()=>{active=c;load();};nav.appendChild(b);});load();
    $('dev-apply').onclick=()=>{try{const parsed=JSON.parse(editor.value);if(active==='playerState'){this.state={...this.createInitialState(),...parsed};this.normalizeState();this.applyPlayerStateToWorld();this.updateHUD();}else this.data[active]=parsed;status.textContent=`Applied ${active}. Rebuilding world and UI...`;if(active!=='playerState'&&['world','areas','enemies','bosses','animals','harvestables','npcs'].includes(active))this.buildWorld();this.renderCurrentTab();this.updateHeldItem();this.toast(`Applied ${active}`);}catch(e){status.textContent=`JSON error: ${e.message}`;}};
    $('dev-export').onclick=()=>this.downloadJson('FSG_Runelite_ContentRegistry.json',this.data);
    $('dev-import').onclick=()=>$('dev-file').click();$('dev-file').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const parsed=JSON.parse(await f.text());this.data={...this.data,...parsed};active='items';load();this.buildWorld();this.renderCurrentTab();status.textContent='Imported registry and rebuilt world.';}catch(err){status.textContent=`Import failed: ${err.message}`;}};
    $('dev-save-player').onclick=async()=>{await this.savePlayerState();status.textContent=`Player save complete. ${this.server.status}.`;};
    $('dev-load-player').onclick=async()=>{await this.loadPlayerState();this.applyPlayerStateToWorld();this.renderCurrentTab();this.updateHUD();active='playerState';load();status.textContent='Player save loaded.';};
    $('dev-save-server').onclick=async()=>{try{const result=await this.api('saveContent',{content:this.data,contentVersion:this.data.meta.contentVersion});this.data.meta.contentVersion=result.contentVersion;status.textContent=`Server content saved. Version ${result.contentVersion}.`;}catch(e){status.textContent=`Server save failed: ${e.message}`;}};
    $('dev-load-server').onclick=async()=>{try{await this.loadRemoteContent(true);load();this.buildWorld();status.textContent='Pulled content registry from server.';}catch(e){status.textContent=`Server load failed: ${e.message}`;}};
    $('dev-drop-table').onclick=()=>this.openDropTables();
    $('dev-catalog').onclick=()=>this.openDataCatalog();
    $('dev-layout').onclick=()=>this.openLayoutAudit();
    $('dev-events').onclick=()=>this.openPlayerEvents();
    $('dev-reset').onclick=()=>{if(active==='playerState')this.state=this.createInitialState();else this.data[active]=clone(window.DEFAULT_GAME_DATA[active]);load();};
    return modal;
  }

  countCategory(value){return Array.isArray(value)?value.length:value&&typeof value==='object'?Object.keys(value).length:1;}

  openDataCatalog() {
    const unionFields=records=>[...new Set(records.flatMap(record=>record&&typeof record==='object'?Object.keys(record):[]))].sort();
    const groups=[
      ['Items',Object.values(this.data.items)],['Recipes',Object.values(this.data.recipes)],['Creatures',Object.values(this.data.enemies)],['Bosses',Object.values(this.data.bosses)],['Wildlife',Object.values(this.data.animals)],['Harvestables',Object.values(this.data.harvestables||{})],['NPC characters',Object.values(this.data.npcs)],['Shops',Object.values(this.data.shops)],['Quests',Object.values(this.data.quests)],['Slayer tasks',Object.values(this.data.slayerTasks)],['Spells',Object.values(this.data.spells)],['Prayers',Object.values(this.data.prayers)],['Areas',Object.values(this.data.areas)],['Achievements',Object.values(this.data.achievements)],['Random events',Object.values(this.data.randomEvents)],['Minigames',Object.values(this.data.minigames||{})]
    ];
    const worldGroups=[['Buildings',this.data.world.cityBuildings||[]],['Roads',this.data.world.cityRoads||[]],['NPC spawns',this.data.world.npcSpawns||[]],['Creature spawns',this.data.world.enemySpawns||[]],['Wildlife spawns',this.data.world.animalSpawns||[]],['Resource spawns',this.data.world.resourceSpawns||[]],['Harvestable spawns',this.data.world.harvestableSpawns||[]],['Special objects',this.data.world.specialObjects||[]],['Terrain regions',this.data.world.terrainRegions||[]],['House rooms',this.data.world.playerHouse?.rooms||[]]];
    const rows=[...groups,...worldGroups].map(([label,records])=>`<details><summary><b>${esc(label)}</b> — ${records.length} records</summary><p><b>Fields:</b> ${unionFields(records).map(esc).join(', ')||'none'}</p><p><b>Tracked names:</b> ${records.map(r=>esc(r.name||r.id||r.npc||r.enemy||r.animal||r.kind||r.type||'unnamed')).join(', ')||'none'}</p></details>`).join('');
    const body=document.createElement('div');body.className='guide-content';body.innerHTML=`<h2>Runtime Object & Data Catalog</h2><p>This view is generated from the currently loaded content registry. Editing or importing JSON changes this list immediately.</p>${rows}<h3>Saved character state fields</h3><p>${Object.keys(this.state).sort().map(esc).join(', ')}</p>`;this.openModal('Object & Data Catalog',body,'developer-window');
  }

  openLayoutAudit() {
    const roads=this.data.world.cityRoads||[],buildings=this.data.world.cityBuildings||[];const issues=[];
    buildings.forEach((building,i)=>{
      const entrance=this.getBuildingDoorPosition(building,34),nearest=this.nearestRoadPoint(entrance.x,entrance.z);
      if(!nearest||nearest.dist>420)issues.push(`${building.name}: entrance is ${Math.round(nearest?.dist||9999)} units from the nearest road.`);
      buildings.slice(i+1).forEach(other=>{const overlapX=Math.abs(building.x-other.x)<(building.w+other.w)/2+35,overlapZ=Math.abs(building.z-other.z)<(building.d+other.d)/2+35;if(overlapX&&overlapZ)issues.push(`${building.name} overlaps or crowds ${other.name}.`);});
      roads.forEach(road=>{const overlapX=Math.abs(building.x-road.x)<(building.w+road.w)/2-20,overlapZ=Math.abs(building.z-road.z)<(building.d+road.d)/2-20;if(overlapX&&overlapZ)issues.push(`${building.name} footprint intersects ${road.name}.`);});
    });
    const body=document.createElement('div');body.className='guide-content';body.innerHTML=`<h2>World Layout Audit</h2><p>Checked ${buildings.length} buildings against ${roads.length} road segments, entrances, spacing, and footprints.</p>${issues.length?`<ul>${issues.map(i=>`<li>${esc(i)}</li>`).join('')}</ul>`:'<p class="good-text">No road/building overlap or disconnected entrance problems detected.</p>'}`;this.openModal('World Layout Audit',body,'developer-window');
  }

  async openPlayerEvents() {
    const body=document.createElement('div');body.innerHTML='<p>Loading server event history...</p>';this.openModal('Player Event History',body,'developer-window');
    try{
      const result=await this.api('listEvents',{characterName:this.state.name,limit:300});
      if(!result.events.length){body.innerHTML='<p>No server events have been recorded yet. Events are uploaded with the next autosave.</p>';return;}
      body.innerHTML=`<table class="data-table"><thead><tr><th>Server time</th><th>Event</th><th>Payload</th></tr></thead><tbody>${result.events.map(e=>`<tr><td>${esc(e.serverCreatedAt||'')}</td><td>${esc(e.type)}</td><td><pre>${esc(JSON.stringify(e.payload,null,2))}</pre></td></tr>`).join('')}</tbody></table>`;
    }catch(e){body.innerHTML=`<p>Unable to load server events: ${esc(e.message)}</p><p>Unsaved local event queue: ${this.eventQueue.length}</p>`;}
  }

  openDropTables(){const body=document.createElement('div');const rows=[...Object.values(this.data.enemies),...Object.values(this.data.bosses)].map(e=>`<tr><td>${e.boss?'Boss':'Creature'}</td><td>${esc(e.name)}</td><td>${e.level}</td><td>${e.hp}</td><td>${e.drops.map(d=>`${esc(this.data.items[d.item]?.name||d.item)} — ${(d.chance*100).toFixed(d.chance<.01?2:1)}% (${d.min}-${d.max})`).join('<br>')}</td></tr>`).join('');body.innerHTML=`<table class="data-table"><thead><tr><th>Type</th><th>Name</th><th>Level</th><th>HP</th><th>Drop table</th></tr></thead><tbody>${rows}</tbody></table>`;this.openModal('Creatures, Bosses & Drop Tables',body,'developer-window');}

  openChoice(title,choices){const body=document.createElement('div');body.className='recipe-grid';choices.forEach(c=>{const b=document.createElement('button');b.className='rs-button';b.textContent=c.label;b.onclick=c.action;body.appendChild(b);});this.openModal(title,body);}
  openModal(title,content,extraClass='') {this.closeModal();const modal=$('window-template').content.firstElementChild.cloneNode(true);modal.querySelector('.modal-title').textContent=title;modal.querySelector('.modal-body').appendChild(content);if(extraClass)modal.querySelector('.modal-window').classList.add(extraClass);modal.querySelector('.modal-close').onclick=()=>this.closeModal();modal.addEventListener('mousedown',e=>{if(e.target===modal)this.closeModal();});$('modal-root').appendChild(modal);this.activeModal=modal;return modal;}
  closeModal(){if(this.activeModal){this.activeModal.remove();this.activeModal=null;}}

  restorePrayer(){this.state.prayer=this.state.maxPrayer;this.addChat('system','Your prayer points are restored.');this.updateHUD();}
  examineEnemy(id){const e=this.enemies.get(id);if(!e)return;this.addChat('system',`${e.data.name}: level ${e.data.level}, ${e.data.hp} HP, max hit ${e.data.maxHit}. Drops: ${e.data.drops.map(d=>this.data.items[d.item]?.name||d.item).join(', ')}.`);}

  updateHUD(){
    $('hud-hp').textContent=`${Math.ceil(this.state.hp)}/${this.state.maxHp}`;$('hud-prayer').textContent=`${Math.floor(this.state.prayer)}/${this.state.maxPrayer}`;$('hud-run').textContent=`${Math.floor(this.state.runEnergy)}%`;$('hud-combat').textContent=this.combatLevel();$('hud-total').textContent=this.totalLevel();$('hud-area').textContent=this.data.areas[this.state.area]?.name||this.state.area;$('hud-task').textContent=this.state.slayerTask?`${this.state.slayerTask.name}: ${this.state.slayerTask.remaining}`:'No Slayer task';$('toggle-run').textContent=`Run: ${this.state.runEnabled?'On':'Off'}`;const regenRemaining=Math.max(0,Number(this.state.buffs.homeFountainRegenUntil||0)-Date.now());const regenPill=$('hud-regen-pill');if(regenPill){regenPill.classList.toggle('hidden',regenRemaining<=0);if(regenRemaining>0){const total=Math.ceil(regenRemaining/1000),minutes=Math.floor(total/60),seconds=String(total%60).padStart(2,'0');$('hud-regen').textContent=`${minutes}:${seconds}`;}}
  }
  addChat(type,text){const line=document.createElement('div');line.className=`chat-line ${type}`;line.textContent=text;$('chat-log')?.appendChild(line);if($('chat-log'))$('chat-log').scrollTop=$('chat-log').scrollHeight;}
  toast(text,type=''){const el=document.createElement('div');el.className=`toast ${type}`;el.textContent=text;$('toast-stack').appendChild(el);setTimeout(()=>el.remove(),3100);}

  drawMinimap() {
    const canvas=$('minimap'),ctx=canvas.getContext('2d'),area=this.data.areas[this.state.area]||this.data.areas.city;ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle=area.ground;ctx.fillRect(0,0,canvas.width,canvas.height);
    const scale=Math.min(canvas.width,canvas.height)/(area.size*2.25),originX=canvas.width/2-(this.state.position.x-area.center[0])*scale,originZ=canvas.height/2-(this.state.position.z-area.center[1])*scale;
    if(area.id==='city'){ctx.fillStyle='#7b7265';ctx.fillRect(originX-1800*scale,originZ-1800*scale,3600*scale,3600*scale);ctx.strokeStyle='#ddd1ae';ctx.strokeRect(originX-1800*scale,originZ-1800*scale,3600*scale,3600*scale);}
    if(area.id==='house'){ctx.fillStyle='#735f48';ctx.fillRect(originX-500*scale,originZ-380*scale,1000*scale,760*scale);}
    const draw=(x,z,color,r=2)=>{const sx=originX+(x-area.center[0])*scale,sy=originZ+(z-area.center[1])*scale;if(sx<0||sy<0||sx>canvas.width||sy>canvas.height)return;ctx.fillStyle=color;ctx.beginPath();ctx.arc(sx,sy,r,0,Math.PI*2);ctx.fill();};
    this.enemies.forEach(e=>{if(!e.dead&&e.area===this.state.area)draw(e.x,e.z,e.data.boss?'#b76ce0':'#d64b45',e.data.boss?4:2);});
    this.npcActors.forEach(n=>{if(n.area===this.state.area)draw(n.mesh.position.x,n.mesh.position.z,'#e7d35b',2);});
    this.animalActors.forEach(a=>{if(a.area===this.state.area)draw(a.x,a.z,a.adopted?'#ff8bc5':'#d8c7a0',a.adopted?3:1.5);});
    this.resources.forEach(r=>{if(!r.depleted&&this.detectAreaAt(r.x,r.z)===this.state.area)draw(r.x,r.z,r.skill==='mining'?'#8b8b91':r.skill==='fishing'?'#4ca8ce':'#4b8b4b',1);});
    this.harvestables.forEach(h=>{if(!h.depleted&&h.area===this.state.area)draw(h.x,h.z,'#b6d65e',1.6);});
    draw(this.state.position.x,this.state.position.z,'#ffffff',4);
  }

  loop(now) {
    const dt=Math.min(.05,(now-this.lastTimestamp)/1000);this.lastTimestamp=now;
    this.updatePlayer(dt);this.updateBuffs(dt);this.updateHouseInteriorState();this.updateCombat(dt);this.updateEnemies(dt);this.updateNPCs(dt);this.updateAnimals(dt);this.updateResources();this.updateHarvestables();this.updateDoors(dt);this.updateGroundItems();this.updatePrayers(dt);this.updateRandomEvents(dt);this.updateDayNight(dt);this.updateAnimations(dt);this.updateCamera();
    this.autosaveAccumulator+=dt;if(this.autosaveAccumulator>=this.data.settings.autosaveSeconds){this.autosaveAccumulator=0;this.savePlayerState();}
    this.minimapAccumulator+=dt;if(this.minimapAccumulator>.25){this.minimapAccumulator=0;this.drawMinimap();this.updateHUD();}
    this.renderer.render(this.scene,this.camera);requestAnimationFrame(this.boundLoop);
  }

  resize(){this.camera.aspect=innerWidth/innerHeight;this.camera.updateProjectionMatrix();this.renderer.setSize(innerWidth,innerHeight);}
  applyPlayerStateToWorld(){this.normalizeState();this.playerMesh.position.set(this.state.position.x,this.areaY(this.state.position.x,this.state.position.z),this.state.position.z);this.state.target={...this.state.position};this.playerMesh.children[0].material.color.set(this.state.color||this.playerColor);this.data.world.specialObjects.forEach(s=>{const special=this.specials.get(s.id);if(special&&s.onceFlag&&this.state.flags[s.onceFlag])special.mesh.visible=false;});this.refreshHouseObjects();this.refreshQuestMarkers();this.updateHeldItem();this.renderHotbar();this.updateHouseInteriorState(true);}

  async api(action,payload={}) {
    const response=await fetch(`${API_URL}?action=${encodeURIComponent(action)}`,{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({sessionId:this.sessionId,...payload})});
    const json=await response.json().catch(()=>({ok:false,error:`HTTP ${response.status}`}));if(!response.ok||!json.ok)throw new Error(json.error||`HTTP ${response.status}`);this.server.online=true;return json;
  }

  async loadRemoteContent(force=false) {
    try{const result=await this.api('bootstrap',{includeContent:true});this.server.authenticated=!!result.authenticated;this.server.isAdmin=!!result.isAdmin;this.server.status=result.authenticated?'Authenticated':'Guest server session';if(result.content&&(!this.data.meta.contentVersion||force||result.contentVersion>=this.data.meta.contentVersion)){this.data={...this.data,...result.content};}return true;}catch(e){this.server.online=false;this.server.status='Local mode';return false;}
  }

  async loadPlayerState() {
    const local=this.loadLocal();if(local)this.state={...this.createInitialState(),...local};this.state.name=$('character-name').value.trim()||this.state.name;this.state.color=this.playerColor;
    try{const result=await this.api('loadPlayer',{characterName:this.state.name});if(result.state){const remote=result.state;const localDate=Date.parse(this.state.lastSavedAt||0),remoteDate=Date.parse(remote.lastSavedAt||0);if(remoteDate>=localDate)this.state={...this.createInitialState(),...remote};this.server.revision=result.revision||0;this.state.saveRevision=this.server.revision;}this.server.authenticated=!!result.authenticated;}catch(e){this.server.online=false;}this.normalizeState();
  }

  recordEvent(type,payload={}) {
    this.eventQueue.push({eventId:uid('event'),type,payload,createdAt:new Date().toISOString()});
    if(this.eventQueue.length>100)this.eventQueue.splice(0,this.eventQueue.length-100);
  }

  async savePlayerState() {
    this.state.lastSavedAt=new Date().toISOString();this.saveLocal();
    if(!this.server.online)return;try{const result=await this.api('savePlayer',{characterName:this.state.name,revision:this.state.saveRevision||0,state:this.sanitizedState(),events:this.eventQueue.slice(0,100)});this.eventQueue=[];this.state.saveRevision=result.revision;this.server.revision=result.revision;this.server.status=`Saved revision ${result.revision}`;}catch(e){if(e.message.includes('revision')){this.server.status='Save conflict; local recovery retained';}else{this.server.online=false;this.server.status='Local recovery save';}}
  }
  saveSoon(){this.autosaveAccumulator=Math.max(this.autosaveAccumulator,this.data.settings.autosaveSeconds-2);this.saveLocal();}
  sanitizedState(){const state=clone(this.state);state.combatTarget=null;state.target={...state.position};state.combatLevel=this.combatLevel();state.totalLevel=this.totalLevel();return state;}
  saveLocal(){localStorage.setItem('FSG_Runelite_LocalSave',JSON.stringify(this.sanitizedState()));}
  loadLocal(){try{return JSON.parse(localStorage.getItem('FSG_Runelite_LocalSave')||'null');}catch{return null;}}
  exportSave(){this.downloadJson(`FSG_Runelite_${this.state.name}_Save.json`,this.sanitizedState());}
  downloadJson(filename,value){const blob=new Blob([JSON.stringify(value,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}
  enemyTemplate(id){return this.data.enemies[id]||this.data.bosses[id]||null;}
}

const game=new PrimitiveRealmGame();window.PrimitiveRealmGame=game;game.boot();
})();
