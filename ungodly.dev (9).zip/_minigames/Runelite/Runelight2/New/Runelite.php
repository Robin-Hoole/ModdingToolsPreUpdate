<?php

declare(strict_types=1);

/**
 * ==============================================================================
 * NAMESPACE: RobinHooleProduction
 * CONTEXT: Shared auth/session helper for the Ungodly/FSG web-app suite
 * DESCRIPTION: One login, every same-origin tool, 12-hour browser auth token.
 * ==============================================================================
 */
function fsgAuth_tokenLifetimeSeconds(): int { return 43200; }

function fsgAuth_isHttpsRequest(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
}

function fsgAuth_cookieDomain(): string
{
    $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
    $host = preg_replace('/:\d+$/', '', $host) ?: '';
    if ($host === '' || $host === 'localhost' || filter_var($host, FILTER_VALIDATE_IP) !== false) return '';
    return $host === 'ungodly.dev' ? '.ungodly.dev' : $host;
}

function fsgAuth_startSharedSession(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;

    ini_set('session.gc_maxlifetime', (string)fsgAuth_tokenLifetimeSeconds());
    ini_set('session.cookie_lifetime', (string)fsgAuth_tokenLifetimeSeconds());
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_strict_mode', '1');

    $params = [
        'lifetime' => fsgAuth_tokenLifetimeSeconds(),
        'path' => '/',
        'secure' => fsgAuth_isHttpsRequest(),
        'httponly' => true,
        'samesite' => 'Lax',
    ];
    $domain = fsgAuth_cookieDomain();
    if ($domain !== '') $params['domain'] = $domain;

    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params($params);
    } else {
        session_set_cookie_params(fsgAuth_tokenLifetimeSeconds(), '/', $domain, fsgAuth_isHttpsRequest(), true);
    }

    session_start();
}

function fsgAuth_touchSharedSession(): void
{
    fsgAuth_startSharedSession();
    $_SESSION['fsg_last_seen_at'] = time();
}

function fsgAuth_setBearerCookie(string $token): void
{
    $params = [
        'expires' => time() + fsgAuth_tokenLifetimeSeconds(),
        'path' => '/',
        'secure' => fsgAuth_isHttpsRequest(),
        'httponly' => true,
        'samesite' => 'Lax',
    ];
    $domain = fsgAuth_cookieDomain();
    if ($domain !== '') $params['domain'] = $domain;

    if (PHP_VERSION_ID >= 70300) {
        setcookie('AUTH_TOKEN', $token, $params);
    } else {
        setcookie('AUTH_TOKEN', $token, time() + fsgAuth_tokenLifetimeSeconds(), '/', $domain, fsgAuth_isHttpsRequest(), true);
    }

    header('X-Auth-Token: ' . $token);
    header('X-Auth-Expires-At: ' . gmdate('c', time() + fsgAuth_tokenLifetimeSeconds()));
}

function fsgAuth_clearBearerCookie(): void
{
    $params = [
        'expires' => time() - 42000,
        'path' => '/',
        'secure' => fsgAuth_isHttpsRequest(),
        'httponly' => true,
        'samesite' => 'Lax',
    ];
    $domain = fsgAuth_cookieDomain();
    if ($domain !== '') $params['domain'] = $domain;

    if (PHP_VERSION_ID >= 70300) {
        setcookie('AUTH_TOKEN', '', $params);
    } else {
        setcookie('AUTH_TOKEN', '', time() - 42000, '/', $domain, fsgAuth_isHttpsRequest(), true);
    }
}

function fsgAuth_extractBearerToken(): string
{
    // Query/body fallback exists because some shared-hosting stacks do not pass
    // Authorization or custom X-* headers into PHP reliably. Same-origin tools
    // append this token only after login, so all seven web apps can recognize
    // the same browser for the 12-hour window.
    $queryToken = (string)($_GET['authToken'] ?? $_GET['token'] ?? '');
    if (trim($queryToken) !== '') return trim($queryToken);

    $postToken = (string)($_POST['authToken'] ?? $_POST['token'] ?? '');
    if (trim($postToken) !== '') return trim($postToken);

    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authHeader = '';
    foreach ($headers as $key => $value) {
        if (strtolower((string)$key) === 'authorization') {
            $authHeader = (string)$value;
            break;
        }
    }
    if ($authHeader === '') $authHeader = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
    if ($authHeader === '') $authHeader = (string)($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (preg_match('/Bearer\s+(.+)/i', $authHeader, $matches)) return trim($matches[1]);

    $xToken = (string)($_SERVER['HTTP_X_AUTH_TOKEN'] ?? '');
    if (trim($xToken) !== '') return trim($xToken);

    $cookieToken = (string)($_COOKIE['AUTH_TOKEN'] ?? '');
    return trim($cookieToken);
}

function fsgAuth_tokenHash(string $token): string { return hash('sha256', $token); }

function fsgAuth_respondJson(array $payload, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function fsgAuth_requireCredentials(): array
{
    return [
        'pdb1058.awardspace.net',
        '4567047_ungodlytest',
        'qOhZ4m8w8Pes%SGW',
        '4567047_ungodlytest',
    ];
}

function fsgAuth_dbConnection(): PDO
{
    [$dbHost, $dbUser, $dbPass, $dbName] = fsgAuth_requireCredentials();
    $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
    return new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function fsgAuth_textValue(mixed $value): string
{
    if ($value === null) return '';
    if (is_bool($value)) return $value ? '1' : '0';
    if (is_scalar($value)) return (string)$value;
    return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '';
}

function fsgAuth_boolValue(mixed $value): int
{
    if (is_bool($value)) return $value ? 1 : 0;
    if (is_numeric($value)) return ((int)$value) !== 0 ? 1 : 0;
    if (is_string($value)) return in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true) ? 1 : 0;
    return 0;
}

function fsgAuth_requestBody(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') return [];
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) fsgAuth_respondJson(['ok' => false, 'error' => 'Invalid JSON body.'], 400);
    return $decoded;
}

function fsgAuth_sharedFsgUserIdSqlType(PDO $pdo): string
{
    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM FSG_users LIKE 'id'");
        $column = $stmt ? $stmt->fetch() : null;
        $type = strtolower((string)($column['Type'] ?? 'int'));
        $isUnsigned = strpos($type, 'unsigned') !== false;
        if (strpos($type, 'bigint') !== false) return $isUnsigned ? 'BIGINT UNSIGNED' : 'BIGINT';
        return $isUnsigned ? 'INT UNSIGNED' : 'INT';
    } catch (Throwable $e) {
        return 'INT';
    }
}

function fsgAuth_ensureAccountTables(PDO $pdo): void
{
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_users (
        id INT NOT NULL AUTO_INCREMENT,
        username VARCHAR(64) NOT NULL,
        email VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        is_over_18 TINYINT(1) NOT NULL DEFAULT 0,
        agreed_terms TINYINT(1) NOT NULL DEFAULT 0,
        agreed_privacy TINYINT(1) NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        is_admin TINYINT(1) NOT NULL DEFAULT 0,
        banned_until DATETIME NULL DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_FSG_users_active_username (is_active, username),
        KEY idx_FSG_users_active_email (is_active, email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $userColumns = [
        'is_over_18' => "ALTER TABLE FSG_users ADD COLUMN is_over_18 TINYINT(1) NOT NULL DEFAULT 0",
        'agreed_terms' => "ALTER TABLE FSG_users ADD COLUMN agreed_terms TINYINT(1) NOT NULL DEFAULT 0",
        'agreed_privacy' => "ALTER TABLE FSG_users ADD COLUMN agreed_privacy TINYINT(1) NOT NULL DEFAULT 0",
        'is_active' => "ALTER TABLE FSG_users ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1",
        'is_admin' => "ALTER TABLE FSG_users ADD COLUMN is_admin TINYINT(1) NOT NULL DEFAULT 0",
        'banned_until' => "ALTER TABLE FSG_users ADD COLUMN banned_until DATETIME NULL DEFAULT NULL",
        'created_at' => "ALTER TABLE FSG_users ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP",
        'updated_at' => "ALTER TABLE FSG_users ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
    ];
    foreach ($userColumns as $columnName => $alterSql) {
        try {
            $check = $pdo->query("SHOW COLUMNS FROM FSG_users LIKE " . $pdo->quote($columnName));
            if ($check && $check->rowCount() === 0) $pdo->exec($alterSql);
        } catch (Throwable $e) {}
    }

    $userType = fsgAuth_sharedFsgUserIdSqlType($pdo);

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_user_identity_history (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$userType} NOT NULL,
        field_name ENUM('username','email','password') NOT NULL,
        old_value VARCHAR(255) NOT NULL DEFAULT '',
        new_value VARCHAR(255) NOT NULL DEFAULT '',
        changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_FSG_user_identity_history_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_auth_sessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$userType} NOT NULL,
        token_hash CHAR(64) NOT NULL,
        browser_label VARCHAR(128) NOT NULL DEFAULT '',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME NOT NULL,
        last_seen_at DATETIME NULL DEFAULT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_auth_sessions_token_hash (token_hash),
        KEY idx_FSG_auth_sessions_user_seen (user_id, last_seen_at),
        KEY idx_FSG_auth_sessions_expires (expires_at),
        KEY idx_FSG_auth_sessions_active (user_id, is_active, expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    foreach ([
        'browser_label' => "ALTER TABLE FSG_auth_sessions ADD COLUMN browser_label VARCHAR(128) NOT NULL DEFAULT '' AFTER token_hash",
        'is_active' => "ALTER TABLE FSG_auth_sessions ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER last_seen_at"
    ] as $columnName => $alterSql) {
        try {
            $check = $pdo->query("SHOW COLUMNS FROM FSG_auth_sessions LIKE " . $pdo->quote($columnName));
            if ($check && $check->rowCount() === 0) $pdo->exec($alterSql);
        } catch (Throwable $e) {}
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Server_Sessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$userType} NOT NULL,
        app_key VARCHAR(64) NOT NULL DEFAULT 'DialogueDesigner',
        session_id VARCHAR(96) NOT NULL,
        first_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        first_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_viewed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        workspace_count INT UNSIGNED NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Server_Sessions_user_app_session (user_id, app_key, session_id),
        KEY idx_FSG_Server_Sessions_user_viewed (user_id, last_viewed_at),
        KEY idx_FSG_Server_Sessions_session (session_id),
        KEY idx_FSG_Server_Sessions_app_user (app_key, user_id, last_viewed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_DD_UserSessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id {$userType} NOT NULL,
        session_id VARCHAR(96) NOT NULL,
        first_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_pushed_at TIMESTAMP NULL DEFAULT NULL,
        last_viewed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        workspace_count INT UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_DD_UserSessions_session (session_id),
        KEY idx_FSG_DD_UserSessions_user_viewed (user_id, last_viewed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    try { $pdo->prepare('DELETE FROM FSG_auth_sessions WHERE expires_at < UTC_TIMESTAMP() OR is_active = 0')->execute(); } catch (Throwable $e) {}
}

function fsgAuth_currentUserId(): int
{
    if (isset($_SESSION['fsg_user_id'])) return (int)$_SESSION['fsg_user_id'];
    if (isset($_SESSION['dd_user_id'])) return (int)$_SESSION['dd_user_id'];
    if (isset($_SESSION['user_id'])) return (int)$_SESSION['user_id'];
    return 0;
}

function fsgAuth_setCurrentUserSession(int $userId, string $username): void
{
    fsgAuth_startSharedSession();
    $_SESSION['fsg_user_id'] = $userId;
    $_SESSION['fsg_username'] = $username;
    $_SESSION['dd_user_id'] = $userId;
    $_SESSION['dd_username'] = $username;
    $_SESSION['user_id'] = $userId;
    $_SESSION['username'] = $username;
    $_SESSION['fsg_last_seen_at'] = time();
}

function fsgAuth_clearCurrentUserSession(): void
{
    unset($_SESSION['fsg_user_id'], $_SESSION['fsg_username'], $_SESSION['dd_user_id'], $_SESSION['dd_username'], $_SESSION['user_id'], $_SESSION['username'], $_SESSION['guest_name']);
}

function fsgAuth_issueAuthToken(PDO $pdo, int $userId, string $browserLabel = ''): string
{
    $token = bin2hex(random_bytes(32));
    $hash = fsgAuth_tokenHash($token);
    $expiresSql = gmdate('Y-m-d H:i:s', time() + fsgAuth_tokenLifetimeSeconds());
    $pdo->prepare('DELETE FROM FSG_auth_sessions WHERE expires_at < UTC_TIMESTAMP() OR is_active = 0')->execute();
    $stmt = $pdo->prepare('INSERT INTO FSG_auth_sessions (user_id, token_hash, browser_label, expires_at, last_seen_at, is_active) VALUES (?, ?, ?, ?, UTC_TIMESTAMP(), 1)');
    $stmt->execute([$userId, $hash, mb_substr($browserLabel, 0, 128), $expiresSql]);
    fsgAuth_setBearerCookie($token);
    return $token;
}

function fsgAuth_userIdFromBearerToken(PDO $pdo): int
{
    $token = fsgAuth_extractBearerToken();
    if ($token === '') return 0;
    $hash = fsgAuth_tokenHash($token);
    $stmt = $pdo->prepare('SELECT s.user_id, u.username FROM FSG_auth_sessions s JOIN FSG_users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > UTC_TIMESTAMP() AND s.is_active = 1 AND u.is_active = 1 LIMIT 1');
    $stmt->execute([$hash]);
    $row = $stmt->fetch();
    if (!$row) return 0;

    $userId = (int)$row['user_id'];
    $username = (string)$row['username'];
    $expiresSql = gmdate('Y-m-d H:i:s', time() + fsgAuth_tokenLifetimeSeconds());
    $upd = $pdo->prepare('UPDATE FSG_auth_sessions SET expires_at = ?, last_seen_at = UTC_TIMESTAMP(), is_active = 1 WHERE token_hash = ?');
    $upd->execute([$expiresSql, $hash]);
    fsgAuth_setBearerCookie($token);
    fsgAuth_setCurrentUserSession($userId, $username);
    return $userId;
}

function fsgAuth_currentUserIdFromRequest(PDO $pdo): int
{
    fsgAuth_startSharedSession();
    $sessionUserId = fsgAuth_currentUserId();
    if ($sessionUserId > 0 && fsgAuth_getUserById($pdo, $sessionUserId)) return $sessionUserId;
    return fsgAuth_userIdFromBearerToken($pdo);
}

function fsgAuth_passwordMeetsPolicy(string $password): bool
{
    return (bool)preg_match('/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z0-9]).{8,}/', $password);
}

function fsgAuth_normalizeUsername(string $username): string { return trim($username); }
function fsgAuth_normalizeEmail(string $email): string { return strtolower(trim($email)); }

function fsgAuth_activeIdentityExists(PDO $pdo, string $username, string $email, int $excludeUserId = 0): bool
{
    $sql = 'SELECT id FROM FSG_users WHERE is_active = 1 AND (LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?))';
    $params = [$username, $email];
    if ($excludeUserId > 0) { $sql .= ' AND id != ?'; $params[] = $excludeUserId; }
    $sql .= ' LIMIT 1';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (bool)$stmt->fetch();
}

function fsgAuth_getUserById(PDO $pdo, int $userId): ?array
{
    if ($userId <= 0) return null;
    $stmt = $pdo->prepare('SELECT id, username, email, created_at FROM FSG_users WHERE id = ? AND is_active = 1 LIMIT 1');
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    return $row ?: null;
}


function fsgAuth_identifierIsSafe(string $identifier): bool
{
    return $identifier !== '' && (bool)preg_match('/^[A-Za-z0-9_]+$/', $identifier);
}

function fsgAuth_quoteIdentifier(string $identifier): string
{
    if (!fsgAuth_identifierIsSafe($identifier)) {
        throw new RuntimeException('Unsafe SQL identifier: ' . $identifier);
    }
    return '`' . str_replace('`', '``', $identifier) . '`';
}

function fsgAuth_tableExists(PDO $pdo, string $tableName): bool
{
    $tableName = trim($tableName);
    if (!fsgAuth_identifierIsSafe($tableName)) return false;
    try {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?');
        $stmt->execute([$tableName]);
        if ((int)$stmt->fetchColumn() > 0) return true;
    } catch (Throwable $e) {}
    try {
        $stmt = $pdo->query('SHOW TABLES');
        foreach (($stmt ? $stmt->fetchAll(PDO::FETCH_NUM) : []) as $row) {
            if (strcasecmp((string)($row[0] ?? ''), $tableName) === 0) return true;
        }
    } catch (Throwable $e) {}
    try {
        $pdo->query('SHOW COLUMNS FROM ' . fsgAuth_quoteIdentifier($tableName));
        return true;
    } catch (Throwable $e) {}
    return false;
}

function fsgAuth_columnExists(PDO $pdo, string $tableName, string $columnName): bool
{
    $tableName = trim($tableName);
    $columnName = trim($columnName);
    if (!fsgAuth_identifierIsSafe($tableName) || !fsgAuth_identifierIsSafe($columnName)) return false;
    try {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?');
        $stmt->execute([$tableName, $columnName]);
        if ((int)$stmt->fetchColumn() > 0) return true;
    } catch (Throwable $e) {}
    try {
        $stmt = $pdo->query('SHOW COLUMNS FROM ' . fsgAuth_quoteIdentifier($tableName));
        foreach (($stmt ? $stmt->fetchAll() : []) as $row) {
            if (strcasecmp((string)($row['Field'] ?? ''), $columnName) === 0) return true;
        }
    } catch (Throwable $e) {}
    return false;
}

function fsgAuth_serverSessionColumns(PDO $pdo): array
{
    $cols = [
        'app' => '',
        'first' => '',
        'firstPushed' => '',
        'lastPushed' => '',
        'lastViewed' => '',
        'workspaceCount' => '',
        'isActive' => '',
    ];
    if (!fsgAuth_tableExists($pdo, 'FSG_Server_Sessions')) return $cols;
    $cols['app'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'app_key') ? 'app_key' : (fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'app_name') ? 'app_name' : '');
    $cols['first'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'first_seen_at') ? 'first_seen_at' : (fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'first_used_at') ? 'first_used_at' : '');
    $cols['firstPushed'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'first_pushed_at') ? 'first_pushed_at' : '';
    $cols['lastPushed'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'last_pushed_at') ? 'last_pushed_at' : '';
    $cols['lastViewed'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'last_viewed_at') ? 'last_viewed_at' : '';
    $cols['workspaceCount'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'workspace_count') ? 'workspace_count' : '';
    $cols['isActive'] = fsgAuth_columnExists($pdo, 'FSG_Server_Sessions', 'is_active') ? 'is_active' : '';
    return $cols;
}

function fsgAuth_serverSessionTimeExpr(array $cols): string
{
    $parts = [];
    if ($cols['lastViewed'] !== '') $parts[] = $cols['lastViewed'];
    if ($cols['lastPushed'] !== '') $parts[] = $cols['lastPushed'];
    if ($cols['firstPushed'] !== '') $parts[] = $cols['firstPushed'];
    if ($cols['first'] !== '') $parts[] = $cols['first'];
    return $parts ? 'COALESCE(' . implode(', ', $parts) . ')' : 'id';
}

function fsgAuth_touchServerSession(PDO $pdo, int $userId, string $appKey, string $sessionId, string $mode = 'view'): void
{
    $sessionId = trim($sessionId);
    $appKey = trim($appKey) ?: 'DialogueDesigner';
    if ($userId <= 0 || $sessionId === '') return;

    if (!$pdo->inTransaction()) {
        fsgAuth_ensureAccountTables($pdo);
    }

    $cols = fsgAuth_serverSessionColumns($pdo);
    if ($cols['app'] === '') return;

    $isPush = $mode === 'push';
    $insertCols = ['user_id', $cols['app'], 'session_id'];
    $valuesSql = ['?', '?', '?'];
    $params = [$userId, $appKey, $sessionId];

    if ($cols['firstPushed'] !== '') { $insertCols[] = $cols['firstPushed']; $valuesSql[] = $isPush ? 'CURRENT_TIMESTAMP' : 'NULL'; }
    if ($cols['lastPushed'] !== '') { $insertCols[] = $cols['lastPushed']; $valuesSql[] = $isPush ? 'CURRENT_TIMESTAMP' : 'NULL'; }
    if ($cols['lastViewed'] !== '') { $insertCols[] = $cols['lastViewed']; $valuesSql[] = 'CURRENT_TIMESTAMP'; }
    if ($cols['workspaceCount'] !== '') { $insertCols[] = $cols['workspaceCount']; $valuesSql[] = $isPush ? '1' : '0'; }
    if ($cols['isActive'] !== '') { $insertCols[] = $cols['isActive']; $valuesSql[] = '1'; }

    $updates = [];
    if ($cols['lastViewed'] !== '') $updates[] = "{$cols['lastViewed']} = CURRENT_TIMESTAMP";
    if ($cols['lastPushed'] !== '') $updates[] = "{$cols['lastPushed']} = IF(VALUES({$cols['lastPushed']}) IS NULL, {$cols['lastPushed']}, VALUES({$cols['lastPushed']}))";
    if ($cols['firstPushed'] !== '') $updates[] = "{$cols['firstPushed']} = IF({$cols['firstPushed']} IS NULL, VALUES({$cols['firstPushed']}), {$cols['firstPushed']})";
    if ($cols['workspaceCount'] !== '') $updates[] = "{$cols['workspaceCount']} = {$cols['workspaceCount']} + " . ($isPush ? '1' : '0');
    if ($cols['isActive'] !== '') $updates[] = "{$cols['isActive']} = 1";

    $sql = "INSERT INTO FSG_Server_Sessions (`" . implode('`,`', $insertCols) . "`) VALUES (" . implode(',', $valuesSql) . ")";
    if ($updates) $sql .= " ON DUPLICATE KEY UPDATE " . implode(', ', $updates);

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
}

function fsgAuth_listUserSessions(PDO $pdo, int $userId, string $appKey = 'DialogueDesigner'): array
{
    if ($userId <= 0) return [];
    if (!$pdo->inTransaction()) {
        fsgAuth_ensureAccountTables($pdo);
    }

    $sessionsById = [];
    $normalizedAppKey = strtolower(str_replace(' ', '', $appKey));

    try {
        $cols = fsgAuth_serverSessionColumns($pdo);
        if ($cols['app'] !== '') {
            $timeExpr = fsgAuth_serverSessionTimeExpr($cols);
            $whereActive = $cols['isActive'] !== '' ? " AND {$cols['isActive']} = 1" : '';
            $firstExpr = $cols['firstPushed'] !== '' ? $cols['firstPushed'] : ($cols['first'] !== '' ? $cols['first'] : 'NULL');
            $lastPushExpr = $cols['lastPushed'] !== '' ? $cols['lastPushed'] : 'NULL';
            $lastViewExpr = $cols['lastViewed'] !== '' ? $cols['lastViewed'] : ($cols['first'] !== '' ? $cols['first'] : 'NULL');
            $countExpr = $cols['workspaceCount'] !== '' ? $cols['workspaceCount'] : '0';
            $stmt = $pdo->prepare("SELECT session_id, {$cols['app']} AS app_key, {$firstExpr} AS first_pushed_at, {$lastPushExpr} AS last_pushed_at, {$lastViewExpr} AS last_viewed_at, {$countExpr} AS workspace_count FROM FSG_Server_Sessions WHERE user_id = ? AND REPLACE(LOWER({$cols['app']}), ' ', '') = ?{$whereActive} ORDER BY {$timeExpr} DESC, id DESC");
            $stmt->execute([$userId, $normalizedAppKey]);
            foreach ($stmt->fetchAll() as $row) {
                $sid = trim((string)($row['session_id'] ?? ''));
                if ($sid !== '') $sessionsById[$sid] = $row;
            }
        }
    } catch (Throwable $e) {}

    if ($normalizedAppKey === 'dialoguedesigner') {
        try {
            if (fsgAuth_tableExists($pdo, 'FSG_DD_UserSessions')) {
                $stmt = $pdo->prepare('SELECT session_id, first_pushed_at, last_pushed_at, last_viewed_at, workspace_count FROM FSG_DD_UserSessions WHERE user_id = ? ORDER BY last_viewed_at DESC, last_pushed_at DESC, id DESC');
                $stmt->execute([$userId]);
                foreach ($stmt->fetchAll() as $row) {
                    $sid = trim((string)($row['session_id'] ?? ''));
                    if ($sid === '') continue;
                    if (!isset($sessionsById[$sid])) $sessionsById[$sid] = ['app_key' => 'DialogueDesigner'] + $row;
                }
            }
        } catch (Throwable $e) {}

        try {
            if (fsgAuth_tableExists($pdo, 'FSG_DD_Workspaces')) {
                $createdCol = fsgAuth_columnExists($pdo, 'FSG_DD_Workspaces', 'created_at') ? 'created_at' : (fsgAuth_columnExists($pdo, 'FSG_DD_Workspaces', 'updated_at') ? 'updated_at' : 'id');
                $updatedCol = fsgAuth_columnExists($pdo, 'FSG_DD_Workspaces', 'updated_at') ? 'updated_at' : $createdCol;
                $stmt = $pdo->prepare("SELECT session_id, MIN({$createdCol}) AS first_pushed_at, MAX({$updatedCol}) AS last_pushed_at, MAX({$updatedCol}) AS last_viewed_at, COUNT(*) AS workspace_count FROM FSG_DD_Workspaces WHERE user_id = ? AND session_id <> '' GROUP BY session_id ORDER BY last_viewed_at DESC");
                $stmt->execute([$userId]);
                foreach ($stmt->fetchAll() as $row) {
                    $sid = trim((string)($row['session_id'] ?? ''));
                    if ($sid === '') continue;
                    if (!isset($sessionsById[$sid])) $sessionsById[$sid] = ['app_key' => 'DialogueDesigner'] + $row;
                }
            }
        } catch (Throwable $e) {}
    }

    if ($normalizedAppKey === 'taskmanager') {
        try {
            if (fsgAuth_tableExists($pdo, 'FSG_TASK_server_sessions')) {
                $stmt = $pdo->prepare("SELECT session_id, created_at AS first_pushed_at, updated_at AS last_pushed_at, updated_at AS last_viewed_at, 1 AS workspace_count FROM FSG_TASK_server_sessions WHERE user_id = ? ORDER BY updated_at DESC");
                $stmt->execute([$userId]);
                foreach ($stmt->fetchAll() as $row) {
                    $sid = trim((string)($row['session_id'] ?? ''));
                    if ($sid === '') continue;
                    if (!isset($sessionsById[$sid])) $sessionsById[$sid] = ['app_key' => 'TaskManager'] + $row;
                }
            }
        } catch (Throwable $e) {}
    }

    if ($normalizedAppKey === 'promptdesigner') {
        try {
            if (fsgAuth_tableExists($pdo, 'FSG_PD_server_sessions')) {
                $stmt = $pdo->prepare("SELECT session_id, created_at AS first_pushed_at, updated_at AS last_pushed_at, updated_at AS last_viewed_at, 1 AS workspace_count FROM FSG_PD_server_sessions WHERE user_id = ? ORDER BY updated_at DESC");
                $stmt->execute([$userId]);
                foreach ($stmt->fetchAll() as $row) {
                    $sid = trim((string)($row['session_id'] ?? ''));
                    if ($sid === '') continue;
                    if (!isset($sessionsById[$sid])) $sessionsById[$sid] = ['app_key' => 'PromptDesigner'] + $row;
                }
            }
        } catch (Throwable $e) {}
    }

    if ($normalizedAppKey === 'narrativeflow') {
        try {
            if (fsgAuth_tableExists($pdo, 'FSG_NF_server_sessions')) {
                $stmt = $pdo->prepare("SELECT session_id, created_at AS first_pushed_at, updated_at AS last_pushed_at, updated_at AS last_viewed_at, 1 AS workspace_count FROM FSG_NF_server_sessions WHERE user_id = ? ORDER BY updated_at DESC");
                $stmt->execute([$userId]);
                foreach ($stmt->fetchAll() as $row) {
                    $sid = trim((string)($row['session_id'] ?? ''));
                    if ($sid === '') continue;
                    if (!isset($sessionsById[$sid])) $sessionsById[$sid] = ['app_key' => 'NarrativeFlow'] + $row;
                }
            }
        } catch (Throwable $e) {}
    }

    $sessions = array_values($sessionsById);
    usort($sessions, function($a, $b) {
        $aTime = strtotime((string)($a['last_viewed_at'] ?? $a['last_pushed_at'] ?? $a['first_pushed_at'] ?? '')) ?: 0;
        $bTime = strtotime((string)($b['last_viewed_at'] ?? $b['last_pushed_at'] ?? $b['first_pushed_at'] ?? '')) ?: 0;
        return $bTime <=> $aTime;
    });
    return $sessions;
}

function fsgAuth_authPayload(PDO $pdo): array
{
    $userId = fsgAuth_currentUserIdFromRequest($pdo);
    $user = fsgAuth_getUserById($pdo, $userId);
    if (!$user) {
        fsgAuth_clearCurrentUserSession();
        return ['loggedIn' => false, 'user' => null, 'sessions' => [], 'authExpiresAt' => ''];
    }
    fsgAuth_setCurrentUserSession((int)$user['id'], (string)$user['username']);
    return [
        'loggedIn' => true,
        'user' => [
            'id' => (int)$user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'createdAt' => $user['created_at'],
        ],
        'sessions' => fsgAuth_listUserSessions($pdo, (int)$user['id'], 'DialogueDesigner'),
        'authExpiresAt' => gmdate('c', time() + fsgAuth_tokenLifetimeSeconds()),
    ];
}

function fsgAuth_registerAccount(PDO $pdo, array $body): array
{
    $username = fsgAuth_normalizeUsername(fsgAuth_textValue($body['username'] ?? ''));
    $email = fsgAuth_normalizeEmail(fsgAuth_textValue($body['email'] ?? ''));
    $password = fsgAuth_textValue($body['password'] ?? '');
    $passwordConfirm = fsgAuth_textValue($body['passwordConfirm'] ?? $body['passwordVerify'] ?? '');
    $over18 = fsgAuth_boolValue($body['over18'] ?? false);
    $terms = fsgAuth_boolValue($body['terms'] ?? false);
    $privacy = fsgAuth_boolValue($body['privacy'] ?? false);
    if ($username === '' || $email === '') fsgAuth_respondJson(['ok' => false, 'error' => 'Username and email are required.'], 400);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fsgAuth_respondJson(['ok' => false, 'error' => 'Enter a valid email address.'], 400);
    if (!$over18 || !$terms || !$privacy) fsgAuth_respondJson(['ok' => false, 'error' => 'You must confirm 18+ and agree to the Terms of Service and Privacy Policy.'], 400);
    if ($password !== $passwordConfirm) fsgAuth_respondJson(['ok' => false, 'error' => 'Passwords do not match.'], 400);
    if (!fsgAuth_passwordMeetsPolicy($password)) fsgAuth_respondJson(['ok' => false, 'error' => 'Password must be at least 8 characters with 1 uppercase, 1 lowercase, 1 number, and 1 special character.'], 400);
    if (fsgAuth_activeIdentityExists($pdo, $username, $email)) fsgAuth_respondJson(['ok' => false, 'error' => 'Username or email is already active.'], 409);
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO FSG_users (username, email, password, is_over_18, agreed_terms, agreed_privacy, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)');
    $stmt->execute([$username, $email, $hash, $over18, $terms, $privacy]);
    $userId = (int)$pdo->lastInsertId();
    fsgAuth_setCurrentUserSession($userId, $username);
    $payload = fsgAuth_authPayload($pdo);
    $payload['authToken'] = fsgAuth_issueAuthToken($pdo, $userId, fsgAuth_textValue($body['browserLabel'] ?? ''));
    return $payload;
}

function fsgAuth_loginAccount(PDO $pdo, array $body): array
{
    $identity = trim(fsgAuth_textValue($body['identity'] ?? ''));
    $password = fsgAuth_textValue($body['password'] ?? '');
    if ($identity === '' || $password === '') fsgAuth_respondJson(['ok' => false, 'error' => 'Username/email and password are required.'], 400);
    $stmt = $pdo->prepare('SELECT id, username, password FROM FSG_users WHERE is_active = 1 AND (LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)) LIMIT 1');
    $stmt->execute([$identity, $identity]);
    $row = $stmt->fetch();
    if (!$row || !password_verify($password, $row['password'])) fsgAuth_respondJson(['ok' => false, 'error' => 'Invalid credentials.'], 401);
    $userId = (int)$row['id'];
    fsgAuth_setCurrentUserSession($userId, (string)$row['username']);
    $payload = fsgAuth_authPayload($pdo);
    $payload['authToken'] = fsgAuth_issueAuthToken($pdo, $userId, fsgAuth_textValue($body['browserLabel'] ?? ''));
    return $payload;
}

function fsgAuth_updateProfile(PDO $pdo, array $body): array
{
    $userId = fsgAuth_currentUserIdFromRequest($pdo);
    $user = fsgAuth_getUserById($pdo, $userId);
    if (!$user) fsgAuth_respondJson(['ok' => false, 'error' => 'You are not logged in.'], 401);
    $username = fsgAuth_normalizeUsername(fsgAuth_textValue($body['username'] ?? ''));
    $email = fsgAuth_normalizeEmail(fsgAuth_textValue($body['email'] ?? ''));
    if ($username === '' || $email === '') fsgAuth_respondJson(['ok' => false, 'error' => 'Username and email are required.'], 400);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fsgAuth_respondJson(['ok' => false, 'error' => 'Enter a valid email address.'], 400);
    if (fsgAuth_activeIdentityExists($pdo, $username, $email, $userId)) fsgAuth_respondJson(['ok' => false, 'error' => 'Username or email is already active.'], 409);
    $pdo->beginTransaction();
    try {
        if ($username !== $user['username']) {
            $hist = $pdo->prepare("INSERT INTO FSG_user_identity_history (user_id, field_name, old_value, new_value) VALUES (?, 'username', ?, ?)");
            $hist->execute([$userId, $user['username'], $username]);
        }
        if ($email !== strtolower((string)$user['email'])) {
            $hist = $pdo->prepare("INSERT INTO FSG_user_identity_history (user_id, field_name, old_value, new_value) VALUES (?, 'email', ?, ?)");
            $hist->execute([$userId, $user['email'], $email]);
        }
        $stmt = $pdo->prepare('UPDATE FSG_users SET username = ?, email = ? WHERE id = ?');
        $stmt->execute([$username, $email, $userId]);
        fsgAuth_setCurrentUserSession($userId, $username);
        $pdo->commit();
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
    return fsgAuth_authPayload($pdo);
}

function fsgAuth_changePassword(PDO $pdo, array $body): array
{
    $userId = fsgAuth_currentUserIdFromRequest($pdo);
    if (!fsgAuth_getUserById($pdo, $userId)) fsgAuth_respondJson(['ok' => false, 'error' => 'You are not logged in.'], 401);
    $password = fsgAuth_textValue($body['password'] ?? '');
    $passwordConfirm = fsgAuth_textValue($body['passwordConfirm'] ?? $body['passwordVerify'] ?? '');
    if ($password !== $passwordConfirm) fsgAuth_respondJson(['ok' => false, 'error' => 'Passwords do not match.'], 400);
    if (!fsgAuth_passwordMeetsPolicy($password)) fsgAuth_respondJson(['ok' => false, 'error' => 'Password must be at least 8 characters with 1 uppercase, 1 lowercase, 1 number, and 1 special character.'], 400);
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('UPDATE FSG_users SET password = ? WHERE id = ?');
        $stmt->execute([$hash, $userId]);
        $hist = $pdo->prepare("INSERT INTO FSG_user_identity_history (user_id, field_name, old_value, new_value) VALUES (?, 'password', '[password changed]', '[password changed]')");
        $hist->execute([$userId]);
        $pdo->commit();
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
    return fsgAuth_authPayload($pdo);
}

function fsgAuth_generateUniqueSessionId(PDO $pdo): string
{
    for ($attempt = 0; $attempt < 25; $attempt++) {
        $bytes = strtoupper(bin2hex(random_bytes(8)));
        $sessionId = 'DD-' . substr($bytes, 0, 6) . '-' . substr($bytes, 6, 10);
        foreach (['FSG_DD_Workspaces', 'FSG_DD_UserSessions', 'FSG_Server_Sessions', 'FSG_PD_server_sessions', 'FSG_NF_server_sessions', 'FSG_NF_workspaces'] as $table) {
            try {
                $stmt = $pdo->prepare("SELECT session_id FROM {$table} WHERE session_id = ? LIMIT 1");
                $stmt->execute([$sessionId]);
                if ($stmt->fetch()) continue 2;
            } catch (Throwable $e) {}
        }
        return $sessionId;
    }
    return 'DD-' . strtoupper(bin2hex(random_bytes(4))) . '-' . strtoupper(bin2hex(random_bytes(5)));
}

function fsgAuth_logout(?PDO $pdo = null): void
{
    if ($pdo) {
        $token = fsgAuth_extractBearerToken();
        if ($token !== '') {
            $stmt = $pdo->prepare('UPDATE FSG_auth_sessions SET is_active = 0, expires_at = UTC_TIMESTAMP() WHERE token_hash = ?');
            $stmt->execute([fsgAuth_tokenHash($token)]);
        }
    }
    fsgAuth_clearCurrentUserSession();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'] ?? '/', $params['domain'] ?? '', (bool)($params['secure'] ?? false), (bool)($params['httponly'] ?? true));
    }
    fsgAuth_clearBearerCookie();
    if (session_status() === PHP_SESSION_ACTIVE) session_destroy();
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Content-Type-Options: nosniff');


function rlDefaultContentJson(): string
{
    return <<<'RUNELITE_DEFAULT_CONTENT'
{
  "meta": {
    "gameId": "runelite_primitive_realm",
    "name": "RuneLite: Primitive Realm",
    "schemaVersion": 8,
    "contentVersion": 4,
    "tablePrefix": "FSG_Runelite_",
    "mapSize": 34000,
    "serverAuthoritativePersistence": true
  },
  "settings": {
    "inventorySlots": 28,
    "maxBankSlots": 800,
    "walkSpeed": 90,
    "runSpeed": 155,
    "enemyRespawnSeconds": 22,
    "resourceRespawnSeconds": 15,
    "autosaveSeconds": 25,
    "aggroLeash": 320,
    "guardAssistRadius": 300,
    "dayLengthMinutes": 24,
    "houseRoofIndoorOpacity": 0.14,
    "fountainRegenSeconds": 600,
    "fountainRegenPerSecond": 1
  },
  "skills": {
    "attack": {
      "id": "attack",
      "name": "Attack",
      "icon": "⚔️"
    },
    "strength": {
      "id": "strength",
      "name": "Strength",
      "icon": "💪"
    },
    "defence": {
      "id": "defence",
      "name": "Defence",
      "icon": "🛡️"
    },
    "ranged": {
      "id": "ranged",
      "name": "Ranged",
      "icon": "🏹"
    },
    "magic": {
      "id": "magic",
      "name": "Magic",
      "icon": "✨"
    },
    "prayer": {
      "id": "prayer",
      "name": "Prayer",
      "icon": "🙏"
    },
    "hitpoints": {
      "id": "hitpoints",
      "name": "Hitpoints",
      "icon": "❤️"
    },
    "woodcutting": {
      "id": "woodcutting",
      "name": "Woodcutting",
      "icon": "🪓"
    },
    "firemaking": {
      "id": "firemaking",
      "name": "Firemaking",
      "icon": "🔥"
    },
    "fishing": {
      "id": "fishing",
      "name": "Fishing",
      "icon": "🎣"
    },
    "cooking": {
      "id": "cooking",
      "name": "Cooking",
      "icon": "🍳"
    },
    "mining": {
      "id": "mining",
      "name": "Mining",
      "icon": "⛏️"
    },
    "smithing": {
      "id": "smithing",
      "name": "Smithing",
      "icon": "⚒️"
    },
    "farming": {
      "id": "farming",
      "name": "Farming",
      "icon": "🌱"
    },
    "thieving": {
      "id": "thieving",
      "name": "Thieving",
      "icon": "🕵️"
    },
    "crafting": {
      "id": "crafting",
      "name": "Crafting",
      "icon": "🧵"
    },
    "fletching": {
      "id": "fletching",
      "name": "Fletching",
      "icon": "🏹"
    },
    "slayer": {
      "id": "slayer",
      "name": "Slayer",
      "icon": "☠️"
    }
  },
  "items": {
    "coins": {
      "id": "coins",
      "name": "Coins",
      "icon": "🟡",
      "type": "currency",
      "value": 1,
      "stackable": true
    },
    "bones": {
      "id": "bones",
      "name": "Bones",
      "icon": "🦴",
      "type": "resource",
      "value": 2,
      "stackable": false,
      "action": "Bury",
      "prayerXp": 5
    },
    "big_bones": {
      "id": "big_bones",
      "name": "Big Bones",
      "icon": "🦴",
      "type": "resource",
      "value": 16,
      "stackable": false,
      "action": "Bury",
      "prayerXp": 15
    },
    "dragon_bones": {
      "id": "dragon_bones",
      "name": "Dragon Bones",
      "icon": "☠️",
      "type": "resource",
      "value": 150,
      "stackable": false,
      "action": "Bury",
      "prayerXp": 72
    },
    "bucket": {
      "id": "bucket",
      "name": "Bucket",
      "icon": "🪣",
      "type": "tool",
      "value": 5,
      "stackable": false
    },
    "milk": {
      "id": "milk",
      "name": "Bucket of Milk",
      "icon": "🥛",
      "type": "resource",
      "value": 15,
      "stackable": false
    },
    "tinderbox": {
      "id": "tinderbox",
      "name": "Tinderbox",
      "icon": "🔥",
      "type": "tool",
      "value": 10,
      "stackable": false
    },
    "small_fishing_net": {
      "id": "small_fishing_net",
      "name": "Small Fishing Net",
      "icon": "🕸️",
      "type": "tool",
      "value": 15,
      "stackable": false
    },
    "fishing_rod": {
      "id": "fishing_rod",
      "name": "Fishing Rod",
      "icon": "🎣",
      "type": "tool",
      "value": 30,
      "stackable": false
    },
    "needle": {
      "id": "needle",
      "name": "Needle",
      "icon": "🪡",
      "type": "tool",
      "value": 5,
      "stackable": false
    },
    "thread": {
      "id": "thread",
      "name": "Thread",
      "icon": "🧵",
      "type": "resource",
      "value": 2,
      "stackable": true
    },
    "knife": {
      "id": "knife",
      "name": "Knife",
      "icon": "🔪",
      "type": "tool",
      "value": 8,
      "stackable": false
    },
    "hammer": {
      "id": "hammer",
      "name": "Hammer",
      "icon": "🔨",
      "type": "tool",
      "value": 10,
      "stackable": false
    },
    "chisel": {
      "id": "chisel",
      "name": "Chisel",
      "icon": "🔧",
      "type": "tool",
      "value": 10,
      "stackable": false
    },
    "shears": {
      "id": "shears",
      "name": "Shears",
      "icon": "✂️",
      "type": "tool",
      "value": 10,
      "stackable": false
    },
    "rope": {
      "id": "rope",
      "name": "Rope",
      "icon": "🪢",
      "type": "tool",
      "value": 20,
      "stackable": false
    },
    "sewer_key": {
      "id": "sewer_key",
      "name": "Sewer Key",
      "icon": "🗝️",
      "type": "quest",
      "value": 0,
      "stackable": false
    },
    "warehouse_key": {
      "id": "warehouse_key",
      "name": "Warehouse Key",
      "icon": "🔑",
      "type": "quest",
      "value": 0,
      "stackable": false
    },
    "normal_logs": {
      "id": "normal_logs",
      "name": "Normal Logs",
      "icon": "🪵",
      "type": "resource",
      "value": 8,
      "stackable": false
    },
    "oak_logs": {
      "id": "oak_logs",
      "name": "Oak Logs",
      "icon": "🪵",
      "type": "resource",
      "value": 18,
      "stackable": false
    },
    "willow_logs": {
      "id": "willow_logs",
      "name": "Willow Logs",
      "icon": "🪵",
      "type": "resource",
      "value": 35,
      "stackable": false
    },
    "maple_logs": {
      "id": "maple_logs",
      "name": "Maple Logs",
      "icon": "🪵",
      "type": "resource",
      "value": 65,
      "stackable": false
    },
    "yew_logs": {
      "id": "yew_logs",
      "name": "Yew Logs",
      "icon": "🪵",
      "type": "resource",
      "value": 120,
      "stackable": false
    },
    "normal_unstrung_bow": {
      "id": "normal_unstrung_bow",
      "name": "Normal Unstrung Bow",
      "icon": "🏹",
      "type": "resource",
      "value": 15,
      "stackable": false
    },
    "oak_unstrung_bow": {
      "id": "oak_unstrung_bow",
      "name": "Oak Unstrung Bow",
      "icon": "🏹",
      "type": "resource",
      "value": 30,
      "stackable": false
    },
    "willow_unstrung_bow": {
      "id": "willow_unstrung_bow",
      "name": "Willow Unstrung Bow",
      "icon": "🏹",
      "type": "resource",
      "value": 55,
      "stackable": false
    },
    "maple_unstrung_bow": {
      "id": "maple_unstrung_bow",
      "name": "Maple Unstrung Bow",
      "icon": "🏹",
      "type": "resource",
      "value": 95,
      "stackable": false
    },
    "yew_unstrung_bow": {
      "id": "yew_unstrung_bow",
      "name": "Yew Unstrung Bow",
      "icon": "🏹",
      "type": "resource",
      "value": 180,
      "stackable": false
    },
    "normal_shortbow": {
      "id": "normal_shortbow",
      "name": "Normal Shortbow",
      "icon": "🏹",
      "type": "weapon",
      "value": 30,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "ranged",
      "toolType": "bow",
      "tier": 1,
      "stats": {
        "ranged": 3,
        "rangedStrength": 2
      }
    },
    "oak_shortbow": {
      "id": "oak_shortbow",
      "name": "Oak Shortbow",
      "icon": "🏹",
      "type": "weapon",
      "value": 60,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "ranged",
      "toolType": "bow",
      "tier": 2,
      "stats": {
        "ranged": 7,
        "rangedStrength": 5
      }
    },
    "willow_shortbow": {
      "id": "willow_shortbow",
      "name": "Willow Shortbow",
      "icon": "🏹",
      "type": "weapon",
      "value": 105,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "ranged",
      "toolType": "bow",
      "tier": 3,
      "stats": {
        "ranged": 11,
        "rangedStrength": 8
      }
    },
    "maple_shortbow": {
      "id": "maple_shortbow",
      "name": "Maple Shortbow",
      "icon": "🏹",
      "type": "weapon",
      "value": 180,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "ranged",
      "toolType": "bow",
      "tier": 4,
      "stats": {
        "ranged": 15,
        "rangedStrength": 11
      }
    },
    "yew_shortbow": {
      "id": "yew_shortbow",
      "name": "Yew Shortbow",
      "icon": "🏹",
      "type": "weapon",
      "value": 320,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "ranged",
      "toolType": "bow",
      "tier": 5,
      "stats": {
        "ranged": 19,
        "rangedStrength": 14
      }
    },
    "normal_longbow": {
      "id": "normal_longbow",
      "name": "Normal Longbow",
      "icon": "🏹",
      "type": "weapon",
      "value": 42,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "ranged",
      "toolType": "bow",
      "tier": 1,
      "stats": {
        "ranged": 5,
        "rangedStrength": 3
      }
    },
    "oak_longbow": {
      "id": "oak_longbow",
      "name": "Oak Longbow",
      "icon": "🏹",
      "type": "weapon",
      "value": 80,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "ranged",
      "toolType": "bow",
      "tier": 2,
      "stats": {
        "ranged": 10,
        "rangedStrength": 7
      }
    },
    "willow_longbow": {
      "id": "willow_longbow",
      "name": "Willow Longbow",
      "icon": "🏹",
      "type": "weapon",
      "value": 140,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "ranged",
      "toolType": "bow",
      "tier": 3,
      "stats": {
        "ranged": 15,
        "rangedStrength": 11
      }
    },
    "maple_longbow": {
      "id": "maple_longbow",
      "name": "Maple Longbow",
      "icon": "🏹",
      "type": "weapon",
      "value": 240,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "ranged",
      "toolType": "bow",
      "tier": 4,
      "stats": {
        "ranged": 20,
        "rangedStrength": 15
      }
    },
    "yew_longbow": {
      "id": "yew_longbow",
      "name": "Yew Longbow",
      "icon": "🏹",
      "type": "weapon",
      "value": 420,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "ranged",
      "toolType": "bow",
      "tier": 5,
      "stats": {
        "ranged": 25,
        "rangedStrength": 19
      }
    },
    "arrow_shafts": {
      "id": "arrow_shafts",
      "name": "Arrow Shafts",
      "icon": "➖",
      "type": "resource",
      "value": 1,
      "stackable": true
    },
    "headless_arrows": {
      "id": "headless_arrows",
      "name": "Headless Arrows",
      "icon": "➶",
      "type": "resource",
      "value": 2,
      "stackable": true
    },
    "feather": {
      "id": "feather",
      "name": "Feather",
      "icon": "🪶",
      "type": "resource",
      "value": 2,
      "stackable": true
    },
    "bronze_arrowtips": {
      "id": "bronze_arrowtips",
      "name": "Bronze Arrowtips",
      "icon": "🔺",
      "type": "resource",
      "value": 3,
      "stackable": true
    },
    "bronze_arrow": {
      "id": "bronze_arrow",
      "name": "Bronze Arrow",
      "icon": "🏹",
      "type": "ammo",
      "value": 3,
      "stackable": true,
      "slot": "ammo",
      "tier": 1,
      "stats": {
        "rangedStrength": 3
      }
    },
    "iron_arrowtips": {
      "id": "iron_arrowtips",
      "name": "Iron Arrowtips",
      "icon": "🔺",
      "type": "resource",
      "value": 6,
      "stackable": true
    },
    "iron_arrow": {
      "id": "iron_arrow",
      "name": "Iron Arrow",
      "icon": "🏹",
      "type": "ammo",
      "value": 6,
      "stackable": true,
      "slot": "ammo",
      "tier": 2,
      "stats": {
        "rangedStrength": 7
      }
    },
    "steel_arrowtips": {
      "id": "steel_arrowtips",
      "name": "Steel Arrowtips",
      "icon": "🔺",
      "type": "resource",
      "value": 9,
      "stackable": true
    },
    "steel_arrow": {
      "id": "steel_arrow",
      "name": "Steel Arrow",
      "icon": "🏹",
      "type": "ammo",
      "value": 9,
      "stackable": true,
      "slot": "ammo",
      "tier": 3,
      "stats": {
        "rangedStrength": 11
      }
    },
    "flax": {
      "id": "flax",
      "name": "Flax",
      "icon": "🌾",
      "type": "resource",
      "value": 5,
      "stackable": false
    },
    "bowstring": {
      "id": "bowstring",
      "name": "Bow String",
      "icon": "🧵",
      "type": "resource",
      "value": 12,
      "stackable": false
    },
    "wool": {
      "id": "wool",
      "name": "Wool",
      "icon": "☁️",
      "type": "resource",
      "value": 4,
      "stackable": false
    },
    "ball_of_wool": {
      "id": "ball_of_wool",
      "name": "Ball of Wool",
      "icon": "🧶",
      "type": "resource",
      "value": 9,
      "stackable": false
    },
    "copper_ore": {
      "id": "copper_ore",
      "name": "Copper Ore",
      "icon": "🟠",
      "type": "resource",
      "value": 12,
      "stackable": false
    },
    "tin_ore": {
      "id": "tin_ore",
      "name": "Tin Ore",
      "icon": "⚪",
      "type": "resource",
      "value": 12,
      "stackable": false
    },
    "iron_ore": {
      "id": "iron_ore",
      "name": "Iron Ore",
      "icon": "🟤",
      "type": "resource",
      "value": 25,
      "stackable": false
    },
    "coal_ore": {
      "id": "coal_ore",
      "name": "Coal Ore",
      "icon": "⚫",
      "type": "resource",
      "value": 40,
      "stackable": false
    },
    "silver_ore": {
      "id": "silver_ore",
      "name": "Silver Ore",
      "icon": "◻️",
      "type": "resource",
      "value": 55,
      "stackable": false
    },
    "gold_ore": {
      "id": "gold_ore",
      "name": "Gold Ore",
      "icon": "🟡",
      "type": "resource",
      "value": 80,
      "stackable": false
    },
    "bronze_bar": {
      "id": "bronze_bar",
      "name": "Bronze Bar",
      "icon": "▰",
      "type": "resource",
      "value": 30,
      "stackable": false
    },
    "iron_bar": {
      "id": "iron_bar",
      "name": "Iron Bar",
      "icon": "▰",
      "type": "resource",
      "value": 60,
      "stackable": false
    },
    "steel_bar": {
      "id": "steel_bar",
      "name": "Steel Bar",
      "icon": "▰",
      "type": "resource",
      "value": 110,
      "stackable": false
    },
    "silver_bar": {
      "id": "silver_bar",
      "name": "Silver Bar",
      "icon": "▰",
      "type": "resource",
      "value": 120,
      "stackable": false
    },
    "gold_bar": {
      "id": "gold_bar",
      "name": "Gold Bar",
      "icon": "▰",
      "type": "resource",
      "value": 180,
      "stackable": false
    },
    "cowhide": {
      "id": "cowhide",
      "name": "Cowhide",
      "icon": "🐄",
      "type": "resource",
      "value": 12,
      "stackable": false
    },
    "leather": {
      "id": "leather",
      "name": "Leather",
      "icon": "🟫",
      "type": "resource",
      "value": 20,
      "stackable": false
    },
    "hard_leather": {
      "id": "hard_leather",
      "name": "Hard Leather",
      "icon": "🟤",
      "type": "resource",
      "value": 45,
      "stackable": false
    },
    "silk": {
      "id": "silk",
      "name": "Silk",
      "icon": "🎀",
      "type": "resource",
      "value": 35,
      "stackable": false
    },
    "bear_fur": {
      "id": "bear_fur",
      "name": "Bear Fur",
      "icon": "🐻",
      "type": "resource",
      "value": 25,
      "stackable": false
    },
    "wolf_pelt": {
      "id": "wolf_pelt",
      "name": "Wolf Pelt",
      "icon": "🐺",
      "type": "resource",
      "value": 30,
      "stackable": false
    },
    "green_dragonhide": {
      "id": "green_dragonhide",
      "name": "Green Dragonhide",
      "icon": "🦎",
      "type": "resource",
      "value": 200,
      "stackable": false
    },
    "rat_tail": {
      "id": "rat_tail",
      "name": "Rat Tail",
      "icon": "〰️",
      "type": "resource",
      "value": 6,
      "stackable": false
    },
    "slime_core": {
      "id": "slime_core",
      "name": "Slime Core",
      "icon": "🟢",
      "type": "resource",
      "value": 42,
      "stackable": false
    },
    "cave_fang": {
      "id": "cave_fang",
      "name": "Cave Fang",
      "icon": "🦷",
      "type": "resource",
      "value": 38,
      "stackable": false
    },
    "dark_essence": {
      "id": "dark_essence",
      "name": "Dark Essence",
      "icon": "🟣",
      "type": "resource",
      "value": 140,
      "stackable": false
    },
    "golem_core": {
      "id": "golem_core",
      "name": "Golem Core",
      "icon": "🔘",
      "type": "resource",
      "value": 300,
      "stackable": false
    },
    "raw_shrimp": {
      "id": "raw_shrimp",
      "name": "Raw Shrimp",
      "icon": "🦐",
      "type": "food",
      "value": 6,
      "stackable": false
    },
    "cooked_shrimp": {
      "id": "cooked_shrimp",
      "name": "Cooked Shrimp",
      "icon": "🍤",
      "type": "food",
      "value": 12,
      "stackable": false,
      "action": "Eat",
      "heal": 4
    },
    "raw_trout": {
      "id": "raw_trout",
      "name": "Raw Trout",
      "icon": "🐟",
      "type": "food",
      "value": 15,
      "stackable": false
    },
    "cooked_trout": {
      "id": "cooked_trout",
      "name": "Cooked Trout",
      "icon": "🍣",
      "type": "food",
      "value": 30,
      "stackable": false,
      "action": "Eat",
      "heal": 8
    },
    "raw_beef": {
      "id": "raw_beef",
      "name": "Raw Beef",
      "icon": "🥩",
      "type": "food",
      "value": 10,
      "stackable": false
    },
    "cooked_beef": {
      "id": "cooked_beef",
      "name": "Cooked Meat",
      "icon": "🍖",
      "type": "food",
      "value": 20,
      "stackable": false,
      "action": "Eat",
      "heal": 6
    },
    "raw_rat_meat": {
      "id": "raw_rat_meat",
      "name": "Raw Rat Meat",
      "icon": "🥩",
      "type": "food",
      "value": 4,
      "stackable": false
    },
    "cooked_rat_meat": {
      "id": "cooked_rat_meat",
      "name": "Cooked Rat Meat",
      "icon": "🍖",
      "type": "food",
      "value": 9,
      "stackable": false,
      "action": "Eat",
      "heal": 3
    },
    "burnt_food": {
      "id": "burnt_food",
      "name": "Burnt Food",
      "icon": "⬛",
      "type": "trash",
      "value": 1,
      "stackable": false
    },
    "cabbage": {
      "id": "cabbage",
      "name": "Cabbage",
      "icon": "🥬",
      "type": "food",
      "value": 15,
      "stackable": false,
      "action": "Eat",
      "heal": 3
    },
    "bread": {
      "id": "bread",
      "name": "Bread",
      "icon": "🍞",
      "type": "food",
      "value": 22,
      "stackable": false,
      "action": "Eat",
      "heal": 5
    },
    "wheat": {
      "id": "wheat",
      "name": "Wheat",
      "icon": "🌾",
      "type": "resource",
      "value": 8,
      "stackable": false
    },
    "flour": {
      "id": "flour",
      "name": "Pot of Flour",
      "icon": "🥣",
      "type": "resource",
      "value": 16,
      "stackable": false
    },
    "barley_seed": {
      "id": "barley_seed",
      "name": "Barley Seed",
      "icon": "🌱",
      "type": "seed",
      "value": 5,
      "stackable": true
    },
    "cabbage_seed": {
      "id": "cabbage_seed",
      "name": "Cabbage Seed",
      "icon": "🌱",
      "type": "seed",
      "value": 8,
      "stackable": true
    },
    "barley": {
      "id": "barley",
      "name": "Barley",
      "icon": "🌾",
      "type": "resource",
      "value": 20,
      "stackable": false
    },
    "garden_berries": {
      "id": "garden_berries",
      "name": "Sunberries",
      "icon": "🫐",
      "type": "food",
      "value": 12,
      "stackable": true,
      "action": "Eat",
      "heal": 2
    },
    "apple": {
      "id": "apple",
      "name": "Garden Apple",
      "icon": "🍎",
      "type": "food",
      "value": 18,
      "stackable": true,
      "action": "Eat",
      "heal": 4
    },
    "carrot": {
      "id": "carrot",
      "name": "Garden Carrot",
      "icon": "🥕",
      "type": "food",
      "value": 14,
      "stackable": true,
      "action": "Eat",
      "heal": 3
    },
    "garden_herbs": {
      "id": "garden_herbs",
      "name": "Fresh Garden Herbs",
      "icon": "🌿",
      "type": "resource",
      "value": 24,
      "stackable": true
    },
    "mind_rune": {
      "id": "mind_rune",
      "name": "Mind Rune",
      "icon": "🧠",
      "type": "rune",
      "value": 5,
      "stackable": true
    },
    "air_rune": {
      "id": "air_rune",
      "name": "Air Rune",
      "icon": "💨",
      "type": "rune",
      "value": 4,
      "stackable": true
    },
    "water_rune": {
      "id": "water_rune",
      "name": "Water Rune",
      "icon": "💧",
      "type": "rune",
      "value": 4,
      "stackable": true
    },
    "earth_rune": {
      "id": "earth_rune",
      "name": "Earth Rune",
      "icon": "🌍",
      "type": "rune",
      "value": 4,
      "stackable": true
    },
    "fire_rune": {
      "id": "fire_rune",
      "name": "Fire Rune",
      "icon": "🔥",
      "type": "rune",
      "value": 6,
      "stackable": true
    },
    "body_rune": {
      "id": "body_rune",
      "name": "Body Rune",
      "icon": "🫀",
      "type": "rune",
      "value": 8,
      "stackable": true
    },
    "chaos_rune": {
      "id": "chaos_rune",
      "name": "Chaos Rune",
      "icon": "🌀",
      "type": "rune",
      "value": 18,
      "stackable": true
    },
    "death_rune": {
      "id": "death_rune",
      "name": "Death Rune",
      "icon": "💀",
      "type": "rune",
      "value": 35,
      "stackable": true
    },
    "nature_rune": {
      "id": "nature_rune",
      "name": "Nature Rune",
      "icon": "🍃",
      "type": "rune",
      "value": 60,
      "stackable": true
    },
    "law_rune": {
      "id": "law_rune",
      "name": "Law Rune",
      "icon": "⚖️",
      "type": "rune",
      "value": 90,
      "stackable": true
    },
    "basic_staff": {
      "id": "basic_staff",
      "name": "Staff of Air",
      "icon": "🪄",
      "type": "weapon",
      "value": 75,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "magic",
      "toolType": "staff",
      "stats": {
        "magic": 8
      }
    },
    "fire_staff": {
      "id": "fire_staff",
      "name": "Staff of Fire",
      "icon": "🪄",
      "type": "weapon",
      "value": 175,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "magic",
      "toolType": "staff",
      "stats": {
        "magic": 15
      }
    },
    "bronze_helm": {
      "id": "bronze_helm",
      "name": "Bronze Helm",
      "icon": "🪖",
      "type": "armor",
      "value": 47,
      "stackable": false,
      "slot": "head",
      "tier": 1,
      "color": "#b87333",
      "stats": {
        "defence": 3
      }
    },
    "bronze_body": {
      "id": "bronze_body",
      "name": "Bronze Platebody",
      "icon": "🥋",
      "type": "armor",
      "value": 67,
      "stackable": false,
      "slot": "body",
      "tier": 1,
      "color": "#b87333",
      "stats": {
        "defence": 8
      }
    },
    "bronze_legs": {
      "id": "bronze_legs",
      "name": "Bronze Platelegs",
      "icon": "👖",
      "type": "armor",
      "value": 59,
      "stackable": false,
      "slot": "legs",
      "tier": 1,
      "color": "#b87333",
      "stats": {
        "defence": 6
      }
    },
    "bronze_boots": {
      "id": "bronze_boots",
      "name": "Bronze Boots",
      "icon": "🥾",
      "type": "armor",
      "value": 43,
      "stackable": false,
      "slot": "feet",
      "tier": 1,
      "color": "#b87333",
      "stats": {
        "defence": 2
      }
    },
    "bronze_gloves": {
      "id": "bronze_gloves",
      "name": "Bronze Gloves",
      "icon": "🧤",
      "type": "armor",
      "value": 43,
      "stackable": false,
      "slot": "hands",
      "tier": 1,
      "color": "#b87333",
      "stats": {
        "defence": 2
      }
    },
    "bronze_shield": {
      "id": "bronze_shield",
      "name": "Bronze Kiteshield",
      "icon": "🛡️",
      "type": "armor",
      "value": 55,
      "stackable": false,
      "slot": "shield",
      "tier": 1,
      "color": "#b87333",
      "stats": {
        "defence": 5
      }
    },
    "bronze_dagger": {
      "id": "bronze_dagger",
      "name": "Bronze Dagger",
      "icon": "🗡️",
      "type": "weapon",
      "value": 60,
      "stackable": false,
      "slot": "weapon",
      "tier": 1,
      "color": "#b87333",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 3,
        "strength": 1
      }
    },
    "bronze_sword": {
      "id": "bronze_sword",
      "name": "Bronze Sword",
      "icon": "⚔️",
      "type": "weapon",
      "value": 60,
      "stackable": false,
      "slot": "weapon",
      "tier": 1,
      "color": "#b87333",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 6,
        "strength": 4
      }
    },
    "bronze_longsword": {
      "id": "bronze_longsword",
      "name": "Bronze Longsword",
      "icon": "🗡️",
      "type": "weapon",
      "value": 60,
      "stackable": false,
      "slot": "weapon",
      "tier": 1,
      "color": "#b87333",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 8,
        "strength": 6
      }
    },
    "bronze_battleaxe": {
      "id": "bronze_battleaxe",
      "name": "Bronze Battleaxe",
      "icon": "🪓",
      "type": "weapon",
      "value": 60,
      "stackable": false,
      "slot": "weapon",
      "tier": 1,
      "color": "#b87333",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 5,
        "strength": 10
      }
    },
    "bronze_pickaxe": {
      "id": "bronze_pickaxe",
      "name": "Bronze Pickaxe",
      "icon": "⛏️",
      "type": "weapon",
      "value": 60,
      "stackable": false,
      "slot": "weapon",
      "tier": 1,
      "color": "#b87333",
      "combatStyle": "melee",
      "toolType": "pickaxe",
      "stats": {
        "attack": 3,
        "strength": 3,
        "miningPower": 1
      }
    },
    "bronze_hatchet": {
      "id": "bronze_hatchet",
      "name": "Bronze Hatchet",
      "icon": "🪓",
      "type": "weapon",
      "value": 60,
      "stackable": false,
      "slot": "weapon",
      "tier": 1,
      "color": "#b87333",
      "combatStyle": "melee",
      "toolType": "axe",
      "stats": {
        "attack": 3,
        "strength": 4,
        "woodcutPower": 1
      }
    },
    "iron_helm": {
      "id": "iron_helm",
      "name": "Iron Helm",
      "icon": "🪖",
      "type": "armor",
      "value": 98,
      "stackable": false,
      "slot": "head",
      "tier": 2,
      "color": "#a8adb3",
      "stats": {
        "defence": 7
      }
    },
    "iron_body": {
      "id": "iron_body",
      "name": "Iron Platebody",
      "icon": "🥋",
      "type": "armor",
      "value": 118,
      "stackable": false,
      "slot": "body",
      "tier": 2,
      "color": "#a8adb3",
      "stats": {
        "defence": 12
      }
    },
    "iron_legs": {
      "id": "iron_legs",
      "name": "Iron Platelegs",
      "icon": "👖",
      "type": "armor",
      "value": 110,
      "stackable": false,
      "slot": "legs",
      "tier": 2,
      "color": "#a8adb3",
      "stats": {
        "defence": 10
      }
    },
    "iron_boots": {
      "id": "iron_boots",
      "name": "Iron Boots",
      "icon": "🥾",
      "type": "armor",
      "value": 94,
      "stackable": false,
      "slot": "feet",
      "tier": 2,
      "color": "#a8adb3",
      "stats": {
        "defence": 6
      }
    },
    "iron_gloves": {
      "id": "iron_gloves",
      "name": "Iron Gloves",
      "icon": "🧤",
      "type": "armor",
      "value": 94,
      "stackable": false,
      "slot": "hands",
      "tier": 2,
      "color": "#a8adb3",
      "stats": {
        "defence": 6
      }
    },
    "iron_shield": {
      "id": "iron_shield",
      "name": "Iron Kiteshield",
      "icon": "🛡️",
      "type": "armor",
      "value": 106,
      "stackable": false,
      "slot": "shield",
      "tier": 2,
      "color": "#a8adb3",
      "stats": {
        "defence": 9
      }
    },
    "iron_dagger": {
      "id": "iron_dagger",
      "name": "Iron Dagger",
      "icon": "🗡️",
      "type": "weapon",
      "value": 95,
      "stackable": false,
      "slot": "weapon",
      "tier": 2,
      "color": "#a8adb3",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 7,
        "strength": 5
      }
    },
    "iron_sword": {
      "id": "iron_sword",
      "name": "Iron Sword",
      "icon": "⚔️",
      "type": "weapon",
      "value": 95,
      "stackable": false,
      "slot": "weapon",
      "tier": 2,
      "color": "#a8adb3",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 10,
        "strength": 8
      }
    },
    "iron_longsword": {
      "id": "iron_longsword",
      "name": "Iron Longsword",
      "icon": "🗡️",
      "type": "weapon",
      "value": 95,
      "stackable": false,
      "slot": "weapon",
      "tier": 2,
      "color": "#a8adb3",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 12,
        "strength": 10
      }
    },
    "iron_battleaxe": {
      "id": "iron_battleaxe",
      "name": "Iron Battleaxe",
      "icon": "🪓",
      "type": "weapon",
      "value": 95,
      "stackable": false,
      "slot": "weapon",
      "tier": 2,
      "color": "#a8adb3",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 9,
        "strength": 14
      }
    },
    "iron_pickaxe": {
      "id": "iron_pickaxe",
      "name": "Iron Pickaxe",
      "icon": "⛏️",
      "type": "weapon",
      "value": 95,
      "stackable": false,
      "slot": "weapon",
      "tier": 2,
      "color": "#a8adb3",
      "combatStyle": "melee",
      "toolType": "pickaxe",
      "stats": {
        "attack": 7,
        "strength": 7,
        "miningPower": 2
      }
    },
    "iron_hatchet": {
      "id": "iron_hatchet",
      "name": "Iron Hatchet",
      "icon": "🪓",
      "type": "weapon",
      "value": 95,
      "stackable": false,
      "slot": "weapon",
      "tier": 2,
      "color": "#a8adb3",
      "combatStyle": "melee",
      "toolType": "axe",
      "stats": {
        "attack": 7,
        "strength": 8,
        "woodcutPower": 2
      }
    },
    "steel_helm": {
      "id": "steel_helm",
      "name": "Steel Helm",
      "icon": "🪖",
      "type": "armor",
      "value": 153,
      "stackable": false,
      "slot": "head",
      "tier": 3,
      "color": "#707b87",
      "stats": {
        "defence": 12
      }
    },
    "steel_body": {
      "id": "steel_body",
      "name": "Steel Platebody",
      "icon": "🥋",
      "type": "armor",
      "value": 173,
      "stackable": false,
      "slot": "body",
      "tier": 3,
      "color": "#707b87",
      "stats": {
        "defence": 17
      }
    },
    "steel_legs": {
      "id": "steel_legs",
      "name": "Steel Platelegs",
      "icon": "👖",
      "type": "armor",
      "value": 165,
      "stackable": false,
      "slot": "legs",
      "tier": 3,
      "color": "#707b87",
      "stats": {
        "defence": 15
      }
    },
    "steel_boots": {
      "id": "steel_boots",
      "name": "Steel Boots",
      "icon": "🥾",
      "type": "armor",
      "value": 149,
      "stackable": false,
      "slot": "feet",
      "tier": 3,
      "color": "#707b87",
      "stats": {
        "defence": 11
      }
    },
    "steel_gloves": {
      "id": "steel_gloves",
      "name": "Steel Gloves",
      "icon": "🧤",
      "type": "armor",
      "value": 149,
      "stackable": false,
      "slot": "hands",
      "tier": 3,
      "color": "#707b87",
      "stats": {
        "defence": 11
      }
    },
    "steel_shield": {
      "id": "steel_shield",
      "name": "Steel Kiteshield",
      "icon": "🛡️",
      "type": "armor",
      "value": 161,
      "stackable": false,
      "slot": "shield",
      "tier": 3,
      "color": "#707b87",
      "stats": {
        "defence": 14
      }
    },
    "steel_dagger": {
      "id": "steel_dagger",
      "name": "Steel Dagger",
      "icon": "🗡️",
      "type": "weapon",
      "value": 130,
      "stackable": false,
      "slot": "weapon",
      "tier": 3,
      "color": "#707b87",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 12,
        "strength": 10
      }
    },
    "steel_sword": {
      "id": "steel_sword",
      "name": "Steel Sword",
      "icon": "⚔️",
      "type": "weapon",
      "value": 130,
      "stackable": false,
      "slot": "weapon",
      "tier": 3,
      "color": "#707b87",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 15,
        "strength": 13
      }
    },
    "steel_longsword": {
      "id": "steel_longsword",
      "name": "Steel Longsword",
      "icon": "🗡️",
      "type": "weapon",
      "value": 130,
      "stackable": false,
      "slot": "weapon",
      "tier": 3,
      "color": "#707b87",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 17,
        "strength": 15
      }
    },
    "steel_battleaxe": {
      "id": "steel_battleaxe",
      "name": "Steel Battleaxe",
      "icon": "🪓",
      "type": "weapon",
      "value": 130,
      "stackable": false,
      "slot": "weapon",
      "tier": 3,
      "color": "#707b87",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 14,
        "strength": 19
      }
    },
    "steel_pickaxe": {
      "id": "steel_pickaxe",
      "name": "Steel Pickaxe",
      "icon": "⛏️",
      "type": "weapon",
      "value": 130,
      "stackable": false,
      "slot": "weapon",
      "tier": 3,
      "color": "#707b87",
      "combatStyle": "melee",
      "toolType": "pickaxe",
      "stats": {
        "attack": 12,
        "strength": 12,
        "miningPower": 3
      }
    },
    "steel_hatchet": {
      "id": "steel_hatchet",
      "name": "Steel Hatchet",
      "icon": "🪓",
      "type": "weapon",
      "value": 130,
      "stackable": false,
      "slot": "weapon",
      "tier": 3,
      "color": "#707b87",
      "combatStyle": "melee",
      "toolType": "axe",
      "stats": {
        "attack": 12,
        "strength": 13,
        "woodcutPower": 3
      }
    },
    "mithril_helm": {
      "id": "mithril_helm",
      "name": "Mithril Helm",
      "icon": "🪖",
      "type": "armor",
      "value": 212,
      "stackable": false,
      "slot": "head",
      "tier": 4,
      "color": "#456e9a",
      "stats": {
        "defence": 18
      }
    },
    "mithril_body": {
      "id": "mithril_body",
      "name": "Mithril Platebody",
      "icon": "🥋",
      "type": "armor",
      "value": 232,
      "stackable": false,
      "slot": "body",
      "tier": 4,
      "color": "#456e9a",
      "stats": {
        "defence": 23
      }
    },
    "mithril_legs": {
      "id": "mithril_legs",
      "name": "Mithril Platelegs",
      "icon": "👖",
      "type": "armor",
      "value": 224,
      "stackable": false,
      "slot": "legs",
      "tier": 4,
      "color": "#456e9a",
      "stats": {
        "defence": 21
      }
    },
    "mithril_boots": {
      "id": "mithril_boots",
      "name": "Mithril Boots",
      "icon": "🥾",
      "type": "armor",
      "value": 208,
      "stackable": false,
      "slot": "feet",
      "tier": 4,
      "color": "#456e9a",
      "stats": {
        "defence": 17
      }
    },
    "mithril_gloves": {
      "id": "mithril_gloves",
      "name": "Mithril Gloves",
      "icon": "🧤",
      "type": "armor",
      "value": 208,
      "stackable": false,
      "slot": "hands",
      "tier": 4,
      "color": "#456e9a",
      "stats": {
        "defence": 17
      }
    },
    "mithril_shield": {
      "id": "mithril_shield",
      "name": "Mithril Kiteshield",
      "icon": "🛡️",
      "type": "armor",
      "value": 220,
      "stackable": false,
      "slot": "shield",
      "tier": 4,
      "color": "#456e9a",
      "stats": {
        "defence": 20
      }
    },
    "mithril_dagger": {
      "id": "mithril_dagger",
      "name": "Mithril Dagger",
      "icon": "🗡️",
      "type": "weapon",
      "value": 165,
      "stackable": false,
      "slot": "weapon",
      "tier": 4,
      "color": "#456e9a",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 18,
        "strength": 16
      }
    },
    "mithril_sword": {
      "id": "mithril_sword",
      "name": "Mithril Sword",
      "icon": "⚔️",
      "type": "weapon",
      "value": 165,
      "stackable": false,
      "slot": "weapon",
      "tier": 4,
      "color": "#456e9a",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 21,
        "strength": 19
      }
    },
    "mithril_longsword": {
      "id": "mithril_longsword",
      "name": "Mithril Longsword",
      "icon": "🗡️",
      "type": "weapon",
      "value": 165,
      "stackable": false,
      "slot": "weapon",
      "tier": 4,
      "color": "#456e9a",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 23,
        "strength": 21
      }
    },
    "mithril_battleaxe": {
      "id": "mithril_battleaxe",
      "name": "Mithril Battleaxe",
      "icon": "🪓",
      "type": "weapon",
      "value": 165,
      "stackable": false,
      "slot": "weapon",
      "tier": 4,
      "color": "#456e9a",
      "combatStyle": "melee",
      "toolType": "sword",
      "stats": {
        "attack": 20,
        "strength": 25
      }
    },
    "mithril_pickaxe": {
      "id": "mithril_pickaxe",
      "name": "Mithril Pickaxe",
      "icon": "⛏️",
      "type": "weapon",
      "value": 165,
      "stackable": false,
      "slot": "weapon",
      "tier": 4,
      "color": "#456e9a",
      "combatStyle": "melee",
      "toolType": "pickaxe",
      "stats": {
        "attack": 18,
        "strength": 18,
        "miningPower": 4
      }
    },
    "mithril_hatchet": {
      "id": "mithril_hatchet",
      "name": "Mithril Hatchet",
      "icon": "🪓",
      "type": "weapon",
      "value": 165,
      "stackable": false,
      "slot": "weapon",
      "tier": 4,
      "color": "#456e9a",
      "combatStyle": "melee",
      "toolType": "axe",
      "stats": {
        "attack": 18,
        "strength": 19,
        "woodcutPower": 4
      }
    },
    "bronze_axe": {
      "id": "bronze_axe",
      "name": "Bronze Axe",
      "icon": "🪓",
      "type": "weapon",
      "value": 25,
      "stackable": false,
      "slot": "weapon",
      "tier": 1,
      "color": "#b87333",
      "combatStyle": "melee",
      "toolType": "axe",
      "stats": {
        "attack": 3,
        "strength": 4,
        "woodcutPower": 1
      },
      "legacyAliasFor": "bronze_hatchet"
    },
    "bronze_platebody": {
      "id": "bronze_platebody",
      "name": "Bronze Platebody",
      "icon": "🥋",
      "type": "armor",
      "value": 120,
      "stackable": false,
      "slot": "body",
      "tier": 1,
      "color": "#b87333",
      "stats": {
        "defence": 8
      },
      "legacyAliasFor": "bronze_body"
    },
    "bronze_platelegs": {
      "id": "bronze_platelegs",
      "name": "Bronze Platelegs",
      "icon": "👖",
      "type": "armor",
      "value": 90,
      "stackable": false,
      "slot": "legs",
      "tier": 1,
      "color": "#b87333",
      "stats": {
        "defence": 6
      },
      "legacyAliasFor": "bronze_legs"
    },
    "leather_cowl": {
      "id": "leather_cowl",
      "name": "Leather Cowl",
      "icon": "🧢",
      "type": "armor",
      "value": 35,
      "stackable": false,
      "slot": "head",
      "tier": 1,
      "stats": {
        "defence": 2,
        "ranged": 1
      }
    },
    "leather_body": {
      "id": "leather_body",
      "name": "Leather Body",
      "icon": "🦺",
      "type": "armor",
      "value": 90,
      "stackable": false,
      "slot": "body",
      "tier": 1,
      "stats": {
        "defence": 7,
        "ranged": 4
      }
    },
    "leather_chaps": {
      "id": "leather_chaps",
      "name": "Leather Chaps",
      "icon": "👖",
      "type": "armor",
      "value": 70,
      "stackable": false,
      "slot": "legs",
      "tier": 1,
      "stats": {
        "defence": 5,
        "ranged": 3
      }
    },
    "leather_boots": {
      "id": "leather_boots",
      "name": "Leather Boots",
      "icon": "🥾",
      "type": "armor",
      "value": 25,
      "stackable": false,
      "slot": "feet",
      "tier": 1,
      "stats": {
        "defence": 1,
        "ranged": 1
      }
    },
    "leather_gloves": {
      "id": "leather_gloves",
      "name": "Leather Gloves",
      "icon": "🧤",
      "type": "armor",
      "value": 25,
      "stackable": false,
      "slot": "hands",
      "tier": 1,
      "stats": {
        "defence": 1,
        "ranged": 1
      }
    },
    "leather_vambraces": {
      "id": "leather_vambraces",
      "name": "Leather Vambraces",
      "icon": "🧤",
      "type": "armor",
      "value": 35,
      "stackable": false,
      "slot": "hands",
      "tier": 1,
      "stats": {
        "defence": 2,
        "ranged": 2
      }
    },
    "studded_body": {
      "id": "studded_body",
      "name": "Studded Leather Body",
      "icon": "🦺",
      "type": "armor",
      "value": 165,
      "stackable": false,
      "slot": "body",
      "tier": 2,
      "stats": {
        "defence": 11,
        "ranged": 7
      }
    },
    "studded_chaps": {
      "id": "studded_chaps",
      "name": "Studded Leather Chaps",
      "icon": "👖",
      "type": "armor",
      "value": 125,
      "stackable": false,
      "slot": "legs",
      "tier": 2,
      "stats": {
        "defence": 8,
        "ranged": 5
      }
    },
    "sewer_king_blade": {
      "id": "sewer_king_blade",
      "name": "Sewer King Blade",
      "icon": "🗡️",
      "type": "weapon",
      "value": 2500,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "melee",
      "toolType": "sword",
      "tier": 6,
      "stats": {
        "attack": 32,
        "strength": 38
      },
      "rare": true
    },
    "plagueguard_body": {
      "id": "plagueguard_body",
      "name": "Plagueguard Chestpiece",
      "icon": "🥋",
      "type": "armor",
      "value": 3200,
      "stackable": false,
      "slot": "body",
      "tier": 6,
      "stats": {
        "defence": 36,
        "poisonResist": 50
      },
      "rare": true
    },
    "dragonfire_blade": {
      "id": "dragonfire_blade",
      "name": "Dragonfire Blade",
      "icon": "🔥",
      "type": "weapon",
      "value": 12000,
      "stackable": false,
      "slot": "weapon",
      "combatStyle": "melee",
      "toolType": "sword",
      "tier": 8,
      "stats": {
        "attack": 52,
        "strength": 58
      },
      "rare": true
    },
    "king_rat_pet": {
      "id": "king_rat_pet",
      "name": "King Rat Pet",
      "icon": "🐀",
      "type": "pet",
      "value": 1,
      "stackable": false,
      "rare": true
    },
    "dragon_pet": {
      "id": "dragon_pet",
      "name": "Baby Dragon Pet",
      "icon": "🐉",
      "type": "pet",
      "value": 1,
      "stackable": false,
      "rare": true
    },
    "spellbook": {
      "id": "spellbook",
      "name": "Personal Spellbook",
      "icon": "📕",
      "type": "spellbook",
      "value": 0,
      "stackable": false,
      "bound": true,
      "container": "spellbook",
      "action": "Open"
    },
    "oak_plank": {
      "id": "oak_plank",
      "name": "Oak Plank",
      "icon": "🪵",
      "type": "resource",
      "value": 38,
      "stackable": true
    },
    "steel_nails": {
      "id": "steel_nails",
      "name": "Steel Nails",
      "icon": "🔩",
      "type": "resource",
      "value": 4,
      "stackable": true
    },
    "pet_bedding": {
      "id": "pet_bedding",
      "name": "Soft Pet Bedding",
      "icon": "🧺",
      "type": "resource",
      "value": 55,
      "stackable": true
    },
    "arcane_lens": {
      "id": "arcane_lens",
      "name": "Arcane Lens",
      "icon": "🔮",
      "type": "resource",
      "value": 180,
      "stackable": false
    }
  },
  "recipes": [
    {
      "id": "smelt_bronze",
      "name": "Smelt Bronze Bar",
      "skill": "smithing",
      "level": 1,
      "station": "furnace",
      "inputs": {
        "copper_ore": 1,
        "tin_ore": 1
      },
      "outputs": {
        "bronze_bar": 1
      },
      "xp": 18,
      "icon": "▰"
    },
    {
      "id": "smelt_iron",
      "name": "Smelt Iron Bar",
      "skill": "smithing",
      "level": 15,
      "station": "furnace",
      "inputs": {
        "iron_ore": 1
      },
      "outputs": {
        "iron_bar": 1
      },
      "xp": 30,
      "icon": "▰",
      "successChance": 0.75
    },
    {
      "id": "smelt_steel",
      "name": "Smelt Steel Bar",
      "skill": "smithing",
      "level": 30,
      "station": "furnace",
      "inputs": {
        "iron_ore": 1,
        "coal_ore": 2
      },
      "outputs": {
        "steel_bar": 1
      },
      "xp": 48,
      "icon": "▰"
    },
    {
      "id": "smelt_silver",
      "name": "Smelt Silver Bar",
      "skill": "smithing",
      "level": 40,
      "station": "furnace",
      "inputs": {
        "silver_ore": 1
      },
      "outputs": {
        "silver_bar": 1
      },
      "xp": 55,
      "icon": "▰"
    },
    {
      "id": "smelt_gold",
      "name": "Smelt Gold Bar",
      "skill": "smithing",
      "level": 50,
      "station": "furnace",
      "inputs": {
        "gold_ore": 1
      },
      "outputs": {
        "gold_bar": 1
      },
      "xp": 72,
      "icon": "▰"
    },
    {
      "id": "smith_bronze_dagger",
      "name": "Smith Bronze Dagger",
      "skill": "smithing",
      "level": 1,
      "station": "anvil",
      "inputs": {
        "bronze_bar": 1
      },
      "outputs": {
        "bronze_dagger": 1
      },
      "xp": 25,
      "icon": "🗡️"
    },
    {
      "id": "smith_bronze_sword",
      "name": "Smith Bronze Sword",
      "skill": "smithing",
      "level": 1,
      "station": "anvil",
      "inputs": {
        "bronze_bar": 1
      },
      "outputs": {
        "bronze_sword": 1
      },
      "xp": 25,
      "icon": "⚔️"
    },
    {
      "id": "smith_bronze_longsword",
      "name": "Smith Bronze Longsword",
      "skill": "smithing",
      "level": 1,
      "station": "anvil",
      "inputs": {
        "bronze_bar": 2
      },
      "outputs": {
        "bronze_longsword": 1
      },
      "xp": 50,
      "icon": "🗡️"
    },
    {
      "id": "smith_bronze_battleaxe",
      "name": "Smith Bronze Battleaxe",
      "skill": "smithing",
      "level": 2,
      "station": "anvil",
      "inputs": {
        "bronze_bar": 3
      },
      "outputs": {
        "bronze_battleaxe": 1
      },
      "xp": 75,
      "icon": "🪓"
    },
    {
      "id": "smith_bronze_pickaxe",
      "name": "Smith Bronze Pickaxe",
      "skill": "smithing",
      "level": 2,
      "station": "anvil",
      "inputs": {
        "bronze_bar": 2
      },
      "outputs": {
        "bronze_pickaxe": 1
      },
      "xp": 50,
      "icon": "⛏️"
    },
    {
      "id": "smith_bronze_hatchet",
      "name": "Smith Bronze Hatchet",
      "skill": "smithing",
      "level": 2,
      "station": "anvil",
      "inputs": {
        "bronze_bar": 2
      },
      "outputs": {
        "bronze_hatchet": 1
      },
      "xp": 50,
      "icon": "🪓"
    },
    {
      "id": "smith_bronze_helm",
      "name": "Smith Bronze Helm",
      "skill": "smithing",
      "level": 3,
      "station": "anvil",
      "inputs": {
        "bronze_bar": 2
      },
      "outputs": {
        "bronze_helm": 1
      },
      "xp": 50,
      "icon": "🪖"
    },
    {
      "id": "smith_bronze_body",
      "name": "Smith Bronze Platebody",
      "skill": "smithing",
      "level": 3,
      "station": "anvil",
      "inputs": {
        "bronze_bar": 5
      },
      "outputs": {
        "bronze_body": 1
      },
      "xp": 125,
      "icon": "🥋"
    },
    {
      "id": "smith_bronze_legs",
      "name": "Smith Bronze Platelegs",
      "skill": "smithing",
      "level": 3,
      "station": "anvil",
      "inputs": {
        "bronze_bar": 3
      },
      "outputs": {
        "bronze_legs": 1
      },
      "xp": 75,
      "icon": "👖"
    },
    {
      "id": "smith_bronze_boots",
      "name": "Smith Bronze Boots",
      "skill": "smithing",
      "level": 4,
      "station": "anvil",
      "inputs": {
        "bronze_bar": 1
      },
      "outputs": {
        "bronze_boots": 1
      },
      "xp": 25,
      "icon": "🥾"
    },
    {
      "id": "smith_bronze_gloves",
      "name": "Smith Bronze Gloves",
      "skill": "smithing",
      "level": 4,
      "station": "anvil",
      "inputs": {
        "bronze_bar": 1
      },
      "outputs": {
        "bronze_gloves": 1
      },
      "xp": 25,
      "icon": "🧤"
    },
    {
      "id": "smith_bronze_shield",
      "name": "Smith Bronze Kiteshield",
      "skill": "smithing",
      "level": 4,
      "station": "anvil",
      "inputs": {
        "bronze_bar": 3
      },
      "outputs": {
        "bronze_shield": 1
      },
      "xp": 75,
      "icon": "🛡️"
    },
    {
      "id": "smith_bronze_arrowtips",
      "name": "Smith Bronze Arrowtips",
      "skill": "smithing",
      "level": 1,
      "station": "anvil",
      "inputs": {
        "bronze_bar": 1
      },
      "outputs": {
        "bronze_arrowtips": 15
      },
      "xp": 35,
      "icon": "🔺"
    },
    {
      "id": "smith_iron_dagger",
      "name": "Smith Iron Dagger",
      "skill": "smithing",
      "level": 15,
      "station": "anvil",
      "inputs": {
        "iron_bar": 1
      },
      "outputs": {
        "iron_dagger": 1
      },
      "xp": 45,
      "icon": "🗡️"
    },
    {
      "id": "smith_iron_sword",
      "name": "Smith Iron Sword",
      "skill": "smithing",
      "level": 15,
      "station": "anvil",
      "inputs": {
        "iron_bar": 1
      },
      "outputs": {
        "iron_sword": 1
      },
      "xp": 45,
      "icon": "⚔️"
    },
    {
      "id": "smith_iron_longsword",
      "name": "Smith Iron Longsword",
      "skill": "smithing",
      "level": 15,
      "station": "anvil",
      "inputs": {
        "iron_bar": 2
      },
      "outputs": {
        "iron_longsword": 1
      },
      "xp": 70,
      "icon": "🗡️"
    },
    {
      "id": "smith_iron_battleaxe",
      "name": "Smith Iron Battleaxe",
      "skill": "smithing",
      "level": 16,
      "station": "anvil",
      "inputs": {
        "iron_bar": 3
      },
      "outputs": {
        "iron_battleaxe": 1
      },
      "xp": 95,
      "icon": "🪓"
    },
    {
      "id": "smith_iron_pickaxe",
      "name": "Smith Iron Pickaxe",
      "skill": "smithing",
      "level": 16,
      "station": "anvil",
      "inputs": {
        "iron_bar": 2
      },
      "outputs": {
        "iron_pickaxe": 1
      },
      "xp": 70,
      "icon": "⛏️"
    },
    {
      "id": "smith_iron_hatchet",
      "name": "Smith Iron Hatchet",
      "skill": "smithing",
      "level": 16,
      "station": "anvil",
      "inputs": {
        "iron_bar": 2
      },
      "outputs": {
        "iron_hatchet": 1
      },
      "xp": 70,
      "icon": "🪓"
    },
    {
      "id": "smith_iron_helm",
      "name": "Smith Iron Helm",
      "skill": "smithing",
      "level": 17,
      "station": "anvil",
      "inputs": {
        "iron_bar": 2
      },
      "outputs": {
        "iron_helm": 1
      },
      "xp": 70,
      "icon": "🪖"
    },
    {
      "id": "smith_iron_body",
      "name": "Smith Iron Platebody",
      "skill": "smithing",
      "level": 17,
      "station": "anvil",
      "inputs": {
        "iron_bar": 5
      },
      "outputs": {
        "iron_body": 1
      },
      "xp": 145,
      "icon": "🥋"
    },
    {
      "id": "smith_iron_legs",
      "name": "Smith Iron Platelegs",
      "skill": "smithing",
      "level": 17,
      "station": "anvil",
      "inputs": {
        "iron_bar": 3
      },
      "outputs": {
        "iron_legs": 1
      },
      "xp": 95,
      "icon": "👖"
    },
    {
      "id": "smith_iron_boots",
      "name": "Smith Iron Boots",
      "skill": "smithing",
      "level": 18,
      "station": "anvil",
      "inputs": {
        "iron_bar": 1
      },
      "outputs": {
        "iron_boots": 1
      },
      "xp": 45,
      "icon": "🥾"
    },
    {
      "id": "smith_iron_gloves",
      "name": "Smith Iron Gloves",
      "skill": "smithing",
      "level": 18,
      "station": "anvil",
      "inputs": {
        "iron_bar": 1
      },
      "outputs": {
        "iron_gloves": 1
      },
      "xp": 45,
      "icon": "🧤"
    },
    {
      "id": "smith_iron_shield",
      "name": "Smith Iron Kiteshield",
      "skill": "smithing",
      "level": 18,
      "station": "anvil",
      "inputs": {
        "iron_bar": 3
      },
      "outputs": {
        "iron_shield": 1
      },
      "xp": 95,
      "icon": "🛡️"
    },
    {
      "id": "smith_iron_arrowtips",
      "name": "Smith Iron Arrowtips",
      "skill": "smithing",
      "level": 15,
      "station": "anvil",
      "inputs": {
        "iron_bar": 1
      },
      "outputs": {
        "iron_arrowtips": 15
      },
      "xp": 57,
      "icon": "🔺"
    },
    {
      "id": "smith_steel_dagger",
      "name": "Smith Steel Dagger",
      "skill": "smithing",
      "level": 30,
      "station": "anvil",
      "inputs": {
        "steel_bar": 1
      },
      "outputs": {
        "steel_dagger": 1
      },
      "xp": 65,
      "icon": "🗡️"
    },
    {
      "id": "smith_steel_sword",
      "name": "Smith Steel Sword",
      "skill": "smithing",
      "level": 30,
      "station": "anvil",
      "inputs": {
        "steel_bar": 1
      },
      "outputs": {
        "steel_sword": 1
      },
      "xp": 65,
      "icon": "⚔️"
    },
    {
      "id": "smith_steel_longsword",
      "name": "Smith Steel Longsword",
      "skill": "smithing",
      "level": 30,
      "station": "anvil",
      "inputs": {
        "steel_bar": 2
      },
      "outputs": {
        "steel_longsword": 1
      },
      "xp": 90,
      "icon": "🗡️"
    },
    {
      "id": "smith_steel_battleaxe",
      "name": "Smith Steel Battleaxe",
      "skill": "smithing",
      "level": 31,
      "station": "anvil",
      "inputs": {
        "steel_bar": 3
      },
      "outputs": {
        "steel_battleaxe": 1
      },
      "xp": 115,
      "icon": "🪓"
    },
    {
      "id": "smith_steel_pickaxe",
      "name": "Smith Steel Pickaxe",
      "skill": "smithing",
      "level": 31,
      "station": "anvil",
      "inputs": {
        "steel_bar": 2
      },
      "outputs": {
        "steel_pickaxe": 1
      },
      "xp": 90,
      "icon": "⛏️"
    },
    {
      "id": "smith_steel_hatchet",
      "name": "Smith Steel Hatchet",
      "skill": "smithing",
      "level": 31,
      "station": "anvil",
      "inputs": {
        "steel_bar": 2
      },
      "outputs": {
        "steel_hatchet": 1
      },
      "xp": 90,
      "icon": "🪓"
    },
    {
      "id": "smith_steel_helm",
      "name": "Smith Steel Helm",
      "skill": "smithing",
      "level": 32,
      "station": "anvil",
      "inputs": {
        "steel_bar": 2
      },
      "outputs": {
        "steel_helm": 1
      },
      "xp": 90,
      "icon": "🪖"
    },
    {
      "id": "smith_steel_body",
      "name": "Smith Steel Platebody",
      "skill": "smithing",
      "level": 32,
      "station": "anvil",
      "inputs": {
        "steel_bar": 5
      },
      "outputs": {
        "steel_body": 1
      },
      "xp": 165,
      "icon": "🥋"
    },
    {
      "id": "smith_steel_legs",
      "name": "Smith Steel Platelegs",
      "skill": "smithing",
      "level": 32,
      "station": "anvil",
      "inputs": {
        "steel_bar": 3
      },
      "outputs": {
        "steel_legs": 1
      },
      "xp": 115,
      "icon": "👖"
    },
    {
      "id": "smith_steel_boots",
      "name": "Smith Steel Boots",
      "skill": "smithing",
      "level": 33,
      "station": "anvil",
      "inputs": {
        "steel_bar": 1
      },
      "outputs": {
        "steel_boots": 1
      },
      "xp": 65,
      "icon": "🥾"
    },
    {
      "id": "smith_steel_gloves",
      "name": "Smith Steel Gloves",
      "skill": "smithing",
      "level": 33,
      "station": "anvil",
      "inputs": {
        "steel_bar": 1
      },
      "outputs": {
        "steel_gloves": 1
      },
      "xp": 65,
      "icon": "🧤"
    },
    {
      "id": "smith_steel_shield",
      "name": "Smith Steel Kiteshield",
      "skill": "smithing",
      "level": 33,
      "station": "anvil",
      "inputs": {
        "steel_bar": 3
      },
      "outputs": {
        "steel_shield": 1
      },
      "xp": 115,
      "icon": "🛡️"
    },
    {
      "id": "smith_steel_arrowtips",
      "name": "Smith Steel Arrowtips",
      "skill": "smithing",
      "level": 30,
      "station": "anvil",
      "inputs": {
        "steel_bar": 1
      },
      "outputs": {
        "steel_arrowtips": 15
      },
      "xp": 79,
      "icon": "🔺"
    },
    {
      "id": "tan_leather",
      "name": "Tan Cowhide",
      "skill": "crafting",
      "level": 1,
      "station": "tannery",
      "inputs": {
        "cowhide": 1,
        "coins": 1
      },
      "outputs": {
        "leather": 1
      },
      "xp": 8,
      "icon": "🟫"
    },
    {
      "id": "tan_hard_leather",
      "name": "Harden Leather",
      "skill": "crafting",
      "level": 15,
      "station": "tannery",
      "inputs": {
        "leather": 2,
        "coins": 3
      },
      "outputs": {
        "hard_leather": 1
      },
      "xp": 18,
      "icon": "🟤"
    },
    {
      "id": "craft_leather_cowl",
      "name": "Craft Leather Cowl",
      "skill": "crafting",
      "level": 1,
      "station": "crafting_table",
      "inputs": {
        "leather": 1,
        "thread": 1
      },
      "outputs": {
        "leather_cowl": 1
      },
      "xp": 18,
      "icon": "🧢"
    },
    {
      "id": "craft_leather_body",
      "name": "Craft Leather Body",
      "skill": "crafting",
      "level": 4,
      "station": "crafting_table",
      "inputs": {
        "leather": 3,
        "thread": 1
      },
      "outputs": {
        "leather_body": 1
      },
      "xp": 54,
      "icon": "🦺"
    },
    {
      "id": "craft_leather_chaps",
      "name": "Craft Leather Chaps",
      "skill": "crafting",
      "level": 3,
      "station": "crafting_table",
      "inputs": {
        "leather": 2,
        "thread": 1
      },
      "outputs": {
        "leather_chaps": 1
      },
      "xp": 36,
      "icon": "👖"
    },
    {
      "id": "craft_leather_boots",
      "name": "Craft Leather Boots",
      "skill": "crafting",
      "level": 1,
      "station": "crafting_table",
      "inputs": {
        "leather": 1,
        "thread": 1
      },
      "outputs": {
        "leather_boots": 1
      },
      "xp": 18,
      "icon": "🥾"
    },
    {
      "id": "craft_leather_gloves",
      "name": "Craft Leather Gloves",
      "skill": "crafting",
      "level": 1,
      "station": "crafting_table",
      "inputs": {
        "leather": 1,
        "thread": 1
      },
      "outputs": {
        "leather_gloves": 1
      },
      "xp": 18,
      "icon": "🧤"
    },
    {
      "id": "craft_leather_vambraces",
      "name": "Craft Leather Vambraces",
      "skill": "crafting",
      "level": 2,
      "station": "crafting_table",
      "inputs": {
        "leather": 1,
        "thread": 1
      },
      "outputs": {
        "leather_vambraces": 1
      },
      "xp": 18,
      "icon": "🧤"
    },
    {
      "id": "craft_studded_body",
      "name": "Craft Studded Body",
      "skill": "crafting",
      "level": 25,
      "station": "crafting_table",
      "inputs": {
        "leather_body": 1,
        "steel_bar": 1,
        "thread": 1
      },
      "outputs": {
        "studded_body": 1
      },
      "xp": 90,
      "icon": "🦺"
    },
    {
      "id": "craft_studded_chaps",
      "name": "Craft Studded Chaps",
      "skill": "crafting",
      "level": 22,
      "station": "crafting_table",
      "inputs": {
        "leather_chaps": 1,
        "steel_bar": 1,
        "thread": 1
      },
      "outputs": {
        "studded_chaps": 1
      },
      "xp": 70,
      "icon": "👖"
    },
    {
      "id": "spin_flax",
      "name": "Spin Bow String",
      "skill": "crafting",
      "level": 10,
      "station": "spinning_wheel",
      "inputs": {
        "flax": 1
      },
      "outputs": {
        "bowstring": 1
      },
      "xp": 15,
      "icon": "🧵"
    },
    {
      "id": "spin_wool",
      "name": "Spin Ball of Wool",
      "skill": "crafting",
      "level": 1,
      "station": "spinning_wheel",
      "inputs": {
        "wool": 1
      },
      "outputs": {
        "ball_of_wool": 1
      },
      "xp": 8,
      "icon": "🧶"
    },
    {
      "id": "fletch_normal_short_unstrung",
      "name": "Fletch Normal Unstrung Bow",
      "skill": "fletching",
      "level": 1,
      "station": "any",
      "inputs": {
        "normal_logs": 1,
        "knife": 1
      },
      "outputs": {
        "normal_unstrung_bow": 1
      },
      "xp": 20,
      "icon": "🏹"
    },
    {
      "id": "string_normal_shortbow",
      "name": "String Normal Shortbow",
      "skill": "fletching",
      "level": 1,
      "station": "any",
      "inputs": {
        "normal_unstrung_bow": 1,
        "bowstring": 1
      },
      "outputs": {
        "normal_shortbow": 1
      },
      "xp": 20,
      "icon": "🏹"
    },
    {
      "id": "fletch_normal_longbow",
      "name": "Fletch Normal Longbow",
      "skill": "fletching",
      "level": 6,
      "station": "any",
      "inputs": {
        "normal_logs": 1,
        "knife": 1,
        "bowstring": 1
      },
      "outputs": {
        "normal_longbow": 1
      },
      "xp": 28,
      "icon": "🏹"
    },
    {
      "id": "fletch_oak_short_unstrung",
      "name": "Fletch Oak Unstrung Bow",
      "skill": "fletching",
      "level": 15,
      "station": "any",
      "inputs": {
        "oak_logs": 1,
        "knife": 1
      },
      "outputs": {
        "oak_unstrung_bow": 1
      },
      "xp": 42,
      "icon": "🏹"
    },
    {
      "id": "string_oak_shortbow",
      "name": "String Oak Shortbow",
      "skill": "fletching",
      "level": 15,
      "station": "any",
      "inputs": {
        "oak_unstrung_bow": 1,
        "bowstring": 1
      },
      "outputs": {
        "oak_shortbow": 1
      },
      "xp": 42,
      "icon": "🏹"
    },
    {
      "id": "fletch_oak_longbow",
      "name": "Fletch Oak Longbow",
      "skill": "fletching",
      "level": 20,
      "station": "any",
      "inputs": {
        "oak_logs": 1,
        "knife": 1,
        "bowstring": 1
      },
      "outputs": {
        "oak_longbow": 1
      },
      "xp": 56,
      "icon": "🏹"
    },
    {
      "id": "fletch_willow_short_unstrung",
      "name": "Fletch Willow Unstrung Bow",
      "skill": "fletching",
      "level": 30,
      "station": "any",
      "inputs": {
        "willow_logs": 1,
        "knife": 1
      },
      "outputs": {
        "willow_unstrung_bow": 1
      },
      "xp": 64,
      "icon": "🏹"
    },
    {
      "id": "string_willow_shortbow",
      "name": "String Willow Shortbow",
      "skill": "fletching",
      "level": 30,
      "station": "any",
      "inputs": {
        "willow_unstrung_bow": 1,
        "bowstring": 1
      },
      "outputs": {
        "willow_shortbow": 1
      },
      "xp": 64,
      "icon": "🏹"
    },
    {
      "id": "fletch_willow_longbow",
      "name": "Fletch Willow Longbow",
      "skill": "fletching",
      "level": 35,
      "station": "any",
      "inputs": {
        "willow_logs": 1,
        "knife": 1,
        "bowstring": 1
      },
      "outputs": {
        "willow_longbow": 1
      },
      "xp": 84,
      "icon": "🏹"
    },
    {
      "id": "fletch_maple_short_unstrung",
      "name": "Fletch Maple Unstrung Bow",
      "skill": "fletching",
      "level": 45,
      "station": "any",
      "inputs": {
        "maple_logs": 1,
        "knife": 1
      },
      "outputs": {
        "maple_unstrung_bow": 1
      },
      "xp": 86,
      "icon": "🏹"
    },
    {
      "id": "string_maple_shortbow",
      "name": "String Maple Shortbow",
      "skill": "fletching",
      "level": 45,
      "station": "any",
      "inputs": {
        "maple_unstrung_bow": 1,
        "bowstring": 1
      },
      "outputs": {
        "maple_shortbow": 1
      },
      "xp": 86,
      "icon": "🏹"
    },
    {
      "id": "fletch_maple_longbow",
      "name": "Fletch Maple Longbow",
      "skill": "fletching",
      "level": 50,
      "station": "any",
      "inputs": {
        "maple_logs": 1,
        "knife": 1,
        "bowstring": 1
      },
      "outputs": {
        "maple_longbow": 1
      },
      "xp": 112,
      "icon": "🏹"
    },
    {
      "id": "fletch_yew_short_unstrung",
      "name": "Fletch Yew Unstrung Bow",
      "skill": "fletching",
      "level": 60,
      "station": "any",
      "inputs": {
        "yew_logs": 1,
        "knife": 1
      },
      "outputs": {
        "yew_unstrung_bow": 1
      },
      "xp": 108,
      "icon": "🏹"
    },
    {
      "id": "string_yew_shortbow",
      "name": "String Yew Shortbow",
      "skill": "fletching",
      "level": 60,
      "station": "any",
      "inputs": {
        "yew_unstrung_bow": 1,
        "bowstring": 1
      },
      "outputs": {
        "yew_shortbow": 1
      },
      "xp": 108,
      "icon": "🏹"
    },
    {
      "id": "fletch_yew_longbow",
      "name": "Fletch Yew Longbow",
      "skill": "fletching",
      "level": 65,
      "station": "any",
      "inputs": {
        "yew_logs": 1,
        "knife": 1,
        "bowstring": 1
      },
      "outputs": {
        "yew_longbow": 1
      },
      "xp": 140,
      "icon": "🏹"
    },
    {
      "id": "fletch_shafts",
      "name": "Cut Arrow Shafts",
      "skill": "fletching",
      "level": 1,
      "station": "any",
      "inputs": {
        "normal_logs": 1,
        "knife": 1
      },
      "outputs": {
        "arrow_shafts": 15
      },
      "xp": 12,
      "icon": "➖"
    },
    {
      "id": "feather_shafts",
      "name": "Make Headless Arrows",
      "skill": "fletching",
      "level": 1,
      "station": "any",
      "inputs": {
        "arrow_shafts": 15,
        "feather": 15
      },
      "outputs": {
        "headless_arrows": 15
      },
      "xp": 15,
      "icon": "➶"
    },
    {
      "id": "tip_bronze_arrows",
      "name": "Make Bronze Arrows",
      "skill": "fletching",
      "level": 1,
      "station": "any",
      "inputs": {
        "headless_arrows": 15,
        "bronze_arrowtips": 15
      },
      "outputs": {
        "bronze_arrow": 15
      },
      "xp": 25,
      "icon": "🏹"
    },
    {
      "id": "tip_iron_arrows",
      "name": "Make Iron Arrows",
      "skill": "fletching",
      "level": 15,
      "station": "any",
      "inputs": {
        "headless_arrows": 15,
        "iron_arrowtips": 15
      },
      "outputs": {
        "iron_arrow": 15
      },
      "xp": 50,
      "icon": "🏹"
    },
    {
      "id": "tip_steel_arrows",
      "name": "Make Steel Arrows",
      "skill": "fletching",
      "level": 30,
      "station": "any",
      "inputs": {
        "headless_arrows": 15,
        "steel_arrowtips": 15
      },
      "outputs": {
        "steel_arrow": 15
      },
      "xp": 75,
      "icon": "🏹"
    },
    {
      "id": "cook_shrimp",
      "name": "Cook shrimp",
      "skill": "cooking",
      "level": 1,
      "station": "range",
      "inputs": {
        "raw_shrimp": 1
      },
      "outputs": {
        "cooked_shrimp": 1
      },
      "xp": 20,
      "icon": "🍖"
    },
    {
      "id": "cook_trout",
      "name": "Cook trout",
      "skill": "cooking",
      "level": 15,
      "station": "range",
      "inputs": {
        "raw_trout": 1
      },
      "outputs": {
        "cooked_trout": 1
      },
      "xp": 50,
      "icon": "🍖"
    },
    {
      "id": "cook_beef",
      "name": "Cook beef",
      "skill": "cooking",
      "level": 1,
      "station": "range",
      "inputs": {
        "raw_beef": 1
      },
      "outputs": {
        "cooked_beef": 1
      },
      "xp": 30,
      "icon": "🍖"
    },
    {
      "id": "cook_rat_meat",
      "name": "Cook rat meat",
      "skill": "cooking",
      "level": 1,
      "station": "range",
      "inputs": {
        "raw_rat_meat": 1
      },
      "outputs": {
        "cooked_rat_meat": 1
      },
      "xp": 16,
      "icon": "🍖"
    },
    {
      "id": "mill_flour",
      "name": "Mill Wheat",
      "skill": "cooking",
      "level": 1,
      "station": "mill",
      "inputs": {
        "wheat": 1
      },
      "outputs": {
        "flour": 1
      },
      "xp": 10,
      "icon": "🥣"
    },
    {
      "id": "bake_bread",
      "name": "Bake Bread",
      "skill": "cooking",
      "level": 1,
      "station": "range",
      "inputs": {
        "flour": 1
      },
      "outputs": {
        "bread": 1
      },
      "xp": 35,
      "icon": "🍞"
    },
    {
      "id": "burn_normal_logs",
      "name": "Burn Normal Logs",
      "skill": "firemaking",
      "level": 1,
      "station": "any",
      "inputs": {
        "normal_logs": 1,
        "tinderbox": 1
      },
      "outputs": {},
      "xp": 40,
      "icon": "🔥"
    },
    {
      "id": "burn_oak_logs",
      "name": "Burn Oak Logs",
      "skill": "firemaking",
      "level": 15,
      "station": "any",
      "inputs": {
        "oak_logs": 1,
        "tinderbox": 1
      },
      "outputs": {},
      "xp": 68,
      "icon": "🔥"
    },
    {
      "id": "burn_willow_logs",
      "name": "Burn Willow Logs",
      "skill": "firemaking",
      "level": 30,
      "station": "any",
      "inputs": {
        "willow_logs": 1,
        "tinderbox": 1
      },
      "outputs": {},
      "xp": 96,
      "icon": "🔥"
    },
    {
      "id": "burn_maple_logs",
      "name": "Burn Maple Logs",
      "skill": "firemaking",
      "level": 45,
      "station": "any",
      "inputs": {
        "maple_logs": 1,
        "tinderbox": 1
      },
      "outputs": {},
      "xp": 124,
      "icon": "🔥"
    },
    {
      "id": "burn_yew_logs",
      "name": "Burn Yew Logs",
      "skill": "firemaking",
      "level": 60,
      "station": "any",
      "inputs": {
        "yew_logs": 1,
        "tinderbox": 1
      },
      "outputs": {},
      "xp": 152,
      "icon": "🔥"
    },
    {
      "id": "saw_oak_planks",
      "name": "Saw Oak Planks",
      "skill": "crafting",
      "level": 12,
      "station": "sawmill",
      "inputs": {
        "oak_logs": 1
      },
      "outputs": {
        "oak_plank": 2
      },
      "xp": 28,
      "icon": "🪵"
    },
    {
      "id": "smith_steel_nails",
      "name": "Smith Steel Nails",
      "skill": "smithing",
      "level": 30,
      "station": "anvil",
      "inputs": {
        "steel_bar": 1
      },
      "outputs": {
        "steel_nails": 15
      },
      "xp": 42,
      "icon": "🔩"
    },
    {
      "id": "sew_pet_bedding",
      "name": "Sew Pet Bedding",
      "skill": "crafting",
      "level": 18,
      "station": "crafting_table",
      "inputs": {
        "ball_of_wool": 3,
        "thread": 2
      },
      "outputs": {
        "pet_bedding": 1
      },
      "xp": 55,
      "icon": "🧺"
    },
    {
      "id": "shape_arcane_lens",
      "name": "Shape Arcane Lens",
      "skill": "crafting",
      "level": 25,
      "station": "crafting_table",
      "inputs": {
        "gold_bar": 1,
        "chisel": 1,
        "law_rune": 1
      },
      "outputs": {
        "arcane_lens": 1
      },
      "xp": 90,
      "icon": "🔮"
    }
  ],
  "enemies": {
    "chicken": {
      "id": "chicken",
      "name": "Chicken",
      "level": 1,
      "hp": 6,
      "aggro": false,
      "speed": 1.2,
      "attackSpeed": 2.4,
      "maxHit": 1,
      "xp": 10,
      "color": "#eee9d9",
      "shape": "chicken",
      "drops": [
        {
          "item": "bones",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "feather",
          "chance": 1,
          "min": 5,
          "max": 15
        },
        {
          "item": "raw_beef",
          "chance": 0.1,
          "min": 1,
          "max": 1
        }
      ]
    },
    "cow": {
      "id": "cow",
      "name": "Cow",
      "level": 2,
      "hp": 12,
      "aggro": false,
      "speed": 1,
      "attackSpeed": 2.4,
      "maxHit": 1,
      "xp": 18,
      "color": "#9a642e",
      "shape": "cow",
      "drops": [
        {
          "item": "bones",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "cowhide",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "raw_beef",
          "chance": 1,
          "min": 1,
          "max": 1
        }
      ]
    },
    "goblin": {
      "id": "goblin",
      "name": "Goblin",
      "level": 5,
      "hp": 15,
      "aggro": true,
      "speed": 1.5,
      "attackSpeed": 2.2,
      "maxHit": 3,
      "xp": 28,
      "color": "#3e963d",
      "shape": "humanoid",
      "drops": [
        {
          "item": "bones",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "coins",
          "chance": 0.75,
          "min": 3,
          "max": 18
        },
        {
          "item": "bronze_sword",
          "chance": 0.08,
          "min": 1,
          "max": 1
        },
        {
          "item": "mind_rune",
          "chance": 0.12,
          "min": 2,
          "max": 8
        }
      ]
    },
    "bear": {
      "id": "bear",
      "name": "Bear",
      "level": 12,
      "hp": 25,
      "aggro": true,
      "speed": 1.3,
      "attackSpeed": 2.6,
      "maxHit": 5,
      "xp": 55,
      "color": "#5b351d",
      "shape": "bear",
      "drops": [
        {
          "item": "big_bones",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "bear_fur",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "coins",
          "chance": 0.45,
          "min": 15,
          "max": 45
        }
      ]
    },
    "spider": {
      "id": "spider",
      "name": "Giant Spider",
      "level": 20,
      "hp": 35,
      "aggro": true,
      "speed": 1.8,
      "attackSpeed": 2,
      "maxHit": 6,
      "xp": 80,
      "color": "#22201e",
      "shape": "spider",
      "drops": [
        {
          "item": "silk",
          "chance": 0.65,
          "min": 1,
          "max": 2
        },
        {
          "item": "coins",
          "chance": 0.35,
          "min": 20,
          "max": 70
        },
        {
          "item": "chaos_rune",
          "chance": 0.08,
          "min": 3,
          "max": 10
        }
      ]
    },
    "skeleton": {
      "id": "skeleton",
      "name": "Skeleton",
      "level": 25,
      "hp": 45,
      "aggro": true,
      "speed": 1.4,
      "attackSpeed": 2.3,
      "maxHit": 7,
      "xp": 110,
      "color": "#ddd7c8",
      "shape": "skeleton",
      "drops": [
        {
          "item": "bones",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "coins",
          "chance": 0.55,
          "min": 25,
          "max": 90
        },
        {
          "item": "iron_sword",
          "chance": 0.06,
          "min": 1,
          "max": 1
        },
        {
          "item": "death_rune",
          "chance": 0.03,
          "min": 2,
          "max": 5
        }
      ]
    },
    "rat": {
      "id": "rat",
      "name": "Sewer Rat",
      "level": 3,
      "hp": 10,
      "aggro": true,
      "speed": 2.1,
      "attackSpeed": 1.9,
      "maxHit": 2,
      "xp": 17,
      "color": "#776b61",
      "shape": "rat",
      "drops": [
        {
          "item": "bones",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "raw_rat_meat",
          "chance": 0.75,
          "min": 1,
          "max": 1
        },
        {
          "item": "rat_tail",
          "chance": 0.5,
          "min": 1,
          "max": 1
        },
        {
          "item": "coins",
          "chance": 0.35,
          "min": 1,
          "max": 6
        }
      ]
    },
    "cave_rat": {
      "id": "cave_rat",
      "name": "Cave Rat",
      "level": 8,
      "hp": 22,
      "aggro": true,
      "speed": 2.3,
      "attackSpeed": 1.8,
      "maxHit": 4,
      "xp": 38,
      "color": "#42342e",
      "shape": "rat",
      "drops": [
        {
          "item": "bones",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "raw_rat_meat",
          "chance": 1,
          "min": 1,
          "max": 2
        },
        {
          "item": "cave_fang",
          "chance": 0.35,
          "min": 1,
          "max": 1
        },
        {
          "item": "iron_ore",
          "chance": 0.12,
          "min": 1,
          "max": 2
        }
      ]
    },
    "sewer_slime": {
      "id": "sewer_slime",
      "name": "Sewer Slime",
      "level": 11,
      "hp": 30,
      "aggro": true,
      "speed": 0.8,
      "attackSpeed": 2.8,
      "maxHit": 5,
      "xp": 52,
      "color": "#4da657",
      "shape": "slime",
      "drops": [
        {
          "item": "slime_core",
          "chance": 0.55,
          "min": 1,
          "max": 1
        },
        {
          "item": "water_rune",
          "chance": 0.45,
          "min": 2,
          "max": 9
        },
        {
          "item": "sewer_key",
          "chance": 0.08,
          "min": 1,
          "max": 1,
          "unique": true
        }
      ]
    },
    "brigand": {
      "id": "brigand",
      "name": "Road Brigand",
      "level": 15,
      "hp": 38,
      "aggro": true,
      "speed": 1.7,
      "attackSpeed": 2.1,
      "maxHit": 6,
      "xp": 72,
      "color": "#6c3131",
      "shape": "humanoid",
      "drops": [
        {
          "item": "bones",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "coins",
          "chance": 0.9,
          "min": 25,
          "max": 100
        },
        {
          "item": "steel_dagger",
          "chance": 0.05,
          "min": 1,
          "max": 1
        },
        {
          "item": "warehouse_key",
          "chance": 0.04,
          "min": 1,
          "max": 1
        }
      ]
    },
    "wolf": {
      "id": "wolf",
      "name": "Grey Wolf",
      "level": 18,
      "hp": 42,
      "aggro": true,
      "speed": 2.2,
      "attackSpeed": 1.9,
      "maxHit": 7,
      "xp": 85,
      "color": "#747b82",
      "shape": "wolf",
      "drops": [
        {
          "item": "bones",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "wolf_pelt",
          "chance": 0.8,
          "min": 1,
          "max": 1
        },
        {
          "item": "raw_beef",
          "chance": 0.65,
          "min": 1,
          "max": 2
        }
      ]
    },
    "dark_wizard": {
      "id": "dark_wizard",
      "name": "Dark Wizard",
      "level": 28,
      "hp": 55,
      "aggro": true,
      "speed": 1.2,
      "attackSpeed": 2.4,
      "maxHit": 10,
      "xp": 140,
      "color": "#542d72",
      "shape": "wizard",
      "combatStyle": "magic",
      "drops": [
        {
          "item": "bones",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "chaos_rune",
          "chance": 0.65,
          "min": 4,
          "max": 16
        },
        {
          "item": "death_rune",
          "chance": 0.18,
          "min": 2,
          "max": 8
        },
        {
          "item": "fire_staff",
          "chance": 0.025,
          "min": 1,
          "max": 1
        },
        {
          "item": "dark_essence",
          "chance": 0.08,
          "min": 1,
          "max": 1
        }
      ]
    },
    "moss_giant": {
      "id": "moss_giant",
      "name": "Moss Giant",
      "level": 32,
      "hp": 75,
      "aggro": true,
      "speed": 1,
      "attackSpeed": 2.8,
      "maxHit": 11,
      "xp": 190,
      "color": "#3d7346",
      "shape": "giant",
      "drops": [
        {
          "item": "big_bones",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "nature_rune",
          "chance": 0.12,
          "min": 2,
          "max": 6
        },
        {
          "item": "steel_battleaxe",
          "chance": 0.04,
          "min": 1,
          "max": 1
        },
        {
          "item": "coins",
          "chance": 0.7,
          "min": 75,
          "max": 260
        }
      ]
    },
    "ogre": {
      "id": "ogre",
      "name": "Ogre",
      "level": 38,
      "hp": 90,
      "aggro": true,
      "speed": 1.1,
      "attackSpeed": 3,
      "maxHit": 14,
      "xp": 240,
      "color": "#889650",
      "shape": "giant",
      "drops": [
        {
          "item": "big_bones",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "steel_legs",
          "chance": 0.025,
          "min": 1,
          "max": 1
        },
        {
          "item": "coins",
          "chance": 0.75,
          "min": 100,
          "max": 350
        },
        {
          "item": "law_rune",
          "chance": 0.08,
          "min": 1,
          "max": 4
        }
      ]
    }
  },
  "bosses": {
    "sewer_king": {
      "id": "sewer_king",
      "name": "The Sewer King",
      "level": 35,
      "hp": 180,
      "aggro": true,
      "speed": 2,
      "attackSpeed": 1.8,
      "maxHit": 12,
      "xp": 620,
      "color": "#8a6652",
      "shape": "king_rat",
      "boss": true,
      "drops": [
        {
          "item": "big_bones",
          "chance": 1,
          "min": 2,
          "max": 2
        },
        {
          "item": "coins",
          "chance": 1,
          "min": 400,
          "max": 900
        },
        {
          "item": "sewer_key",
          "chance": 1,
          "min": 1,
          "max": 1,
          "unique": true
        },
        {
          "item": "king_rat_pet",
          "chance": 0.005,
          "min": 1,
          "max": 1,
          "unique": true
        },
        {
          "item": "slime_core",
          "chance": 0.5,
          "min": 3,
          "max": 8
        }
      ]
    },
    "iron_golem": {
      "id": "iron_golem",
      "name": "Iron Golem",
      "level": 46,
      "hp": 260,
      "aggro": true,
      "speed": 0.8,
      "attackSpeed": 3.1,
      "maxHit": 17,
      "xp": 900,
      "color": "#737b82",
      "shape": "golem",
      "boss": true,
      "drops": [
        {
          "item": "big_bones",
          "chance": 1,
          "min": 2,
          "max": 3
        },
        {
          "item": "iron_bar",
          "chance": 1,
          "min": 4,
          "max": 10
        },
        {
          "item": "steel_bar",
          "chance": 0.55,
          "min": 2,
          "max": 6
        },
        {
          "item": "golem_core",
          "chance": 0.2,
          "min": 1,
          "max": 1
        },
        {
          "item": "mithril_sword",
          "chance": 0.015,
          "min": 1,
          "max": 1
        }
      ]
    },
    "red_dragon": {
      "id": "red_dragon",
      "name": "Red Dragon",
      "level": 50,
      "hp": 320,
      "aggro": true,
      "speed": 1.1,
      "attackSpeed": 2.5,
      "maxHit": 22,
      "xp": 1300,
      "color": "#a32620",
      "shape": "dragon",
      "boss": true,
      "combatStyle": "magic",
      "drops": [
        {
          "item": "dragon_bones",
          "chance": 1,
          "min": 1,
          "max": 1
        },
        {
          "item": "green_dragonhide",
          "chance": 1,
          "min": 1,
          "max": 2
        },
        {
          "item": "coins",
          "chance": 1,
          "min": 800,
          "max": 2500
        },
        {
          "item": "dragonfire_blade",
          "chance": 0.008,
          "min": 1,
          "max": 1,
          "unique": true
        },
        {
          "item": "dragon_pet",
          "chance": 0.002,
          "min": 1,
          "max": 1,
          "unique": true
        }
      ]
    }
  },
  "animals": {
    "butterfly": {
      "id": "butterfly",
      "name": "Butterfly",
      "icon": "🦋",
      "shape": "butterfly",
      "color": "#e8a8e8",
      "secondaryColor": "#73bde8",
      "speed": 1.8,
      "adoptable": false,
      "temporaryFollow": false
    },
    "dog": {
      "id": "dog",
      "name": "Friendly Dog",
      "icon": "🐕",
      "shape": "dog",
      "color": "#9b6d45",
      "secondaryColor": "#5a3828",
      "speed": 2.2,
      "adoptable": true,
      "temporaryFollow": true,
      "followSeconds": [
        12,
        28
      ]
    },
    "cat": {
      "id": "cat",
      "name": "Curious Cat",
      "icon": "🐈",
      "shape": "cat",
      "color": "#777b82",
      "secondaryColor": "#d1c9b8",
      "speed": 2.4,
      "adoptable": true,
      "temporaryFollow": true,
      "followSeconds": [
        10,
        24
      ]
    }
  },
  "harvestables": {
    "sunberry_bush": {
      "id": "sunberry_bush",
      "name": "Sunberry Bush",
      "icon": "🫐",
      "item": "garden_berries",
      "skill": "farming",
      "level": 1,
      "xp": 14,
      "qty": [
        1,
        3
      ],
      "respawnSeconds": 28,
      "shape": "bush",
      "color": "#47713f",
      "produceColor": "#8e315f"
    },
    "apple_tree": {
      "id": "apple_tree",
      "name": "Garden Apple Tree",
      "icon": "🍎",
      "item": "apple",
      "skill": "farming",
      "level": 5,
      "xp": 24,
      "qty": [
        1,
        2
      ],
      "respawnSeconds": 42,
      "shape": "tree",
      "color": "#4c783f",
      "produceColor": "#bd3535"
    },
    "carrot_patch": {
      "id": "carrot_patch",
      "name": "Carrot Patch",
      "icon": "🥕",
      "item": "carrot",
      "skill": "farming",
      "level": 3,
      "xp": 18,
      "qty": [
        1,
        3
      ],
      "respawnSeconds": 32,
      "shape": "patch",
      "color": "#4f843e",
      "produceColor": "#d66a24"
    },
    "herb_bed": {
      "id": "herb_bed",
      "name": "Kitchen Herb Bed",
      "icon": "🌿",
      "item": "garden_herbs",
      "skill": "farming",
      "level": 8,
      "xp": 30,
      "qty": [
        1,
        2
      ],
      "respawnSeconds": 48,
      "shape": "herbs",
      "color": "#3f7f4d",
      "produceColor": "#86b65a"
    }
  },
  "minigames": {
    "garden_rune_match": {
      "id": "garden_rune_match",
      "name": "Garden Rune Match",
      "icon": "🧩",
      "description": "Match six pairs of garden runes as quickly as possible.",
      "pairCount": 6,
      "timeLimitSeconds": 60,
      "symbols": [
        "🌱",
        "🦋",
        "🍎",
        "🌿",
        "🐕",
        "🐈",
        "⛲",
        "🏹"
      ],
      "rewards": {
        "coins": 45,
        "xp": {
          "farming": 35
        },
        "items": {
          "garden_berries": 2
        }
      }
    }
  },
  "npcs": {
    "banker": {
      "id": "banker",
      "name": "Banker Ada",
      "role": "bank",
      "color": "#d9c9a0",
      "building": "Grand Bank",
      "dialogue": [
        "Your valuables are safe beneath Crownstone."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": []
      }
    },
    "shopkeeper": {
      "id": "shopkeeper",
      "name": "Shopkeeper Giles",
      "role": "shop",
      "shop": "general_store",
      "color": "#d4a735",
      "building": "General Store",
      "dialogue": [
        "Everything an adventurer needs, except good judgment."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": []
      }
    },
    "blacksmith": {
      "id": "blacksmith",
      "name": "Smith Brann",
      "role": "craft",
      "station": "anvil",
      "shop": "armor_shop",
      "color": "#985b3b",
      "building": "Forge",
      "dialogue": [
        "Ore becomes opportunity under a proper hammer."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": [
          "wind_strike",
          "water_strike"
        ]
      }
    },
    "smelter": {
      "id": "smelter",
      "name": "Furnace Keeper Iona",
      "role": "craft",
      "station": "furnace",
      "color": "#d36b3a",
      "building": "Forge",
      "dialogue": [
        "Mind the heat. Steel needs coal and patience."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": [
          "wind_strike",
          "water_strike"
        ]
      }
    },
    "fletcher": {
      "id": "fletcher",
      "name": "Fletcher Rowan",
      "role": "craft",
      "station": "fletching_bench",
      "shop": "ranger_shop",
      "color": "#5d8e45",
      "building": "Fletching Hall",
      "dialogue": [
        "A bow begins as a log and ends as a promise."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": [
          "wind_strike",
          "water_strike"
        ]
      }
    },
    "tanner": {
      "id": "tanner",
      "name": "Tanner Ellis",
      "role": "craft",
      "station": "tannery",
      "color": "#765039",
      "building": "Tannery",
      "quest": "apprentice_crafter",
      "dialogue": [
        "Bring hides and a few coins. I will make them workable."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": [
          "wind_strike",
          "water_strike"
        ]
      }
    },
    "weaver": {
      "id": "weaver",
      "name": "Weaver Tessa",
      "role": "craft",
      "station": "spinning_wheel",
      "color": "#9c6cab",
      "building": "Weaver Hall",
      "quest": "spider_thread",
      "dialogue": [
        "Flax becomes bow string here. Wool becomes thread."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": [
          "wind_strike",
          "water_strike"
        ]
      }
    },
    "chef": {
      "id": "chef",
      "name": "Master Chef Horace",
      "role": "craft",
      "station": "range",
      "color": "#db645a",
      "building": "Golden Ladle Inn",
      "quest": "cooks_assistant",
      "dialogue": [
        "The city guard eats like an army because it is one."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": [
          "wind_strike",
          "water_strike"
        ]
      }
    },
    "wizard": {
      "id": "wizard",
      "name": "Wizard Gray",
      "role": "quest",
      "shop": "magic_shop",
      "color": "#4fa3d6",
      "building": "Arcane Tower",
      "quest": "thirsty_mage",
      "dialogue": [
        "A bucket of milk steadies the hands before spellwork."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": [
          "wind_strike",
          "water_strike"
        ]
      }
    },
    "huntsman": {
      "id": "huntsman",
      "name": "Huntsman Vale",
      "role": "slayer",
      "color": "#4f7738",
      "building": "Ranger Lodge",
      "quest": "bear_hunt",
      "dialogue": [
        "I assign dangerous work to people who look capable."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": []
      }
    },
    "guildmaster": {
      "id": "guildmaster",
      "name": "Guildmaster Orin",
      "role": "quest",
      "color": "#d49d39",
      "building": "Adventurers Guild",
      "quest": "dragon_slayer",
      "dialogue": [
        "The eastern wastes belong to a dragon. Change that."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": [
          "wind_strike",
          "water_strike"
        ]
      }
    },
    "priest": {
      "id": "priest",
      "name": "Priest Mara",
      "role": "prayer",
      "color": "#ded8bd",
      "building": "Temple",
      "dialogue": [
        "Bury bones respectfully and your devotion will grow."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": []
      }
    },
    "farmer": {
      "id": "farmer",
      "name": "Farmer Bryn",
      "role": "farm",
      "color": "#9a8439",
      "building": "Market Farm",
      "dialogue": [
        "Plant seeds in the city allotment and return after they grow."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": []
      }
    },
    "guard": {
      "id": "guard",
      "name": "Crownstone Guard",
      "role": "guard",
      "color": "#7184a0",
      "building": "Guard Barracks",
      "dialogue": [
        "Keep your weapon sheathed inside the walls."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": [
          "wind_strike"
        ]
      }
    },
    "sewer_keeper": {
      "id": "sewer_keeper",
      "name": "Drainmaster Pell",
      "role": "quest",
      "color": "#65716c",
      "building": "Sewer Works",
      "quest": "sewer_key",
      "dialogue": [
        "The old sewer chest has a lock. The key vanished among the slimes."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": [
          "wind_strike",
          "water_strike"
        ]
      }
    },
    "carpenter": {
      "id": "carpenter",
      "name": "Carpenter Nessa",
      "role": "craft",
      "station": "sawmill",
      "color": "#9b7447",
      "building": "Carpenters Guild",
      "dialogue": [
        "Oak logs become useful planks at the saw bench."
      ],
      "inventory": [
        "spellbook"
      ],
      "spellbook": {
        "learned": [
          "wind_strike"
        ]
      }
    }
  },
  "shops": {
    "general_store": {
      "id": "general_store",
      "name": "Crownstone General Store",
      "buyMultiplier": 1.15,
      "sellMultiplier": 0.45,
      "stock": {
        "bucket": 20,
        "tinderbox": 20,
        "small_fishing_net": 10,
        "fishing_rod": 10,
        "knife": 20,
        "hammer": 20,
        "needle": 20,
        "thread": 100,
        "rope": 10,
        "bronze_pickaxe": 8,
        "bronze_hatchet": 8,
        "bronze_sword": 8,
        "air_rune": 200,
        "mind_rune": 200,
        "water_rune": 150,
        "earth_rune": 150,
        "fire_rune": 150,
        "body_rune": 100,
        "chaos_rune": 60,
        "death_rune": 30,
        "nature_rune": 25,
        "law_rune": 25,
        "cabbage_seed": 50,
        "barley_seed": 50,
        "oak_plank": 60,
        "steel_nails": 300,
        "ball_of_wool": 60
      }
    },
    "ranger_shop": {
      "id": "ranger_shop",
      "name": "Rowan’s Bow Shop",
      "buyMultiplier": 1.2,
      "sellMultiplier": 0.5,
      "stock": {
        "normal_shortbow": 10,
        "oak_shortbow": 6,
        "bronze_arrow": 500,
        "iron_arrow": 200,
        "feather": 500,
        "bowstring": 60
      }
    },
    "armor_shop": {
      "id": "armor_shop",
      "name": "Brann’s Armor Counter",
      "buyMultiplier": 1.3,
      "sellMultiplier": 0.5,
      "stock": {
        "bronze_helm": 5,
        "bronze_body": 3,
        "bronze_legs": 3,
        "bronze_boots": 5,
        "bronze_gloves": 5,
        "bronze_shield": 4,
        "bronze_dagger": 6,
        "bronze_sword": 6,
        "bronze_longsword": 4,
        "bronze_battleaxe": 4,
        "iron_helm": 4,
        "iron_body": 2,
        "iron_legs": 2,
        "iron_boots": 4,
        "iron_gloves": 4,
        "iron_shield": 3,
        "iron_dagger": 4,
        "iron_sword": 4,
        "iron_longsword": 3,
        "iron_battleaxe": 3,
        "steel_helm": 2,
        "steel_body": 1,
        "steel_legs": 1,
        "steel_boots": 2,
        "steel_gloves": 2,
        "steel_shield": 2,
        "steel_dagger": 2,
        "steel_sword": 2,
        "steel_longsword": 1,
        "steel_battleaxe": 1,
        "leather_cowl": 8,
        "leather_body": 6,
        "leather_chaps": 6,
        "leather_boots": 8,
        "leather_gloves": 8
      }
    },
    "magic_shop": {
      "id": "magic_shop",
      "name": "Gray’s Rune & Staff Shop",
      "buyMultiplier": 1.25,
      "sellMultiplier": 0.5,
      "stock": {
        "basic_staff": 8,
        "fire_staff": 3,
        "air_rune": 500,
        "mind_rune": 500,
        "water_rune": 300,
        "earth_rune": 300,
        "fire_rune": 300,
        "body_rune": 200,
        "chaos_rune": 100,
        "death_rune": 50,
        "nature_rune": 35,
        "law_rune": 35
      }
    }
  },
  "quests": {
    "thirsty_mage": {
      "id": "thirsty_mage",
      "name": "The Thirsty Mage",
      "giver": "wizard",
      "summary": "Bring Wizard Gray a bucket of milk.",
      "requirements": {},
      "objectives": [
        {
          "type": "item",
          "item": "milk",
          "qty": 1
        }
      ],
      "rewards": {
        "xp": {
          "magic": 150
        },
        "items": {
          "air_rune": 50,
          "mind_rune": 25
        },
        "coins": 100
      }
    },
    "cooks_assistant": {
      "id": "cooks_assistant",
      "name": "The Baker's Feast",
      "giver": "chef",
      "summary": "Bring cooked meat, shrimp, and bread to the Master Chef.",
      "objectives": [
        {
          "type": "item",
          "item": "cooked_beef",
          "qty": 1
        },
        {
          "type": "item",
          "item": "cooked_shrimp",
          "qty": 1
        },
        {
          "type": "item",
          "item": "bread",
          "qty": 1
        }
      ],
      "rewards": {
        "xp": {
          "cooking": 350
        },
        "items": {
          "cabbage_seed": 10
        },
        "coins": 250
      }
    },
    "goblin_slayer": {
      "id": "goblin_slayer",
      "name": "Goblin Menace",
      "giver": "guard",
      "summary": "Defeat ten goblins outside the south gate.",
      "objectives": [
        {
          "type": "kill",
          "enemy": "goblin",
          "qty": 10
        }
      ],
      "rewards": {
        "xp": {
          "attack": 250,
          "strength": 250,
          "defence": 250
        },
        "items": {
          "iron_sword": 1
        },
        "coins": 400
      }
    },
    "spider_thread": {
      "id": "spider_thread",
      "name": "The Spider's Thread",
      "giver": "weaver",
      "summary": "Bring Weaver Tessa five silk.",
      "objectives": [
        {
          "type": "item",
          "item": "silk",
          "qty": 5
        }
      ],
      "rewards": {
        "xp": {
          "crafting": 400
        },
        "items": {
          "bowstring": 15
        },
        "coins": 350
      }
    },
    "bear_hunt": {
      "id": "bear_hunt",
      "name": "Bear Hunt",
      "giver": "huntsman",
      "summary": "Bring three bear furs.",
      "objectives": [
        {
          "type": "item",
          "item": "bear_fur",
          "qty": 3
        }
      ],
      "rewards": {
        "xp": {
          "slayer": 450,
          "ranged": 200
        },
        "items": {
          "oak_shortbow": 1,
          "iron_arrow": 100
        },
        "coins": 500
      }
    },
    "apprentice_crafter": {
      "id": "apprentice_crafter",
      "name": "Apprentice Crafter",
      "giver": "tanner",
      "summary": "Craft and return a leather body.",
      "objectives": [
        {
          "type": "item",
          "item": "leather_body",
          "qty": 1
        }
      ],
      "rewards": {
        "xp": {
          "crafting": 500
        },
        "items": {
          "hard_leather": 4,
          "thread": 30
        },
        "coins": 400
      }
    },
    "sewer_key": {
      "id": "sewer_key",
      "name": "Key Beneath the City",
      "giver": "sewer_keeper",
      "summary": "Find the sewer key and open the locked treasure chest.",
      "objectives": [
        {
          "type": "flag",
          "flag": "sewer_chest_opened",
          "qty": 1
        }
      ],
      "rewards": {
        "xp": {
          "slayer": 800,
          "attack": 500,
          "defence": 500
        },
        "items": {
          "coins": 1200
        },
        "coins": 0
      }
    },
    "dragon_slayer": {
      "id": "dragon_slayer",
      "name": "Dragon Slayer",
      "giver": "guildmaster",
      "summary": "Slay the red dragon and return dragon bones.",
      "objectives": [
        {
          "type": "kill",
          "enemy": "red_dragon",
          "qty": 1
        },
        {
          "type": "item",
          "item": "dragon_bones",
          "qty": 1
        }
      ],
      "rewards": {
        "xp": {
          "attack": 1200,
          "strength": 1200,
          "defence": 1200
        },
        "items": {
          "mithril_body": 1
        },
        "coins": 3000
      }
    }
  },
  "slayerTasks": [
    {
      "id": "rats",
      "name": "Sewer Cleanup",
      "enemyPool": [
        "rat",
        "cave_rat"
      ],
      "min": 15,
      "max": 35,
      "minLevel": 1,
      "rewardXp": 8
    },
    {
      "id": "goblins",
      "name": "Goblin Patrol",
      "enemyPool": [
        "goblin"
      ],
      "min": 20,
      "max": 45,
      "minLevel": 1,
      "rewardXp": 10
    },
    {
      "id": "beasts",
      "name": "Forest Predators",
      "enemyPool": [
        "wolf",
        "bear"
      ],
      "min": 15,
      "max": 30,
      "minLevel": 10,
      "rewardXp": 14
    },
    {
      "id": "sewer_horrors",
      "name": "Sewer Horrors",
      "enemyPool": [
        "sewer_slime",
        "cave_rat"
      ],
      "min": 20,
      "max": 40,
      "minLevel": 15,
      "rewardXp": 18
    },
    {
      "id": "giants",
      "name": "Heavy Problems",
      "enemyPool": [
        "moss_giant",
        "ogre"
      ],
      "min": 12,
      "max": 25,
      "minLevel": 30,
      "rewardXp": 25
    },
    {
      "id": "dark_magic",
      "name": "Dark Magic Purge",
      "enemyPool": [
        "dark_wizard",
        "skeleton"
      ],
      "min": 15,
      "max": 30,
      "minLevel": 25,
      "rewardXp": 24
    }
  ],
  "spells": {
    "wind_strike": {
      "id": "wind_strike",
      "name": "Wind Strike",
      "level": 1,
      "maxHit": 3,
      "xp": 6,
      "icon": "🌪️",
      "runes": {
        "air_rune": 1,
        "mind_rune": 1
      }
    },
    "water_strike": {
      "id": "water_strike",
      "name": "Water Strike",
      "level": 5,
      "maxHit": 5,
      "xp": 9,
      "icon": "💧",
      "runes": {
        "air_rune": 1,
        "water_rune": 1,
        "mind_rune": 1
      }
    },
    "earth_strike": {
      "id": "earth_strike",
      "name": "Earth Strike",
      "level": 9,
      "maxHit": 7,
      "xp": 12,
      "icon": "🌍",
      "runes": {
        "air_rune": 1,
        "earth_rune": 2,
        "mind_rune": 1
      }
    },
    "fire_strike": {
      "id": "fire_strike",
      "name": "Fire Strike",
      "level": 13,
      "maxHit": 9,
      "xp": 15,
      "icon": "🔥",
      "runes": {
        "air_rune": 2,
        "fire_rune": 3,
        "mind_rune": 1
      }
    },
    "varrock_teleport": {
      "id": "varrock_teleport",
      "name": "Crownstone Teleport",
      "level": 25,
      "teleport": "city",
      "xp": 35,
      "icon": "🏰",
      "runes": {
        "air_rune": 3,
        "fire_rune": 1,
        "law_rune": 1
      }
    },
    "house_teleport": {
      "id": "house_teleport",
      "name": "Player House Teleport",
      "level": 1,
      "teleport": "house",
      "xp": 15,
      "icon": "🏠",
      "runes": {
        "law_rune": 1,
        "air_rune": 1
      }
    }
  },
  "prayers": {
    "thick_skin": {
      "id": "thick_skin",
      "name": "Thick Skin",
      "level": 1,
      "icon": "🛡️",
      "drain": 0.18,
      "bonuses": {
        "defence": 0.05
      }
    },
    "burst_strength": {
      "id": "burst_strength",
      "name": "Burst of Strength",
      "level": 4,
      "icon": "💪",
      "drain": 0.22,
      "bonuses": {
        "strength": 0.05
      }
    },
    "clarity_thought": {
      "id": "clarity_thought",
      "name": "Clarity of Thought",
      "level": 7,
      "icon": "🎯",
      "drain": 0.22,
      "bonuses": {
        "attack": 0.05
      }
    },
    "rock_skin": {
      "id": "rock_skin",
      "name": "Rock Skin",
      "level": 10,
      "icon": "🪨",
      "drain": 0.32,
      "bonuses": {
        "defence": 0.1
      }
    },
    "rapid_heal": {
      "id": "rapid_heal",
      "name": "Rapid Heal",
      "level": 22,
      "icon": "❤️",
      "drain": 0.45,
      "bonuses": {
        "regen": 2
      }
    },
    "protect_melee": {
      "id": "protect_melee",
      "name": "Protect from Melee",
      "level": 43,
      "icon": "⚔️",
      "drain": 0.8,
      "bonuses": {
        "protectMelee": 0.4
      }
    }
  },
  "areas": {
    "city": {
      "id": "city",
      "name": "Crownstone City",
      "center": [
        0,
        0
      ],
      "size": 2100,
      "ground": "#7f8f6a",
      "music": "city",
      "safe": true,
      "unlocked": true,
      "baseY": 0,
      "priority": 10
    },
    "forest": {
      "id": "forest",
      "name": "Greenwood Forest",
      "center": [
        -5200,
        0
      ],
      "size": 2600,
      "ground": "#50784a",
      "music": "forest",
      "safe": false,
      "unlocked": true,
      "baseY": 0,
      "priority": 4
    },
    "mine": {
      "id": "mine",
      "name": "Crownstone Mine",
      "center": [
        5200,
        0
      ],
      "size": 2500,
      "ground": "#777064",
      "music": "mine",
      "safe": false,
      "unlocked": true,
      "baseY": 0,
      "priority": 4
    },
    "southlands": {
      "id": "southlands",
      "name": "South Road",
      "center": [
        0,
        5400
      ],
      "size": 3000,
      "ground": "#858759",
      "music": "field",
      "safe": false,
      "unlocked": true,
      "baseY": 0,
      "priority": 3
    },
    "east_wastes": {
      "id": "east_wastes",
      "name": "Eastern Wastes",
      "center": [
        5400,
        5400
      ],
      "size": 2600,
      "ground": "#8b684e",
      "music": "wastes",
      "safe": false,
      "unlocked": false,
      "requireQuest": "dragon_slayer",
      "baseY": 0,
      "priority": 5
    },
    "sewer": {
      "id": "sewer",
      "name": "Crownstone Sewers",
      "center": [
        30000,
        30000
      ],
      "size": 1850,
      "ground": "#39453e",
      "music": "sewer",
      "safe": false,
      "unlocked": true,
      "baseY": -60,
      "priority": 30
    },
    "house": {
      "id": "house",
      "name": "Player-Owned House",
      "center": [
        16000,
        0
      ],
      "size": 1150,
      "ground": "#687f55",
      "music": "home",
      "safe": true,
      "unlocked": true,
      "baseY": 0,
      "priority": 20
    }
  },
  "achievements": {
    "first_blood": {
      "id": "first_blood",
      "name": "First Blood",
      "description": "Defeat any enemy.",
      "condition": {
        "type": "kills",
        "count": 1
      },
      "reward": {
        "coins": 25
      }
    },
    "city_industry": {
      "id": "city_industry",
      "name": "City Industry",
      "description": "Complete one recipe in Smithing, Crafting, Fletching, and Cooking.",
      "condition": {
        "type": "craftedSkills",
        "skills": [
          "smithing",
          "crafting",
          "fletching",
          "cooking"
        ]
      },
      "reward": {
        "coins": 500
      }
    },
    "rat_problem": {
      "id": "rat_problem",
      "name": "Rat Problem",
      "description": "Defeat 50 rats or cave rats.",
      "condition": {
        "type": "enemyKills",
        "enemies": [
          "rat",
          "cave_rat"
        ],
        "count": 50
      },
      "reward": {
        "items": {
          "steel_sword": 1
        }
      }
    },
    "sewer_secret": {
      "id": "sewer_secret",
      "name": "Beneath Crownstone",
      "description": "Open the locked sewer treasure chest.",
      "condition": {
        "type": "flag",
        "flag": "sewer_chest_opened"
      },
      "reward": {
        "coins": 1000
      }
    },
    "total_250": {
      "id": "total_250",
      "name": "Developing Adventurer",
      "description": "Reach total level 250.",
      "condition": {
        "type": "totalLevel",
        "count": 250
      },
      "reward": {
        "coins": 2500
      }
    }
  },
  "randomEvents": {
    "falling_star": {
      "id": "falling_star",
      "name": "Fallen Star",
      "chancePerMinute": 0.08,
      "duration": 180,
      "area": "mine",
      "rewardTable": [
        {
          "item": "iron_ore",
          "chance": 0.6,
          "min": 2,
          "max": 8
        },
        {
          "item": "coal_ore",
          "chance": 0.35,
          "min": 2,
          "max": 6
        },
        {
          "item": "gold_ore",
          "chance": 0.05,
          "min": 1,
          "max": 2
        }
      ]
    },
    "wandering_merchant": {
      "id": "wandering_merchant",
      "name": "Wandering Merchant",
      "chancePerMinute": 0.05,
      "duration": 240,
      "area": "city"
    },
    "goblin_raid": {
      "id": "goblin_raid",
      "name": "Goblin Raid",
      "chancePerMinute": 0.035,
      "duration": 300,
      "area": "southlands",
      "spawnEnemy": "goblin",
      "count": 12
    }
  },
  "world": {
    "cityBuildings": [
      {
        "id": "bank",
        "name": "Grand Bank",
        "icon": "🏦",
        "use": "Store and withdraw items",
        "district": "West Market",
        "x": -1050,
        "z": -820,
        "w": 290,
        "d": 210,
        "h": 140,
        "color": "#8b8274",
        "doorSide": "south",
        "station": "bank"
      },
      {
        "id": "general_store",
        "name": "General Store",
        "icon": "🛒",
        "use": "Buy tools, runes, seeds, and supplies",
        "district": "West Market",
        "x": -470,
        "z": -850,
        "w": 240,
        "d": 180,
        "h": 115,
        "color": "#8a5d39",
        "doorSide": "south",
        "station": "shop"
      },
      {
        "id": "forge",
        "name": "Forge",
        "icon": "⚒️",
        "use": "Smelt ore and smith equipment",
        "district": "Foundry Ward",
        "x": 500,
        "z": -900,
        "w": 330,
        "d": 240,
        "h": 135,
        "color": "#6e4c3d",
        "doorSide": "south",
        "station": "anvil"
      },
      {
        "id": "barracks",
        "name": "Guard Barracks",
        "icon": "🛡️",
        "use": "City guards and combat quest",
        "district": "Foundry Ward",
        "x": 1200,
        "z": -900,
        "w": 300,
        "d": 220,
        "h": 140,
        "color": "#68758c",
        "doorSide": "south",
        "station": "guards"
      },
      {
        "id": "sewer_works",
        "name": "Sewer Works",
        "icon": "🕳️",
        "use": "Entrance to the sewer dungeon",
        "district": "South Gate",
        "x": 420,
        "z": -1430,
        "w": 270,
        "d": 175,
        "h": 105,
        "color": "#56645e",
        "doorSide": "north",
        "station": "sewer_entrance"
      },
      {
        "id": "fletching_hall",
        "name": "Fletching Hall",
        "icon": "🏹",
        "use": "Make bows, shafts, and arrows",
        "district": "Craft Row",
        "x": -1120,
        "z": -120,
        "w": 280,
        "d": 210,
        "h": 125,
        "color": "#6f7646",
        "doorSide": "east",
        "station": "fletching_bench"
      },
      {
        "id": "tannery",
        "name": "Tannery",
        "icon": "🟫",
        "use": "Tan hides into leather",
        "district": "Craft Row",
        "x": -500,
        "z": -80,
        "w": 250,
        "d": 190,
        "h": 110,
        "color": "#725139",
        "doorSide": "south",
        "station": "tannery"
      },
      {
        "id": "weaver_hall",
        "name": "Weaver Hall",
        "icon": "🧶",
        "use": "Spin flax and wool",
        "district": "Craft Row",
        "x": 350,
        "z": -170,
        "w": 250,
        "d": 190,
        "h": 115,
        "color": "#796080",
        "doorSide": "south",
        "station": "spinning_wheel"
      },
      {
        "id": "inn",
        "name": "Golden Ladle Inn",
        "icon": "🍳",
        "use": "Cook food and begin the chef quest",
        "district": "East Market",
        "x": 850,
        "z": -100,
        "w": 330,
        "d": 250,
        "h": 145,
        "color": "#8d5c40",
        "doorSide": "west",
        "station": "range"
      },
      {
        "id": "tower",
        "name": "Arcane Tower",
        "icon": "✨",
        "use": "Buy runes, staves, and take a magic quest",
        "district": "North Heights",
        "x": -1150,
        "z": 900,
        "w": 230,
        "d": 230,
        "h": 220,
        "color": "#526e8e",
        "doorSide": "east",
        "station": "magic"
      },
      {
        "id": "ranger_lodge",
        "name": "Ranger Lodge",
        "icon": "☠️",
        "use": "Receive Slayer assignments and buy bows",
        "district": "North Heights",
        "x": -470,
        "z": 900,
        "w": 280,
        "d": 210,
        "h": 125,
        "color": "#546f3e",
        "doorSide": "east",
        "station": "slayer"
      },
      {
        "id": "guild",
        "name": "Adventurers Guild",
        "icon": "⚔️",
        "use": "Major quests and adventuring services",
        "district": "North Heights",
        "x": 350,
        "z": 930,
        "w": 360,
        "d": 250,
        "h": 160,
        "color": "#8a7048",
        "doorSide": "north",
        "station": "guild"
      },
      {
        "id": "temple",
        "name": "Temple",
        "icon": "🙏",
        "use": "Restore Prayer points",
        "district": "North Heights",
        "x": 1030,
        "z": 930,
        "w": 300,
        "d": 230,
        "h": 155,
        "color": "#b0aa91",
        "doorSide": "north",
        "station": "altar"
      },
      {
        "id": "market_farm",
        "name": "Market Farm",
        "icon": "🌱",
        "use": "Plant and harvest crops",
        "district": "Garden Ward",
        "x": -1050,
        "z": 1430,
        "w": 250,
        "d": 170,
        "h": 95,
        "color": "#7a6f3f",
        "doorSide": "east",
        "station": "farm"
      },
      {
        "id": "carpenters_guild",
        "name": "Carpenters Guild",
        "icon": "🪚",
        "use": "Saw logs into house-building planks",
        "district": "Garden Ward",
        "x": 350,
        "z": 1400,
        "w": 310,
        "d": 210,
        "h": 130,
        "color": "#806044",
        "doorSide": "south",
        "station": "sawmill"
      }
    ],
    "npcSpawns": [
      {
        "npc": "banker",
        "x": -1050,
        "z": -650
      },
      {
        "npc": "shopkeeper",
        "x": -470,
        "z": -690
      },
      {
        "npc": "blacksmith",
        "x": 450,
        "z": -690
      },
      {
        "npc": "smelter",
        "x": 570,
        "z": -690
      },
      {
        "npc": "fletcher",
        "x": -930,
        "z": -120
      },
      {
        "npc": "tanner",
        "x": -500,
        "z": 85
      },
      {
        "npc": "weaver",
        "x": 350,
        "z": -25
      },
      {
        "npc": "chef",
        "x": 620,
        "z": -100
      },
      {
        "npc": "wizard",
        "x": -990,
        "z": 900
      },
      {
        "npc": "huntsman",
        "x": -280,
        "z": 900
      },
      {
        "npc": "guildmaster",
        "x": 350,
        "z": 755
      },
      {
        "npc": "priest",
        "x": 1030,
        "z": 775
      },
      {
        "npc": "farmer",
        "x": -875,
        "z": 1430
      },
      {
        "npc": "sewer_keeper",
        "x": 420,
        "z": -1600
      },
      {
        "npc": "carpenter",
        "x": 350,
        "z": 1600
      },
      {
        "npc": "guard",
        "x": -140,
        "z": -1720
      },
      {
        "npc": "guard",
        "x": 140,
        "z": -1720
      },
      {
        "npc": "guard",
        "x": 1720,
        "z": 0
      },
      {
        "npc": "guard",
        "x": -1720,
        "z": 0
      },
      {
        "npc": "guard",
        "x": 0,
        "z": 1720
      },
      {
        "npc": "guard",
        "x": 930,
        "z": -760
      }
    ],
    "resourceSpawns": [
      {
        "kind": "tree_normal",
        "x": -4200,
        "z": -400,
        "count": 30,
        "radius": 900,
        "level": 1
      },
      {
        "kind": "tree_oak",
        "x": -5200,
        "z": 200,
        "count": 20,
        "radius": 760,
        "level": 15
      },
      {
        "kind": "tree_willow",
        "x": -6000,
        "z": 800,
        "count": 16,
        "radius": 650,
        "level": 30
      },
      {
        "kind": "tree_maple",
        "x": -6300,
        "z": -600,
        "count": 12,
        "radius": 620,
        "level": 45
      },
      {
        "kind": "tree_yew",
        "x": -7000,
        "z": 500,
        "count": 8,
        "radius": 520,
        "level": 60
      },
      {
        "kind": "rock_copper",
        "x": 4100,
        "z": -650,
        "count": 14,
        "radius": 500,
        "level": 1
      },
      {
        "kind": "rock_tin",
        "x": 4800,
        "z": -400,
        "count": 14,
        "radius": 500,
        "level": 1
      },
      {
        "kind": "rock_iron",
        "x": 5350,
        "z": 250,
        "count": 18,
        "radius": 600,
        "level": 15
      },
      {
        "kind": "rock_coal",
        "x": 6100,
        "z": 650,
        "count": 16,
        "radius": 620,
        "level": 30
      },
      {
        "kind": "rock_silver",
        "x": 6500,
        "z": -500,
        "count": 8,
        "radius": 400,
        "level": 40
      },
      {
        "kind": "rock_gold",
        "x": 7000,
        "z": 400,
        "count": 7,
        "radius": 380,
        "level": 50
      },
      {
        "kind": "fishing_net",
        "x": -2600,
        "z": 2500,
        "count": 8,
        "radius": 330,
        "level": 1
      },
      {
        "kind": "fishing_rod",
        "x": -3100,
        "z": 2900,
        "count": 8,
        "radius": 330,
        "level": 20
      },
      {
        "kind": "flax",
        "x": -1180,
        "z": 1320,
        "count": 28,
        "radius": 190,
        "level": 1
      },
      {
        "kind": "wheat",
        "x": -750,
        "z": 1500,
        "count": 24,
        "radius": 210,
        "level": 1
      },
      {
        "kind": "tree_normal",
        "x": 15370,
        "z": 650,
        "count": 6,
        "radius": 105,
        "level": 1,
        "area": "house"
      },
      {
        "kind": "tree_oak",
        "x": 16610,
        "z": 640,
        "count": 4,
        "radius": 95,
        "level": 15,
        "area": "house"
      },
      {
        "kind": "flax",
        "x": 15470,
        "z": -650,
        "count": 12,
        "radius": 105,
        "level": 1,
        "area": "house"
      },
      {
        "kind": "wheat",
        "x": 15630,
        "z": -710,
        "count": 12,
        "radius": 100,
        "level": 1,
        "area": "house"
      },
      {
        "kind": "fishing_net",
        "x": 16000,
        "z": 760,
        "count": 1,
        "radius": 0,
        "level": 1,
        "area": "house"
      }
    ],
    "enemySpawns": [
      {
        "enemy": "chicken",
        "x": -1200,
        "z": 2450,
        "count": 14,
        "radius": 420,
        "area": "southlands"
      },
      {
        "enemy": "cow",
        "x": -2700,
        "z": 800,
        "count": 14,
        "radius": 520,
        "area": "forest"
      },
      {
        "enemy": "goblin",
        "x": 0,
        "z": 2850,
        "count": 18,
        "radius": 700,
        "area": "southlands"
      },
      {
        "enemy": "bear",
        "x": -5600,
        "z": -500,
        "count": 11,
        "radius": 680,
        "area": "forest"
      },
      {
        "enemy": "spider",
        "x": -6200,
        "z": 1100,
        "count": 12,
        "radius": 600,
        "area": "forest"
      },
      {
        "enemy": "skeleton",
        "x": 3300,
        "z": 4300,
        "count": 12,
        "radius": 680,
        "area": "southlands"
      },
      {
        "enemy": "brigand",
        "x": 0,
        "z": 5000,
        "count": 13,
        "radius": 760,
        "area": "southlands"
      },
      {
        "enemy": "wolf",
        "x": -3800,
        "z": 3100,
        "count": 13,
        "radius": 700,
        "area": "forest"
      },
      {
        "enemy": "dark_wizard",
        "x": 3900,
        "z": 5100,
        "count": 10,
        "radius": 600,
        "area": "east_wastes"
      },
      {
        "enemy": "moss_giant",
        "x": 5800,
        "z": 2500,
        "count": 9,
        "radius": 560,
        "area": "mine"
      },
      {
        "enemy": "ogre",
        "x": 6200,
        "z": 5000,
        "count": 9,
        "radius": 620,
        "area": "east_wastes"
      },
      {
        "enemy": "red_dragon",
        "x": 7000,
        "z": 6500,
        "count": 1,
        "radius": 40,
        "area": "east_wastes",
        "boss": true
      },
      {
        "enemy": "rat",
        "x": 29400,
        "z": 29400,
        "count": 22,
        "radius": 620,
        "area": "sewer"
      },
      {
        "enemy": "cave_rat",
        "x": 30200,
        "z": 29800,
        "count": 16,
        "radius": 560,
        "area": "sewer"
      },
      {
        "enemy": "sewer_slime",
        "x": 29800,
        "z": 30700,
        "count": 14,
        "radius": 580,
        "area": "sewer"
      },
      {
        "enemy": "sewer_king",
        "x": 30900,
        "z": 30900,
        "count": 1,
        "radius": 30,
        "area": "sewer",
        "boss": true
      },
      {
        "enemy": "iron_golem",
        "x": 6000,
        "z": 0,
        "count": 1,
        "radius": 30,
        "area": "mine",
        "boss": true
      }
    ],
    "specialObjects": [
      {
        "id": "house_portal_out",
        "type": "travel",
        "visual": "portal",
        "name": "Portal to Crownstone City Center",
        "x": 16000,
        "z": 120,
        "targetArea": "city",
        "target": [
          0,
          0
        ],
        "icon": "🌀"
      },
      {
        "id": "city_home_portal",
        "type": "travel",
        "visual": "portal",
        "name": "Portal to Your Player-Owned House",
        "x": 0,
        "z": 0,
        "targetArea": "house",
        "target": [
          16000,
          160
        ],
        "icon": "🏠"
      },
      {
        "id": "sewer_ladder_down",
        "type": "travel",
        "visual": "ladder",
        "name": "Climb down sewer ladder",
        "x": 420,
        "z": -1550,
        "targetArea": "sewer",
        "target": [
          29050,
          29050
        ],
        "icon": "🕳️"
      },
      {
        "id": "sewer_ladder_up",
        "type": "travel",
        "visual": "ladder",
        "name": "Climb up to Crownstone",
        "x": 29050,
        "z": 29050,
        "targetArea": "city",
        "target": [
          420,
          -1600
        ],
        "icon": "🪜"
      },
      {
        "id": "sewer_key_cache",
        "type": "pickup",
        "name": "Search broken drain",
        "x": 30100,
        "z": 30550,
        "item": "sewer_key",
        "onceFlag": "sewer_key_cache_taken",
        "icon": "🔍"
      },
      {
        "id": "sewer_treasure",
        "type": "locked_chest",
        "name": "Locked Sewer Treasure Chest",
        "x": 31100,
        "z": 31100,
        "key": "sewer_key",
        "rewards": {
          "sewer_king_blade": 1,
          "plagueguard_body": 1,
          "coins": 1500
        },
        "flag": "sewer_chest_opened",
        "icon": "🧰"
      },
      {
        "id": "silk_stall",
        "type": "thieving_stall",
        "name": "Silk Stall",
        "x": -200,
        "z": -570,
        "item": "silk",
        "level": 1,
        "xp": 40,
        "icon": "🎀"
      },
      {
        "id": "city_bank",
        "type": "station",
        "name": "Bank Booth — Store Items",
        "x": -1050,
        "z": -670,
        "station": "bank",
        "icon": "🏦"
      },
      {
        "id": "city_shop",
        "type": "station",
        "name": "General Store Counter — Buy & Sell",
        "x": -470,
        "z": -715,
        "station": "shop",
        "shop": "general_store",
        "icon": "🛒"
      },
      {
        "id": "city_furnace",
        "type": "station",
        "name": "Furnace — Smelt Bars",
        "x": 420,
        "z": -710,
        "station": "furnace",
        "icon": "🔥"
      },
      {
        "id": "city_anvil",
        "type": "station",
        "name": "Anvil — Smith Equipment",
        "x": 570,
        "z": -710,
        "station": "anvil",
        "icon": "⚒️"
      },
      {
        "id": "city_fletching",
        "type": "station",
        "name": "Fletching Bench — Make Bows & Arrows",
        "x": -935,
        "z": -120,
        "station": "fletching_bench",
        "icon": "🏹"
      },
      {
        "id": "city_tannery",
        "type": "station",
        "name": "Tanning Rack — Tan Hides",
        "x": -500,
        "z": 70,
        "station": "tannery",
        "icon": "🟫"
      },
      {
        "id": "city_spinning",
        "type": "station",
        "name": "Spinning Wheel — Spin Fibres",
        "x": 350,
        "z": -25,
        "station": "spinning_wheel",
        "icon": "🧶"
      },
      {
        "id": "city_range",
        "type": "station",
        "name": "Cooking Range — Cook Food",
        "x": 640,
        "z": -100,
        "station": "range",
        "icon": "🍳"
      },
      {
        "id": "city_altar",
        "type": "station",
        "name": "Temple Altar — Restore Prayer",
        "x": 1030,
        "z": 775,
        "station": "altar",
        "icon": "🙏"
      },
      {
        "id": "city_farm",
        "type": "farm_patch",
        "name": "City Allotment — Plant Seeds",
        "x": -875,
        "z": 1430,
        "station": "farm",
        "icon": "🌱"
      },
      {
        "id": "city_sawmill",
        "type": "station",
        "name": "Saw Bench — Make Oak Planks",
        "x": 350,
        "z": 1550,
        "station": "sawmill",
        "icon": "🪚"
      },
      {
        "id": "house_bank",
        "type": "station",
        "name": "House Bank Chest",
        "x": 15750,
        "z": -140,
        "station": "bank",
        "icon": "🧰"
      },
      {
        "id": "house_range",
        "type": "station",
        "name": "House Cooking Range",
        "x": 15880,
        "z": -150,
        "station": "range",
        "icon": "🍳"
      },
      {
        "id": "house_crafting",
        "type": "station",
        "name": "House Crafting Table",
        "x": 16020,
        "z": -150,
        "station": "crafting_table",
        "icon": "🧵"
      },
      {
        "id": "house_altar",
        "type": "station",
        "name": "House Altar",
        "x": 16160,
        "z": -150,
        "station": "altar",
        "icon": "🙏"
      },
      {
        "id": "house_bed",
        "type": "rest",
        "name": "Rest in Your Bed",
        "x": 15780,
        "z": 280,
        "icon": "🛏️"
      },
      {
        "id": "house_spell_lectern",
        "type": "spellbook",
        "name": "Spellbook Lectern",
        "x": 16160,
        "z": 260,
        "icon": "📕"
      },
      {
        "id": "house_arcane_door",
        "type": "house_unlock",
        "name": "Locked Arcane Study",
        "x": 16330,
        "z": 250,
        "requirements": {
          "oak_plank": 8,
          "steel_nails": 20,
          "arcane_lens": 1
        },
        "flag": "house_arcane_study_unlocked",
        "unlockName": "Arcane Study",
        "icon": "🔒"
      },
      {
        "id": "house_pet_door",
        "type": "house_unlock",
        "name": "Locked Pet Room",
        "x": 16330,
        "z": -180,
        "requirements": {
          "oak_plank": 6,
          "steel_nails": 10,
          "pet_bedding": 1,
          "rope": 2
        },
        "flag": "house_pet_room_unlocked",
        "unlockName": "Pet Room",
        "icon": "🔒"
      },
      {
        "id": "house_enchanting_desk",
        "type": "spellbook",
        "name": "Arcane Study Spell Desk",
        "x": 16500,
        "z": 260,
        "visibleWhenFlag": "house_arcane_study_unlocked",
        "icon": "🔮"
      },
      {
        "id": "house_pet_manager",
        "type": "pet_manager",
        "name": "Pet Room Adoption Board",
        "x": 16500,
        "z": -180,
        "visibleWhenFlag": "house_pet_room_unlocked",
        "icon": "🐾"
      },
      {
        "id": "house_front_door",
        "type": "door",
        "name": "Front Garden Door",
        "x": 16000,
        "z": -380,
        "openFlag": "house_front_door_open",
        "openAngle": -1.5708,
        "icon": "🚪"
      },
      {
        "id": "house_back_door",
        "type": "door",
        "name": "Back Yard Door",
        "x": 16000,
        "z": 380,
        "openFlag": "house_back_door_open",
        "openAngle": 1.5708,
        "icon": "🚪"
      },
      {
        "id": "house_healing_fountain",
        "type": "healing_fountain",
        "name": "Restorative Home Fountain",
        "x": 16000,
        "z": -610,
        "icon": "⛲"
      },
      {
        "id": "house_outdoor_farm",
        "type": "farm_patch",
        "name": "Home Garden Allotment",
        "x": 15640,
        "z": -585,
        "station": "farm",
        "icon": "🌱"
      },
      {
        "id": "house_outdoor_range",
        "type": "station",
        "name": "Outdoor Cooking Hearth",
        "x": 16430,
        "z": -610,
        "station": "range",
        "icon": "🔥"
      },
      {
        "id": "house_training_dummy",
        "type": "training_dummy",
        "name": "Home Combat Training Dummy",
        "x": 16410,
        "z": 570,
        "icon": "🎯"
      },
      {
        "id": "house_garden_game",
        "type": "minigame",
        "name": "Garden Rune Match Table",
        "x": 16180,
        "z": 760,
        "game": "garden_rune_match",
        "icon": "🧩"
      }
    ],
    "cityRoads": [
      {
        "id": "king_road",
        "name": "King Road",
        "x": 0,
        "z": 0,
        "w": 190,
        "d": 3500,
        "width": 190
      },
      {
        "id": "central_boulevard",
        "name": "Central Boulevard",
        "x": 0,
        "z": 100,
        "w": 3500,
        "d": 190,
        "width": 190
      },
      {
        "id": "market_way",
        "name": "Market Way",
        "x": 0,
        "z": -625,
        "w": 3100,
        "d": 180,
        "width": 180
      },
      {
        "id": "north_heights_way",
        "name": "North Heights Way",
        "x": 0,
        "z": 700,
        "w": 3150,
        "d": 180,
        "width": 180
      },
      {
        "id": "garden_lane",
        "name": "Garden Lane",
        "x": -150,
        "z": 1580,
        "w": 2500,
        "d": 170,
        "width": 170
      },
      {
        "id": "west_craft_lane",
        "name": "West Craft Lane",
        "x": -800,
        "z": 430,
        "w": 160,
        "d": 2350,
        "width": 160
      },
      {
        "id": "east_market_lane",
        "name": "East Market Lane",
        "x": 600,
        "z": 350,
        "w": 160,
        "d": 2150,
        "width": 160
      },
      {
        "id": "sewer_spur",
        "name": "Sewer Works Spur",
        "x": 225,
        "z": -1600,
        "w": 520,
        "d": 150,
        "width": 150
      }
    ],
    "terrainRegions": [
      {
        "id": "overworld",
        "name": "Overworld Ground",
        "x": 0,
        "z": 2600,
        "w": 16000,
        "d": 16000,
        "y": -0.65,
        "color": "#657f50"
      },
      {
        "id": "house_ground",
        "name": "House Grounds",
        "x": 16000,
        "z": 0,
        "w": 2300,
        "d": 2300,
        "y": -0.35,
        "color": "#66804f"
      },
      {
        "id": "sewer_ground",
        "name": "Sewer Foundation",
        "x": 30000,
        "z": 30000,
        "w": 3700,
        "d": 3700,
        "y": -60.5,
        "color": "#39453e"
      }
    ],
    "playerHouse": {
      "center": [
        16000,
        0
      ],
      "w": 1000,
      "d": 760,
      "rooms": [
        {
          "id": "main_hall",
          "name": "Main Hall",
          "x": 16000,
          "z": 60,
          "w": 500,
          "d": 360,
          "unlocked": true,
          "color": "#8b7458"
        },
        {
          "id": "kitchen",
          "name": "Kitchen & Workshop",
          "x": 15860,
          "z": -170,
          "w": 360,
          "d": 250,
          "unlocked": true,
          "color": "#7d684f"
        },
        {
          "id": "bedroom",
          "name": "Bedroom",
          "x": 15820,
          "z": 280,
          "w": 280,
          "d": 230,
          "unlocked": true,
          "color": "#745f55"
        },
        {
          "id": "chapel",
          "name": "Chapel",
          "x": 16170,
          "z": -170,
          "w": 230,
          "d": 250,
          "unlocked": true,
          "color": "#8d846b"
        },
        {
          "id": "arcane_study",
          "name": "Arcane Study",
          "x": 16500,
          "z": 260,
          "w": 300,
          "d": 260,
          "flag": "house_arcane_study_unlocked",
          "color": "#5e587f"
        },
        {
          "id": "pet_room",
          "name": "Pet Room",
          "x": 16500,
          "z": -180,
          "w": 300,
          "d": 260,
          "flag": "house_pet_room_unlocked",
          "color": "#7d6659"
        }
      ],
      "doors": [
        {
          "id": "house_front_door",
          "name": "Front Garden Door",
          "x": 16000,
          "z": -380,
          "openFlag": "house_front_door_open"
        },
        {
          "id": "house_back_door",
          "name": "Back Yard Door",
          "x": 16000,
          "z": 380,
          "openFlag": "house_back_door_open"
        }
      ],
      "outdoorActivities": [
        {
          "id": "house_healing_fountain",
          "name": "Restorative fountain",
          "effect": "Full heal and +1 hitpoint per second for 10 minutes"
        },
        {
          "id": "house_outdoor_farm",
          "name": "Garden allotment",
          "skill": "farming"
        },
        {
          "id": "house_fishing_pond",
          "name": "Fishing pond",
          "skill": "fishing"
        },
        {
          "id": "house_woodcutting_grove",
          "name": "Normal and oak grove",
          "skill": "woodcutting"
        },
        {
          "id": "house_outdoor_range",
          "name": "Outdoor cooking hearth",
          "skill": "cooking"
        },
        {
          "id": "house_training_dummy",
          "name": "Combat training dummy",
          "skill": "attack and strength"
        },
        {
          "id": "house_garden_game",
          "name": "Garden Rune Match",
          "skill": "farming",
          "effect": "Memory matching game with coins, Farming XP, and garden produce"
        }
      ]
    },
    "decorationZones": [
      {
        "type": "lamp",
        "x1": -1650,
        "z1": -1650,
        "x2": 1650,
        "z2": 1650,
        "step": 260,
        "count": 0
      },
      {
        "type": "market_clutter",
        "x": -760,
        "z": -500,
        "count": 36,
        "radius": 520
      },
      {
        "type": "garden",
        "x": -850,
        "z": 1150,
        "count": 80,
        "radius": 520
      },
      {
        "type": "residential",
        "x": 850,
        "z": 1250,
        "count": 55,
        "radius": 560
      },
      {
        "type": "forest_floor",
        "x": -5200,
        "z": 0,
        "count": 180,
        "radius": 2200
      },
      {
        "type": "mine_clutter",
        "x": 5200,
        "z": 0,
        "count": 100,
        "radius": 1900
      }
    ],
    "animalSpawns": [
      {
        "animal": "butterfly",
        "x": -900,
        "z": 1150,
        "count": 28,
        "radius": 650,
        "area": "city"
      },
      {
        "animal": "butterfly",
        "x": -5200,
        "z": 200,
        "count": 45,
        "radius": 1900,
        "area": "forest"
      },
      {
        "animal": "dog",
        "x": -350,
        "z": 350,
        "count": 8,
        "radius": 1200,
        "area": "city"
      },
      {
        "animal": "cat",
        "x": 450,
        "z": 500,
        "count": 10,
        "radius": 1250,
        "area": "city"
      },
      {
        "animal": "cat",
        "x": 16000,
        "z": 0,
        "count": 2,
        "radius": 340,
        "area": "house"
      }
    ],
    "harvestableSpawns": [
      {
        "harvestable": "apple_tree",
        "x": 15340,
        "z": -650,
        "count": 3,
        "radius": 75,
        "area": "house"
      },
      {
        "harvestable": "sunberry_bush",
        "x": 15490,
        "z": -800,
        "count": 5,
        "radius": 72,
        "area": "house"
      },
      {
        "harvestable": "carrot_patch",
        "x": 15680,
        "z": -800,
        "count": 6,
        "radius": 64,
        "area": "house"
      },
      {
        "harvestable": "herb_bed",
        "x": 15820,
        "z": -735,
        "count": 5,
        "radius": 58,
        "area": "house"
      }
    ]
  }
}
RUNELITE_DEFAULT_CONTENT;
}

function rlRespond(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function rlBody(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') return [];
    if (strlen($raw) > 8 * 1024 * 1024) rlRespond(['ok' => false, 'error' => 'Request body is too large.'], 413);
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) rlRespond(['ok' => false, 'error' => 'Invalid JSON request body.'], 400);
    return $decoded;
}

function rlText(mixed $value, int $maxLength = 255): string
{
    $text = trim(is_scalar($value) ? (string)$value : '');
    return mb_substr($text, 0, $maxLength);
}

function rlJson(mixed $value): string
{
    $json = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) rlRespond(['ok' => false, 'error' => 'Unable to encode JSON data.'], 400);
    return $json;
}

function rlEnsureTables(PDO $pdo): void
{
    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Runelite_ContentVersions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        content_version INT UNSIGNED NOT NULL,
        schema_version INT UNSIGNED NOT NULL DEFAULT 1,
        content_json LONGTEXT NOT NULL,
        content_hash CHAR(64) NOT NULL,
        created_by BIGINT NULL,
        is_published TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Runelite_ContentVersions_version (content_version),
        KEY idx_FSG_Runelite_ContentVersions_published (is_published, content_version)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Runelite_PlayerSaves (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        owner_key VARCHAR(180) NOT NULL,
        user_id BIGINT NULL,
        session_id VARCHAR(128) NOT NULL,
        character_name VARCHAR(64) NOT NULL,
        revision INT UNSIGNED NOT NULL DEFAULT 1,
        schema_version INT UNSIGNED NOT NULL DEFAULT 1,
        state_json LONGTEXT NOT NULL,
        state_hash CHAR(64) NOT NULL,
        last_area VARCHAR(64) NOT NULL DEFAULT 'city',
        total_level INT UNSIGNED NOT NULL DEFAULT 0,
        combat_level INT UNSIGNED NOT NULL DEFAULT 0,
        play_seconds BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Runelite_PlayerSaves_owner_character (owner_key, character_name),
        KEY idx_FSG_Runelite_PlayerSaves_user_updated (user_id, updated_at),
        KEY idx_FSG_Runelite_PlayerSaves_session_updated (session_id, updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Runelite_PlayerEvents (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        owner_key VARCHAR(180) NOT NULL,
        user_id BIGINT NULL,
        session_id VARCHAR(128) NOT NULL,
        character_name VARCHAR(64) NOT NULL,
        event_id VARCHAR(128) NOT NULL,
        event_type VARCHAR(80) NOT NULL,
        payload_json LONGTEXT NOT NULL,
        client_created_at DATETIME NULL,
        server_created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Runelite_PlayerEvents_event (owner_key, event_id),
        KEY idx_FSG_Runelite_PlayerEvents_character_time (owner_key, character_name, server_created_at),
        KEY idx_FSG_Runelite_PlayerEvents_type_time (event_type, server_created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Runelite_WorldInstances (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        instance_key VARCHAR(128) NOT NULL,
        content_version INT UNSIGNED NOT NULL,
        state_json LONGTEXT NOT NULL,
        revision INT UNSIGNED NOT NULL DEFAULT 1,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_FSG_Runelite_WorldInstances_key (instance_key),
        KEY idx_FSG_Runelite_WorldInstances_active (is_active, updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Runelite_AuditLog (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT NULL,
        session_id VARCHAR(128) NOT NULL,
        action_name VARCHAR(96) NOT NULL,
        target_type VARCHAR(64) NOT NULL,
        target_key VARCHAR(180) NOT NULL,
        before_hash CHAR(64) NULL,
        after_hash CHAR(64) NULL,
        metadata_json LONGTEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_FSG_Runelite_AuditLog_action_time (action_name, created_at),
        KEY idx_FSG_Runelite_AuditLog_user_time (user_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS FSG_Runelite_ServerLocks (
        lock_key VARCHAR(180) NOT NULL,
        lock_token VARCHAR(128) NOT NULL,
        owner_key VARCHAR(180) NOT NULL,
        expires_at DATETIME NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (lock_key),
        KEY idx_FSG_Runelite_ServerLocks_expiry (expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function rlSeedContent(PDO $pdo): void
{
    $count = (int)$pdo->query('SELECT COUNT(*) FROM FSG_Runelite_ContentVersions')->fetchColumn();
    if ($count > 0) return;
    $json = rlDefaultContentJson();
    if (json_decode($json, true) === null) return;
    $decoded = json_decode($json, true);
    $version = max(1, (int)($decoded['meta']['contentVersion'] ?? 1));
    $schema = max(1, (int)($decoded['meta']['schemaVersion'] ?? 1));
    $stmt = $pdo->prepare('INSERT INTO FSG_Runelite_ContentVersions (content_version, schema_version, content_json, content_hash, created_by, is_published) VALUES (?, ?, ?, ?, NULL, 1)');
    $stmt->execute([$version, $schema, $json, hash('sha256', $json)]);
}

function rlCurrentIdentity(PDO $pdo, array $body): array
{
    fsgAuth_startSharedSession();
    $userId = fsgAuth_currentUserIdFromRequest($pdo);
    $sessionId = rlText($body['sessionId'] ?? '', 128);
    if ($sessionId === '') $sessionId = 'anonymous-' . substr(hash('sha256', (string)($_SERVER['REMOTE_ADDR'] ?? '') . (string)($_SERVER['HTTP_USER_AGENT'] ?? '')), 0, 32);
    $ownerKey = $userId > 0 ? 'user:' . $userId : 'session:' . $sessionId;
    $isAdmin = false;
    if ($userId > 0) {
        try {
            $stmt = $pdo->prepare('SELECT is_admin FROM FSG_users WHERE id = ? LIMIT 1');
            $stmt->execute([$userId]);
            $isAdmin = ((int)$stmt->fetchColumn()) === 1;
        } catch (Throwable $e) { $isAdmin = false; }
    }
    return ['userId' => $userId, 'sessionId' => $sessionId, 'ownerKey' => $ownerKey, 'authenticated' => $userId > 0, 'isAdmin' => $isAdmin];
}

function rlLatestContent(PDO $pdo): ?array
{
    $stmt = $pdo->query('SELECT content_version, schema_version, content_json FROM FSG_Runelite_ContentVersions WHERE is_published = 1 ORDER BY content_version DESC, id DESC LIMIT 1');
    $row = $stmt ? $stmt->fetch() : false;
    if (!$row) return null;
    $content = json_decode((string)$row['content_json'], true);
    if (!is_array($content)) return null;
    return ['contentVersion' => (int)$row['content_version'], 'schemaVersion' => (int)$row['schema_version'], 'content' => $content];
}

function rlAudit(PDO $pdo, array $identity, string $action, string $targetType, string $targetKey, ?string $beforeHash, ?string $afterHash, array $metadata = []): void
{
    $stmt = $pdo->prepare('INSERT INTO FSG_Runelite_AuditLog (user_id, session_id, action_name, target_type, target_key, before_hash, after_hash, metadata_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$identity['userId'] ?: null, $identity['sessionId'], $action, $targetType, $targetKey, $beforeHash, $afterHash, rlJson($metadata)]);
}

try {
    $pdo = fsgAuth_dbConnection();
    rlEnsureTables($pdo);
    rlSeedContent($pdo);
    $body = rlBody();
    $identity = rlCurrentIdentity($pdo, $body);
    $action = rlText($_GET['action'] ?? $body['action'] ?? 'bootstrap', 64);

    if ($action === 'bootstrap') {
        $latest = rlLatestContent($pdo);
        rlRespond([
            'ok' => true,
            'authenticated' => $identity['authenticated'],
            'isAdmin' => $identity['isAdmin'],
            'contentVersion' => $latest['contentVersion'] ?? 0,
            'schemaVersion' => $latest['schemaVersion'] ?? 0,
            'content' => ($body['includeContent'] ?? true) ? ($latest['content'] ?? null) : null,
            'serverTime' => gmdate('c'),
        ]);
    }

    if ($action === 'loadPlayer') {
        $characterName = rlText($body['characterName'] ?? 'Adventurer', 64);
        $stmt = $pdo->prepare('SELECT revision, state_json, updated_at FROM FSG_Runelite_PlayerSaves WHERE owner_key = ? AND character_name = ? LIMIT 1');
        $stmt->execute([$identity['ownerKey'], $characterName]);
        $row = $stmt->fetch();
        rlRespond([
            'ok' => true,
            'authenticated' => $identity['authenticated'],
            'revision' => $row ? (int)$row['revision'] : 0,
            'state' => $row ? json_decode((string)$row['state_json'], true) : null,
            'updatedAt' => $row['updated_at'] ?? null,
        ]);
    }

    if ($action === 'savePlayer') {
        $characterName = rlText($body['characterName'] ?? 'Adventurer', 64);
        $state = $body['state'] ?? null;
        if (!is_array($state)) rlRespond(['ok' => false, 'error' => 'Player state must be a JSON object.'], 400);
        $stateJson = rlJson($state);
        if (strlen($stateJson) > 4 * 1024 * 1024) rlRespond(['ok' => false, 'error' => 'Player state is too large.'], 413);
        $requestedRevision = max(0, (int)($body['revision'] ?? 0));
        $schemaVersion = max(1, (int)($state['schemaVersion'] ?? 1));
        $lastArea = rlText($state['area'] ?? 'city', 64);
        $totalLevel = 0;
        foreach (($state['skills'] ?? []) as $skill) $totalLevel += max(0, (int)($skill['level'] ?? 0));
        $combatLevel = max(0, (int)($state['combatLevel'] ?? 0));
        $playSeconds = max(0, (int)($state['playSeconds'] ?? 0));
        $hash = hash('sha256', $stateJson);

        $pdo->beginTransaction();
        try {
            $lock = $pdo->prepare('SELECT id, revision, state_hash FROM FSG_Runelite_PlayerSaves WHERE owner_key = ? AND character_name = ? FOR UPDATE');
            $lock->execute([$identity['ownerKey'], $characterName]);
            $existing = $lock->fetch();
            $beforeHash = $existing['state_hash'] ?? null;
            if ($existing) {
                $currentRevision = (int)$existing['revision'];
                if ($requestedRevision !== $currentRevision) {
                    $pdo->rollBack();
                    rlRespond(['ok' => false, 'error' => 'Save revision conflict. Reload the server save before writing.', 'serverRevision' => $currentRevision], 409);
                }
                $newRevision = $currentRevision + 1;
                $stmt = $pdo->prepare('UPDATE FSG_Runelite_PlayerSaves SET user_id = ?, session_id = ?, revision = ?, schema_version = ?, state_json = ?, state_hash = ?, last_area = ?, total_level = ?, combat_level = ?, play_seconds = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
                $stmt->execute([$identity['userId'] ?: null, $identity['sessionId'], $newRevision, $schemaVersion, $stateJson, $hash, $lastArea, $totalLevel, $combatLevel, $playSeconds, $existing['id']]);
            } else {
                if ($requestedRevision !== 0) {
                    $pdo->rollBack();
                    rlRespond(['ok' => false, 'error' => 'Save revision conflict. No server save exists for the requested revision.', 'serverRevision' => 0], 409);
                }
                $newRevision = 1;
                $stmt = $pdo->prepare('INSERT INTO FSG_Runelite_PlayerSaves (owner_key, user_id, session_id, character_name, revision, schema_version, state_json, state_hash, last_area, total_level, combat_level, play_seconds) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute([$identity['ownerKey'], $identity['userId'] ?: null, $identity['sessionId'], $characterName, $newRevision, $schemaVersion, $stateJson, $hash, $lastArea, $totalLevel, $combatLevel, $playSeconds]);
            }

            $eventStmt = $pdo->prepare('INSERT IGNORE INTO FSG_Runelite_PlayerEvents (owner_key, user_id, session_id, character_name, event_id, event_type, payload_json, client_created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            foreach (array_slice(is_array($body['events'] ?? null) ? $body['events'] : [], 0, 100) as $event) {
                if (!is_array($event)) continue;
                $eventId = rlText($event['eventId'] ?? '', 128);
                $eventType = rlText($event['type'] ?? '', 80);
                if ($eventId === '' || $eventType === '') continue;
                $clientAt = rlText($event['createdAt'] ?? '', 40);
                $clientSql = null;
                if ($clientAt !== '') {
                    $timestamp = strtotime($clientAt);
                    if ($timestamp !== false) $clientSql = gmdate('Y-m-d H:i:s', $timestamp);
                }
                $eventStmt->execute([$identity['ownerKey'], $identity['userId'] ?: null, $identity['sessionId'], $characterName, $eventId, $eventType, rlJson($event['payload'] ?? []), $clientSql]);
            }

            rlAudit($pdo, $identity, 'save_player', 'character', $characterName, $beforeHash, $hash, ['revision' => $newRevision, 'eventCount' => count($body['events'] ?? [])]);
            $pdo->commit();
            rlRespond(['ok' => true, 'revision' => $newRevision, 'stateHash' => $hash, 'savedAt' => gmdate('c')]);
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
    }

    if ($action === 'saveContent') {
        if (!$identity['authenticated'] || !$identity['isAdmin']) rlRespond(['ok' => false, 'error' => 'Administrator login is required to publish global game content.'], 403);
        $content = $body['content'] ?? null;
        if (!is_array($content)) rlRespond(['ok' => false, 'error' => 'Content registry must be a JSON object.'], 400);
        foreach (['meta','settings','skills','items','recipes','enemies','bosses','animals','npcs','shops','quests','slayerTasks','spells','prayers','areas','achievements','randomEvents','world'] as $required) {
            if (!array_key_exists($required, $content)) rlRespond(['ok' => false, 'error' => 'Content registry is missing required category: ' . $required], 400);
        }
        $json = rlJson($content);
        if (strlen($json) > 6 * 1024 * 1024) rlRespond(['ok' => false, 'error' => 'Content registry is too large.'], 413);
        $latest = rlLatestContent($pdo);
        $requested = max(1, (int)($body['contentVersion'] ?? 1));
        $newVersion = max($requested, (int)($latest['contentVersion'] ?? 0) + 1);
        $schemaVersion = max(1, (int)($content['meta']['schemaVersion'] ?? 1));
        $hash = hash('sha256', $json);
        $stmt = $pdo->prepare('INSERT INTO FSG_Runelite_ContentVersions (content_version, schema_version, content_json, content_hash, created_by, is_published) VALUES (?, ?, ?, ?, ?, 1)');
        $stmt->execute([$newVersion, $schemaVersion, $json, $hash, $identity['userId']]);
        rlAudit($pdo, $identity, 'publish_content', 'content_registry', (string)$newVersion, $latest ? hash('sha256', rlJson($latest['content'])) : null, $hash, ['schemaVersion' => $schemaVersion]);
        rlRespond(['ok' => true, 'contentVersion' => $newVersion, 'schemaVersion' => $schemaVersion, 'contentHash' => $hash]);
    }

    if ($action === 'listEvents') {
        $characterName = rlText($body['characterName'] ?? 'Adventurer', 64);
        $limit = min(500, max(1, (int)($body['limit'] ?? 100)));
        $stmt = $pdo->prepare('SELECT event_id, event_type, payload_json, client_created_at, server_created_at FROM FSG_Runelite_PlayerEvents WHERE owner_key = ? AND character_name = ? ORDER BY id DESC LIMIT ' . $limit);
        $stmt->execute([$identity['ownerKey'], $characterName]);
        $events = [];
        foreach ($stmt->fetchAll() as $row) {
            $events[] = ['eventId' => $row['event_id'], 'type' => $row['event_type'], 'payload' => json_decode((string)$row['payload_json'], true), 'clientCreatedAt' => $row['client_created_at'], 'serverCreatedAt' => $row['server_created_at']];
        }
        rlRespond(['ok' => true, 'events' => $events]);
    }

    rlRespond(['ok' => false, 'error' => 'Unknown action.'], 404);
} catch (PDOException $e) {
    error_log('Runelite database error: ' . $e->getMessage());
    rlRespond(['ok' => false, 'error' => 'Database operation failed.'], 500);
} catch (Throwable $e) {
    error_log('Runelite server error: ' . $e->getMessage());
    rlRespond(['ok' => false, 'error' => 'Server operation failed.'], 500);
}
