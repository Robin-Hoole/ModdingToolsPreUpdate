-- RuneLite: Primitive Realm
-- Every game-owned table uses the required FSG_Runelite_ prefix.

CREATE TABLE IF NOT EXISTS FSG_Runelite_ContentVersions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    content_version INT UNSIGNED NOT NULL,
    schema_version INT UNSIGNED NOT NULL DEFAULT 1,
    content_json LONGTEXT NOT NULL,
    content_hash CHAR(64) NOT NULL,
    created_by BIGINT NULL,
    is_published TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_Runelite_ContentVersions_version (content_version),
    KEY idx_FSG_Runelite_ContentVersions_published (is_published, content_version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Runelite_PlayerSaves (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_key VARCHAR(180) NOT NULL,
    user_id BIGINT NULL,
    session_id VARCHAR(128) NOT NULL,
    character_name VARCHAR(64) NOT NULL,
    revision INT UNSIGNED NOT NULL DEFAULT 1,
    schema_version INT UNSIGNED NOT NULL DEFAULT 1,
    state_json LONGTEXT NOT NULL,
    state_hash CHAR(64) NOT NULL,
    last_area VARCHAR(64) NOT NULL DEFAULT 'city',
    total_level INT UNSIGNED NOT NULL DEFAULT 0,
    combat_level INT UNSIGNED NOT NULL DEFAULT 0,
    play_seconds BIGINT UNSIGNED NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_Runelite_PlayerSaves_owner_character (owner_key, character_name),
    KEY idx_FSG_Runelite_PlayerSaves_user_updated (user_id, updated_at),
    KEY idx_FSG_Runelite_PlayerSaves_session_updated (session_id, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Runelite_PlayerEvents (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    owner_key VARCHAR(180) NOT NULL,
    user_id BIGINT NULL,
    session_id VARCHAR(128) NOT NULL,
    character_name VARCHAR(64) NOT NULL,
    event_id VARCHAR(128) NOT NULL,
    event_type VARCHAR(80) NOT NULL,
    payload_json LONGTEXT NOT NULL,
    client_created_at DATETIME NULL,
    server_created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_Runelite_PlayerEvents_event (owner_key, event_id),
    KEY idx_FSG_Runelite_PlayerEvents_character_time (owner_key, character_name, server_created_at),
    KEY idx_FSG_Runelite_PlayerEvents_type_time (event_type, server_created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Runelite_WorldInstances (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    instance_key VARCHAR(128) NOT NULL,
    content_version INT UNSIGNED NOT NULL,
    state_json LONGTEXT NOT NULL,
    revision INT UNSIGNED NOT NULL DEFAULT 1,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_FSG_Runelite_WorldInstances_key (instance_key),
    KEY idx_FSG_Runelite_WorldInstances_active (is_active, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Runelite_AuditLog (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT NULL,
    session_id VARCHAR(128) NOT NULL,
    action_name VARCHAR(96) NOT NULL,
    target_type VARCHAR(64) NOT NULL,
    target_key VARCHAR(180) NOT NULL,
    before_hash CHAR(64) NULL,
    after_hash CHAR(64) NULL,
    metadata_json LONGTEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_FSG_Runelite_AuditLog_action_time (action_name, created_at),
    KEY idx_FSG_Runelite_AuditLog_user_time (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS FSG_Runelite_ServerLocks (
    lock_key VARCHAR(180) NOT NULL,
    lock_token VARCHAR(128) NOT NULL,
    owner_key VARCHAR(180) NOT NULL,
    expires_at DATETIME NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (lock_key),
    KEY idx_FSG_Runelite_ServerLocks_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
